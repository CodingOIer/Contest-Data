#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2100, M = 2e4 + 100;

int n, m; i64 a[N][N], b[N][N], ans[N];
bool vis[N][N], vis3[N][N];

struct Graph{
    int head[N], nxt[M], to[M], cnt;
    void Add(int u, int v) { 
        to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    }
}G1, G2;

bool vis2[N]; int dfn[N], num;
vector<int> ve;
void dfs1(int u) { 
    vis2[u] = 1, dfn[++num] = u;
    for (int i = G2.head[u]; i; i = G2.nxt[i]) 
        if (!vis2[G2.to[i]]) dfs1(G2.to[i]);
}
void dfs2(int u) { 
    vis2[u] = 1, ve.push_back(u);
    for (int i = G1.head[u]; i; i = G1.nxt[i]) 
        if (!vis2[G1.to[i]]) dfs2(G1.to[i]);
}
int p[N];
void solve() {
    int l = SZ(ve) - 1;
    sort(ve.begin() + 1, ve.end());
    For(i, 1, l) For(j, 1, l) {
        b[i][j] = a[ve[i]][ve[j]];
        vis3[i][j] = vis[ve[i]][ve[j]];
    }
    For(k, 1, l) For(i, 1, l) if (vis3[i][k]) For(j, 1, l) if (vis3[k][j]) 
        vis3[i][j] = 1, b[i][j] = min(b[i][j], b[i][k] + b[k][j]);
    
    For(i, 1, n) p[i] = 0;
    For(i, 1, l) if (ve[i] > n) p[ve[i] - n] = i;

    For(i, 1, l) if (ve[i] <= n) { int x = ve[i];
        if (!p[x] || !vis3[i][p[x]]) ans[x] = -2;
        else if (b[i][p[x]] < 0) ans[x] = -1;
        else ans[x] = b[i][p[x]];
    }
}
signed main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.ans", "w", stdout);
    n = read(), m = read();
    memset(a, 0x3f, sizeof a);
    For(i, 1, m) {
        int u = read() + 1, v = read() + 1; i64 w = read();
        if (w & 1) {
            G1.Add(u, v + n), G1.Add(u + n, v);
            G2.Add(v + n, u), G2.Add(v, u + n);
            vis[u][v + n] = 1, a[u][v + n] = min(a[u][v + n], w);
            vis[u + n][v] = 1, a[u + n][v] = min(a[u + n][v], w);
        } else {
            G1.Add(u, v), G1.Add(u + n, v + n);
            G2.Add(v, u), G2.Add(v + n, u + n);
            vis[u + n][v + n] = 1, a[u][v] = min(a[u][v], w);
            vis[u][v] = 1, a[u + n][v + n] = min(a[u + n][v + n], w);
        }
    }

    For(i, 1, 2 * n) if (!vis2[i]) dfs1(i);
    reverse(dfn + 1, dfn + num + 1);
    For(i, 1, 2 * n) vis2[i] = 0;
    For(i, 1, 2 * n) if (!vis2[dfn[i]]) ve = {0}, dfs2(dfn[i]), solve();
    
    For(i, 1, n) {
        if (ans[i] == -2) puts("a-w-r-y");
        else if (ans[i] == -1) puts("Twinkle");
        else cout << ans[i] << '\n'; 
    }
	return 0;
}
