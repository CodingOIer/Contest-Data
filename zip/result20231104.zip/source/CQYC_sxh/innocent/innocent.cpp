#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2010;

int n, m; i64 a[N][N];
bool vis[N][N];

signed main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.out", "w", stdout);
    n = read(), m = read();
    memset(a, 0x3f, sizeof a);
    For(i, 1, m) {
        int u = read() + 1, v = read() + 1; i64 w = read();
        if (w & 1) {
            vis[u][v + n] = 1, a[u][v + n] = min(a[u][v + n], w);
            vis[u + n][v] = 1, a[u + n][v] = min(a[u + n][v], w);
        } else {
            vis[u + n][v + n] = 1, a[u][v] = min(a[u][v], w);
            vis[u][v] = 1, a[u + n][v + n] = min(a[u + n][v + n], w);
        }
    }
    For(k, 1, 2 * n) For(i, 1, 2 * n) if (vis[i][k]) For(j, 1, 2 * n) if (vis[k][j]) 
        vis[i][j] = 1, a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
    For(i, 1, n) {
        if (!vis[i][i + n]) puts("a-w-r-y");
        else if (a[i][i + n] < 0) puts("Twinkle");
        else cout << a[i][i + n] << '\n'; 
    }
	return 0;
}
