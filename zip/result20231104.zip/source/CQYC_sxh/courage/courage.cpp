#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


const int N = 2010;
int n;
int head[N], nxt[N << 1], to[N << 1], cnt, d[N];
void Add(int u, int v) {
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt, ++d[v];
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt, ++d[u];
}

namespace part1 {
	int f[N][N], siz[N], g[N];
	void dfs(int u, int fa) {
		f[u][0] = 1; Eor(u) if (to[i] != fa) {
			dfs(to[i], u);
			For(j, 0, siz[u]) g[j] = f[u][j], f[u][j] = 0;
			For(j, 0, siz[u]) For(k, 0, siz[to[i]]) 
				add(f[u][j + k], 1ll * g[j] * f[to[i]][k] % mod);
			siz[u] += siz[to[i]];
		}
		++siz[u]; Rof(i, siz[u], 1) f[u][i] = f[u][i - 1]; f[u][0] = 0;
		For(i, 0, siz[u]) add(f[u][i], f[u][i + 2] * (i + 1ll) % mod);
	}
	int work() { dfs(1, 0); return f[1][0]; }
}

namespace part2 {
	int work() { return 0; }
}
signed main() {
	freopen("courage.in", "r", stdin);
	freopen("courage.out", "w", stdout);
    n = read(); For(i, 2, n) Add(read(), read());
	cout << part1::work() <<" ";
	cout << part2::work() <<"\n";
	return 0;
}
