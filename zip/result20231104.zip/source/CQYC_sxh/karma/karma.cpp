#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 100;

int n; i64 ans; string s;
struct node { int x, y; }a[N];
bool cmp(node x, node y) { return 1ll * x.y * y.x < 1ll * y.y * x.x; }

namespace part1 {
    i64 f[1 << 18]; 
    void solve() {
        memset(f, 0x3f, sizeof f), f[0] = 0;
        int o = (1 << n) - 1;
        For(i, 0, o - 1) { i64 cnt0 = 0, cnt1 = 0;
            For(j, 1, n) if ((i >> (j - 1)) & 1) 
                cnt0 += a[j].x, cnt1 += a[j].y;
            For(j, 1, n) if ((i >> (j - 1)) & 1 ^ 1) {
                f[i ^ (1 << (j - 1))] = min(f[i ^ (1 << (j - 1))], 
                f[i] + min(a[j].y * cnt0, cnt1 * a[j].x));
            }
        } cout << ans + f[o];
    }
}
signed main() {
	freopen("karma.in", "r", stdin);
	freopen("karma.out", "w", stdout);
    n = read(); 
    For(i, 1, n) { 
        cin >> s; for (auto c : s) {
            if (c == '1') ++a[i].y;
            else ans += a[i].y, ++a[i].x;
        }
    } 
    sort(a + 1, a + n + 1, cmp); int cnt = 0;
    For(i, 1, n) ans += 1ll * cnt * a[i].x, cnt += a[i].y;
    cout << ans;
	return 0;
}
