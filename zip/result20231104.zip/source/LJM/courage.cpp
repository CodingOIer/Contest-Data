#include<bits/stdc++.h>
#define int long long
#define N 2010
#define mod 998244353
using namespace std;
int n;
int Pow(int a, int n) {
	if(n == 0) return 1;
	if(n == 1) return a;
	int x = Pow(a, n / 2);
	if(n % 2 == 0) return x * x % mod;
	else return x * x % mod * a % mod;
} 
int inv(int x) {
	return Pow(x, mod - 2);
}
int now[N];
vector<int>p[N]; 
int dfn[N], b[N], cnt, siz[N];
int col[N], ans, out[N];
/*void dfs(int x, int fa, int tot) {
	if(tot > n / 2) {
		ans++;
		return;
	}
	dfn[x] = ++cnt;
	b[cnt] = x;
	siz[x] = 1;
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == fa) continue;
		dfs(y, x);
		siz[x] += siz[y];
	}
	for(int i = dfn[x]; i <= dfn[x] + siz[x] - 1; i++) {
		int now = b[i];
		if(col[now]) continue;
		col[x] = tot;
		col[now] = tot;
		for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == fa) continue;
		dfs(y, x, tot + 1);
	    }
	    col[x] = 0;
	    col[now] = 0;
	}
}*/
signed main() {
	freopen("courage.in", "r", stdin);
	freopen("courage.out", "w", stdout);
    cin >> n;
    if(n % 2 == 1) {
    	cout << 0 << " " << 0 << endl;
    	return 0;
	}
    for(int i = 1; i <= n - 1; i++) {
    	int u, v;
    	cin >> u >> v;
    	p[u].push_back(v);
    	p[v].push_back(u);
    	out[u]++;
    	out[v]++;
	}
	for(int i = 1; i <= n; i++) {
		if(out[i] == n - 1) {
			cout << 0 << " " << 0;
			return 0;
		}
	}
	/*if(n <= 10) {
		dfs(1, 0);
		cout << ans << " " << 114514 << endl;
		return 0;
	}*/
	int ret = 1;
	for(int i = 1; i <= n - 1; i += 2) ret = ret * i % mod;
	cout << ret << " " << 114514; 
	return 0; 
}

