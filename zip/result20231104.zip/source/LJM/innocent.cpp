#include<bits/stdc++.h>
#define int long long
#define N 3010
using namespace std;
int n, m;
struct node{
	int to, w;
};
vector<node>p[N];
int dis[N][N], num[N];
bool vis[N];
queue<int>Q;
bool B[N];
bool SPFA(int S) {
	for(int i = 1; i <= 2 * n; i++) {
		dis[S][i] = 1e18;
		num[i] = 0;
		vis[i] = 0;
	} 
	dis[S][S] = 0;
	while(!Q.empty()) Q.pop();
	Q.push(S);
	vis[S] = 1;
	num[S]++;
	while(!Q.empty()) {
		int x = Q.front();
		Q.pop();
		vis[x] = 0;
		for(int i = 0; i < p[x].size(); i++) {
			int y = p[x][i].to;
			if(dis[S][x] + p[x][i].w < dis[S][y]) {
				dis[S][y] = dis[S][x] + p[x][i].w;
				if(!vis[y]) {
					Q.push(y);
					vis[y] = 1;
					num[y]++;
					if(num[y] > 2 * n + 3) {
						/*for(int i = 1; i <= 2 * n; i++) {
							if(num[i] > 2 * n + 3) B[i] = 1;
						}*/
						B[y] = 1;
						return 0;
					} 
				}
			}
		}
	}
	return 1;
}
bool can[N][N];
void dfs(int x, int S) {
	if(can[S][x]) return;
	can[S][x] = 1;
	for(int i = 0; i < p[x].size(); i++) dfs(p[x][i].to, S);
}
signed main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.out", "w", stdout);
    scanf("%lld %lld", &n, &m);
    for(int i = 1; i <= m; i++) {
    	int u, v, w;
    	scanf("%lld %lld %lld", &u, &v, &w);
    	u++, v++;
    	if(w % 2 == 0) {
    		p[u].push_back((node){v, w});
    		p[u + n].push_back((node){v + n, w});
		}
		else {
			p[u].push_back((node){v + n, w});
    		p[u + n].push_back((node){v, w});
		}
	}
	for(int i = 1; i <= 2 * n; i++) dfs(i, i);
	for(int i = 1; i <= n; i++) {
		if(!can[i][i + n]) {
			printf("a-w-r-y\n");
			continue;
		}
		bool flag = 0;
		for(int j = 1; j <= 2 * n; j++) {
			if(!B[j]) continue;
			if(can[i][j] && can[j][i + n]) {
				printf("Twinkle\n");
				flag = 1;
				break;
			}
		}
		if(flag) continue;
		bool num = SPFA(i);
		if(dis[i][i + n] == 1e18) printf("a-w-r-y\n");
		else if(dis[i][i + n] >= 0) printf("%lld\n", dis[i][i + n]);
		else printf("Twinkle\n");
	} 
	return 0;
}
/*
3 4
0 1 -2
1 2 -2
2 1 0
1 0 100
*/
