#include<bits/stdc++.h>
#define int long long
#define N 3010
using namespace std;
int n, m, k, ans;
int u[N], v[N], now[N], sum[N];
vector<int>p[N];
int fa[N], dep[N];
void dd(int x, int father) {
	fa[x] = father;
	dep[x] = dep[father] + 1;
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == father) continue;
		dd(y, x);
	}
}
void gg(int x, int father) {
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == father) continue;
		gg(y, x);
		sum[x] += sum[y];
	}
}
int lca(int x, int y) {
	if(dep[x] < dep[y]) swap(x, y);
	while(dep[x] > dep[y]) x = fa[x];
	if(x == y) return x;
	while(fa[x] != fa[y]) {
		x = fa[x];
		y = fa[y];
	}
	return fa[x];
}
void dfs(int x, int use) {
	if(x > m) {
		if(use != k) return;
		for(int i = 1; i <= n; i++) sum[i] = 0;
		for(int i = 1; i <= m; i++) {
			if(!now[i]) continue;
			sum[u[i]]++;
			sum[v[i]]++;
			int LCA = lca(u[i], v[i]);
			sum[LCA]--;
			sum[fa[LCA]]--;
		} 
		gg(1, 0);
		for(int i = 1; i <= n; i++) 
		    if(sum[i] >= k) {
		    	ans++;
		    	return;
			}
		return;
	}
	if(use < k) {
		now[x] = 1;
		dfs(x + 1, use + 1);
		now[x] = 0;
	}
	now[x] = 0;
	dfs(x + 1, use);
}
signed main() {
	freopen("desire.in", "r", stdin);
	freopen("desire.out", "w", stdout);
	scanf("%lld %lld %lld", &n, &m, &k);
	for(int i = 1; i <= n - 1; i++) {
		int u, v;
		scanf("%lld %lld", &u, &v);
		p[u].push_back(v);
		p[v].push_back(u); 
	}
	for(int i = 1; i <= m; i++) scanf("%lld %lld", &u[i], &v[i]);
	dd(1, 0);
	dfs(1, 0);
	cout << ans;
	return 0;
}
/*
5 5 2
2 1
3 2
4 2
5 3
3 4
3 3
2 3
5 2
3 4
*/
