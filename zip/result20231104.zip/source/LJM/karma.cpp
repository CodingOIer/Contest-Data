#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n, ans;
string s;
struct node{
	int a, b;
}p[N];
bool cmp(node x, node y) {
	return x.b * y.a > y.b * x.a;
}
signed main() {
	freopen("karma.in", "r", stdin);
	freopen("karma.out", "w", stdout);
    cin >> n;
    for(int i = 1; i <= n; i++) {
    	cin >> s;
    	int len = s.length();
    	p[i].b = 0;
    	for(int j = len - 1; j >= 0; j--) {
    		if(s[j] == '1') {
    			p[i].a++;
				ans += p[i].b;
			} 
    		else {
    			p[i].b++;
			}
		}
	}
	sort(p + 1, p + n + 1, cmp);
	int b = 0;
	for(int i = n; i >= 1; i--) {
		ans += p[i].a * b;
		b += p[i].b;
	}
	cout << ans;
	return 0;
}

