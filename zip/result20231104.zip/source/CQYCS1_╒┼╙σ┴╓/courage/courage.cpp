#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e3+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353;
using namespace std;
int n,h[N],to[N<<1],nxt[N<<1],cnt,dp[N][N],siz[N];//i�������ڣ��� j ��δ��ƥ�� 
inline void Add(int &x,int y){
	((x+=y)>=mod) and (x-=mod);
}
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt;
}
inline void Dp(int x,int fa){
	siz[x]=1;
	dp[x][1]=1;
	e(x)if(y^fa){
		Dp(y,x),siz[x]+=siz[y];
		per(j,siz[x],1){
			int pre=dp[x][j];
			rep(k,0,min(siz[y],j))Add(dp[x][j],1LL*dp[y][k]*dp[x][j-k]%mod);
			Add(dp[x][j],(mod-pre)%mod);
		}
	}
	rep(i,0,siz[x]-2)Add(dp[x][i],1LL*dp[x][i+2]*(i+1)%mod);
} 
int main(){
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	n=read();
	for(int i=1,x,y;i^n;i++)x=read(),y=read(),add(x,y),add(y,x);
	if(n%2==1){
		cout <<"0 0\n";
		return 0;
	}
	Dp(1,0);
	cout <<dp[1][0]<<" 0\n";
	return 0;
}
