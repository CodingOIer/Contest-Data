#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e3+5,M=1e4+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m,h[N],to[M],nxt[M],cnt,w[M];
inline void add(int a,int b,int c){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,w[cnt]=c;
}

ll dis[N][2];
vector<Pi >p[N];
struct node{
	int id;
	bool ty;
	ll d;
	bool friend operator<(node a,node b){
		return a.d>b.d;
	}
};
int ct[N][2];
bool vis[N][2];
inline void spfa1(int s){
	priority_queue<node>q;
	rep(i,1,n)dis[i][0]=dis[i][1]=llf,vis[i][0]=vis[i][1],ct[i][0]=ct[i][1]=0;
	dis[s][0]=0;
	q.push({s,0,0});
	while(!q.empty()){
		int x=q.top().id;
		bool ty=q.top().ty;
		vis[x][ty]=0;
		q.pop();
		e(x)if(dis[x][ty]+w[i]<dis[y][(ty+w[i])&1]){
			bool nx=(ty+w[i])&1;
			dis[y][nx]=dis[x][ty]+w[i];
			if(!vis[y][nx]&&ct[y][nx]<=m){
				ct[y][nx]++;
				vis[y][nx]=1;
				q.push({y,nx,dis[y][nx]});
			} 
		}
	}
}
ll dis2[N][2];
int ct2[N][2];
inline void spfa2(int s){
	priority_queue<node>q;
	rep(i,1,n)dis2[i][0]=dis2[i][1]=llf,vis[i][0]=vis[i][1]=ct2[i][0]=ct2[i][1]=0;
	dis2[s][0]=0;
	q.push({s,0,0});
	while(!q.empty()){
		int x=q.top().id;
		bool ty=q.top().ty;
		vis[x][ty]=0;
		q.pop();
		E(x)if(dis2[x][ty]+y.second<dis2[y.first][(ty+y.second)&1]){
			bool nx=(ty+y.second)&1;
			dis2[y.first][nx]=dis2[x][ty]+y.second;
			if(!vis[y.first][nx]&&ct2[y.first][nx]<=n*2){
				ct2[y.first][nx]++;
				vis[y.first][nx]=1;
				q.push({y.first,nx,dis2[y.first][nx]});
			} 
		}
	}
}
inline void solve(int x){
	spfa1(x),spfa2(x);
	bool fl=1;
	ll ans=llf;
	rep(i,1,n){
		if(((ct[i][0]>n*2||ct2[i][1]>n*2)&&(dis[i][0]<llf/10000+1&&dis2[i][1]<llf/10000+1))||((ct[i][1]>n*2||ct2[i][0]>n*2)&&(dis[i][1]<llf/10000+1&&dis2[i][0]<llf/10000+1))){
			fl=0;
			break;
		}
		ans=min({ans,dis[i][0]+dis2[i][1],dis[i][1]+dis2[i][0]});
	}
	if(!fl)cout <<"Twinkle\n";
	else if(ans>=llf/10000+1)cout <<"a-w-r-y\n";
	else cout <<ans<<'\n';
}
int main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	n=read(),m=read();
	for(int i=1,x,y,z;i<=m;i++)x=read()+1,y=read()+1,z=read(),add(x,y,z),p[y].pb({x,z});
	rep(i,1,n)solve(i);
	
	return 0;
}
