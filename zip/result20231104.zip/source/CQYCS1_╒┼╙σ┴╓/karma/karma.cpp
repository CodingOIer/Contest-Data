#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e5+5,M=3e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
ll ans;
char c[N];
int n,cnt;
struct node{
	int c0,c1;
}a[N],b[N];
ll dp[M],sum[M];
inline void get(int s){
	ll sm=0;
	rep(i,1,cnt)if((s>>i-1)&1)sm+=b[i].c1;
	sum[s]=sm;
}
inline bool cmp(node a,node b){
	if(a.c0^b.c0)return a.c0>b.c0;
	return a.c1<b.c1;
}
int main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	n=read();
	rep(i,1,n){
		scanf("%s",c+1);
		int len=strlen(c+1),c1=0;
		rep(j,1,len)if(c[j]=='0')ans+=c1;
		else c1++;
		a[i]={len-c1,c1};
	}
	if(n==1){
		cout <<ans;
		return 0;
	}
	rep(i,1,n)if(a[i].c0&&a[i].c1)b[++cnt]=a[i];
	if(!cnt){
		cout <<ans;
		return 0;
	}
	if(cnt<=18){
		int S=(1<<cnt)-1;
		rep(i,0,S)dp[i]=llf,get(i);
		dp[0]=0;
		rep(s,1,S){
			rep(i,1,cnt)if((s>>i-1)&1){
				int pre=s^(1<<i-1),k=b[i].c0;
				dp[s]=min(dp[s],dp[pre]+1LL*sum[pre]*k);
			}
		}
		cout <<ans+dp[S];
		return 0;
	}
	sort(b+1,b+cnt+1,cmp);
	ll sumy=0;
	rep(i,1,cnt)ans+=b[i].c0*sumy,sumy+=b[i].c1;
	cout <<ans;
	return 0;
}
