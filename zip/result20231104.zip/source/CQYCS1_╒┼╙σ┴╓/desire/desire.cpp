#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e6+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m,k;
int h[N],to[N<<1],nxt[N<<1],cnt;
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt;
}
int dfn[N],Time,son[N],top[N],dep[N],siz[N],f[N];
inline void dfs(int x,int fa){
	f[x]=fa,dep[x]=dep[fa]+1,siz[x]=1;
	e(x)if(y^fa)dfs(y,x),siz[x]+=siz[y],son[x]=siz[y]>siz[son[x]]?y:son[x];
}
inline void Dfs(int x,int low){
	top[x]=low,dfn[x]=++Time;
	if(son[x])Dfs(son[x],low);
	e(x)if(y^f[x]&&y^son[x])Dfs(y,y);
}
inline int lca(int x,int y){
	while(top[x]^top[y])dep[top[x]]>dep[top[y]]?x=f[top[x]]:y=f[top[y]];
	return dep[x]<=dep[y]?x:y;
}
struct road{
	int x,y;
}e[N];
int a[N];
ll ans;
bool fl;
inline void dfS(int x){
	e(x)if(y^f[x])dfS(y),a[x]+=a[y];
	if(a[x]==k)fl=1;
} 
inline int bitcount(int x){
	int ans=0;
	while(x)ans++,x-=x&-x;
	return ans;
}
inline void subtask1(){
	int S=(1<<m)-1;
	rep(s,0,S){
		if(bitcount(s)!=k)continue;
		rep(i,1,n)a[i]=0;
		rep(i,1,m){
			if((s>>i-1)&1){
				int Lca=lca(e[i].x,e[i].y);
				a[e[i].x]++,a[e[i].y]++,a[Lca]--,a[f[Lca]]--;
			}
		}
		fl=0;
		dfS(1);
		ans+=fl;
	}
}
ll mul[N],inv[N];
inline ll qp(ll a,ll b){
	if(!b)return 1;
	ll c=qp(a,b>>1);
	c=c*c%mod;
	if(b&1)c=c*a%mod;
	return c;
}
inline void prep(){
	mul[0]=inv[0]=1;
	rep(i,1,m)mul[i]=mul[i-1]*i%mod;
	inv[m]=qp(mul[m],mod-2);
	per(i,m-1,1)inv[i]=inv[i+1]*(i+1)%mod;
}
inline ll c(int x,int y){
	if(x<0||y<0||x<y)return 0;
	return mul[x]*inv[y]%mod*inv[x-y]%mod;
}
inline void dFs(int x){
	e(x)if(y^f[x])dFs(y),a[x]+=a[y];
} 
inline bool insubt(int x,int y){
	return dfn[y]>=dfn[x]&&dfn[y]<=dfn[x]+siz[x]-1;
}
inline int getson(int x,int y){
	while(dep[top[x]]>y){
		if(dep[top[x]]==dep[y]+1)return top[x];
		x=f[top[x]];
	}
	return son[y];
}
inline void solve(int x,int y){
	if(dep[x]>dep[y])swap(x,y);
	int Lca=lca(x,y);
	int dis=dep[x]+dep[y]-dep[Lca]*2+1,ct=0;
	if(Lca!=x){
		rep(i,1,m)if((insubt(x,e[i].x)&&insubt(y,e[i].y))||(insubt(x,e[i].y)&&insubt(y,e[i].x)))ct++;
	}else if(Lca!=y){
		swap(x,y);
		int xx=getson(x,y);
		rep(i,1,m){
			int X=e[i].x,Y=e[i].y;
			if(insubt(x,Y))swap(X,Y);
			if(!insubt(x,X))continue;
			if(!insubt(y,Y)||(insubt(y,Y)&&!insubt(xx,Y)))ct++;
		}
	}else {
		rep(i,1,n)a[i]=0;
		rep(i,1,m){
			int LA=lca(e[i].x,e[i].y);
			a[e[i].x]++,a[e[i].y]++,a[LA]--,a[f[LA]]--;
		}
		dFs(1),ct=a[x];
	}
	if(dis&1)(ans+=c(ct,k))%=mod;
	else ans=(ans-c(ct,k)+mod)%mod;
}
inline void subtask2(){
	prep();
	rep(i,1,n)rep(j,i,n)solve(i,j);
}
int main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1,x,y;i^n;i++)x=read(),y=read(),add(x,y),add(y,x);
	dfs(1,0),Dfs(1,1);
	rep(i,1,m)e[i].x=read(),e[i].y=read();
	if(m<=16){
		subtask1();
		cout <<ans;
		return 0;
	}
	subtask2();
	cout <<ans;
	return 0;
}
