#include <bits/stdc++.h>
using namespace std;
signed main()
{
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	puts("0 0");
	return 0;
}

