#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int N = 2e6+5;
int n,m,k,p[N],vis[N],f[N],dep[N];
vector<int> g[N];
inline void _dfs(int u,int fa)
{
	f[u] = fa,dep[u] = dep[fa]+1;
	for(auto v:g[u])
	{
		if(v==fa) continue;
		_dfs(v,u);
	}
}
inline void change(int x,int y)
{
	if(dep[x]>dep[y]) swap(x,y);
	while(dep[x]<dep[y]) vis[y]++,y = f[y];
	while(x!=y) vis[x]++,vis[y]++,x = f[x],y = f[y];
	vis[x]++;
}
int s[N],t[N],ans;
inline void get()
{
	for(int i = 1;i<=n;i++) vis[i] = 0;
	for(int i = 1;i<=k;i++)
		change(s[p[i]],t[p[i]]);
	for(int i = 1;i<=n;i++)
		if(vis[i]>=k)
			return ans++,void();
}
void dfs(int x,int las)
{
	if(x>k) return get();
	for(int i = las+1;i<=m;i++)
		p[x] = i,dfs(x+1,i);
}
signed main()
{
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	read(n),read(m),read(k);
	for(int i = 1,u,v;i<n;i++)
		read(u),read(v),g[u].push_back(v),g[v].push_back(u);
	for(int i = 1;i<=m;i++)
		read(s[i]),read(t[i]);
	_dfs(1,0),dfs(1,0);
	write(ans);
	return 0;
}

