#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e5+5;
int n,c,ans;
string s[N];
struct node{
	int id,x,y,len;
	friend bool operator < (node x,node y)
	{
		return (x.x*y.len==y.x*x.len)?(x.y*y.len<y.y*x.len):(x.x*y.len>y.x*x.len);
	}
}a[N];
signed main()
{
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i = 1;i<=n;i++)
	{
		cin>>s[i];
		a[i].id = i,a[i].len = s[i].size();
		for(auto j:s[i])
			if(j=='0') a[i].x++;
			else a[i].y++;
	}
	sort(a+1,a+n+1);
	for(int ii = 1,i;ii<=n;ii++)
	{
		i = a[ii].id;
		for(auto j:s[i])
			if(j=='1') c++;
			else ans+=c;
	}
	cout<<ans;
	return 0;
}

