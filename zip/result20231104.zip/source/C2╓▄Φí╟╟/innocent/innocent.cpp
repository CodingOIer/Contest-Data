#include<bits/stdc++.h>
#define P pair<int,bool>
#define a(x) (x.first)
#define b(x) (x.second)
#define P2 pair<P,bool>
using namespace std;
const int N=1005,M=20005;
const long long INF=1e18;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int head[N][2],nxt[M],w[M],tot;
P to[M];
inline void add(P x,P y,int z){
	to[++tot]=y;
	nxt[tot]=head[a(x)][b(x)];
	w[tot]=z;
	head[a(x)][b(x)]=tot;
}
int n,m,u,v,k,cnt[N][2];
bool zh[N];
long long dis[2][N][2],ans;
int K;
inline void wei_spfa(P s){
	queue<P2> q;
	q.push({s,0});
	P2 p;P u,v;bool nw;
	for(int i=1;i<=n;++i){
		dis[b(s)][i][0]=dis[b(s)][i][1]=INF;
		cnt[i][0]=cnt[i][1]=0;
	}
	dis[b(s)][a(s)][0]=0;
	while(!q.empty()){
		p=q.front(),q.pop();
		u=a(p);
		for(int o=head[a(u)][b(s)];o;o=nxt[o]){
			v=to[o];nw=b(p)^(abs(w[o])&1);
			if(dis[b(s)][a(v)][nw]>dis[b(s)][a(u)][b(p)]+w[o]&&dis[b(s)][a(v)][nw]!=-INF){
				if(++cnt[a(v)][nw]>K||dis[b(s)][a(u)][b(p)]==-INF){
					dis[b(s)][a(v)][nw]=-INF;
				}else dis[b(s)][a(v)][nw]=dis[b(s)][a(u)][b(p)]+w[o];
				q.push({v,nw});
			}
		}
	}
}
int st[50],top;
inline void print(long long x){
	if(x<0) x=-x,putchar('-');
	for(;x;x/=10) st[++top]=x%10+48;
	while(top) putchar(st[top--]);
	putchar('\n');
}
inline long long Add(long long x,long long y){
	if(x==INF||y==INF) return INF;
	return (x==-INF||y==-INF)?(-INF):x+y;
}
int main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	read(n),read(m);
	K=min(m,3000);
	for(int i=1;i<=m;++i){
		read(u),read(v),read(k);
		++u,++v;
		add({u,0},{v,0},k);
		add({v,1},{u,1},k);
	}
	for(int i=1;i<=n;++i){
		wei_spfa({i,0});
		wei_spfa({i,1});
		ans=1e18;
		for(int j=1;j<=n;++j){
			ans=min(ans,Add(dis[0][j][0],dis[1][j][1]));
			ans=min(ans,Add(dis[1][j][0],dis[0][j][1]));
		}
		if(ans==INF) puts("a-w-r-y");
		else if(ans==-INF) puts("Twinkle");
		else print(ans);
	}
	return 0;
}
