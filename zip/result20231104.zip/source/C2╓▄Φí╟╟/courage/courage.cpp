#include<bits/stdc++.h>
using namespace std;
const int N=2005,mod=998244353;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int head[N],to[N<<1],nxt[N<<1],tot;
inline void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
bool sub=1;
int n,u,v,dfn[N],sz[N],idx,xl[N];
void dfs(int p,int fa){
	dfn[p]=++idx;
	sz[p]=1;xl[idx]=p;
	for(int o=head[p];o;o=nxt[o])
		if(to[o]!=fa){
			dfs(to[o],p);
			sz[p]+=sz[to[o]];
		}
}
int vis[N];
int ans1,ans2;
inline bool Fa(int x,int y){return dfn[x]<=dfn[y]&&dfn[y]+sz[y]<=dfn[x]+sz[x];}
void solve(int x){
	if(x==n+1){
		bool ok=1;
		for(int i=1;i<=n&&ok;++i) ok&=(vis[i]!=0);
		ans1+=ok;
		return;
	}
	if(vis[x]!=0){
		solve(x+1);
		return;
	}
	for(int i=dfn[x]+1;i<dfn[x]+sz[x];++i){
		if(vis[xl[i]]!=0) continue;
		vis[x]=xl[i];
		vis[xl[i]]=-1;
		solve(x+1);
		vis[xl[i]]=0;
	}
	vis[x]=0;
	solve(x+1);
}
int main(){
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	read(n);
	for(int i=1;i<n;++i){
		read(u),read(v);
		add(u,v);
		add(v,u);
		sub&=(u==1||v==1);
	}
	if(sub){
		puts("0 0");
		return 0;
	}
	dfs(1,0);
	solve(1);
	printf("%d %d",ans1,ans2);
	return 0;
}

