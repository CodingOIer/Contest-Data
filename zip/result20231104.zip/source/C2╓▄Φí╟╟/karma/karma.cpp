#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int n,m;
struct node{int _0,_1;long long w;}a[N];
char s[N];
inline bool cmp(node x,node y){return 1ll*x._1*y._0<1ll*y._1*x._0;}
long long ans;
int main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	read(n);
	for(int i=1;i<=n;++i){
		scanf("%s",s+1);
		m=strlen(s+1);
		for(int j=1;j<=m;++j){
			if(s[j]=='0'){
				++a[i]._0;
				a[i].w+=a[i]._1;
			}else ++a[i]._1;
		}
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1,_1=0;i<=n;++i){
		ans+=a[i].w+1ll*_1*a[i]._0;
		_1+=a[i]._1;
	}
	printf("%lld",ans);
	return 0;
}
