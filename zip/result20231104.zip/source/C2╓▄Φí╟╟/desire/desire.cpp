#include<bits/stdc++.h>
using namespace std;
const int N=2e6+5,mod=1e9+7;
inline void read(int &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int head[N],to[N<<1],nxt[N<<1],tot;
inline void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
int n,m,k,fac[N],u,v,lca;
int f[N],dep[N],top[N],sz[N],son[N];
void dfs1(int p,int fa){
	f[p]=fa;sz[p]=1;
	dep[p]=dep[fa]+1;
	for(int o=head[p],v;o;o=nxt[o]){
		v=to[o];
		if(v==fa) continue;
		dfs1(v,p);
		if(sz[v]>sz[son[p]]) son[p]=v;
		sz[p]+=sz[v];
	}
}
void dfs2(int p,int tp){
	top[p]=tp;
	if(!son[p]) return;
	dfs2(son[p],tp);
	for(int o=head[p];o;o=nxt[o])
		if(to[o]^f[p]&&to[o]^son[p])
			dfs2(to[o],to[o]);
}
inline int Lca(int x,int y){
	while(top[x]^top[y]){
		if(dep[top[x]]>dep[top[y]]) x=f[top[x]];
		else y=f[top[y]];
	}return dep[x]<dep[y]?x:y;
}
int cnt[N],lc[N];
inline int Inv(int x){
	int ans=1;
	for(int y=mod-2;y;y>>=1){
		if(y&1) ans=1ll*ans*x%mod;
		x=1ll*x*x%mod;
	}
	return ans;
}
inline int C(int n,int m){return n<m?0:1ll*fac[n]*Inv(fac[m])%mod*Inv(fac[n-m])%mod;}
long long ans;
void dfs3(int p){
	for(int o=head[p];o;o=nxt[o])
		if(to[o]^f[p]){
			dfs3(to[o]);
			cnt[p]+=cnt[to[o]];
		}
	ans=1ll*(1ll*ans+C(lc[p]+cnt[p],k)-C(cnt[p],k)+mod)%mod;
}
int main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=1;i<n;++i){
		read(u),read(v);
		add(u,v);
		add(v,u);
	}
	dfs1(1,0);
	dfs2(1,1);
	fac[0]=1;
	for(int i=1;i<=m;++i){
		fac[i]=1ll*fac[i-1]*i%mod;
		read(u),read(v);
		++cnt[u],++cnt[v];
		lca=Lca(u,v);
		cnt[lca]-=2;
		++lc[lca];
	}
	dfs3(1);
	printf("%lld",ans);
	return 0;
}
