/*
    Program: courage.cpp
    Author: 1l6suj7
    DateTime: 2023-11-04 10:58:23
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' '
#define cod(x) cout << (x) << endl

using namespace std;

const int N = 2010;
const ll MOD = 998244353, g = 3, rg = 332748118;

struct edge { int v, nxt; } e[N << 1];
int en, hd[N];

void add(int u, int v) { e[++en] = { v, hd[u] }, hd[u] = en; }

int r[N];

ll qpow(ll x, int k) {
    ll res = 1;
    while(k) {
        if(k & 1) res = res * x % MOD;
        x = x * x % MOD, k >>= 1;
    }
    return res;
}

void ntt(ll * f, ll op, int len) {
    lp(i, 0, len - 1) if(i < r[i]) swap(f[i], f[r[i]]);
    for(int ln = 2, o = 1; ln <= len; ln <<= 1, o <<= 1) {
        ll W = qpow(op == -1? rg : g, (MOD - 1) / ln);
        for(int i = 0; i < len; i += ln) {
            ll w = 1;
            for(int j = i; j < i + o; ++j, w = w * W % MOD) {
                ll t1 = f[j], t2 = w * f[j + o] % MOD;
                f[j] = (t1 + t2) % MOD, f[j + o] = (t1 - t2 + MOD) % MOD;
            }
        }
    }
    ll rev = qpow(len, MOD - 2);
    if(op == -1) lp(i, 0, len - 1) f[i] = f[i] * rev % MOD;
}

int n;
ll f[N][N];

int len = 1, cnt = 0;

void dfs(int now, int fa) {
    f[now][0] = 1;
    for(int i = hd[now]; i; i = e[i].nxt) if(e[i].v != fa) dfs(e[i].v, now);
    ntt(f[now], 1, len);
    for(int i = hd[now]; i; i = e[i].nxt) {
        int v = e[i].v;
        if(v == fa) continue;
        lp(j, 0, len - 1) f[now][j] = f[now][j] * f[v][j] % MOD;
    }
    ntt(f[now], -1, len);
    dlp(i, n, 1) f[now][i] = (f[now][i] + f[now][i - 1]) % MOD;
    ntt(f[now], 1, len);
}

signed main() {
    freopen("courage.in", "r", stdin);
    freopen("courage.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    cin >> n;
    int u, v;
    lp(i, 1, n - 1) cin >> u >> v, add(u, v), add(v, u);
    // while(len <= n + n) len <<= 1, ++cnt;
    // lp(i, 0, len - 1) r[i] = (r[i >> 1] >> 1) | ((i & 1) << (cnt - 1));
    // dfs(1, 0);
    // cout << f[1][n] << ' ' << 0 << endl;
    cout << 0 << ' ' << 0 << endl;
    return 0;
}