/*
    Program: desire.cpp
    Author: 1l6suj7
    DateTime: 2023-11-04 11:58:57
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' ';
#define cod(x) cout << (x) << endl;

using namespace std;

signed main() {
    freopen("desire.in", "r", stdin);
    freopen("desire.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    cout << 10 << endl;
    return 0;
}