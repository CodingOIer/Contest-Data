/*
    Program: innocent.cpp
    Author: 1l6suj7
    DateTime: 2023-11-04 10:08:32
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' ';
#define cod(x) cout << (x) << endl;

using namespace std;

const int N = 2010, M = 400010;

#define READ
int read() {
    int x = 0;
    char c;
    int f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

struct edge { int v, nxt; ll w; } e[M];
int en, hd[N];

void add(int u, int v, ll w) { e[++en] = {v, hd[u], w}, hd[u] = en; }

int n, m, arr[N][N];
ll slf[N];
bool islf[N];

bool vis[N];
void bfs(int s) {
    mst(vis, 0);
    queue<int> q;
    q.push(s), vis[s] = 1;
    while(!q.empty()) {
        int u = q.front(); q.pop();
        for(int i = hd[u]; i; i = e[i].nxt) {
            int v = e[i].v;
            if(vis[v]) continue;
            vis[v] = 1, q.push(v), arr[s][v] = 1;
        }
    }
}

int no(int x) { return n + x; }

ll dis[N];
ll spfa(int s) {
    mst(vis, 0), mst(dis, 0x3f);
    queue<int> q;
    for(int i = hd[s]; i; i = e[i].nxt) q.push(e[i].v), vis[e[i].v] = 1, dis[e[i].v] = min(dis[e[i].v], e[i].w);
    while(!q.empty()) {
        int u = q.front(); q.pop();
        vis[u] = 0;
        if(dis[no(s)] < 0) return -1;
        for(int i = hd[u]; i; i = e[i].nxt) {
            int v = e[i].v;
            if(islf[v] && slf[v] < 0 && arr[v][no(s)]) return -1;
            if(dis[u] + e[i].w < dis[v]) {
                dis[v] = dis[u] + e[i].w;
                if(!vis[v] && arr[v][no(s)]) q.push(v), vis[v] = 1;
            }
        }
    }
    return dis[no(s)];
}

signed main() {
    freopen("innocent.in", "r", stdin);
    freopen("innocent.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read(), m = read();
    int u, v; ll w;
    mst(slf, 0x3f);
    lp(i, 1, m) {
        u = read() + 1, v = read() + 1, w = read();
        if(u == v) islf[u] = 1, slf[u] = min(slf[u], w);
        if(w % 2 != 0) add(u, no(v), w), add(no(u), v, w);
        else add(u, v, w), add(no(u), no(v), w);
    }
    lp(i, 1, n << 1) bfs(i);
    lp(i, 1, n) {
        ll res = spfa(i);
        if(res == -1) printf("Twinkle\n");
        else if(res == MAX8) printf("a-w-r-y\n");
        else printf("%lld\n", res);
    }
    return 0;
}