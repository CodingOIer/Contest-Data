/*
    Program: karma.cpp
    Author: 1l6suj7
    DateTime: 2023-11-04 08:15:43
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' ';
#define cod(x) cout << (x) << endl;

using namespace std;

const int N = 200010;

int n, c0[N], c1[N], id[N];
string s;
ll ans;

bool cmp(int t1, int t2) { return c1[t1] * c0[t2] < c1[t2] * c0[t1]; }

signed main() {
    freopen("karma.in", "r", stdin);
    freopen("karma.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    cin >> n;
    lp(i, 1, n) {
        cin >> s;
        for(int j = 0; j < s.size(); ++j) {
            if(s[j] == '0') ++c0[i], ans += c1[i];
            else ++c1[i];
        }
        id[i] = i;
    }
    sort(id + 1, id + 1 + n, cmp);
    ll t = 0;
    lp(i, 1, n) ans += t * c0[id[i]], t += c1[id[i]];
    cout << ans << endl;
    return 0;
}
/*
3
1
11
101
*/