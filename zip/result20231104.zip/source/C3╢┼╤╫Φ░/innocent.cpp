#include<bits/stdc++.h>
#define int long long
using namespace std;
int head[205],to[205],nxt[205],w[205],tot,vis[205],dis[205],cnt[205];
map<pair<int,int>,int> ma,sf;
int n,m,flag=0;
void add(int x,int y,int z) {
	to[++tot]=y;
	nxt[tot]=head[x];
	w[tot]=z;
	head[x]=tot;
}
void spfa(int x) {
	memset(dis,0x3f,sizeof dis);
	memset(vis,0,sizeof vis);
	queue<int> Q;
	Q.push(x);
	dis[x]=0;
	while(!Q.empty()) {
		int u=Q.front();
		Q.pop();
		vis[u]=0;
		cnt[u]++; 
		if(cnt[u]>2*m) {
			flag=1;
			break;
		}
		for(int i=head[u];i;i=nxt[i]) {
			if(dis[to[i]]>dis[u]+w[i]) {
				dis[to[i]]=dis[u]+w[i];
				if(!vis[to[i]]) {
					Q.push(to[i]);
					vis[to[i]]=1;
				}
			}
		}
	} 
}
signed main() {
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=m;i++) {
		int x,y,z;
		scanf("%lld %lld %lld",&x,&y,&z);
		x++;y++;
		add(x,y,z);
		ma[{x,y}]=z;
		sf[{x,y}]=1;
	}
	for(int i=1;i<=n;i++) {
		flag=0;
		spfa(i);
		if(flag) {
			printf("Twinkle\n");
			continue;
		}
		int ans=1e9;
		for(int j=1;j<=n;j++) {
			if(sf[{j,i}]) {
				ans=min(ans,dis[j]+ma[{j,i}]);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
} 
