#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node {
	int x,y,id;
}a[200005];
bool cmp(node x,node y) {
	if(x.y*y.x<=y.y*x.x) return 1;
	return 0;
}
string s[200005];
signed main() {
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	int n;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) {
		cin>>s[i];
		for(int j=0;j<s[i].size();j++) {
			if(s[i][j]=='0') a[i].x++;
			else a[i].y++;
		}
		a[i].id=i;
	}
	sort(a+1,a+n+1,cmp);
	int ans=0,sum=0;
	for(int i=1;i<=n;i++) {
		for(int j=0;j<s[a[i].id].size();j++) {
			if(s[a[i].id][j]=='1') sum++;
			else ans+=sum;
		}
	}
	printf("%lld",ans);
	return 0;
} 
/*
3
1
11
101
*/
