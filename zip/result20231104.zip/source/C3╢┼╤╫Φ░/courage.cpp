#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	printf("0 0");
	return 0;
} 
