#include<bits/stdc++.h>
#define int long long
using namespace std;
int Rand(int l,int r) {
	return (rand()*rand()+114514)%(r-l+1)+l;
}
int vis[2000005],f[2000005];
signed main() {
	srand(time(0));
	freopen("3.in","w",stdout);
	//for(int i=1;i<=2000000;i++) f[i]=i;
	int n=2e6;
	printf("%d %d %d\n",n,2000000,1000000);
	for(int i=2;i<=n;i++) {
		int w=Rand(1,i-1);
		printf("%d %d\n",w,i);
	}
	for(int i=1;i<=2e6;i++) {
		printf("%d %d\n",Rand(1,n),Rand(1,n));
	}
	return 0;
} 
/*
4
69 0 0 0
1 1 1 1
0 0 3 3
6 1 0 6
*/
