#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+2;
int n,m;
string s[maxn];
namespace brute1{
    void solve(){
        long long num=0,ans=0;
        for(int i=0;i<s[1].size();i++){
            if(s[1][i]=='1')num++;
            else ans+=num;
        }
        printf("%lld\n",ans);
    }
}
namespace brute2{
    void solve(){
        printf("0\n");
        return ;
    }
}
namespace brute3{
    const int maxs=(1<<18);
    long long cnt[maxn],dp[maxs],num[maxs];
    void solve(){
        memset(dp,0x3f,sizeof(dp));
        long long ans=0;
        for(int i=1;i<=n;i++){
            for(int j=0;j<s[i].size();j++){
                if(s[i][j]=='1')cnt[i]++;
                else ans+=cnt[i];
            }
        }
        dp[0]=0;
        for(int S=1;S<(1<<n);S++){
            for(int i=1;i<=n;i++){
                if(S&(1<<i-1)){
                    num[S]+=cnt[i];
                    long long siz=s[i].size();
                    dp[S]=min(dp[S],dp[S^(1<<i-1)]+num[S^(1<<i-1)]*(siz-cnt[i]));
                }
            }
        }
        printf("%lld\n",dp[(1<<n)-1]+ans);
    }
}
int main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)cin>>s[i],m+=((int)s[i].size());
    if(n==1)brute1::solve();
    else if(n==m)brute2::solve();
    else if(n<=18)brute3::solve();
    return 0;
}