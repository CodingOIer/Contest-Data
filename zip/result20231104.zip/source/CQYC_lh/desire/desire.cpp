#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=2e6+2,logn=23;
const int mod=1e9+7;
int n,m,K;
int cnt;
int hed[maxn],fat[maxn];
int all[maxn],num[maxn];
int fac[maxn],inv_fac[maxn];
bool vis[maxn];
int ans;
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
struct node_q{
    int id,v;
};
struct node_ro{
    int u,v,lca;
}q[maxn];
struct node_edge{
    int nxt,to;
}G[maxn*2];
vector<node_q>qu[maxn];
struct UFS{
    int fa[maxn],siz[maxn],tp[maxn];
    void init(int mx){
        for(int i=1;i<=mx;i++)fa[i]=i,siz[i]=1,tp[i]=i;
        return ;
    }
    int find(int x){return (fa[x]==x)?x:(fa[x]=find(fa[x]));}
    void merge(int u,int v){
        u=find(u),v=find(v);
        int ntp=tp[v];
        if(siz[u]>siz[v])swap(u,v);
        fa[u]=v,siz[v]+=siz[u],tp[v]=ntp;
        return ;
    }
}ufs;
void add(int u,int v){
    G[++cnt]=(node_edge){hed[u],v};
    hed[u]=cnt;
    return ;
}
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void dfs(int x,int f){
    vis[x]=1;
    for(int i=0;i<qu[x].size();i++){
        if(vis[qu[x][i].v])q[qu[x][i].id].lca=ufs.tp[ufs.find(qu[x][i].v)];
    }
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==f)continue;
        dfs(v,x),fat[v]=x;
        ufs.merge(v,x);
    }
    return ;
}
void pre(){
    fac[0]=1;
    for(int i=1;i<maxn;i++)fac[i]=1ll*fac[i-1]*i%mod;
    inv_fac[maxn-1]=f_pow(fac[maxn-1],mod-2);
    for(int i=maxn-1;i;i--)inv_fac[i-1]=1ll*inv_fac[i]*i%mod;
    return ;
}
int calc_C(int a,int b){
    if(a<b||a<0||b<0)return 0;
    return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
}
void get_sum(int x,int f){
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==f)continue;
        get_sum(v,x);
        all[x]+=all[v];
    }
    return ;
}
int main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    pre();
    n=read(),m=read(),K=read();
    for(int i=1,u,v;i<n;i++){
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    for(int i=1;i<=m;i++){
        q[i].u=read(),q[i].v=read();
        qu[q[i].u].push_back((node_q){i,q[i].v});
        qu[q[i].v].push_back((node_q){i,q[i].u});
    }
    ufs.init(n);
    dfs(1,0);
    for(int i=1;i<=m;i++){
        // printf("lcaof %d\n",q[i].lca);
        all[q[i].u]++,all[q[i].v]++;
        all[q[i].lca]--,all[fat[q[i].lca]]--;
        num[q[i].lca]++;
    }
    get_sum(1,0);
    for(int i=1,ano;i<=n;i++){
        ano=all[i]-num[i];
        upd(ans,(calc_C(all[i],K)-calc_C(ano,K)+mod)%mod);
    }
    printf("%d\n",ans);
    return 0;
}