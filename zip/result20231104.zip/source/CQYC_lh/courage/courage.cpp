#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=2e3+10;
const int mod=998244353;
int n;
int siz[maxn];
int pre[maxn][maxn],suf[maxn][maxn],prep[maxn],sufp[maxn],presz[maxn],sufsz[maxn];
int dp[maxn][maxn],g[maxn][maxn],h[maxn][maxn],nv[maxn],ng[maxn],nh[maxn];
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
vector<int>G[maxn];
void add(int u,int v){
    G[u].push_back(v);
    return ;
}
struct node_poly{
    const int G=3;
    int ar[maxn*4];
    int nid[maxn*4];
    void init(){
        memset(ar,0,sizeof(ar));
        memset(nid,0,sizeof(nid));
        return ;
    }
    int f_pow(int x,int p){
        int ret=1;
        while(p){
            if(p%2)ret=1ll*ret*x%mod;
            x=1ll*x*x%mod;
            p/=2;
        }
        return ret;
    }
    void NTT(int len,int type){
        for(int i=1;i<len;++i){
            nid[i]=(nid[i>>1]>>1)|((i&1)?(len>>1):0);
            if(nid[i]<i)swap(ar[i],ar[nid[i]]);
        }
        int wn,w,las1,las2;
        for(int h=2;h<=len;h<<=1){
            if(type)wn=f_pow(G,(mod-1)/h);
            else wn=f_pow(G,mod-1-(mod-1)/h);
            for(int j=0;j<len;j+=h){
                w=1ll;
                for(int k=j;k<j+h/2;++k){
                    las1=ar[k],las2=1ll*ar[k+h/2]*w%mod;
                    ar[k]=las1+las2,ar[k+h/2]=las1-las2+mod;
                    if(ar[k]>=mod)ar[k]-=mod;
                    if(ar[k+h/2]>=mod)ar[k+h/2]-=mod;
                    w=1ll*w*wn%mod;
                }
            }
        }
        if(!type){
            int invn=f_pow(len,mod-2);
            for(int i=0;i<len;i++)ar[i]=1ll*ar[i]*invn%mod;
        }
        return ;
    }
}ff,gg;
void dfs(int x,int f){
    siz[x]=0;
    int sz=G[x].size(),las=0;
    pre[0][0]=suf[0][0]=1;
    for(int i=0,v;i<sz;i++){
        v=G[x][i];
        if(v==f)continue;
        prep[v]=las;
        dfs(v,x);
        for(int j=0;j<=presz[las];j++)nv[j]=pre[las][j];
        for(int j=0;j<=presz[las];j++){
            for(int k=0;k<=siz[v];k++){
                upd(pre[v][j+k],1ll*nv[j]*dp[v][k]%mod);
            }
        }
        presz[v]=presz[las]+siz[v];
        siz[x]+=siz[v];
        las=v;
    }
    las=0;
    for(int i=sz-1,v;i>=0;i--){
        v=G[x][i];
        if(v==f)continue;
        sufp[v]=las;
        for(int j=0;j<=sufsz[las];j++)nv[j]=suf[las][j];
        for(int j=0;j<=sufsz[las];j++){
            for(int k=0;k<=siz[v];k++){
                upd(suf[v][j+k],1ll*nv[j]*dp[v][k]%mod);
            }
        }
        sufsz[v]=sufsz[las]+siz[v];
        las=v;
    }
    siz[x]++;
    for(int i=0;i<=siz[x];i++)nh[i]=ng[i]=0;
    // printf("dfs %d %d\n",x,f);
    for(int i=0,v;i<sz;i++){
        v=G[x][i];
        if(v==f)continue;
        int len=1;while(len<=(presz[prep[v]]+sufsz[sufp[v]]))len<<=1;
        // printf("(%d %d)\n",len,presz[prep[v]]+sufsz[sufp[v]]);
        for(int j=0;j<len;j++)ff.ar[j]=pre[prep[v]][j],gg.ar[j]=suf[sufp[v]][j];
        ff.NTT(len,1);
        gg.NTT(len,1);
        for(int j=0;j<len;j++)ff.ar[j]=1ll*ff.ar[j]*gg.ar[j]%mod;
        ff.NTT(len,0);
        for(int j=0;j<=siz[x];j++)nv[j]=ff.ar[j];
        for(int j=0;j<len;j++)ff.ar[j]=gg.ar[j]=0;
        // for(int j=0;j<=siz[x];j++)nv[j]=0;
        // for(int j=0;j<=presz[prep[v]];j++){
        //     for(int k=0;k<=sufsz[sufp[v]];k++)upd(nv[j+k],1ll*pre[prep[v]][j]*suf[sufp[v]][k]%mod);
        // }//n^3
        // printf("vapo %d\n",nv[0]);
        // for(int j=0;j<=siz[x];j++)printf("%d ",nv[j]);
        // printf("\n");
        for(int j=0;j<=siz[x];j++){
            for(int k=0;j+k<=siz[x]&&k<=siz[v];k++){
                upd(g[x][j+k-1],1ll*nv[j]*k%mod*g[v][k]%mod);
                upd(g[x][j+k-1],1ll*nv[j]*j%mod*g[v][k]%mod);
                upd(g[x][j+k-1],1ll*nv[j]*h[v][k]%mod);
                upd(h[x][j+k-1],1ll*nv[j]*j%mod*h[v][k]%mod);
                if(k>=2)upd(h[x][j+k-1],1ll*nv[j]*(k-2)%mod*h[v][k]%mod);
                upd(ng[j+k],1ll*nv[j]*g[v][k]%mod);
                upd(nh[j+k],1ll*nv[j]*h[v][k]%mod);
                // if(x==3&&j+k==1)printf("add (%d) %d %d %d %d\n",v,j,k,nv[j],h[v][k]);
            }
        }
    }
    for(int i=0;i<=siz[x];i++)nv[i]=suf[las][i];
    for(int i=0;i<=siz[x];i++){
        if(i<siz[x]){
            upd(dp[x][i+1],nv[i]);
            upd(h[x][i+1],(nh[i]+1ll*nv[i]*i%mod)%mod);
            upd(g[x][i+1],ng[i]);
        }
        if(i>0)upd(dp[x][i-1],1ll*i*nv[i]%mod);
    }
    // printf("siz[%d]=%d\n",x,siz[x]);
    // for(int i=0;i<=siz[x];i++)printf("dp[%d][%d] =%d\n",x,i,dp[x][i]);
    // for(int i=0;i<=siz[x];i++)printf("g[%d][%d] =%d\n",x,i,g[x][i]);
    // for(int i=0;i<=siz[x];i++)printf("h[%d][%d] =%d\n",x,i,h[x][i]);
    return ;
}
int main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    n=read();
    for(int i=1,u,v;i<n;i++){
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    dfs(1,0);
    printf("%d %d\n",dp[1][0],g[1][0]);
    return 0;
}