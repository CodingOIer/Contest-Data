#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e6+5,mod=1e9+7;
int n,m,k,u,v,a[maxn],b[maxn],ans,t[maxn<<2],la[maxn<<2];
int fa[maxn],de[maxn],si[maxn],son[maxn],top[maxn],id[maxn],tot;
int he[maxn<<1],ne[maxn<<1],to[maxn<<1],cnt;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int u,int v){
    ne[++cnt]=he[u],to[cnt]=v,he[u]=cnt;
    ne[++cnt]=he[v],to[cnt]=u,he[v]=cnt;
}
void dfs1(int u,int f,int dep){
    fa[u]=f,de[u]=dep,si[u]=1;
    for(int i=he[u];i;i=ne[i]){
        int v=to[i];
        if(v==f)
            continue;
        dfs1(v,u,dep+1);
        si[u]+=si[v];
        if(si[v]>si[son[u]])
            son[u]=v;
    }
}
void dfs2(int u,int topp){
    top[u]=topp,id[u]=++tot;
    if(son[u])
        dfs2(son[u],topp);
    for(int i=he[u];i;i=ne[i]){
        int v=to[i];
        if(top[v])
            continue;
        dfs2(v,v);
    }
}
void pushdown(int k){
    if(la[k]){
        t[k<<1]+=la[k];
        la[k<<1]+=la[k];
        t[k<<1|1]+=la[k];
        la[k<<1|1]+=la[k];
        la[k]=0;
    }
}
void pushup(int k){
    t[k]=max(t[k<<1],t[k<<1|1]);
}
void update(int k,int l,int r,int L,int R,int v){//cout<<L<<"/"<<R<<"/"<<v<<endl;
    if(l>=L&&r<=R){
        t[k]+=v;
        la[k]+=v;
        return;
    }
    pushdown(k);
    int mid=(l+r)>>1;
    if(L<=mid)
        update(k<<1,l,mid,L,R,v);
    if(mid<R)
        update(k<<1|1,mid+1,r,L,R,v);
    pushup(k);
}
void f(int x,int y,int z){
    while(top[x]!=top[y]){
        if(de[top[x]]<de[top[y]])
            swap(x,y);
        update(1,1,n,id[top[x]],id[x],z);
        x=fa[top[x]];
    }
    if(de[x]>de[y])
        swap(x,y);
    update(1,1,n,id[x],id[y],z);
}
void solve(int x,int y){
    if(y>k){
        if(t[1]>=k)
            ++ans;
        return;
    }
    if(x>m)
        return;
    for(int i=x;i+(k-y)<=m;i++){
        f(a[i],b[i],1);
        solve(i+1,y+1);
        f(a[i],b[i],-1);
    }
}
signed main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<n;i++){
        u=read(),v=read();
        add(u,v);
    }
    dfs1(1,0,1);
    dfs2(1,1);
    for(int i=1;i<=m;i++)
        a[i]=read(),b[i]=read();
    if(m<=16){
        solve(1,1);
        printf("%lld\n",ans);
        return 0;
    }
    return 0;
}