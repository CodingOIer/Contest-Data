#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,ans;
pair<int,int> a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++){
        string str;
        cin>>str;
        int xx[2]={0,0};
        for(char c:str){
            if(c=='0')
                ans+=xx[1];
            xx[c^48]++;
        }
        a[i]={xx[0],xx[1]};
    }
    sort(a+1,a+1+n,[](auto x,auto y){return (long long)x.second*y.first<(long long)y.second*x.first;});
    int cnt=0;
    for(int i=1;i<=n;i++){
        ans+=1ll*cnt*a[i].first;
        cnt+=a[i].second;
    }
    printf("%lld\n",ans);
    return 0;
}
