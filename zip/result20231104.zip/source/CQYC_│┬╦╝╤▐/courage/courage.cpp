#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,u,v,f[205][205],vis[205],ans1,ans2,a[205],tot;
int he[4005],ne[4005],to[4005],cnt;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int u,int v){
    ne[++cnt]=he[u],to[cnt]=v,he[u]=cnt;
    ne[++cnt]=he[v],to[cnt]=u,he[v]=cnt;
}
void dfs(int u,int fa){
    for(int i=1;i<=n;i++)
        if(f[fa][i])
            f[u][i]=1;
    for(int i=he[u];i;i=ne[i]){
        int v=to[i];
        if(v==fa)
            continue;
        f[v][u]=1;
        dfs(v,u);
    }
}
void solve(int x){
    if(x>n){
        ++ans1;
        for(int i=1;i<tot;i++)
            for(int j=i+1;j<=tot;j++)
                if((f[a[j]][a[i]]&&f[vis[a[i]]][a[j]]&&f[vis[a[j]]][vis[a[i]]])||(f[a[i]][a[j]]&&f[vis[a[j]]][a[i]]&&f[vis[a[i]]][vis[a[j]]]))
                    ++ans2;
        return;
    }
    if(vis[x])
        solve(x+1);
    else
        for(int i=x+1;i<=n;i++)
            if(!vis[i]&&(f[x][i]||f[i][x])){
                if(f[x][i])
                    a[++tot]=i;
                else
                    a[++tot]=x;
                vis[x]=i,vis[i]=x;
                solve(x+1);
                vis[x]=vis[i]=0;
                --tot;
            }
}
signed main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    n=read();
    int bj=0;
    for(int i=1;i<n;i++){
        u=read(),v=read();
        if(u!=1&&v!=1)
            bj=1;
        add(u,v);
    }
    if(n%2){
        puts("0 0");
        return 0;
    }
    if(!bj){
        if(n==2)
            puts("1 0");
        else
            puts("0 0");
        return 0;
    }
    dfs(1,0);
    solve(1);
    printf("%lld %lld\n",ans1,ans2);
    return 0;
}