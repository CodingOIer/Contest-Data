#include<bits/stdc++.h>
#define int long long
using namespace std;

const int MAXN=2e6+10,MOD=1e9+7;
int n,m,k;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}

struct node
{
    int u,v,nxt;
}e[MAXN<<1];

int head[MAXN],tot;

void add(int u,int v)
{
    e[tot].v=v;
    e[tot].nxt=head[u];
    head[u]=tot++;
}

int depth[MAXN],st[MAXN][30],sum[MAXN],cnt[MAXN];
int fac[MAXN],inv[MAXN];

void dfs(int u,int d,int fa)
{
    st[u][0]=fa;
    depth[u]=d;
    for(int i=head[u];i!=-1;i=e[i].nxt)
    {
        int v=e[i].v;
        if(v==fa)continue;
        dfs(v,d+1,u);
    }
}

inline int qpow(int a,int b)
{
    int res=1,base=a;
    while(b)
    {
        if(b&1)res=res*base%MOD;
        base=base*base%MOD;
        b>>=1;
    }
    return res;
}

void init()
{
    for(int i=1;i<=20;i++)
    {
        for(int j=1;j<=n;j++)
        {
            st[j][i]=st[st[j][i-1]][i-1];
        }
    }
}

inline int LCA(int x,int y)
{
    if(depth[y]>depth[x])
        swap(x,y);
    while(depth[x]!=depth[y])
    {
        int d=depth[x]-depth[y];
        for(int i=0;i<=20;i++)
            if(d>>i&1)
                x=st[x][i];    
    }
    if(x==y)return x;
    for(int i=20;i>=0;i--)
    {
        if(st[x][i]!=st[y][i])
        {
            x=st[x][i];
            y=st[y][i];
        }
    }
    return st[x][0];
}

void pre(int u,int fa)
{
    for(int i=head[u];i!=-1;i=e[i].nxt)
    {
        int v=e[i].v;
        if(v==fa)continue;
        pre(v,u);
        sum[u]+=sum[v];
    }
}

inline int C(int a,int b)
{
    if(b==0||a<b)return 0;
    return fac[a]*inv[b]%MOD*inv[a-b]%MOD;
}
int calc(int x)
{
    int ans=C(sum[x],k);
    ans=((ans-C(sum[x]-cnt[x],k)%MOD)%MOD+MOD)%MOD;
    return ans;
}

signed main() 
{
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    fac[0]=1;
    inv[0]=1;
    for(int i=1;i<MAXN;i++)
    {
        fac[i]=fac[i-1]*i%MOD;
        inv[i]=qpow(fac[i],MOD-2);
    }
    memset(head,-1,sizeof(head));
    tot=0;
    n=read(),m=read(),k=read();
    for(int i=1;i<n;i++)
    {
        int u,v;
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    dfs(1,0,0);
    init();
    for(int i=1;i<=m;i++)
    {
        int u,v;
        u=read(),v=read();
        int x=LCA(u,v);
        sum[u]++,sum[v]++;
        sum[x]--,sum[st[x][0]]--;
        cnt[x]++;
    }
    pre(1,0);
    int ans=0;
    for(int i=1;i<=n;i++)
        ans=(ans+calc(i))%MOD;
    printf("%lld\n",ans);
    return 0 ;
}