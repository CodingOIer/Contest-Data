#include<bits/stdc++.h>
#define int long long 
using namespace std;

const int MAXN=2e5+10;
const int INF=1e18;
int n,ans;
string str;

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

struct node
{
    string s;
    int strl,cnt;
    bool operator <(const node &b)
	{
        return cnt*(b.strl-b.cnt)>b.cnt*(strl-cnt);
    }
}a[MAXN];

signed main()
{
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
	{
        std::cin>>a[i].s;
        a[i].strl=a[i].s.size();
        for(int j=0;j<a[i].strl;j++) 
        {
        	if(a[i].s[j]=='0')
        	{
        		a[i].cnt++;
			}
		}
    }
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++)
    {
    	str+=a[i].s;
	}
    int strl=str.size();
    str=' '+str;
    for(int i=1,cnt=0;i<=strl;i++)
	{
        if(str[i]=='1')
		{
			cnt++;
		}
        else
        {
        	ans+=cnt;
		}
    }
    printf("%lld\n",ans);
    return 0;
}
