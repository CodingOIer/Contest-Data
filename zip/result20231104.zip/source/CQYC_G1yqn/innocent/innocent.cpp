#include<bits/stdc++.h>
using namespace std;
signed main()
{
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	return 0;
}
