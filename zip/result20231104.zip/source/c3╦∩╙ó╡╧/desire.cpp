#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define pii pair <int, int>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 2e6 + 5, M = 2e6 + 5;

namespace G {

array <int, N> fir;
array <int, M> nex, to;
int cnt;
void add(int x, int y) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;
}

}

namespace HPT {

using G::fir; using G::nex; using G::to;
array <int, N> siz, son, dep, fa;
void dfs1(int x) {
	siz[x] = 1;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x]) continue;
		fa[to[i]] = x;
		dep[to[i]] = dep[x] + 1;
		dfs1(to[i]);
		siz[x] += siz[to[i]];
		if (siz[to[i]] > siz[son[x]]) son[x] = to[i];
	}
}
array <int, N> dfn, top, idx;
int cnt;
void dfs2(int x, int Mgn) {
	cnt++;
	dfn[x] = cnt;
	idx[cnt] = x;
	top[x] = Mgn;
	if (son[x]) dfs2(son[x], Mgn);
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x] || to[i] == son[x]) continue;
		dfs2(to[i], to[i]);
	}
}
int lca(int x, int y) {
	while (top[x] != top[y]) {
		if (dfn[top[x]] < dfn[top[y]]) swap(x, y);
		x = fa[top[x]];
	}
	if (dep[x] > dep[y]) swap(x, y);
	return x;
}

}
array <int, 40> dis;
bool check(int x, int k) {
	using G::fir; using G::nex; using G::to; using HPT::fa;
	/* write(x), putchar(32); */
	/* write(dis[x]), puts(""); */
	int ans = dis[x] >= k;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x]) continue;
		ans |= check(to[i], k);
	}
	return ans;
}
#define fi first
#define se second
array <pii, N> isl;
int main() {
	freopen("desire.in", "r", stdin);
	freopen("desire.out", "w", stdout);
	int n = read(), m = read(), k = read();
	for (int i = 2; i <= n; i++) {
		int x = read(), y = read();
		G::add(x, y), G::add(y, x);
	}
	HPT::dfs1(1), HPT::dfs2(1, 1);
	for (int i = 1; i <= m; i++)
		isl[i].fi = read(), isl[i].se = read();
	int ans = 0;
	for (int T = 0; T < 1 << m; T++) {
		int id = 0;
		for (int i = 1; i <= m; i++) {
			if (T & (1 << (i - 1)))
				id++;
		}
		if (id != k) continue;
		dis.fill(0);
		for (int i = 1; i <= m; i++) {
			if (!(T & (1 << (i - 1)))) continue;
			/* write(isl[i].fi), puts(""); */
			int lcA = HPT::lca(isl[i].fi, isl[i].se);
			/* write(lcA), puts(""); */
			/* return 0; */
			while (isl[i].fi != lcA) dis[isl[i].fi]++, isl[i].fi = HPT::fa[isl[i].fi];
			while (isl[i].se != lcA) dis[isl[i].se]++, isl[i].se = HPT::fa[isl[i].se];
			dis[lcA]++;
			if (check(1, k)) ans++;
		}
	}
	write(ans), puts("");
	return 0;
}
