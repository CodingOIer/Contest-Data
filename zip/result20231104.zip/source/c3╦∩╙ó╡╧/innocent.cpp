#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <bitset>
#include <queue>
#define int long long
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 5e3 + 5, M = 1e5 + 5, inf = 1e9;
namespace G {

array <int, N> fir;
array <int, M> nex, to, len;
int cnt;
void add(int x, int y, int z) {
	/* write(x), putchar(32); */
	/* write(y), putchar(32); */
	/* write(z), puts("@"); */
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	len[cnt] = z;
	fir[x] = cnt;
}

}

namespace SPFA {

array <int, N> dis, mark;
bitset <N> vis;
void init(int n) {
	for (int i = 1; i <= 2 * n; i++) {
		dis[i] = inf;
		vis[i] = 0;
		mark[i] = 0;
	}
}

using G::fir; using G::nex; using G::to; using G::len;
queue <int> q;
void main(int x, int n) {
	q.push(x);
	dis[x] = 0;
	vis[x] = 1;
	while (!q.empty()) {
		int u = q.front();
		q.pop();
		vis[u] = 0;
		if (mark[u] > 2 * n) {
			dis[u] = -inf;
			continue;
		}
		for (int i = fir[u]; i; i = nex[i]) {
			G::cnt++;
			if (dis[to[i]] <= dis[u] + len[i]) continue;
			mark[to[i]]++;
			dis[to[i]] = dis[u] + len[i];
			q.push(to[i]);
			/* if (!vis[to[i]]) q.push(to[i]), vis[to[i]] = 1; */
		}
	}
}

}

signed main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.out", "w", stdout);
	int n = read(), m = read();
	for (int i = 1; i <= m; i++) {
		int x = read() + 1, y = read() + 1, z = read();
		if (z % 2 == 0) {
			G::add(x, y, z);
			G::add(x + n, y + n, z);
		}
		else {
			G::add(x, y + n, z);
			G::add(x + n, y, z);
		}
	}
	/* write(G::cnt), puts(""); */
	for (int i = 1; i <= n; i++) {
		SPFA::init(n); SPFA::main(i, n);
		if (SPFA::dis[i + n] == -inf) puts("Twinkle");
		else if (SPFA::dis[i + n] == inf) puts("a-w-r-y");
		else write(SPFA::dis[i + n]), puts("");
	}
	return 0;
}
