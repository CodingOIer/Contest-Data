#include<bits/stdc++.h>
using namespace std;
string f;
struct node{
	long long c0,c1;
}a[200200];
long long cnt=0,n;
long long ans=0,sum[200200];
bool cmp(node a,node b)
{
	return a.c0*b.c1>a.c1*b.c0;
}
int main()
{
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>f;cnt=0;
		for(int j=0;j<f.size();j++)
		{
			if(f[j]=='1') cnt++,a[i].c0++;
			else ans+=cnt,a[i].c1++;
		}
	}
	sort(a+1,a+n+1,cmp);
	for(int i=n;i>=1;i--) sum[i]=sum[i+1]+a[i].c0;
	for(int i=1;i<=n;i++) ans+=a[i].c1*sum[i+1];
	cout<<ans;
	return 0;
}
