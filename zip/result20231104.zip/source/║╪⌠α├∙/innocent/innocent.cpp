#include<bits/stdc++.h>
using namespace std;
long long n,m,a,b,c;
long long cnt=0,dp[2010][2010];
bool vis[100100];
int main()
{
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	memset(dp,0x3f,sizeof dp);
	for(int i=1;i<=2*n;i++) dp[i][i]=0;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b>>c;
		a++,b++;
		if((c%2+2)%2==1) dp[a][n+b]=dp[n+a][b]=c;
		else dp[a][b]=dp[n+a][n+b]=c;
	}
	n*=2;
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++) dp[i][j]=min(dp[i][j],dp[i][k]+dp[k][j]);
	for(int i=1;i<=n/2;i++)
	{
		if(dp[i][n/2+i]>=1e14) cout<<"a-w-r-y\n";
		else if(dp[i][n/2+i]>0) cout<<dp[i][n/2+i]<<"\n";
		else cout<<"Twinkle\n";
	}
	return 0;
}
