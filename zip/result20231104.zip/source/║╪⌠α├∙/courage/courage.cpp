#include<bits/stdc++.h>
using namespace std;
int n,u,v;
int main()
{
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<n;i++) cin>>u>>v;
	if(n<=2) cout<<1<<" "<<n;
	else cout<<0<<" "<<0;
	return 0;
}
