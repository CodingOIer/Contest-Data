#include<bits/stdc++.h>
using namespace std;
int n,m,k,a,b,dep[2002000],f[2002000][24],u[2002000],v[2002000],lc[2002000];
long long inv[2002000],jie[2002000],ans=0;
int e[4002000],h[4002000],ne[4002000],cnt=0,vis[2002000],fa[2002000];
map<int,int> mp[200200];
const int mod=1e9+7;
long long quick(int x,int y)
{
	long long ans=1,sum=x;
	while(y)
	{
		int t=(y&1);
		if(t) ans=(ans*sum)%mod;
		sum=(sum*sum)%mod,y/=2;
	}
	return ans;
}
void init(int n)
{
	jie[0]=inv[0]=1;
	for(int i=1;i<=n;i++) jie[i]=(jie[i-1]*i)%mod;
	inv[n]=quick(jie[n],mod-2);
	for(int i=n-1;i>0;i--) inv[i]=inv[i+1]*(i+1)%mod;
	return ;
}
long long C(long long x,long long y){return jie[y]*inv[y-x]%mod*inv[x]%mod;}
void add(int a,int b)
{
	e[cnt]=b,ne[cnt]=h[a],h[a]=cnt++;
	return ;
}
void dfs(int u,int fa)
{
	dep[u]=dep[fa]+1;
	for(int i=1;(1<<i)<=dep[u];i++) f[u][i]=f[f[u][i-1]][i-1];
	for(int i=h[u];i!=-1;i=ne[i])
	{
		int to=e[i];
		if(to==fa) continue;
		f[to][0]=u,dfs(to,u);
	}
	return ;
}
int lca(int a,int b)
{
	if(dep[a]<dep[b]) swap(a,b);
	for(int i=22;i>=0;i--)
	{
		if(dep[f[a][i]]>=dep[b]) a=f[a][i];
		if(a==b) return a;
	}
	for(int i=22;i>=0;i--) if(f[a][i]!=f[b][i]) a=f[a][i],b=f[b][i];
	return f[a][0];
}
int vv[1001000],len=0;
void cheak(int x)
{
	long long temp=1;
	len=0;
	for(int i=0;(1<<i)<=x;i++)
		if((x&(1<<i))) temp=(temp*mp[u[i+1]][v[i+1]])%mod,vv[++len]=i+1;
	if(len!=k) return ;
	for(int i=1;i<=n;i++)
	{
		int tf=1;
		for(int j=1;j<=len;j++)
		{
			int xx=lca(u[vv[j]],i),yy=lca(v[vv[j]],i);
			if(xx==i&&yy==lc[vv[j]]||yy==i&&xx==lc[vv[j]]) tf=1;
			else {tf=0;break;}
		}
		if(tf==1) {ans=(ans+temp)%mod;return ;}
	}
	return ;
}
int main()
{
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	cin>>n>>m>>k;
	init(m+10);
	memset(h,-1,sizeof h);
	for(int i=1;i<n;i++) cin>>a>>b,add(a,b),add(b,a);
	dfs(1,0);
	for(int i=1;i<=m;i++)
	{
		cin>>u[i]>>v[i];
		if(mp[u[i]][v[i]]||mp[v[i]][u[i]]) {mp[u[i]][v[i]]++,mp[v[i]][u[i]]++,i--,m--;continue;}
		mp[u[i]][v[i]]=mp[u[i]][v[i]]=1;
		lc[i]=lca(u[i],v[i]);
	}
	for(int i=1;i<=m;i++)
		if(mp[u[i]][v[i]]>=k) ans+=C(k,mp[u[i]][v[i]]),ans%=mod;
	for(long long i=0;i<(1<<m);i++) cheak(i);
	cout<<ans;
	return 0;
}
