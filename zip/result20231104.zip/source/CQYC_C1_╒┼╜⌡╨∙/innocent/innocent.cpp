#include <bits/stdc++.h>
using namespace std;

int n, m, x, y, l;
struct Edge {
	int to, l;
};
vector<Edge> rdges[10001];
long long f[30005][101][2];

long long s(long long a) {
	if (a % 2 == 1 || a % 2 == -1) return 1;
	else return 0;
}

void solve(int st) {
	for (int i = 0; i <= 3 * m; ++i) {
		for (int j = 0; j < n; ++j) {
			f[i][j][0] = f[i][j][1] = 1ll << 62;
		}
	} 
	f[0][st][0] = 0;
	for (int d = 1; d <= 3 * m; ++d) {
		bool update = 0;
		for (int i = 0; i < n; ++i) {
			for (auto j : rdges[i]) {
				long long odd = s(f[d - 1][j.to][0] + j.l);
				if (f[d - 1][j.to][0] == 1ll << 62);
				else f[d][i][odd] = min(f[d][i][odd], f[d - 1][j.to][0] + j.l);
				//printf("(%lld,%lld,%lld): %lld, (%lld,%lld,%lld): %lld\n", d, i, odd,f[d][i][odd],d-1,j.to,0ll,f[d-1][j.to][0],j.l);
				odd = s(f[d - 1][j.to][1] + j.l);
				if (f[d - 1][j.to][1] == 1ll << 62);
				else f[d][i][odd] = min(f[d][i][odd], f[d - 1][j.to][1] + j.l);
				//printf("(%lld,%lld,%lld): %lld, (%lld,%lld,%lld): %lld, %d\n", d, i, odd,f[d][i][odd],d-1,j.to,1ll,f[d-1][j.to][1], j.l);
			}
		}
	}
	long long ans = 1ll << 62;
	for (int d = 1; d <= 3 * m; ++d){
		if (f[d][st][1] < ans && d >= m + 1) {
			puts("Twinkle");
			return;
		}
		ans = min(ans, f[d][st][1]);
	}
	if (ans == 1ll << 62) puts("a-w-r-y");
	else printf("%lld\n", ans);
}

int main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d%d", &x, &y, &l);
		rdges[y].push_back({x, l});
	}
	for (int i = 0; i < n; ++i) {
		solve(i);
	}
	return 0;
}
/*
Accepted on (#1, #2, #3)
Wrong Answer on (#1, #2, #3)
TLE on #4
0 (50%)
60 (50%)

���� 30 �� 
*/

