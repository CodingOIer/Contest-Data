#include <bits/stdc++.h>
using namespace std;

int n, m, x, y, ans, ans2, d[21], f[11][21], c[21];
vector<int> l[21], edges[21];

void dfs(int i) {
	for (auto j : edges[i]) {
		if (!d[j]) {
			d[j] = d[i] + 1;
			f[0][j] = i;
			dfs(j);
		}
	}
}

bool lca(int x, int y) {
	if (d[x] < d[y]) swap(x, y);
	int step = d[x] - d[y]; 
	for (int l = 0; step; step >>= 1, ++l) {
		if (step & 1) x = f[l][x];
	}
	if (x == y) return 1;
	return 0;
}

bool used[21];
int pai[21][2], tot;

bool vaild(int x, int y, int a, int b) {
	if (d[x] > d[y]) swap(x, y);
	if (d[a] > d[b]) swap(a, b);
	if (lca(x, y) && lca(x, a) && lca(x, b) && lca(y, a) && lca(y, b) && lca(a, b)) return 1;
	return 0;
}

void solve(int i) {
	if (i == n + 1) {
		++ans;
		for (int j = 1; j <= tot; ++j) {
			for (int k = j + 1; k <= tot; ++k) {
				if (vaild(pai[j][0], pai[j][1], pai[k][0], pai[k][1])) {
					++ans2;
				}
			}
		}
		return;
	}
	if (used[i]) {
		solve(i + 1);
		return;
	}
	for (int b = i + 1; b <= n; ++b) {
		if (!used[b]) {
			if (lca(i, b)) {
				used[i] = 1;
				used[b] = 1;
				pai[++tot][0] = i;
				pai[tot][1] = b;
				solve(i + 1);
				used[i] = 0;
				used[b] = 0;
				--tot;
			} 
		}	
	}
}

int main() {
	freopen("courage.in", "r", stdin);
	freopen("courage.out","w",stdout);
	scanf("%d", &n);
	if (n > 10 || n % 2 == 1) {
		printf("0 0\n");
		return 0;
	}
	for (int i = 1; i < n; ++i) {
		scanf("%d%d", &x, &y);
		edges[x].push_back(y);
		edges[y].push_back(x);
	}
	d[1] = 1; dfs(1);
	for (int j = 1; j <= 10; ++j) {
		for (int i = 1; i <= n; ++i) {
			f[j][i] = f[j - 1][f[j - 1][i]];
		}
	}
	solve(1);
	printf("%d %d\n", ans, ans2 / 3);
	return 0;
}
/*
Accepted on (#1~4), #9
PA on (#1~4)
WA on (#1~4)
Runtime Error on #5~8, #10~20
5pts (30%)
13pts (40%)
25pts (30%)
���� 14 ��
*/
