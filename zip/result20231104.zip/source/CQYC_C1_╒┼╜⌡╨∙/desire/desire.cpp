#include <bits/stdc++.h>
using namespace std;

int n, m, k, x, y, ans, d[21], f[11][21], c[21];
vector<int> l[21], edges[21];

void dfs(int i) {
	for (auto j : edges[i]) {
		if (!d[j]) {
			d[j] = d[i] + 1;
			f[0][j] = i;
			dfs(j);
		}
	}
}

int lca(int x, int y) {
	if (d[x] < d[y]) swap(x, y);
	int step = d[x] - d[y]; 
	for (int l = 0; step; step >>= 1, ++l) {
		if (step & 1) x = f[l][x];
	}
	if (x == y) return x;
	for (int l = 10; ~l; --l) {
		if (f[l][x] != f[l][y] && f[l][x] != 0 && f[l][y] != 0) {
			x = f[l][x];
			y = f[l][y];
		}
	}
	return f[0][x];
}

void solve(int i, int sel) {
	if (sel == k) {
		for (int j = 1; j <= n; ++j) {
			if (c[j] == k) {
				++ans;
				return;
			}
		}
		return;
	}
	if (i == n + 1) return;
	solve(i + 1, sel);
	for (auto j : l[i]) ++c[j];
	solve(i + 1, sel + 1);
	for (auto j : l[i]) --c[j];
}
int main() {
	freopen("desire.in", "r", stdin);
	freopen("desire.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	if (n <= 20 && m <= 16 && k <= 16) {
		for (int i = 1; i < n; ++i) {
			scanf("%d%d", &x, &y);
			edges[x].push_back(y);
			edges[y].push_back(x);
		}
		d[1] = 1; dfs(1);
		for (int j = 1; j <= 10; ++j) {
			for (int i = 1; i <= n; ++i) {
				f[j][i] = f[j - 1][f[j - 1][i]];
			}
		}
		for (int i = 1; i <= m; ++i) {
			scanf("%d%d", &x, &y);
			int lc = lca(x, y);
			while (y != lc) {
				l[i].push_back(y);
				y = f[0][y];
			}
			while (x != lc) {
				l[i].push_back(x);
				x = f[0][x];
			}
			l[i].push_back(lc);
		}
		solve(1, 0);
		printf("%d\n", ans);
	} else {
		puts("0");
	}
}
/*
10(60%)
5(30%)
0(10%)
���� 7 �� 
*/

