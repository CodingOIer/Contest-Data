#include<bits/stdc++.h>
using namespace std;
const int mod = 998244353;
vector<int> v[2011];
long long f[2011][2011];
long long g[2011];
int siz[2011];
void DFS(int fa,int p)
{
	f[p][0] = 1;
	for(auto i:v[p]) if(i != fa)
	{
		DFS(p,i);
		memset(g,0,sizeof(g));
		for(int x = 0;x <= siz[p];x++)
			for(int y = 0;y <= siz[i];y++)
				(g[x + y] += f[p][x] * f[i][y]) %= mod;
		memcpy(f[p],g,sizeof(g));
		siz[p] += siz[i];
	}
	for(int i = (siz[p] & 1);i <= siz[p];i += 2)
	{
		(f[p][i - 1] += f[p][i] * i) %= mod;
		f[p][i + 1] += f[p][i];
		if(f[p][i + 1] >= mod) f[p][i + 1] -= mod;
		f[p][i] = 0;
	}
	siz[p]++;
}
int n;
int x,y;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	cin >> n;
	for(int i = 1;i < n;i++)
	{
		cin >> x >> y;
		v[x].push_back(y),v[y].push_back(x);
	}
	DFS(1,1);
	cout << f[1][0];
	return 0;
}