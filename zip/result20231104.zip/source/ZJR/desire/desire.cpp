#include<bits/stdc++.h>
using namespace std;
struct ios{
    inline char gc(){
        static const int IN_LEN=1<<18|1;
        static char buf[IN_LEN],*s,*t;
        return (s==t)&&(t=(s=buf)+fread(buf,1,IN_LEN,stdin)),s==t?-1:*s++;
    }
    template <typename _Tp> inline ios & operator >> (_Tp&x){
        static char ch,sgn; ch = gc(), sgn = 0;
        for(;!isdigit(ch);ch=gc()){if(ch==-1)return *this;sgn|=ch=='-';}
        for(x=0;isdigit(ch);ch=gc())x=x*10+(ch^'0');
        sgn&&(x=-x); return *this;
    }
}io;
#define cin io
const int mod = 1000000007;
long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1) (res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}
long long fac[2000011],exfac[2000011];
long long C(int n,int m)
{
	if(n < m) return 0;
	return fac[n] * exfac[m] % mod * exfac[n - m] % mod;
}
int nw[2000011],cnt[2000011],cut[2000011];
int deep[2000011],fa[25][2000011];
vector<int> v[2000011];
long long ans;
void Init(int f,int p)
{
	deep[p] = deep[fa[0][p] = f] + 1;
	for(auto i:v[p]) if(i != f) Init(p,i);
}
int lca(int x,int y)
{
	if(deep[x] < deep[y]) swap(x,y);
	int b = deep[x] - deep[y];
	for(int k = 0;k < 25;k++)
		if(b & (1 << k)) x = fa[k][x];
	if(x == y) return x;
	for(int k = 24;k >= 0;k--) if(fa[k][x] != fa[k][y])
		x = fa[k][x],y = fa[k][y];
	return fa[0][x];
}
void DFS(int p)
{
    for(auto i:v[p]) if(i != fa[0][p])
    {
        DFS(i);
        cnt[p] += cnt[i];
    }
    cnt[p] -= cut[p];
}
int n,m,k;
int x,y;
int main()
{
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	cin >> n >> m >> k;
	fac[0] = 1;
	for(int i = 1;i <= m;i++) fac[i] = fac[i - 1] * i % mod;
	exfac[m] = qmi(fac[m],mod - 2);
	for(int i = m;i;i--) exfac[i - 1] = exfac[i] * i % mod;
	for(int i = 1;i < n;i++)
	{
		cin >> x >> y;
		v[x].push_back(y),v[y].push_back(x);
	}
	Init(0,1);
	for(int K = 1;K < 25;K++)
		for(int i = 1;i <= n;i++)
			fa[K][i] = fa[K - 1][fa[K - 1][i]];
	for(int i = 1;i <= m;i++)
	{
		cin >> x >> y;
        int LCA = lca(x,y);
        nw[LCA]++;
        if(deep[x] > deep[y]) swap(x,y);
        cnt[y]++,cut[fa[0][LCA]]++;
        if(x != LCA) cnt[x]++,cut[LCA]++;
	}
    DFS(1);
    for(int i = 1;i <= n;i++)
        (ans += C(cnt[i],k) + mod - C(cnt[i] - nw[i],k)) %= mod;
    printf("%lld",ans);
	return 0;
}