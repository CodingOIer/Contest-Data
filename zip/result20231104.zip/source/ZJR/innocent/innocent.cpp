#include<bits/stdc++.h>
using namespace std;
long long mn[2011];
int deep[2011];
vector<pair<int,int> > v[2011];
vector<int> l[2011];
inline void add(int x,int y,int w)
{
    v[x].push_back({y,w}),l[y].push_back(x);
}
bool b[2011];
int n,m;
inline void Clac(int p)
{
    queue<int> q;
    memset(b,0,sizeof(b));
    q.push(p);
    while(!q.empty())
    {
        p = q.front();
        q.pop();
        b[p] = 1;
        for(auto i:l[p]) if(!b[i])
            q.push(i);
    }
}
inline void SPFA(int S,int T)
{
    mn[S] = 0;
    queue<int> q;
    q.push(S);
    while(!q.empty())
    {
        int p = q.front();
        q.pop();
        if(deep[p] > 2 * n)
        {
            cout << "Twinkle\n";
            return;
        }
        for(auto i:v[p]) if(b[i.first])
        {
            if(mn[i.first] > mn[p] + i.second)
            {
                mn[i.first] = mn[p] + i.second;
                deep[i.first] = deep[p] + 1;
                q.push(i.first);
            }
        }
    }
    cout << mn[T] << "\n";
}
inline void Solve(int p)
{
    memset(mn,0x3f,sizeof(mn));
    memset(deep,0,sizeof(deep));
    Clac(p + n);
    if(!b[p])
    {
        cout << "a-w-r-y\n";
        return;
    }
    SPFA(p,p + n);
}
int x,y,w;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    cin >> n >> m;
    for(int i = 1;i <= m;i++)
    {
        cin >> x >> y >> w;
        x++,y++;
        if(w & 1) add(x,y + n,w),add(x + n,y,w);
        else add(x,y,w),add(x + n,y + n,w);
    }
    for(int i = 1;i <= n;i++) Solve(i);
    return 0;
}