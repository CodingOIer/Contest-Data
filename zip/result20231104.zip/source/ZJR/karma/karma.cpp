#include<bits/stdc++.h>
#define lowbit(x) ((x)&-(x))
using namespace std;
char c[200011];
int a,b;
pair<int,int> p[200011];
bool cmp(pair<int,int> A,pair<int,int> B)
{
	return (long long)A.second * B.first < (long long)B.second * A.first;
}
int n;
long long ans;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	cin >> n;
	for(int tms = 1;tms <= n;tms++)
	{
		cin >> (c + 1);
		a = b = 0;
		for(int i = 1;c[i];i++)
		{
			if(c[i] == '0') ans += b,a++;
			else b++;
		}
		p[tms] = {a,b};
	}
	sort(p + 1,p + n + 1,cmp);
	a = b = 0;
	for(int i = 1;i <= n;i++)
	{
		ans += (long long)p[i].first * b;
		a += p[i].first,b += p[i].second;
	}
	cout << ans;
	return 0;
}