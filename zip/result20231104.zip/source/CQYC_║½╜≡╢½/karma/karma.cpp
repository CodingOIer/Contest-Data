#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pii pair<int,int>
#define fi first
#define se second
#define pk push_back
#define N 1010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
int f__[40];
il void write(int x){
    int cnt=0;
    if(!x) putchar('0');
    if(x<0){
        x=-x;putchar('-');
    }
    while(x){
        f__[cnt++]=x%10+'0';x/=10;
    }
    while(cnt) putchar(f__[--cnt]);
}
int n,ans;
pii a[N];
char S[N];
il bool cmp(pii u,pii v){
    return u.se*v.fi<u.fi*v.se;
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i){
        scanf(" %s",S+1);
        int sz=strlen(S+1),cnt1=0;
        for(int j=1;j<=sz;++j){
            if(S[j]=='1') ++cnt1;
            else ans+=cnt1;
        }
        a[i]=pii(sz-cnt1,cnt1);
    }
    sort(a+1,a+1+n,cmp);
    int cnt1=0;
    for(int i=1;i<=n;++i){
        ans+=a[i].fi*cnt1;
        cnt1+=a[i].se;
    }
    write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
    return 0;
}
