#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pii pair<int,int>
#define fi first
#define se second
#define pk push_back
#define N 2000010
#define inf (int)(1000000000000000000)
#define mod 1000000007
using namespace std;
bool ppp;
il int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
int f__[40];
il void write(int x){
    int cnt=0;
    if(!x) putchar('0');
    if(x<0){
        x=-x;putchar('-');
    }
    while(x){
        f__[cnt++]=x%10+'0';x/=10;
    }
    while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int head[N],nxt[N<<1],to[N<<1],t;
il void add(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;
    nxt[++t]=head[v];head[v]=t;to[t]=u;
}
int n,m,K,f[N][22],dep[N],sum1[N],sum2[N],fac[N],inv[N],ans;
il int C(int a,int b){
    if(a<0||b<0||a<b) return 0;
    return fac[a]*inv[b]%mod*inv[a-b]%mod;
}
il void dfs1(int x,int fa){
    f[x][0]=fa;dep[x]=dep[fa]+1;
    for(int i=1;i<21;++i) f[x][i]=f[f[x][i-1]][i-1];
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa) dfs1(to[i],x);
}
il int LCA(int a,int b){
    if(dep[a]<dep[b]) swap(a,b);
    for(int i=20;i>=0;--i) if(dep[f[a][i]]>=dep[b]) a=f[a][i];
    if(a==b) return a;
    for(int i=20;i>=0;--i) if(f[a][i]!=f[b][i]){
        a=f[a][i];b=f[b][i];
    }
    return f[a][0];
}
il void dfs2(int x,int fa){
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa){
        dfs2(to[i],x);
        sum1[x]+=sum1[to[i]];sum2[x]+=sum2[to[i]];
    }
    Add(ans,C(sum1[x],K));Del(ans,C(sum2[x],K));
}
il void init(){
    fac[0]=1;
    for(int i=1;i<N;++i) fac[i]=fac[i-1]*i%mod;
    inv[N-1]=Pow(fac[N-1],mod-2);
    for(int i=N-1;i;--i) inv[i-1]=inv[i]*i%mod;
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    init();n=read();m=read();K=read();
    for(int i=1;i<n;++i) add(read(),read());
    dfs1(1,0);
    while(m--){
        int u=read(),v=read(),lca=LCA(u,v);
        ++sum1[u];++sum1[v];--sum1[lca];--sum1[f[lca][0]];
        ++sum2[u];++sum2[v];sum2[lca]-=2;
    }
    dfs2(1,0);
    write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
    return 0;
}
