#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pii pair<int,int>
#define fi first
#define se second
#define pk push_back
#define N 1010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
int f__[40];
il void write(int x){
    int cnt=0;
    if(!x) putchar('0');
    if(x<0){
        x=-x;putchar('-');
    }
    while(x){
        f__[cnt++]=x%10+'0';x/=10;
    }
    while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N],to[N],w[N],t;
il void add(int u,int v,int d){
    nxt[++t]=head[u];head[u]=t;to[t]=v;w[t]=d;
}
int n,m,dis[N][N][2],cnt[N][2];
queue<pii> Q;
bool vis[N][2];
il void SPFA(int S){
    for(int i=1;i<=n;++i) for(int j=0;j<2;++j) vis[i][j]=cnt[i][j]=0;
    dis[S][S][0]=0;Q.push(pii(S,0));vis[S][0]=1;
    while(!Q.empty()){
        pii x=Q.front();Q.pop();
        vis[x.fi][x.se]=0;
        // if(S==4&&x.fi==14) cerr<<"ERROR";
        // if((S==7||S==14||S==4||S==3)) cerr<<S<<" "<<x.fi<<" "<<x.se<<" "<<dis[S][x.fi][x.se]<<"\n";
        ++cnt[x.fi][x.se];
        if(cnt[x.fi][x.se]>n){
            dis[S][x.fi][x.se]=-inf;vis[x.fi][x.se]=1;
        }
        for(int i=head[x.fi];i;i=nxt[i]){
            // if(S==4&&x.fi==4) cerr<<cnt[to[i]][(x.se+w[i])&1]<<"\n";
            if(dis[S][to[i]][(x.se+w[i])&1]>dis[S][x.fi][x.se]+w[i]&&cnt[to[i]][(x.se+w[i])&1]<=n){
                dis[S][to[i]][(x.se+w[i])&1]=dis[S][x.fi][x.se]+w[i];
                if(!vis[to[i]][(x.se+w[i])&1]) Q.push(pii(to[i],(dis[S][x.fi][x.se]+w[i])&1));
            }
        }
    }
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    n=read();m=read();
    while(m--){
        int u=read()+1,v=read()+1,d=read();
        add(u,v,d);
    }
    memset(dis,0x3f,sizeof(dis));
    // write(dis[0][0][0]);putchar('\n');
    for(int i=1;i<=n;++i) SPFA(i);
    // cerr<<dis[2][1][0]<<" ";
    for(int i=1;i<=n;++i){
        int ans=inf;
        for(int j=head[i];j;j=nxt[j]){
            ans=min(ans,dis[to[j]][i][(w[j]&1)^1]+w[j]);
            // if(i==1) cerr<<(w[j]&1)<<" "<<to[j]<<" "<<dis[to[j]][i][0]<<" "<<dis[to[j]][i][1]<<"\n";
        }
        if(ans==inf) puts("a-w-r-y");
        else if(ans<0) puts("Twinkle");
        else{
            write(ans);putchar('\n');
        }
    }
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
    return 0;
}
