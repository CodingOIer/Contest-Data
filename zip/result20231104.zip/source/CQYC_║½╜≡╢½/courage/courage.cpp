#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pii pair<int,int>
#define fi first
#define se second
#define pk push_back
#define N 2010
#define inf (int)(1000000000000000000)
#define mod 998244353
using namespace std;
bool ppp;
il int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
int f__[40];
il void write(int x){
    int cnt=0;
    if(!x) putchar('0');
    if(x<0){
        x=-x;putchar('-');
    }
    while(x){
        f__[cnt++]=x%10+'0';x/=10;
    }
    while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
vector<int> e[N];
il void add(int u,int v){
    e[u].pk(v);e[v].pk(u);
}
int n,dp[N][N][5],sz[N],f[N],g[N][5],ff[N],pre[N][N],suf[N][N];
il bool cmp(int u,int v){
    return sz[u]>sz[v];
}
il void dfs1(int x,int fa){
    for(vector<int>::iterator it=e[x].begin();it!=e[x].end();++it){
        if(*it==fa){
            e[x].erase(it);break;
        }
    }
    sz[x]=1;
    for(auto v:e[x]){
        dfs1(v,x);sz[x]+=sz[v];
    }
    sort(e[x].begin(),e[x].end(),cmp);
}
il void dfs2(int x){
    // cerr<<x<<" "<<sz[x]<<"\n";
    if(e[x].empty()){
        dp[x][1][0]=dp[x][0][1]=1;
        return;
    }
    for(auto v:e[x]) dfs2(v);
    for(int i=0;i<=sz[x];++i) f[i]=0;
    f[0]=1;
    for(auto v:e[x]){
        for(int j=0;j<=sz[x];++j) pre[v][j]=f[j];
        if(v!=e[x].back()){
            for(int j=0;j<=sz[v];++j) for(int k=0;k+j<=sz[x];++k)
                Add(ff[j+k],f[k]*dp[v][j][0]%mod);
            for(int j=0;j<=sz[x];++j){
                f[j]=ff[j];ff[j]=0;
            }
        }
    }
    for(int i=0;i<=sz[x];++i) f[i]=0;
    f[0]=1;
    reverse(e[x].begin(),e[x].end());
    for(auto v:e[x]){
        for(int j=0;j<=sz[x];++j) suf[v][j]=f[j];
        // if(v!=e[x].back()){
            for(int j=0;j<=sz[v];++j) for(int k=0;k+j<=sz[x];++k)
                Add(ff[j+k],f[k]*dp[v][j][0]%mod);
            for(int j=0;j<=sz[x];++j){
                f[j]=ff[j];ff[j]=0;
            }
        // }
    }
    for(int i=0;i<=sz[x];++i) g[i][0]=f[i];
    for(auto v:e[x]){
        for(int j=0;j<=sz[x];++j) if(pre[v][j]) for(int k=0;k+j<=sz[x];++k)
            Add(ff[j+k],pre[v][j]*suf[v][k]%mod);
        for(int j=0;j<=sz[x];++j) if(ff[j])
            for(int k=0;k<=sz[v]&&j+k<=sz[x];++k)
                for(int d=1;d<5;++d) Add(dp[x][j+k][d],ff[j]*dp[v][k][d]%mod);
        for(int j=0;j<=sz[x];++j) ff[j]=0;
    }
    for(int i=0;i<=sz[x];++i) for(int j=1;j<5;++j){
        g[i][j]=dp[x][i][j];dp[x][i][j]=0;
    }
    // if(x==3) cerr<<g[3][0]<<" "<<g[1][0]<<"\n";
    for(int i=0;i<=sz[x];++i) for(int j=0;j<5;++j){
        // if(x==3&&!j&&(i-1==1||i+1==1||i==1)&&g[i][j]) cerr<<i<<" "<<j<<"\n";
        if(i>0) Add(dp[x][i-1][j],g[i][j]*i%mod);
        if(i<sz[x]) Add(dp[x][i+1][j],g[i][j]);
        if(j<4) Add(dp[x][i][j+1],g[i][j]);
    }
    // for(int i=0;i<=sz[x];++i)
    //     if(dp[x][i][0]) cout<<x<<" "<<i<<" "<<dp[x][i][0]<<"\n";
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    n=read();
    for(int i=1;i<n;++i) add(read(),read());
    dfs1(1,0);dfs2(1);
    write(dp[1][0][0]);putchar(' ');write(dp[1][0][4]);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
    return 0;
}
