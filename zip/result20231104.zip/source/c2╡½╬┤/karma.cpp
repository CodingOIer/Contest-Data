#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn=2e5+5;
int n,ans;
struct node{int cnt,len;}a[Maxn];
char s[Maxn];
inline bool cmp(node a,node b){return a.cnt*(b.len-b.cnt)>b.cnt*(a.len-a.cnt);}
signed main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%s",s+1);
		a[i].len=strlen(s+1);
		int sum=0;
		for(int j=1;j<=a[i].len;j++)
			if(s[j]=='0')a[i].cnt++,ans+=sum;
			else sum++;
	}
	sort(a+1,a+1+n,cmp);
	int sum=0;
	for(int i=1;i<=n;i++){
		ans+=a[i].cnt*sum;
		sum+=a[i].len-a[i].cnt;
	}
	printf("%lld",ans);
	return 0;
}

