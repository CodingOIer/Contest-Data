#include<bits/stdc++.h>
#define ll long long
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=1005,Maxm=100005;
const ll inf=1e18;
int n,m,a[Maxn<<1];//0:ż 1:�� 
inline int id(int x,int y){return x+n*y;}
int head[Maxn<<1],nxt[Maxm],to[Maxm],w[Maxm],cnt1;
inline void add(int u,int v,int val){
	to[++cnt1]=v;
	nxt[cnt1]=head[u];
	w[cnt1]=val;
	head[u]=cnt1;
}
ll f[Maxn<<1];
int main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		int u=read()+1,v=read()+1,val=read();
		if(val%2==0){
			add(id(u,0),id(v,0),val);
			add(id(u,1),id(v,1),val);
		}
		else{
			add(id(u,0),id(v,1),val);
			add(id(u,1),id(v,0),val);
		}
	}
	for(int k=1;k<=n;k++){
		queue<int>h;
		for(int i=0;i<=n*2;i++)f[i]=inf,a[i]=0;
		f[id(k,0)]=0;
		h.push(id(k,0));
		while(h.size()){
			int u=h.front();
			h.pop();
			if(a[u]>m){
				f[u]=-inf;
				continue;
			}
			for(int i=head[u];i;i=nxt[i]){
				int y=to[i];
				if(f[y]>f[u]+1ll*w[i]){
					f[y]=f[u]+1ll*w[i];
					a[y]++;h.push(y);
				}
			}
		}
		if(f[id(k,1)]==-inf)write("Twinkle\n");
		else if(f[id(k,1)]==inf)write("a-w-r-y\n");
		else write(f[id(k,1)]),pc('\n');
	}
	flush();
	return 0;
}
