#include<bits/stdc++.h>
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=2e6+5;
int n,m,k;
int head[Maxn],to[Maxn<<1],nxt[Maxn<<1],cnt1;
inline void add_e(int u,int v){
	to[++cnt1]=v;
	nxt[cnt1]=head[u];
	head[u]=cnt1;
}
int f[Maxn],dfn[Maxn],cnt2,si[Maxn],son[Maxn],dep[Maxn],top[Maxn];
void dfs(int u,int v){
	f[u]=v;dep[u]=dep[v]+1;
	si[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v)continue;
		dfs(y,u);
		si[u]+=si[y];
		if(si[son[u]]<si[y])son[u]=y;
	}
}
void dfs2(int u,int t){
	top[u]=t;
	dfn[u]=++cnt2;
	if(!son[u])return;
	dfs2(son[u],t);
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==son[u]||y==f[u])continue;
		dfs2(y,y);
	}
}
struct Tree{int ls,rs,data;}t[Maxn<<1];
int root,cnt;
int add[Maxn];
inline void spread(int x){
	t[t[x].ls].data+=add[x];t[t[x].rs].data+=add[x];
	add[t[x].ls]+=add[x];add[t[x].rs]+=add[x];
	add[x]=0;
}
void change(int&x,int l,int r,int L,int R,int p){
	if(!x)x=++cnt;
	if(L<=l&&r<=R){t[x].data+=p;add[x]+=p;return;}
	int mid=l+r>>1;spread(x);
	if(L<=mid)change(t[x].ls,l,mid,L,R,p);
	if(mid<R)change(t[x].rs,mid+1,r,L,R,p);
	t[x].data=max(t[t[x].ls].data,t[t[x].rs].data);
}
inline int solve(int u,int v,int p){
	while(top[u]!=top[v]){
		if(dep[top[u]]<dep[top[v]])swap(u,v);
		change(root,1,n,dfn[top[u]],dfn[u],p);
		u=f[top[u]];
	}
	if(dep[u]<dep[v])swap(u,v);
	change(root,1,n,dfn[v],dfn[u],p);
	return v;
}
struct node{int u,v;}w[Maxn];
int ans;
int main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		add_e(u,v);add_e(v,u);
	}
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		w[i]={u,v};
	}
	dfs(1,0);dfs2(1,1);
	for(int i=1;i<=n;i++)change(root,1,n,i,i,0);
	for(int s=0;s<(1<<m);s++){
		int cntt=0;
		for(int i=1;i<=m;i++)
			if(s&(1<<i-1))cntt++;
		if(cntt!=k)continue;
		for(int i=1;i<=m;i++)
			if(s&(1<<i-1))
				solve(w[i].u,w[i].v,1);
		if(t[root].data==k)ans++;
		//write(t[root].data);pc('\n');
		for(int i=1;i<=m;i++)
			if(s&(1<<i-1))
				solve(w[i].u,w[i].v,-1);
	}
	write(ans);flush();
	return 0;
}

