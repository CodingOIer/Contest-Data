#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int mod=998244353;
int n;
int siz[205],son[205];
int f[205][205];
int F[205][205];
int g[205][205];
vector<int>to[205];
void sol(int x,int fa){
	g[x][0]=1;
	siz[x]=1;
	for(auto y:to[x]){
		if(y==fa)continue;
		sol(y,x);
		siz[x]+=siz[y];
		if(siz[y]>siz[son[x]])son[x]=y;
	}
	if(son[x])for(int i=0;i<=siz[son[x]];i++)g[x][i]=f[son[x]][i];
	int sum=siz[son[x]];
	for(auto y:to[x]){
		if(y==fa)continue;
		if(y==son[x])continue;
		sum+=siz[y];
		int tmp[205];
		fill(tmp,tmp+sum+1,0);
		for(int i=0;i<=sum;i++)
			for(int j=0;j<=siz[y]&&j<=i;j++)
				tmp[i]=(tmp[i]+f[y][j]*g[x][i-j])%mod;
		for(int i=0;i<=sum;i++)g[x][i]=tmp[i];
	}
	f[x][0]=g[x][1];
	for(int i=1;i<=siz[x];i++)
		f[x][i]=(g[x][i+1]*(i+1)%mod+g[x][i-1])%mod;
}
signed main(){
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	cin>>n;
	for(int i=1;i<n;i++){
		int x,y;
		cin>>x>>y;
		to[x].push_back(y);
		to[y].push_back(x);
	}
	sol(1,0);
	cout<<f[1][0]<<" 0";
	return 0;
}
