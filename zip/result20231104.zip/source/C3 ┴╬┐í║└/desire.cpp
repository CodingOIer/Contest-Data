#include<bits/stdc++.h>
#define int long long 
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
const int mod=1e9+7;
int n,m,k,ans;
int dep[2000005],top[2000005],siz[2000005],fa[2000005],sum[2000005],res[2000005],son[2000005];
int fac[2000005],inv[2000005];
vector<int>to[2000005];
int poww(int x,int y){
	int sum=1;
	while(y){
		if(y&1)sum=sum*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return sum;
}
void Init(int N){
	fac[0]=1;
	for(int i=1;i<=N;i++)fac[i]=(fac[i-1]*i)%mod;
	inv[N]=poww(fac[N],mod-2);
	for(int i=N-1;i>=0;i--)inv[i]=inv[i+1]*(i+1)%mod;
}
int C(int x,int y){
	if(x<0||y<0||x<y)return 0;
	return fac[x]*inv[y]%mod*inv[x-y]%mod;
}
void dfs1(int x,int p){
	fa[x]=p;
	dep[x]=dep[p]+1;
	siz[x]=1;
	for(auto y:to[x]){
		if(y==p)continue;
		dfs1(y,x);
		siz[x]+=siz[y];
		if(siz[y]>siz[son[x]])son[x]=y;
	}
}
void dfs2(int x,int Top){
	top[x]=Top;
	if(son[x])dfs2(son[x],Top);
	for(auto y:to[x]){
		if(y==fa[x])continue;
		if(y==son[x])continue;
		dfs2(y,y);
	}
}
int lca(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]>dep[top[y]])x=fa[top[x]];
		else y=fa[top[y]];
	}
	if(dep[x]<dep[y])return x;
	else return y;
}
void sol(int x){
	for(auto y:to[x]){
		if(y==fa[x])continue;
		sol(y);
		sum[x]+=sum[y];
	}
	ans=(ans+C(sum[x],k)-C(sum[x]-res[x],k)+mod)%mod;
}
signed main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	Init(2e6);
	read(n,m,k);
	for(int i=1;i<n;i++){
		int u,v;
		read(u,v);
		to[u].push_back(v);
		to[v].push_back(u);
	}
	dfs1(1,0);
	dfs2(1,1);
	for(int i=1;i<=m;i++){
		int x,y;
		read(x,y);
		sum[x]++,sum[y]++;
		sum[lca(x,y)]--;
		sum[fa[lca(x,y)]]--;
		res[lca(x,y)]++;
	}
	sol(1);
	write(ans);
	flush();
	return 0;
}
