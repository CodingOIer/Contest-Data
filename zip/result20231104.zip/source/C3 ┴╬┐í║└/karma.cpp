#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,ans;
string s[200005];
struct node{
	int x,y,id;
}a[200005];
bool cmp(node A,node B){
	return A.y*B.x<A.x*B.y;
}
signed main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>s[i];
	for(int i=1;i<=n;i++){
		a[i].id=i;
		for(int j=0;j<s[i].size();j++){
			if(s[i][j]=='0')a[i].x++;
			else a[i].y++;
		}
	}
	sort(a+1,a+n+1,cmp);
	int s0=0,s1=0;
	for(int i=1;i<=n;i++){
		for(int j=0;j<s[a[i].id].size();j++){
			if(s[a[i].id][j]=='0'){
				ans+=s1;
				s0++;
			}else{
				s1++;
			}
		}
	}
	cout<<ans;
	return 0; 
} 
