#include<bits/stdc++.h>
#define int long long 
#define mk(a,b) make_pair(a,b)
using namespace std;
int n,m;
struct node{
	int u,w;
};
vector<node>to[1005],To[1005];
int in[1005][2],vis[1005][2];
int dis[1005][2],len[1005][2];
bool check(int x){
	memset(vis,0,sizeof vis);
	memset(in,0,sizeof in);
	queue<pair<int,int> >q;
	q.push(mk(x,0));
	vis[x][0]=1;
	in[x][0]=1;
	while(!q.empty()){
		int x=q.front().first;
		int s=q.front().second;
		q.pop();
		for(auto y:to[x]){
			if(vis[y.u][s]==0){
				vis[y.u][s]=1;
				q.push(mk(y.u,s));
			}
		}
		for(auto y:To[x]){
			if(vis[y.u][1-s]==0){
				vis[y.u][1-s]=1;
				q.push(mk(y.u,1-s));
			}
		}
	}
	return vis[x][1];
}
void sol(int x){
	for(int i=1;i<=n;i++)dis[i][0]=dis[i][1]=1e17;
	memset(in,0,sizeof in);
	memset(len,0,sizeof len);
	queue<pair<int,int> >q;
	q.push(mk(x,0));
	in[x][0]=1;
	dis[x][0]=0;
	len[x][0]=0;
	while(!q.empty()){
		int x=q.front().first;
		int s=q.front().second;
		q.pop();
//		cout<<x<<" "<<s<<" "<<dis[x][s]<<endl;
		in[x][s]=0;
		for(auto y:to[x]){
			if(dis[y.u][s]>dis[x][s]+y.w){
				dis[y.u][s]=dis[x][s]+y.w;
				len[y.u][s]=len[x][s]+1;
				if(len[y.u][s]>2*m){
//					cout<<y.u<<" "<<s<<" "<<len[y.u][s]<<" "<<2*n<<endl;
					dis[y.u][s]=-1e17;
					continue;
				}
				if(in[y.u][s]==0){
					q.push(mk(y.u,s));
					in[y.u][s]=1;
				}
			}
		}
		for(auto y:To[x]){
			if(dis[y.u][1-s]>dis[x][s]+y.w){
				dis[y.u][1-s]=dis[x][s]+y.w;
				len[y.u][1-s]=len[x][s]+1;
				if(len[y.u][1-s]>2*m){
//					cout<<y.u<<" "<<1-s<<" "<<len[y.u][1-s]<<" "<<2*n<<endl;
					dis[y.u][1-s]=-1e17;
					continue;
				}
				if(in[y.u][1-s]==0){
					q.push(mk(y.u,1-s));
					in[y.u][1-s]=1;
				}
			}
		}
	}
	if(dis[x][1]==-1e17)cout<<"Twinkle"<<'\n';
	else cout<<dis[x][1]<<'\n';
}
signed main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v,w;
		cin>>u>>v>>w;
		u++,v++;
		if(abs(w)%2==1){
			To[u].push_back((node){v,w});
		}else{
			to[u].push_back((node){v,w});
		}
	}
	for(int i=1;i<=n;i++){
		if(check(i)){
			sol(i);
		}else{
			cout<<"a-w-r-y"<<'\n';
		}
	}
	return 0;
}
