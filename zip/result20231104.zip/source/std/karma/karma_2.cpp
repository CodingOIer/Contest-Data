#include<bits/stdc++.h>
using namespace std;
#define int long long
using ll =long long;
#define rep(i,l,r) for(int i=l;i<=r;++i)
const int N=2e6+5;
const int mod=1e9+7;
ll a[N],vis[N],n,m,x,b[N],pre[N],y,f[N],d[N],v[N],k;
ll s1[N],s0[N];
ll getmi(ll a,ll x)
{
	ll rt=1;
	while(x)
	{
		if(x&1) rt=rt*a%mod;
		a=a*a%mod,x>=1;
	}
	return rt;
}
struct D{
int v,id;
} q[N];
string ss[N];
ll gett(string s,int x)
{
	ll tm=0,len=s.size(),ans=0;
	rep(i,0,len-1)
	{
		if(s[i]=='1') tm++;
		else ans+=tm;
 
	}
	s1[x]=tm;
	s0[x]=len-tm;
	//cout<<ans<<"" <<tm<<" "<<len<< " "<<x<<"\n";
	return ans; 
}
vector<int> v1,v2;
bool cmp(int x,int y)
{
	return s0[x]*s1[y]>s1[x]*s0[y];
}
 
void solve()
{
	cin>>n;
	ll ans=0,tm=0;
	rep(i,1,n) cin>>ss[i];
	rep(i,1,n) a[i]=i;
	rep(i,1,n) ans+=gett(ss[i],i);
	sort(a+1,a+n+1,cmp);
	//rep(i,1,n) cout<<s0[a[i]]<<" "<<s1[a[i]]<<"\n";
	rep(i,1,n)
	{
		ans+=s0[a[i]]*tm;
		tm+=s1[a[i]];
	}
	
	cout<<ans<<"\n";
	
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	//freopen("1.in","w",stdout);
	//srand(time(0)^getpid());
	int t=1;
	//cin>>t;
	while(t--) solve();
}
