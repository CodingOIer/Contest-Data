#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
const int N=1e6+7;
const int M=1e7+7;
 
char s[M];
pair<int,int>A[N];
 
int main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    int n;scanf("%d",&n);
    ll ans=0;
    for(int i=0;i<n;++i){
        scanf("%s",s);
        int m=strlen(s);
        int cnt=0;
        for(int j=0;j<m;++j){
            if(s[j]=='0'){
                ans+=cnt;
            }
            else {
                cnt++;
            }
        }
        A[i]={m-cnt,cnt};
    }
    sort(A,A+n,[](const pair<int,int> &A, const pair<int,int> &B){return (ll)A.first*B.second>(ll)A.second*B.first;});
    int sum=0;
    for(int i=0;i<n;++i){
        ans+=(ll)A[i].first*sum;
        sum+=A[i].second;
    }
    printf("%lld\n",ans);
    return 0;
}
