#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define cs const
#define pb push_back
#define gc getchar
inline int read(){
    int res=0;bool f=0;
    char ch=gc();
    while(!isdigit(ch))f=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?-res:res;
}
cs int mod=1e9+7;
inline int mul(int a,int b){return 1ll*a*b%mod;}
inline void Add(int &a,int b){a=(a+b>=mod)?(a+b-mod):(a+b);}
inline void Dec(int &a,int b){a=(a<b)?(a-b+mod):(a-b);}
inline void Mul(int &a,int b){a=1ll*a*b%mod;}
inline int ksm(int a,int b,int res=1){for(;b;b>>=1,Mul(a,a))if(b&1)Mul(res,a);return res;}
inline int Inv(int x){return ksm(x,mod-2);}
cs int N=2000005;
int fac[N],ifac[N];
void init(){
    ifac[0]=fac[0]=1;
    for(int i=1;i<N;i++)fac[i]=mul(fac[i-1],i);
    ifac[N-1]=Inv(fac[N-1]);
    for(int i=N-2;i;i--)ifac[i]=mul(ifac[i+1],i+1);
}
inline int C(int n,int m){return (n<m||n<0||m<0)?0:mul(fac[n],mul(ifac[m],ifac[n-m]));}
vector<int> e[N];
int n,m,k;
int vl1[N],vl2[N],tg1[N],tg2[N];
int fa[N][22],dep[N];
void dfs(int u){
    for(int i=1;i<=21;i++)fa[u][i]=fa[fa[u][i-1]][i-1];
    for(int v:e[u])if(v!=fa[u][0]){
        dep[v]=dep[u]+1,fa[v][0]=u;
        dfs(v);
    }
}
inline int Lca(int u,int v){
    if(dep[u]<dep[v])swap(u,v);
    for(int i=21;~i;i--)if(dep[fa[u][i]]>=dep[v])u=fa[u][i];
    if(u==v)return u;
    for(int i=21;~i;i--)if(fa[u][i]!=fa[v][i])u=fa[u][i],v=fa[v][i];
    return fa[u][0];
}
void dfs2(int u){
    for(int v:e[u])if(v!=fa[u][0]){
        dfs2(v),vl1[u]+=vl1[v],vl2[u]+=vl2[v];
    }vl1[u]+=tg1[u],vl2[u]+=tg2[u];
}
int main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    init();
    n=read(),m=read(),k=read();
    for(int i=1;i<n;i++){
        int u=read(),v=read();
        e[u].pb(v),e[v].pb(u);
    }
    dep[1]=1,dfs(1);
    for(int i=1;i<=m;i++){
        int u=read(),v=read(),g=Lca(u,v);
        tg1[u]++,tg1[v]++,tg1[g]--,tg1[fa[g][0]]--;
        tg2[u]++,tg2[v]++,tg2[g]--,tg2[g]--;
    }
    dfs2(1);
    int res=0;
    for(int i=1;i<=n;i++)Add(res,C(vl1[i],k));
    for(int i=2;i<=n;i++)Dec(res,C(vl2[i],k));
    cout<<res<<'\n';
    for(int i=1;i<=n;i++){
        e[i].clear(),tg1[i]=tg2[i]=vl1[i]=vl2[i]=dep[i]=0;
        for(int j=0;j<22;j++)fa[i][j]=0;
    }
    return 0;
}
