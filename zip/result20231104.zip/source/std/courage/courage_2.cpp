/*
start thinking:
BULB:
result of thinking: Pure.

f(u, k): 处理 subtree(u), 从 u 处冒出 k 个线头, 方案数.
g(u, k): 处理 subtree(u), 从 u 处冒出 k 个线头, 交点数之和 * 2.
对交点的贡献在较浅线头冒出时计入.

start coding:
AC:
*/
#include <bits/stdc++.h>
#define mp make_pair
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ldouble;
typedef pair<int, int> P;
typedef pair<ll, ll> Pll;
const int inf = 0x3f3f3f3f;
const ll infll = 0x3f3f3f3f3f3f3f3f;
template<class T> bool chmin(T &x, const T &y) {
  return x > y ? (x = y, true) : false;
}
template<class T> bool chmax(T &x, const T &y) {
  return x < y ? (x = y, true) : false;
}
bool Mbe;

#define maxn 2005
const int mod = 998244353;
const int inv2 = 499122177;
int n, siz[maxn], f[maxn][maxn], g[maxn][maxn], tmpf[maxn], tmpg[maxn];
vector<int> adj[maxn];

void dfs(int u, int p) {
  siz[u] = 0;
  f[u][0] = 1;
  for (auto v : adj[u]) {
    if (v == p)
      continue;
    dfs(v, u);
    for (int i = 0; i <= siz[u] + siz[v]; i++)
      tmpf[i] = tmpg[i] = 0;
    for (int i = 0; i <= siz[u]; i++) {
      for (int j = 0; j <= siz[v]; j++) {
        tmpf[i + j] = (tmpf[i + j] + (ll)f[u][i] * f[v][j]) % mod;
        tmpg[i + j] = (tmpg[i + j] + (ll)g[u][i] * f[v][j] + (ll)f[u][i] * g[v][j]) % mod;
      }
    }
    siz[u] += siz[v];
    memcpy(f[u], tmpf, sizeof(tmpf));
    memcpy(g[u], tmpg, sizeof(tmpg));
  }
  siz[u]++;
  for (int i = 0; i <= siz[u]; i++)
    tmpf[i] = tmpg[i] = 0;
  for (int i = 0; i < siz[u]; i++) {
    if (i) {
      tmpf[i - 1] = (tmpf[i - 1] + (ll)f[u][i] * i) % mod;
      tmpg[i - 1] = (tmpg[i - 1] + (ll)g[u][i] * i) % mod;
    }
    tmpf[i + 1] = (tmpf[i + 1] + f[u][i]) % mod;
    tmpg[i + 1] = (tmpg[i + 1] + g[u][i] + (ll)i * f[u][i]) % mod;
  }
  memcpy(f[u], tmpf, sizeof(tmpf));
  memcpy(g[u], tmpg, sizeof(tmpg));
}

void solve() {
  cin >> n;
  for (int i = 1; i <= n; i++) {
    adj[i].clear();
    siz[i] = 0;
    for (int j = 0; j <= n; j++)
      f[i][j] = g[i][j] = 0;
  }
  for (int i = 1; i < n; i++) {
    int u, v;
    cin >> u >> v;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }
  dfs(1, 0);
  cout << (f[1][0] + mod) % mod << " " << ((ll)g[1][0] * inv2 % mod + mod) % mod << '\n';
}

bool Med;
int main() {
  ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    solve();
  return 0;
}