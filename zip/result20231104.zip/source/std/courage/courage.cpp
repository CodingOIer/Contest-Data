#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define cs const
#define pii pair<int,int>
#define fi first
#define se second
#define gc getchar
#define pb push_back
#define bg begin
inline int read(){
    char ch=gc();
    int res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
  inline ll readll(){
    char ch=gc();
    ll res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
template<typename tp>inline void chemx(tp &a,tp b){if(a<b)a=b;}
template<typename tp>inline void chemn(tp &a,tp b){if(a>b)a=b;}
cs int mod=998244353;
inline int add(int a,int b){return (a+b)>=mod?(a+b-mod):(a+b);}
inline int dec(int a,int b){return (a<b)?(a-b+mod):(a-b);}
inline int mul(int a,int b){static ll r;r=(ll)a*b;return (r>=mod)?(r%mod):r;}
inline void Add(int &a,int b){a=(a+b)>=mod?(a+b-mod):(a+b);}
inline void Dec(int &a,int b){a=(a<b)?(a-b+mod):(a-b);}
inline void Mul(int &a,int b){static ll r;r=(ll)a*b;a=(r>=mod)?(r%mod):r;}
inline int ksm(int a,int b,int res=1){for(;b;b>>=1,Mul(a,a))(b&1)&&(Mul(res,a),1);return res;}
inline int Inv(int x){return ksm(x,mod-2);}
inline int fix(ll x){x%=mod;return (x<0)?x+mod:x;}
cs int N=2005;
int f[N][N],g[N][N];
int n,sz[N];
vector<int> e[N];
int fac[N],ifac[N];
void init_fac(){
    fac[0]=ifac[0]=1;
    for(int i=1;i<N;i++)fac[i]=mul(fac[i-1],i);
    ifac[N-1]=Inv(fac[N-1]);
    for(int i=N-2;i;i--)ifac[i]=mul(ifac[i+1],i+1);
}
inline int C(int n,int m){
    return (n<m||n<0||m<0)?0:mul(fac[n],mul(ifac[m],ifac[n-m]));
}
int tmpf[N],tmpg[N];
void dfs(int u,int fa){
    sz[u]=1;f[u][0]=1;
    for(int v:e[u]){
        if(v==fa)continue;
        dfs(v,u);
        for(int i=0;i<=sz[u];i++)
        for(int j=0;j<=sz[v];j++)
            Add(tmpf[i+j],mul(mul(f[u][i],f[v][j]),C(i+j,i))),
            Add(tmpg[i+j],mul(add(mul(f[u][i],g[v][j]),mul(g[u][i],f[v][j])),C(i+j,i)));
        sz[u]+=sz[v];
        for(int i=0;i<=sz[u];i++)f[u][i]=tmpf[i],g[u][i]=tmpg[i],tmpf[i]=tmpg[i]=0;
    }
    for(int i=0;i<=sz[u];i++){
        if(i)Add(tmpf[i-1],f[u][i]);
        Add(tmpf[i+1],mul(f[u][i],i+1));

        if(i)Add(tmpg[i-1],g[u][i]);
        Add(tmpg[i+1],add(mul(g[u][i],i+1),mul(i*(i+1)/2,f[u][i])));
    }
    for(int i=0;i<=sz[u];i++){
        f[u][i]=tmpf[i];
        g[u][i]=tmpg[i];
        tmpf[i]=tmpg[i]=0;
    }assert(tmpf[sz[u]+1]==0&&tmpg[sz[u]+1]==0);
}
int main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    int T=1;
    init_fac();
    while(T--){
        n=read();
        
        for(int i=1;i<n;i++){
            int u=read(),v=read();
            e[u].pb(v),e[v].pb(u);
        }
        dfs(1,0);
        cout<<f[1][0]<<" "<<g[1][0]<<'\n';
        for(int i=1;i<=n;i++)e[i].clear();
        memset(sz,0,sizeof(sz));
        memset(f,0,sizeof(f));
        memset(g,0,sizeof(g));
    }
    return 0;
}
