#include <bits/stdc++.h>

#define int long long

using namespace std;

typedef long long ll;
typedef long double ld;

#define pii pair<int, int>
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()

const int N = 2005, INF = 1e15;
vector<pii> orig_g[N], orig_r[N];

bool used[N];
vector<int> order;

void dfs_order(int v) {
    used[v] = true;
    for (auto [to, c] : orig_g[v])
        if (!used[to])
            dfs_order(to);
    order.push_back(v);
}

int comp[N], comp_cnt;
vector<int> comp_memb[N];
vector<pair<pii, int>> comp_edges[N];

void dfs_component(int v) {
    used[v] = true;
    comp[v] = comp_cnt;
    comp_memb[comp_cnt].push_back(v);
    for (auto [to, c] : orig_r[v]) {
        if (!used[to])
            dfs_component(to);
        if (comp[to] == comp[v])
            comp_edges[comp_cnt].push_back({{v, to}, c});
    }
}

int even(int i) {
    return 2 * i;
}

int odd(int i) {
    return 2 * i + 1;
}

int ans[N];
vector<int> d(N), new_d(N);
vector<pii> doubled_g[N];

void doubled_dfs(int v) {
    used[v] = true;
    for (auto [to, c] : doubled_g[v])
        if (!used[to])
            doubled_dfs(to);
}

void solve_component(int cur_comp) {
    vector<pair<pii, int>> e;
    for (auto p : comp_edges[cur_comp]) {
        int from = p.fi.fi, to = p.fi.se, c = p.se;
        if (c % 2) {
            e.push_back({{even(from), odd(to)}, c});
            e.push_back({{odd(from), even(to)}, c});
            doubled_g[even(from)].push_back({odd(to), c});
            doubled_g[odd(from)].push_back({even(to), c});
        } else {
            e.push_back({{even(from), even(to)}, c});
            e.push_back({{odd(from), odd(to)}, c});
            doubled_g[even(from)].push_back({even(to), c});
            doubled_g[odd(from)].push_back({odd(to), c});
        }
    }
    bool neg_cycle = false;
    fill(all(d), INF);
    d[even(comp_memb[cur_comp].front())] = 0;
    for (int i = 0; i < 2 * comp_memb[cur_comp].size(); i++) {
        for (auto p : e) {
            int from = p.fi.fi, to = p.fi.se, c = p.se;
            if (d[to] > d[from] + c) {
                d[to] = max(-INF, d[from] + c);
                if (i + 1 >= 2 * comp_memb[cur_comp].size()) {
                    neg_cycle = true;
                }
            }
        }
    }
    if (neg_cycle) {
        for (int v : comp_memb[cur_comp]) {
            fill(used, used + N, false);
            doubled_dfs(even(v));
            ans[v] = (used[odd(v)] ? -INF : INF);
        }
    } else {
        for (int v : comp_memb[cur_comp]) {
            fill(used, used + N, false);
            doubled_dfs(even(v));
            if (!used[odd(v)]) {
                ans[v] = INF;
            } else {
                fill(used, used + N, false);
                fill(all(new_d), INF);
                int s = even(v);
                new_d[s] = 0;
                priority_queue<pii, vector<pii>, greater<>> q;
                q.push({new_d[s], s});

                while (!q.empty()) {
                    auto [dist, v] = q.top();
                    q.pop();
                    if (used[v]) continue;
                    used[v] = true;
                    for (auto [to, cost] : doubled_g[v]) {
                        int w = cost + d[v] - d[to];
                        if (new_d[to] > dist + w) {
                            new_d[to] = dist + w;
                            q.push({new_d[to], to});
                        }
                    }
                }

                ans[v] = new_d[odd(v)] - d[s] + d[odd(v)];
            }
        }
    }
}

int32_t main() {
//   freopen("input.txt", "r", stdin);
//   freopen("output.txt", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    int n, m;
    cin >> n >> m;

    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        orig_g[a].push_back({b, c});
        orig_r[b].push_back({a, c});
    }

    order.reserve(n);
    for (int i = 0; i < n; i++)
        if (!used[i])
            dfs_order(i);
    fill(used, used + n, false);
    reverse(all(order));
    for (int v : order)
        if (!used[v]) {
            dfs_component(v);
            comp_cnt++;
        }

    for (int i = 0; i < comp_cnt; i++)
        solve_component(i);

    for (int i = 0; i < n; i++) {
        if (ans[i] == -INF)
            cout << "Twinkle\n";
        else if (ans[i] == INF)
            cout << "a-w-r-y\n";
        else
            cout << ans[i] << '\n';
    }

    return 0;
}