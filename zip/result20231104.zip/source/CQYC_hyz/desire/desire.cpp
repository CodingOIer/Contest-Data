#include <bits/stdc++.h>
using namespace std;

char buf[1 << 23], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 and (p2 = (p1 = buf) + fread(buf, 1, 1 << 23, stdin), p1 == p2) ? EOF : *p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e6 + 10;

int n, m, k, ans;
int fa[N], dep[N], son[N], top[N], siz[N];
int s[N], d[N], fac[N], inv[N];

vector<int> e[N];

void dfs1(int x) {
    siz[x] = 1, dep[x] = dep[fa[x]] + 1;
    for(int v : e[x]) if(v ^ fa[x]) {
        fa[v] = x, dfs1(v), siz[x] += siz[v];
        if(siz[v] > siz[son[x]]) son[x] = v;
    }
}

void dfs2(int x, int t) {
    top[x] = t; if(!son[x]) return; dfs2(son[x], t);
    for(int v : e[x]) if(!top[v]) dfs2(v, v);
}

int lca(int x, int y) {
    while(top[x] ^ top[y]) dep[top[x]] > dep[top[y]] ? x = fa[top[x]] : y = fa[top[y]];
    return dep[x] > dep[y] ? y : x;
}

int C(int x, int y) { return y > x ? 0 : 1ll * fac[x] * inv[y] % mod * inv[x - y] % mod; }

void init() {
    dfs1(1), dfs2(1, 1), fac[0] = 1;
    for(int i = 1; i < N; i++) fac[i] = 1ll * fac[i - 1] * i % mod;
    inv[N - 1] = q_pow(fac[N - 1], mod - 2);
    for(int i = N - 1; i; i--) inv[i - 1] = 1ll * inv[i] * i % mod; 
}

void dfs3(int x) {
    for(int v : e[x]) if(v ^ fa[x]) {
        dfs3(v), s[x] += s[v] - d[v];
        inc(ans, mod - C(s[v] - d[v], k));
    }
    inc(ans, C(s[x], k));
}

bool edmer;
signed main() {
	freopen("desire.in", "r", stdin);
	freopen("desire.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), k = read();

    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    init();

    for(int i = 1; i <= m; i++) {
        int x = read(), y = read(), lc = lca(x, y);
        s[x]++, s[y]++, s[lc]--, d[lc]++;
    }

    dfs3(1), write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 