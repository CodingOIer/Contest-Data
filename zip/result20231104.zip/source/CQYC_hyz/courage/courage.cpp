#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2010;

int n;
int fa[N], siz[N], fac[N], inv[N];

int C(int x, int y) { return y > x ? 0 : 1ll * fac[x] * inv[y] % mod * inv[x - y] % mod; }

struct node {
    int x, y;
    node operator + (const node &p) const {
        return { (x + p.x) % mod, (y + p.y) % mod };
    }

    node operator * (const node &p) const {
        return { 1ll * x * p.x % mod, (1ll * x * p.y % mod + 1ll * p.x * y % mod) % mod };
    }

    node operator * (const int &p) const {
        return { 1ll * x * p % mod, 1ll * y * p % mod };
    }

    void operator += (const node &p) { *this = *this + p; }
} f[N][N], g[N];

vector<int> e[N];

void init() {
    fac[0] = 1;
    for(int i = 1; i < N; i++) fac[i] = 1ll * fac[i - 1] * i % mod;
    inv[N - 1] = q_pow(fac[N - 1], mod - 2);
    for(int i = N - 1; i; i--) inv[i - 1] = 1ll * inv[i] * i % mod;
}

void dfs(int x) {
    f[x][0] = { 1, 0 };

    for(int v : e[x]) if(v ^ fa[x]) {
        fa[v] = x, dfs(v);
        for(int i = 0; i <= siz[x]; i++) g[i] = f[x][i], f[x][i] = { 0, 0 };
        for(int i = 0; i <= siz[x]; i++) for(int j = 0; j <= siz[v]; j++)
            f[x][i + j] += (g[i] * f[v][j]) * C(i + j, i);
        
        siz[x] += siz[v];
    }
    
    for(int i = 0; i <= siz[x]; i++) g[i] = f[x][i], f[x][i] = f[x][i + 1];
    for(int i = 0; i <= siz[x]; i++) {
        int a = g[i].x, b = g[i].y;
        b = (1ll * b * (i + 1) % mod + 1ll * i * (i + 1) / 2 * a % mod) % mod;
        a = 1ll * a * (i + 1) % mod, f[x][i + 1] += (node) { a, b }; 
    }

    siz[x]++;
}

bool edmer;
signed main() {
	freopen("courage.in", "r", stdin);
	freopen("courage.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    init(), n = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    dfs(1);
    
    write(f[1][0].x), putchar(' '), write(f[1][0].y);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 