#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e4 + 10, inf = 1e17;

struct edge {
    int v, w;
};

int n, m;
int d[2][N], cnt[2][N];

bool vis[2][N];

vector<edge> e[N], tmp;

queue<int> q;

namespace sub1 {

    void solve(int s) {
        while(!q.empty()) q.pop();
        for(int i = 1; i <= n; i++) {
            d[0][i] = d[1][i] = inf;
            vis[0][i] = vis[1][i] = 0;
            cnt[0][i] = cnt[1][i] = 0;
        }

        for(edge l : e[s]) {
            int op = l.w & 1;
            if(l.w < d[op][l.v]) {
                d[op][l.v] = l.w;
                if(!vis[op][l.v]) vis[op][l.v] = 1, q.push(op ? -l.v : l.v);
            }
        }

        while(!q.empty()) {
            int x = q.front(), op = 0; q.pop();
            if(x < 0) x = -x, op = 1;
            vis[op][x] = 0, cnt[op][x]++;
            for(edge l : e[x]) {
                int w = l.w + d[op][x], t = w & 1;
                if(w < d[t][l.v] and cnt[t][l.v] <= n + 10) {
                    d[t][l.v] = w;
                    if(!vis[t][l.v]) vis[t][l.v] = 1, q.push(t ? -l.v : l.v);
                }
            }
        }

        if(cnt[1][s] > n) puts("Twinkle");
        else if(!cnt[1][s]) puts("a-w-r-y");
        else write(d[1][s]), putchar('\n');
    }

    void main() {
        for(int i = 1; i <= n; i++) solve(i);
    }
}

namespace sub2 {
    int tot, top;
    int dfn[N], col[N], low[N], stk[N];

    bool v1[N];

    void tarjan(int x) {
        dfn[x] = low[x] = ++tot, v1[x] = 1, stk[++top] = x;
        
        for(edge l : e[x]) {
            if(!dfn[l.v]) tarjan(l.v), Min(low[x], low[l.v]);
            else if(v1[l.v]) Min(low[x], dfn[l.v]);
        }

        if(dfn[x] == low[x]) while(stk[top + 1] ^ x) col[stk[top]] = x, v1[stk[top--]] = 0;
    }

    bool check(int s) {
        while(!q.empty()) q.pop();
        for(int i = 1; i <= n; i++) {
            d[0][i] = d[1][i] = inf;
            vis[0][i] = vis[1][i] = 0;
            cnt[0][i] = cnt[1][i] = 0;
        }

        for(edge l : e[s]) {
            int op = l.w & 1;
            if(l.w < d[op][l.v]) {
                d[op][l.v] = l.w;
                if(!vis[op][l.v]) vis[op][l.v] = 1, q.push(op ? -l.v : l.v);
            }
        }

        while(!q.empty()) {
            int x = q.front(), op = 0; q.pop();
            if(x < 0) x = -x, op = 1;
            vis[op][x] = 0, cnt[op][x]++;
            for(edge l : e[x]) {
                int w = l.w + d[op][x], t = w & 1;
                if(w < d[t][l.v] and cnt[t][l.v] <= n + 10) {
                    d[t][l.v] = w;
                    if(!vis[t][l.v]) vis[t][l.v] = 1, q.push(t ? -l.v : l.v);
                }
            }
        }

        for(int i = 1; i <= n; i++) if(col[i] == s and cnt[1][i] > n) return 1;
        return 0;
    }

    void main() {
        for(int i = 1; i <= n; i++) if(!dfn[i]) tarjan(i);

        for(int i = 1; i <= n; i++) {
            for(edge l : e[i]) if(col[l.v] == col[i]) tmp.push_back(l);
            swap(e[i], tmp), tmp.clear();
        }

        for(int i = 1; i <= n; i++) if(col[i] == i) v1[i] = check(i);
        
        for(int i = 1; i <= n; i++) {
            if(v1[col[i]]) puts("Twinkle");
            else sub1 :: solve(i);
        }
    }
}

bool edmer;
signed main() {
	freopen("innocent.in", "r", stdin);
	freopen("innocent.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    n = read(), m = read();
    for(int i = 1; i <= m; i++) {
        int u = read() + 1, v = read() + 1, w = read();
        e[u].push_back({ v, w });
    }

    sub2 :: main();


    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 