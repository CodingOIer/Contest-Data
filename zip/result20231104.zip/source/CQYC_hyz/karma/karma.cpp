#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct node {
    int x, y;
} a[N];

int n, ans;

string ch;

namespace sub1 {
    const int M = 1 << 18;

    int f[M];

    void main() {
        memset(f, 0x3f, sizeof(f)), f[0] = 0;

        for(int i = 0; i < (1 << n); i++) {
            int x = 0;
            for(int j = 0; j < n; j++) if(i >> j & 1) x += a[j].y;
            for(int j = 0; j < n; j++) if(!(i >> j & 1)) Min(f[i | (1 << j)], f[i] + a[j].x * x);
        }

        write(f[(1 << n) - 1] + ans);
    }
}

namespace sub2 {
    bool check() {
        for(int i = 0; i < n; i++) if(a[i].x + a[i].y != 1) return 0;
        return 1;
    }

    void main() { write(ans); }
}

bool edmer;
signed main() {
	freopen("karma.in", "r", stdin);
	freopen("karma.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 0; i < n; i++) {
        cin >> ch;
        for(int j = 0; j < ch.size(); j++)
            ch[j] == '0' ? ans += a[i].y, a[i].x++ : a[i].y++;
    }

    if(n <= 18) sub1 :: main();
    else if(sub2 :: check()) sub2 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 