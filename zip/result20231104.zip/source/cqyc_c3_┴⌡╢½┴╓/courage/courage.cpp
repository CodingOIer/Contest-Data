#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 2005,mod = 998244353;
vector<int> g[N];
int n;

int f[N][N],t[N],siz[N];
void dfs(int u,int father){
    siz[u] = 1;
    for(int v:g[u]){
        if(v==father)
            continue;
        dfs(v,u);
        siz[u] += siz[v];
        for(int k=0;k<=siz[u];k++)
            t[k] = 0;
        for(int k=0;k<=siz[u];k++)
            for(int j=0;j<=min(siz[v],k);j++)
                t[k] = (t[k]+f[u][k-j]*f[v][j])%mod;
        for(int k=0;k<=siz[u];k++)
            f[u][k] = t[k];
    }
    for(int k=0;k<=siz[u];k++)
        t[k] = 0;
    for(int k=0;k<=siz[u];k++){
        t[k] = f[u][k+1]*(k+1);
        if(k)
            t[k] = max(t[k],f[u][k-1]);
    }
    f[u][siz[u]] = max(f[u][siz[u]],1ll);
}

signed main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    n = in;
    for(int k=1;k<n;k++){
        int a = in,b = in;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs(1,0);
    out(f[1][0]);
    return 0;
}