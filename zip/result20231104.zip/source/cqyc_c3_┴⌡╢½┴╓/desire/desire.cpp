#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 2000005,mod = 1000000007;
int fac[N],inv[N];
vector<int> g[N];
int n,m,K;

int ksm(int a,int b){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

int C(int a,int b){
    if(a<0||b<0||b>a)
        return 0;
    return fac[a]*inv[b]%mod*inv[a-b]%mod;
}

int fa[N],dep[N],siz[N],son[N],top[N];
void dfs1(int u){
    siz[u] = 1;
    for(auto v:g[u]){
        if(v==fa[u])
            continue;
        fa[v] = u;
        dep[v] = dep[u]+1;
        dfs1(v);
        siz[u] += siz[v];
        if(siz[v]>siz[son[u]])
            son[u] = v;
    }
}

void dfs2(int u,int tp){
    top[u] = tp;
    if(son[u])
        dfs2(son[u],tp);
    for(auto v:g[u]){
        if(v==son[u]||v==fa[u])
            continue;
        dfs2(v,v);
    }
}

int lca(int x,int y){
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]])
            swap(x,y);
        x = fa[top[x]];
    }
    if(dep[x]<dep[y])
        swap(x,y);
    return y;
}

int d[N],e[N];

void dfs3(int u){
    for(int v:g[u]){
        if(v==fa[u])
            continue;
        dfs3(v);
        d[u] += d[v];
        e[u] += e[v];
    }
}

signed main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    inv[0] = fac[0] = 1;
    for(int k=1;k<N;k++)
        fac[k] = fac[k-1]*k%mod;  
    inv[N-1] = ksm(fac[N-1],mod-2);
    for(int k=N-2;k;k--)
        inv[k] = inv[k+1]*(k+1)%mod;
    
    n = in,m = in,K = in;
    for(int k=1;k<n;k++){
        int a = in,b = in;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs1(1);
    dfs2(1,1);
    for(int k=1;k<=m;k++){
        int x = in,y = in;
        int z = lca(x,y);
        d[x]++,d[y]++;
        d[z]--,d[fa[z]]--;

        e[x]++,e[y]++;
        e[z] -= 2;
    }
    dfs3(1);
    int ans = 0;
    for(int k=1;k<=n;k++){
        ans = (ans+C(d[k],K))%mod;
        ans = (ans-C(e[k],K)+mod)%mod;
    }
    out(ans);
    return 0;
}