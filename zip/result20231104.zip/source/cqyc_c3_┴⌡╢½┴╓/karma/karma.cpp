#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 200005;
pair<int,int> a[N];
int n;

int main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    cin >> n;
    long long ans = 0;
    for(int k=1;k<=n;k++){
        string s;
        cin >> s;
        int w[2] = {0,0};
        for(char c:s){
            if(c=='0')
                ans += w[1];
            w[c^48]++;
        }
        a[k] = {w[0],w[1]};
    }
    sort(a+1,a+1+n,[](auto x,auto y){return (long long)x.second*y.first<(long long)y.second*x.first;});
    int w1 = 0;
    for(int k=1;k<=n;k++){
        ans += (long long)w1*a[k].first;
        w1 += a[k].second;
    }
    cout << ans;
    return 0;
}