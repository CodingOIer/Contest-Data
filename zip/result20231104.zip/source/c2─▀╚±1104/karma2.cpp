#include<bits/stdc++.h>
#define re register
// #define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,per[200001],ans=0x7fffffff;
string s[200001];
int zero[200001];
inline int chk()
{
	int res=0;
	string t="";
	rep(i,1,n) t+=s[per[i]];
	int lim=t.size()-1;
	req(i,lim,0) zero[i]=zero[i+1]+(t[i]=='0');
	rep(i,0,lim) if(t[i]=='1') res+=zero[i];
	return res;
}
signed main()
{
//	freopen("karma.in","r",stdin);
//	freopen("karma.out","w",stdout);
	read(n);
	rep(i,1,n) cin>>s[i];
	iota(per+1,per+n+1,1);
	do
	{
		ans=min(ans,chk());
	} while(next_permutation(per+1,per+n+1));
	write(ans);
	return 0; 
}
