#include<bits/stdc++.h>
#define re register
#define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n;
string s[200001];
int zero[200001];
namespace Subtask1
{
	int per[200001],ans=0x7fffffff;
	inline int fact(int n)
	{
		int res=1;
		rep(i,2,n) res*=i;
		return res;
	}
	inline int chk()
	{
		int res=0;
		string t="";
		rep(i,1,n) t+=s[per[i]];
		int lim=t.size()-1;
		req(i,lim,0) zero[i]=zero[i+1]+(t[i]=='0');
		rep(i,0,lim) if(t[i]=='1') res+=zero[i];
		return res;
	}

	inline bool check()
	{
		int m=0;
		rep(i,1,n) m+=s[i].size();
		return (n<=11)&&(fact(n)*m<=5e8);
	}
	inline void solve()
	{
		iota(per+1,per+n+1,1);
		do
		{
			ans=min(ans,chk());
		} while(next_permutation(per+1,per+n+1));
		write(ans);
	}
}
namespace Subtask2
{
	inline bool check()
	{
		rep(i,1,n) if((s[i].size())^1) return 0;
		return 1;
	}
	inline void solve()
	{
		puts("0");
	}
}
namespace Subtask3
{
	int h[200001],id[200001],all[200001],m;
	double ave;
	inline void solve()
	{
		sort(s+1,s+n+1);
		rep(i,1,n) m+=s[i].size();
		rep(i,1,n)
		{
			int res=0,j=s[i].size()-1;
			while(s[i][j]=='1'&&j>=0) ++res,--j;
			h[i]=res;
			if(h[i]==s[i].size()) h[i]=1;
			else h[i]=0;
			for(auto j:s[i]) all[i]+=j=='1';
		}
		iota(id+1,id+n+1,1);
		sort(id+1,id+n+1,[](int x,int y){return h[x]!=h[y]?h[x]>h[y]:all[x]>all[y];});
		string t="";
		req(i,n,1) t+=s[id[i]];
		int ans=0,lim=t.size()-1;
		req(i,lim,0) zero[i]=zero[i+1]+(t[i]=='0');
		rep(i,0,lim) if(t[i]=='1') ans+=zero[i];
		write(ans);
	}
}
signed main()
{
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	read(n);
	rep(i,1,n) cin>>s[i];
	if(Subtask1::check()) Subtask1::solve();
	else if(Subtask2::check()) Subtask2::solve();
	else Subtask3::solve();
	return 0;
}
