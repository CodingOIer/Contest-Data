#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,k;
int ans,sum,ans1;
struct XZXZXZ{
	string x;
	int n0,ans;
}a[200005];
bool cmp(XZXZXZ x,XZXZXZ y){
	return x.n0*y.x.size()>y.n0*x.x.size();
}
bool vis[200005];
signed main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		cin>>a[i].x;
		for(int j=a[i].x.size()-1;j>=0;j--){
			if(a[i].x[j]=='0') a[i].n0++,sum++;
			else a[i].ans+=a[i].n0;
		}
	}
	sort(a+1,a+n+1,cmp);
	int Ssum=sum;
	if(n<=1000){
		for(int i=1;i<=n;i++){
			int maxx=1e16,p;
			for(int j=1;j<=n;j++){
				if(!vis[j]){
					if(maxx>(sum-a[j].n0)*(a[j].x.size()-a[j].n0))
					    maxx=(sum-a[j].n0)*(a[j].x.size()-a[j].n0),p=j;
				}
			}
			ans1+=maxx+a[p].ans;
			vis[p]=1;
			sum-=a[p].n0;
//			cout<<p<<" "<<ans1<<endl;
		}
	}
	sum=Ssum;
	for(int i=1;i<=n;i++){
		ans+=(sum-a[i].n0)*(a[i].x.size()-a[i].n0)+a[i].ans;
		sum-=a[i].n0;
	}
	cout<<min(ans1,ans);
	return 0;
}
