#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,m,k;
int gg[2000005],fa[2000005],dep[2000005];
int xz[2000005],yz[2000005],siz[2000005];
int top[2000005],son[2000005];
vector<int>q[2000005];
void dfS(int x,int far){
	fa[x]=far;
	dep[x]=dep[far]+1;
	siz[x]=1;
	for(auto y:q[x]){
		if(y==far) continue;
		dfS(y,x);
		siz[x]+=siz[y];
		if(siz[y]>siz[son[x]]){
			son[x]=y;
		}
	}
}
void dfS2(int x,int y){
	top[x]=y;
	if(son[x])
		dfS2(son[x],y);
	for(auto v:q[x]){
		if(v==fa[x]) continue;
		dfS2(v,v);
	}
}
int lca(int x,int y){
	while(top[x]!=top[y]){
		if(dep[x]>dep[y]) swap(x,y);
		y=fa[top[y]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}
int ans;
bool check(int x,int a[]){
	for(int i=1;i<=k;i++){
		int u=xz[gg[i]],v=yz[gg[i]];
		int Lca=lca(u,v);
		if(dep[Lca]>dep[x]) return 0;
		if(lca(u,x)!=x&&lca(v,x)!=x) return 0;
	}
	return 1;
}
void dfs(int x,int v){
	if(m-x+1+v<k) return;
	if(v==k){
		int minx=1e16,p;
		for(int i=1;i<=k;i++){	
			int lcac=lca(xz[gg[i]],yz[gg[i]]);
			if(dep[xz[gg[i]]]+yz[gg[i]]-2*dep[lcac]<minx){
				minx=dep[xz[gg[i]]]+yz[gg[i]]-2*dep[lcac];
				p=i;
			}
		}
		int a=xz[gg[p]],b=yz[gg[p]];
		if(check(a,gg)||check(b,gg)){
			ans++;
			return;
		}
		while(a!=b){
			if(dep[a]>dep[b]) swap(a,b);
			b=fa[b];
			if(check(b,gg)){
			ans++;
			return;
			}
		}
		return;
	}
	gg[v+1]=x;
	dfs(x+1,v+1);
	gg[v+1]=0;
	dfs(x+1,v);
}
signed main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		q[u].pb(v);
		q[v].pb(u);
	}
	for(int i=1;i<=m;i++){
		xz[i]=read();yz[i]=read();
	}
	dfS(1,0);
	dfS2(1,0); 
//	for(int i=1;i<=n;i++) f[i][0]=fa[i];
//	for(int k=1;k<=20;k++){
//		for(int i=1;i<=n;i++){
//			f[i][k]=f[f[i][k-1]][k-1];
//		}
//	}
	if(m<=20){
		dfs(1,0);
		cout<<ans;
		return 0;
	}
	cout<<0; 
	return 0;
}
