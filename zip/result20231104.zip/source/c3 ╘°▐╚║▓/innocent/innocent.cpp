#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,m,sum;
int u[100005],v[10005],w[100005];
int dp[100005][3]; 
int dis[1005][1005][2];
int ds[1005][1005];
bool flag[1005];
signed main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	n=read();m=read();
	memset(dis,0x3f,sizeof(dis));
	for(int i=1;i<=m;i++){
		u[i]=read(),v[i]=read(),w[i]=read();
		dis[u[i]+1][v[i]+1][(w[i]%2+2)%2]=w[i];
		ds[u[i]+1][v[i]+1]=w[i];
		if(w[i]<0) sum+=w[i];
	}
	FOR(i,1,n) dis[i][i][0]=0,ds[i][i]=0;
	for(int t=1;t<=10;t++)
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				dis[i][j][0]=min(dis[i][j][0],dis[i][k][0]+dis[k][j][0]);
				dis[i][j][1]=min(dis[i][j][1],dis[i][k][0]+dis[k][j][1]);
				dis[i][j][1]=min(dis[i][j][1],dis[i][k][1]+dis[k][j][0]);
				dis[i][j][0]=min(dis[i][j][0],dis[i][k][1]+dis[k][j][1]);
				ds[i][j]=min(ds[i][j],ds[i][k]+ds[k][j]);
			}
		}
	}
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(ds[i][j]>ds[i][k]+ds[k][j]) flag[k]=1;
			}
		}
	}
	for(int i=1;i<=n;i++){
		int ans=1e16;
//		dfs()
		for(int j=1;j<=n;j++){
			if(i==j) continue;
//			if(flag[j]&&(ds[i][j]<dis[0][2][1]&&ds[j][i]<dis[0][2][1])){
//				bk=1;
//			}
//			for(int k=1;k<=n;k++){
//				if(dis[i][j][1]+dis[i][j][0]>dis[i][k][0]+dis[k][j][1]+dis[j][k][1]+dis[k][i][1]) bk=1;
//				if(dis[i][j][0]+dis[i][j][1]>dis[i][k][1]+dis[k][j][0]+dis[j][k][1]+dis[k][i][1]) bk=1;
//			}
			ans=min(ans,dis[i][j][0]+dis[j][i][1]);
			ans=min(ans,dis[i][j][1]+dis[j][i][0]);
		}
		ans=min(ans,dis[i][i][1]);
		if(ans<sum||dis[i][i][1]<0) cout<<"Twinkle"<<endl;
		else if(ans>=1e16) cout<<"a-w-r-y"<<endl;
		else cout<<ans<<endl;
	}
	return 0;
}
