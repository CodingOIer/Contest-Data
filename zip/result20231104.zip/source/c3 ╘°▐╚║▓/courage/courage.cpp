#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,k;
signed main(){
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	n=read();
	cout<<0<<" "<<0; 
	return 0;
}
