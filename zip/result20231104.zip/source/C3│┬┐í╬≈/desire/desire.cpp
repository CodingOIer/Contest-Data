#include<bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
#define mid (l+r>>1) 
#define fi first
#define sd second
using namespace std;
const int N=1e5+5,mod=1e9+7;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
bool SSS;
int n,m,k;
pair<int,int> Way[N];
int head[N],nxt[N<<1],to[N<<1],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}

int dep[N],fa[N],son[N],siz[N],top[N],id[N],p[N],idx;
void dfs1(int u,int f){
	fa[u]=f;
	dep[u]=dep[f]+1;
	siz[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==f) continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]]) son[u]=v;
	}
	return;
}
void dfs2(int u,int tp){
	top[u]=tp;
	id[u]=++idx;
	p[idx]=u;
	if(!son[u]) return;
	dfs2(son[u],tp);
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return;
}

int maxn[N<<3],lazy[N<<3];
int Max(int a,int b){return a>b?a:b;}
void down(int x,int l,int r,int k){
	maxn[x]+=k;
	lazy[x]+=k;
}
void pushdown(int x,int l,int r){
	if(!lazy[x]) return;
	down(ls,l,mid,lazy[x]);
	down(rs,mid+1,r,lazy[x]);
	lazy[x]=0;
}
void pushup(int x){
	maxn[x]=Max(maxn[ls],maxn[rs]);
}
void update(int x,int l,int r,int L,int R,int k){
	if(l>=L&&r<=R){
		down(x,l,r,k);
		return;
	}
	if(l>R||r<L) return;
	pushdown(x,l,r);
	update(ls,l,mid,L,R,k);
	update(rs,mid+1,r,L,R,k);
	pushup(x);
}
int query(int x,int l,int r,int L,int R){
	if(l>=L&&r<=R) return maxn[x];
	if(l>R||r<L) return 0;
	pushdown(x,l,r);
	return Max(query(ls,l,mid,L,R),query(rs,mid+1,r,L,R));
}

void update_way(int x,int y,int k){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		update(1,1,n,id[top[x]],id[x],k);
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	update(1,1,n,id[y],id[x],k);
	return;
}
int query_way(int x,int y){
	int res=0;
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		res=Max(res,query(1,1,n,id[top[x]],id[x]));
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	res=Max(res,query(1,1,n,id[y],id[x]));
	return res;
}

pair<int,int> s[N];
int tp,ans;
bool vis[N];
void solve(int pos,int cs){
	if(pos==m+1){
		if(cs) return;
		for(int i=1;i<=k;i++){
			int u=s[i].fi,v=s[i].sd;
			update_way(u,v,1);
		}
		int res=query(1,1,n,1,n);
		if(res==k) ans++;		
		for(int i=1;i<=k;i++){
			int u=s[i].fi,v=s[i].sd;
			update_way(u,v,-1);
		}		
		return;
	}
	if(cs) s[++tp]=Way[pos],solve(pos+1,cs-1),tp--;
	solve(pos+1,cs);
	return;
}

vector<int> flen[25];
void ex_update_way(int x,int y,int ID){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		for(int i=id[top[x]];i<=id[x];i++) flen[p[i]].emplace_back(ID); 
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=id[y];i<=id[x];i++) flen[p[i]].emplace_back(ID); 
	return;
}

int inv[N],fac[N];
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=(res*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return res;
}
void pre(){
	fac[0]=inv[0]=1;
	for(int i=1;i<=100001;i++) fac[i]=(fac[i-1]*i)%mod;
	inv[100001]=ksm(fac[100001],mod-2);
	for(int i=100000;i>=1;i--) inv[i]=(inv[i+1]*(i+1))%mod;
} 
int C(int n,int m){
	if(n<m) return 0;
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
int lb(int x){return x&(-x);}
int cot(int x){
	int res=0;
	while(x) res++,x-=lb(x);
	return res;
}
bitset<N> base[25],Ans,LLL;
bool TTT;
signed main(){
//	cerr<<(&SSS-&TTT)/1024/1024<<"Mib\n";
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		Way[i]={u,v};
	}
	dfs1(1,0);
	dfs2(1,1);
	
	if(m<=16&&k<=16){
		solve(1,k);
		printf("%lld",ans%mod);	
	}
	else{
		for(int i=1;i<=m;i++){
			int u=Way[i].fi,v=Way[i].sd;
			ex_update_way(u,v,i);
		}
		pre();
		for(int i=1;i<=n;i++){
			ans=(ans+C(flen[i].size(),k))%mod;	
			for(int j=0;j<flen[i].size();j++){
				int ID=flen[i][j];
				base[i][ID]=1;
			}
		} 
		for(int i=0;i<(1<<n);i++){
			if(i-lb(i)==0) continue;
			Ans&=LLL;
			bool act=0;
			int x=i,id=0;
			while(x){
				id++;
				if(x&1){
					if(!act) Ans=base[id],act=1;
					else Ans&=base[id];
				}
				x>>=1;
			}
			int cnt=Ans.count();
			if(cot(i)&1) ans=(ans+C(cnt,k)+mod)%mod;
			else ans=(ans-C(cnt,k)+mod)%mod;
		}
		printf("%lld\n",ans%mod);
	}
	return 0;
}
