#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
struct Node{
	int s0,s1;
}a[N];
bool cmp(Node a,Node b){
	return a.s0*b.s1>a.s1*b.s0;
}
int n,ans,sum1;
string s;
signed main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		cin>>s;
		for(int j=0;j<s.size();j++){
			if(s[j]=='0'){
				ans=ans+a[i].s1;
				a[i].s0++;
			}
			else a[i].s1++;
		}
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		ans=ans+sum1*a[i].s0;
		sum1+=a[i].s1;
	}
	printf("%lld",ans);
	return 0;
}
