#include<bits/stdc++.h>
#define int long long
#define fi first
#define sd second
using namespace std;
const int N=1e5+5,mod=998244353;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n;
int head[N],nxt[N<<1],to[N<<1],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}

int dep[N],fa[N],son[N],siz[N],top[N];
void dfs1(int u,int f){
	fa[u]=f;
	dep[u]=dep[f]+1;
	siz[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==f) continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]]) son[u]=v;
	}
	return;
}
void dfs2(int u,int tp){
	top[u]=tp;
	if(!son[u]) return;
	dfs2(son[u],tp);
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
	return;
}
int LCA(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}

pair<int,int> s[N];
int tp,ans1,ans2;
bool vis[N];
void solve(int pos){
	if(pos==n+1){
		ans1++;
//		cout<<"Sol:\n";
//		for(int i=1;i<=n/2;i++) cout<<s[i].fi<<" "<<s[i].sd<<"\n";	
		for(int i=1;i<=n/2;i++){
			for(int j=1;j<=n/2;j++){
				if(i==j) continue;
				int a=s[i].fi,b=s[i].sd;
				int c=s[j].fi,d=s[j].sd;
				if(LCA(a,b)==a&&LCA(a,c)==a&&LCA(a,d)==a&&LCA(c,b)==c&&LCA(c,d)==c&&LCA(b,d)==b) ans2++;
			}
		}
		return;
	}
	if(vis[pos]) solve(pos+1);
	else{
		for(int i=pos+1;i<=n;i++){
			if(vis[i]) continue;
			int ls=LCA(pos,i);
			if(ls==pos){
				s[++tp]={pos,i};
				vis[pos]=vis[i]=1;
				solve(pos+1);
				vis[pos]=vis[i]=0;
				tp--;
			}
			else if(ls==i){
				s[++tp]={i,pos};
				vis[pos]=vis[i]=1;
				solve(pos+1);
				vis[pos]=vis[i]=0;
				tp--;				
			}
		}
	}
	return;
}
signed main(){
//	cerr<<(&SSS-&TTT)/1024/1024<<"Mib\n";
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	n=read();
	int cnt=0;
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		add(u,v);
		add(v,u);
		if(u==1||v==1) cnt++; 
	}
	if(n&1||cnt==n-1){
		printf("0 0");
		return 0;
	}
	if(n<=10){
		dfs1(1,0);
		dfs2(1,1);
		solve(1);
		printf("%lld %lld",ans1%mod,ans2%mod);		
	}
	return 0;
}
