#include<bits/stdc++.h>
#define mid ((l + r) >> 1)
#define lson (x << 1)
#define rson ((x << 1) | 1)
#define int long long
using namespace std;
const int maxn = 2000000, Maxn = 4000010;
const int mod = 1000000007;
int n, m, k, ans;
struct Tree{
	int to, nxt;
}tree[Maxn];
int head[Maxn], tot;
void add(int x, int y){
	tree[++tot] = {y, head[x]};
	head[x] = tot;
}
int dfn[Maxn], cnt;
int fa[Maxn], siz[Maxn], dep[Maxn], son[Maxn], top[Maxn];
int sum[Maxn << 2], tag[Maxn << 2];
void pushdown(int x, int l, int r){
	tag[lson] += tag[x];
	tag[rson] += tag[x];
	sum[lson] += tag[x] * (mid - l + 1);
	sum[rson] += tag[x] * (r - mid);
	tag[x] = 0;
}
void update(int x, int l, int r, int L, int R, int y){
	if(l >= L && r <= R){
		sum[x] += y * (r - l + 1);
		tag[x] += y;
		return ;
	}
	pushdown(x, l, r);
	if(mid >= L) update(lson, l, mid, L, R, y);
	if(mid + 1 <= R) update(rson, mid + 1, r, L, R, y);
	sum[x] = sum[lson] + sum[rson];
}
void dfs1(int x){
	dfn[x] = ++cnt;
	dep[x] = dep[fa[x]] + 1;
	siz[x] = 1;
	for(int i = head[x] ; i ; i = tree[i].nxt){
		int to = tree[i].to;
		if(to == fa[x]) continue;
		fa[to] = x;
		dfs1(to);
		siz[x] = (siz[x] + siz[to]) % mod;
		if(!son[x] || siz[son[x]] < siz[to]) son[x] = to;
	}
}
void dfs2(int x, int tp){
	top[x] = tp;
	if(!son[x]) return;
	dfs2(son[x], tp);
	for(int i = head[x] ; i ; i = tree[i].nxt){
		int to = tree[i].to;
		if(to == fa[x] || to == son[x]) continue;
		dfs2(to, to);
	}
}
int Lca(int x, int y){
	while(top[x] != top[y]){
//		cout << x << " " << y << " " << top[x] << " " << top[y] << '\n';
		if(dep[top[x]] < dep[top[y]]) swap(x, y);
		update(1, 1, n, dfn[top[x]], dfn[x], 1);
		x = fa[top[x]];
	}
//	cout << x << " " << y << '\n' << '\n';
	if(dep[x] > dep[y]) swap(x, y);
	update(1, 1, n, dfn[x], dfn[y], 1);
	return x;
}
int fac[maxn + 10], inv[maxn + 10];
int ksm(int x, int y){
	int ans = 1;
	while(y){
		if(y & 1) ans = ans * x % mod;
		x = x * x % mod;
		y >>= 1;
	}
	return ans;
}
void Pre(){
	inv[0] = fac[0] = 1;
	for(int i = 1 ; i <= maxn ; i++) fac[i] = fac[i - 1] * i % mod;
	inv[maxn] = ksm(fac[maxn], mod - 2);
	for(int i = maxn - 1 ; i ; i--) inv[i] = inv[i + 1] * (i + 1) % mod;
}
int C(int x, int y){
	if(x < y) return 0;
	return fac[x] * inv[y] % mod * inv[x - y] % mod;
}
int s[Maxn], cf[Maxn];
void dfs(int x){
//	cout <<":"<< x << " " << la << " " << cf[x] << " " << s[x] << " " << ans << " ";
//	la = (la + cf[x]) % mod;
//	cout <<'\n'<< s[x] <<" " <<la << " " << k << " "<<C(s[x] + la, k)<< " " << C(la, k) << '\n';
	ans = (ans + (C(sum[dfn[x]], k) - C(sum[dfn[x]] - s[x], k)) % mod + mod) % mod;
//	ans = (ans + C(s[x] + la, k) - C(la, k) + mod) % mod;
//	cout << la << " " << ans << '\n';
//	cout << x << " " << la << " " << ans << '\n';
	for(int i = head[x] ; i ; i = tree[i].nxt){
		int to = tree[i].to;
		if(to == fa[x]) continue;
		dfs(to);
	}
}
signed main() {
	ios::sync_with_stdio(false);
	freopen("desire.in", "r", stdin);
	freopen("desire.out", "w", stdout);
	Pre();
	cin >> n >> m >> k;
	for(int i = 1 ; i < n ; i++){
		int x, y;
		cin >> x >> y;
		add(x, y);
		add(y, x);
	}
	dfs1(1);
	dfs2(1, 1);
	for(int i = 1 ; i <= m ; i++){
		int x, y;
		cin >> x >> y;
		int lca = Lca(x, y);
//		cout << ":"<<lca << '\n';
		s[lca]++;
//		update(1, 1, n, dfn[lca], dfn[x], 1);
//		update(1, 1, n, dfn[lca], dfn[y], 1);
//		if(x == y) continue;
//		for(int j = head[lca] ; j ; j = tree[j].nxt){
//			int to = tree[j].to;
//			if(to == fa[lca]) continue;
//			if(Lca(to, x) == to || Lca(to, y) == to) cf[to]++;
//		}
//		if(x != lca){
//			for(int j = head[x] ; j ; j = tree[j].nxt){
//				int to = tree[j].to;
//				if(to == fa[x]) continue;
//				cf[to]--;
//			}
//		}
//		if(y != lca){
//			for(int j = head[y] ; j ; j = tree[j].nxt){
//				int to = tree[j].to;
//				if(to == fa[y]) continue;
//				cf[to]--;
//			}
//		}
	}
	dfs(1);
	cout << ans << '\n';
	return 0;
}
/*
5 5 2
2 1
3 2
4 2
5 3
3 4
3 3
2 3
5 2
3 4

5 3 2
1 2
2 3
3 4
4 5
1 3
2 4
3 5

10 6 3
1 2
1 3
1 10
2 4
2 5
3 6
3 7
6 8
6 9

2 10
4 5
5 6
6 7
10 7
8 9
*/
