#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 200010;
int n, ans, la, len;
string s[Maxn];
struct node{
	int x, y, id;
}a[Maxn];
bool cmp(node q, node p){
	return q.y * p.x < q.x * p.y;
}
signed main() {
	ios::sync_with_stdio(false);
	freopen("karma.in", "r", stdin);
	freopen("karma.out", "w", stdout);
	cin >> n;
	for(int i = 1 ; i <= n ; i++){
		cin >> s[i];
		len += s[i].size();
		a[i].id = i;
		for(int j = 0 ; j < s[i].size() ; j++){
			if(s[i][j] == '0') a[i].x++;
			else a[i].y++;
		}
	}
	if(len == n){
		cout << 0 << '\n';
		return 0;
	}
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1 ; i <= n ; i++){
		for(int j = 0 ; j < s[a[i].id].size() ; j++){
			if(s[a[i].id][j] == '0') ans += la;
			else la++;
		}
	}
	cout << ans << '\n';
	return 0;
}
