#include<bits/stdc++.h>
#define int long long
using namespace std;

signed main() {
	ios::sync_with_stdio(false);
	freopen("courage.in", "r", stdin);
	freopen("courage.out", "w", stdout);
	cout << 0 << " " << 0 << '\n';	
	return 0;
}
