#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=2e5+5,inf=1e18;
int n,res;
struct name{
    string s;
    int m,cnt;
    double val;
    bool operator <(const name &b){
        return cnt*(b.m-b.cnt)>b.cnt*(m-cnt);
        // return val<b.val;
    }
}a[N];
string ans;
signed main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i].s;
        a[i].m=a[i].s.size();
        for(int j=0;j<a[i].m;j++) a[i].cnt+=a[i].s[j]=='0';
        // if(a[i].cnt==0) a[i].val=inf;
        // else a[i].val=1.0*(a[i].m-a[i].cnt)/a[i].cnt;
    }
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++) ans+=a[i].s;
    int m=ans.size();
    ans=' '+ans;
    for(int i=1,cnt=0;i<=m;i++){
        if(ans[i]=='1') cnt++;
        else res+=cnt;
    }
    // cout<<ans<<"\n";
    cout<<res;
    return 0;
}