#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2e6+5,K=20,mod=1e9+7;
int n,m,k,d[N],fa[N][K+1],c[N],ans,c2[N],jc[N],ijc[N];
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=1ll*ans*x%mod;
        x=1ll*x*x%mod;
        base>>=1;
    }
    return ans;
}
vector<int> g[N];
void dfs(int x){
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        fa[y][0]=x;
        d[y]=d[x]+1;
        dfs(y);
    }
}
int lca(int x,int y){
    if(d[x]<d[y]) swap(x,y);
    for(int i=K-1;~i;i--)
        if(d[fa[x][i]]>=d[y]) x=fa[x][i];
    if(x==y) return x;
    for(int i=K-1;~i;i--)
        if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
// vector<int> s;
int bj=0;
void dfs2(int x){
    // cout<<x<<" "<<fa[x][0]<<"\n";
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        dfs2(y);
        c[x]+=c[y],c2[x]+=c2[y];
    }
    if(c[x]>=k) bj=1;
}
int check(){
    bj=0;
    dfs2(1);
    return bj;
}
void init(){
    for(int i=1;i<K;i++)
        for(int j=1;j<=n;j++){
            fa[j][i]=fa[fa[j][i-1]][i-1];
        }
}
int C(int n,int m){
    if(n>m||n<0||m<0) return 0;
    return 1ll*jc[m]*ijc[n]%mod*ijc[m-n]%mod;
}
void intt(int n){
    jc[0]=1;
    for(int i=1;i<=n;i++) jc[i]=1ll*jc[i-1]*i%mod;
    ijc[n]=pow(jc[n],mod-2);
    for(int i=n-1;~i;i--) ijc[i]=1ll*ijc[i+1]*(i+1)%mod;
}
signed main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    n=read(),m=read(),k=read();
    intt(N-5);
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1);
    init();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        int l=lca(x,y);
        c[x]++;
        c[y]++;
        c[l]--;
        c[fa[l][0]]--;

        c2[x]++;
        c2[y]++;
        c2[l]-=2;
    }
    dfs2(1);
    for(int i=1;i<=n;i++){
        // cout<<i<<" "<<c[i]<<" "<<c2[i]<<"\n";
        ans=(ans+C(k,c[i])-C(k,c2[i])+mod)%mod;
    }
    cout<<ans;
    return 0;
}