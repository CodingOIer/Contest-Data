#include <bits/stdc++.h>
using namespace std;
// char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2e6+5,K=26;
int n,m,k,d[N],fa[N][K+5],c[N],ans;
vector<int> g[N];
struct ee{
    int x,y;
}a[N];
void dfs(int x){
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        fa[y][0]=x;
        d[y]=d[x]+1;
        dfs(y);
    }
}
int lca(int x,int y){
    if(d[x]<d[y]) swap(x,y);
    for(int i=K-1;~i;i--)
        if(d[fa[x][i]]>=d[y]) x=fa[x][i];
    if(x==y) return x;
    for(int i=K-1;~i;i--)
        if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
vector<int> s;
int bj=0;
void dfs2(int x){
    // cout<<x<<" "<<fa[x][0]<<"\n";
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        dfs2(y);
        c[x]+=c[y];
    }
    if(c[x]>=k) bj=1;
}
int check(){
    bj=0;
    dfs2(1);
    return bj;
}
void init(){
    for(int i=1;i<K;i++)
        for(int j=1;j<=n;j++){
            fa[j][i]=fa[fa[j][i-1]][i-1];
        }
}
int main(){
    n=read(),m=read(),k=read();
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=m;i++){
        a[i].x=read(),a[i].y=read();
    }
    dfs(1);
    init();
    for(int i=0;i<(1<<m);i++){
        s.clear();
        for(int j=1;j<=m;j++)
            if((1<<(j-1))&i) s.push_back(j);
        int cc=s.size();
        if(cc==k){
            memset(c,0,sizeof(c));
            for(auto x:s){
                c[a[x].x]++;
                c[a[x].y]++;
                int l=lca(a[x].x,a[x].y);
                c[l]--;
                c[fa[l][0]]--;
            }
            ans+=check();
        }
    }
    cout<<ans;
    return 0;
}