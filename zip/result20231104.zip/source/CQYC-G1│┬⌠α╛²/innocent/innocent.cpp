#include <bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=105,inf=1e18;
int n,m,f[N][N][2][3];
struct name{
    int to,v;
};
signed main(){
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            for(int kk=0;kk<3;kk++) f[i][j][0][kk]=f[i][j][1][kk]=inf;
    for(int i=1;i<=m;i++){
        int x=read()+1,y=read()+1,z=read();
        f[x][y][abs(z)&1][0]=z;
    }
    for(int kk=0;kk<3;kk++){
        for(int k=1;k<=n;k++){
            for(int i=1;i<=n;i++){
                for(int j=1;j<=n;j++){
                    for(int l=0;l<=1;l++){
                        for(int l1=0;l1<=1;l1++){
                            // if(i==1&&j==1&&k==2&&kk==1) cout<<f[i][k][l][kk]+f[k][j][l1][kk]<<"\n";
                            f[i][j][l^l1][kk]=min(f[i][j][l^l1][kk],f[i][k][l][kk]+f[k][j][l1][kk]);
                        }
                    }
                }
            }
        }
        if(kk!=2)
            for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++) f[i][j][0][kk+1]=f[i][j][0][kk],f[i][j][1][kk+1]=f[i][j][1][kk];
    }
    // cout<<f[1][2][0][0]<<" "<<f[2][1][1][0]<<" "<<f[1][1][1][1]<<"\n";
    // return 0;
    for(int i=1;i<=n;i++){
        if(f[i][i][1][1]>=1e15) cout<<"a-w-r-y\n";
        else if(f[i][i][1][2]<f[i][i][1][1]) cout<<"Twinkle\n";
        else cout<<f[i][i][1][1]<<"\n";
    }
    return 0;
}