#include <bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2005,mod=998244353;
int n,fa[N],sz[N],f[2][N][N];
vector<int> g[N];
int dp[N][N]; // i为根子树下面有j个空的方案
void dfs(int x){
    sz[x]=1;
    for(auto y:g[x]){
        if(y==fa[x]) continue;
        fa[y]=x;
        dfs(y);
        sz[x]+=sz[y];
    }
}
void get_dp(int x){
    if(sz[x]==1) dp[x][1]=1;
    int bj=0;
    int now=0;
    for(auto y:g[x]){
        if(y==fa[x]) continue;
        get_dp(y);
        if(!bj){
            bj=1;
            for(int i=0;i<=sz[y];i++) f[now^1][x][i]=dp[y][i];
            now^=1;
            continue;
        }
        memset(f[now^1][x],0,sizeof(f[now^1][x]));
        for(int i=0;i<=sz[y];i++){
            for(int j=sz[x];~j;j--){
                f[now^1][x][i+j]=(f[now^1][x][i+j]+f[now][x][j]*dp[y][i]%mod)%mod;
            }
        }
        now^=1;
    }
    // cout<<x<<"!\n";
    // for(int i=0;i<=sz[x];i++) cout<<f[now][x][i]<<" ";
    // cout<<"\n";
    for(int i=0;i<=sz[x];i++){
        dp[x][i+1]=(f[now][x][i]+dp[x][i+1])%mod;
        if(i) dp[x][i-1]=(f[now][x][i]*i%mod+dp[x][i-1])%mod;
    }
}
namespace p60{ // 写不完了
}
signed main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    n=read();
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    dfs(1);
    get_dp(1);
    cout<<dp[1][0]<<" "<<0<<"\n";
    return 0;
}