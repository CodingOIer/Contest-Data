#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2005;
int n,fa[N];
vector<int> g[N],s[N];
void dfs(int x){
    for(auto y:g[x]){
        if(y==fa[x]) continue;
        fa[y]=x;
        dfs(y);
        s[x].push_back(y);
        for(auto i:s[y]) s[x].push_back(i);
    }
}
int main(){
    n=read();
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    return 0;
}