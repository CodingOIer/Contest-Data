#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=110,M=1e4+10;
const ll inf=1e18;
int n,m;
int first[N],to[M],nxt[M],lth[M],cnt;
ll dis[N][N][2];
inline void Min(ll &x,ll y) {x=x>y?y:x;}
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
int main()
{
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1,u,v,w;i<=m;i++)
        scanf("%d%d%d",&u,&v,&w),inc(u+1,v+1,w);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            for(int k=1;k<=n;k++)
                dis[j][k][0]=dis[j][k][1]=inf;
        for(int j=1;j<=n;j++) dis[j][j][0]=0;
        for(int j=1;j<=n;j++)
            for(int k=first[j];k;k=nxt[k]) Min(dis[j][to[k]][abs(lth[k])&1],lth[k]);
        ll check;
        for(int j=1;j<=n;j++)
            for(int k=1;k<=n;k++)
                for(int p=1;p<=n;p++)
                    for(int h=0;h<2;h++)
                        for(int g=0;g<2;g++)
                            if(dis[k][j][h]<inf&&dis[j][p][g]<inf)
                                Min(dis[k][p][(h+g)&1],dis[k][j][h]+dis[j][p][g]);
        if(dis[i][i][1]==inf) {puts("a-w-r-y");continue;}
        check=dis[i][i][1];
        for(int j=1;j<=n;j++)
            for(int k=1;k<=n;k++)
                for(int p=1;p<=n;p++)
                    for(int h=0;h<2;h++)
                        for(int g=0;g<2;g++)
                            Min(dis[k][p][(h+g)&1],dis[k][j][h]+dis[j][p][g]);
        if(dis[i][i][1]!=check) puts("Twinkle");
        else printf("%lld\n",check);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
