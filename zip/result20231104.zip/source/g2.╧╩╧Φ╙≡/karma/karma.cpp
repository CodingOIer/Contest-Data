#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e5+10,M=1<<19;
int n,b[N],c[N],S[M];
string a[N];
ll tot,dp[M];
inline void Min(ll &x,ll y) {x=x>y?y:x;}
int main()
{
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    scanf("%d",&n);
    int sum=0;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        int m=a[i].size();
        sum+=m;
        for(int j=0;j<m;j++)
            if(a[i][j]=='0') tot+=c[i],++b[i];
            else ++c[i];
    }
    if(n==sum) return puts("0"),0;
    if(n==1) return printf("%lld\n",tot),0;
    memset(dp,0x3f,sizeof(dp));
    dp[0]=0;
    int P=(1<<n)-1;
    for(int i=1;i<=P;i++)
        for(int j=0;j<n;j++)
            if(i>>j&1) Min(dp[i],dp[1<<j^i]+1ll*S[1<<j^i]*b[j]),S[i]+=c[j];
    printf("%lld\n",dp[P]+tot);
    fclose(stdin);fclose(stdout);
    return 0;
}
