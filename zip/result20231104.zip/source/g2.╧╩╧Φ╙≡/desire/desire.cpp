#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=2e6+10,M=N<<1,K=N<<2,mod=1e9+7;
bool Begin;
int n,m,k,ans,tx[N],ty[N];
int fa[N],ID[N],dfn[N],dep[N],son[N],num[N],top[N];
int Mx[K],tag[K];
int first[N],to[M],nxt[M],cnt;
bool End;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
void dfs1(int x,int fr)
{
    fa[x]=fr;num[x]=1;
    dep[x]=dep[fr]+1;
    for(int i=first[x],v;i;i=nxt[i])
    {
        if((v=to[i])==fr) continue;
        dfs1(v,x);num[x]+=num[v];
        if(num[son[x]]<num[v]) son[x]=v;
    }
}
void dfs2(int x,int t)
{
    top[x]=t;
    ID[dfn[x]=++cnt]=x;
    if(!son[x]) return;
    dfs2(son[x],t);
    for(int i=first[x],v;i;i=nxt[i])
        if((v=to[i])!=fa[x]&&v!=son[x]) dfs2(v,v);
}
inline void Add(int id,int k) {Mx[id]+=k,tag[id]+=k;}
inline void push_up(int id) {Mx[id]=max(Mx[lt],Mx[rt]);}
inline void push_down(int id)
{
    if(!tag[id]) return;
    Add(lt,tag[id]),Add(rt,tag[id]);
    tag[id]=0;
}
void add(int id,int l,int r,int L,int R,int k)
{
    if(l>R||r<L) return;
    if(L<=l&&r<=R) return Add(id,k);
    push_down(id);
    int mid=(l+r)>>1;
    add(lt,l,mid,L,R,k);
    add(rt,mid+1,r,L,R,k);
    push_up(id);
}
void Inc(int x,int y,int k)
{
    while(top[x]!=top[y])
    {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        add(1,1,n,dfn[top[x]],dfn[x],k);
        x=fa[top[x]];
    }
    if(dep[x]<dep[y]) swap(x,y);
    add(1,1,n,dfn[y],dfn[x],k);
}
void dfs(int x,int rest)
{
    if(!rest)
        return ans+=(Mx[1]==k),void();
    if(x>m) return;
    Inc(tx[x],ty[x],1);dfs(x+1,rest-1);
    Inc(tx[x],ty[x],-1);dfs(x+1,rest);
}
int main()
{
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    cerr<<(&Begin-&End)/1024/1024<<"MB\n";
    n=read(),m=read(),k=read();
    for(int i=1,u,v;i<n;i++)
        u=read(),v=read(),inc(u,v),inc(v,u);
    dfs1(1,0);cnt=0;dfs2(1,1);
    for(int i=1;i<=m;i++)
        tx[i]=read(),ty[i]=read();
    dfs(1,k);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
