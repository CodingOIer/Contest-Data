#include<bits/stdc++.h>
using namespace std;
const int N=2010,M=N<<1,mod=998244353;
int n,in[N],num[N],cpy[N],c[N][N],f[N][N],dp[N][N];
int stk[N];
int first[N],to[M],nxt[M],cnt;
bool subtask=1;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
inline int add(int x,int y) {upd(x,y);return x;}
void pre()
{
    for(int i=0;i<N;i++)
    {
        c[i][0]=1;
        for(int j=1;j<=i;j++) c[i][j]=add(c[i-1][j],c[i-1][j-1]);
    }
}
void dfs1(int x,int fr)
{
    f[x][0]=1;
    stk[++cnt]=x;
    for(int i=first[x],v;i;i=nxt[i])
    {
        if((v=to[i])==fr) continue;
        dfs1(v,x);
        for(int j=0;j<=num[x];j++)
            cpy[j]=f[x][j],f[x][j]=0;
        for(int j=num[v];~j;j--)
            for(int k=num[x];~k;k--) upd(f[x][j+k],1ll*dp[v][j]*cpy[k]%mod);
        num[x]+=num[v];
    }
    ++num[x];
    for(int i=0;i<num[x];i++) upd(dp[x][i+1],f[x][i]);
    for(int i=1;i<num[x];i++) upd(dp[x][i-1],1ll*i*f[x][i]%mod);
}
int main()
{
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    pre();
    scanf("%d",&n);
    if(n&1) return puts("0 0"),0;
    for(int i=1,u,v;i<n;i++)
        scanf("%d%d",&u,&v),inc(u,v),inc(v,u),++in[u],++in[v];
    for(int i=1;i<=n;i++)
        if(in[i]>2) subtask=0;
    cnt=0;dfs1(1,0);
    printf("%d ",dp[1][0]);
    if(subtask)
        printf("%d\n",1ll*c[n][4]*dp[stk[5]][0]%mod);
    else puts("0");
    fclose(stdin);fclose(stdout);
    return 0;
}
