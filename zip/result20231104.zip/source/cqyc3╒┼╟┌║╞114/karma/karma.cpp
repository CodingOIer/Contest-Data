#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=2e5+7,inf=1e9;
struct node{
	string s;
	ll cnt0,len,id;
	double w;
}a[Maxn];
inline ll getans(string x){
	ll l=x.size();
	ll cnt1=0,res=0;
	for(ll i=0;i<l;i++){
		cnt1+=(x[i]=='1');
		if(x[i]=='0') res+=cnt1;
	}
	return res;
}
inline bool cmp(node x,node y){
	return x.cnt0*y.len>y.cnt0*x.len;
}
ll n,ans;
string all;

int main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		cin>>a[i].s;
		a[i].len=a[i].s.size();
		for(ll j=0;j<a[i].len;j++) a[i].cnt0+=(a[i].s[j]=='0');
		//cout<<a[i].s<<" "<<a[i].w<<endl;
	}
	sort(a+1,a+n+1,cmp);
	for(ll i=1;i<=n;i++) all+=a[i].s;
	printf("%lld",getans(all));
	//cout<<all<<endl;
	return 0;
}
/*
3
1
11
101

3
1010
111
101
*/


