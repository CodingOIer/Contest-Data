#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=2e6+7,Mod=1e9+7;
ll n,m,k,lca[Maxn];
vector<ll>e[Maxn];
vector<pair<ll,ll> >q[Maxn];

ll vok[Maxn],f[Maxn],aslca[Maxn];
ll Sum[Maxn],smu[Maxn];
ll fac[Maxn],Inv[Maxn],ans;

inline ll up(ll x){
	return (x%Mod+Mod)%Mod;
}

inline ll ksm(ll a,ll b,ll mod){
	ll z=1;
	while(b){
		if(b&1) z=z*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return z;
}

inline ll qfind(ll key){
	return key==f[key]?key:f[key]=qfind(f[key]);
}
inline void Merge(ll x,ll y){
	ll qx=qfind(x),qy=qfind(y);
	if(qx!=qy) f[qx]=qy;
}

void Tarjan(ll u,ll ft){
	vok[u]++;
	for(auto v:e[u])
		if(v!=ft){
			Tarjan(v,u);
			Merge(v,u);
		}
	for(auto i:q[u]){
		if(vok[i.first]==2&&!lca[i.second]){
			aslca[i.second]=qfind(i.first);
		}
	}
	vok[u]++;
}
void DFS(ll u,ll ft){
	Sum[u]=lca[u];
	for(auto v:e[u]){
		if(v!=ft){
			DFS(v,u);
			Sum[u]+=Sum[v];
			smu[u]+=smu[v];
		}
	}
}

inline ll C(ll x,ll y){
	if(y>x) return 0;
	return fac[x]*Inv[y]%Mod*Inv[x-y]%Mod;
}

void getans(ll u,ll ft){
	for(ll i=1;i<k;i++){
		ll x=smu[u]-2*Sum[u];
		//cout<<u<<" "<<x<<" "<<m-Sum[u]-x<<" "<<i<<" "<<lca[u]<<" "<<C(lca[u],i)<<' '<<C(m-Sum[u]-x,k-i)<<endl;
		ans=(ans+C(lca[u],i)*C(m-Sum[u]-x,k-i)%Mod)%Mod;
	}
		
	for(auto v:e[u])
		if(v!=ft)
			getans(v,u);	
}

void init(ll N){
	fac[0]=1;
	for(ll i=1;i<=N;i++) fac[i]=fac[i-1]*i%Mod;
	Inv[N]=ksm(fac[N],Mod-2,Mod);
	for(ll i=N-1;~i;i--) Inv[i]=Inv[i+1]*(i+1)%Mod;
}

int main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	init(Maxn-7);
	for(ll i=1;i<=n;i++) f[i]=i;
	for(ll i=1,u,v;i<n;i++){
		scanf("%lld%lld",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(ll i=1,u,v;i<=m;i++){
		scanf("%lld%lld",&u,&v);
		smu[u]++;smu[v]++;
		if(u==v){
			aslca[i]=u;
			continue;
		}
		q[u].push_back(make_pair(v,i));
		q[v].push_back(make_pair(u,i));
	}
	Tarjan(1,0);
	for(ll i=1;i<=m;i++) lca[aslca[i]]++;
	DFS(1,0);
	getans(1,0);
	//cout<<Sum[1]<<" "<<Sum[3]<<endl; 
	ans=up(C(m,k)-ans);
	printf("%lld",ans);
	return 0;
}
/*
5 5 2
2 1
3 2
4 2
5 3
3 4
3 3
2 3
5 2
3 4

20 15 7
2 1
3 2
4 3
5 4
6 5
7 6
8 7
9 8
10 9
11 1
12 9
13 5
14 1
15 7
16 3
17 7
18 9
19 2
20 9
3 5
18 13
17 1
5 9
7 8
1 13
9 8
20 14
2 9
12 4
1 14
16 3
1 15
6 6
13 9

*/


