#include<bits/stdc++.h>
#define int long long
#define N 2000005
using namespace std;
int n,m,k;
int tot,head[N],to[N],nxt[N];
int fa[N],dep[N],top[N],s[N];
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
signed main(){
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	for(int i=1,u,v;i<n;i++){
		scanf("%lld %lld",&u,&v);
		add(u,v);
		add(v,u);
	}
	cout<<0<<endl;
	return 0;
}


