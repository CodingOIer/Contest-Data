#include<bits/stdc++.h>
#define int long long
#define N 1005
#define M 10005
using namespace std;
int n,m;
int tot,head[N],nxt[M],to[M],val[M];
int d[N][2],vis[N][2],s[N][2],k[N][2];
queue<pair<int,int> > q;
void add(int u,int v,int w){
	nxt[++tot]=head[u];
	to[tot]=v;
	val[tot]=w;
	head[u]=tot;
}
void spfa(int o){
	while(!q.empty()) q.pop();
	for(int i=1;i<=n;i++){
		d[i][0]=d[i][1]=1e18;
		vis[i][0]=vis[i][1]=0;
		s[i][0]=s[i][1]=0;
		k[i][0]=k[i][1]=0;
	}
	for(int i=head[o];i;i=nxt[i]){
		d[to[i]][val[i]&1]=min(d[to[i]][val[i]&1],val[i]);
		if(!s[to[i]][val[i]&1]){
			s[to[i]][val[i]&1]=1;
			q.push({to[i],val[i]&1});
		}
	}
	while(!q.empty()){
		int x=q.front().first,y=q.front().second;
		q.pop();
		s[x][y]=0;
		vis[x][y]++;
		if(vis[x][y]>n*2||k[x][y]){
			k[x][y]=1;
			s[x][y]=1;
		}
		for(int i=head[x];i;i=nxt[i]){
			if(k[to[i]][(y+val[i])&1]) continue;
			if(d[x][y]+val[i]<d[to[i]][(y+val[i])&1]||k[x][y]){
				if(k[x][y]) k[to[i]][(y+val[i])&1]=k[x][y];
				d[to[i]][(y+val[i])&1]=d[x][y]+val[i];
				if(!s[to[i]][(y+val[i])&1]){
					s[to[i]][(y+val[i])&1]=1;
					q.push({to[i],(y+val[i])&1});
				}
			}
		}
	}
	if(k[o][1]) printf("Twinkle\n");
	else if(d[o][1]==1e18) printf("a-w-r-y\n");
	else printf("%lld\n",d[o][1]);
}
signed main(){
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1,u,v,w;i<=m;i++){
		scanf("%lld %lld %lld",&u,&v,&w);
		u++;v++;
		add(u,v,w);
	}
	for(int i=1;i<=n;i++) spfa(i);
	return 0;
}


