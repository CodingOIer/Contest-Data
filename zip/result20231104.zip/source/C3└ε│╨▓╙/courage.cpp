#include<bits/stdc++.h>
#define int long long
#define N 4005
using namespace std;
int n,m,k;
int tot,head[N],to[N],nxt[N];
int cnt,dfn[N],siz[N];
int a[N];
int vis[N];
int in[N];
int ans,sum;
const int mod=998244353;
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
void dfs(int x,int fa){
	siz[x]=1;
	dfn[x]=++cnt;
	for(int i=head[x];i;i=nxt[i]){
		if(to[i]==fa) continue;
		dfs(to[i],x);
		siz[x]+=siz[to[i]];
	}
}
void f(int x,int s){
	if(x>n){
		ans++;
		ans%=mod;
		sum+=s;
		sum%=mod;
		return;
	}
	if(vis[x]){
		for(int i=vis[x]+1;i<x;i++){
			if(a[i]&&x<a[i]&&a[i]<dfn[x]+siz[x]) s++;
		}
		f(x+1,s);
	}
	else for(int i=dfn[x]+1;i<dfn[x]+siz[x];i++){
		if(!vis[i]){
			a[x]=i;
			vis[i]=x;
			f(x+1,s);
			a[x]=0;
			vis[i]=0;
		}
	}
}
signed main(){
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1,u,v;i<n;i++){
		scanf("%lld %lld",&u,&v);
		add(u,v);
		add(v,u);
		in[u]++;
		in[v]++;
	}
	int z=0;
	for(int i=1;i<=n;i++){
		if(in[i]==1) z++; 
		if(in[i]==n-1){
			printf("%lld %lld",0,0);
			return 0;
		}
	}
	if(z==2){
		ans=1;
		for(int i=n-1;i>=1;i-=2) ans=ans*i%mod;
		printf("%lld %lld",ans,sum);
		return 0;
	}
	dfs(1,0);
	f(1,0);
	printf("%lld %lld",ans,sum);
	return 0;
}


