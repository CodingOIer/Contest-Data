#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int ans,sum;
bool vis[200005];
string s;
struct node{
	int a,b;
}t[200005];
bool cmp(node x,node y){
	return x.a*(y.a+y.b)>y.a*(x.a+x.b);
}
signed main(){
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		cin>>s;
		for(int j=0;j<s.size();j++){
			if(s[j]=='0') t[i].a++,ans+=t[i].b;
			else t[i].b++;
		}
	}
	sort(t+1,t+n+1,cmp);
	for(int i=1;i<=n;i++){
		ans+=t[i].a*sum;
		sum+=t[i].b;
	}
	printf("%lld",ans);
	return 0;
}


