#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2010,Mod=998244353;
int N,hed[Maxn],cnt,in[Maxn],Ans1,id[Maxn],Ans2;
int fa[Maxn],dfn[Maxn],Siz[Maxn],tot,top,dep[Maxn];
pair<int,int> Q[Maxn];
struct node{int nxt,to;}G[Maxn<<1];
bool f1,Vis[Maxn];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void Solve0(){
    if(N==2) puts("1 0");
    else puts("0 0");
    exit(0);
}

void Solve1(){
    int Ans=1;
    for(int i=N-1;i;i-=2) (Ans*=i)%=Mod;
    write(Ans),pc(' '),pc('0'),pc('\n');
}

void DFS(int x,int p){
    fa[x]=p,dfn[x]=++tot,Siz[x]=1,id[tot]=x,dep[x]=dep[p]+1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        DFS(y,x); Siz[x]+=Siz[y];
    }
}

bool Cs(int x,int y){
    return dfn[y]>=dfn[x]+1&&dfn[y]<=dfn[x]+Siz[x]-1;
}

void calc(int x){
    if(x>N){
        ++Ans1;
        For(i,1,top){
            int a=Q[i].first,b=Q[i].second;
            For(j,i+1,top){
                int c=Q[j].first,d=Q[j].second;
                if(dep[a]>dep[c]) swap(a,c),swap(b,d);
                if(Cs(a,c)&&Cs(c,b)&&Cs(b,d)) ++Ans2;
            }
        }
        return;
    }
    if(Vis[x]) calc(x+1);
    else{
        Vis[x]=1;
        For(i,dfn[x]+1,dfn[x]+Siz[x]-1) if(!Vis[id[i]]){
            int c=id[i];
            Vis[c]=1,Q[++top]=mp(x,c);
            calc(x+1);
            Vis[c]=0,--top;
        }
        Vis[x]=0;
    }
}

signed main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    N=read();
    For(i,1,N-1){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
        if(u!=1&&v!=1) f1=1;
        ++in[u],++in[v];
    }
    if(N&1) puts("0 0"),exit(0);
    if(!f1) Solve0();
    int t1=0,t2=0;
    For(i,1,N) if(in[i]!=2) in[i]==1?++t1:++t2;
    if(!t2&&t1==2) Solve1();
    DFS(1,0); calc(1);
    write(Ans1),pc(' '),write(Ans2),pc('\n');
    return 0;
}
/*
g++ courage.cpp -o courage -O2
./courage
*/