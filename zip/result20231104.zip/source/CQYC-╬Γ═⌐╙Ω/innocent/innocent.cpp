#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e4+10,INF=1e9;
int N,M,hed[Maxn],cnt,Ans=INF;
struct node{int nxt,to,w;}G[Maxn<<1];
bool f,Vis[5010][5010];

void Addedge(int x,int y,int z){G[++cnt]=(node){hed[x],y,z}; hed[x]=cnt;}

void DFS(int x,int p,int v,int t){
    if(v>Ans)  return;
    if(v<=-INF) return f=1,void();
    if(x==t&&(v&1)) Ans=min(Ans,v);
    for(int y,i=hed[x];i;i=G[i].nxt){
        DFS(G[i].to,x,v+G[i].w,t);
        if(f) return;
    }
}

void calc(int x){
    f=0,Ans=INF; DFS(x,0,0,x);
    if(f) puts("Twinkle");
    else{
        if(Ans==INF) puts("a-w-r-y");
        else write(Ans),pc('\n');
    }
}

signed main(){
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    N=read(),M=read();
    For(i,1,M){
        int u=read()+1,v=read()+1,w=read();
        Addedge(u,v,w);
    }
    For(i,1,N) calc(i);
    return 0;
}
/*
g++ innocent.cpp -o innocent -O2
./innocent
*/