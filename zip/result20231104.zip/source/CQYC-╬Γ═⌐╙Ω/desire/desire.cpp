#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e6,Mod=1e9+7;
int N,M,K,hed[Maxn],cnt,X[Maxn],Y[Maxn],top[Maxn];
int d[Maxn],Ans,fa[Maxn],dep[Maxn],Siz[Maxn],Son[Maxn];
int dfn[Maxn],tot,Mx[Maxn<<2],Tag[Maxn<<2];
struct node{int nxt,to;}G[Maxn<<1];
bool Vis[Maxn];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void DFS0(int x,int p){
    fa[x]=p,dep[x]=dep[p]+1,Siz[x]=1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        DFS0(y,x); Siz[x]+=Siz[y];
        if(Siz[y]>Siz[Son[x]]) Son[x]=y;
    }
}

void DFS1(int x,int t){
    top[x]=t,dfn[x]=++tot;
    if(!Son[x]) return;
    DFS1(Son[x],t);
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==fa[x]||y==Son[x]) continue;
        DFS1(y,y);
    }
}

void pushdown(int id){
    Mx[ls]+=Tag[id],Mx[rs]+=Tag[id];
    Tag[ls]+=Tag[id],Tag[rs]+=Tag[id];
    Tag[id]=0;
}

void Modify(int id,int l,int r,int L,int R,int v){
    if(L<=l&&r<=R) return Mx[id]+=v,Tag[id]+=v,void();
    if(Tag[id]) pushdown(id);
    if(L<=mid) Modify(ls,l,mid,L,R,v);
    if(R>mid) Modify(rs,mid+1,r,L,R,v);
    Mx[id]=max(Mx[ls],Mx[rs]);
}

void Pt(int x,int y,int v){
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        Modify(1,1,N,dfn[top[x]],dfn[x],v);
        x=fa[top[x]];
    }
    if(dep[x]>dep[y]) swap(x,y);
    Modify(1,1,N,dfn[x],dfn[y],v);
}

void DFS(int x,int lst){
    if(x>K){
        if(Mx[1]>=K) ++Ans;
        return;
    }
    For(i,lst+1,M) if(!Vis[i]){
        Vis[i]=1,Pt(X[i],Y[i],1);
        DFS(x+1,i);
        Vis[i]=0,Pt(X[i],Y[i],-1);
    }
}

int main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    N=read(),M=read(),K=read();
    For(i,1,N-1){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
    }
    DFS0(1,0); DFS1(1,1);
    For(i,1,M) X[i]=read(),Y[i]=read();
    DFS(1,0); write(Ans);
    return 0;
}
/*
g++ desire.cpp -o desire -O2
./desire
*/