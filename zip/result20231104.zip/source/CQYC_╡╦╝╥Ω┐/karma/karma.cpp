#include <bits/stdc++.h>
using namespace std;
int n, sum;
long long ans;
char s[400000];
vector<pair<int, int>> p;
int main()
{
    freopen("karma.in", "r", stdin);
    freopen("karma.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%s", s);
        int x = 0, y = 0;
        for (int j = 0; s[j]; j++)
            if (s[j] == '0')
                x++, ans += y;
            else
                y++;
        p.emplace_back(x, y);
    }
    sort(p.begin(), p.end(), [](pair<int, int> x, pair<int, int> y)
         { return 1ll * x.first * y.second > 1ll * y.first * x.second; });
    for (auto [x, y] : p)
        ans += 1ll * x * sum, sum += y;
    printf("%lld\n", ans);
    return 0;
}