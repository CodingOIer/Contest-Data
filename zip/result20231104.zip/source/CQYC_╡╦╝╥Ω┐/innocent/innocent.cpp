#include <bits/stdc++.h>
using namespace std;
int n, m;
bool f[2000][2];
vector<pair<int, int>> e[2000];
int main()
{
    freopen("innocent.in", "r", stdin);
    freopen("innocent.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 0, x, y, z; i < m; i++)
        scanf("%d%d%d", &x, &y, &z), e[x].emplace_back(y, z);
    for (int i = 0; i < n; i++)
    {
        priority_queue<pair<long long, int>> q;
        q.emplace(0, i);
        memset(f, 0, sizeof f);
        while (q.size())
        {
            auto [w, x] = q.top();
            if (x == i && w & 1)
            {
                w < 0 ? printf("%lld\n", -w) : puts("Twinkle");
                break;
            }
            q.pop();
            if (f[x][w & 1])
                continue;
            f[x][w & 1] = true;
            for (auto [y, z] : e[x])
                if (!f[y][(w - z) & 1])
                    q.emplace(w - z, y);
        }
        if (q.empty())
            puts("a-w-r-y");
    }
    return 0;
}