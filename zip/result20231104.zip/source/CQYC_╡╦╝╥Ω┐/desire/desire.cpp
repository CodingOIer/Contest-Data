#include <bits/stdc++.h>
using namespace std;
const int P = 1e9 + 7;
int n, m, k, ans;
int d[2400000], t[2400000], s[2400000], fac[2400000], inv[2400000];
int f[2400000][24];
vector<int> e[2400000];
int power(int x, int y)
{
    int res = 1;
    while (y)
    {
        if (y % 2)
            res = 1ll * res * x % P;
        x = 1ll * x * x % P;
        y /= 2;
    }
    return res;
}
int C(int x, int y)
{
    if (y < 0 || y > x)
        return 0;
    return 1ll * fac[x] * inv[y] % P * inv[x - y] % P;
}
void dfs(int x)
{
    for (int i = 0; i < 20; i++)
        f[x][i + 1] = f[f[x][i]][i];
    for (int y : e[x])
        if (y != f[x][0])
            d[y] = d[x] + 1, f[y][0] = x, dfs(y), s[x] += s[y];
    ans = (1ll * ans + C(s[x] + t[x], k) - C(s[x], k) + P) % P;
}
int lca(int x, int y)
{
    if (d[x] < d[y])
        swap(x, y);
    for (int i = 20; i >= 0; i--)
        if (1 << i <= d[x] - d[y])
            x = f[x][i];
    for (int i = 20; i >= 0; i--)
        if (f[x][i] != f[y][i])
            x = f[x][i], y = f[y][i];
    return x == y ? x : f[x][0];
}
int main()
{
    freopen("desire.in", "r", stdin);
    freopen("desire.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for (int i = fac[0] = 1; i <= m; i++)
        fac[i] = 1ll * fac[i - 1] * i % P;
    inv[m] = power(fac[m], P - 2);
    for (int i = m; i; i--)
        inv[i - 1] = 1ll * inv[i] * i % P;
    for (int i = 1, x, y; i < n; i++)
        scanf("%d%d", &x, &y), e[x].push_back(y), e[y].push_back(x);
    dfs(1);
    for (int i = 0, x, y, z; i < m; i++)
        scanf("%d%d", &x, &y), t[z = lca(x, y)]++, s[x]++, s[y]++, s[z] -= 2;
    dfs(1);
    printf("%d\n", ans);
    return 0;
}