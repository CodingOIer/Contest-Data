#include <bits/stdc++.h>
using namespace std;
const int P = 998244353;
int n;
int s[4000], g[4000];
int f[4000][4000];
vector<int> e[4000];
void dfs(int x, int w)
{
    s[x] = f[x][0] = 1;
    for (int y : e[x])
        if (y != w)
        {
            dfs(y, x);
            for (int i = 0; i <= s[x]; i++)
                for (int j = 0; j <= s[y]; j++)
                    g[i + j] = (g[i + j] + 1ll * f[x][i] * f[y][j]) % P;
            memcpy(f[x], g, sizeof g);
            memset(g, 0, sizeof g);
            s[x] += s[y];
        }
    for (int i = 0; i <= s[x]; i++)
        g[i] = ((i + 1ll) * f[x][i + 1] + (i ? f[x][i - 1] : 0)) % P;
    memcpy(f[x], g, sizeof g);
    memset(g, 0, sizeof g);
}
int main()
{
    freopen("courage.in", "r", stdin);
    freopen("courage.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1, x, y; i < n; i++)
        scanf("%d%d", &x, &y), e[x].push_back(y), e[y].push_back(x);
    dfs(1, 0);
    printf("%d 0\n", f[1][0]);
    return 0;
}