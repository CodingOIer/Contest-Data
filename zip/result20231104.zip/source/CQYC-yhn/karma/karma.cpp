#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,sz,sum=0,ans=1e18,dp[1000005],b[1000005];
char a[200005];
double st;
struct ok{
	int x,y;
}; 
vector<ok> e;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline bool cmp(ok a,ok b){
	if(a.y==b.y) return a.x>b.x;
	return a.y<b.y;
}
inline bool cmp2(ok a,ok b){
	if(a.x==b.x) return a.y<b.y;
	return a.x>b.x;
}
inline bool cmp3(ok a,ok b){
	if((a.x-a.y)==(b.x-b.y)) return cmp(a,b);
	return (a.x-a.y)<(b.x-b.y);
}
inline bool cmp4(ok a,ok b){
	if((a.x-a.y)==(b.x-b.y)) return cmp2(a,b);
	return (a.x-a.y)<(b.x-b.y);
}
inline bool cmp5(ok a,ok b){
	if((a.x-a.y)==(b.x-b.y)) return cmp(a,b);
	return (a.x-a.y)>(b.x-b.y);
}
inline bool cmp6(ok a,ok b){
	if((a.x-a.y)==(b.x-b.y)) return cmp2(a,b);
	return (a.x-a.y)>(b.x-b.y);
}
signed main(){
    freopen("karma.in","r",stdin);
    freopen("karma.out","w",stdout);
    st=clock();
    n=read();
    for(int i=1;i<=n;i++){
        scanf("%s",a+1);
        sz=strlen(a+1);
        int d=0,tot=0;
        for(int j=1;j<=sz;j++){
            if(a[j]=='1') d++;
            else tot+=d;
        }
        sum+=tot;
        e.push_back((ok){sz-d,d});
    }
    if(n<=18){
    	memset(dp,0x3f,sizeof(dp));
	    dp[0]=0;
	    for(int i=0;i<(1<<n);i++) for(int j=0;j<n;j++) if(i&(1<<j)) b[i]+=e[j].y;
	    for(int i=0;i<(1<<n);i++) for(int j=0;j<n;j++) if(!(i&(1<<j))) dp[i+(1<<j)]=min(dp[i+(1<<j)],dp[i]+b[i]*e[j].x);
	    cout<<sum+dp[(1<<n)-1];
	}
    else{
    	int d,o,ans=1e18;
    	sort(e.begin(),e.end(),cmp);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		sort(e.begin(),e.end(),cmp2);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		sort(e.begin(),e.end(),cmp3);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		sort(e.begin(),e.end(),cmp4);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		sort(e.begin(),e.end(),cmp5);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		sort(e.begin(),e.end(),cmp6);
    	d=o=0;
    	for(int i=0;i<(int)e.size();i++){
    		o+=(e[i].x*d);
    		d+=e[i].y;
		}
		ans=min(ans,o);
		while(((double)(clock()-st)/CLOCKS_PER_SEC)<=0.9){
			random_shuffle(e.begin(),e.end());
			d=o=0;
			for(int i=0;i<(int)e.size();i++){
				o+=(e[i].x*d);
				d+=e[i].y;
			}
			ans=min(ans,o);
		}
		cout<<ans+sum;
	}
    return 0;
}
