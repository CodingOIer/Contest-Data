#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,t1,t2,t3,cnt,head[10005],nxt[10005],txt[10005],zhi[10005],dis[10005][2],dp[10005][2],sum[2][10005][2];
bool v[2][10005][2];
struct ok{
    int d,z;
};
vector<ok> e[10005];
queue<pair<int,int>> q;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("innocent.in","r",stdin);
    freopen("innocent.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        t1=read()+1,t2=read()+1,t3=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2,zhi[cnt]=t3;
        e[t2].push_back((ok){t1,t3});
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            dis[j][0]=dis[j][1]=dp[j][0]=dp[j][1]=1e18;
            v[0][j][0]=v[0][j][1]=v[1][j][0]=v[1][j][1]=0;
            sum[0][j][0]=sum[0][j][1]=sum[1][j][0]=sum[1][j][1]=0;
        }
        dis[i][0]=0;dp[i][0]=0;
        q.push(make_pair(i,0));
        while(!q.empty()){
            pair<int,int> o=q.front();q.pop();
            int t=o.first;
            sum[0][t][o.second]++;
            if(sum[0][t][o.second]>(n+1)){
                v[0][t][o.second]=1;
                continue;
            }
            for(int j=head[t];j;j=nxt[j]){
                for(int g=0;g<=1;g++){
                    if(dis[t][g]>=(int)1e15) continue;
                    int d=dis[t][g]+zhi[j];
                    if(d<dis[txt[j]][d&1]){
                        dis[txt[j]][d&1]=d;
                        q.push(make_pair(txt[j],d&1));
                    }
                }
            }
        }
        q.push(make_pair(i,0));
        while(!q.empty()){
            pair<int,int> o=q.front();q.pop();
            int t=o.first;
            sum[1][t][o.second]++;
            if(sum[1][t][o.second]>(n+1)){
                v[1][t][o.second]=1;
                continue;
            }
            for(int j=0;j<(int)e[t].size();j++){
                for(int g=0;g<=1;g++){
                    if(dp[t][g]>=(int)1e15) continue;
                    int d=dp[t][g]+e[t][j].z;
                    if(d<dp[e[t][j].d][d&1]){
                        dp[e[t][j].d][d&1]=d;
                        q.push(make_pair(e[t][j].d,d&1));
                    }
                }
            }
        }
        for(int j=1;j<=n;j++){
            for(int g=0;g<=1;g++){
                for(int h=0;h<=1;h++){
                    if(sum[g][j][h]>n) v[g][j][h]=1;
                }
            }
        }
        int ans=1e18;
        bool f=0;
        for(int j=1;j<=n;j++){
            int d1=dis[j][0]+dp[j][1],d2=dis[j][1]+dp[j][0];
            bool f1=v[0][j][0]|v[1][j][1],f2=v[0][j][1]|v[1][j][0];
            if(d1<=(int)1e15&&f1) f=1;
            if(d2<=(int)1e15&&f2) f=1;
            if(d1<=(int)1e15&&d1<ans) ans=d1;
            if(d2<=(int)1e15&&d2<ans) ans=d2;
        }
        if(f) puts("Twinkle");
        else if(ans>=(int)1e15) puts("a-w-r-y");
        else cout<<ans<<"\n";
    }
    return 0;
}