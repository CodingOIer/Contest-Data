#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,t1,t2,cnt,head[2005],nxt[4005],txt[4005],F[2005],ans1=0,ans2=0,dp[2005][2005],sz[2005],G[2005];
bool flag,FFF=0;
double st;
pair<int,int> a[2005];
vector<int> e[2005];
bool v[2005],vis[2005][2005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void dfs(int k,int f){
    e[k].push_back(k);F[k]=f;sz[k]=0;
    dp[k][0]++;
    bool F=0;
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        dfs(txt[i],k);F=1;
        for(int j=0;j<=(sz[k]+sz[txt[i]]);j++) G[j]=0;
        for(int j=0;j<=sz[k];j++){
            for(int g=0;g<=sz[txt[i]];g++) add(G[j+g],dp[k][j]*dp[txt[i]][g]%M);
        }
        sz[k]+=sz[txt[i]];
        for(int i=0;i<=sz[k];i++) dp[k][i]=G[i];
        for(int j=0;j<(int)e[txt[i]].size();j++) e[k].push_back(e[txt[i]][j]);
    }
    // cout<<k<<"\n";
    // for(int i=0;i<=sz[k];i++) cout<<i<<" "<<dp[k][i]<<"\n";
    // cout<<"\n";
    if(F){
        sz[k]++;
        for(int i=0;i<=sz[k];i++) G[i]=0;
        for(int i=0;i<=sz[k];i++){
            if((i-1)>=0) add(G[i],dp[k][i-1]);
            add(G[i],dp[k][i+1]*(i+1)%M);
            // cerr<<k<<" "<<i<<" "<<G[i]<<"\n";
        }
        for(int i=0;i<=sz[k];i++) dp[k][i]=G[i];
    }
    else dp[k][1]=1,sz[k]++,dp[k][0]--;
    // cout<<k<<"\n";
    // for(int i=0;i<=sz[k];i++) cout<<i<<" "<<dp[k][i]<<"\n";
    // cout<<"\n";
}
inline void dfs2(int k){
    if(((double)(clock()-st)/CLOCKS_PER_SEC)>=0.8){
        FFF=1;
        return;
    }
    if(k==(n/2+1)){
        ans1++;
        for(int i=1;i<=(n/2);i++){
            for(int j=1;j<=(n/2);j++){
                if(i==j) continue;
                if(vis[a[j].first][a[i].first]&&vis[a[i].second][a[j].first]&&vis[a[j].second][a[i].second]) ans2++;
            }
        }
        return;
    }
    int t;
    for(int i=1;i<=n;i++){
        if(!v[i]){
            t=i;
            break;
        }
    }
    for(int i=0;i<(int)e[t].size();i++){
        if(e[t][i]==t) continue;
        if(v[e[t][i]]) continue;
        a[k]=make_pair(t,e[t][i]);
        if(vis[a[k].first][a[k].second]) swap(a[k].first,a[k].second);
        v[t]=v[e[t][i]]=1;
        dfs2(k+1);
        if(FFF) return;
        v[t]=v[e[t][i]]=0;
    }
}
signed main(){
    freopen("courage.in","r",stdin);
    freopen("courage.out","w",stdout);
    st=clock();
    n=read();
    for(int i=1;i<n;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    if(n&1){
        cout<<"0 0";
        return 0;
    }
    dfs(1,0);
    for(int i=1;i<=n;i++){
        int t=F[i];
        while(t){
            vis[i][t]=1;
            e[i].push_back(t);
            t=F[t];
        }
        sort(e[i].begin(),e[i].end());
    }
    dfs2(1);
    cout<<dp[1][0]<<" "<<ans2%M;
    return 0;
}