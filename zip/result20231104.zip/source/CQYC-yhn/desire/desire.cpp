#include<bits/stdc++.h>
#define M 1000000007
using namespace std;
bool st;
int F[22][2000005];
long long LG[2000005],n,m,K,t1,t2,cnt,head[2000005],nxt[4000005],txt[4000005],b[2000005],c[2000005],dep[2000005],ans=0,s[2000005],inv[2000005];
bool v[2000005];
pair<long long,long long> a[2000005];
bool ed;
inline long long read(){
    long long x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void dfs(long long k,long long f){
    F[0][k]=f;dep[k]=dep[f]+1;
    for(long long i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        dfs(txt[i],k);
    }
}
inline long long LCA(long long x,long long y){
    if(dep[x]<dep[y]) swap(x,y);
    long long t=LG[dep[x]];
    while(dep[x]>dep[y]){
        if(dep[F[t][x]]<dep[y]) t--;
        else x=F[t][x];
    }
    if(x==y) return x;
    t=LG[dep[x]];
    while(x!=y){
        if(F[t][x]==F[t][y]) t--;
        else x=F[t][x],y=F[t][y];
        if(t<0) break;
    }
    return F[0][x];
}
inline void dfs2(long long k,long long f){
    for(long long i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        dfs2(txt[i],k);
        b[k]+=b[txt[i]];
        c[k]+=c[txt[i]];
    }
}
inline long long ksm(long long k,long long c){
    long long a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
inline long long C(long long x,long long y){
    if(x<y) return 0;
    long long s1=s[x],s2=inv[y],s3=inv[x-y];
    s2=(s2*s3)%M;
    s1=(s1*s2)%M;
    return s1;
}
inline void add(long long &x,long long y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void del(long long &x,long long y){
    if(x<y) x=x-y+M;
    else x-=y;
}
signed main(){
    freopen("desire.in","r",stdin);
    freopen("desire.out","w",stdout);
    // double st=clock();
    for(int i=1;i<=2000000;i++) LG[i]=LG[i-1]+((1<<LG[i-1])==i);
    s[0]=1;
    for(long long i=1;i<=2000000;i++) s[i]=(s[i-1]*i)%M;
    inv[2000000]=ksm(s[2000000],M-2);
    for(long long i=1999999;i>=0;i--) inv[i]=(inv[i+1]*(i+1))%M;
    n=read(),m=read(),K=read();
    for(long long i=1;i<n;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    for(long long i=1;i<=m;i++) a[i].first=read(),a[i].second=read();
    dfs(1,0);
    for(long long i=1;i<22;i++) for(long long j=1;j<=n;j++) F[i][j]=F[i-1][F[i-1][j]];
    for(long long i=1;i<=m;i++){
        b[a[i].first]++;
        b[a[i].second]++;
        c[a[i].first]++;
        c[a[i].second]++;
        long long w=LCA(a[i].first,a[i].second);
        b[w]--;
        b[F[0][w]]--;
        c[w]-=2;
    }
    dfs2(1,0);
    for(long long i=1;i<=n;i++){
        if(b[i]>=K) add(ans,C(b[i],K));
        if(c[i]>=K) del(ans,C(c[i],K));
    }
    cout<<ans;
    // cerr<<(double)(clock()-st)/CLOCKS_PER_SEC<<"s\n";
    return 0;
}