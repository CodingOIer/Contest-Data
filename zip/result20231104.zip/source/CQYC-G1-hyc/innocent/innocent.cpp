#include<bits/stdc++.h>
using namespace std;
const int NN=2004;
vector<pair<int,int> >g[NN];
int d[NN],cnt[NN],n;
bool st[NN];
void spfa(int s)
{
	for(int i=0;i<=n*2-1;i++)
	{
		st[i]=false;
		cnt[i]=0;
		d[i]=1e9;
	}
	d[s]=0;
	st[s]=true;
	queue<int>q;
	q.push(s);
	while(q.size())
	{
		int u=q.front();
		q.pop();
		st[u]=false;
		if(cnt[u]==n+1)
			st[u]=true;
		for(int i=0;i<g[u].size();i++)
		{
			int v=g[u][i].first,w=g[u][i].second;
			if(d[v]>d[u]+w)
			{
				cnt[v]++;
				d[v]=d[u]+w;
				if(!st[v])
				{
					q.push(v);
					st[v]=true;
				}
			}
		}
	}
}
int main()
{
	freopen("innocent.in","r",stdin);
	freopen("innocent.out","w",stdout);
	int m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		if(w%2)
		{
			g[u*2+1].push_back({v*2,w});
			g[u*2].push_back({v*2+1,w});
		}
		else
		{
			g[u*2].push_back({v*2,w});
			g[u*2+1].push_back({v*2+1,w});
		}
	}
	for(int i=0;i<n;i++)
	{
		spfa(i*2);
		if(cnt[i*2+1]>n)
			puts("Twinkle");
		else if(d[i*2+1]==1e9)
			puts("a-w-r-y");
		else
			printf("%d\n",d[i*2+1]);
	}
	return 0;
}
