#include<bits/stdc++.h>
using namespace std;
const int NN=2e6+4,P=1e9+7;
int up[NN][24],dep[NN],a[NN],b[NN],fac[NN],ifac[NN];
vector<int>g[NN];
void before_lca(int u,int fa)
{
	dep[u]=dep[fa]+1;
	up[u][0]=fa;
	for(int i=1;i<=20;i++)
		up[u][i]=up[up[u][i-1]][i-1];
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa)
			continue;
		before_lca(v,u);
	}
}
int lca(int u,int v)
{
	if(dep[u]<dep[v])
		swap(u,v);
	for(int i=20;~i;i--)
		if(dep[up[u][i]]>=dep[v])
			u=up[u][i];
	if(u==v)
		return u;
	for(int i=20;~i;i--)
		if(up[u][i]!=up[v][i])
			u=up[u][i],v=up[v][i];
	return up[u][0];
}
int qmi(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1)
			res=1ll*res*a%P;
		a=1ll*a*a%P;
		b>>=1;
	}
	return res;
}
int C(int a,int b)
{
	if(a<b||b<0)
		return 0;
	return 1ll*fac[a]*ifac[b]%P*ifac[a-b]%P;
}
void dfs(int u,int fa)
{
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa)
			continue;
		dfs(v,u);
		a[u]+=a[v],b[u]+=b[v];
	}
}
int main()
{
	freopen("desire.in","r",stdin);
	freopen("desire.out","w",stdout);
	fac[0]=1;
	for(int i=1;i<NN;i++)
		fac[i]=1ll*fac[i-1]*i%P;
	ifac[NN-1]=qmi(fac[NN-1],P-2);
	for(int i=NN-2;~i;i--)
		ifac[i]=1ll*ifac[i+1]*(i+1)%P;
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	before_lca(1,0);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		int l=lca(u,v);
		a[u]++,a[v]++,a[l]-=2;
		b[u]++,b[v]++,b[up[l][0]]--,b[l]--;
	}
	dfs(1,0);
	int ans=0;
	for(int i=1;i<=n;i++)
		ans=(0ll+ans+C(b[i],k)-C(a[i],k)+P)%P;
	printf("%d",ans);
	return 0;
}
