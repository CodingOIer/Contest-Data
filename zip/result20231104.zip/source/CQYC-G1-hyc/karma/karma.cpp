#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4;
struct node
{
	string s;
	int len,cnt;
	bool operator<(const node&it)const
	{
		return 1ll*(len-cnt)*it.cnt<1ll*(it.len-it.cnt)*cnt;
	}
}a[NN];
int main()
{
	freopen("karma.in","r",stdin);
	freopen("karma.out","w",stdout);
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].s;
		a[i].len=a[i].s.size();
		for(int j=0;j<a[i].len;j++)
			if(a[i].s[j]=='0')
				a[i].cnt++;
	}
	sort(a+1,a+1+n);
	string str;
	for(int i=1;i<=n;i++)
		str+=a[i].s;
	int cnt=0,m=str.size();
	long long ans=0;
	for(int i=0;i<m;i++)
		if(str[i]=='1')
			cnt++;
		else
			ans+=cnt;
	printf("%lld",ans);
	return 0;
}
