#include<bits/stdc++.h>
using namespace std;
const int NN=2004,P=998244353;
int f[NN][NN],siz[NN];
vector<int>g[NN];
void dfs(int u,int fa)
{
	siz[u]=1;
	f[u][1]=1;
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa)
			continue;
		dfs(v,u);
		siz[u]+=siz[v];
		for(int j=siz[u];~j;j--)
		{
			int res=0;
			for(int k=0;k<=min(j,siz[v]);k++)
				res=(res+1ll*f[u][j-k]*f[v][k]%P)%P;
			f[u][j]=res;
		}
	}
	for(int i=0;i<=siz[u];i++)
		f[u][i]=(f[u][i]+1ll*f[u][i+2]*(i+1)%P)%P;
}
int main()
{
	freopen("courage.in","r",stdin);
	freopen("courage.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1,0);
	printf("%d 0\n",f[1][0]);
	return 0;
}
