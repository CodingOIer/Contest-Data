#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2005 ;
const int MOD = 998244353 ;
int n,ans ;
int fa[N],dep[N],p[N],zu[N][N],pi[N] ;
int id[N],vis[N],sz[N],f[N][N],g[N][N] ;
vector<int>zx[N] ;
vector<int>e[N] ;
void Solve(int x)
{
    sz[x] = vis[x] = 1 ; int chk = 0 ;
    for(auto v:e[x]) if(!vis[v])
    {
        Solve(v) ;
        if(!chk)
        {
            FOR(i,0,min(n,sz[v]),1) f[x][i] = f[v][i] ; chk = 1 ;
        }
        else
        {
            me(g[x],0) ;
            ROF(i,min(sz[x],n),0,1) FOR(j,0,min(sz[v],n),1) if(i+j <= n)
                (g[x][i+j] += f[x][i]*f[v][j]%MOD) %= MOD ;
            FOR(i,0,n,1) f[x][i] = g[x][i] ;
        }
        sz[x] += sz[v] ;
    }
    ROF(i,min(sz[x],n),1,1) (f[x][i] = f[x][i-1]%MOD) %= MOD ; f[x][0] = 0 ; //print(x) ; FOR(i,0,n,1) print(f[x][i]) ; enter ;
    FOR(i,0,min(sz[x],n),1) (f[x][i] += f[x][i+2]*(i+1)%MOD) %= MOD ;
    if(!chk) f[x][1] = 1 ;
}
vector<int>gd[N] ;
void Dfs(int x)
{
    vis[x] = 1 ;
    for(auto v:e[x]) if(!vis[v]) fa[v] = x,Dfs(v) ;
}
int cmp(int x,int y) {return dep[x] > dep[y] ;}
void calc()
{//cerr<<"!" ;
    FOR(i,1,n,1)
    {
        int x = i,y = pi[x] ;
        if(dep[x] > dep[y]) continue ;
        FOR(j,1,n,1) if(i != j)
        {
            int X = j,Y = pi[j] ;
            if(dep[X] > dep[Y]) continue ;
            if(zu[x][X] && zu[y][Y] && zu[Y][x]) ++ans ;
        }
    }
}
void Bao(int x)
{
    if(x == n+1) {calc() ; return ;}
    if(pi[id[x]]) {Bao(x+1) ; return ;}
    for(auto ff:gd[id[x]])
    {
        if(!pi[ff])
        {
            pi[ff] = id[x],pi[id[x]] = ff ;
            Bao(x+1),pi[ff] = 0,pi[id[x]] = 0 ;
        }
    }
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("courage.in","r",stdin) ;
	freopen("courage.out","w",stdout) ;
    read(n) ;
    FOR(i,2,n,1)
    {
        int u,v ; read(u,v) ;
        e[u].pb(v),e[v].pb(u) ;
    }
    Solve(1) ;
    // if(n <= 10)
    // {
    //     me(vis,0),Dfs(1) ;
    //     FOR(i,1,n,1)
    //     {
    //         int x = i ;
    //         while(fa[x]) zu[i][x] = 1,x = fa[x],gd[i].pb(x) ;
    //     }
    //     FOR(i,1,n,1) id[i] = i ;
    //     sort(id+1,id+1+n,cmp),Bao(1) ;
    // }
    print(f[1][0],ans),enter ;
    return 0 ;
}