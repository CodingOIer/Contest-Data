#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e3+5 ;
int n,m,rt,chk,idx,cnt,top ;
int ans[N],vis[N],yys[N],in[N],dis[N],dep[N],st[N],low[N],dfn[N] ;
struct Edge{int v,w ;} ;
vector<Edge>e[N] ;
void Solve(int x,int sum)
{
    vis[x] = 1 ;
    for(auto p:e[x])
    {
        int v = p.v,w = p.w ;
        if(vis[v] && v != rt) continue ;
        if(v == rt)
        {
            int val = sum+w ;
            if(val < 0 && abs(val)%2) ans[rt] = -1,chk = 1 ;
            else if(val > 0 && abs(val)%2) ans[rt] = min(ans[rt],val) ;
            else if(val < 0 && abs(val)%2 == 0) yys[rt] = 1 ;
            if(abs(val)%2 && yys[rt]) ans[rt] = -1,chk = 1 ;
        }
        else
        {
            Solve(v,sum+w) ;
            if(chk) return ;
        }
    }
    vis[x] = 0 ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("innocent.in","r",stdin) ;
	freopen("innocent.out","w",stdout) ;
    read(n,m) ;
    FOR(i,1,m,1)
    {
        int u,v,w ; 
        read(u,v,w),e[u+1].pb({v+1,w}) ;
    }
    me(ans,0x3f) ;
    FOR(i,1,n,1) me(vis,0),chk = 0,rt = i,Solve(i,0) ;
    FOR(i,1,n,1)
    {
        if(ans[i] == -1) puts("Twinkle") ;
        else if(ans[i] == ans[0]) puts("a-w-r-y") ;
        else print(ans[i]),enter ;
    }
    return 0 ;
}