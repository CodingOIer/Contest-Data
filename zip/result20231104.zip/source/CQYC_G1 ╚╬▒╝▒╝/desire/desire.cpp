#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 25 ;
int n,m,k,f,ans ;
int chk[N],val[N],vis[N],a[N],b[N] ;
vector<int>e[N] ;
void re(int x,int to)
{
    if(x == to) {val[x]++,f = 1 ; return ;}
    vis[x] = 1 ;
    for(auto v:e[x]) if(!vis[v])
    {
        re(v,to) ;
        if(f) {val[x]++ ; return ;}
    }
}
void Check()
{
    int tot = 0 ;
    FOR(i,1,n,1) tot += chk[i] ;
    if(tot != k) return ; me(val,0) ;
    FOR(i,1,m,1) if(chk[i]) me(vis,0),f = 0,re(a[i],b[i]) ;
    FOR(i,1,n,1) if(val[i] == k) {ans++ ; return ;}
}
void Dfs(int x)
{
    if(x == m+1) {Check() ; return ;}
    chk[x] = 1,Dfs(x+1),chk[x] = 0,Dfs(x+1) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("desire.in","r",stdin) ;
	freopen("desire.out","w",stdout) ;
    read(n,m,k) ;
    FOR(i,2,n,1)
    {
        int u,v ; read(u,v) ;
        e[u].pb(v),e[v].pb(u) ;
    }
    FOR(i,1,m,1) read(a[i],b[i]) ;
    Dfs(1),print(ans),enter ;
    return 0 ;
}