#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2e5+5 ;
int n,ans ;
struct Node{int a,b ;}a[N] ;
string s[N] ;
int cmp(Node x,Node y)
{
    return x.b*y.a < y.b*x.a ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("karma.in","r",stdin) ;
	freopen("karma.out","w",stdout) ;
    read(n) ;
    FOR(i,1,n,1)
    {
        cin>>s[i] ;
        for(auto p:s[i])
            if(p == '1') a[i].b++ ;
            else ans += a[i].b,a[i].a++ ;
    }
    sort(a+1,a+1+n,cmp) ; int sum = 0 ;
    FOR(i,1,n,1) ans += sum*a[i].a,sum += a[i].b ; print(ans),enter ;
    return 0 ;
}