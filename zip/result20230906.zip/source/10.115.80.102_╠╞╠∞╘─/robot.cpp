#include<bits/stdc++.h>
using namespace std;
int n,m1,m2,s1=0,s2=0;
int a[50005];
int b[50005];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i];
		b[i]=a[i];
	}
	for (int i=1;i<n;i++)
	{
		if (a[i]>a[i+1])
		{
			a[i+1]=a[i];
			s1+=m1;
		}
	}
	for (int i=1;i<=n;i++)
		a[i]=b[i];
	for (int i=1;i<n;i++)
	{
		if (a[i]<a[i+1])
		{
			a[i+1]=a[i];
			s2+=m2;
		}
	}
	cout<<min(s1,s2);
	return 0;
}

