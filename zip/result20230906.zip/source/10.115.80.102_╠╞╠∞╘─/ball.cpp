#include<bits/stdc++.h>
using namespace std;
long long n,m,k,l,ans=1,mod=1e9+7,p=1;
long long a[10000005],flag=0;
void g(int x)
{
//	cout<<x<<' ';
	for (int i=2;i<=x;i++)
	{
		while (x%i==0)
		{
			a[i]++;
			x/=i;
		}
	}
	return;
}
void f(int x)
{
	for (int i=2;i<=x;i++)
	{
		while (x%i==0)
		{
			a[i]--;
			x/=i;
		}
	}
	return;
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	l=n-k;
	m--;
	for (int i=1;i<=m;i++)
		g(l-i+1);
	for (int i=1;i<=m;i++)
		f(i);
	for (int i=2;i<=1000005;i++)
	{
		while (a[i]>0)
		{
			ans=(ans%mod)*i%mod;
			flag=1;
			a[i]--;
		}
	}
	if (flag==0)
	{
		cout<<0;
		return 0;
	}
	cout<<ans;
	return 0;
}
