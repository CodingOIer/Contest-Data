#include <bits/stdc++.h>
using namespace std;
string str;
char s[100005],a[100005][10005];
int b[100005];
int main() {
	freopen("subsdript.in", "r", stdin);
	freopen("subscript.out", "w", stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>str;
		str.copy(s,100000,0);
		for(int j=0;j<=10;j++)
		{
			if(s[j]==0)break;
			cout<<s[j];
		}
		cout<<endl;
		int j=1,d=0;
		for(int k=1;d<=100000;d++)
		{
			if(int(s[d]==0))break;
			if(d==0)
			{
				while(1)
				{
					cin>>a[j][k],k++;
					i++;
					if(s[i]=='[')
					{
						b[j]=k;
						j++;
						break;
					}
				}
			}
			if(int(s[d])=='[')
			{
				while(1)
				{
					i++;
					if(int(s[d])==']')
					{
						b[j]=k;
						j++,k=1;
						break;
					}
					cin>>a[j][k],k++;
				}
			}
		}
		for(int w=1;w<=d+1;w++)
			cout<<s[w-1];
		memset(s,0,sizeof(s));
	}
	
	return 0;
}


