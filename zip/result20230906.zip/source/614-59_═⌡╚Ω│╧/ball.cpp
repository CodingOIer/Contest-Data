#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	n-=k,m-=1;
	long long ans=0;
	if(m==0)
	{
		cout<<1;
		return 0;
	}
	if(m==1)
	{
		cout<<n%1000000007;
		return 0;
	}
	if(m==2)
	{
		cout<<((n-1)*n/2)%1000000007;
		return 0;
	}
	if(n-m+1<=3)
	{
		long long i=n-m+1;
		for(int j=1;j<=m;j++)
		{
			ans=(ans+(1+i)*i/2%1000000007)%1000000007;
			if(i>0)i--;
		}
		cout<<ans;
		return 0;
	}
	for(int s=1;s<=n-m+1;s++)
	{
		long long i=n-m-s+2;
		for(int j=1;j<=m;j++)
		{
			ans=(ans+(1+i)*i/2%1000000007)%1000000007;
			if(i>0)i--;
		}
	}
	cout<<ans;
	return 0;
}


