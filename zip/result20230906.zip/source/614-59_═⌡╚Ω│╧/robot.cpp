#include <bits/stdc++.h>
using namespace std;
int a[500005],b[500005],c[500005];
int main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	int n,m1,m2;
	scanf("%d%d%d",&n,&m1,&m2);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),b[i]=a[i],c[i]=a[i];
	long long ans1=0,ans2=0;
	for(int i=1;i<n;i++)
	{
		if(b[i]>b[i+1])
		{
			b[i+1]=b[i];
			ans1+=m1;
		}
	}
	for(int i=n;i>1;i--)
	{
		if(c[i-1]<c[i])
		{
			c[i-1]=c[i];
			ans2+=m2;
		}
	}
	cout<<min(ans1,ans2);
	return 0;
}


