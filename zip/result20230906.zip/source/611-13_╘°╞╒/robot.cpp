#include<bits/stdc++.h>
using namespace std;
int Saber[50005],a[50005];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int n,m,l;
	cin>>n>>m>>l;
	if(n==1||n==2){
		cout<<0;
		return 0;
	}
	long long flag1=0,flag2=0;
	for(int i=1;i<=n;i++)
	{
		cin>>Saber[i];
		a[i]=Saber[i];
		if(Saber[i]<Saber[i-1]&&i>1)
			flag1++,Saber[i]=Saber[i-1];
	}
	for(int i=n;i>1;i--)
	{
		if(a[i]>a[i-1])
			flag2++,a[i]=a[i-1];
	}
	cout<<min(flag1*m,flag2*l);
	return 0;
 } 
