#include<bits/stdc++.h>
using namespace std;
long long MAXN=1e9+7,ans=0;
long long n,m,k;
void dfs(int j,int p){
	if(j==m){
		ans=(ans+1)%MAXN;
		//cout<<p<<" ";
		return ;
	}
	for(int i=p+1;i<=n;i++)
		dfs(j+1,i);
}
int main()
{
	//freopen("ball.in","r",stdin);
	//freopen("ball.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	dfs(1,k);
	printf("%lld",ans);
	return 0;
 } 
