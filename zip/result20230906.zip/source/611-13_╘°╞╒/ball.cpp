#include<bits/stdc++.h>
using namespace std;
const long long MAXN=1e9+7;
int Saber[1000005];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	if(m==1)
	{
		cout<<1;
		return 0;
	}
	int l=n-k+2-m;
	for(int i=1;i<=l;i++)
		Saber[i]=1;
	for(int i=3;i<=m;i++)
	{
		for(int j=2;j<=l;j++)
		{
			Saber[j]=(Saber[j]+Saber[j-1])%MAXN;
		}
	}
	long long ans=0;
	for(int i=1;i<=l;i++)
		ans=(ans+Saber[i])%MAXN;
	cout<<ans;
	return 0;
 } 
