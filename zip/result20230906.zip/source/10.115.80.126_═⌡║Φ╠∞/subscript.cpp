#include <algorithm>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

const int MaxN = 1e5 + 5;
class str
{
  public:
    std::vector<int> sons;
    std::string name;
    bool operator<(const str __x)
    {
        str a, b;
        a = *this;
        b = __x;
        int len;
        len = std::max(a.name.size(), b.name.size());
        b.name += a.name;
        a.name += __x.name;
        for (int i = 0; i < len; i++)
        {
            if (a.name[i] < b.name[i])
            {
                return true;
            }
            else if (a.name[i] > b.name[i])
            {
                return false;
            }
        }
        return false;
    }
};
int t;
int n;
int cnt;
str p[MaxN];
char s[MaxN];
int get(int x, int last)
{
    int now;
    cnt++;
    now = cnt;
    p[last].sons.push_back(now);
    int i;
    for (i = x; x <= n && s[i] != ']'; i++)
    {
        if (s[i] == '[')
        {
            i = get(i + 1, now);
        }
        else
        {
            p[now].name += s[i];
        }
    }
    return i;
}
std::string all(int x)
{
    std::string result;
    result = p[x].name;
    for (int i = 0; i < p[x].sons.size(); i++)
    {
        result += all(p[x].sons[i]);
    }
    return result;
}
void sort(int x)
{
    std::vector<std::string> tmp;
    tmp.push_back(p[x].name);
    for (int i = 0; i < p[x].sons.size(); i++)
    {
        sort(p[x].sons[i]);
        tmp.push_back(all(p[x].sons[i]));
    }
    std::sort(tmp.begin(), tmp.end());
    p[x].name = tmp[0];
    for (int i = 0; i < p[x].sons.size(); i++)
    {
        p[p[x].sons[i]].name = tmp[i + 1];
    }
}
void print(int x)
{
    printf("%s", p[x].name.c_str());
    if (x != 0 && p[x].sons.size() != 0)
    {
        printf("[");
    }
    for (int i = 0; i < p[x].sons.size(); i++)
    {
        print(p[x].sons[i]);
    }
    if (x != 0 && p[x].sons.size() != 0)
    {
        printf("]");
    }
}
void solve()
{
    cnt = 0;
    p[0].sons.clear();
    scanf("%s", s + 1);
    n = strlen(s + 1);
    get(1, 0);
    sort(0);
    print(0);
    printf("\n");
}
int main()
{
    freopen("subscript.in", "r", stdin);
    freopen("subscript.out", "w", stdout);
    scanf("%d", &t);
    for (int i = 1; i <= t; i++)
    {
        solve();
    }
    return 0;
}