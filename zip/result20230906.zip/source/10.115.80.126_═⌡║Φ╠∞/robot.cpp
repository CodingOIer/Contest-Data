#include <algorithm>
#include <cstdio>
#include <cstring>
const int MaxN = 5e3 + 5;
int n;
int m_1, m_2;
int answer_1, answer_2, answer_3, answer_4;
int p[MaxN];
int s[MaxN];
int main()
{
    freopen("robot.in", "r", stdin);
    freopen("robot.out", "w", stdout);
    scanf("%d%d%d", &n, &m_1, &m_2);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &p[i]);
    }
    for (int i = 1; i <= n; i++)
    {
        s[i] = p[i];
    }
    for (int i = 2; i <= n; i++)
    {
        if (s[i] < s[i - 1])
        {
            int sum_1, sum_2;
            sum_1 = 0;
            sum_2 = 0;
            for (int j = i; j <= n && s[j] < s[i - 1]; j++)
            {
                sum_1 += m_1;
            }
            for (int j = i - 1; j >= 1 && s[j] > s[i]; j--)
            {
                sum_2 += m_2;
            }
            if (sum_1 > sum_2)
            {
                answer_1 += sum_2;
                for (int j = i - 1; j >= (i - 1) - sum_2 / m_2 + 1; j--)
                {
                    s[j] = s[i];
                }
            }
            else
            {
                answer_1 += sum_1;
                for (int j = i; j <= i + sum_1 / m_1 - 1; j++)
                {
                    s[j] = s[i - 1];
                }
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        s[i] = p[i];
    }
    for (int i = 2; i <= n; i++)
    {
        if (s[i] > s[i - 1])
        {
            int sum_1, sum_2;
            sum_1 = 0;
            sum_2 = 0;
            for (int j = i; j <= n && s[j] > s[i - 1]; j++)
            {
                sum_1 += m_2;
            }
            for (int j = i - 1; j >= 1 && s[j] < s[i]; j--)
            {
                sum_2 += m_1;
            }
            if (sum_1 > sum_2)
            {
                answer_2 += sum_2;
                for (int j = i - 1; j >= (i - 1) - sum_2 / m_2 + 1; j--)
                {
                    s[j] = s[i];
                }
            }
            else
            {
                answer_2 += sum_1;
                for (int j = i; j <= i + sum_1 / m_1 - 1; j++)
                {
                    s[j] = s[i - 1];
                }
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        s[n - i + 1] = p[i];
    }
    for (int i = 2; i <= n; i++)
    {
        if (s[i] < s[i - 1])
        {
            int sum_1, sum_2;
            sum_1 = 0;
            sum_2 = 0;
            for (int j = i; j <= n && s[j] < s[i - 1]; j++)
            {
                sum_1 += m_1;
            }
            for (int j = i - 1; j >= 1 && s[j] > s[i]; j--)
            {
                sum_2 += m_2;
            }
            if (sum_1 > sum_2)
            {
                answer_3 += sum_2;
                for (int j = i - 1; j >= (i - 1) - sum_2 / m_2 + 1; j--)
                {
                    s[j] = s[i];
                }
            }
            else
            {
                answer_3 += sum_1;
                for (int j = i; j <= i + sum_1 / m_1 - 1; j++)
                {
                    s[j] = s[i - 1];
                }
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        s[n - i + 1] = p[i];
    }
    for (int i = 2; i <= n; i++)
    {
        if (s[i] > s[i - 1])
        {
            int sum_1, sum_2;
            sum_1 = 0;
            sum_2 = 0;
            for (int j = i; j <= n && s[j] > s[i - 1]; j++)
            {
                sum_1 += m_2;
            }
            for (int j = i - 1; j >= 1 && s[j] < s[i]; j--)
            {
                sum_2 += m_1;
            }
            if (sum_1 > sum_2)
            {
                answer_4 += sum_2;
                for (int j = i - 1; j >= (i - 1) - sum_2 / m_2 + 1; j--)
                {
                    s[j] = s[i];
                }
            }
            else
            {
                answer_4 += sum_1;
                for (int j = i; j <= i + sum_1 / m_1 - 1; j++)
                {
                    s[j] = s[i - 1];
                }
            }
        }
    }
    printf("%d\n", std::min({answer_1, answer_2, answer_3, answer_4}));
    // printf("%d %d %d %d\n", answer_1, answer_2, answer_3, answer_4);
    return 0;
}