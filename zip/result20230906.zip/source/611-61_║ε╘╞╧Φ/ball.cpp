#include<bits/stdc++.h>
using namespace std;
const int r=10e9+7;
int n,m,k,a,b,c,sum;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	a=n-k;
	m--;
	if(m*2>a)
	    m=a-m;
	b=n;
	c=1;
	for(int i=1;i<=m-1;i++)
	{
		b*=n-1;
		c*=i+1;
		n--;
	}
	sum=b/c; 
	printf("%d",sum);
	return 0;
}
