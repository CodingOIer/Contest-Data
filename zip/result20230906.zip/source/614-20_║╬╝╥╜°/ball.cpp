#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,m,k;
int ksm(int x,int p)
{
	int ans=1;
	while(p)
	{
		if(p&1)
			ans=ans*x%mod;
		x=x*x%mod;
		p>>=1;
	}
	return ans%mod;
}
int inv(int x)
{
	return ksm(x,mod-2);
}
int C(int x,int y)
{
	int ans=1;
	for(int i=1;i<=y;i++)
		ans=ans*i%mod;
	int ans1=1;
	for(int i=1;i<=x;i++)
		ans1=ans1*i%mod;
	int ans2=1;
	for(int i=1;i<=y-x;i++)
		ans2=ans2*i%mod;
	int k=ans1*ans2%mod;
	return ans*inv(k);
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(m-1>=n-k)
	{
		cout<<0;
		return 0;
	}
	cout<<C(m-1,n-k)%mod;
	return 0;
}
