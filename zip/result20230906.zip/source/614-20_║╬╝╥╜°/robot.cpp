#include<bits/stdc++.h>
using namespace std;
//struct smt
//{
//	struct node
//	{
//		int val;
//		node *l=NULL,*r=NULL;
//	};	
//	node *root=NULL;
//	node* New()
//	{
//		node *p=new node;
//		p->l=p->r=NULL;
//		p->val=0;
//		return p;
//	}
//	void insert(int l,int r,int x,int k,node* root)
//	{	
//		if(root==NULL)
//		return;
//		if(l==r)
//		{	
//			root->val+=k;
//			return;
//		}
//		if(x<=mid)
//		{
//			if(ls==NULL)
//				ls=New();
//			insert(l,mid,x,k,ls);
//		}
//		else
//		{
//			if(rs==NULL)
//				rs=New();
//			insert(mid+1,r,x,k,rs);
//		}
//		if(ls!=NULL)
//			root->val=max(ls->val,root->val);
//		if(rs!=NULL)
//			root->val=max(rs->val,root->val);
//	}
//	int query(int l,int r,int x,int y,node* root)
//	{
//		if(l>=x&&r<=y)
//			return root->val;
//		int res=0;
//		if(x<=mid&&ls!=NULL)
//			res+=query(l,mid,x,y,ls);
//		if(y>mid&&rs!=NULL)
//			res+=query(mid+1,r,x,y,rs);
//		return res;
//	}
//};
//struct Smt
//{
//	smt t;
//	int l,r;
//}t[1145*4];
int n,m1,m2,h[114514*5],h1[114514*5];
int ansl=1e9,ansh=1e9;
int dp[114514*5];
int t[1145];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
		scanf("%d",&h[i]),h1[i]=h[i];
	if(n<=5000)
	{
		for(int i=1;i<=n;i++)
		{
			int maxn=0;
			for(int j=1;j<=i;j++)
				if(h[i]>=h[j]&&dp[maxn]<dp[j])
					maxn=j;
			dp[i]+=dp[maxn]+1;
			ansh=min(ansh,n-dp[i]);
		}
		memset(dp,0,sizeof dp);
		for(int i=1;i<=n;i++)
		{
			int maxn=0;
			for(int j=1;j<=i;j++)
				if(h1[i]<=h1[j]&&dp[maxn]<dp[j])
					maxn=j;
			dp[i]+=dp[maxn]+1;
			ansl=min(ansl,n-dp[i]);
		}
		cout<<min(ansl,ansh);
	}
	else
	{
		for(int i=1;i<=n;i++)
			t[h[i]]++;
		cout<<min(t[1],t[2])*min(m1,m2);
	}
	return 0;
}
