#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <queue>
#include <cstring>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 5e4 + 5, M = 1005;
int s[N], h[N], isl[N];
int lm[N], rm[N];
int f[M], g[M];
deque <int> q;
int main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout); 
	int n = read(), m1 = read(), m2 = read();
	for (int i = 1; i <= n; i++) {
		h[i] = s[i] = read();
	}
	sort(h + 1, h + 1 + n);
	int m = unique(h + 1, h + 1 + n) - h - 1;
	for (int i = 1; i <= n; i++)
		s[i] = lower_bound(h + 1, h + 1 + m, s[i]) - h;
	for (int i = 1; i <= n; i++) {
		int pos = lower_bound(h + 1, h + 1 + m, s[i]) - h;
		for (int j = 1; j <= m; j++) {
			f[j] = g[j];
			if (j > pos)
				f[j] += m1;
			if (j < pos)
				f[j] += m2;
			g[j] = f[j];
		}
		for (int j = 2; j <= m; j++) {
			g[j] = min(g[j], g[j - 1]);
		}
	}
	int ans = 0x7f7f7f7f;
	for (int i = 1; i <= m; i++) {
		ans = min(ans, f[i]);
	}
	memset(f, 0, sizeof(f));
	memset(g, 0, sizeof(g));
	for (int i = 1; i <= n; i++) {
		int pos = lower_bound(h + 1, h + 1 + m, s[i]) - h;
		for (int j = m; j >= 1; j--) {
			f[j] = g[j];
			if (j > pos)
				f[j] += m1;
			if (j < pos)
				f[j] += m2;
			g[j] = f[j];
		}
		for (int j = m - 1; j >= 1; j--) {
			g[j] = min(g[j], g[j + 1]);
		}
	}
	for (int i = 1; i <= m; i++) {
		ans = min(ans, f[i]);
	}
	write(ans), puts("");
	return 0;	
}
