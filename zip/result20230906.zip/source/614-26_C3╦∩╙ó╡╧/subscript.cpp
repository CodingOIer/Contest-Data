#include <iostream>
#include <algorithm>
#include <cstdio>
#include <stack>
#include <cstring>
using namespace std;
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 1e5 + 5, M = 2e5 + 5;
stack <int> stk;
int fir[N], nex[M], to[M], cnt;
int isl[N];
string mp[N];
void add(int x, int y) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;	
}
int fa[N];
string dfs(int x) {
	if (!mp[x].c_str()) return "";
//	write(x), putchar(32);
//	printf("%s\n", mp[x].c_str());
	string s1, s2;
	int t1, t2;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x]) continue;
		s1 = dfs(to[i]);
	}
//	return "";
	if (s1.size()) {
		s2 = mp[x];
		if (s1 > s2) swap(s1, s2);
		return s1 + '[' + s2 + ']';
	}
	else return mp[x];
}
void solve() {
	cnt = 0;
	memset(fir, 0, sizeof(fir));
	string s;
	cin >> s;
	memset(isl, 0, sizeof(isl));
	int n = s.size();
	for (int i = 1; i <= n; i++) {
		if (mp[i].size()) mp[i] = "";	
	}
	s = " " + s;
	int cnt = 0;
	string tmp;
	int last = 1, klast = 1;
	for (int i = 1; i <= n; i++) {
		if (s[i] >= 'a' && s[i] <= 'z')
			tmp += s[i];
		else if (s[i] == '[') {
			if (!mp[last].size())
				mp[last] = tmp;
//			write(last), cout << tmp << " " << i << endl;
			stk.push(i);
			tmp = "";
			isl[i] = last;
			last = i;
		}
		else {
			int x = stk.top();
			stk.pop();
			add(isl[x], x);
//			if (i == 4) cout << mp[x].size() << endl;
			if (!mp[x].size())
				mp[x] = tmp;
			tmp = "";
		}
	}
	printf("%s\n", dfs(1).c_str());
}
int main() {
	freopen("subscript.in", "r", stdin);
	freopen("subscript.out", "w", stdout);]
	int T = read();
	while (T--) solve();
	return 0;	
}
