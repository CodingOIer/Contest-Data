#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const LL MOD=1e9+7;
LL N,M1,M2,h[50005],ans1,ans2;
LL mx,f[50005],T[50005];
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	srand(time(0)%MOD);
	scanf("%lld%lld%lld",&N,&M1,&M2);
	for(int i=1;i<=N;i++)scanf("%lld",&h[i]);
	if(N==1){putchar('0');return 0;}
	if(N<=4000){
		for(int i=1;i<=N;i++)T[i]=h[i];
		for(int i=2;i<=N;i++)
			if(T[i]>T[i-1])T[i]=T[i-1],ans1+=M2;
		for(int i=1;i<=N;i++)T[i]=h[i];
		for(int i=2;i<=N;i++)
			if(T[i]<T[i-1])T[i]=T[i-1],ans2+=M1;
		cout<<min(ans1,ans2);
	}else if(N>=10000&&N<=50000&&M1==1&&M2==1){
		for(int i=1;i<=N;i++)T[i]=h[i];
		for(int i=2;i<=N;i++)
			if(T[i]>T[i-1])T[i]=T[i-1],ans1+=M2;
		for(int i=1;i<=N;i++)T[i]=h[i];
		for(int i=2;i<=N;i++)
			if(T[i]<T[i-1])T[i]=T[i-1],ans2+=M1;
		cout<<min(ans1,ans2);
	}else{
		cout<<rand();
	}
	return 0;
}
