#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long LL;
const LL MOD=1e9+7;
LL N,M,K;
LL gsc(LL X,LL P){
	if(X==1||P==0)return 1;
	if(P==1)return X;
	LL ret=1;
	while(P){
		if(P&1)ret=ret*X%MOD;
		X=X*X%MOD;
		P>>=1;
	}
	return ret%MOD;
}//��һ������Ԫ��ϣ����Ҫ����QAQ 
LL inv(LL QWQ){return gsc(QWQ,MOD-2);}
LL A(LL n,LL m){
	LL ret=1;
	for(LL cnt=1,i=n;cnt<=m;cnt++,i--)
		ret=ret*i%MOD;
	return ret%MOD;
}
LL C(LL n,LL m){return A(n,m)*inv(A(m,m))%MOD;}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>N>>M>>K; 
	if(N-K<M-1){putchar('0');return 0;}
	LL ans=C(N-K,M-1);
	printf("%lld",ans);
	return 0;
}
