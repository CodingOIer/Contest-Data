#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL T,sum[200005],inx[200005],len;
char s[200005];
void init(){//Ԥ���� 
	scanf("%s",s);len=strlen(s);
	for(int i=0;i<len;i++)
		sum[i]=(i==0?0:sum[i-1]+(s[i]=='['||s[i]==']'));
	stack<int>stk;
	for(int i=0;i<len;i++){
		if(s[i]=='[')stk.push(i);
		else if(s[i]==']')inx[stk.top()]=i,stk.pop();
		inx[i]=0;
	}
}
void Swap(LL l1,LL r1,LL l2,LL r2){
	char temp[200005];
	LL p=l1;
	for(int i=l2;i<=r2;i++)temp[p++]=s[i];
	for(int i=r1+1;i<=l2-1;i++)temp[p++]=s[i];
	for(int i=l1;i<=r1;i++)temp[p++]=s[i];
	for(int i=l1;i<=r2;i++)s[i]=temp[i];
}
int cmp(LL l1,LL r1,LL l2,LL r2){	
	LL p=l1,q=l2;        	     
	while(1){                    
		if(s[p]<s[q])return 1;
		if(s[p]>s[q])return 0;
		if(p==r1&&q<r2)return 1;
		if(q==r2&&p<r1)return 0;
		if(p>r1||q>r2)break;
		p++;q++;
	}
	return 1;
}
void solve(LL L,LL R){//�ݹ�,����! 
	//cout<<"now solving L: "<<L<<" R: "<<R<<endl;
	if(L>R)return;
	if(L==0&&sum[R]==0)return; 
	if(sum[R]-sum[L-1]==0)return;
	LL p=L;
	while(p<R){
		while(!inx[p]&&p<R)p++;
		if(p>=R)return;
		int L1=p+1,R1=inx[p]-1;
		solve(L1,R1);solve(L,p-1);
		if(!cmp(L,p-1,L1,R1))Swap(L,p-1,L1,R1);
		p=inx[p]+1;
		if(s[p]!='['&&s[p]!=']')
		{solve(p,R);return;}
	}
	return;
}
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		init();
		solve(0,len-1);
		puts(s);
	} 
	return 0;
}
/*
4
aaa[bbb]
a[b[abbb]]
b[a[azzz]]
x[a][b[a]]
*/
