#include<bits/stdc++.h>
using namespace std ;
int t ;
char a[123456] ;
int l[123456] , r[123456] ;
bool f(string a,string b) {
	if(a.size()==b.size()) {
		for(int i=0; i<a.size(); i++) {
			if(a[i]!=b[i]) return a[i]>b[i] ;
		}
	}
	return a.size()>b.size() ;
}
int main() {
	freopen("subscript.in","r",stdin) ;
	freopen("subscript.out","w",stdout) ;
	cin >> t ;
	while(t--) {
		scanf("%s",a) ;
		string s[1234] ;
		bool ant = 0 ;
		int size = strlen(a) , m=0 , lk=0 , rk=0 ;
		for(int i=0; i<size; i++) {
			if(a[i]>='a'&&a[i]<='z') {
				s[m] += a[i] ;
				ant = 1 ;
			} else {
				if(ant) {
					ant = 0 ;
					m++ ;
				}
				if(a[i]==']')
					r[rk++] = m-1 ;
				else if(a[i]=='[')
					l[lk++] = m ;
			}
		}
//		cout << m ;
		for(int i=0; i<m; i++) {
			for(int j=i+1; j<m&&f(s[i],s[j]); j++) {
				swap(s[i],s[j]) ;
//				cout << i << " " << j << "     " ;
//				for(int i=0; i<m; i++) {
//					cout << s[i] << " " ;
//				}
//				cout << '\n' ;
			}
		}
		lk = rk = 0 ;
		for(int i=0; i<=m; i++) {
			if(i==l[lk]) {
				while(i==l[lk]) {
					cout << '[' ;
					lk++ ;
				}
			}
			cout << s[i] ;
			if(i==r[rk]) {
				while(i==r[rk]) {
					cout << ']' ;
					rk++ ;
				}
			}
		}
		cout << endl ;
	}
	return 0 ;
}
