#include<bits/stdc++.h>
using namespace std ;
const int mid = 1E+9+7 ;
int n , m , k , ans=0 ;
bool t[1234567] ;
void dfs(int sum,int l) {
	if(sum==m&&t[k]) {
		ans++ ;
		ans %= mid ;
		return ;
	}
	for(int i=l; i<=n; i++) {
		if(!t[i]) {
			t[i] = 1 ;
			dfs(sum+1,i) ;
			t[i] = 0 ;
		}
	}
}
int main() {
	freopen("ball.in","r",stdin) ;
	freopen("ball.out","w",stdout) ;
	cin >> n >> m >> k ;
	dfs(0,k) ;
	cout << ans ;
	return 0 ;
}
