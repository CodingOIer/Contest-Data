#include<bits/stdc++.h>
using namespace std ;
int n , m1 , m2 , a[12345] , s1=0 , s2=0 , t1[12345] , t2[12345] ;
int main() {
	freopen("robot.in","r",stdin) ;
	freopen("robot.out","w",stdout) ;
	cin >> n >> m1 >> m2 ;
	for(int i=0; i<n; i++) {
		scanf("%d",a+i) ;
		t1[i] = a[i] ;
		t2[i] = a[i] ;
	}
	for(int i=1; i<n; i++) {
		if(t1[i+1]>t1[i-1]) {
			s1 += m2 ;
			t1[i+1] = t1[i-1] ;
		} else if(t1[i]<t1[i+1]) {
			s1 += m1 ;
			t1[i] = t1[i+1] ;
		}
	}
	for(int i=n-2; i+1; i--) {
		if(t2[i]>t2[i-1]) {
			s2 += m2 ;
			t2[i] = t2[i-1] ;
		}
	}
	cout << min(s1,s2) ;
	return 0 ;
}
