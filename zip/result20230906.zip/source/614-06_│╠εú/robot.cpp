#include<bits/stdc++.h>
using namespace std;
long long h[60000],n,m1,m2;
long long ans1,ans2,id=1,id1=1;
map<long long ,long long >a,b;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	cin>>h[1];
	for(int i=2; i<=n; i++) {
		cin>>h[i];
	}
	a[1]=h[1];
	b[1]=h[1];
	for(int i=2; i<=n; i++) {
		
			if(a[id]<h[i]) ans1+=m2;
			else a[++id]=h[i];
		
	}
	for(int i=2; i<=n; i++) {
			if(b[id1]>h[i]) ans2+=m1;
			else b[++id1]=h[i];
		
	}
	cout<<min(ans1,ans2);
	return 0;
}

