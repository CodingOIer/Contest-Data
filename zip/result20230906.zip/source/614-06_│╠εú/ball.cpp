#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
long long n,m,k,ans=1,b[1000000];
int main()

{freopen("ball.in","r",stdin);
freopen("ball.out","w",stdout);
cin>>n>>m>>k;
b[0]=1;
for(long long j=n-k, i=1;i<=m;i++,j--){
	ans=ans*j%mod;
}
cout<<ans;
return 0;
}
