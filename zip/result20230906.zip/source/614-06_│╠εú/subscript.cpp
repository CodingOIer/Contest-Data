#include<bits/stdc++.h>
using namespace std;
string s;
long long n;

int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
cin>>n;
for(int i=1;i<=n;i++){
	cin>>s;
	cout<<s<<endl;
}
	return 0;
}

