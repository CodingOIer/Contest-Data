#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,m,k;
int C(int a,int b){
	int res1=1,res2=1;
	int p=b;
	for(int i=1;i<=a;i++){
		res1*=p;
		p--;
	}
	int q=a;
	for(int i=1;i<=a;i++){
		res2*=q;
		q--;
	}
	return res1/res2;
}
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	cout<<C(n-m-1,n-k)<<endl;
	return 0;
}

