#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
signed main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		string s;
		cin>>s;
		int k=s.size();
		if(s.size()<=2){
			sort(s.begin(),s.end());
			cout<<s<<endl;
		}
		else if(s.size()<=4){
			string t;
			int flag=0;
			for(int i=0;i<k;i++){
				if(s[i]=='[' || s[i]==']') flag=1;
				else t+=s[i];
			}
			sort(t.begin(),t.end());
			if(flag) cout<<t[0]<<'['<<t[1]<<']'<<endl;
			else cout<<s<<endl;
		}
		else{
			string m[10],l;
			int flag=0,cnt=0;
			for(int i=0;i<k;i++){
				if(s[i]=='[' || s[i]==']'){
					m[++cnt]=l;
					l="";
					flag=1;	
				}
				else l+=s[i];
			}
//			cout<<m[1]<<'['<<m[2]<<']'<<endl;
			if(flag){
				sort(m+1,m+1+cnt);
				cout<<m[1]<<'['<<m[2]<<']'<<endl;	
			}
			else cout<<s<<endl;
		}
	}
	return 0;
}

