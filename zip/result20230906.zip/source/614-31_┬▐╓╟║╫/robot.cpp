#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=5e4+5;
int n,p,q,ans1,ans2;
int a[maxn],b[maxn],f[maxn];
signed main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>p>>q;
	for(int i=1; i<=n; i++) cin>>a[i],b[i]=a[i];
	for(int i=1; i<=n; i++) {
		if(a[i-1]<=a[i]) continue;
		else {
			if(a[i]>a[i-1]) ans1+=q;
			else ans1+=p;
			a[i]=a[i-1];
		}
	}
	for(int i=n; i>=1; i--) {
		if(b[i+1]<=b[i]) continue;
		else {
			if(b[i+1]<b[i]) ans2+=q;
			else ans2+=p;
			b[i+1]=b[i];
		}
	}
	cout<<min(ans1,ans2)<<endl;
	return 0;
}

