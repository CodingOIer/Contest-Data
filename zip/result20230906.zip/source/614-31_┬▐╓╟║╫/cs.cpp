#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	srand(time(NULL));
	cout<<rand()%10+1<<endl;
	return 0;
}

