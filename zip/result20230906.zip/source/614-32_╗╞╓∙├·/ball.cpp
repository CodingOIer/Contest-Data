#include <bits/stdc++.h>
#define int long long

using namespace std;
const int mod=1e9+7,N=1000006;
int n,m,k,ans=1,f[N];
int ksm(int x,int p){
	int ans=1;
	for(;p;p>>=1){
		if(p&1) ans=ans*x%mod;
		x=x*x%mod; 
	}return ans%mod;
}
int C(int x,int y){
	return f[x]*ksm(f[y]*f[x-y]%mod,mod-2)%mod;
}
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	f[0]=1;
	for(int i=1;i<=N;i++)f[i]=f[i-1]*i%mod; 
	scanf("%lld%lld%lld",&n,&m,&k);
	int S=n-k;
//	cout << n << "\n";
	printf("%lld",C(S,m-1));
	
	return 0;
}
/*4 3 1

1 2 3 4 
1 2 3 4 5 
*/
