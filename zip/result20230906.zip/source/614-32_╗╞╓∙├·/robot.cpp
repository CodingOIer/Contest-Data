#include <bits/stdc++.h>
#define int long long
#define debug1 cout << ans1<<"\n";
#define debug2 cout << ans2<<"\n";
using namespace std;
const int N=5e4+5;
int n,m1,m2;
struct node{
	int h,id;	
}a[N];
int h_id[N],val[N],G[N],ans1,ans2,ans;
int q[N],tot;
signed main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m1,&m2);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].h),a[i].id=i,val[i]=a[i].h;
	sort(val+1,val+n+1);
	for(int i=1;i<=n;i++) h_id[a[i].id]=lower_bound(val+1,val+n+1,a[i].h)-val,G[i]=h_id[i];
	if(m1==1 && m2==1){
		int ans1=0,ans2=0;
		for(int i=1;i<n;i++){
			if(h_id[i]<h_id[i+1]) h_id[i]=h_id[i-1],ans1++;
		}for(int i=1;i<=n;i++) h_id[i]=G[i];
		for(int i=1;i<n;i++){
			if(h_id[i]>h_id[i+1]) h_id[i]=h_id[i-1],ans2++;
		}
		cout <<min(ans1,ans2);
		return 0;
	}
	for(int i=n;i>=1;i--){
		if(h_id[i]<h_id[i+1] && h_id[i-1]>h_id[i+1] && i<n && i>1) h_id[i]=h_id[i-1],ans1+=m1;
		else if(h_id[i]>h_id[i-1] && i>1) h_id[i]=h_id[i-1],ans1+=m2;
	}
	if(h_id[n]>h_id[n-1]) ans1+=m2;
	
	for(int i=1;i<=n;i++) h_id[i]=G[i];
	for(int i=n;i>=1;i--){
		if(h_id[i]>h_id[i+1] && h_id[i-1]>h_id[i+1] && i<n && i>1) h_id[i]=h_id[i-1],ans2+=m2;
		else if(h_id[i]<h_id[i-1] && i>1) h_id[i]=h_id[i-1],ans2+=m1;
	}
	if(h_id[n]<h_id[n-1]) ans2+=m1;
	cout <<min(ans1,ans2);
	return 0;
}
/*
10 2 3
10 6 3 1 8 7 4 2 5 9
15 1 1
10 10 10 10 10 9 2 8 7 6 1000 5 3 4 1
0������1�Ǽ�С 
*/
