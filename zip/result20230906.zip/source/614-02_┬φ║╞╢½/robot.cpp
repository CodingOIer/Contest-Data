#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e5+5;
int n,m1,m2,ans;
int a[Max],b[Max];
int check(){
	int sum=0;
	for(int i=1;i<=n;i++)
		if(b[i-1]<=b[i+1]){
			if(b[i]<b[i-1]) b[i]=b[i-1];
			if(b[i]>b[i+1]) b[i]=b[i+1];
		}
		else{
			if(b[i+1]<b[i]) b[i+1]=b[i];
			if(b[i-1]>b[i]) b[i-1]=b[i];
		} 
	for(int i=1;i<=n;i++)
		if(b[i]>a[i]) sum+=m1;
		else if(b[i]<a[i]) sum+=m2;
	//cout<<sum;
	//for(int i=1;i<=n;i++) cout<<b[i]<<" ";
	//cout<<"\n";
	return sum;
}
int check2(){
	int sum=0;
	for(int i=1;i<=n;i++)
		if(b[i-1]>=b[i+1]){
			if(b[i]>b[i-1]) b[i]=b[i-1];
			if(b[i]<b[i+1]) b[i]=b[i+1];
		}
		else{
			if(b[i+1]>b[i]) b[i+1]=b[i];
			if(b[i-1]<b[i]) b[i-1]=b[i];
		} 
	for(int i=1;i<=n;i++)
		if(b[i]>a[i]) sum+=m1;
		else if(b[i]<a[i]) sum+=m2;
	//cout<<sum;
	//for(int i=1;i<=n;i++) cout<<b[i]<<" ";
	//cout<<"\n";
	return sum;
}
signed main(){
	freopen("robot.in","r",stdin);
	freopen("rpbot.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m1,&m2);
	for(int i=1;i<=n;i++) scanf("%lld",a+i),b[i]=a[i];
	ans=check();
	for(int i=1;i<=n;i++) b[i]=a[i];
	ans=min(ans,check2());
	printf("%lld",ans);
	return 0;
}



