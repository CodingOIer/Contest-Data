#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e5+5,mod=1e9+7;
int n,m,k,ans=1;
int a[Max];
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	n-=k;
	m--;
	if(!m) return cout<<n+1,0;
	if(m==1) return cout<<n,0;
	for(int i=n;i>=n-m;i--) ans=(ans*i)%mod;
	a[1]=1;
	for(int i=2;i<=m;i++) a[i]=(a[i-1]*i)%mod;
	ans=ans/a[m];
	cout<<ans;
	return 0;
}
/*
*/

