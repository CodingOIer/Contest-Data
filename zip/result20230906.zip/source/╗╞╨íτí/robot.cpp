#include<bits/stdc++.h>
using namespace std;
long long w=0,k,n,m,s=0,a[50010],b=0,c=0,d=0;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		if(a[i]>a[i-1])
			d++;
	}
	for(int i=n;i>1;i--)
	{
		if(a[i]<a[i-1])
			c++;
	}
	w=min(d,c);
	cout<<w;
	return 0;
}
