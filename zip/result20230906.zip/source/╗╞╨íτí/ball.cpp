#include<bits/stdc++.h>
using namespace std;
long long w,k,n,m,s=1,a=1000000007;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	w=n-k;
	for(long long i=1;i<=m;i++)
	{
		s*=w;
		w--;
		s=s%a;
	}
	cout<<s;
	return 0;
}


