#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod = 1e9+7;
const int mx = 5e5;
int n;
vector<string> ans;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin >> n;
	while(n--)
	{
		stack<pair<int,int>> tmp;
		vector<pair<int,int>> kh;
		string s;
		cin >> s;
		for(int i = 0;i < s.length();i++)
		{
			if(s[i] == '[')
			{
				pair<int,int> t;
				t.first = i;
				tmp.push(t);
			}
			if(s[i] == ']')
			{
				pair<int,int> t = tmp.top();
				tmp.pop();
				t.second = i;
				kh.push_back(t);
			}
		}
		cout << s << endl;
//		for(auto i : kh) cout << i.first << " " << i.second << endl;
	}
	return 0;
}

