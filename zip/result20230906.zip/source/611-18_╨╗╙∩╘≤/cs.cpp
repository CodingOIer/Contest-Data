#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod = 1e9+7;

int main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	pair<int,int> a;
	a.first = 1;
	a.second = 2;
	return 0;
}

