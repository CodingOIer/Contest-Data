#include <bits/stdc++.h>
using namespace std;
#define ll long long
const ll mod = 1e9+7;
ll n,m,k;
ll ans = 2;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin >> n >> m >> k;
	cout << ans;
	return 0;
}
