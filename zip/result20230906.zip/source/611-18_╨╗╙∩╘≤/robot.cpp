#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod = 1e9+7;
int n,m1,m2;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin >> n >> m1 >> m2;
	vector<int> h(n),a(n),c(n);
	bool asd = 0;
	for(int i = 0;i < n;i++) cin >> h[i],a[i] = c[i] = h[i],asd = (h[i]==1||h[i]==2?true:false);
	if(asd)
	{
		int s = 0,b = 0;
		for(int i = 0;i < n;i++)
		{
			if(h[i] == 1) s++;
			if(h[i] == 2) b++;
		}
		cout << min(s,b);
	}
	else
	{
		int sum1 = 0,sum2 = 0;
		for(int i = 1;i < n;i++) if(a[i-1] > a[i]) a[i] = a[i-1],sum1+=m1;
		for(int i = 1;i < n;i++) if(c[i] > c[i-1]) c[i] = c[i-1],sum2+=m2;
		cout << min(sum1,sum2);
	}
	return 0;
}

