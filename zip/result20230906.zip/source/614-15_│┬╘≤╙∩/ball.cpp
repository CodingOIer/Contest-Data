#include<bits/stdc++.h>
#define int long long
using namespace std;
int init(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	return 0;
}
const int init_=init(),maxn=2e5+10,mod=1e9+7;
inline int pow_(int x){return x*x;}
inline int ksm(int x,int k){return !k?1:(int)pow_(ksm(x,k/2))%mod*(k&1?x:1)%mod;}
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-';
	do n=n*10+c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int n=read(),m=read()-1,k=read(),a=1,b=1;

signed main(){
	n-=k;
	if(m>n) write(0),exit(0);
	for(int i=1;i<=m;++i) (a*=n-i+1)%=mod,b=b*i%mod;
	write(a*ksm(b,mod-2)%mod);
	return 0;
}
