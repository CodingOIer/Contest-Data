#include<bits/stdc++.h>
#define int long long
using namespace std;
int init(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	return 0;
}
const int init_=init(),maxn=2e5+10,mod=1e9+7;
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-';
	do n=n*10+c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int top;
char tmp[maxn];
string ans[maxn];
set<string> t;
bool cmp(string a,string b){
	int i=0,j=0;
	for(;i<a.size()&&j<b.size();++i,++j){
		while(i<a.size()&&(a[i]=='['||a[i]==']')) ++i;
		while(j<b.size()&&(b[j]=='['||b[j]==']')) ++j;
		if(a[i]<b[j]) return 1;
		if(a[i]>b[j]) return 0;
	}
	if(i==a.size()&&j<b.size()) return 1;
	return 0;
}
string dfs(string s,int l,int r){
	int cnt=0,look=0,split=-1;
	string ans,a,b;
	for(int i=r-1;i>=l;--i){
		ans=s[i]+ans;
		if(s[i]==']') cnt++,look=1;
		if(s[i]=='[') cnt--;
		if(!cnt&&look){
			split=i;
			break;
		}
	}
	if(split!=-1) a=dfs(s,l,split),b=dfs(s,split+1,r-1);
	else return ans;
	if(!cmp(a,b)) swap(a,b);
	return a+'['+b+']';
}

signed main(){
	for(int T=read();T--;){
		scanf("%s",tmp);
		string s=tmp;
		ans[++top]=dfs(s,0,s.size());
	}
	sort(ans+1,ans+top+1,cmp);
	for(int i=1;i<=top;++i) cout<<ans[i]<<endl;
	return 0;
}
