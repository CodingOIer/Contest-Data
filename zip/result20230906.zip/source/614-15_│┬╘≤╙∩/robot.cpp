#include<bits/stdc++.h>
#define int long long
using namespace std;
int init(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	return 0;
}
const int init_=init(),maxn=2e5+10,mod=1e9+7;
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-';
	do n=n*10+c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int n=read(),m1=read(),m2=read(),a[maxn],c1[maxn],c2[maxn];

signed main(){
	for(int i=1;i<=n;++i) a[i]=read();
	if(m1==m2) if(n<=4000){
		int ans1=INT_MAX,ans2=INT_MAX;
		for(int i=1;i<=n;++i){
			int cnt=0;
			for(int j=i-1,tmp=a[i];j;--j) if(a[j]<tmp) cnt+=m1;
			else tmp=a[j];
			for(int j=i+1,tmp=a[i];j<=n;++j) if(a[j]>tmp) cnt+=m2;
			else tmp=a[j];
			ans1=min(ans1,cnt);
		}
		for(int i=1;i<=n;++i){
			int cnt=0;
			for(int j=i-1,tmp=a[i];j;--j) if(a[j]>tmp) cnt+=m2;
			else tmp=a[j];
			for(int j=i+1,tmp=a[i];j<=n;++j) if(a[j]<tmp) cnt+=m1;
			else tmp=a[j];
			ans2=min(ans2,cnt);
		}
		write(min(ans1,ans2));
		return 0;
	}
	else{
		int ans=INT_MAX;
		for(int i=1;i<=n;++i){
			c1[i]=c1[i-1],c2[i]=c2[i-1];
			if(a[i]-1) c2[i]++;
			else c1[i]++;
		}
		for(int i=1;i<=n;++i) ans=min(ans,min(c1[i]+c2[n]-c2[i],c2[i]+c1[n]-c1[i]));
		write(ans);
		return 0;
	}
	return 0;
}
