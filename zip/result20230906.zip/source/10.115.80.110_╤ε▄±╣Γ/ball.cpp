#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
long long sum=1,cnt=1,cc=1;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	long long n,m,k;
	cin>>n>>m>>k;
	if(m==1){
		cout<<1;
	} 
	else if(m==2){
		cout<<n-k;
	}
	else if(k==n){
		cout<<0;
	}
}
//a!/b!/m!
