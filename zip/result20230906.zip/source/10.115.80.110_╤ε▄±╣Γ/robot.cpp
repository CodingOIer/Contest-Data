#include<bits/stdc++.h>
using namespace std;
int a[50001],b[50001];
long long ans,as;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i]<a[i-1]&&a[i]<a[i+1]&&a[i-1]<a[i+1]){
			ans+=min(k,2*m);
			i+=2;
		}
		if(a[i]<a[i-1]&&a[i]<a[i+1]&&a[i-1]>a[i+1]){
			ans+=min(2*k,m);
			i+=2;
		}
		if(a[i]>a[i-1]&&a[i]>a[i+1]&&a[i-1]<a[i+1]){
			ans+=min(2*k,m);
			i+=2;
		}
		if(a[i]>a[i-1]&&a[i]>a[i+1]&&a[i-1]>a[i+1]){
			ans+=min(k,2*m);
			i+=2;
		}
	}
	cout<<ans;
}
