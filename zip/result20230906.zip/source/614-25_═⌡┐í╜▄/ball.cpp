#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k,ans;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(m==1) 
	{
		printf("1");
		return 0;
	}
	n-=k,m--;
	for(int i=1;i<=n-m+1;i++)
	{
		ll sum=1;
		for(int j=1;j<m;j++)
		{
			sum=(sum*(n-i-j+1))%1000000007;
		}
		ans=(ans+sum)%1000000007;
	}
	printf("%d",ans);
	return 0;
}
