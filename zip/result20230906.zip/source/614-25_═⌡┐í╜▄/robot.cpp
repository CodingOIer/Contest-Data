#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,m2,h[50005],b[50005],a[50005],sum,ans;
int main(){
  freopen("robot.in","r",stdin);
  freopen("robot.out","w",stdout);
	scanf("%d%d%d",&n,&m,&m2);
	for(int i=1;i<=n;i++)
		scanf("%d",&h[i]);
	a[1]=h[1];
	b[1]=h[1];
	for(int i=2;i<=n;i++)
	{
		if(h[i]>a[i-1]) 
		{
			if((i==n || h[i+1]<=a[i-1]) && m2<=m) ans+=m2,a[i]=a[i-1];
			else if(a[i-2]>=h[i]) a[i]=h[i],a[i-1]=a[i-2],ans+=m;
			else a[i]=a[i-1],ans+=m2;
		}
		else a[i]=h[i];
		if(h[i]<b[i-1])
		{
			if((i==n || h[i+1]>=b[i-1]) && m<=m2) sum+=m,b[i]=a[i-1];
			else if(b[i-2]<=h[i]) b[i]=h[i],b[i-1]=b[i-2],sum+=m2;
			else b[i]=b[i-1],sum+=m;
		}
		else b[i]=h[i];
	}
//	printf("%d\n",ans);
//	for(int i=1;i<=n;i++)
//	{
//		cout<<a[i]<<" ";
//	}
//	cout<<'\n';
//	printf("%d\n",sum);
//	for(int i=1;i<=n;i++)
//	{
//		cout<<b[i]<<" ";
//	}
//	cout<<'\n';
	printf("%d",min(ans,sum));
	return 0;
}
