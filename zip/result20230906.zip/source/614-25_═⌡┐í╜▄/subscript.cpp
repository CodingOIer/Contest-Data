#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
string s; 
int main(){
  freopen("subscript.in","r",stdin);
  freopen("subscript.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		cout<<s<<endl;
	}
	return 0;
}

