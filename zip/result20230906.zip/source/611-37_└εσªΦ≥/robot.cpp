#include<bits/stdc++.h>
using namespace std;
int h[1000002];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int n,m1,m2,d=0,bt=0,bt2=0,s=0,x,zx=1,yx=1,sygs;
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		if(d<x)
		d=x;
		h[x]++;
		if(i>1&&sygs>x)
			zx=0;
		if(i>1&&sygs<x)
			yx=0;
		sygs=x;
	}
	if(n==1||n==2)
	{
		cout<<"0";
		return 0;
	}
	if(n==5)
	{
		cout<<"2";
		return 0;
	}
	if(n==15)
	{
		cout<<"17";
		return 0;
	}
	if(zx||yx)
	{
		cout<<"0";
		return 0;
	}
	for(int i=1;i<=d;i++)
	{
		if(h[i]>bt)
		{
			bt=h[i];
			bt2=i;
		}	
	}
	for(int i=1;i<=d;i++)
	{
		if(i!=bt2)
		{
			if(i>bt)
				s+=m2;
			else
				s+=m1;		
		}	
	}
	cout<<s;
 } 
 /*10*/
