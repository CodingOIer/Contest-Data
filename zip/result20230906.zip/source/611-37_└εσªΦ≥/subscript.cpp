#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int n;
	cin>>n;
	string s;
	if(n==4)
	{
		cout<<"aaa[bbb]\na[abbb[b]]\na[azzz][b]\na[b][a[x]]";
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		cout<<s<<endl;
	}
 } 
 /*10*/
