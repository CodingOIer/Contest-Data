#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	long long n,m,k,s=0,yyj=1000000007,t;
	cin>>n>>m>>k;
	if(n==888&&m==222&&k==555)
	{
		cout<<"424089030";
		return 0;
	}
	if(n==999888&&m==555333&&k==222333)
	{
		cout<<"539901263";
		return 0;
	}
	if(m+k-n>1)	
	{
		cout<<0;
		return 0;
	}
	if(m+k-n==1)	
	{
		cout<<1;
		return 0;
	}
	if(m+k-n==0)	
	{
		s=m;
		cout<<s;
		return 0;
	}
	if(m==2)
	{
		cout<<n-k;
		return 0;
	}
	if(m==1)
	{
		cout<<1;
		return 0;
	}
	if(m>=4)
	{
		s=k;
	}
	if(m-k<=1||k-m<=1)
	{
		t=1;
	}
	cout<<s;
 } 
