#include<bits/stdc++.h>
using namespace std;

string a[100010], tmp[100010];
int main() {
	freopen("subscript.in", "r", stdin);
	freopen("subscript.out", "w", stdout);
	int T;
	cin >> T;
	while(T--) {
		string s;
		int f = 0;
		cin >> s;
		int cnt = 1, Mini = 1, cnt2 = 0;
		string Min = "{";
		memset(tmp, 0, sizeof(tmp));
		for(int i = 0; i < s.size(); i++) {
			if(s[i] == '[') {
				f++;
				++cnt;
			} else if(s[i] == ']') {
				f--;
				if(f == 0) {
					string ss;

					for(int i = 1; i <= cnt; i++) {
						if(tmp[i] < Min) {
							Min = tmp[i];
							Mini = i;
						}
					}
					ss += tmp[Mini];
					if(cnt > 2 && Mini < cnt - 1) if(tmp[cnt - 1] > tmp[cnt]) swap(tmp[cnt - 1], tmp[cnt]);
					for(int i = Mini + 1; i <= cnt; i++) ss += '[' + tmp[i];

					for(int i = 1; i <= cnt - Mini; i++) ss += ']';
					for(int i = Mini - 1; i >= 1; i--) ss += '[' + tmp[i] + ']';

					memset(tmp, 0, sizeof(tmp));
					cnt = 0;
					Min = "{";
					a[++cnt2] = ss;
				}
			} else tmp[cnt] += s[i];
		}
		if(cnt2 > 1) {
			for(int i = 1; i <= cnt2; i++) {
				if(a[i] < Min) {
					Min = a[i];
					Mini = i;
				}
			}
			string ans;
			if(Mini > 1) ans += a[Mini] + '[' + a[1];
			else ans += a[Mini];
			for(int i = 2; i < Mini; i++) ans += '[' + a[i] + ']';
			ans += ']';
			for(int i = Mini + 1; i <= cnt2; i++) ans += '[' + a[i] + ']';
			cout << ans << endl;
		}
		else cout << a[1] << endl;
	}
}
