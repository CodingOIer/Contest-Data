#include<bits/stdc++.h>
#define int long long
using namespace std;

const int Mod = 1e9 + 7;
int ksm(int x, int y) {
	int res = 1, pw = x;
	while(y) {
		if(y % 2) res = (res * pw) % Mod;
		pw = (pw * pw) % Mod;
		y /= 2;
	}
	return res % Mod;
}
signed main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	int n, m, k;
	cin >> n >> m >> k;
	int t = n - k, ans = 1;
	m--;
	if(t < m) {
		cout << 0;
		return 0;
	}
	for(int i = 1; i <= t; i++) ans = (ans * i) % Mod;
	for(int i = 1; i <= m; i++) ans = (ans * ksm(i, Mod - 2)) % Mod;
	for(int i = 1; i <= t - m; i++) ans = (ans * ksm(i, Mod - 2)) % Mod;
	cout << ans;
}
