#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 5e4 + 10;
int a[N], tree[N * 4], tag[N * 4];
int ls(int k) {return k * 2;}
int rs(int k) {return k * 2 + 1;}
void addtag(int p, int d) {
	tag[p] = d;
	tree[p] = d;
}
void push_down(int p) {
	if(tag[p]) {
		addtag(ls(p), tag[p]);
		addtag(rs(p), tag[p]);
		tag[p] = 0;
	}
}
void update(int L, int R, int p, int pl, int pr, int d) {
	if(L <= pl && pr <= R) {
		addtag(p, d);
		return;
	}
	push_down(p);
	int mid = (pl + pr) / 2;
	if(L <= mid) update(L, R, ls(p), pl, mid, d);
	if(R > mid) update(L, R, rs(p), mid + 1, pr, d);
	tree[p] = tree[ls(p)] + tree[rs(p)];
}
int query(int L, int R, int p, int pl, int pr) {
	if(L <= pl && pr <= R) return tree[p];
	push_down(p);
	int mid = (pl + pr) / 2, res = 0;
	if(L <= mid) res += query(L, R, ls(p), pl, mid);
	if(R > mid) res += query(L, R, rs(p), mid + 1, pr);
	return res;
}
signed main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	int n, m1, m2, sum = 0, sum2 = 0;
	cin >> n >> m1 >> m2;
	for(int i = 1; i <= n; i++) cin >> a[i];
	
	
	update(1, 1, 1, 1, n, a[1]);
	for(int i = 2; i <= n; i++) {
		if(a[i] <= query(i - 1, i - 1, 1, 1, n)) update(i, i, 1, 1, n, a[i]);
		else {
			int l = 1, r = i - 1, ans = -1;
			while(l <= r) {
				int mid = (l + r) / 2;
				if(query(mid, mid, 1, 1, n) >= a[i]) {
					ans = mid;
					l = mid + 1;
				}
				else r = mid - 1;
			}
			int p = 1e9;
			if(ans != -1) p = (i - ans - 1) * m1;
			if(p < m2) update(ans + 1, i, 1, 1, n, a[i]);
			else update(i, i, 1, 1, n, query(i - 1, i - 1, 1, 1, n));
			sum += min(p, m2);
		}
	}
	
	memset(tree, 0, sizeof(tree));
	memset(tag, 0, sizeof(tag));
	update(1, 1, 1, 1, n, a[1]);
	for(int i = 2; i <= n; i++) {
		if(a[i] >= query(i - 1, i - 1, 1, 1, n)) update(i, i, 1, 1, n, a[i]);
		else {
			int l = 1, r = i - 1, ans = -1;
			while(l <= r) {
				int mid = (l + r) / 2;
				if(query(mid, mid, 1, 1, n) <= a[i]) {
					ans = mid;
					l = mid + 1;
				}
				else r = mid - 1;
			}
			int p = 1e9;
			if(ans != -1) p = (i - ans - 1) * m2;
			if(p < m1) update(ans + 1, i, 1, 1, n, a[i]);
			else update(i, i, 1, 1, n, query(i - 1, i - 1, 1, 1, n));
			sum2 += min(p, m1); 
		}
	}
	cout << min(sum, sum2);
}
