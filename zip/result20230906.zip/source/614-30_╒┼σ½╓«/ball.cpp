#include <bits/stdc++.h>
#define ll long long 
using namespace std;

/*
�������ת��Ϊ�� k~n ȡ m ����Ҳ���� C(n - k, m - 1)  
*/
const ll mod = 1e9 + 7;
ll n, m, k, ans;

ll fac(ll x) {
	ll ans = 1;
	for (int i = 1; i <= x; i++) ans = ans * i % mod;
	return ans;
}

ll inv(ll a) {
	ll b = mod - 2, ans = 1;
	while (b) {
		if (b & 1) ans = ans * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return ans % mod;
}

ll C(ll n, ll m) {
	return n < m ? 0 : fac(n) * inv(fac(n - m)) % mod * inv(fac(m)) % mod;
}

int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &k);
	printf("%lld", C(n - k, m - 1));
	return 0;
}
