#include <bits/stdc++.h>
using namespace std;

int n, m1, m2;
int a[50005];

namespace d1 {
	int num[50005], arr[50005];
	int ans = 2e9;

	bool check1() {
		for (int i = 1; i <= n; i++) {
			if (!num[i]) {
				arr[i] = a[i];
				if (arr[i] < arr[i - 1]) return 0;
			}
			else if (num[i] == 1)
				if (a[i] < a[i - 1]) arr[i] = arr[i - 1];
			else
				if (a[i] > a[i - 1]) arr[i] = arr[i - 1];
		}
		return 1;
	}

	bool check2() {
		for (int i = 1; i <= n; i++) {
			if (!num[i]) {
				arr[i] = a[i];
				if (arr[i] > arr[i - 1]) return 0;
			}
			else if (num[i] == 1)
				if (a[i] < a[i - 1]) arr[i] = arr[i - 1];
			else
				if (a[i] > a[i - 1]) arr[i] = arr[i - 1];
		}
		return 1;
	}

	void dfs(int cur) {
		if (cur > n) {
			if (check1() || check2()) {
				int sum = 0;
				for (int i = 1; i <= n; i++) sum += a[i] != 0;
				ans = min(ans, sum);
			}
			return;
		}
		for (int i = 0; i < 3; i++) {
			num[cur] = i;
			dfs(cur + 1);
		}
	}

	int d() {
		dfs(1);
		return ans;
	}
}

namespace d2 {
	int ans = 2e9;
	int sum[50005][2];

	int d() {
		for (int i = 1; i <= n; i++) {
			sum[i][0] = sum[i - 1][0] + (a[i] == 1);
			sum[i][1] = sum[i - 1][0] + (a[i] == 2);
		}
		for (int i = 1; i <= n; i++) ans = min(ans, sum[i - 1][1] + sum[n][0] - sum[i - 1][0]);
		return ans;
	}
}
int main() {
	//freopen(".in", "r", stdin);
	//freopen(".out", "w", stdout);
	scanf("%d %d %d", &n, &m1, &m2);
	for (int i = 1; i <= n; i++) scanf("%d", a + i);
	printf("%d", n >= 20 ? d2::d() : d1::d());
	return 0;
}
