#include<bits/stdc++.h> 
using namespace std;
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	return 0;
}
