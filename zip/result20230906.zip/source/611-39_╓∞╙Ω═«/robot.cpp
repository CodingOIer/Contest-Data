#include<bits/stdc++.h>
using namespace std;
long long a[50005],b[50005],c[50005],n,m1,m2;
long long ans2=0,ans1=0;
int k[3],max=0,min=0;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1; i<=n; i++) {
		cin>>a[i];
		b[i]=a[i];
		c[i]=a[i];
		if(i==1) {
			k[i]=a[i];
			a[i]=1000000;
			b[i]=1;
		}
		if(i==2) {
			k[i]=a[i];
		}
		if(i>=3) {
			if(a[i]>a[i-1]) {
				if(m1<m2) {
					if(a[i]<=a[i-2]) {
						ans1+=m1;
						a[i-1]=a[i-2];
					} else {
						ans1+=m2;
						a[i]=a[i-1];
					}
				} else {
					ans1+=m2;
					a[i]=a[i-1];
				}
			}
			if(b[i]<b[i-1]) {
				if(m1>m2) {
					if(b[i]>=b[i-2]) {
						ans2+=m2;
						b[i-1]=b[i-2];
					} else {
						ans2+=m1;
						b[i]=b[i-1];
					}
				} else {
					ans2+=m1;
					b[i]=b[i-1];
				}
			}
		} else if(i==2) {
			if(a[i]>a[i-1]) {
				ans1+=m1;
				a[i]=a[i-1];
			}
			if(b[i]<b[i-1]) {
				ans2+=m2;
				b[i]=b[i-1];
			}
		}
	}
	//if(k[1]<k[2]){
	//	ans1=ans1+
	//}
	//if(k[1]>k[2]){
	//	
	//}
		if(ans1>=ans2) {
			ans1=ans2;
		}
	cout<<ans1;
	return 0;
}
