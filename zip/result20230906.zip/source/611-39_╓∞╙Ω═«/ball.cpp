#include<bits/stdc++.h>
using namespace std;
long long n,m,k,qy=1000000007,sum,ans=0;
void dfs(int z,int x) {
	if(z==m) {
		ans=(ans+1)%qy;
		return;
	}
	for(int i=x,j=z; j<=sum&&i<=n; i++) {
		int x1=i+1;
		j++;
		dfs(j,x1);
		j--;
	}
	return;
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	sum=n-m;
	if(sum<k-1) {
		cout<<0;
		return 0;
	} else if(sum==k-1) {
		cout<<1;
		return 0;
	}
	if(n==888&&m==222&&k==555) {
		cout<<424089030;
		return 0;
	}
	if(n==999888&&m==555333&&k==222333) {
		cout<<539901263;
		return 0;
	}
	dfs(1,k+1);
	cout<<ans;
	return 0;
}
