#include<bits/stdc++.h>
using namespace std;
int n,m1,m2,ans=0,sum=0,a[50005];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	if(n<=2) cout<<0;
	return 0;
}
