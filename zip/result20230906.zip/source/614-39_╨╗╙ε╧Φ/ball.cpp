#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,m,k,s1=1,s2=1;
int ksm(int x,int s)
{
	int res=1;
	while(s)
	{
		if(s%2) res=(res*x)%mod;
		x=(x*x)%mod;
		s/=2;
	}
	return res;
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k;
	for(int i=1;i<=n-k;i++)
		s1=(s1*i)%mod;
	for(int i=1;i<=m-1;i++)
		s2=(s2*i)%mod;
	s2=ksm(s2,mod-2);
	s1=(s1*s2)%mod;
	s2=1;
	for(int i=1;i<=n-k-m+1;i++)
		s2=(s2*i)%mod;
	s2=ksm(s2,mod-2);
	s1=(s1*s2)%mod;
	cout<<s1;
	return 0;
}
