#include<bits/stdc++.h>
#define MAXN 1000000007
using namespace std;
long long n,m,k,ans=1;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	long long num=n-k+1;
	for(int i=1;i<m;i++)
	{
		ans=ans*(num-i)/i;
	}
	if(ans<0)
	{
		printf("0");
		return 0;
	}
	printf("%lld",ans%MAXN);
    return 0;
}
