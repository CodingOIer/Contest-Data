#include<bits/stdc++.h>
using namespace std;
int a;
int main(){
	//freopen("subscript.in","r",stdin);
	//freopen("subscript.out","w",stdout);
	while(1)
	{
		cin>>a;
		cout<<char(a)<<endl;
	}
    return 0;
}
