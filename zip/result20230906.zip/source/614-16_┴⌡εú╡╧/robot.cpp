#include<bits/stdc++.h>
#define MAXN 1000010 
using namespace std;
int n,m1,m2,a[MAXN],b[MAXN],a1[MAXN],a2[MAXN],b1[MAXN],b2[MAXN],ans1,ans2;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%d%d%d",&n,&m1,&m2);
	if(n<=2)
	{
		printf("0");
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	for(int i=2;i<=n;i++)
	{
		if(a[i]<a[i-1])
		{
			if(m1<=m2)
			{
				ans1+=m1;
				a[i]=a[i-1];
				a1[i]=1;
			}else
			{
				int bs=m2/m1,e;
				for(int j=i;bs!=0&&j!=0;bs--,j--)
				{
					if(a1[j]!=0&&a2[j]!=0) bs++;
					if(a[j]>a[j-1]&&a[j-1]<=a[i])
					{
						for(int k=j;k<=i;k++) a2[j]=1;
						ans1=ans1+m2*(m2/m1-bs);
						e=1; 
						break;
					}
				}
				if(e==0)
				{
					ans1+=m1;
					a[i]=a[i-1];
					a1[i]=1;
				}
			}
		}
	}
	for(int i=2;i<=n;i++)
	{
		if(b[i]>b[i-1])
		{
			if(m2<=m1)
			{
				ans2+=m2;
				b[i]=b[i-1];
				b1[i]=1;
			}else
			{
				int bs=m1/m2,e;
				for(int j=i;bs!=0&&j!=0;bs--,j--)
				{
					if(b1[j]!=0&&b2[j]!=0) bs++;
					if(b[j]<b[j-1]&&b[j-1]>=b[i])
					{
						for(int k=j;k<=i;k++) b2[j]=1;
						ans2=ans2+m2*(m2/m1-bs);
						e=1; 
						break;
					}
				}
				if(e==0)
				{
					ans2+=m1;
					b[i]=b[i-1];
					b1[i]=1;
				}
			}
		}
	}
	printf("%d",min(ans1,ans2));
    return 0;
}
