#include<bits/stdc++.h>
using namespace std;
int t,n,lst;
string s;
string f(string sx,string sy)
{
	if(sy=="") return sx;
	int l=sx.length();
	sx=" "+sx;
	string sa,sb;
	sa=sb="";
	int i=1;
	while(sx[i]!='[' && i<=l)
		sa+=sx[i],i++;
	i++;
	while(i<l)
		sb+=sx[i],i++;
	sx=f(sa,sb);
	l=sy.length();
	sa=sb="";
	sy=" "+sy;
	i=1;
	while(sy[i]!='[' && i<=l)
		sa+=sy[i],i++;
	i++;
	while(i<l)
		sb+=sy[i],i++;
	sy=f(sa,sb);
	if(sx>sy) swap(sx,sy);
	return sx+"["+sy+"]";
}
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>s;
		n=s.length();
		s=" "+s;
		int tp=1;
		int k=0;
		int fg=0;
		for(int i=n;i>=1;i--)
		{
			if(s[i]==']') k++;
			if(s[i]=='[') k--;
			if(k==0)
			{
				fg=i;
				break;
			}
		}
		string ss1,ss2;
		ss1=ss2="";
		for(int i=1;i<fg;i++)
			ss1+=s[i];
		for(int i=fg+1;i<n;i++)
			ss2+=s[i];
		cout<<f(ss1,ss2);
	}
	return 0;
}
