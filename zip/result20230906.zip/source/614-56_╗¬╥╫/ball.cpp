#include<bits/stdc++.h>
#define ll long long
#define mod 1000000007
using namespace std;
ll n,m,k;
ll a[1000005],b[1000005];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	n-=k;
	m-=1;
	for(int i=1;i<=n;i++)
		a[i]=i;
	for(int i=2;i<=m;i++)
	{
		b[i]=1;
		for(int j=i+1;j<=n;j++)
			b[j]=a[j-1]+b[j-1],b[j]%=mod;
		for(int j=1;j<=n;j++)
			a[j]=b[j];
	}
	cout<<a[n];
	return 0;
}
