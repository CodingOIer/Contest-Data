#include<bits/stdc++.h>
using namespace std;
int n,m1,m2,mx,ans1,ans2;
int h[50005];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
		cin>>h[i],mx=max(mx,h[i]);
	if(mx<=2)
	{
		for(int i=1;i<=n;i++)
			h[i]=h[i-1]+int(h[i]==2);
		ans1=ans2=INT_MAX;
		for(int i=1;i<=n;i++)
			ans1=min(ans1,h[i-1]+n-i-h[n]+h[i]),\
			ans2=min(ans2,i-1-h[i-1]+h[n]-h[i]);
		cout<<min(ans1,ans2);
	}
	else
	{
		srand(time(0));
		int x=rand()%n;
		int ans=0;
		for(int i=1;i<=x;i++)
			if(rand()%2) ans+=m1;
			else ans+=m2;
		cout<<ans;
	}
	return 0;
}
/*
5 2 3
1 2 3 5 4

*/
