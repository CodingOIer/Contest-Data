#include<bits/stdc++.h>
using namespace std;
long long n,m1,m2,cnt,ans1,ans2,sum1,sum2,tot,m;
stack<long long >len1,len2;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m1,&m2);
	m=min(m1,m2);
	scanf("%lld%lld",&cnt,&tot);
	len1.push(cnt);
	len2.push(cnt);
	if(len1.top()<tot&&m1<m2) {
		if(m1<m2) {
			sum1+=m1; 
		}else sum1+=m2;
		len1.push(tot);
	}
	if(len2.top()>tot&&m1>m2) {
		if(m1>m2) {
			sum2+=m2; 
		}else sum2+=m1;
		len2.push(tot);
	}
	for(long long i=2;i<n;++i) {
		scanf("%lld",&cnt);
//		printf("%lld %lld\n",len1.top(),len2.top());
		if(len1.top()<cnt) {
//			cout<<1;
			long long tmp=len1.top();
			len1.pop();
			if(len1.top()<cnt) {
				
				sum1+=m2;
				len1.push(tmp);
			}else {
				if(m1<m2) {
					len1.push(cnt);
					sum1+=m1;
				}else {
					len1.push(tmp);
					sum1+=m2;
				}
			}
		}else {
			len1.push(cnt);
		}
		if(len2.top()>cnt) {
			long long tmp=len2.top();
			len2.pop();
			if(len2.top()>cnt) {
				sum2+=m1;
				len2.push(tmp);
			}else {
				if(m2<m1) {
					len2.push(cnt);
					sum2+=m2;
				}else {
					len1.push(tmp);
					sum2+=m1;
				}
			} 
		}else {
			len2.push(cnt);
		}
	}
	printf("%lld",min(sum1,sum2));
	return 0;
}

