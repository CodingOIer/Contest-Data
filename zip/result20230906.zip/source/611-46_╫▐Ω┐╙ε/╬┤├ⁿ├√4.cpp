#include<bits/stdc++.h>
using namespace std;
void cmp(char a[]) {
	char x[1000001],y=a,tmp;
	for(long long i=0;a[i];++i) {
		if(a[i]=='[') {
			long long ans=1;
			for(long long j=i;ans;++j) {
				if(a[j]=='[') ans++;
				if(a[j]==']') ans--;
				x+=a[i];
				y-=a[i];
			}
			if(x<y) {
				tmp=x;
				x=y;
				y=tmp;
			}
			cmp(x);
			cmp(y);
			printf("%s%s",x,y);
		}
	}
}
int main() {
	return 0;
}
