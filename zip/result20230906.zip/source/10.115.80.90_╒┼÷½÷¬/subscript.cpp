#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("subscript.in","w",stdin);
	freopen("subscript.out","r",stdout);
	int T;
	cin>>T;
	while(T--){
		string s;
		cin>>s;
		string a,b;
		int f=0,l=-1,r=-1,x=0;
		for(int i=0;i<s.size();i++){
			if(s[i]=='[') f=1,l=i,x++;
			else if(s[i]==']') f=0,r=i;
			else if(f==0) a+=s[i];
			else if(f==1) b+=s[i];
		}
		if(l==-1||x==2){
			cout<<s<<endl;
		}
		else if(a<=b){
			cout<<a;
			cout<<'[';
			cout<<b;
			cout<<']';
			cout<<endl;
		}
		else{
			cout<<b;
			cout<<'[';
			cout<<a;
			cout<<']';
			cout<<endl;
		}
	}
	return 0;
}

