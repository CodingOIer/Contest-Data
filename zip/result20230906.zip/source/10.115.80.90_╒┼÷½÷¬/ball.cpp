#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int c[1000005];
int C(int x,int y){
	for(int i=1;i<=y;i++) c[i]=(c[i-1]*(x-i+1)/i)%mod;
	int ans=c[y];
	return ans;
}
signed main(){
	freopen("ball.in","w",stdin);
	freopen("ball.out","r",stdout);
	c[0]=1;
	int n,m,k,ans=1;
	cin>>n>>m>>k;
	int a=n-k,b=m-1;
	cout<<C(a,b);
	return 0;
}
