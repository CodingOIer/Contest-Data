#include<bits/stdc++.h>
using namespace std;
int a[15],m[15],b[15],ans=INT_MAX;
int n,m1,m2;
bool check1(){
	for(int i=2;i<=n;i++){
		if(b[i]<b[i-1]) return 0;
	}
	return 1;
}
bool check2(){
	for(int i=1;i<n;i++){
		if(b[i+1]>b[i]) return 0;
	}
	return 1;
}
int main(){
	freopen("robot.in","w",stdin);
	freopen("robot.out","r",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(n==1) return cout<<0,0;
	if(n==2) return cout<<min(m1,m2),0;
	if(n>10){
		int ans1=0,ans2=0;
		for(int i=2;i<=n;i++){
			if(a[i]<a[i-1]) ans1++,a[i]=a[i-1];
		}
		for(int i=2;i<=n;i++){
			if(a[i]>a[i-1]) ans2++,a[i]=a[i+1];
		}
		cout<<min(ans1,ans2);
		return 0;
	}
	for(int t=1;t<=(1<<n);t++){
		int calc=0;
		m[n]++;
		for(int i=n;i>=1;i--){
			if(m[i]==2) {
				m[i]=0;
				m[i-1]++;
			}
		}
		for(int i=1;i<=n;i++) if(m[i]==1) calc++;
		for(int i=1;i<=n;i++) {
			if(m[i]==0) b[i]=a[i];
			else b[i]=a[i-1];
		}
		if(check1()) ans=min(ans,calc);
	}
	for(int t=1;t<=(1<<n);t++){
		int calc=0;
		m[n]++;
		for(int i=n;i>=1;i--){
			if(m[i]==2) {
				m[i]=0;
				m[i-1]++;
			}
		}
		for(int i=1;i<=n;i++) if(m[i]==1) calc++;
		if(m[1]==1) b[1]=INT_MAX;
		for(int i=2;i<=n;i++) {
			if(m[i]==0) b[i]=a[i];
			else b[i]=a[i+1];
		}
		if(check2()) ans=min(ans,calc);
	}
	cout<<ans;
	return 0;
}
