#include<bits/stdc++.h>
#define int long long
#define mid ((l+r)>>1)
using namespace std;
int n;
int tot;
string s;
struct node{
	int l,r;
	int ls,rs;
}tree[100005];

void build(int x,int L,int R){
	tree[x].l=L;
	tree[x].r=R;
	int ops=0;
	for(int i=L;i<=R;i++){
		if(s[i]=='['||s[i]==']')ops=1;	
	}
	if(ops==0){
		tree[x].ls=tree[x].rs=0;
		return;		
	}
	int now=R,sum=0;
	while(1){
		if(s[now]==']')sum++;
		else if(s[now]=='['){
			sum--;
			if(sum==0)
			break;	
		}
		now--;
	}
	tree[x].ls=tot+1;
	build(++tot,tree[x].l,now-1);
	tree[x].rs=tot+1;
	build(++tot,now+1,R-1);
}
string get(int l,int r){
	string t;
	t.clear();
	for(int i=l;i<=r;i++){
		t=t+s[i];	
	}
	return t;
}
bool cmp(string t1,string t2){
	for(int i=0;i<min(t1.size(),t2.size());i++){
		if(t1[i]<t2[i])return 1;
		else if(t1[i]>t2[i])return 0;
	}
	return t1<t2;
}
string dfs(int x){
	if(tree[x].ls==0&&tree[x].rs==0){
		return get(tree[x].l,tree[x].r);
	}
	string t1=dfs(tree[x].ls);
	string t2=dfs(tree[x].rs);
	if(cmp(t1,t2)){
		return t1+'['+t2+']';	
	}else{
		return t2+'['+t1+']';	
	}
}
signed main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		s.clear();
		tot=1;
		cin>>s;
		n=s.size();
		s=' '+s;
		build(1,1,n);
		cout<<dfs(1)<<endl;
	}
}
