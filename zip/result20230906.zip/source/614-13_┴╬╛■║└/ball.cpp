#include<bits/stdc++.h>
#define int long long
#define mid ((l+r)>>1)
using namespace std;
int n,k,m,mod=1e9+7;
int poww(int x,int y){
	int sum=1;
	while(y){
		if(y&1)sum=(sum*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return sum;
}
int C(int n,int m){
	int ans=1;
	for(int i=0;i<m;i++){
		ans=(ans*(n-i))%mod;
	}
	for(int i=1;i<=m;i++){
		ans=(ans*poww(i,mod-2))%mod;	
	}
	return ans;
}
signed main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout); 
	cin>>n>>m>>k;
	cout<<C(n-k,m-1);
}
