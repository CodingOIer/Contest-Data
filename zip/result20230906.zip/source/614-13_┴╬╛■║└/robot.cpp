#include<bits/stdc++.h>
#define int long long
#define mid ((l+r)>>1)
using namespace std;
int n,m1,m2,ans=1e18;
struct node{
	int s,id;	
}p[50005];
bool cmp(node A,node B){
	return A.s<B.s;	
}
int a[50005];
int f[50005][1005];
signed main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++){cin>>p[i].s;p[i].id=i;}
	sort(p+1,p+n+1,cmp);
	int tot=0;
	for(int i=1;i<=n;i++){
		if(p[i].s!=p[i-1].s)tot++;
		a[p[i].id]=tot;
	}
	for(int i=1;i<=tot;i++){
		if(i<a[1])f[1][i]=m2;
		if(i>a[1])f[1][i]=m1;
	}
	//down
	for(int i=2;i<=n;i++){
		int minn=1e18;
		for(int j=tot;j>0;j--){
			minn=min(minn,f[i-1][j]);
			if(j>a[i])f[i][j]=minn+m1;
			else if(j==a[i])f[i][j]=minn;
			else f[i][j]=minn+m2;
		}
	}
	for(int i=1;i<=tot;i++){
		ans=min(ans,f[n][i]);	
	}
	//up
	for(int i=2;i<=n;i++){
		int minn=1e18;
		for(int j=1;j<=tot;j++){
			minn=min(minn,f[i-1][j]);
			if(j>a[i])f[i][j]=minn+m1;
			else if(j==a[i])f[i][j]=minn;
			else f[i][j]=minn+m2;
		}	
	}
	for(int i=1;i<=tot;i++){
		ans=min(ans,f[n][i]);	
	}
	cout<<ans;
}
