#include<bits/stdc++.h>
#define int long long
#define re register
#define mod 1000000007
#define rep(i,a,b) for(re int i(a);i<=b;++i)
#define req(i,a,b) for(re int i(a);i>=b;--i)
using namespace std;
inline int read(int &num)
{
	re int x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
inline void write(int x)
{
	x<0?putchar('-'),x=-x:0;
	x>9?write(x/10),0:0;
	putchar(x%10+48);
}
int qpow(int x,int y)
{
	if(!y) return 1; if(y==1) return x;
	int mid=qpow(x,y>>1);
	return (y&1)?mid*mid%mod*x%mod:mid*mid%mod;
}
inline int getinv(int x){return qpow(x,mod-2);}
namespace bino
{
	int fac[2000001],Maxn=0;
	inline void init()
	{
		fac[0]=1;
		rep(i,1,Maxn) fac[i]=fac[i-1]*i%mod;
	}
	inline int calc(int x,int y)
	{
		return fac[x]*getinv(fac[x-y])%mod*getinv(fac[y])%mod;
		/*
		n!/((n-m)!m!)
		*/
	}
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	bino::Maxn=2e6;
	bino::init();
	int n,m,k;
	read(n);read(m);read(k);
	write(bino::calc(n-k,m-1));
	return 0;
}
