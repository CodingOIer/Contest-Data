#include<bits/stdc++.h>
// #define int long long
#define re register
#define rep(i,a,b) for(re int i(a);i<=b;++i)
#define req(i,a,b) for(re int i(a);i>=b;--i)
using namespace std;
inline int read(int &num)
{
	re int x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
inline void write(int x)
{
	x<0?putchar('-'),x=-x:0;
	x>9?write(x/10),0:0;
	putchar(x%10+48);
}
int T,n,wz[100001][2],cnt;
stack <int> stk;
string s,ans;
mt19937 rnd(time(0));
signed main()
{
	 freopen("subscript.in","r",stdin);
	 freopen("subscript.out","w",stdout);
	cin>>T;
	double tm=0.9/T;
	while(T--)
	{
		cin>>s;
		n=s.size();
		s=' '+s;
		ans=s;
		// basic_string::at: __n (which is %zu) >= this->size() (which is %zu)
		int st=clock();
		while(1)
		{
			if((clock()-st)*1.0/CLOCKS_PER_SEC>=tm) break;
			memset(wz,0,sizeof wz),cnt=0;
			n=s.size()-1;
			rep(i,1,n)
			{
				if(s[i]==']')wz[++cnt][0]=stk.top(),stk.pop(),wz[cnt][1]=i;
				if(s[i]=='[')stk.push(i);
			}
			int cg=rnd()%cnt+1;
//			while(!isalpha(s[wz[cg][0]-1])) cg=rnd()%cnt+1;
//			int cg=2;
			string rig=s.substr(wz[cg][0]+1,wz[cg][1]-wz[cg][0]-1),lef="";
			s.erase(s.begin()+wz[cg][0]+1,s.begin()+wz[cg][1]);
			auto pos=s.begin()+wz[cg][0]-1;
			int have=0;
			while(have>=0)
			{
				if(*pos==']') ++have;
				if(*pos=='[') --have;
				if(have<0) break;
				lef.insert(lef.begin(),*pos);
				s.erase(pos);--wz[cg][0];
				if(pos==s.begin()+1) break;
				--pos;
			}
//			cout<<lef<<" "<<rig<<" "<<wz[cg][0]<<'\n';
//			cout<<s<<endl;
			req(i,rig.size()-1,0)s.insert(s.begin()+wz[cg][0],rig[i]);
//			cout<<s<<endl;
			req(i,lef.size()-1,0)s.insert(s.begin()+wz[cg][0]+rig.size()+1,lef[i]);
			ans=min(ans,s);
//			cout<<s<<endl;
//			system("pause");
		}
		ans.erase(ans.begin());
		cout<<ans<<'\n';
	}
	return 0;
}

