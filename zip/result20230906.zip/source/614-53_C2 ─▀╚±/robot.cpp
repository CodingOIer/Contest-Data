#include<bits/stdc++.h>
#define writeln(x) write(x),puts("")
// #define int long long
#define re register
#define rep(i,a,b) for(re int i(a);i<=b;++i)
#define req(i,a,b) for(re int i(a);i>=b;--i)
using namespace std;
inline int read(int &num)
{
	re int x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
inline void write(int x)
{
	x<0?putchar('-'),x=-x:0;
	x>9?write(x/10),0:0;
	putchar(x%10+48);
}
int n,m1,m2,a[200001],b[200001],ans=0x7fffffff;
bool get()
{
	int bmz1=0;
	rep(i,1,n-1) bmz1+=a[i]>a[i+1];
	return (bmz1==n/2?m1<m2:bmz1<n/2?1:0);
}
signed main()
{
	 freopen("robot.in","r",stdin);
	 freopen("robot.out","w",stdout);
	read(n);read(m1);read(m2);
	rep(i,1,n) read(a[i]);
	memcpy(b,a,sizeof a);
	int fx=get();
	// fx=1: increase
	// fx=0: decrease
	if(fx)
	{
		int res1=0,res2=0;
		for(int i=2;i^n;++i) if(a[i-1]>a[i]&&a[i]<a[i+1]&&a[i-1]<=a[i+1])a[i]=a[i-1],++res1;
		else if(a[i-1]>a[i]&&a[i]<a[i+1]) a[i]=a[i-1],++res2;
		else if(a[i-1]<a[i]&&a[i]>a[i+1]&&a[i-1]>=a[i+1])a[i]=a[i-1],++res2;
		res1+=a[1]>a[2];res1+=a[n-1]>a[n];
		ans=min(ans,res1*m1+res2*m2);
	}
	else
	{
		int res1=0,res2=0;
		for(int i=2;i^n;++i) if(a[i-1]<a[i]&&a[i]>a[i+1]&&a[i-1]>=a[i+1])a[i]=a[i-1],++res2;
		else if(a[i-1]<a[i]&&a[i]>a[i+1]) a[i]=a[i-1],++res1;
		else if(a[i-1]>a[i]&&a[i]<a[i+1]&&a[i-1]<=a[i+1])a[i]=a[i-1],++res1;
		res2+=a[1]<a[2];res2+=a[n-1]<a[n];
		ans=min(ans,res1*m1+res2*m2);
		
	}
	writeln(ans);
	return 0;
}

