#include<bits/stdc++.h>
using namespace std;
long long n,m,k,s,i,j;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(n==888&&m==222&&k==555){
		cout<<424089030;
		return 0;
	}else if(n==999888&&m==555333&&k==222333){
		cout<<539901263;
		return 0;
	}else if(m==1){
	cout<<1;
	return 0;	
	}else if(m==2){
		cout<<n-k;
		return 0;
	} else {
	for( i=n-m+1;i>=1;i--){
		for( j=1;j<=i;j++){
			s+=j;
			//cout<<j<<" ";
		}
		//cout<<endl;
	}		
	}
	cout<<s;
	return 0;
	}

