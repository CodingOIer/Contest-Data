#include<bits/stdc++.h>
using namespace std;
long long n,m1,m2,a[50005],b[5005],i,s=2;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(i=1;i<=n;i++){
		cin>>a[i];
		a[i]=b[i]; 
	}
	sort(b+1,b+1+n);
	for( i=1;i<=n;i++){
	if(a[i]!=b[i]){
		if(a[i]!=a[i-1]){
		if(a[i]>b[i])s+=m1;
		else s+=m2;	
		a[i]=a[i+1];
		}
		}
	}
	cout<<s;
	return 0;
	}

