#include<bits/stdc++.h>
#define int long long
using namespace std;
signed a[50001],c[50001],b[50001];
int ans=INT_MAX;
void dfs(int q,int n,int m1,int m2,int sum)
{
	if(q>n)
	{
		ans=min(ans,sum);
		return;
	}
	if(a[q]<a[q-1]) a[q]=a[q-1],dfs(q+1,n,m1,m2,sum+m1),a[q]=b[q];
	else
	{
		dfs(q+1,n,m1,m2,sum);
		if(a[q]!=a[q-1])
		{
		    a[q]=a[q-1];
		    dfs(q+1,n,m1,m2,sum+m2);
		    a[q]=b[q];	
		}
	}
}
void dfs2(int q,int n,int m1,int m2,int sum)
{
//	cout<<q<<endl;
	if(q<n)
	{
		ans=min(ans,sum);
//		for(int i=1;i<=l;i++) cout<<c[i];
//		cout<<endl;
//		cout<<sum<<endl;
		return;
	}
	if(a[q]<a[q+1]) a[q]=a[q+1],dfs2(q-1,n,m1,m2,sum+m2),a[q]=b[q];
	else
	{
		dfs2(q-1,n,m1,m2,sum);
		if(a[q]!=a[q+1])
		{
			a[q]=a[q+1];
			dfs2(q-1,n,m1,m2,sum+m1);
			a[q]=b[q];
		}
	}
}
signed main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int n,m1,m2,f=0,f1=0;
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		if(i!=1 && a[i]<a[i-1])f=1;
		if(a[i]!=1 && a[i]!=2) f1=1;
		b[i]=a[i];
	}
	if(f==0) return cout<<0,0;
	for(int i=n-1;i>=1;i--)
	{
		if(a[i]<a[i+1]) 
		{
			f=0;
			break;
		}
	}
	if(f==1) return cout<<0,0;
	if(n<=25)
	{
		dfs(2,n,m1,m2,0);
//		cout<<ans;
		n--;
		dfs2(n,1,m1,m2,0);
		cout<<ans;
		return 0;
	}
	if(f1==0)
	{
		int ans=0,sum=0;
		for(int i=1;i<=n;i++)
		{
			if(a[i]==2) sum++;
		}
		if(sum>=n/2+n%2)
		{
			for(int i=1;i<=n;i++)
			{
				if(a[i]!=1)
				{
					ans+=(n-i+1-sum)*m1;
					break;
				}
			}
			for(int i=n;i>=1;i--)
			{
				if(sum==0)
				{
					ans=min(ans,(n-i-sum)*m1);
				}
				if(a[i]==2) sum--;
			}
		}
		else
		{
			ans=sum*m2;
			for(int i=n;i>=1;i--)
			{
				if(a[i]!=2)
				{
					ans=min(ans,(sum-(n-i))*m2);
					break;
				}
			}
		}
		cout<<ans;
		return 0;
	}
	int cnt=0,o=0;a[0]=INT_MAX-10;
	for(int i=1;i<=n;i++)if(a[i]<a[i-1]) c[cnt++]=i-o,o=i;
	for(int i=2;i<=cnt;i+=3)if(c[i]>c[i-1]+c[i+1]) ans+=(c[i-1]+c[i+1])*m2;else ans+=c[i]*m1;
	cnt=0;o=0;a[n]=INT_MAX-10;
	for(int i=n;i>=1;i--)if(a[i]<a[i+1]) c[cnt++]=i-o,o=i;
	int ans2=0;
	for(int i=2;i<=cnt;i+=3)if(c[i]>c[i-1]+c[i+1]) ans2+=(c[i-1]+c[i+1])*m2;else ans2+=c[i]*m1;
 	cout<<min(ans,ans2);
	return 0;
}

