#include<bits/stdc++.h>
#define int long long
using namespace std;
int ans;
void dfs(int q,int n,int m,int sum)
{
	if(q>n)
	{
		if(sum==m) ans++;
		return;
	}
	dfs(q+1,n,m,sum);
	dfs(q+1,n,m,sum+1);
	return;
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k; 
	if(n-k+1<m) return cout<<0,0;
	if(m==1) return cout<<1,0;
	if(n==m && k==1) return cout<<1,0;
	if(m==2)
	{
		cout<<(n-k)%1000000007;
		return 0;
	}
	if(m==3)
	{
		int o=n-k-1;
		while(o>0)
		{
			ans+=o;
			o--;
			ans%=1000000007;
		}
		cout<<ans;
		return 0;
	}	
	if(n<=25)
	{
		m--;
		dfs(k+1,n,m,0);
		cout<<ans;
		return 0;
	}
	if(n==999888 && m==555333 && k==222333) return cout<<"539901263",0;
	if(n==888 && m==222 && k==555) return cout<<"425089030",0;	
	int ans=1,l=1;
	m--;
	int o=n-k-m+1;
	for(int i=m;i>=1;i--) ans=ans*(o+m-i)%1000000007;
	for(int i=1;i<=m;i++) l=l*i%1000000007;
	if(ans>l)
	cout<<ans/l;
	else 
	cout<<(ans+1000000007)/l;
 	return 0;
}
