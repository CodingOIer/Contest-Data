#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int t;
	cin>>t;
	while(t>0)
	{
		char a[100001];
		cin>>a+1;
		if(strlen(a+1)<=2) 
		{
			int n=strlen(a+1);
			for(int i=1;i<=n;i++) cout<<a[i];
			cout<<endl;
		}
		else 
		{
			int n=strlen(a+1);
			for(int i=1;i<=n;i++) cout<<a[i];
			cout<<endl;
		}
	}
 	return 0;
}

