#include<bits/stdc++.h>
using namespace std;
long long a,b,c,d[50001],s=INT_MAX,s2=INT_MAX,mn;
void dfs(long long n,long long m) {
	if(m>=a) {
		s=min(s,n);
		return;
	}
	for(int i=1; i<=a-1; i++) {
		if(i[d]>i[d+1]) {
			m++;
			d[i]=d[i+1];
			n+=c;
			dfs(n,m);
			n-=c;
			d[i+1]=d[i];
			n+=b;
			dfs(n,m);
			n-=b;
			m--;
		}
		m++;
	}
	return;
}
void dfs2(long long n,long long m) {
	if(m>=a) {
		s2=min(s2,n);
		return;
	}
	for(int i=1; i<=a-1; i++) {
		if(i[d]<i[d+1]) {
			m++;
			d[i]=d[i+1];
			n+=b;
			dfs(n,m);
			n-=b;
			d[i+1]=d[i];
			n+=c;
			dfs(n,m);
			n-=c;
			m--;
		}
		m++;
	}
	return;
}
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>a>>b>>c;
	for(int i=1; i<=a; i++) {
		cin>>i[d];
	}
	dfs(0,1);
	dfs2(0,1);
	mn=min(s,s2);
	cout<<mn;
	return 0;
}
