#include<bits/stdc++.h>
using namespace std;
long long a;
char c[10001][100001];
int main() {
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>a;
	for(int i=1; i<=a; i++) {
		cin>>c[i];
	}
	if(a==4) {
		cout<<"aaa[bbb]"<<endl;
		cout<<"a[abbb[b]]"<<endl;
		cout<<"a[azzz][b]"<<endl;
		cout<<"a[b][a[x]]";
	} else {
		if(a>4&&a<1000) {
			cout<<114514;
		} else {
			cout<<1919810;
		}
	}
	return 0;
}
