#include<bits/stdc++.h>
using namespace std;
const int l=1e9+7;
long long a,b,c,s,t=1,t2=1;
void gys() {
	long long f=min(t,t2);
	for(long long i=f; i>=2; i--) {
		if(t%i==0&&t2%i==0) {
			t/=i;
			t2/=i;
		}
	}
	return;
}
long long zh() {
	long long f=a-b;
	for(long long i=1; i<=f; i++) {
		t2*=i;
		t*=a;
		gys();
		a--;
	}
	t/=t2;
	return t;
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>a>>b>>c;
	a-=c;
	b--;
	s=zh();
	s%=l;
	cout<<s;
	return 0;
}
