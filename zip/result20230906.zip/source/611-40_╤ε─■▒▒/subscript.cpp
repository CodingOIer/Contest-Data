#include<bits/stdc++.h>
using namespace std;
int n,cnt1,cnt2; 
vector<char> a[100000];
int main(){
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		char hb[100000];
		cin>>hb;
		for(int j=0;j<strlen(hb);j++) a[i].push_back(hb[j]);
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<a[i].size();j++) cout<<a[i][j];
		cout<<endl;
	}
	return 0;
}

