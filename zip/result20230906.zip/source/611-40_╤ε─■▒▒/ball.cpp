#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,k;
vector<vector<int>> a;
void print(){
	for(int i=0;i<a.size();i++){
		for(int j=0;j<a[i].size();j++) cout<<a[i][j]<<" ";
		cout<<endl;
	}
	cout<<endl;
}
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	n-=k;
	a.push_back({0,3,1,0});
	if(n<3){
		if(m==1) cout<<1;
		else cout<<1+1;
		return 0;
	}
	if(m==1) cout<<1;
	for(int i=3;i<n;i++){
		a.push_back({0});
		a[i-2].push_back(a[i-3][1]+i);
		for(int j=1;j<=i;j++){
		//	print();
		//	int s=0;
		//	for(int k=0;k<j-1;k++){
		//		s+=a[k][1];
		//	}
		//	a[i-2].push_back(s);
			a[i-2].push_back((a[i-3][j]+a[i-3][j+1])%1000000007);
		}
		a[i-2].push_back(0);
	}
	//cout<<666;
	cout<<a[n-3][m-1];
	return 0;
} 

