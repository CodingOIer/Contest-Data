#include<bits/stdc++.h>
using namespace std;
long long n,m,k,jl=1,o=1;
int main()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);	
	cin>>n>>m>>k;
	if(m==1)
	{
			cout<<"1";
			return 0;
	 } 
	if(m==2)
	{
		cout<<n-k;
		return 0;
	}	
	m=m-1; 
	n=n-k;
	for(int i=n;i>m;i--)
	{
		jl=(jl*o)%1000000007;
	}
	cout<<jl;
	return 0;
}

