#include<bits/stdc++.h>
using namespace std;
//long long n,a,b,o[1000440],j,s,big,small=99999999;
string i;
int main()
{
	//freopen("robot.in","r",stdin);
	//freopen("robot.out","w",stdout);	'
	int i;
	cin>>i;
	cout<<i/'a';
	return 0;
}

