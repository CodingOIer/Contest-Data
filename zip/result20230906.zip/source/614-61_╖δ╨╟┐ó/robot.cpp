#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 5e4 + 5;
int n, m1, m2;
int ans = 0x3f3f3f3f;
int a[N];

signed main(){
	freopen ("robot.in", "r", stdin);
	freopen ("robot.out", "w", stdout);
	
	scanf ("%lld%lld%lld", &n, &m1, &m2);
	for (int i = 1; i <= n; ++i) scanf ("%lld", &a[i]);
	
	int t1 = 0, t2 = 0;
	for (int i = 1; i <= n; ++i){
		if (a[i] <= a[i+1]) t1++;
		else if (a[i] >= a[i+1]) t2++; 
	}
	if (t1 > t2 || t1 == t2){
		//�ܵ�������
		int ans1 = 0, ans2 = 0;
		for (int i = 1; i <= n; ++i){
			if (a[i] > a[i+1]){
				ans2 += m2;
			}
		}
		for (int i = 1; i <= n; ++i){
			if (a[i] < a[i-1]) {
				ans1 += m1;
			}
		} 
		ans = min(ans1, ans2);
	} 
	if (t2 > t1 || t1 == t2){
		//�ܵ����ݼ�
		int ans1 = 0;
		for (int i = 1; i <= n; ++i){
			if (a[i] < a[i+1]){
				if (a[i-1] > a[i] && a[i] < a[i+1]) {
					ans1 += m1;
					a[i] = a[i-1];
				}
			}
		}
		for (int i = 1; i <= n; ++i){
			if (a[i] < a[i+1]){
				if (a[i+2] < a[i+1]) ans1 = ans1 - m1 + m2;
			}
		}
		ans = min(ans, ans1);
	}
	
	printf ("%lld", ans);

	return 0;
}
/*
15 5 7
10 10 10 10 10 9 2 8 7 6 1000 5 3 4 1
*/
