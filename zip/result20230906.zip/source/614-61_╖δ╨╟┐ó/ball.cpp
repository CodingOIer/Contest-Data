#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e6 + 5, MOD = 1e9 + 7;
int n, m, k;
int pn;
int ans;

signed main(){
	freopen ("ball.in", "r", stdin);
	freopen ("ball.out", "w", stdout);
	
	scanf ("%lld%lld%lld", &n, &m, &k);
	
	--m;
	n = n - k + 1;
	ans = 1;
	
	for (int i = 1; i <= m; ++i){
		ans *= n - i;
		ans %= MOD;
	}
	
	ans *= m;
	printf ("%lld", ans % MOD);
	
	return 0;
}

