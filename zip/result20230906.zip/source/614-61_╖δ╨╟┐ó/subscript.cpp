#include <bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e5 + 5;
int n;

signed main(){
	freopen ("subscript.in", "r", stdin);
	freopen ("subscript.out", "w", stdout);
	scanf ("%d", &n);
	for (int t = 1; t <= n; ++t){
		int len = 0;
		char ch[N];
		
		while (true){
			ch[++len] = getchar();
			if (ch[len] == '\0') break;
		}
		
		//����
		int l = 0;
		char a[N];
		for (int i = 1; i <= len; ++i){
			if (ch[i] != '[') a[++l] = ch[i];
			else {
				bool flag = false;
				for (int j = 1; j <= max(len, l); ++i){
					if (a[j] < ch[j]){
						flag = true;
						break;
					}
				}
				if (flag){
					for (int j = i; j <= l; ++j) ch[j] = a[j];
					ch[l+1] = '[';
					for (int j = l + 2; j <= len; ++j)
				}
			}
		} 
		
	}

	return 0;
}

