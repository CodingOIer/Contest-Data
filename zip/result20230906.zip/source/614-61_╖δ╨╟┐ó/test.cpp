#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
//	freopen (".in", "r", stdin);
//	freopen (".out", "w", stdout);
	char ch = getchar();
	printf ("%c", ch);

	return 0;
}

