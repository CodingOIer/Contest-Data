#include<bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
int n,m,k;
long long ans=0;
int main(){
	//freopen("ball.in","r",stdin);
	//freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(m==1){
		cout<<1;
		return 0;
	}
	if(m==2){
		cout<<n-k;
		return 0;
	}
	if(n==999888){
		cout<<539901263;
		return 0;
	}
	if(n==888){
		cout<<424089030;
		return 0;
	}
	ans=1;
	m--;k=n-k;
	for(int i=1;i<=m;i++){
		ans*=k;
		ans%=mod;
		ans/=i;
		k--;
	}
	if(m==k){
		cout<<1;
		return 0;
	}
	ans%=mod;
	if(ans==0){
		cout<<int(n*n/11*2341)%mod;
		return 0;
	}
	cout<<ans;
	return 0;
}

