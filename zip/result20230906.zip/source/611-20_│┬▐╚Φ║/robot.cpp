#include<bits/stdc++.h>
using namespace std;
int n,m1,n1,a[50000],b[50100],top1,top,tl1,tl,lon,lon1,lon2;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>n1;
	for(int i=1; i<=n; i++) {
		scanf("%d",&a[i]);
	}
	top1=1;
	tl1=1;
	if(n==1) {
		cout<<0;
		return 0;
	}
	if(n==2){
		cout<<0;
		return 0;
	}
	if(n>=3 && n<=10){
		if(a[1]>a[2] && a[2]>a[3] || a[1]<a[2] && a[2]<a[3]){
			cout<<0;
			return 0;
		}
	}
	for(int i=2; i<=n; i++) {
		if(a[i]<a[i-1] || i==n) {
			if(i==n && a[i]>a[i-1]){
				top=top1;
				tl=tl1+1;
				break;
			}
			if(lon1>lon) {
				top=top1;
				tl=tl1;
			}
			top1=i;
			tl1=i;
		} else {
			tl1++;
			lon1++;
		}
	}
	if(top==1 && tl==n){
		cout<<0;
		return 0;
	}
	cout<<min(m1,n1)*(n-lon);
	return 0;
}
/*
5 2 3
1 2 3 5 4
*/
