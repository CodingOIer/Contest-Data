#include<bits/stdc++.h>
using namespace std;
int n;
string a;
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a;
		cout<<a<<endl;
	}
	return 0;
}

