#include<bits/stdc++.h>
using namespace std;
const int N = 5e4+5,M = 1e3+5,inf = 2e9;
int n,m1,m2,a[N],b[N],m,ans = inf,dp[N],_dp[N];
signed main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m1>>m2;
	for(int i = 1;i<=n;i++)
		cin>>a[i],b[i] = a[i];
	sort(b+1,b+n+1);
	m = unique(b+1,b+n+1)-b-1;
	for(int i = 1;i<=n;i++)
		a[i] = lower_bound(b+1,b+m+1,a[i])-b;
	memset(dp,0x3f,sizeof dp);
	for(int i = 1;i<a[1];i++)
		dp[i] = m1;
	for(int i = a[1]+1;i<=m;i++)
		dp[i] = m2;
	dp[a[1]] = 0;
	for(int i = 2;i<=n;i++)
	{
		memcpy(_dp,dp,sizeof dp);
		int mn = inf;
		for(int j = 1;j<=m;j++)
		{
			if(j<a[i]) dp[j] = m1;
			else if(j>a[i]) dp[j] = m2;
			else dp[j] = 0;
			dp[j]+=(mn = min(mn,_dp[j]));
		}
	}
	for(int i = 1;i<=m;i++)
		ans = min(ans,dp[i]);
	memset(dp,0x3f,sizeof dp);
	for(int i = 1;i<a[n];i++)
		dp[i] = m1;
	for(int i = a[n]+1;i<=m;i++)
		dp[i] = m2;
	dp[a[n]] = 0;
	for(int i = n-1;i>=1;i--)
	{
		memcpy(_dp,dp,sizeof dp);
		int mn = inf;
		for(int j = 1;j<=m;j++)
		{
			if(j<a[i]) dp[j] = m1;
			else if(j>a[i]) dp[j] = m2;
			else dp[j] = 0;
			dp[j]+=(mn = min(mn,_dp[j]));
		}
	}
	for(int i = 1;i<=m;i++)
		ans = min(ans,dp[i]);
	cout<<ans;
	return 0;
}

