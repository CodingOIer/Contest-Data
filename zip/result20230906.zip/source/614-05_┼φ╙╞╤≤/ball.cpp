#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9+7,N = 1e6+5;
int n,m,k;
int qpow(int x,int y)
{
	int res = 1;
	while(y)
	{
		if(y&1) res = res*x%mod;
		y>>=1;
		x = x*x%mod;
	}
	return res;
}
int inv(int x)
{
	return qpow(x%mod,mod-2);
}
int a(int n,int m)
{
	int res = 1;
	for(int i = m;i>=m-n+1;i--)
		res*=i,res%=mod;
	return res;
}
int c(int n,int m)
{
	return a(n,m)*inv(a(n,n))%mod;
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m>>k;
	cout<<c(m-1,n-k);
	return 0;
}

