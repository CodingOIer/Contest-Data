#include<bits/stdc++.h>
using namespace std;
int t,n;
string s;
signed main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>t;
	while(t--)
	{
		cin>>s;
		if(s.size()<=2) cout<<s<<'\n';
	}
	return 0;
}

