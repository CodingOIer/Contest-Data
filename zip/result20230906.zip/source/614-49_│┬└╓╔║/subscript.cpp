#include<bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;
ll t;
int n;
string s;
string dfs(string ts) {
	string ret="",res="";
	int L=ts.size();
	int f=0;
	for(int i=0;i<L;i++) {
		if(ts[i]=='[') {
			f++;
			if(f==1) {
				res="";
				continue;
			}
		}
		if(ts[i]==']') {
			f--;
			if(f==0) {
				string u=dfs(res);
				if(ret<=u) ret=ret+"["+u+"]";
				else ret=u+"["+ret+"]";
				continue;
			}
		}
		if(f==0) ret+=ts[i];
		else res+=ts[i];
	}
	return ret;
}
int main() {
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>t;
	while(t--) {
		cin>>s;
		cout<<dfs(s)<<"\n";
	}
	return 0;
}

