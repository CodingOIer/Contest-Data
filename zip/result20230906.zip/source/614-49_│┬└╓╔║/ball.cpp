#include<bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;
const ll mod=1e9+7;
ll n,m,k,c[1000006];
ll ksm(ll x,ll y) {
	ll res=1;
	while(y) {
		if(y&1) res=res*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return res;
}
ll C(ll x,ll y) {
	return c[x]*ksm(c[y]*c[x-y]%mod,mod-2)%mod;
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(k==n) {
		if(m>1) cout<<0;
		else cout<<1;
		return 0;
	}
	c[0]=1;
	for(ll i=1;i<=n;i++) {
		c[i]=c[i-1]*i%mod;
	}
	cout<<C(n-k,m-1);
	return 0;
}

