#include<bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;
const int N=5e4+5;
ll n,m1,m2,h[N];
int f1[N],f2[N];
int l,r,mid,tl,tr;
ll ans;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++) {
		cin>>h[i];
	}
	l=r=1;
	f1[1]=f2[1]=h[1];
	for(int i=2;i<=n;i++) {//���� 
		int x=h[i],ret=r;
		while(l<=r) {
			mid=(l+r)/2;
			if(f1[mid]<=x) {
				l=mid+1;
				ret=mid+1;
			} else {
				r=mid-1;
			}
		}
		f1[ret]=x;
		l=1;
		if(ret==1) {
			tl=i;
		}
		if(ret>r) {
			r=ret;
			tr=i;
		}
	}
	ans=(n-r)*m1;
	l=r=1;
	for(int i=2;i<=n;i++) {//���� 
		int x=h[i],ret=r;
		while(l<=r) {
			mid=(l+r)/2;
			if(f2[mid]>=x) {
				r=mid-1;
				ret=mid+1;
			} else {
				l=mid+1;
			}
		}
		f2[ret]=x;
		l=1;
		if(ret==1) {
			tl=i;
		}
		if(ret>r) {
			r=ret;
			tr=i;
		}
	}
	ans=min(ans,(n-r)*m2);
	cout<<ans;
	return 0;
}

