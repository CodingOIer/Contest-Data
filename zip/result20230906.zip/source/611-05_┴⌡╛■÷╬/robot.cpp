#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
int n,m1,m2,a[50505],b[50505];
void hf()
{
	for(int i=1;i<=n;i++)
		b[i]=a[i];
}
void pf()
{
	int minx1=0,minx2=0,i=0;
	hf();for(i=1;i<=n-1;i++) if(b[i]<b[i+1]) break;
	for(;i<=n;i++) if(b[i]>b[i+1]) minx1+=m2,b[i]=b[i+1];
	hf();for(i=2;i<=n;i++) if(b[i]<b[i-1]) break;
	for(;i<=n;i++) if(b[i]>b[i-1]) minx2+=m1,b[i]=b[i-1];
	cout << min(minx1,minx2);
	exit(0);
}
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin >> n >> m1 >> m2;
	for(int i=1;i<=n;i++)
		cin >> a[i];
	pf();
	return 0;
}

