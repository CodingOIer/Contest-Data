#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
char a[101010];
int n,t;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin >> t;
	for(int T=1;T<=t;T++)
	{
		memset(a,'\0',sizeof(a));
		cin >> a+1;
		n=strlen(a+1);
		cout << a << endl;
		
	}
	return 0;
}
