#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
ll n,m,k,ans,vis[20];
void f(int cnt)
{
	if(cnt>=m)
	{
		ans++;
		return;
	}
	for(int i=k+1;i<=n;i++)
	{
		if(!vis[i])
		{
			vis[i]=1;
			f(cnt+1);
			vis[i]=0;
		}
	}
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin >> n >> m >> k;
	if(k+m>n) return cout << 0,0;
	else if(n==m) cout << n-k;
	if(n<=10)
	{
		vis[k]=1;
		f(1);
		return cout << ans,0;
	}
	else
	{
		ans=1;
		int suml=n-k,sumr=m-1;
		if(suml<sumr) swap(suml,sumr);
		for(int i=suml,sum=1;sum<=sumr&&i>=1;i--,sum++)
		{
			ans=(ans*i)%1000000007;
		}
		return cout << ans%1000000007,0;
	}
}
