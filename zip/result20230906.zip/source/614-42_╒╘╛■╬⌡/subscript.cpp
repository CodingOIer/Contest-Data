#include<bits/stdc++.h>
using namespace std;

//byd�����ַ��� ���Ҹ�ϰ�˺þ�����  :(  WAW 

//struct s{
//	long long f;//father 
//	string a[100010];//string :(
//} b[100010];

long long n,t=1,tt=1;
string str,a[100010];
//
//bool cmp(s aa,s bb){
//	return aa.a<bb.a;
//}

int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=t;j++){
			a[j]="";
		}
		t=1;
		cin>>str;
		for(int j=0;j<str.length();j++){
			if(str[j]=='[' || str[j]==']'){
				t++;
			}
			else{
				a[t]+=str[j];
			}
		}
		sort(a+1,a+1+t);
		long long tmp=1;
		for(int j=1;j<=t;j++){
			if(a[j]!=""){
				tmp=j;
				break;
			}
		}
		cout<<a[tmp];
		for(int j=tmp+1;j<=t;j++){
			cout<<"["<<a[j]<<"]";
		}//̫����:( ʱ�䵽�� QAQ  
		cout<<"\n";
	}
	return 0;
}

