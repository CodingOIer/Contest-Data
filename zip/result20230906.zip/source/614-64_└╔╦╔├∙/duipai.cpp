#include<bits/stdc++.h>
using namespace std;
int main() {
	ios::sync_with_stdio(false);
	while(1){
		system("pai.bat");
	}
	return 0;
}

