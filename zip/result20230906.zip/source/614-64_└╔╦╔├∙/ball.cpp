#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e9+7;
int n,m,k;
int jc(int n) {
	int ret=1;
	for(int i=1; i<=n; i++) ret=(ret*i)%maxn;
	return ret;
}
int c(int n,int m) {
	int shang=jc(n),xia1=jc(n-m),xia2=jc(m),tmp=1,ret=1;
	tmp*=(xia1*xia2)%maxn;
	ret=shang/tmp;
	return ret;
}
signed main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>k;
	cout<<c(n-k,m-1)<<endl;
	return 0;
}
//�����÷֣�100
//ʵ�ʵ÷֣�40 
