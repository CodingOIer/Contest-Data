#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int main() {
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1; i<=n; i++) {
		getline(cin,s);
		cout<<s<<endl;
	}
	return 0;
}
//�����÷֣�100
//ʵ�ʵ÷֣�50?
