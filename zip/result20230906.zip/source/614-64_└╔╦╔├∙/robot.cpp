#include<bits/stdc++.h>
using namespace std;
int n,a[50010],m1,m2,ans1,ans2;
deque<int> deq;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++){
		while(deq.size()){
			if(a[i]<deq.back()){
				ans1+=m1;
			}else ans2+=m2;
			deq.pop_back();	
		}
		deq.push_back(a[i]);
	}
	cout<<min(ans1,ans2)<<endl;
	return 0;
}
//�����÷֣�100
//ʵ�ʵ÷֣�0
