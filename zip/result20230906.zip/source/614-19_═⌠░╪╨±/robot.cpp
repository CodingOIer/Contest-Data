#include<bits/stdc++.h>
using namespace std;
int a[100000001]={};
int main(){
	int n,m1,m2;
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	long long x=0,y=0;
	for(int i=2;i<=n;i++){
		if(a[i]>=a[i-1]){
			continue;
		}
		else{
			x+=m1;
		}
	}
	int u=0;
	for(int i=2;i<=n;i++){
//		if(a[i]==a[i+1]&&a[i]<a[i-1]){
//			for(int j=i;;j++){
//				u++;
//				if(a[j]<a[j+1]){
//					break;
//				}
//			}
//			if(u>=(n-(i+u-1))){
//				for(int k=i+u;k<=n;k++){
//					if(a[i]<a[i-1]&&a[i]<a[i+1]){
//						y+=m2;
//						continue;
//					}
//				}
//				cout<<y;
//				return 0;
//			}
//			else{
//				for(int k=i+u;k<=n;k++){
//					if(a[i]<a[i-1]&&a[i]<a[i+1]){
//						y+=m2;
//						continue;
//					}
//				}
//				cout<<y+u*m2;
//				return 0;				
//			}
//		}
		if(a[i+1]>a[i]&&a[i+1]>a[i+2]&&a[i+1]>a[i-1]){
			a[i+1]=a[i];
//			cout<<a[i+1]<<"***"<<endl;
			y+=m2;
		}
		if(a[i]<a[i-1]&&a[i]<a[i+1]){
			y+=m1;
			a[i]=a[i-1];
//			cout<<i<<endl;
			continue;
		}
		if(a[i]<=a[i-1]){
			continue;
		}
		else{
			if(a[i]>a[i-1]) y+=m2; 
//			if(a[i]<a[i-1]) y+=m1;
			a[i]=a[i-1];
//			cout<<i<<endl;
		}
	}
//	cout<<x<<" "<<y;
	cout<<min(x,y);
	return 0;
}

