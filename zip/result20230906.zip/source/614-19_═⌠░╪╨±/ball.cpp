#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m,k;
int C(int x,int y){
	long long ans=1;
	long long ans1=1;
//	if((y-x+1)<(x)){
//		for(int i=1;i<=(y-x+1);i++){
//			ans=(ans%mod)*i%mod;
//		}
//		for(int j=y;j>=x;j--){
//			ans1=(ans1%mod)*j%mod;
//		}
//		return ans1/ans;
//	}
	for(int i=1;i<=x;i++){
		ans=(ans%mod)*i%mod;
	}
	for(int j=y;j>=y-x+1;j--){
		ans1=(ans1%mod)*j%mod;
	}
	return ans1/ans;
} 
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	long long ans=1;
	m--;
	int u=n-k;

//	for(int i=1;i<=m;i++){
//		ans*=i;
//	}
//	long long ans1=1;
//	for(int i=u;i>=u-m+1;i--){
//		ans1*=i;
//	}
//	cout<<ans<<" "<<ans1;

	cout<<C(m,u);

//	int x,y;
//	cin>>x>>y;
//	cout<<C(x,y);
	return 0;
}

