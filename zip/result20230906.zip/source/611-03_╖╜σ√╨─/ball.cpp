#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll mod=1e9+7,mx=1e6+5;
ll n,m,k,fac[mx];
ll ksm(ll k)
{
	ll res=1,p=mod-2;
	while(p)
	{
		if(p&1) res=res*k%mod;
		k=k*k%mod,p>>=1;
	}
	return res%mod;
}
ll C(ll n,ll m){return fac[n]*ksm(fac[m])%mod*ksm(fac[n-m])%mod;}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin >> n >> m >> k;
	fac[0]=1ll;for(ll i=1;i<=n;i++) fac[i]=fac[i-1]*i%mod;
	cout<<max(0ll,C(n-k,m-1));
	return 0;
}
