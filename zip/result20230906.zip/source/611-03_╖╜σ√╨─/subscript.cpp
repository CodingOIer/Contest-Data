#include<bits/stdc++.h>
using namespace std;
const int mx=1e5+5;
struct kkk{int l,r,id;}m[mx];
int t;
string s,S[mx],now="";
void change(string s,int len)
{
	for(int i=cout<<s<<"\n";
	return;
}
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout); 
	cin >> t;
	while(t--)
	{
		cin >> s;
		change(s,s.length());
	}
	return 0;
}
