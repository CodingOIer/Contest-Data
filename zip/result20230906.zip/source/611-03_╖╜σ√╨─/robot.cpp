#include<bits/stdc++.h>
using namespace std;
const int mx=1e5*5+5;
int n,q[mx],p[mx],ans1,ans2,m1,m2;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin >> n >> m1 >> m2;
	q[0]=p[n+1]=-1,q[n+1]=p[0]=1e7+5;
	for(int i=1;i<=n;i++){cin >> q[i];p[i]=q[i];}
	for(int i=n-1;i>=1;i--)
	{
		if(q[i]>q[i+1] && q[i+1] >= n-i) ans1+=m1,q[i]=q[i+1];
		else ans1+=m2,q[i+1]=q[i];
	}
	for(int i=2;i<=n;i++)
	{
		if(p[i]>p[i-1] && p[i-1] >= n-i) ans2+=m2,p[i]=p[i-1];
		else ans2+=m1,p[i-1]=p[i];
	}
//	for(int i=1;i<=n;i++) cout<<q[i]<<" "<<p[i]<<"\n";
	cout<<min(ans1,ans2);
	return 0;
}	
