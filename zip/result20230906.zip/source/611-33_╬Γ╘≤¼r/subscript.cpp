#include<bits/stdc++.h>
using namespace std;
int t;
string s;
int main(){
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	cin>>t;
	while(t--){
		cin>>s;
		cout<<s<<endl;
	}
	return 0;
}

