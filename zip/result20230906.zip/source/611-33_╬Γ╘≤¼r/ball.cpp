#include<bits/stdc++.h>
using namespace std;

long long n,m,k;

int ql(int i,int l){
	long long s=0;
	if(l==m){
		return 1;
	}else if(i==n){
		return 0;
	} 
	for(int j=i+1;j<=n;j++){
		s=(s+ql(j,l+1))%1000000007;
	}
	return s;
}

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(n-k+1>=m){
		cout<<ql(k,1);
	}else{
		cout<<0;
	}
	return 0;
}
