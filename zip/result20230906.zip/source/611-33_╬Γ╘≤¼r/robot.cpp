#include<bits/stdc++.h>
using namespace std;
long long n,m1,m2,h[50001],g[50001],y11,y12,y21,y22,y[5];
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=0;i<n;i++){
		cin>>h[i];
	}
	g[0]=h[0];
	g[n-1]=h[n-1];
	for(int i=1;i<n;i++){
		g[i]=h[i];
		if(g[i]<g[i-1]){
			g[i]=g[i-1];
			y[1]=y[1]+m1;
		}
	}
	g[0]=h[0];
	g[n-1]=h[n-1];
	for(int i=1;i<n;i++){
		g[i]=h[i];
		if(g[i]>g[i-1]){
			g[i]=g[i-1];
			y[2]=y[2]+m2;
		}
	}
	g[0]=h[0];
	g[n-1]=h[n-1];
	for(int i=n-2;i>=0;i--){
		g[i]=h[i];
		if(g[i]<g[i+1]){
			g[i]=g[i+1];
			y[3]=y[3]+m1;
		}
	}
	g[0]=h[0];
	g[n-1]=h[n-1];
	for(int i=n-2;i>=0;i--){
		g[i]=h[i];
		if(g[i]>g[i+1]){
			g[i]=g[i+1];
			y[4]=y[4]+m2;
		}
	}
	y[0]=y[1];
	for(int i=2;i<=4;i++){
		if(y[i]<y[0]){
			y[0]=y[i];
		}
	}
	cout<<y[0];
	return 0;
}

