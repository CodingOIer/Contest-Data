#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Mod=1e9+7;
int n,m,k;
int ans=1;
inline int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
inline int C(int n,int m){
	int cnt=1;
	for(int i=0;i<m;i++)
		cnt=cnt*(n-i)%Mod;
	int cnt1=1;
	for(int i=1;i<=m;i++)cnt1=cnt1*i%Mod;
	return cnt*ksm(cnt1,Mod-2)%Mod;
}
inline void init(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
}
signed main(){
	init();
	scanf("%lld%lld%lld",&n,&m,&k);
	m--;
	n=n-k;
	if(n<m){printf("0");return 0;}
	printf("%lld",C(n,m));
	return 0;
}

