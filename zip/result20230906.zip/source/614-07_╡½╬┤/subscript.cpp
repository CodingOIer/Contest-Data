#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline void init(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
}
const int Maxn=1e5+5,Mod=998244353,Mod1=1e9+7;
int T;
stack<int>stk;
vector<int>s[Maxn];
int f[Maxn];
inline bool cmp(vector<int>a,vector<int>b){
	int len=min(a.size(),b.size());
	for(int i=0;i<len;i++){
		if(a[i]<b[i])return 1;
		if(a[i]>b[i])return 0;
	}
	if(a.size()>b.size())return 0;
	return 1;
}
int vis[Maxn];
int main(){
	init();
	scanf("%d",&T);
	while(T--){
		char ch,ch1;
		while(ch!='['&&ch!=']'&&('a'>ch||ch>'z'))ch=getchar();
		int n=0,len=0;
		while(ch=='['||ch==']'||('a'<=ch&&ch<='z')){
			++len;
			if(ch=='['){f[len]=1;stk.push(n);}
			else if(ch==']'){
				vis[n]++;f[len]=0;
				sort(s+stk.top(),s+n+1,cmp);
				stk.pop();
			}
			else{if(ch1=='['||ch1==']'||len==1)n++;s[n].push_back(ch-'a');f[len]=0;}
			ch1=ch;
			ch=getchar();
		}
		sort(s+1,s+1+n,cmp);
		int cnt=1;
		if(!f[1]){
			for(int i=0;i<s[cnt].size();i++)
				printf("%c",s[cnt][i]+'a');
		}
		else{
			printf("[");
			for(int i=0;i<s[cnt].size();i++)
				printf("%c",s[cnt][i]+'a');
		}
		for(int i=2;i<=len;i++){
			if(f[i]){
				printf("[");
				++cnt;
				for(int j=0;j<s[cnt].size();j++)
					printf("%c",s[cnt][j]+'a');
			}
			if(!vis[cnt])continue;
			for(int i=1;i<=vis[cnt];i++)printf("]");
			vis[cnt]=0;
		}
		puts("");
		for(int i=1;i<=n;i++)s[i].clear();
	}
	return 0;
}

