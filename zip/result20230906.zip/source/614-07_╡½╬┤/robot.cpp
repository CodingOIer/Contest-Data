#include<bits/stdc++.h>
using namespace std;
inline void init(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
}
const int Maxn=5e4+5,Maxh=1e6+5;
int a[Maxn];
int n,m1,m2,h,m;
int t1[Maxh];
inline void add(int x,int d){
	while(x<=h){t1[x]=max(t1[x],d);x+=x&-x;}
}
inline int query(int x){
	int res=0;
	while(x){res=max(res,t1[x]);x-=x&-x;}
	return res;
}
inline void solve75(){
	int ans=0;
	for(int i=1;i<=n;i++){
		int tmp=query(a[i]);
		ans=max(ans,tmp+1);
		add(a[i],tmp+1);
	}
	memset(t1,0,sizeof t1);
	for(int i=n;i;i--){
		int tmp=query(a[i]);
		ans=max(ans,tmp+1);
		add(a[i],tmp+1);
	}
	printf("%d",n-ans);
}
int vis[Maxh];
vector<int>v;
int val[Maxh];
int f[2][1005];
inline void solve(){
	memset(f,0x7f,sizeof f);
	int ans=1e9;
	for(int i=0;i<=m;i++)f[0][i]=0;
	for(int i=1;i<=n;i++){
		int g=1e9;
		for(int j=1;j<=m;j++){
			g=min(g,f[(i+1)&1][j]);
			if(j==val[a[i]])f[i&1][j]=g;
			if(j>val[a[i]])f[i&1][j]=g+m1;
			if(j<val[a[i]])f[i&1][j]=g+m2;
			f[(i+1)&1][j]=f[i&1][j];
		}
	}
	for(int i=1;i<=m;i++)ans=min(ans,f[n&1][i]);
	memset(f,0x7f,sizeof f);
	for(int i=0;i<=m;i++)f[(n+1)&1][i]=0;
	for(int i=n;i;i--){
		int g=1e9;
		for(int j=1;j<=m;j++){
			g=min(g,f[(i+1)&1][j]);
			if(j==val[a[i]])f[i&1][j]=g;
			if(j>val[a[i]])f[i&1][j]=g+m1;
			if(j<val[a[i]])f[i&1][j]=g+m2;
			f[(i+1)&1][j]=f[i&1][j];
		}
	}
	for(int i=1;i<=m;i++)ans=min(ans,f[1][i]);
	printf("%d",ans);
}
int main(){
	init();
	scanf("%d%d%d",&n,&m1,&m2);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]),h=max(h,a[i])+1,vis[a[i]]=1;
	for(int i=1;i<=h;i++)
		if(vis[i])v.push_back(i),m=val[i]=v.size();
	if(m2==1&&m1==1)solve75();
	else solve();
	return 0;
}

