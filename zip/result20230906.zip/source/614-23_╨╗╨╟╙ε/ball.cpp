#include <bits/stdc++.h>
#define int long long
using namespace std;
const int Mod = 1e9+7;
int n,m,k;
int ans;
int ksm(int a,int b)
{
	int s = 1;
	for (; b; b>>=1)
	{
		if (b&1) s = s*a%Mod;
		a = a*a%Mod;
	}
	return s%Mod;
}
int inv(int a){
	return ksm(a,Mod-2);
}
int C(int x,int y)
{
	int sum = 1,invv = 1;
	for (int i = x; i >= x-y+1; i--) sum = i%Mod*sum%Mod;
	for (int i = 1; i <= y; i++) invv = invv*i%Mod;
	return sum*inv(invv)%Mod;
}
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	if (m > n-k){
		printf("0");
		return 0;
	}
	ans = C(n-k,m-1);
	printf("%lld",ans);
	return 0;
}
