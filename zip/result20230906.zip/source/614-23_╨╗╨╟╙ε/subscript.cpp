#include <bits/stdc++.h>
using namespace std;
int t;
string s;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		cin >> s;
		s += ' ';
		if (s.size() <= 2) cout << s;
		else if (s.size() <= 6)
		{
			char a[114] = {},b[114] = {};
			int cnt = 0,cnt2 = 0;
			for (int i = 0; i <= s.size(); i++)
			{

				if (s[i] == '['){
					for (int j = i+1; j <= s.size(); j++)
					{
						if (s[j] == ']') break;
						b[++cnt2] = s[j];						
					}
					break;
				}
				a[++cnt] = s[i];
			}
			int flag = 0;
			for (int i = 1; i <= min(cnt,cnt2); i++)
			{
				if (i == min(cnt,cnt2))
				{
					if (b[i] < a[i]) flag = 1;
					else if (b[i]==a[i]) flag = (cnt2<cnt);
					break;
				}
				if (b[i] < a[i]){
					flag = 1;
					break;
				}
			}
			if (flag)
			{
				for (int i = 1; i <= cnt2; i++) cout << b[i];
				cout << "[";
				for (int i = 1; i <= cnt; i++) cout << a[i];
				cout << "]";
			}
			else cout << s;
		} 
	}
	return 0;
}
