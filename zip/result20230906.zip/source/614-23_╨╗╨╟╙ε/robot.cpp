#include <bits/stdc++.h>
using namespace std;
int n,m1,m2,id;
int h[50005] = {},dp_up[50005],dp_down[50005];
int ans = 0,flag = 0;
map<int,int> ton;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%d %d %d",&n,&m1,&m2);
	ans = n*m1;
	for (int i = 1; i <= n; i++)
	{
		scanf("%d",&h[i]);
		dp_up[i] = dp_down[i] = 1;
		ton[h[i]]++;
		if (ton[h[i]] > 1) id = h[i];
		if (h[i] != 1 && h[i] != 2) flag = 1;
	}
	if (flag)
	{
		ans -= ton[id]*m1;
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j < i; j++)
				if (h[i] >= h[j]) dp_up[i] = max(dp_up[i],dp_up[j]+1);
			ans = min(ans,(n-dp_up[i])*m1);
		}
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j < i; j++)
				if (h[i] <= h[j]) dp_down[i] = max(dp_down[i],dp_down[j]+1);
			ans = min(ans,(n-dp_down[i])*m1);
		}		
	}
	else ans = min(ton[1],ton[2])*m1;
	printf("%d",ans);
	return 0;
}
