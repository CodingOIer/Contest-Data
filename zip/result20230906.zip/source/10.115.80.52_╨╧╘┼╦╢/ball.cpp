#include <bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
long long n,m,k,ans=1,len,f[1000005],g[1005][1005];
long long fpow(long long a,long long b,long long p){
	long long ans=1;
	while(b){
		if(b&1)ans=(ans*a)%p;
		b/=2;
		a=(a*a)%p;
	}
	return ans%p;
}
bool vis[2][1005][1005];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;//����˵,�������� 
	f[1]=1;
	for(int i = 2;i <= n;i++)
		f[i]=(f[i-1]*i)%mod;
	if(n-k<m-1){
		cout <<0;
		return 0;
	}
	else{
		for(int i =n-k,j=1;j<=n-k-1;i--,j++)ans=((ans%mod)*(i%mod))%mod;
		cout << ans%mod;
	}
	return 0;
}
