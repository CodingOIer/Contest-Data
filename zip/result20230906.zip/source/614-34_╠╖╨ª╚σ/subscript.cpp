#include <bits/stdc++.h>

using namespace std ;

int main ()
{
	freopen ( "subscript.in" , "r" , stdin ) ;
	freopen ( "subscript.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	int t ;
	cin >> t ;
	while ( t -- )
	{
		string s ;
		getline ( cin , s ) ;
		cout << s << endl ;
	}
	return 0 ;
}

