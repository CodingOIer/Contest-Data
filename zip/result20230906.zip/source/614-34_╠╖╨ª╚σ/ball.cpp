#include <bits/stdc++.h>

using namespace std ;

typedef unsigned long long ull ;

const ull mod = 1000000000 + 7 ;

ull num [11000005] ;

ull C ( ull m , ull n )
{
	m = ( ( n - m ) < m ? ( n - m ) : m ) ;
//	cout << n << " " << m << '\n' ;
	if ( num [n * 10 + m] )
	{
		return num [n * 10 + m] ;
	}
	if ( m == 0 )
	{
		num [n * 10 + m] = 0 ;
	}
	else if ( n == m )
	{
		num [n * 10 + m] = 1 ;
	}
	else if ( m == 1 )
	{
		num [n * 10 + m] = n ;
	}
	else
	{
		num [n * 10 + m] = ( C ( m - 1 , n - 1 ) + C ( m , n - 1 ) ) % mod ;
	}
	return num [n * 10 + m] ;
}

int main ()
{
	freopen ( "ball.in" , "r" , stdin ) ;
	freopen ( "ball.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	ull n , m , k ;
	cin >> n >> m >> k ;
	cout << C ( m - 1 , n - k ) << endl ;
	return 0 ;
}

