#include <bits/stdc++.h>

using namespace std ;

int num [100005] ;

int main ()
{
	freopen ( "robot.in" , "r" , stdin ) ;
	freopen ( "robot.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	int n , m1 , m2 , cnt_hig = 0 , cnt_low = 0 ;
	cin >> n >> m1 >> m2 ;
	for ( int i = 0 ; i < n ; i ++ )
	{
		cin >> num [i] ;
		if ( ! i )
		{
			cnt_hig += bool ( num [i - 1] - num [i] >= 0 ) ;
			cnt_low += bool ( num [i - 1] - num [i] <= 0 ) ;
//			cout << cnt_hig << " " << cnt_low << endl ;
		}
	}
	cout << min ( ( cnt_hig >> 1 ) * m2 , ( cnt_low >> 1 ) * m1 ) ;
	return 0 ;
}

