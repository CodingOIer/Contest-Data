#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>t;
	for(int i=0;i<t;i++){
		string s;
		cin>>s;
		cout<<s<<endl;
	}
	return 0;
}
