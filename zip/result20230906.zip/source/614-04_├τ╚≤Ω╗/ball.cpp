#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],b[15][1000005];
int dfs1(int x,int d){
	if(x==1)
		return d;
	if(a[x][d]!=0)
		return a[x][d];
	long long ans=0;
	for(int i=1;i<=d-x+1;i++)
		ans=(ans+dfs1(x-1,d-i))%1000000007;
	a[x][d]=ans;
	return ans;
}
int dfs2(int x,int d){
	if(x==1)
		return d;
	if(b[x][d]!=0)
		return b[x][d];
	long long ans=0;
	for(int i=1;i<=d-x+1;i++)
		ans=(ans+dfs2(x-1,d-i))%1000000007;
	b[x][d]=ans;
	return ans;
}
int main(){
	int n,m,k;
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(n<=1000&&m<=1000)
		cout<<dfs1(m-1,n-k);
	else
		cout<<dfs2(m-1,n-k);
	return 0;
}
