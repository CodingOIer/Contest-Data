#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using i = int;
i main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ll n,m,k,ans=1;
	cin>>n>>m>>k;
	n=n-k;
	m-=1;
	for(ll i=1; i<=m; i++)
		ans=(ans*(n-i+1)/i);
	cout<<ans%1000000007;
	return 0;
}


