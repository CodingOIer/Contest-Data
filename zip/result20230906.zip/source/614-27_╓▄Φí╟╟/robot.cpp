#include<bits/stdc++.h>
using namespace std;
const int N=5e4+5,INF=1145141919; 
inline void read(int &x){
	x=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x*=f;
}
int n,m1,m2,h[N],idx;
struct node{int h,i;}a[N];
inline bool cmp(node x,node y){return x.h<y.h;}
int f[2][1005],ans=INF;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	read(n),read(m1),read(m2);
	for(int i=1;i<=n;i++) read(a[i].h),a[i].i=i;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		if(a[i].h^a[i-1].h) ++idx;
		h[a[i].i]=idx;
	}
	f[0][0]=f[1][0]=INF;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=idx;j++){
		f[i&1][j]=f[!(i&1)][j]+(j^h[i]?(j<h[i]?m1:m2):0);
		f[i&1][j]=min(f[i&1][j-1],f[i&1][j]);
	}
	for(int i=1;i<=idx;i++) ans=min(ans,f[n&1][i]);
	memset(f,0,sizeof(f));
	f[0][idx+1]=f[1][idx+1]=INF;
	for(int i=1;i<=n;i++)
	for(int j=idx;j;j--){
		f[i&1][j]=f[!(i&1)][j]+(j^h[i]?(j<h[i]?m1:m2):0);
		f[i&1][j]=min(f[i&1][j+1],f[i&1][j]);
	}
	for(int i=1;i<=idx;i++) ans=min(ans,f[n&1][i]);
	printf("%d",ans);
	return 0;
}

