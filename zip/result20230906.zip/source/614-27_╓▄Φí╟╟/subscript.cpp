#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
inline void read(int &x){
	x=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x*=f;
}
int T,n,pd[N];
char S[N],c[N<<1];
stack<int> stk;
int nxt[N<<1],cnt;
struct new_str{
	int head,end;
	inline bool min_(new_str y){
		int i=head,j=y.head;
		while(i&&j){
			if(c[i]<c[j]) return 1;
			if(c[i]>c[j]) return 0;
			if(i==end) return 1;
			if(j==end) return 0;
			i=nxt[i],j=nxt[j];
		}return 0;
	}
	inline void p_c(char ch){
		c[++cnt]=ch;
		if(end) nxt[end]=cnt;
		end=cnt;
	}
	inline void p_b(new_str t){
		nxt[end]=t.head;
		end=t.end;
	}
	inline void ins(new_str t){
		nxt[t.end]=head;
		head=t.head;
	}
	inline void ic(char ch){
		c[++cnt]=ch;
		nxt[cnt]=head;
		head=cnt;
	}
	inline void print(){
		for(int i=head;i;i=nxt[i]){
			putchar(c[i]);
			if(i==end) return;
		}
	}
}ans;
void solve(int l,int r,new_str &s){
	int i=l;
	s=(new_str){cnt+1,0};
	for(;i<=r&&S[i]^'[';i++) s.p_c(S[i]);
	new_str t;
	for(;i<=r;i++){
		solve(i+1,pd[i]-1,t);
		if(s.min_(t)){
			s.p_c('[');
			s.p_b(t);
			s.p_c(']');
		}else{
			s.ic('[');
			s.ins(t);
			s.p_c(']');
		}
		i=pd[i];
	}
}
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	read(T);
	while(T--){
		cnt=0;
		scanf("%s",S+1);
		n=strlen(S+1);
		for(int i=1;i<=n;i++){
			if(S[i]=='[') stk.push(i);
			if(S[i]==']') pd[stk.top()]=i,stk.pop();
		}
		solve(1,n,ans);
		ans.print();
		putchar('\n');
	}
	return 0;
}

