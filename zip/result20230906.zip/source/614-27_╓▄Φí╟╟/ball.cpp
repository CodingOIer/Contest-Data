#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=1e9+7;
inline void read(int &x){
	x=0;int f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	x*=f;
}
int n,m,k;
ll c=1,ans=1;
inline int ksm(ll x,int y){
	ll ans=1;
	while(y){
		if(y&1) ans=ans*x%mod;
		x=x*x%mod;
		y>>=1;
	}return ans;
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	read(n),read(m),read(k);
	--m,n-=k;
	for(int i=2;i<=n-m;i++) c=c*i%mod;
	for(int i=2;i<=m;i++) c=c*i%mod;
	for(int i=2;i<=n;i++) ans=ans*i%mod;
	ans=ans*ksm(c,mod-2)%mod;
	printf("%lld",ans);
	return 0;
}
//c(n,3)=n*(n-1)*(n-2)/6
//c(n,m)=!n/(!(n-m)*!m)
