#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=a;i<=b;i++)
#define ROF(i,a,b) for(ll i=a;i>=b;i--)
using namespace std;
inline int read() {
	int ret=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) {
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
string a[500005];
string tmp[500005];
int main() {
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int n=read();
	FOR(i,1,n) cin>>a[i];
	int top=0;
	FOR(i,1,n) {
		int have=0;
		FOR(j,0,a[i].size()) {
			if(a[i][j]=='[') {
				top++;
				have++; 
				continue;
			}
			if(a[i][j]==']') {
				tmp[top-1]=min(tmp[top-1],tmp[top])+'['+max(tmp[top],tmp[top-1])+']';
//				cout<<tmp[top-1]<<" ";
				tmp[top]="";
				top-=1;
				continue;
			}
			tmp[top]+=a[i][j];
//			cout<<top<<" "<<tmp[top]<<endl;
		}
		cout<<tmp[0]<<endl;
		FOR(i,0,have) tmp[i]="";
	}

	return 0;
}


