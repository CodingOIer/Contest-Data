#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=a;i<=b;i++)
#define ROF(i,a,b) for(ll i=a;i>=b;i--)
using namespace std;
inline int read() {
	int ret=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) {
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
const ll mod=1e9+7;
ll A(ll a,ll b){
	ll sum=1;
	FOR(i,max(1ll,a-b),a) sum=(sum*i)%mod;
	cout<<sum<<' ';
	return sum%mod;
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ll n=read(),m=read(),k=read();
	cout<<A(n-k,m-1)/A(m-1,m-1); 
	return 0;
}


