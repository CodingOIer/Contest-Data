#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=a;i<=b;i++)
#define ROF(i,a,b) for(ll i=a;i>=b;i--)
using namespace std;
inline int read() {
	int ret=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) {
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
ll h[50010],tmp[50010];
int vis[1000007],vis2[10000007];
basic_string<int>ed;
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	ll n=read(),m1=read(),m2=read();
	FOR(i,1,n) {
		h[i]=read();
		tmp[i]=h[i];
		if(vis[h[i]]==0) ed+=h[i];
		vis[h[i]]++;
	}
	int ans=0;
	FOR(i,1,n) {
		vis[tmp[i]]++;
		if(tmp[i]==tmp[i-1])continue;
		if(tmp[i]>tmp[i-1]) {
			int s=0,s2=0,have=0,have2=0;
			for(int y:ed) {
				if(y<tmp[i-1])s+=(vis[y]-vis2[y]);
				if(y<tmp[i]) s2+=(vis[y]-vis2[y]);
				if(y>tmp[i]) have+=(vis[y]-vis2[y]);
				if(y>tmp[i-1]) have2+=(vis[y]-vis2[y]);
			}
			if(s2*m1>m2+s*m1+(have+have2)*m2) tmp[i]=tmp[i-1],ans+=m2;
		} else  ans+=m1,tmp[i]=tmp[i-1];
//		cout<<i<<" "<<ans<<endl;
	}
//	cout<<ans<<endl;
	int ans2=0;
	FOR(i,0,1e7) vis2[i]=0;
	ROF(i,n,1) {
		vis2[h[i]]++;
		if(h[i]==h[i+1]) continue;
		int s=0,s2=0,have=0;
		if(h[i]>=h[i+1]) {
			for(int y:ed) {
				if(y<h[i+1]) s+=(vis[y]-vis2[y]);
				if(y<h[i]) s2+=(vis[y]-vis2[y]);
				if(y>h[i]) have+=(vis[y]-vis2[y]);
			}
			if(s2*m1>m2+s*m1+have*m2) h[i]=h[i+1],ans2+=m2;
		} else  ans2+=m1,h[i]=h[i+1];
//		cout<<s<<" "<<s2<<" "<<i<<" "<<ans2<<endl;
	}
	cout<<min(ans,ans2);
	return 0;
}


