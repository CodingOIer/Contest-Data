#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=a;i<=b;i++)
#define ROF(i,a,b) for(ll i=a;i>=b;i--)
using namespace std;
inline int read() {
	int ret=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) {
		if(ch=='-') f=1;
		ch=getchar();
	}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
struct SKY {
	int m,id;
} q[500005];
ll a[500005],tmp[500005];
int vis[500005];
int main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	ll n=read(),m1=read(),m2=read();
	FOR(i,1,n) tmp[i]=a[i]=read();
	int topp=m2/m1+((m2%m1>=1)?1:0);
	int r=1,top=0;
	ll ans=0;
	a[0]=1e12;
	FOR(i,1,n) {
//		if(a[i]<a[i+1]) {
//			cout<<i;
		ll id2=1e12;
		FOR(j,i+1,i+topp)
		if(tmp[j]>=tmp[i] || tmp[j]<tmp[i-1]) {
			id2=1;
			break;
		}
		if(id2==1 && tmp[i]>=tmp[i-1]) continue;
		if(id2=1e12 && tmp[i]==tmp[i-1]) continue;
		if(id2==1) ans+=m1,tmp[i]=tmp[i-1];
		else if(tmp[i]>=tmp[i-1]) ans+=m2,tmp[i]=tmp[i+1];
		else ans+=m1,tmp[i]=tmp[i-1];
//		cout<<i<<' '<<ans<<endl;
//		}
	}
	ll ans2=0;
//	cout<<ans<<endl;
	a[0]=1e12;
	a[n+1]=0;
	ROF(i,n,1) {
//		cout<<1;
		ll id2=2;
		FOR(j,i-topp,i-1)
		if(a[j]>=a[i] || a[j]<a[i+1]) {
			id2=1;
			break;
		}
		if(id2==2 && a[i]==a[i-1]) continue;
		if(id2==1 && a[i]>=a[i+1]) continue;
		if(id2==1) ans2+=m1,a[i]=a[i+1];
		else if(a[i]>=a[i+1]) ans2+=m2,a[i]=a[i-1];
		else ans2+=m1,a[i]=a[i+1];
//		cout<<id2<<" "<<i<<' '<<ans2<<endl;
//		}
	}
	cout<<min(ans2,ans);
	return 0;
}


