#include<bits/stdc++.h>
#define int long long
using namespace std;
int32_t main(){
#ifndef debag
	int a[10]={1,2,3,4,5,6,7,8,9,10},i=4,c[10]={1,2,3,4,5,6,7,8,9,10};
#endif
cout<<c[i][5];

}

