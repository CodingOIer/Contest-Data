#include<bits/stdc++.h>


using namespace std;
const int mod=1000000000+7;
int n,m,k,ans=0;

void dfs(int little,int dn){
	if(dn==0){
		ans++;
		ans%=mod;
		return;
	}
	if(little>n){
		return;
	}
	for(int i=little;i<=n;i++){
		dfs(i+1,dn-1);
	}
}
int32_t main(){
#ifndef debag
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
#endif

	cin>>n>>m>>k;
	if(n-k+1<m){
		cout<<0;
		return 0;
	}
	if(m==1){
		cout<<1;
		return 0;
	}
	dfs(k+1,m-1);
	cout<<ans;
	
}

