#include<bits/stdc++.h>
#include<unistd.h> 
#include<conio.h> 
#define int long long
using namespace std;
int32_t main(){
#ifndef debag
	
#endif
for(int i=60;i>=60;i--){
	cout<<i;
	sleep(1);
	system("cls");
}
for(double i=600;i>0;i-=1){
	printf("%.1lf",i/10);
	_sleep(100);
	system("cls");
}
cout<<"BOOM!";
_getch();
}

