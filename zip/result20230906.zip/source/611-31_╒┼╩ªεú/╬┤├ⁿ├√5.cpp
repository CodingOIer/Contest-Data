#include<bits/stdc++.h>
#include<time.h>
#include<unistd.h>
#define int long long
using namespace std;
int a[]={0,1,2,3,4,5,6,7,8,9,0};
int32_t main(){
	vector<int> s;
	srand(time(0));
	while(1)
	while(1)
	while(1)
	while(1){
		for(int i=0;i<rand()%50;i++)if(rand()%101>40)s.push_back(a[rand()%10]);
		for(int i=0;i<rand()%50;i++){
			for(int a=0;a<s.size();a++){
				cout<<s[a]<<" ";
				
			}
		
			if(rand()%101>40)s.erase(s.begin()+rand()%s.size());
		cout<<endl;
		}
		cout<<endl;
	}
}

