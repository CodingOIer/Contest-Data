#include<bits/stdc++.h>
#define int long long
using namespace std;
int32_t main(){
	for(int i=0;i<=100;i++)	
		for(int i=0;i<=9;i++)cout<<i<<",";
}

