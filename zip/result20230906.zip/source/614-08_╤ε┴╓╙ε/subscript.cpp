#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		string str;
		cin>>str;
		cout<<str<<endl;
	}
	
    return 0;
}

