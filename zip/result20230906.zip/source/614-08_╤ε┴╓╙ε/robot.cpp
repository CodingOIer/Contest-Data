#include<bits/stdc++.h>
using namespace std;
int n,a[50005],m,m2;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	
	cin>>n>>m>>m2;
	for(int i=1;i<=n;i++)cin>>a[i];
	cout<<0<<endl;
    return 0;
}

