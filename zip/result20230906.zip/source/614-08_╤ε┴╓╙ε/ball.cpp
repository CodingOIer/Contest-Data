#include<bits/stdc++.h>
using namespace std;
long long const mod=1e9+7;
long long n,m,k,sum=1;
//int book[1000006];
//C(n-k,m-1);
//C(n,m)=C(n/2,m)*2+C(n/2,1)*C(n/2,m-1)+...
//C(n,m)=C(n-1,m)+C(n-1,m-1)
//(n-m+1~n)/(m-1)! 
/*
long long C(long long n,long long m){
	if(n<m)return 0;
	long long sum=0;
	sum=(sum+C(n/2,m))%mod;
	if(n&1)sum=(sum+C((n+1)/2,m))%mod;
	else sum=(sum+C((n+1)/2,m))%mod;
	for(int i=1;i<=m;i++){
		sum=(sum+C(n/2))%mod;
	}
}*/
long long C(long long n,long long m){
	int sum=1;
	for(int i=n-m+1;i<=n;i++)sum=(sum*i)%mod;
	for(int i=m;i>=1;i--)sum/=i;
	return sum%mod;
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	
	cin>>n>>m>>k;
	cout<<C(n-k,m-1)<<endl;
	/*
	for(int i=n-k;i>=n-k-m+2;i--){
		long long tmp=i;
		for(int j=1;j<=m-1;j++){
			if(book[j]==0&&tmp%j==0){
				book[j]=1;
				tmp/=j;
			}
		}
		sum=sum*tmp%mod;
	}*/
    return 0;
}
//8
//5*6*7 
//3*2*1=6 
//35
//3
//7*8*9=6
//3*2*1=6
