#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-') f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * f;
}

struct P {
    int h, i;
} p[100005];

bool cmp(P a, P b) {
    return a.h < b.h;
}

int h[100005];
int dp[2003][3];

int main() {
    freopen("robot.in", "r", stdin);
    freopen("robot.out", "w", stdout);
    int n = read(), m1 = read(), m2 = read();
    for (int i = 1; i <= n; ++i) {
        p[i].h = read();
        p[i].i = i;
    }
    sort(p + 1, p + 1 + n, cmp);
    int cnt = 0;
    h[p[1].i] = ++cnt;
    for (int i = 2; i <= n; ++i) {
        if (p[i].h != p[i - 1].h) cnt++;
        h[p[i].i] = cnt;
    }

    for (int i = 1; i <= n; ++i) {
        int tmp = dp[1][0];
        for (int j = 1; j < h[i]; ++j) {
            tmp = min(tmp, dp[j][0]);
            dp[j][0] = tmp + m2;
        }
        tmp = min(tmp, dp[h[i]][0]);
        dp[h[i]][0] = tmp;
        for (int j = h[i] + 1; j <= cnt; ++j) {
            tmp = min(tmp, dp[j][0]);
            dp[j][0] = tmp + m1;
        }

        tmp = dp[cnt][1];
        for (int j = cnt; j > h[i]; --j) {
            tmp = min(tmp, dp[j][1]);
            dp[j][1] = tmp + m1;
        }
        tmp = min(tmp, dp[h[i]][1]);
        dp[h[i]][1] = tmp;
        for (int j = h[i] - 1; j >= 1; --j) {
            tmp = min(tmp, dp[j][1]);
            dp[j][1] = tmp + m2;
        }
    }


    int ans = min(dp[1][0], dp[1][1]);
    for (int i = 2; i <= cnt; ++i) {
        ans = min(min(dp[i][0], dp[i][1]), ans);
    }
    printf("%d\n", ans);
    return 0;
}