#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-') f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * f;
}


int st[200005], dy[200005];
char s[200005];
char t[200005];
void solve1(int l, int r) {
    int hsr = 0;
    for (int i = r; i >= l; --i) {
        if (s[i] == ']') {
            hsr = dy[i];
            break;
        }
    }
    if (!hsr) return ;
    solve1(l, hsr - 1);
    solve1(hsr + 1, r - 1);
    int lenL = hsr - l, lenR = r - hsr - 1;
    int milen = min(lenL, lenR), b = 0;
    for (int i = 1; i <= milen; ++i) {
        if (s[l + i - 1] == s[hsr + i]) continue;
        if (s[l + i - 1] < s[hsr + i]) return ;
        if (s[l + i - 1] > s[hsr + i]) {
            b = 1;
            break;
        }
    }
    if (!b && lenL <= lenR) return ;
    for (int i = l; i <= hsr - 1; ++i) {
        t[i] = s[i];
    }
    int tmp = l - 1;
    for (int i = hsr + 1; i <= r - 1; ++i) {
        s[++tmp] = s[i];
    }
    s[++tmp] = '[';
    for (int i = l; i <= hsr - 1; ++i) {
        s[++tmp] = t[i];
    }
    s[++tmp] = ']';
    return ;
}



int hd[200005], nx[200005];
void solve(int l, int r) {
    int hsr = 0;
    for (int i = r; i >= l; --i) {
        if (s[i] == ']') {
            hsr = dy[i];
            break;
        }
    }
    if (!hsr) return ;
    solve(l, hsr - 1);
    solve(hsr + 1, r - 1);
    int lenL = hsr - l, lenR = r - hsr - 1;
    int milen = min(lenL, lenR), b = 0;
    int lz = nx[l - 1], rz = nx[hsr];
    for (int i = 1; i <= milen; ++i, lz = nx[lz], rz = nx[rz]) {
        if (s[lz] == s[rz]) continue;
        if (s[lz] < s[rz]) return ;
        if (s[lz] > s[rz]) {
            b = 1;
            break;
        }
    }
    if (!b && lenL <= lenR) return ;
    int A = l - 1, L = nx[A], p1 = hsr, tmp = hd[p1], p2 = r, R = hd[r];
    nx[A] = nx[p1];
    hd[nx[p1]] = A;
    nx[R] = p1;
    hd[p1] = R;
    nx[p1] = L;
    hd[L] = p1;
    nx[tmp] = p2;
    hd[p2] = tmp;
    return ;
}


int main() {
    freopen("subscript.in", "r", stdin);
    freopen("subscript.out", "w", stdout);
    int T = read();
    while (T--) {
        scanf("%s", s + 1);
        int len = strlen(s + 1);
        int top = 0;
        for (int i = 1; i <= len; ++i) {
            if (s[i] == '[') st[++top] = i;
            if (s[i] == ']') dy[i] = st[top--];
        }
        if (len <= 200) {
            solve1(1, len);
            for (int i = 1; i <= len; ++i) {
                putchar(s[i]);
            }
            putchar('\n');
            continue;
        }

        for (int i = 0; i <= len + 1; ++i) hd[i] = i - 1, nx[i] = i + 1;
        solve(1, len);
        for (int i = nx[0]; i <= len; i = nx[i]) {
            putchar(s[i]);
        }
        putchar('\n');
    }
    return 0;
}


