#include <iostream>
#include <cstdio>
#define mod 1000000007
using namespace std;
int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-') f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * f;
}


long long fct[2000006];

long long fsp(long long base, long long p) {
    long long rt = 1;
    while (p) {
        if (p & 1) (rt *= base) %= mod;
        (base *= base) %= mod;
        p >>= 1;
    }
    return rt;
}

long long ny(long long x) {
    return fsp(x, mod - 2);
}

long long C(long long a, long long b) {
    if (b > a) return 0ll;
    return fct[a] * ny(fct[b]) % mod * ny(fct[a - b]) % mod;
}

int main() {
    freopen("ball.in", "r", stdin);
    freopen("ball.out", "w", stdout);
    long long n = read(), m = read(), k = read();
    fct[0] = 1;
    for (int i = 1; i <= n; ++i) fct[i] = fct[i - 1] * (long long)i % mod;
    printf("%lld\n", C(n - k, m - 1));
    return 0;
}