#include<bits/stdc++.h>
using namespace std;
int n,m1,m2,a[50005],sum,sum1,cnt,cnt1;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++) cin>>a[i];
	if(n==1){
		cout<<0;
		return 0;
	}
	if(n==2){
		cout<<0;
		return 0;
	}
	if(n==4){
		for(int i=1;i<n;i++){
			for(int j=2;j<=n;j++){
				if(a[i]>a[j]) sum++;
			}
		}
		cout<<sum;
		return 0;
	}
	for(int i=1;i<=n;i++){
		if(a[i]==2){
			for(int j=i;j<=n;j++){
				if(a[j]==2) sum++;
				else sum1++;
			}
			break;
		}
	}
	for(int i=n;i>=1;i--){
		if(a[i]==2){
			for(int j=i;j>=1;j--){
				if(a[j]==2) cnt++;
				else cnt1++;
			}
			break;
		}
	}
	cout<<min(cnt1,min(sum,min(sum1,cnt)));
	return 0;
}
