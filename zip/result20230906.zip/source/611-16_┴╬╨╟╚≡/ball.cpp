#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long sum;
int main(){
	freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(m==1) cout<<1;
	if(m==2) cout<<n-k;
	return 0;
}
