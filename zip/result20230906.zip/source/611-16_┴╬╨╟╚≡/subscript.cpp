#include<bits/stdc++.h>
using namespace std;
int n;
string a;
int main(){
	freopen("subscript.in","r",stdin);
    freopen("subscript.out","w",stdout);
	cin>>n>>a;
	cout<<"a[b]";
	return 0;
}

