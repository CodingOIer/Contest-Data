#include <bits/stdc++.h>
using namespace std;

int n, m, k;
long long fact[1000001];

const int p = 1e9 + 7;

long long qpow(long long a, long long b, long long p) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		a = a * a % p;
		b >>= 1;
	}
	return res;
}

long long inv(long long a, long long p) {
	return qpow(a, p - 2, p);
}

long long C(long long n, long long m) {
	return fact[n] * inv(fact[n - m], p) % p * inv(fact[m], p) % p;
}

int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	fact[0] = 1;
	for (int i = 1; i <= n; ++i) {
		fact[i] = 1ll * fact[i - 1] * i % p;
	}
	if (n - k < m - 1 || n < m) {
		puts("0");
		return 0;
	}
	printf("%lld\n", C(n - k, m - 1));
	return 0;
}
/*
�����÷֣�100
��÷֣�100
*/

