#include <bits/stdc++.h>
using namespace std;

int n, m1, m2, a[50001], nt;

int main() {
	srand(time(0));
	freopen("robot.in", "w" ,stdout);
	n = 50000;
	m1 = 1ll * rand() * rand() % 1000;
	m2 = 1ll * rand() * rand() % 1000;
	printf("%d %d %d\n", n, m1, m2);
	int yn = n;
	for (int i = 1; i <= 1000; ++i) {
		int tot = rand() % min(100, yn) + 1;
		yn -= tot;
		if (yn == 0) break;
		for (int j = 1; j <= tot; ++j) {
			srand(i);
			a[++nt] = 1ll * rand() * rand() % 1000000 + 1;
		}
	}
	assert(yn);
	for (int i = 2; i <= 50000; ++i) {
		if (i % 100 == 0) srand(i * clock() + time(0));
		swap(a[i], a[rand() % (i - 1) + 1]);
	}
	for (int i = 1; i <= 50000; ++i) printf("%d ", a[i]);
	return 0;
}

