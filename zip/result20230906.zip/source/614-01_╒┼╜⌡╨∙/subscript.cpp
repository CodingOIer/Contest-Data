#include <bits/stdc++.h>
using namespace std;

int t;
string tmp;
char s[1000005];
int f[1000005];
int st[1000005], top;

string dfs(int l, int r, string t) {
	int lastpos = f[r] - l, x = 0, sz = t.size();
	/*for (int i = sz - 1; i >= 0; --i) {
		if (t[i] == ']') ++x;
		if (t[i] == '[') {
			--x;
			if (x == 0) {
				lastpos = i;
				break;
			}
		}
	}*/
	if (f[r] == 0 || lastpos == 0) return t;
	string a = t.substr(0, lastpos);
	string b = t.substr(lastpos + 1, sz - lastpos - 2);
	a = dfs(l, l + lastpos - 1, a);
	b = dfs(l + lastpos + 1, r - 1, b);
	if (a > b) swap(a, b);
	return a + "[" + b + "]";
}

int main() {
	freopen("subscript.in", "r", stdin);
	freopen("subscript.out", "w", stdout);
	scanf("%d", &t);
	while (t--) {
		scanf("%s", s);
		int sz = strlen(s);
		for (int i = 0; i <= sz; ++i) f[i] = 0;
		for (int i = 0; i < sz; ++i) {
			if (s[i] == '[') st[++top] = i;
			else if (s[i] == ']') {
				f[i] = st[top--];
			}
		}
		tmp = s;
		fputs(dfs(0, tmp.size() - 1, tmp).c_str(), stdout); puts("");
	}
	return 0;
}
/*

�����÷֣�100
��÷֣�20
*/
