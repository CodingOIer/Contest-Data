#include <bits/stdc++.h>
using namespace std;

//#pragma GCC optimize(2) QAQ

int n, m1, m2, a[50001];
bool b[1000002];
int hash_value[1000001]; //���ڹ�ϣ 
int f[50002][1002]; // ���仯���� 
int f2[50002][1002]; // ���仯���� 

inline int ghash(int i) { //��ȡ��ϣֵ 
	if (i == 0) return 0; //����ֵ 
	if (i == 1 << 30) return 1001;
	return hash_value[i];
}

inline int dfs(int i, int minn) { // �ݼ���� 
	if (i == n + 1) return 0;
	if (f[i][ghash(minn)] != -1) return f[i][ghash(minn)];
	if (a[i] < minn) {
		return f[i][ghash(minn)] = min(dfs(i + 1, minn) + m1, dfs(i + 1, a[i]));
	} else if (a[i] == minn) {
		return f[i][ghash(minn)] = dfs(i + 1, minn);
	} else {
		// a[i] > minn, �����޸� 
		return f[i][ghash(minn)] = dfs(i + 1, a[i]) + m2;
	}
}

inline int dfs2(int i, int maxn) { // ������� 
	if (i == n + 1) return 0;
	if (f2[i][ghash(maxn)] != -1) return f2[i][ghash(maxn)]; 
	if (a[i] < maxn) {
		// a[i] < maxn, �����޸�
		return f2[i][ghash(maxn)] = dfs2(i + 1, maxn) + m1;
	} else if (a[i] == maxn) {
		return f2[i][ghash(maxn)] = dfs2(i + 1, maxn);
	} else {
		return f2[i][ghash(maxn)] = min(dfs2(i + 1, maxn) + m2, dfs2(i + 1, a[i]));
	}
}

int main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	memset(f, 255, sizeof(f));
	memset(f2, 255, sizeof(f2));
	scanf("%d%d%d", &n, &m1, &m2);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
		b[a[i]] = 1;
	}
	int hash_tot = 0;
	for (int i = 1; i <= 1000000; ++i) {
		if (b[i]) {
			hash_value[i] = ++hash_tot;
		}
	}
	printf("%d\n", min({dfs(1, a[1]), dfs(1, 1 << 30) + m1, dfs2(1, a[1]), dfs2(1, 0) + m2}));
	return 0;
}
/*
�����÷֣�100
��÷֣�65?? 
*/
