#include <iostream>
#include <cstring>
#include <stack>
using namespace std;
const int N = 1e5 + 5;
string s, mp[N];
int T, n, cnt, vis[N];
inline string solve_3(string a, string b, string c) {
	string t1, t2, t3;
	if (a < b) {
		t1 = a;
		if (a > c) {
			t1 = c;
			t2 = a;
		}
		else
			if (b > c)	t2 = c;
			else	t2 = b;
	}
	else {
		t1 = b;
		if (b > c) {
			t1 = c;
			t2 = b;
		}
		else
			if (a > c)	t2 = c;
			else	t2 = a;
	}
	if (t1 == a) {
		if (t2 == b)	t3 = c;
		if (t2 == c)	t3 = b;
	}
	if (t1 == b) {
		if (t2 == a)	t3 = c;
		if (t2 == c)	t3 = a;
	}
	if (t1 == c) {
		if (t2 == a)	t3 = b;
		if (t2 == b)	t3 = a;
	}
	string res = t1 + "[" + t2 + "[" + t3 + "]]";
//	cout << t1 << ' ' << t2 << ' ' << t3 << endl;
	return res;
}
inline string solve_2(string a, string b) {
	string t1, t2;
	if (a < b)	t1 = a, t2 = b;
	else	t1 = b, t2 = a;
	string res = t1 + "[" + t2 + "]";
	return res;
}
signed main() {
	freopen("subscript.in", "r", stdin);
	freopen("subscript.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		cin >> s;
		memset(vis, 0, sizeof(vis));
		n = s.size(), cnt = 0;
		string t, ans;
		for (int i = 0; i < n; ++i) {
			if (s[i] == '[' && t != "") {
				mp[++cnt] = t;
				t = "";
			}
			if (s[i] == ']' && t != "") {
				mp[++cnt] = t;
				t = "";
			}
			if (s[i] >= 'a' && s[i] <= 'z')
				t = t + s[i];
		}
		ans = mp[cnt];
		for (int i = cnt - 1; i - 1 >= 1; i -= 2)
			ans = solve_3(mp[i], mp[i - 1], ans);
		if ((cnt - 1) % 2)
			for (int i = (cnt - 1) % 2; i >= 1; --i)
				ans = solve_2(mp[i], ans);
		cout << ans << '\n';
	}
	return 0;
}

