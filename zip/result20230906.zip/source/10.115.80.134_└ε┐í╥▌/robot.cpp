#include <iostream>
#include <algorithm>
#include <set>
using namespace std;
const int N = 5e4 + 5;
int n, m1, m2, h[N];
int id[N], rev[N];
set<int> mp;
inline bool cmp1(int x, int y) {
	if (h[x] == h[y])
		return x < y;
	return h[x] < h[y];
}
inline bool cmp2(int x, int y) {
	if (h[x] == h[y])
		return x < y;
	return h[x] > h[y];
}
inline int begin() { 
	for (int i = 1; i <= n; ++i)
		id[i] = i;
	sort(id + 1, id + n + 1, cmp1);
	for (int i = 1; i <= n; ++i)
		rev[id[i]] = i;
//	for (int i = 1; i <= n; ++i)
//		cout << id[i] << ' ';
//	cout << '\n';
//	for (int i = 1; i <= n; ++i)
//		cout << rev[i] << ' ';
//	cout << '\n';
	mp.insert(1);
	int tmp = h[1];
	int res = 0, fl = 1;
	if (rev[1] != 1)
		h[1] = 1, ++res, fl = 0;
	for (int i = 1 + fl; i <= n; ++i) {
		if (i == rev[1])	continue;
		set<int>::iterator k = mp.lower_bound(id[i]);
//		cout << i << ' ' << *k << endl;
		if (k == mp.begin()) {
//			cout << i << '\n';
			nxt:;
			int t = 1000;
			if (id[i] != 1)
				if (h[id[i]] > h[id[i] - 1])	t = m2;
				else	t = m1;
			if (id[i] != n)
				if (h[id[i]] > h[id[i] + 1])	t = min(t, m2);
				else	t = min(t, m1);
			res += t;
		}
		else {
			--k;
			mp.erase(k);
			mp.insert(id[i]);
		}
	}
	h[1] = tmp;
	return res;
}
inline int end() {
	for (int i = 1; i <= n; ++i)
		id[i] = i;
	sort(id + 1, id + n + 1, cmp2);
	for (int i = 1; i <= n; ++i)
		rev[id[i]] = i;
//	for (int i = 1; i <= n; ++i)
//		cout << id[i] << ' ';
//	cout << '\n';
//	for (int i = 1; i <= n; ++i)
//		cout << rev[i] << ' ';
//	cout << '\n';
	mp.insert(n);
	int tmp = h[n];
	int res = 0, fl = 1;
	if (rev[n] != n)
		h[n] = 1, ++res, fl = 0;
	for (int i = n - fl; i >= 1; --i) {
		if (i == rev[n])	continue;
		set<int>::iterator k = mp.upper_bound(id[i]);
		if (k == mp.end()) {
//			cout << i << '\n';
			int t = 1000;
			if (id[i] != 1)
				if (h[id[i]] > h[id[i] - 1])	t = m2;
				else	t = m1;
			if (id[i] != n)
				if (h[id[i]] > h[id[i] + 1])	t = min(t, m2);
				else	t = min(t, m1);
			res += t;
		}
		else {
			mp.erase(k);
			mp.insert(id[i]);
		}
	}
	h[n] = tmp;
	return res;
}
signed main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	scanf("%d%d%d", &n, &m1, &m2);
	for (int i = 1; i <= n; ++i)
		scanf("%d", h + i);
	printf("%d", min(begin(), end()));
	return 0;
}

