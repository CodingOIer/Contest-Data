#include <iostream>
#define int long long
using namespace std;
const int mod = 1e9 + 7;
const int N = 1e6 + 5;
int n, m, k;
int f[N];
inline int fast(int x, int p) {
	int res = 1;
	while (p) {
		if (p & 1ll)
			res = res * x % mod;
		x = x * x % mod;
		p >>= 1ll;
	}
	return res;
}
inline int inv(int x) {
	return fast(x, mod - 2) % mod;
}
inline int C(int n, int m) {
	return f[n] * inv(f[n - m]) % mod * inv(f[m]) % mod;
}
inline void init() {
	f[0] = 1;
	for (int i = 1; i <= n; ++i)
		f[i] = f[i - 1] * i % mod;
}
signed main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &k);
	init();
	printf("%lld", C(n - k, m - 1));
	return 0;
}

