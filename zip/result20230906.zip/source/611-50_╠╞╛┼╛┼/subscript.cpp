#include <bits/stdc++.h>
using namespace std;
signed main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cout<<"aaa[bbb]\na[abbb[b]]\na[azzz][b]\na[b][a[x]]";
	return 0;
}
