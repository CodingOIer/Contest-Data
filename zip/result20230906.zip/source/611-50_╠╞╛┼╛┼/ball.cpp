#include <bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
int n,m,k;
int N,M,K;
int ans;
//�����ұ��೤ѹ�����ֱ�
//һ���⣬ҪG 
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
    cin>>N>>M>>K;
	if(M==1)
	{
		cout<<0;
		return 0;
	}
	if(M==2)
	{
		cout<<N-K;
		return 0;
	}
	int n1=1;
	for(int i=1;i<=N-K;i++)n1*=i,n1%=mod;
	int m1,m2;
	m1=m2=1;
	for(int i=1;i<=(N-K)-(M-1);i++)m1*=i,m1%=mod;
	for(int i=1;i<=M-1;i++)m2*=i,m2%=mod;
//	cout<<n1<<' '<<m1<<' '<<m2<<'\n';
	cout<<(n1/(m1*m2))%mod;
    return 0;
}
