#include <bits/stdc++.h> 
using namespace std;
#define int long long
const int N=50005;
int h[N];
int n,m1,m2;
//ֻ��ƭ�� 
signed main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m1>>m2;
	if(n==1||n==2)
	{
		cout<<0;
		return 0;
	}
	int maxl=-1,cntl=0,hl=0;
	int maxr=-1,cntr=1e9,hr=0;
	for(int i=1;i<=n;i++)
	{
		cin>>h[i];
		if(cntl<=h[i])hl++;
		if(cntl>h[i])hl=1;				
		if(cntr>=h[i])hr++;
		if(cntr<h[i])hr=1;		
		if(hl>maxl)maxl=hl;
		if(hr>maxr)maxr=hr;
		cntr=cntl=h[i];
	}
	if(maxl>maxr)
	{
		int ans=0;
		for(int i=1;i<=n-1;i++)
		{
			if(h[i]>h[i+1])
			{
				h[i]=h[i+1];
				ans+=m1;
			}
		}	
		
		cout<<ans;
	}
	else
	{
		int ans=0;
			for(int i=1;i<=n-1;i++)
			{
				if(h[i]<h[i+1])
				{
					h[i]=h[i+1];
				//	cout<<h[i]<<'\n';
					ans+=m1;
				}
			}		
		cout<<ans;
	}
	return 0;
} 
