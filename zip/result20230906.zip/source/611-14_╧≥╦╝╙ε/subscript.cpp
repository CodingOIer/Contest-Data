#include<bits/stdc++.h>
using namespace std;
int n;
string a[100000];
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cout<<a[i]<<endl;
	return 0;
}
