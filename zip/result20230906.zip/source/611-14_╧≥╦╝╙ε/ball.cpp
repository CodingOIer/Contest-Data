#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a,b[2][1000000];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	a=n-k;
	b[0][1]=1;
	for(int i=1;i<=a+1;i++){
		for(int j=1;j<=i;j++){
			if(i%2==0)b[0][j]=b[1][j]%1000000007+b[1][j-1]%1000000007;
			else b[1][j]=b[0][j]%1000000007+b[0][j-1]%1000000007;
		}
	}
	cout<<b[(a+1)%2][m]%1000000007;
	return 0;
}
