#include<bits/stdc++.h>
using namespace std;
long long n,a[1000000],b[1000000],c,d,m1,m2;
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i]<a[i-1]){
			c++;
			a[i]=a[i-1];
		}
	}
	for(int i=1;i<=n;i++){
		if(i==1)continue;
		if(b[i]>b[i-1]){
			d++;
			b[i]=b[i-1];
		}
	}
	if(c*m1<d*m2)cout<<c*m1;
	else cout<<d*m2;
	return 0;
}
