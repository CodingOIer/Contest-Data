#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a;
long long dfs(int x,int y){
	cout<<x<<" "<<y<<endl;
	if(x<0||y<0)return 0;
	if(x==0&&y==1)return 1;
	int b,d;
	b=dfs(--x,y);
	x++;
	d=dfs(--x,--y);
	x++;
	y++;
	return b+d;
}
int main(){
	//freopen("ball.in","r",stdin);
	//freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	a=n-k;
	cout<<dfs(a+1,m);
	return 0;
}
