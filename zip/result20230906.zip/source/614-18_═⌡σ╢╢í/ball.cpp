#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define inf 1145141919810
#define debug puts("IAKIOI")
using namespace std;
const int mod=1e9+7;
int a[1000010];
int calc(int n,int m)
{
	if(m==0)
	{
		return 1;
	}
	int k=1;
	for ( int j = n ; k<=m ; j--,k++ )
	{
		int x=j;
		for ( int i = 2 ; i*i <= x ; i++ )
		{
			while(x%i==0){
				a[i]++;
//				cout << i << "++\n";
				x/=i;
			}
		}
		if(x!=1)
		{
			a[x]++;
//			cout << x <<"++\n"; 
		}
	}
	for ( int j = 1 ; j <= m ; j++ )
	{
		int x=j;
		for ( int i = 2 ; i*i <= x ; i++ )
		{
			while(x%i==0)
			{
				a[i]--;
//				cout << i << "--\n";
				x/=i;
//				if(a[i]<0)
//				{
//					cout << "ERR";
//					exit(0);
//				}
			}
		}
		if(x!=1)
		{
			a[x]--;
//			cout << x << "--\n";
//			if(a[x]<0)
//			{
//				cout << "ERR";
//				exit(0);
//			}
		}
	}
	
	int ans=1;
	for ( int i = 2 ; i <= n ; i++ )
	{
		while(a[i]>0)
		{
			ans=ans*i%mod;
			a[i]--;
		}
	}
	return ans;
 } 
 
signed main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	int n,m,k;
	cin >> n >> m >> k;
	m--;
	n-=k;
	if(m>n)
	{
		cout << 0<<endl;
		return 0;
	}
	cout << calc(n,min(m,n-m));
	return 0;
 } //70
 // 1000000 500000 1
