#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define inf 1145141919810
#define debug puts("IAKIOI")
using namespace std;
signed main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int T;
	cin >> T;
	while(T--)
	{
		string s;
		cin >> s;
		string str1="",str2="";
		int flag=1;
		for ( int i = 0 ; i < s.size() ; i++ )
		{
			if(s[i]=='[')
			{
				flag--;
			}
			if(flag==1)
			{
				str1+=s[i];
			}else if(s[i]!='['&&s[i]!=']')
			{
				str2+=s[i];
			}
		}
		if(flag)
		{
			cout << s << endl;
		}else if(flag==0){
			if(str1>str2)
			{
				cout<<str2 << '[' << str1 << "]\n";
			}else{
				cout<<str1 << '[' << str2 << "]\n";
			}
		}else{
			cout << s << endl;
		}
	}
	return 0;
 } //20
