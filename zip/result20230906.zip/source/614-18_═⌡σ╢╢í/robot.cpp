#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define inf 1145141919810
#define debug puts("IAKIOI")
using namespace std;
int a[50010];
int s1[50010],s2[50010];
int n,m1,m2;
int ans1=inf,ans2=inf;
void dfs1(int p,int x,int s)
{
	if(x==n+1)
	{
		ans1=min(ans1,s);
		return;
	}
	if(s>ans1)
	{
		return;
	}
	if(a[x]<p)
	{
		dfs1(p,x+1,s+m1);
		return;
	}
	if(a[x]==p)
	{
		dfs1(p,x+1,s);
		return;
	}
	dfs1(p,x+1,s+m2);
	dfs1(a[x],x+1,s);
}
void dfs2(int p,int x,int s)
{
	if(x==n+1)
	{
		ans2=min(ans2,s);
		return;
	}
	if(s>ans2)
	{
		return;
	}
	if(a[x]>p)
	{
		dfs2(p,x+1,s+m2);
		return;
	}
	if(a[x]==p)
	{
		dfs2(p,x+1,s);
		return;
	}
	dfs2(p,x+1,s+m1);
	dfs2(a[x],x+1,s);
}
signed main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin >> n >> m1 >> m2;
	int flag=1;
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i];
		if(a[i]!=1&&a[i]!=2)
		{
			flag=0;
		}
	}
	if(flag)
	{
		for ( int i = 1 ; i <= n ; i++ )
		{
			s1[i]=s1[i-1];
			s2[i]=s2[i-1];
			if(a[i]==1)
			{
				s1[i]++;
			}else{
				s2[i]++;
			}
		}
		int ans1=inf;
		for ( int i = 0 ; i <= n ; i++ )
		{
			if(ans1>s2[i]+s1[n]-s1[i])
			{
				ans1=s2[i]+s1[n]-s1[i];
			}
		}
		int ans2=inf;
		for ( int i = 0 ; i <= n ; i++ )
		{
			if(ans2>s1[i]+s2[n]-s2[n])
			{
				ans2=s1[i]+s2[n]-s2[i];
			}
		}
		cout << min(ans1,ans2);
		return 0;
	}
	dfs1(0,1,0);
	dfs2(inf,1,0);
	cout << min(ans1,ans2);
	return 0;
 } //55
 /*
 5 1 1
 1 1 2 1 2
 */
