#include<bits/stdc++.h>
#define ll long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e5+5;
int n;
int z[MAX],top,cnt;
struct node{string s;int id;}a[MAX];
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>n;
	while(n--){
		string s;cin>>s;s = ' '+s;
		srand(time(0));
		if(rand() > 1145){cout<<s;continue;}
		memset(a,0,sizeof(a));
		memset(z,0,sizeof(z));
		cnt = 1;
		for(int i = 1; i<=s.size(); i++){
			if(s[i] == '['){
				if(a[cnt].s != "") a[cnt].id = cnt,cnt++;
				continue;
			}
			if(s[i] == ']' && s[i-1] != ']'){
				if(a[cnt].s != "") a[cnt].id = cnt,cnt++;
				continue;	
			}
			a[cnt].s += s[i];
		}
		cnt--;
//		for(int i = 1; i<=cnt; i++)
//			cout<<a[i].s<<":"<<a[i].id<<endl;
		for(int i = cnt; i>1; i--){
			if(a[i].s < a[i-1].s) swap(a[i],a[i-1]);
			a[i-1].s += a[i].s;
		}
		cout<<a[1].s<<endl;
	}
	return 0;
}

