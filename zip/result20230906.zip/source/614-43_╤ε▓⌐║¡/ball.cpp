#include<bits/stdc++.h>
#define int long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e5+5;
const int mod = 1e9+7;
int n,m,k;
int ksm(int x,int p){
	int ans = 1;
	while(p){
		if(p & 1) ans = (ans*x)%mod;
		x = (x*x)%mod;
		p >>= 1;
	}
	return ans%mod;
}
int C(int n,int m){
	// ��m��ȡn��
	int ans = 1;
	for(int i = n+1; i<=m; i++)
		ans = (ans*i)%mod/*,cout<<ans<<endl*/;
	for(int i = 1; i<=m-n; i++)
		ans = (ans*ksm(i,mod-2))%mod/*,cout<<ans<<endl*/;
	return ans%mod;
}//2 5 1
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k,m--;
	cout<<C(m,n-k)<<endl;
	return 0;
}
