#include<bits/stdc++.h>
#define ll long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e5+5;
int n,m1,m2,ans,ans1;
int a[MAX],b[MAX];
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	if(n <= 2) cout<<0,exit(0);
	for(int i = 1; i<=n; i++)
		cin>>a[i],b[i] = a[i];
	int k1 = 0,k2 = 0;
	if(a[1] > a[2]) a[1] = 0,k1 += m2,k2 +=m2;
	if(a[n] < a[n-1]) a[n] = 1e5,k1 += m1,k2 += m1;
	
	for(int i = 2; i<n; i++){
		if(a[i-1] > a[i] && a[i] < a[i+1])
			a[i] = min(a[i-1],a[i]),k1 += m1/*,cout<<"2:"<<i<<endl*/;
	}
	for(int i = 2; i<n; i++){
		if(a[i-1] < a[i] && a[i] > a[i+1])
			a[i] = min(a[i-1],a[i]),k1 += m2/*,cout<<"1:"<<i<<endl*/;
	}
	for(int i = 1; i<=n; i++) a[i] = b[i];//---------
	for(int i = 2; i<n; i++){
		if(a[i-1] < a[i] && a[i] > a[i+1])
			a[i] = min(a[i-1],a[i]),k2 += m2/*,cout<<"1:"<<i<<endl*/;
	}
	for(int i = 2; i<n; i++){
		if(a[i-1] > a[i] && a[i] < a[i+1])
			a[i] = min(a[i-1],a[i]),k2 += m1/*,cout<<"2:"<<i<<endl*/;
	}
	ans = min(k1,k2);
	
	for(int i = 1; i<=n; i++) a[i] = b[i];//---------
	
	k1 = k2 = 0;
	if(a[1] < a[2]) a[1] = 1e5,k1 += m1,k2 += m1;
	if(a[n] < a[n-1]) a[n] = 0,k1 += m2,k2 += m2;

	for(int i = 2; i<n; i++){
		if(a[i-1] > a[i] && a[i] < a[i+1])
			a[i] = min(a[i-1],a[i]),k1 += m1/*,cout<<"2:"<<i<<endl*/;
	}
	for(int i = 2; i<n; i++){
		if(a[i-1] < a[i] && a[i] > a[i+1])
			a[i] = min(a[i-1],a[i]),k1 += m2/*,cout<<"1:"<<i<<endl*/;
	}
	for(int i = 1; i<=n; i++) a[i] = b[i];//---------
	for(int i = 2; i<n; i++){
		if(a[i-1] < a[i] && a[i] > a[i+1])
			a[i] = min(a[i-1],a[i]),k2 += m2/*,cout<<"1:"<<i<<endl*/;
	}
	for(int i = 2; i<n; i++){
		if(a[i-1] > a[i] && a[i] < a[i+1])
			a[i] = min(a[i-1],a[i]),k2 += m1/*,cout<<"2:"<<i<<endl*/;
	}
//	cout<<k1<<":"<<k2<<endl;
	ans1 = min(k1,k2);
//	for(int i = 1; i<=n; i++) cout<<a[i]<<" ";
//	cout<<endl;
//	cout<<ans<<":"<<ans1<<endl;
	cout<<min(ans,ans1)<<endl;
	return 0;
}

