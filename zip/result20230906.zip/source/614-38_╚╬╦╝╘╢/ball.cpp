#include <bits/stdc++.h>
#define rep(i,j,k) for(int i=(j);i<=(k);++i)
#define per(i,j,k) for(int i=(j);i>=(k);--i)
#define db double
using namespace std;

const int N = 1e5 + 10, mod = 1e9 + 7;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef map<int,int> mii;

int n,m,k;
int qmi(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=(ll)res*a%mod;
		a=(ll)a*a%mod,b>>=1;
	}return res;
}
int C(int a,int b){
	if(!b)return 0;
	if(a<b)return 0;
	ll res=1;
	rep(i,b+1,a)res=(ll)res*i%mod,res=(ll)res*qmi(a+1-i,mod-2)%mod;
	return res;
}

int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>k;
	cout<<C(n-k,m-1)<<'\n';
	return 0;
}
