#include <bits/stdc++.h>
#define rep(i,j,k) for(int i=(j);i<=(k);++i)
#define per(i,j,k) for(int i=(j);i>=(k);--i)
#define db double
using namespace std;

const int N = 1e5 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef map<int,int> mii;

int t;
string s;

int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>t;
	while(t--)cin>>s,cout<<s<<'\n';
	return 0;
}
