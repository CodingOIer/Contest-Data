#include <bits/stdc++.h>
#define rep(i,j,k) for(int i=(j);i<=(k);++i)
#define per(i,j,k) for(int i=(j);i>=(k);--i)
#define db double
using namespace std;

const int N = 5e4 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef map<int,int> mii;

int n,dp[N],a[N],m1,m2,flag,cnt[N][3];

int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	rep(i,1,n){
		cin>>a[i];
		if(a[i]!=1&&a[i]!=2)flag=1;
	}
	if(n<=4000){
		int max1=0,max2=0;
		rep(i,1,n){
			dp[i]=1;
			rep(j,1,i-1)if(a[i]>=a[j])dp[i]=max(dp[j]+1,dp[i]);
			max1=max(max1,dp[i]);
		}
		memset(dp,0,sizeof dp);
		rep(i,1,n){
			dp[i]=1;
			rep(j,1,i-1)if(a[i]<=a[j])dp[i]=max(dp[i],dp[j]+1);
			max2=max(max2,dp[i]);
		}
		cout<<n-max(max1,max2)<<'\n';exit(0);
	}
	if(!flag&&m1==m2&&m1==1){
		int cnt1=0,cnt2=0,res=0;
		rep(i,1,n)
			if(a[i]==1)++cnt1;
			else cnt2=max(cnt1,cnt2)+1;
		res=max(cnt1,cnt2),cnt1=0,cnt2=0;
		rep(i,1,n)
			if(a[i]==2)++cnt2;
			else cnt1=max(cnt1,cnt2)+1;
		cout<<n-max(res,max(cnt1,cnt2))<<'\n',exit(0);
	}
	cout<<0<<'\n';
	return 0;
}
