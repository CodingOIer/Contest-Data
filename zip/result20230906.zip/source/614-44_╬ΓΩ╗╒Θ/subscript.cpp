#include<bits/stdc++.h>
using namespace std;//���������ҽ�����ÿ����
long long n,m,p[27],top;
string a;
inline long long read(){
	long long x = 0,f = 1;
	char ch = getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
void write(long long x){
    if(x<0)putchar('-'),x=-x;
    if(x>=10) write(x/10);
    putchar(x%10+'0');
}
int main(){
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	n=read();
	for(long long i=1;i<=n;i++)
	{	
		cin>>a;
		if(a.size()==2)
			cout<<a<<endl;
		else{
			for(long long j=0;j<a.size();j++)
				if(a[j]!='['&&a[j]!=']')
					p[a[j]-'a']++;	
			for(long long j=0;j<a.size();j++)
				if(a[j]!='['&&a[j]!=']')
				{
					while(!p[top]) top++;
					p[top]--;
					cout<<char(top+'a');	
				}
				else cout<<a[j];
			cout<<endl;
		}
	}
	return 0;
}


