#include<bits/stdc++.h>
using namespace std;//���������ҽ�����ÿ����
long long n,m,m1,x,top,w[500005],ans,ans1,ans2,ans3,x1[500005];
map<long long,long long>b;
struct node{
	long long cnt,i,top;
}a[500005],c[500005];
inline long long read(){
	long long x = 0,f = 1;
	char ch = getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
void write(long long x){
    if(x<0)putchar('-'),x=-x;
    if(x>=10) write(x/10);
    putchar(x%10+'0');
}
inline int cmp(node i,node j)
{
	return i.cnt<j.cnt;
}
inline int cmp1(node i,node j)
{
	return i.i<j.i;
}
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	n=read(),m=read(),m1=read();
	for(long long i=1;i<=n;i++)
	{
		x=read();
		b[x]++;
		a[i].cnt=x,a[i].i=i;
	}
	sort(a+1,a+n+1,cmp);
	x=-1;
	for(long long i=1;i<=n;i++)
	{
		if(x!=a[i].cnt) x=a[i].cnt,top++,x1[top]=w[top]=b[a[i].cnt];
		a[i].top=c[i].top=top,c[i].cnt=a[i].cnt,c[i].i=a[i].i;
	}
	sort(a+1,a+n+1,cmp1);
	sort(c+1,c+n+1,cmp1);
	ans1=0;
	for(long long i=1;i<=n;i++)
	{
		ans=0;
		w[a[i].top]--;
		for(long long j=a[i].top-1;j>=1;j--)
			ans+=w[j];
		if(a[i-1].top>a[i].top) ans2+=m,a[i].top=a[i-1].top;
		else if(ans>ans1&&m1*(w[a[i].cnt]+1)<ans*m) ans2+=m1,a[i].top=a[i-1].top;
		else ans1=ans;
	}
	ans1=0,c[0].top=1e5;
	for(long long i=1;i<=n;i++)
	{
		ans=0;
		x1[c[i].top]--;
		for(long long j=c[i].top+1;j<=top;j++)
			ans+=x1[j];
		if(c[i-1].top<c[i].top) ans3+=m1,c[i].top=c[i-1].top;
		else if(ans>ans1&&m*(x1[c[i].top]+1)<ans*m1) ans3+=m,c[i].top=c[i-1].top;
		else ans1=ans;
	}
	cout<<min(ans2,ans3);
	return 0;
}


