#include<bits/stdc++.h>
using namespace std;//���������ҽ�����ÿ���� 
long long n,m,a,mod=1e9+7,b[1000005];
inline long long read(){
	long long x = 0,f = 1;
	char ch = getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
void write(long long x){
    if(x<0)putchar('-'),x=-x;
    if(x>=10) write(x/10);
    putchar(x%10+'0');
}
inline long long ksm(long long i,long long j)
{
	long long ans=i,ans1=1;
	while(j)
	{
		if(j%2==1) ans1=(ans1*ans)%mod;
		ans=(ans*ans)%mod;
		j/=2;
	}
	return ans1;
}
inline long long c(long long i,long long j)
{
	return ((b[i]*ksm(b[i-j],mod-2))%mod*ksm(b[j],mod-2))%mod;
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=read(),m=read(),a=read();
	n=n-a,m--;
	b[0]=1;
	for(long long i=1;i<=n;i++)
		b[i]=(b[i-1]*i)%mod;
	write(c(n,m));
	return 0;
}

