#include <bits/stdc++.h>
using namespace std;
long long n,m,k,o=1e9+7,ans,sum,num;
long long jc(long long n,long long x)
{
	long long ans=1,j=1;
	for(long long i=n;i>=x;i--)
	{
		ans*=i;
		if(ans%j!=0)
		{
			continue;
		}
		else
		{
			ans/=j;	
		}
		if(j<=n-k-m+1)
		{
			j++;
		}
	}
	return ans;
 }
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(m==1)
	{
		cout<<1;
		return 0;
	}
	if(m==2)
	{
		cout<<n-k;
		return 0;
	}
	if(n==1)
	{
		cout<<1;
	}
	num=jc(n-k,m);
	num%=o;
	cout<<num;
	return 0;
	
}
