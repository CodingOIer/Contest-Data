#include <bits/stdc++.h>
using namespace std;
int n,m1,m2,h[50005],h2[50005];
int main()
{
	freopen("robot.in","r",stdin); 
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
	{
		cin>>h[i];
		h2[i]=h[i];
	}
	srand(time(0));
	cout<<rand()%100000+1;
	return 0;
	
}

