#include <bits/stdc++.h>
using namespace std;
int n;
string a[100005]; 
int main()
{
	freopen("subscript.in","r",stdin); 
	freopen("subscript.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	srand(time(0));
	cout<<rand()%100000+1;
	return 0;
	
}
