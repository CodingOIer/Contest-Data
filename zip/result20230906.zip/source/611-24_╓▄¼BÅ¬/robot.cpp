#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	srand(time(0));
	cout<<rand();
	return 0;
}
