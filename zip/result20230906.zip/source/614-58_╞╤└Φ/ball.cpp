#include<bits/stdc++.h>
using namespace std;
const long long mod = 1e9 + 7;
int n,m,k,s1,s2;
long long p,ans,l,l1,l2;
long long ksm(long long x,long long pp)//x��p�η� 
{
	ans = 1; p = x,l = 1;
	while(l <= pp)
	{
		if(pp & l) ans = (ans * p) % mod;
		p = (p * p) % mod;
		l *= 2;
	}
	return ans;
}
long long C(int x,int y)
{
	l1 = l2 = 1;
	for(int i = x,j = 1;j <= y;i--,j++)
	{
		l1 = (l1 * i) % mod;
		l2 = (l2 * j) % mod;
	}
	return (l1 * ksm(l2,mod - 2)) % mod;
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	s1 = n - k; s2 = m - 1;
	if(s1 < s2)
	{
		cout << 0 << endl;
		return 0;
	}
	printf("%lld",C(s1,s2));
	return 0;
}

