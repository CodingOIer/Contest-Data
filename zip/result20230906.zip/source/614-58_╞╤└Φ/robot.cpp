#include<bits/stdc++.h>
using namespace std;
int n,m1,m2,a[50010];
int b[50010],o1,c[50010],o2,q1,q2,o3;
void nn(int x)
{
	int l = 1,r = o1,mid;
	while(l <= r)
	{
		mid = (l + r) / 2;
		if(b[mid] > x) r = mid - 1;
		else l = mid + 1;
	}
	if(r == o1 - 1) b[r + 1] = x;
}
void nnd(int x)
{
	int l = 1,r = o2,mid;
	while(l <= r)
	{
		mid = (l + r) / 2;
		if(c[mid] < x) r = mid - 1;
		else l = mid + 1;
	}
	if(r == o2 - 1) c[r + 1] = x;
}
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	scanf("%d%d%d",&n,&m1,&m2);
	for(int i = 1;i <= n;i++) scanf("%d",&a[i]);
	b[0] = INT_MIN;
	for(int i = 1;i <= n;i++)
	{
		if(a[i] >= b[o1]) b[++o1] = a[i];
		else nn(a[i]);
	}
	o3 = 1;
	for(int i = 1;i <= n;i++)
	{
		if(o3 <= o1 && b[o3] == a[i]) o3++;
		else
		{
			if(a[i] > b[o3]) q1 += m2;
			else q1 += m1;
		}
		printf("%d %d %d\n",q1,o3,a[i]);
	}
	c[0] = INT_MAX;
	for(int i = 1;i <= n;i++)
	{
		if(a[i] <= c[o2]) c[++o2] = a[i];
		else nnd(a[i]);
	}
	o3 = 1;
	for(int i = 1;i <= n;i++)
	{
		if(o3 <= o2 && c[o3] == a[i]) o3++;
		else
		{
			if(a[i] > c[o3]) q2 += m2;
			else q2 += m1;
		}
	}
	printf("%d",min(q1,q2));
	return 0;
}

