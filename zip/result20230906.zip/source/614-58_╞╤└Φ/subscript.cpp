#include<bits/stdc++.h>//��������һ�ɣ�ʹ�����ź����������չ���������������У�����ֱ�ӱȽ�һ�¾Ϳ����� 
using namespace std;
int n,a[100010],o1,l,oo;//վ
int lh;
int o = 1,o4 = 1,lll;//����� 
string s,s1[100010],s2,bj;
bool cmp(int a,int b)
{
	return a + b > b + a;
}
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1;i <= n;i++)
	{
		cin >> s;s += ']';
		o = o4 = 1; oo = 0; lh = 0; lll = 1;
		a[1] = -1;
		s1[o] = "";
		for(int j = 0;j < s.size();j++)
		{
			if(s[j] == '[') a[++o4] = j;
			if(s[j] == ']') 
			{
				o =  1; oo = 0; s2 = ""; bj = "";  lll = 1;
				s1[o] = "";
				l = a[o4] + 1;o4--;
			//	cout << o4 << " " << l<<endl;
				for(int z = l;z < j;z++)
				{
					if((s[z] == '[' && s[z + 1] == ']') || (s[z] == '[' && lll == 1)) 
					{
						o++;
						s1[o] = "";
						s2 += s1[o - 1]; 
						lll++;
					}
					else if(s[z] != ']') s1[o] += s[z];
				//	cout << s1[o] << endl;
				}
				if(o <= 1) continue;
				while(o > 1)
				{
					if(s2 > s1[o])
					{//	cout << o << " " << s1[o] << endl;
						if(o != 2) bj += "[" + s1[o];
						else bj += s1[o] + "[" + s1[o - 1],o = 1;
						oo++;
						o--;
						for(int z = s2.size() - 1;z > s2.size() - s1[o].size();z--) s2[z] = 'Q';
					}
					else break;
				}
				if(o) bj += s1[1];
				for(int z = 2;z <= o;z++) bj += "[" + s1[z] + "]";
				while(oo--) bj += "]";
			//	cout << bj<<endl;
				for(int z = l;z < j;z++) s[z] = bj[z - l];
			}
		}
		for(int j = 0;j < s.size() - 1;j++) cout << s[j];
		cout << endl;
	}
	
	return 0;
}
/*
x[a][b[a]]
����������������ڸ� 
a[x][a[a [e [ a[d] ]]] [abaa]]








0123456
11199991118
11181119999








a[x [z [wew] [xwd] [wew] ] ]

a[x [wew [z [wew] [xwd] ] ] ]

a[x [wew [xwd [z [wew] ] ] ] ]
*/ 













