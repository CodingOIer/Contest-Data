#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		string a;
		cin>>a;
		cout<<a<<endl;
	}
	return 0;
}
