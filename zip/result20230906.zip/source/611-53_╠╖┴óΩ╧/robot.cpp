#include<bits/stdc++.h>
using namespace std;
int a[50010],b[50010];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int n,m1,m2,s1=0,s2=0;
	scanf("%d%d%d",&n,&m1,&m2);
	scanf("%d",&a[1]);
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>a[i-1])
		{
			s1++;
		}
		if(a[i]<a[i-1])
		{
			s2++;
		}
	}
	printf("%d",min(s1,s2));
	return 0;
}
/*
�����ʱ��� 
*/
