#include<bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	long long n,m,k;
	scanf("%lld%lld%lld",&n,&m,&k);
	n=n-k; 
	m--;
	long long s1=1,s2=1,t=m;
	for(long long i=1;i<=t;i++)
	{
		s1=s1*n;
		s2=s2*m;
		n--;
		m--;
	}
	printf("%lld",s1/s2%mod);
	return 0;
}
