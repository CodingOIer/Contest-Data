#include <bits/stdc++.h>
using namespace std;
string b[114514];
int main() {
	/*
	����������Ŀ˵���ǲ�����ġ��������AC�ˣ���
	//	for (int i = 1; i <= 9; i++)
	//		cin >> i[a];
	//	for (int i = 1; i <= 9; i++)
	//		cout << a[i] << ' ';
	*/
	int t;
	scanf("%d", &t);
	while (t--) {
		string a;
		cin >> a;
		int id = 1;
		for (int i = 0; i < a.size(); i++) {
			if (a[i] >= 'a' && a[i] <= 'z') {
				b[id] += a[i];
			} else {
				if (a[i] == '[') {
					++id;
				} else {
					id++;
				}
			}
		}
		--id;
		sort(b + 1, b + 1 + id);
		for (int i = 1; i <= id; i++) {
			cout << b[i];
			if (i <= id / 2) {
				cout << '[';
			} else
				cout << ']';
			b[i] = "";
		}
		puts("");
	}
	return 0;
}
