#include <bits/stdc++.h>
using namespace std;
int n, m, k, ans;
const int N = 1e9 + 7;
void dfs(int step, int onne) {
	if (step == m) {
		ans = (ans + 1) % N;
		return;
	}
	for (int i = onne + 1; i <= n; i++) {
		dfs(step + 1, i);
	}
}
int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	if (m == 1)
		puts("1");
	else if (n == k) {
		if (m == 1)
			puts("1");
		else
			puts("0");
	}
	else if (m == 2)
		cout << n - k;
	else if (n == m) {
		if (k == 1) puts("1");
		else puts("0");
	} else {
		dfs(1, k);
		cout << ans;
	}
	return 0;
}
