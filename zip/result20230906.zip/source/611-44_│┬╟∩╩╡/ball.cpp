#include<bits/stdc++.h> 
using namespace std;
#define ll long long
ll n,m,k,ans=1;
int main()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	if(m==1)
	{
		cout<<1;
		return 0;
	}
	if(m==2)
	{
		cout<<n-k;
		return 0;
	}
	if(n-k>=m)for(ll i=1;i<=m;i++)ans*=i;
	else for(ll i=1;i<=n-k;i++)ans*=i;
	printf("%lld",ans%10000000007);
	return 0;
}


