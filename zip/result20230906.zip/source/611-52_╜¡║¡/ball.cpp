#include<bits/stdc++.h>
using namespace std;
long long a[249330][1000],n,m,k;
int main()
{
	a[1][1]=1;
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	n=n-k+1;
	for(long long i=2;i<=n;i++)
		for(long long j=1;j<=min(i,m);j++)
			a[i][j]=(a[i-1][j-1]+a[i-1][j])%1000000007;
	cout<<a[n][m]%1000000007;
	return 0;
} 
