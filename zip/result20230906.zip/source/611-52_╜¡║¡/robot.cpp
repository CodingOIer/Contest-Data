#include<bits/stdc++.h>
using namespace std;
long long a[50001],z=0,n,h,f,d1=0,d2=0,b=0;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>h>>f;
	for(int i=1;i<=n;i++){
	cin>>a[i];
	z+=a[i];
	}
	for(int i=1;i<=n;i++)
	{
		if(a[i]<a[i-1]){
		a[i]=a[i-1];
		d1+=h;}
	}
	for(int i=2;i<=n;i++)
	{
		if(a[i]>a[i-1]){
		a[i]=a[i-1];
		d2+=f;}
	}
	cout<<min(d1,d2);
	return 0;
}
