#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m,k,a[400001][1001];
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	n=n-k+1;
	a[0][0]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			a[i][j]=(a[i-1][j]+a[i-1][j-1])%mod;
		}
	}
	if(n<=100) cout<<a[n][m];
	else cout<<a[k+1][m];
	return 0;
}
