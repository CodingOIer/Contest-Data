#include<bits/stdc++.h>
using namespace std;
long long n,m1,m2,h[100001],mi=1145141919810,ma;
long long h1,h2;
long long q[100001];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m1>>m2;
	for(int i=1;i<=n;i++)
	{
		cin>>h[i];
		mi=min(mi,h[i]);
		ma=max(ma,h[i]);
		if(h[i]==1)
			h1++;
		else if(h[i]==2)
			h2++;
	}
	if(ma<=2)
		return cout<<min(h1,h2),0;
	long long mii=1145141919810,num;
	num=0;
	for(int j=1;j<=n;j++)
		q[j]=h[j];
	for(int i=2;i<=n;i++)
		if(q[i]<q[i-1])
			q[i]=q[i-1],num+=m1;
	mii=min(mii,num);
	num=0;
	for(int j=1;j<=n;j++)
		q[j]=h[j];
	for(int i=2;i<=n;i++)
		if(q[i]>q[i-1])
			q[i]=q[i-1],num+=m2;
	mii=min(mii,num);
	cout<<mii;
	return 0;
}

