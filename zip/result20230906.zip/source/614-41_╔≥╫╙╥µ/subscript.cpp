#include<bits/stdc++.h>
using namespace std;
string s[5001],s2;
long long n;
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>n;
	int l=1;
	for(int i=1;i<=n;i++)
	{
		cin>>s2;
		for(int k=1;k<=l;k++)
			s[k]="";
		l=1;
		for(int j=0;j<s2.size();j++)
		{
			if(s2[j]!='['&&s2[j]!=']')
				s[l]+=s2[j];
			else if(s2[j]=='[')
			{
				s[l]+="\0";
				l++;
			}
		}
		s[l]+="\0";
		sort(s+1,s+l+1);
		for(int j=1;j<l;j++)
		{
			cout<<s[j];
			cout<<'[';
		}
		cout<<s[l];
		for(int j=1;j<l;j++)
		{
			cout<<']';
		}
		cout<<'\n';
	}
	
	return 0;
}
