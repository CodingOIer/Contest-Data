//40pts 
#include<bits/stdc++.h>
using namespace std;
unsigned long long n,m,k,ans=1;
bool b[1000005];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if((k+m-1)>n)
		return cout<<0,0;
	ans=1;
	m--;
	n-=k;
	bool t=0,t2=0;
	long long l=2;
	for(long long i=m;i>=1;i--)
	{
		ans*=(n-i+1);	
		if((n-i+1)<=m&&b[(n-i+1)]==0)
		{
			b[(n-i+1)]=1;
			ans/=(n-i+1);
		}
		else if(b[l]==0&&l<=m)
		{
			ans/=l;
			b[l]=1;
			l++;
		}
		ans%=1000000007000;
	}
	cout<<ans%1000000007;
	return 0;
}

