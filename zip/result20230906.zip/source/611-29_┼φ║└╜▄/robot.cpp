#include <bits/stdc++.h>
using namespace std;
int n,m,k,a[50000];
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	if(n==1 || n==2)
		cout<<0;
	return 0;
}
