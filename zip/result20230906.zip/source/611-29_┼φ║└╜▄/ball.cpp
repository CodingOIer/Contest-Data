#include <bits/stdc++.h>
using namespace std;
int n,m,k;
long long ans,l=1e9+7;
void s(int i,int nu)
{
	if(i==m-1)
	{
		ans++;
		return ;
	}
	for(int j=nu+1;j<=n;j++)
	{
		s(i+1,j);
	}
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=k+1;i<=n-m+2;i++) 
		s(1,i);
	cout<<ans%l;
	return 0;
}
