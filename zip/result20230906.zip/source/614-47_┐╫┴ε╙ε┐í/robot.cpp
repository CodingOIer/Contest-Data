#include<bits/stdc++.h>
using namespace std;
int n,a,b,h[50001],i;
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	cin>>n>>a>>b;
	for(i=1;i<=n;i++)cin>>h[i];
	if(n==1||n==2)
	{
		cout<<0;
		return 0;
	}
	if(n==4)
	{
		if(h[1]<=h[2]<=h[3]<=h[4]||h[4]<=h[3]<=h[2]<=h[1])
		{
			cout<<0;
			return 0;
		}
		if(h[2]<h[1]<h[4]<h[3]||h[3]<h[4]<h[1]<h[2]||h[2]<h[4]<h[1]<h[3]||h[3]<h[1]<h[4]<h[2])
		{
			cout<<2;
			return 0;
		}
		else cout<<1;
	} 
	cout<<1;
	return 0;
}

