#include<bits/stdc++.h>
using namespace std;
long long n,m,k,i,s;
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m>>k;
	if(m==1||(n-m)==(k-1))
	{
		cout<<1;
		return 0;
	}
	if(m==2)
	{
		cout<<n-k;
		return 0;
	}
	if((n-m)==k)
	{
		cout<<n;
		return 0;
	}
	if((n-m)==(k+1))
	{
		cout<<(1+m)*m/2;
		return 0; 
	}
	return 0;
}
