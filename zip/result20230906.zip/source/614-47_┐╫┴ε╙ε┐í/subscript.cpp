#include<bits/stdc++.h>
using namespace std;
int t,i;
char s[100001];
int main()
{
	freopen("subscript.in","r",stdin);
	freopen("subscript.out","w",stdout);
	cin>>t;
	for(i=1;i<=t;i++)
	{
		cin>>s;
		sort(s,s+(strlen(s)-1));
		cout<<s<<endl;
	}
	return 0;
}

