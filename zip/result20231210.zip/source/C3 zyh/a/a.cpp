#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
const int N=1e5+5;
int n,K;
struct XXX{
	int x,id;
}a[N],b[N];
bool cmp(XXX x,XXX y){
	if(x.x==y.x) return x.id<y.id;
	return x.x%998244353<y.x%998244353;
}
int A[N],B[N];
int ga[N],gb[N];
signed main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read(),K=read();
	for(int i=1;i<=n;i++) a[i]={A[i]=read(),i};
	for(int i=1;i<=n;i++) b[i]={B[i]=read(),i};
//	cout<<B[335];
	sort(a+1,a+n+1,cmp);
	sort(b+1,b+n+1,cmp);
	for(int i=1;i<=n;i++){
		ga[i]=a[i].x%998244353;
		gb[i]=b[i].x%998244353;
	}
//	cout<<gb[2]<<" ";
	int len=min(n,500ll);
//	if(b[n].x>998244353) len=min(len,500ll);
//	cout<<b[1].id<<" ";
	int p=upper_bound(ga+1,ga+n+1,gb[1]+K)-ga-1;
	int ans=1e16,ms=0;
	for(int i=0;i<=n;i++){
		bool flag=0;
		int x=i;
//		cout<<x<<" ";
		int maxx=-1e16;
		for(int j=1;j<=len;j++){
			int k=(b[j].id+x-1)%n+1;
			int t=b[j].id;
//			cout<<A[k]-B[t]<<" "<<k<<" ";
			maxx=max(A[k]-B[t],maxx);
			if((A[k]-B[t])>K){
				flag=1;
				break;
			}
		}
		if(flag) continue;
		if(len<=500){
			for(int j=n-len+1;j<=n;j++){
				int k=(b[j].id+x-1)%n+1;
				int t=b[j].id;
			maxx=max(A[k]-B[t],maxx);
				if((A[k]-B[t])>K){
					flag=1;
					break;
				}
			}
			if(flag) continue;
			for(int j=1;j<=len;j++){
				int k=(a[j].id-x+n-1)%n+1;
				int t=a[j].id;
			maxx=max(A[t]-B[k],maxx);
				if((A[t]-B[k])>K){
					flag=1;
					break;
				}
			}
			
		}
		if(flag) continue;
		for(int j=n-len+1;j<=n;j++){
			int k=(a[j].id-x+n-1)%n+1;
			int t=a[j].id;
			maxx=max(A[t]-B[k],maxx);
			if((A[t]-B[k])>K){
				flag=1;
				break;
			}
		}
		if(ans>maxx){
			ans=maxx;
			ms=x;
		}
		else{
			ms=min(ms,x);
		}
	}
	if(ms) cout<<ms<<endl;
	else 
	cout<<-1<<endl;
    return 0;
}
