#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int Mod=998244353;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
const int N=1e6+5;
int n,m,s,p;
int u[N],v[N];
vector<int>q[N];
vector<pair<int,int> >e[N];
//int cnt=0,dfn[N],low[N],fa[N];
//int color;
//vector<int>col[N];
//int sta[N],tp;
//int vis[N],gg[N];
//void dfs(int x,int f){
//	low[x]=dfn[x]=++cnt;
//	fa[x]=f;
//	sta[++tp]=x;
//	for(auto y:q[x]){
//		if(y==f) continue;
//		if(!dfn[y])dfs(y,x),low[x]=min(low[x],low[y]);
//		low[x]=min(low[x],dfn[y]);
//	}
//	if(low[x]>=dfn[x]){
//		color++;
//		gg[color]=x;
//		col[color].push_back(sta[tp]);
//		vis[sta[tp]]=color;
//		tp--;
//		while(low[sta[tp]]>=x){
//			col[color].push_back(sta[tp]);
//			vis[sta[tp]]=color;
//			tp--;
//		}
//		
//	}
//}
int dis[N];
void dij(){
	memset(dis,0x3f,sizeof(dis));
	dis[s]=0;
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >qu;
	qu.push({0,s});
	while(!qu.empty()){
		int u=qu.top().second;
		qu.pop();
		for(auto v:q[u]){
			if(dis[u]+1<dis[v]){
				dis[v]=dis[u]+1;
				qu.push({-dis[v],v});
			}
		}
	}
}
struct XXX{
	int val,id;
}z[N];
bool flag=0;
void dfs2(int x,int f,int ed,int sp,bool gg){
	if(flag) return;
	if(gg) return;
	if(x==ed){
		if(!gg) flag=1;
		return;
	} 
	for(auto y:q[x]){
		if(y==f) continue;
		if(x==u[sp]&&y==v[sp])
			continue;
		else dfs2(y,x,ed,sp,gg); 
	}
}
inline int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1) res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
bool cmp(XXX x,XXX y){
	return x.val>y.val;
}
int dp[N];
void dfs2(int x,int f)
{
	for(auto E:e[x]){
		int y=E.first,val=p-dis[y];
		if(y==f) continue;
		dp[y]=max(dp[x],dp[y]);
		dp[y]=max(dp[y],val);
		dfs2(y,x);
	}
}
signed main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	n=read(),m=read(),s=read(),p=read();
	for(int i=1;i<=m;i++){
		u[i]=read(),v[i]=read();
		q[u[i]].push_back(v[i]);
		e[u[i]].push_back({v[i],i});
	}
//	for(int i=1;i<=n;i++)
//	if(dfn[i]==0)dfs(i,0);
	dij();
//	for(int i=1;i<=n;i++) cout<<vis[i]<<" "<<dis[i]<<" "<<dfn[i]<<" "<<low[i]<<endl;
	for(int i=1;i<=m;i++){
		z[i].val=p-dis[v[i]];
		z[i].id=i;
	//	cout<<val[i];
	}
	int ans=0;
	sort(z+1,z+m+1,cmp);
	if(m==n-1){
		dfs2(s,0);
		for(int i=1;i<=n;i++){
			ans+=dp[i];
		}
	}
	else{
		for(int i=1;i<=n;i++){
			for(int t=1;t<=m;t++){
				int j=z[t].id;
				dfs2(s,0,i,j,0); 
				if(!flag){
					ans+=z[t].val; 
					ans%=Mod;
					break;
				}
				flag=0;
			}
	//		cout<<maxx<<endl; 
		}
		
	}
	cout<<ans*ksm(n,Mod-2)%Mod;
    return 0;
}

