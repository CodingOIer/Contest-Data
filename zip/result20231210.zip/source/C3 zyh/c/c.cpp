#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
const int Mod=1e9+7;
inline int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=res*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return res;
}
const int N=1e6+5;
int fac[N],inv[N];
inline int C(int n,int m){
	if(m>n) return 0;
	return fac[n]*inv[m]%Mod*inv[n-m]%Mod;
}
signed main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int n=read(),m=read(),x=read(),y=read();
	fac[0]=1;
	inv[0]=1;
	for(int i=1;i<=N-5;i++){
		fac[i]=fac[i-1]*i%Mod;
	}
	inv[N-5]=ksm(fac[N-5],Mod-2);
	for(int i=N-6;i>=1;i--){
		inv[i]=inv[i+1]*(i+1)%Mod;
	}
	int ans=0;
	for(int i=0;i<=2*x*y;i++){
		ans+=C(n*m,i);
		ans%=Mod;
	}
	cout<<ans<<endl;
    return 0;
}

