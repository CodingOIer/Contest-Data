#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 50, mod = 1e9 + 7;
int N, M, X, Y;
map<int, int> mp;
int ans = 0;
int vis[Maxn][Maxn];
void dfs1(int a, int b, int x, int y){
    if(x > X || y > Y){
        int s = 0;
        for(int i = 1 ; i <= N ; i++){
            for(int j = 1 ; j <= M ; j++){
                // cout << vis[i][j] << " ";
                s = s * 2 + vis[i][j];
            }
            // cout << endl;
        }
        // cout <<s<< endl;
        if(!mp[s]) ans++;
        if(ans >= mod) ans -= mod;
        mp[s] = 1;
        return ;
    }
    int tox, toy = y;
    tox = x + 1;
    if(tox > X) tox = 1, toy += 1;
    vis[x + a - 1][y + b - 1] = 1;
    dfs1(a, b, tox, toy);
    vis[x + a - 1][y + b - 1] = 0;
    dfs1(a, b, tox, toy);
}
void dfs(int a, int b, int x, int y, int c, int d){
    if(x > X || y > Y){
        dfs1(c, d, 1, 1);
        return ;
    }
    int tox, toy = y;
    tox = x + 1;
    if(tox > X) tox = 1, toy += 1;
    vis[x + a - 1][y + b - 1] = 1;
    dfs(a, b, tox, toy, c, d);
    vis[x + a - 1][y + b - 1] = 0;
    dfs(a, b, tox, toy, c, d);
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("c.in", "r", stdin);
    freopen("c.out", "w", stdout);
    cin >> N >> M >> X >> Y;
    for(int a = 1 ; a <= N ; a++){
        for(int b = 1 ; b <= M ; b++){
            for(int c = a ; c <= N ; c++){
                for(int d = 1 ; d <= M ; d++){
                    dfs(a, b, 1, 1, c, d);
                }
            }
        }
    }
    cout << ans << '\n';
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}