#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1000010, mod = 998244353;
struct node{
    int x, y, w;
}b[Maxn];
int n, m, s, p;
struct tree{
    int to, id;
};
vector<tree> Tree[Maxn];
queue<int> q;
int len[Maxn];
void bfs1(){
    q.push(s);
    while(!q.empty()){
        int x = q.front();
        q.pop();
        for(auto to : Tree[x]){
            if(len[to.to]) continue;
            len[to.to] = len[x] + 1;
            q.push(to.to);
        }
    }
}
int ksm(int x, int y){
    int s = 1;
    while(y){
        if(y & 1) s = s * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return s;
}
int s1, s2[Maxn], vis[Maxn], sum;
int top[Maxn], tp;
void dfs(int x, int t){
    if(x == t){
        s1++;
        for(int i = 1 ; i <= m ; i++) s2[i] += vis[i];
        return ;
    }
    for(auto to : Tree[x]){
        vis[to.id] = 1;
        dfs(to.to, t);
        vis[to.id] = 0;
    }
}
int ops;
signed main(){
    ios::sync_with_stdio(false);
    freopen("b.in", "r", stdin);
    freopen("b.out", "w", stdout);
    cin >> n >> m >> s >> p;
    for(int i = 1 ; i <= m ; i++){
        cin >> b[i].x >> b[i].y;
        Tree[b[i].x].push_back({b[i].y, i});
        if(b[i].y < b[i].x) ops = 1;
    }
    if(!ops && m == n - 1 && s == 1){
        cout << (p - 1) * (n - 1) % mod * ksm(n, mod - 2) % mod << '\n';
        return 0;
    }
    bfs1();
    for(int i = 1 ; i <= n ; i++){
        for(auto to : Tree[i])
            b[to.id].w = p - len[to.to];
    }
    for(int t = 1 ; t <= n ; t++){
        int Max = 0;
        s1 = 0;
        for(int i = 1 ; i <= m ; i++) s2[i] = 0;
        dfs(s, t);
        for(int i = 1 ; i <= m ; i++) 
            if(s2[i] == s1) Max = max(Max, b[i].w);
        // for(int i = 1 ; i <= m ; i++) cout << s2[i] << " ";
        // cout << endl;
        sum += Max;
        // cout << sum << endl;
    }
    cout << sum * ksm(n, mod - 2) % mod << '\n';
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}
/*
8 8 1 10
1 2
1 3
1 4
2 5
3 5
5 6
6 7
6 8
*/