#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 100010;
int n, k;
int a[Maxn], b[Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    cin >> n >> k;
    for(int i = 0 ; i < n ; i++) cin >> a[i];
    for(int i = 0 ; i < n ; i++) cin >> b[i];
    for(int x = 0 ; x < n ; x++){
        int s = a[0] - b[x], ops = 0;
        for(int i = 0 ; i < n ; i++){
            if(a[i] - b[(i + x) % n] != s){
                ops = 1;
                break;
            }
        }
        if(!ops){
            cout << x << '\n';
            return 0;
        }
    }
    cout << -1 << '\n';
    return 0;
}