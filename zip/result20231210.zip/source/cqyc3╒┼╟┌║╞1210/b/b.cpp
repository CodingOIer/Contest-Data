#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=1e3+7,inf=1e12,Mod=998244353;
ll n,m,s,p,deg[Maxn],ind[Maxn],dis[Maxn],f[Maxn];
bool nmsl[Maxn][Maxn];
ll ans,ff[Maxn],gg[Maxn],gind[Maxn],gdeg[Maxn];
vector<pair<ll,ll> >e[Maxn],E,ww[Maxn];
ll nums[Maxn],nus[Maxn]; 

inline ll ksm(ll a,ll b,ll mod){
	ll z=1;
	while(b){
		if(b&1) z=z*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return z;
}
inline void topo1(){
	queue<ll>q;
	for(ll i=1;i<=n;i++) if(!ind[i]) q.push(i);
	for(ll i=1;i<=n;i++) dis[i]=inf;f[s]=1;dis[s]=0;
	while(!q.empty()){
		ll u=q.front();q.pop();
		for(auto i:e[u]){
			ll v=i.first;
			f[v]+=f[u];
			dis[v]=min(dis[v],dis[u]+1);
			ind[v]--;
			if(!ind[v]) q.push(v);
		}
	}
}
inline void ttp(ll s1){
	queue<ll>q;
	q.push(s1);
	nmsl[s1][s1]=1;
	while(!q.empty()){
		ll u=q.front();q.pop();
		for(auto i:ww[u]){
			ll v=i.first;
			nmsl[s1][v]=1;
			q.push(v);
		}
	}
	
}

int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lld%lld%lld%lld",&n,&m,&s,&p);
	for(ll i=1,u,v;i<=m;i++){
		scanf("%lld%lld",&u,&v);
		e[u].emplace_back(v,i);
		deg[v]++;ind[v]++;
		E.emplace_back(u,v);
		ww[v].emplace_back(u,i);
		gdeg[u]++;gind[u]++;
	}
	topo1();
	ll cc=0;
	for(ll i=1;i<=n;i++) ttp(i);
	for(auto i:E){
		ll u=i.first,v=i.second;
		gg[++cc]=dis[v];
	}
	
	
	for(ll i=1;i<=n;i++){
		if(s==i) continue;
		for(ll j=1;j<=m;j++) nums[j]=0,gind[j]=gdeg[j],ff[j]=0;
		queue<ll>q;
		for(ll j=1;j<=n;j++) if(!gind[j]) q.push(j);
		ff[i]=1;
		while(!q.empty()){
			ll u=q.front();q.pop();
			for(auto i:ww[u]){
				ll v=i.first,id=i.second;
				gind[v]--;
				ff[v]+=ff[u];
				nums[id]+=ff[u];
				if(!gind[v]) q.push(v);
			}
		}
		
		
		for(ll j=1;j<=m;j++) nus[j]=0,ind[j]=deg[j],ff[j]=0;
		for(ll j=1;j<=n;j++) if(!ind[j]) q.push(j);
		ff[s]=1;
		while(!q.empty()){
			ll u=q.front();q.pop();
			for(auto i:e[u]){
				ll v=i.first,id=i.second;
				ind[v]--;
				ff[v]+=ff[u];
				nus[id]+=ff[u];
				if(!ind[v]) q.push(v);
			}
		}
		
		
		
		ll res=0;
//		for(ll j=1;j<=m;j++) cout<<i<<" "<<j<<' '<<nums[j]<<endl;
		for(ll j=1;j<=m;j++) if(nums[j]==f[i]&&nmsl[E[j-1].second][s])
		 res=max(res,p-gg[j]);
		 else if(nus[j]==f[i]&&nmsl[i][E[j-1].second])
		 	res=max(res,p-gg[j]);
//		 cout<<i<<" "<<res<<endl;
		ans=(ans+res)%Mod;
	}

	ans=ans*ksm(n,Mod-2,Mod)%Mod;
	
	printf("%lld",ans);
	
	return 0;
}

/*
8 8 1 10
1 2
1 3
1 4
2 5
3 5
5 6
6 7
6 8

3 2 1 3
1 2
1 3
*/

