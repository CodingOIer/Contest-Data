#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e5+7;
const int inf=1e9;
int a[Maxn],b[Maxn];
int c[Maxn],d[Maxn];
int kmp1[Maxn],kmp2[Maxn];
int cnt1,cnt2;

int n,k;
inline int Getmin(int z[]){
	int i=1,j=2,k=0;
	while(i<=n&&j<=n&&k<=n){
		if(z[(i+k-1)%n+1]==z[(j+k-1)%n+1]) ++k;
		else{
			if(z[(i+k-1)%n+1]>z[(j+k-1)%n+1]) i=max(j,i+k+1);
			if(z[(i+k-1)%n+1]<z[(j+k-1)%n+1]) j=max(i,j+k+1);
			if(i==j) ++j;
			k=0; 
		}
	}
	return (min(i,j)-1)%n+1;
}

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	
	int i1=Getmin(a),i2=Getmin(b);
	
	for(int i=1;i<=n;i++) a[i+n]=a[i],b[i+n]=b[i],
						  c[i]=a[(i+i1-2)%n+1],d[i]=b[(i+i2-2)%n+1];

	int cha=c[1]-d[1];
	bool flg=0;
	for(int i=1;i<=n;i++)
		if(c[i]-d[i]!=cha){
			flg=1;
		}
	if(k>=n-1){
		cout<<(i1-i2+n)%n;
		return 0;
	} 
	if(flg){
		printf("-1");
		return 0;
	}
	else{
		cout<<(i1-i2+n)%n;
	}
	
	return 0;
}
/*
4 2
1 10 100 1000
0 0 0 0

6 0
1 2 1 2 1 2
4 3 4 3 4 3
*/


