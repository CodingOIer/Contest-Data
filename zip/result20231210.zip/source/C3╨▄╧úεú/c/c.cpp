#include <bits/stdc++.h>

#define rep(i, a, b) for(auto i = (a); i <= (b); i++)
#define _rep(i, a, b) for(auto i = (a); i >= (b); i--)

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;

template <typename _Tp>
void read(_Tp& first) {
	_Tp x = 0, f = 1; char c = getchar();
	while (!isdigit(c)) {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	first = x * f;
}

template <typename _Tp>
void print(_Tp x) {
	if (x < 0) x = (~x + 1), putchar('-');
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

#define int ll

int n, m, x, y, ans;
bool mat[40][40];
int vis[1 << 21];

signed main() {
#ifndef LOCAL
#ifndef ONLINE_JUDGE
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
#endif
#endif
	read(n), read(m), read(x), read(y);
	int sm = n * m;
	rep (i, 1, n - x + 1) {
		rep (j, 1, m - y + 1) {
			rep (k, 1, n - x + 1) {
				rep (l, 1, m - y + 1) {
					int ex1 = i + x - 1;
					int ey1 = j + y - 1;
					int sx1 = i, sy1 = j;
					int ex2 = k + x - 1;
					int ey2 = l + y - 1;
					int sx2 = k, sy2 = l;
					rep (i, 0, (1 << sm) - 1) {
						int s = i;
						rep (j, 0, sm - 1) {
							if (i & (1 << j)) mat[j / m + 1][j % m + 1] = 1;
							else mat[j / m + 1][j % m + 1] = 0;
						}
						bool flg = 0;
						rep (i, 1, n) {
							rep (j, 1, m) {
								if (mat[i][j]) if (!(
										(sx1 <= i && i <= ex1 && sy1 <= j && j <= ey1)
									||  (sx2 <= i && i <= ex2 && sy2 <= j && j <= ey2)
								)) {
									flg = 1;
								}
							}
						}
						if (!flg) {
							if (!vis[s]) {
								ans++;
							}
							vis[s] = 1;
						}
					}
				}
			}
		}
	}
	print(ans);
	return 0;
}
