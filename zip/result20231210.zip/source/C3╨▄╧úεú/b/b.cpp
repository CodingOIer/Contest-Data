#include <bits/stdc++.h>

#define rep(i, a, b) for(auto i = (a); i <= (b); i++)
#define _rep(i, a, b) for(auto i = (a); i >= (b); i--)

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;

template <typename _Tp>
void read(_Tp& first) {
	_Tp x = 0, f = 1; char c = getchar();
	while (!isdigit(c)) {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	first = x * f;
}

template <typename _Tp>
void print(_Tp x) {
	if (x < 0) x = (~x + 1), putchar('-');
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

#define int ll

const int MAXN = 1e6 + 5;
int n, m, s, p;

vector <pair <int, int> > G[MAXN];
queue <int> q;
int dis[MAXN], tp[MAXN], cnt;

void bfs(int s) {
	q.push(s);
	while (q.size()) {
		int u = q.front(); q.pop();
		for (auto [v, id] : G[u]) {
			if (dis[v]) continue;
			dis[v] = dis[u] + 1;
			q.push(v);
		}
	}
}

int ans[MAXN];

bitset <1005> tot, ch;

void dfs(int u, int t) {
	if (u == t) {
		tot &= ch;
		return;
	}
	for (auto [v, id] : G[u]) {
		ch[id] = 1;
		dfs(v, t);
		ch[id] = 0;
	}
}

int sum = 0;
int to[MAXN];

int qpow(int a, int b, int p) {
	int res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		a = a * a % p;
		b >>= 1;
	}
	return res;
}

signed main() {
#ifndef LOCAL
#ifndef ONLINE_JUDGE
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);
#endif
#endif
	read(n), read(m), read(s), read(p);
	rep (i, 1, m) {
		int u, v;
		read(u), read(v);
		G[u].emplace_back(make_pair(v, i));
		to[i] = v;
	}
	bfs(s);
	if (n <= 1000) {
		rep (i, 1, n) {
			tot.set(); ch.reset();
			dfs(s, i);
			int tans = 0;
			rep (i, 1, n) {
				if (tot[i]) tans = max(tans, p - dis[to[i]]);
			}
			sum += tans;
		}
		print(sum * qpow(n, 998244351, 998244353) % 998244353);
	}
	else {
		sum = (p - 1) * (n - 1);
		print(sum * qpow(n, 998244351, 998244353) % 998244353);
	}
	return 0;
}
