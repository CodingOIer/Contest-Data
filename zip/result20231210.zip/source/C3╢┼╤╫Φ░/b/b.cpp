#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,s,p;
const int mod=998244353;
vector<int> q[2000005];
map<pair<int,int>,int> ma;
int dis[2000005],vis[2000005],du[2000005],f[2000005],ans=0,fl[2000005];
int ksm(int x,int y) {
    int ans=1;
    while(y) {
        if(y&1) ans=(ans*x)%mod;
        x=(x*x)%mod;
        y>>=1;
    }
    return ans;
}
void topu() {
    memset(vis,0,sizeof vis);
    memset(dis,0x3f,sizeof dis);
    for(int i=1;i<=n;i++) vis[i]=(du[i]>1);
    queue<int> Q;
    Q.push(s);
    dis[s]=0;
    while(!Q.empty()) {
        int x=Q.front();
        Q.pop();
        for(auto i:q[x]) {
            du[i]--;
            dis[i]=min(dis[i],dis[x]+1);
            fl[i]|=fl[x];
            if(!vis[i]) {
                f[i]=max(f[x],p-dis[i]);
                if(f[i]<0 || fl[i]) continue;
                if(!vis[i]) ans=(ans+f[i])%mod;
            }
            if(du[i]==0) Q.push(i);
        }
    }
}
signed main() {
    freopen("b.in","r",stdin);
    freopen("b.out","w",stdout);
    scanf("%lld %lld %lld %lld",&n,&m,&s,&p);
    for(int i=1;i<=m;i++) {
        int x,y;
        scanf("%lld %lld",&x,&y);
        if(!ma[{x,y}]) {
            q[x].push_back(y);
            du[y]++;
        }
        ma[{x,y}]++;
    }   
    topu();
    printf("%lld",ans*ksm(n,mod-2)%mod);
    return 0;
}