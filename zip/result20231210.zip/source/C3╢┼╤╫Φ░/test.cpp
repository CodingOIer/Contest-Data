#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,s,p;
vector<int> e[2000005],q[2000005];
int dis[2005],vis[2005],du[2005],f[1000005],X[1000005],Y[1000005],deg[1000005],fl[2005];
const int mod=998244353;
map<pair<int,int>,int> ma;
int ksm(int x,int y) {
    int ans=1;
    while(y) {
        if(y&1) ans=(ans*x)%mod;
        x=(x*x)%mod;
        y>>=1;
    }
    return ans;
}
int topu(int a,int k) {
    memset(vis,0,sizeof vis);
    memset(fl,0,sizeof fl);
    memset(dis,0x3f,sizeof dis);
    for(int i=1;i<=n;i++) vis[i]=(du[i]>1);
    queue<int> Q;
    Q.push(s);
    dis[s]=0;
    int flag=0,ans=0;
    while(!Q.empty()) {
        int x=Q.front();
        Q.pop();
        if(x==a && flag==0) return 0;
        for(auto i:q[x]) {
            du[i]--;
            dis[i]=min(dis[i],dis[x]+1);
            if(x==X[k] && i==Y[k]) {ans=p-dis[i];flag=1;}
            if(flag && vis[i]) fl[i]=1;
            fl[i]|=fl[x];
            if(du[i]==0) Q.push(i);
        }
    }
    if(fl[a]) return 0;
    return ans;
}
signed main() {
    freopen("b3.in","r",stdin);
    freopen("b.out","w",stdout);
    scanf("%lld %lld %lld %lld",&n,&m,&s,&p);
    for(int i=1;i<=m;i++) {
        scanf("%lld %lld",&X[i],&Y[i]);
        q[X[i]].push_back(Y[i]);
        du[Y[i]]++;
        deg[Y[i]]++;
    }
    int sum=0;
    for(int i=1;i<=n;i++) {
        if(deg[i]>1) continue;
        int ans=0;
        for(int j=1;j<=m;j++) {
            for(int k=1;k<=n;k++) du[k]=deg[k];
            ans=max(ans,topu(i,j));
        }
        sum+=ans;
        sum%=mod;
    }
    printf("%lld",sum*ksm(n,mod-2)%mod);
    return 0;
}