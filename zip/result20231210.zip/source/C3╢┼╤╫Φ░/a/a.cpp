#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353,wei=37;
int a[10000005],b[1000005];
int kmp[1000005];
signed main() {
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    int n,k,sum1=0,sum2=0;
    scanf("%lld %lld",&n,&k);
    for(int i=1;i<=n;i++) scanf("%lld",&a[i]),sum1+=a[i];
    for(int i=1;i<=n;i++) scanf("%lld",&b[i]),sum2+=b[i],b[n+i]=b[i];
    if((sum1-sum2)%n!=0) {
        printf("-1");
        return 0;
    }
    sum1=-((sum1-sum2)/n);
    for(int i=1;i<=n;i++) a[i]+=sum1;

    int j=0;
	for(int i=2;i<=n;i++) {
		while(j && a[i]!=a[j+1]) j=kmp[j];
		if(a[i]==a[j+1]) j++;
		kmp[i]=j;
	}
	j=0;
    int minn=1e9;
	for(int i=1;i<=2*n;i++) {
		while(j && b[i]!=a[j+1]) j=kmp[j];
		if(b[i]==a[j+1]) j++;
		if(j==n) {    
            minn=min(i-n,minn);
			j=kmp[j];
		} 
	}
    if(minn==1e9) printf("-1"); 
    else printf("%lld",minn);
    return 0;
}