#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7,MAXN=1e6;
int fac[MAXN+5];
int ksm(int x,int y) {
    int ans=1;
    while(y) {
        if(y&1) ans=(ans*x)%mod;
        x=(x*x)%mod;
        y>>=1;
    }
    return ans;
}
void init() {
    fac[0]=1;
    for(int i=1;i<=MAXN;i++) fac[i]=fac[i-1]*i%mod;
}
int C(int x,int y) {
    return fac[x]*ksm(fac[y],mod-2)%mod*ksm(fac[x-y],mod-2)%mod;
}
signed main() {
    freopen("c.in","r",stdin);
    freopen("c.out","w",stdout);
    init();
    int n,m,x,y,ans=0;
    scanf("%lld %lld %lld %lld",&n,&m,&x,&y);
    printf("1");
    return 0;
}