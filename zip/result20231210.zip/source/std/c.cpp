#include<bits/stdc++.h>
using namespace std;
const int mod=1000000007;
int n,m,X,Y,ans;
int f[65][65],id[43][43],js[64],bin[1605];
int qm(int x) {return x>=mod?x-mod:x;}
int work(int n,int m) {
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j) id[i][j]=0;
	for(int i=0;i<64;++i) js[i]=0;
	for(int i=1;i<=n;++i) id[i][1]|=1,id[i][m]|=2;
	for(int i=1;i<=m;++i) id[1][i]|=4,id[n][i]|=8;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j) {
			if(!((i<=X&&j<=Y)||(i>=n-X+1&&j>=m-Y+1))) id[i][j]|=16;
			if(!((i<=X&&j>=m-Y+1)||(i>=n-X+1&&j<=Y))) id[i][j]|=32;
			++js[id[i][j]];
		}
	f[64][15]=f[64][31]=f[64][47]=1;
	for(int i=63;i>=0;--i) {
		for(int hav=0;hav<64;++hav) {
			f[i][hav]=1LL*qm(bin[js[i]]-1+mod)*f[i+1][hav|i]%mod;
			f[i][hav]=qm(f[i][hav]+f[i+1][hav]);
		}
	}
	return f[0][0];
}
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cin>>n>>m>>X>>Y,ans=1;
	bin[0]=1;
	for(int i=1;i<=n*m;++i) bin[i]=qm(bin[i-1]+bin[i-1]);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			ans=qm(ans+1LL*work(i,j)*(n-i+1)%mod*(m-j+1)%mod);
		}
	}
	cout<<ans<<endl;
	return 0;
}
