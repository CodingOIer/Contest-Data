#include <bits/stdc++.h>
using namespace std;

struct Edge {
	int to, id;
};

int n, m, s, p, x[1000001], y[1000001];
vector<Edge> edges[1000001];
const long long P = 998244353;

long long qpow(long long a, long long b) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % P;
		a = a * a % P;
		b >>= 1;
	}
	return res;
}

long long inv(long long a) {
	return qpow(a, P - 2);
}

int q[1000001], front, rear, d[1000001];
int dist[1000001];
bool tmp[1001];

int main() {
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);
	scanf("%d%d%d%d", &n, &m, &s, &p);
	bool subtask1 = (n <= 5 && m <= 5), subtask2 = (m == n - 1 && s == 1), subtask3 = (n <= 1000 && m <= 1000);
	for (int i = 1; i <= m ;++i) {
		scanf("%d%d", &x[i], &y[i]);
		subtask2 &= (x[i] < y[i]);
		edges[x[i]].push_back({y[i], i});
	}
	q[front = rear = 1] = s;
	dist[s] = 1;
	while (rear + 1 != front) {
		int fx = q[front++];
		for (auto i : edges[fx]) {
			if (!dist[i.to]) {
				dist[i.to] = dist[fx] + 1;
				q[++rear] = i.to;
			}
		}
	}
	if (subtask3) { // Subtask1 and Subtask3
		long long sum = 0;
		for (int t = 1; t <= n; ++t) {
			if (s == t) continue;
			long long res = 0;
			for (int i = 1; i <= m; ++i) {
				memset(tmp, 0, sizeof(tmp));
				tmp[s] = 1;
				q[front = rear = 1] = s;
				bool ok = 1;
				while (rear + 1 != front) {
					int fx = q[front++];
					if (tmp[t]) {
						ok = 0;
						break;
					}
					for (auto j : edges[fx]) {
						if (!tmp[j.to] && j.id != i) {
							tmp[j.to] = 1;
							q[++rear] = j.to;
						}
					}
				}
				if (ok) res = max(res, 1ll * p - dist[y[i]] + 1);
			}
			(sum += res) %= P;
		}
		printf("%lld\n", sum % P * inv(n) % P);
	} else if (subtask2) { // subtask2
		printf("%lld\n", 1ll * (n - 1) * (p - 1) % P * inv(n) % P);
	} else { // subtask4
		
	}
}
/*
[40, 61]
*/
