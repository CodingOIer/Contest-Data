#include <bits/stdc++.h>
using namespace std;

long long n, k, a[100004], ba[100004], tmp[100004], tot = 0;
const int p = 998244353;

long long qpow(long long a, long long b) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		a = a * a % p;
		b >>= 1;
	}
	return res;
}

long long inv(long long a) {
	return qpow(a, p - 2);
}

const unsigned long long Base[7] = {10000007627ll, 10000007569ll, 10000007557ll, 10000007513ll};
// �Ĺ�ϣ�ܲ����ܿ��ɣ� 
unsigned long long hasht[7], basep[7][100005], hashb[7];

int main() {
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	scanf("%lld%lld", &n, &k);
	if (k == 0) { // Subtsak1
		for (int i = 1; i <= n; ++i) scanf("%lld", &a[i]);
		for (int i = 1; i <= n; ++i) scanf("%lld", &ba[i]);
		for (int i = 1; i <= n; ++i) tot += a[i] - ba[i];
		tot = (tot % p + p) % p; (tot *= inv(n)) %= p;
		for (int i = 1; i <= n; ++i) tmp[i] = ((a[i] - tot) % p + p) % p;
		for (int b = 0; b < 4; ++b) for (int i = 1; i <= n; ++i) {
			hasht[b] = hasht[b] * Base[b] + tmp[i];
			hashb[b] = hashb[b] * Base[b] + ba[i];
		}
		for (int b = 0; b < 4; ++b) for (int i = n; i >= 1; --i) {
			if (i == n) basep[b][i] = 1;
			else basep[b][i] = basep[b][i + 1] * Base[b];
		}
		for (int b = 0; b < 4 + 1; ++b) {
			if (b == 4) return puts("0"), 0;
			if (hasht[b] != hashb[b]) break;
		}
		for (int x = 1; x < n; ++x) {
			for (int b = 0; b < 4; ++b) hasht[b] = (hasht[b] - basep[b][1] * tmp[x]) * Base[b] + tmp[x];
			bool ok = 0;
			for (int b = 0; b < 4 + 1; ++b) {
				if (b == 4) return printf("%d\n", x), 0;
				if (hasht[b] != hashb[b]) break;
			}
		}
		return puts("-1"), 0;
	} else { // Subtask2,3,4,5
		return puts("-1"), 0;
	}
}
/*
10
*/
