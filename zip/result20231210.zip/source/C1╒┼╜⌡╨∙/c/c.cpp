#include <bits/stdc++.h>
using namespace std;

int n, m, a, b, ans;
bool vis[3048579];

void dfs(int x, int y, const int &X1, const int &Y1, const int &X2, const int &Y2, int hashv) {
	if (x == n + 1) {
		if (!vis[hashv]) {
			++ans;
		}
		vis[hashv] = 1;
		return;
	}
	if (y == m + 1) {	
		dfs(x + 1, 1, X1, Y1, X2, Y2, hashv);
		return;
	}
	dfs(x, y + 1, X1, Y1, X2, Y2, hashv << 1);
	if ((x >= X1 && x <= X1 + a - 1 && y >= Y1 && y <= Y1 + b - 1) || (x >= X2 && x <= X2 + a - 1 && y >= Y2 && y <= Y2 + b - 1)) {
		dfs(x, y + 1, X1, Y1, X2, Y2, (hashv << 1) | 1);
	}
}

const int P = 1e9 + 7;
long long qpow(long long a, long long b) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % P;
		a = a * a % P;
		b >>= 1;
	}
	return res;
}



int main() {
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	scanf("%d%d%d%d", &n, &m, &a, &b);
	if (n * m <= 20) { // Subtask1
		for (int X1 = 1; X1 <= n - a + 1; ++X1) {
			for (int Y1 = 1; Y1 <= m - b + 1; ++Y1) {
				for (int X2 = 1; X2 <= n - a + 1; ++X2) {
					for (int Y2 = 1; Y2 <= m - b + 1; ++Y2) {
						dfs(1, 1, X1, Y1, X2, Y2, 0);
					}
				}
			}
		}
		printf("%d\n", ans);
	} else if (a == 1) { // Subtask2
		long long tmp = 0, ans = 0;
		for (int l = 1; l <= m; ++l) {
			for (int r = l; r <= min(m, l + b - 1); ++r) {
				(tmp += qpow(2, max(r - l - 1, 0))) %= P;
			}
		}
		ans = qpow(tmp, n);
		if (b * 2 > m)printf("%lld\n", (ans + n * (qpow(2, m) ) - 1 + P) % P);
		else {
			printf("%lld\n", ((ans + n * (qpow(2, m) - qpow(2, max(m - b, 0)))) % P + P) % P);
		}
	} else if (n <= 8 && m <= 8) { // Subtask3
	} else { // Subtask4
	} return 0;
}
/*
00001
00010
00100
01000
10000
11000
01100
00110
00011

*/
