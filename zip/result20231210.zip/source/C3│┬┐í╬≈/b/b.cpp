#include<bits/stdc++.h>
#define int long long
#define pb push_back
using namespace std;
const int mod=998244353,N=1005;
inline int read(){
	int q=0,w=1;char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-') w=-1;ch=getchar();} 	
	while(ch>='0'&&ch<='9') q=q*10+ch-'0',ch=getchar();
	return q*w;
}
int n,m,ans,s,p,u[N],v[N];

struct Path{
	int v,id;
};
vector<Path> e[N],ex[N];

int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=(res*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return res;
}

int dis[N];
bool vis[N];
#define pii pair<int,int>
void dij(){
	priority_queue<pii,vector< pii >,greater< pii > > Q;
	memset(dis,0x3f,sizeof dis);
	dis[s]=0;
	Q.push({0,s});
	while(!Q.empty()){
		int u=Q.top().second;
		Q.pop();
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=0;i<e[u].size();i++){
			int v=e[u][i].v;
			if(!vis[v]&&dis[v]>dis[u]+1){
				dis[v]=dis[u]+1;
				Q.push({dis[v],v});
			}
		}
	}
	return;
}

bool win,com[N];
int T,sp;
void mrk(int u){
	vis[u]=1;
	for(int i=0;i<ex[u].size();i++)
		mrk(ex[u][i].v);
}
void dfs(int u){
	if(u==T){
		win=0;
		return;
	}
	for(int i=0;i<e[u].size();i++){
		if(!com[e[u][i].v]&&vis[e[u][i].v]&&e[u][i].id!=sp){
			com[e[u][i].v]=1;
			dfs(e[u][i].v);
			com[e[u][i].v]=0;
			if(!win) return;
		}
	}
}

signed main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	n=read(),m=read(),s=read(),p=read();
	if(n<=1000&&m<=1000){
		for(int i=1;i<=m;i++){
			int us=read(),vs=read();
			e[us].pb({vs,i});
			ex[vs].pb({us,i});
			u[i]=us,v[i]=vs;
		}
//		for(int i=1;i<=n;i++) printf("%lld\n",in[i]);
		dij();
		for(int t=1;t<=n;t++){
			int rs=0;
			for(int i=1;i<=n;i++) vis[i]=0;
			mrk(t);
			for(int i=1;i<=m;i++){
				T=t,sp=i;
				win=1;
				com[s]=1;
				dfs(s);
				com[s]=0;
				if(win) rs=max(rs,p-dis[v[i]]);
			}
			ans=(ans+rs)%mod;
		}
		ans=ans*ksm(n,mod-2)%mod;
		printf("%lld",ans);
	}
	else if(m==n-1){
		for(int u,v,i=1;i<=m;i++) u=read(),v=read();
		for(int i=2;i<=n;i++) ans=(ans+p-1+mod)%mod;
		ans=ans*ksm(n,mod-2)%mod;
		printf("%lld",ans);
	}
	return 0;
}
/*
8 8 1 10
1 2
1 3
1 4
2 5
3 5
5 6
6 7
6 8
*/
