#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=405,mod=1e9+7;
inline int read(){
	int q=0,w=1;char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-') w=-1;ch=getchar();} 	
	while(ch>='0'&&ch<='9') q=q*10+ch-'0',ch=getchar();
	return q*w;
}
int n,m,sx,sy,ans;

int tp;
struct Point{
	int x,y;
}s[N];
signed main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	n=read(),m=read(),sx=read(),sy=read();
	for(int i=0;i<(1<<(n*m));i++){
		tp=0;
		for(int j=1;j<=n*m;j++)
			if(i&(1<<(j-1)))
				s[++tp]={j/(m+1)+1,j-(j/(m+1))*m};
		bool win=0;
		for(int lx=1;lx<=n&&!win;lx++){
			for(int ly=1;ly<=m&&!win;ly++){
				for(int rx=lx;rx<=n&&!win;rx++){
					for(int ry=1;ry<=m&&!win;ry++){
						win=1;
						for(int j=1;j<=tp&&win;j++){
							int X=s[j].x,Y=s[j].y;
							if(!(X>=lx&&X<=lx+sx-1&&Y>=ly&&Y<=ly+sy-1)&&!(X>=rx&&X<=rx+sx-1&&Y>=ry&&Y<=ry+sy-1)) win=0;
						}
						if(win) ans++;					
					}
				}
			}
		}			
	}
	printf("%lld",ans%mod);
	return 0;
}
//4 4 3 2
