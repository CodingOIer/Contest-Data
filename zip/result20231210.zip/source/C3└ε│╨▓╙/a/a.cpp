#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n,k;
int a[N],b[N];
const int mod=998244353;
signed main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i=0;i<n;i++) scanf("%lld",&a[i]);
	for(int i=0;i<n;i++) scanf("%lld",&b[i]);
	if(k>=n-1){
		printf("0");
		return 0;
	}
	for(int i=0;i<n;i++){
		int w=(a[0]-b[i]+mod)%mod;
		bool z=0;
		for(int j=1;j<n;j++){
			if((a[j]-b[(j+i)%n]+mod)%mod!=w){
				z=1;
				break;
			}
		}
		if(z==0){
			printf("%lld",i);
			return 0;
		}
	}
	printf("-1");
	return 0;
} 
