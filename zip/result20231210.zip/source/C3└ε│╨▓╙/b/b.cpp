#include<bits/stdc++.h>
#define int long long
#define N 1000005
using namespace std;
int n,m,s,p;
int tot,head[N],nxt[N],to[N];
int In[N],in[N],d[N],fa[N];
bool vis[N];
int ans;
queue<int> q;
const int mod=998244353;
int Pow(int x,int y){
	x%=mod;
	int z=1;
	while(y){
		if(y&1) z=z*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return z;
}
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
signed main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lld %lld %lld %lld",&n,&m,&s,&p);
	for(int i=1,u,v;i<=m;i++){
		scanf("%lld %lld",&u,&v);
		add(u,v);
		in[v]++;
	}
	for(int i=1;i<=n;i++){
		d[i]=1e18;
		In[i]=in[i];
	}
	d[s]=0;
	q.push(s);
	while(!q.empty()){
		int x=q.front();
		q.pop();
		for(int i=head[x];i;i=nxt[i]){
			d[to[i]]=min(d[to[i]],d[x]+1);
			in[to[i]]--;
			if(in[to[i]]==0) q.push(to[i]);
		}
	}
	for(int i=1;i<=n;i++) in[i]=In[i];
	for(int i=head[s];i;i=nxt[i]){
		fa[to[i]]=to[i];
		in[to[i]]--;
		vis[to[i]]=1;
		if(in[to[i]]==0) q.push(to[i]);
	}
	while(!q.empty()){
		int x=q.front();
		q.pop();
		if(!fa[x]||(In[fa[x]]>1&&In[x]==1)) fa[x]=x;
		if(In[fa[x]]==1) ans=(ans+max(0ll,p-d[fa[x]]))%mod;
		for(int i=head[x];i;i=nxt[i]){
			if(!vis[to[i]]) fa[to[i]]=fa[x];
			else if(fa[to[i]]!=fa[x]) fa[to[i]]=0;
			vis[to[i]]=1;
			in[to[i]]--;
			if(in[to[i]]==0) q.push(to[i]);
		}
	}
	printf("%lld",ans*Pow(n,mod-2)%mod);
	return 0;
} 
