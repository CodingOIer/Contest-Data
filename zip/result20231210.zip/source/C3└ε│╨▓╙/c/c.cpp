#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,x,y;
int ans;
const int mod=1000000007;
signed main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%lld %lld %lld %lld",&n,&m,&x,&y);
	printf("%lld",ans);
	return 0;
} 
