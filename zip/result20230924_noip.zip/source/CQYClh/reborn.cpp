#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+2;
int n,Q;
int cnt,idx;
int hed[maxn*2],ar[maxn],cr[maxn],dfn[maxn],siz[maxn],br[maxn],dr[maxn];
struct node_edge{
    int nxt,to;
}G[maxn*2];
void add(int u,int v){
    G[++cnt]=(node_edge){hed[u],v};
    hed[u]=cnt;
    return ;
}
void dfs(int x,int f){
    dfn[x]=++idx,siz[x]=1;
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==f)continue;
        dfs(v,x);
        siz[x]+=siz[v];
    }
    return ;
}
int que(int l,int r,int v){
    int ret=0;
    for(int i=l;i<=r;i++)ret=max(ret,ar[i]&v);
    return ret;
}
int fi(int p,int v){
    int ret=0;
    // if(p==1)for(int i=1;i<=n;i++)ret=max(ret,dr[i]&v);
    for(int i=1;i<dfn[p];i++)ret=max(ret,dr[i]&v);
    for(int i=dfn[p]+siz[p];i<=n;i++)ret=max(ret,dr[i]&v);
    return ret;
}
int main(){
    freopen("reborn.in","r",stdin);
    freopen("reborn.out","w",stdout);
    scanf("%d%d",&n,&Q);
    for(int i=1,u,v;i<n;i++){
        scanf("%d%d",&u,&v);
        add(u,v);
        add(v,u);
    }
    for(int i=1;i<=n;i++)scanf("%d",&ar[i]);
    for(int i=1;i<=n;i++)scanf("%d",&cr[i]);
    dfs(1,0);
    for(int i=1;i<=n;i++)br[dfn[i]]=ar[i],dr[dfn[i]]=cr[i];
    int l,r,x,p;
    for(int i=1;i<=Q;i++){
        scanf("%d%d%d%d",&l,&r,&x,&p);
        printf("%d\n",que(l,r,cr[p])+fi(p,x));
    }
    return 0;
}