#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+2;
int n,Q;
int ar[maxn],br[maxn];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
namespace brute1{
    void solve(){
        for(int i=1;i<=n;i++)ar[i]=read();
        for(int i=1;i<=n;i++)br[i]=read();
        int a,b;
        for(int i=1;i<=Q;i++){
            a=read(),b=read();
            printf("%s\n",(a!=b)?"Alice":"Bob");
        }
        return ;
    }
}
namespace brute2{

}
namespace brute4{
    const int maxn2=4097;
    bool dp[maxn2][maxn2],sum[maxn2][maxn2][2];
    void solve(){
        memset(dp,-1,sizeof(dp));
        memset(sum,0,sizeof(sum));
        for(int i=1;i<=n;i++)dp[br[i]][ar[i]^br[i]]=0;
        dp[0][0]=0;
        for(int i=0;i<=3000;i++){
            for(int j=0;j<=3000;j++){
                if(dp[i][j]==-1){
                    dp[i][j]=((i)?sum[i-1][j][1]:0)|((j)?sum[i][j-1][1]:0);
                }
                for(int ty=0;ty<2;ty++)sum[i][j][ty]=((i)?sum[i-1][j][!ty]:0)|((j)?sum[i][j-1][!ty]:0);
            }
        }
        int a,b;
        for(int i=1;i<=Q;i++){
            a=read(),b=read();
            printf("%s\n",(dp[a][b])?"Alice":"Bob");
        }
    }
}
int main(){
    freopen("act.in","r",stdin);
    freopen("act.out","w",stdout);
    n=read(),Q=read();
    int va=0;
    for(int i=1;i<=n;i++)ar[i]=read(),va=max(va,ar[i]);
    for(int i=1;i<=n;i++)br[i]=read(),va=max(va,br[i]);
    if(Q==0||n==0)brute1::solve();
    else if(va<=3000)brute4::solve();
    return 0;
}