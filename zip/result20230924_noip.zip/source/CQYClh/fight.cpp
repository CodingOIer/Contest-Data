#include<bits/stdc++.h>
using namespace std;
const int maxn=4096;
int n,K;
long double X;
long double ar[maxn];
vector<long double>f[13][maxn],g[13][maxn];
long double win(long double A,long double B,bool ty){return (ty)?(B/(A+B)):(A/(A+B));};
int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    scanf("%d%Lf",&n,&X);
    for(int i=13;i>=0;i--)if(n&(1<<i)){K=i;break;}
    for(int i=0;i<=K;i++){
        for(int j=0;j<(1<<K-i);j++){
            f[i][j].resize(1<<i),g[i][j].resize(1<<i);
        }
    }
    for(int i=1;i<n;i++){
        scanf("%Lf",&ar[i-1]);
        f[0][i-1][0]=g[0][i][0]=1;
    }
    ar[n-1]=1;
    for(int i=1;i<=K;i++){
        for(int j=0;j<(1<<K-i);j++){
            for(int p=0;p<(1<<i-1);p++){
                for(int q=0,x,y;q<(1<<i-1);q++){
                    x=((j<<1)<<i-1)+p,y=((j<<1|1)<<i-1)+q;
                    if(x!=n-1&&y!=n-1){
                        f[i][j][p         ]+=f[i-1][j<<1][p]*f[i-1][j<<1|1][q]*win(ar[x],ar[y],0);
                        f[i][j][q|(1<<i-1)]+=f[i-1][j<<1][p]*f[i-1][j<<1|1][q]*win(ar[x],ar[y],1);
                    }
                    if(x!=0&&y!=0){
                        g[i][j][p         ]+=g[i-1][j<<1][p]*g[i-1][j<<1|1][q]*win(ar[x-1],ar[y-1],0);
                        g[i][j][q|(1<<i-1)]+=g[i-1][j<<1][p]*g[i-1][j<<1|1][q]*win(ar[x-1],ar[y-1],1);
                    }
                }
            }
        }
    }
    long double ans,sum;
    for(int x=0,nx;x<n;x++){
        nx=x,ans=1.0;
        for(int i=1;i<=K;i++){
            sum=0;
            if(nx&1){
                for(int j=0,k;j<(1<<i-1);j++){
                    k=((nx-1)<<i-1)+j;
                    sum+=f[i-1][nx-1][j]*win(X,ar[k],0);
                }
            }
            else {
                for(int j=0,k;j<(1<<i-1);j++){
                    k=((nx+1)<<i-1)+j;
                    sum+=g[i-1][nx+1][j]*win(X,ar[k-1],0);
                }
            }
            ans=ans*sum;
            nx>>=1;
        }
        printf("%.11Lf\n",ans);
    }
    cerr<<clock()<<'\n';
    return 0;
}