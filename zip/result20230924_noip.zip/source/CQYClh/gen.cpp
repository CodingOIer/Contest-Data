#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+2,maxm=2e6+2;
const int mod=1e9+7;
int n,m;
int de[maxn],num[maxm];
int ans;
vector<int>aru;
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int f(int A,int B){
    return 1ll*(A^B)*(A|B)%mod*(A&B)%mod;
}
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
int main(){
    freopen("gen.in","r",stdin);
    freopen("gen.out","w",stdout);
    n=read(),m=read();
    for(int i=1,u,v;i<=m;i++){
        u=read(),v=read();
        de[u]++,de[v]++;
    }
    for(int i=1;i<=n;i++){
        num[de[i]]++;
        if(num[de[i]]==1)aru.push_back(de[i]);
    }
    for(int i=0;i<aru.size();i++){
        for(int j=0;j<aru.size();j++){
            ans=(ans+1ll*num[aru[i]]*num[aru[j]]*f(aru[i],aru[j])%mod)%mod;
        }
    }
    printf("%d\n",1ll*ans*f_pow(2,mod-2)%mod);
    return 0;
}