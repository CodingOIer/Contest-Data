#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
int stk[10],tp;
inline void write(int x)
{
	if(!x) return puts("0"),void();
	tp=0;
	while(x) stk[++tp]=x%10,x/=10;
	while(tp) putchar(stk[tp--]^48);
	putchar('\n');
}
const int N=3e5+10,M=N<<2;
int n,q,ans,res,a[N],c[N];
int first[N],to[M],nxt[M],cnt;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void dfs(int x,int fa,int No,int T)
{
	if(x==No) return;
	ans=max(ans,T&a[x]);
	for(int i=first[x],v;i;i=nxt[i])
	{
		if((v=to[i])==fa) continue;
		dfs(v,x,No,T);
	}
}
int main()
{
	freopen("reborn.in","r",stdin);
	freopen("reborn.out","w",stdout);
	n=read(),q=read();
	for(int i=1,u,v;i<n;i++)
		u=read(),v=read(),inc(u,v),inc(v,u);
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) c[i]=read();
	int l,r,x,p;
	while(q--)
	{
		ans=res=0;
		l=read(),r=read(),x=read(),p=read();
		dfs(1,0,p,x);res=ans;
		for(int i=l;i<=r;i++) ans=max(ans,res+(a[i]&c[p]));
		cout<<ans<<'\n';
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
