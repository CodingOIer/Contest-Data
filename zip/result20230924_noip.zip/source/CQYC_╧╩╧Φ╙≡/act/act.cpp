#include<bits/stdc++.h>
#define fi first
#define se second
#define mk make_pair
#define pi pair<int,int>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
const int N=3010;
int n,q,cnt,a[N],b[N],dp[N][N];
bool flag=1,now[2][N];
int main()
{
	freopen("act.in","r",stdin);
	freopen("act.out","w",stdout);
	memset(dp,-1,sizeof(dp));
	dp[0][0]=0;
	n=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++)
	{
		b[i]=read();
		if(a[i]<=3e3&&b[i]<=3e3) dp[a[i]][b[i]]=0;
		else flag=0;
	}
	if(flag) for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			{
				if(!~dp[i][j]) dp[i][j]=now[0][i]||now[1][j];
				now[0][i]|=!dp[i][j],now[1][j]|=!dp[i][j];
			}
	int x,y;
	while(q--)
	{
		x=read(),y=read();
		if(x==y) puts("Bob");
		else if(!n) puts(x==y?"Bob":"Alice");
		else if(n==1)
		{
			if(a[1]==x&&b[1]==y) puts("Bob");
			else if(a[1]<b[1]&&x==y-1&&y>b[1]) puts("Bob");
			else if(a[1]>b[1]&&x-1==y&&x>a[1]) puts("Bob");
			else puts("Alice");
		}
		else puts(dp[x][y]?"Alice":"Bob");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
