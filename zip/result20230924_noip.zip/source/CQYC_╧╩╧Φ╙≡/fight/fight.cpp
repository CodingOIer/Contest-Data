#include<bits/stdc++.h>
using namespace std;
typedef long double ld;
const int N=4110,M=15;
int n,X,a[N];
ld ans,tot,dp[2][N][M];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d%d",&n,&X);
	for(int i=1;i<n;i++) scanf("%d",a+i);
	for(int i=0;i<2;i++)
		for(int j=1;j<=n;j++) dp[i][j][0]=1;
	for(int len=2,j=1;len<n;len<<=1,++j)
		for(int l=1;l<n-len;l+=len)
			for(int i=l;i<l+(len>>1);i++)
				for(int k=l+(len>>1);k<l+len;k++)
					dp[0][i][j]+=dp[0][i][j-1]*dp[0][k][j-1]*(1.0*a[i]/(a[i]+a[k])),
					dp[0][k][j]+=dp[0][i][j-1]*dp[0][k][j-1]*(1.0*a[k]/(a[i]+a[k]));
	for(int len=2,j=1;len<n;len<<=1,++j)
		for(int l=len+1;l<=n;l+=len)
			for(int i=l;i<l+(len>>1);i++)
				for(int k=l+(len>>1);k<l+len;k++)
					dp[1][i][j]+=dp[1][i][j-1]*dp[1][k][j-1]*(1.0*a[i-1]/(a[i-1]+a[k-1])),
					dp[1][k][j]+=dp[1][i][j-1]*dp[1][k][j-1]*(1.0*a[k-1]/(a[i-1]+a[k-1]));
	for(int i=1;i<=n;i++)
	{
		ans=tot=1;
		for(int j=i-1,k=(i&1);j;j--)
		{
			while((j-1)/(1<<k)!=(i-1)/(1<<k)) ++k,ans*=(tot==0)?1:tot,tot=0;
			tot+=dp[0][j][k-1]*(1.0*X/(X+a[j]));
		}
		ans*=tot;tot=1;
		for(int j=i+1,k=!(i&1);j<=n;j++)
		{
			while((j-1)/(1<<k)!=(i-1)/(1<<k)) ++k,ans*=(tot==0)?1:tot,tot=0;
			tot+=dp[1][j][k-1]*(1.0*X/(X+a[j-1]));
		}
		ans*=tot;
		printf("%.15Lf\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
