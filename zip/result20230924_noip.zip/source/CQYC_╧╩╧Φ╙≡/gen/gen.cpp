#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
const int N=2e5+10,M=2e6+10,mod=1e9+7;
int n,m,ans,in[N],num[M];
int cnt,b[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int check(int x,int y) {return 1ll*(x^y)*(x|y)%mod*(x&y)%mod;}
int main()
{
	freopen("gen.in","r",stdin);
	freopen("gen.out","w",stdout);
	n=read(),m=read();
	for(int i=1,x,y;i<=m;i++)
		x=read(),y=read(),++in[x],++in[y];
	for(int i=1;i<=n;i++) ++num[b[i]=in[i]];
	sort(b+1,b+n+1);
	cnt=unique(b+1,b+n+1)-b-1;
	for(int i=1;i<=cnt;i++)
		for(int j=1;j<i;j++)
			upd(ans,1ll*num[b[i]]*num[b[j]]%mod*check(b[i],b[j])%mod);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
