#include<bits/stdc++.h>
#define reg register
#define For(i,a,b) for(reg int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(reg int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(reg int i=head[u];i;i=nxt[i])
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
const int N=6e5+10,SZ=7e6+10;
int head[N],to[N],nxt[N],cnt;
void add(int u,int v){
	to[++cnt]=v,nxt[cnt]=head[u],head[u]=cnt;
}
int num,dfn[N],sz[N];
void dfs(int u,int f){
	dfn[u]=++num,sz[u]=1;
	go(u)if(to[i]!=f)dfs(to[i],u),sz[u]+=sz[to[i]];
}
int n,q;
struct ask{
	int l,r,x,id;
};
bool cmp1(ask a,ask b){
	return a.r<b.r;
}
struct _01Trie{
	int idx=1,c[SZ][2],tim[SZ];
	int ans[N];
	ask d[N];int tot;
	void insert(int x,int p){
		int r=1;
		for(int i=20;~i;i--){
			int v=x>>i&1;
			if(c[r][v])r=c[r][v];
			else r=c[r][v]=++idx;
			tim[r]=p;
		}
	}
	void merge(int &r1,int r2){
	    if(!r1)r1=++idx;
	    tim[r1]=max(tim[r1],tim[r2]);
	    if(c[r2][0])merge(c[r1][0],c[r2][0]);
	    if(c[r2][1])merge(c[r1][1],c[r2][1]);
	    return;
	}
	void dfs(int u){
		if(c[u][0])dfs(c[u][0]);
		if(c[u][1])dfs(c[u][1]);
		if(c[u][1])merge(c[u][0],c[u][1]);
	}
	int lst=1;
	inline void rebuild(int* a,int n){
		For(i,lst,n)insert(a[i],i);lst=n+1;
		dfs(1);
	}
	inline int query(int x,int l){
		int r=1,res=0;
		for(int i=20;~i;i--){
			int v=x>>i&1;
			if(v&&tim[c[r][1]]>=l)r=c[r][1],res+=(1<<i);
			else if(tim[c[r][0]]>=l)r=c[r][0];
			else break;
		}
		return res;
	}
	void solve(int* a,int op=0){
		sort(d+1,d+1+tot,cmp1);
		int S=sqrt(1.0*tot*log2(tot)*log2(tot)),L=1;
		S=8750;
		if(op)rebuild(a,n);
		For(i,1,tot){
			int l=d[i].l,r=d[i].r,x=d[i].x,id=d[i].id;
			if(!op&&(i-1)%S==0){
				rebuild(a,r);
				L=r+1;
			}
			if(l>r)continue;
			reg int res=query(x,l);
			if(!op)For(j,max(L,l),r)res=max(res,x&a[j]);
			ans[id]=res;
		}
	}
	void merge2(int &r1,int r2){
	    if(!r1)r1=++idx,tim[r1]=1e9;
	    tim[r1]=min(tim[r1],tim[r2]);
	    if(c[r2][0])merge2(c[r1][0],c[r2][0]);
	    if(c[r2][1])merge2(c[r1][1],c[r2][1]);
	    return;
	}
	void dfs2(int u){
		if(c[u][0])dfs2(c[u][0]);
		if(c[u][1])dfs2(c[u][1]);
		if(c[u][1])merge2(c[u][0],c[u][1]);
	}
	inline void rebuild2(int* a,int n){
		For(i,1,idx)c[i][0]=c[i][1]=tim[i]=0;idx=1;
		Rof(i,n,1)insert(a[i],i);
		dfs2(1);
	}
	inline int query2(int x,int R){
		int r=1,res=0;
		for(int i=20;~i;i--){
			int v=x>>i&1;
			if(v&&tim[c[r][1]]>0&&tim[c[r][1]]<=R)r=c[r][1],res+=(1<<i);
			else if(tim[c[r][0]]>0&&tim[c[r][0]]<=R)r=c[r][0];
			else break;
		}
		return res;
	}
	void solve2(int* a){
		rebuild2(a,n);
		For(i,1,tot){
			int l=d[i].l,r=d[i].r,x=d[i].x,id=d[i].id;
			if(l>r)continue;
			ans[id]=query2(x,r);
		}
	}
}q1,q2,q3;
//q1.solve(a),q2.solve(c)
int a[N],c[N];
int pr[30],tp;
inline void write(int x){
	if(!x)return puts("0"),void();
	while(x)pr[++tp]=x%10,x/=10;
	while(tp)putchar(pr[tp--]^48); 
	putchar('\n');
}
signed main(){
	freopen("reborn.in","r",stdin);
//	freopen("data2.txt","r",stdin);
	freopen("reborn.out","w",stdout);
	n=read(),q=read();
    For(i,2,n){
    	int u=read(),v=read();
    	add(u,v),add(v,u);
	}
    dfs(1,0);
    For(i,1,n){a[i]=read();}
	For(i,1,n){c[dfn[i]]=read();}
	For(i,1,q){
		int l=read(),r=read(),x=read(),p=read();
		//q1:x=c[dfn[p]],l=l,r=r
		//q2:x=x,l=1,r=dfn[p]-1;x=x,l=dfn[p]+sz[p],r=n
		q1.d[++q1.tot]=(ask){l,r,c[dfn[p]],i};
		q2.d[++q2.tot]=(ask){1,dfn[p]-1,x,i};
		q3.d[++q3.tot]=(ask){dfn[p]+sz[p],n,x,i};
	}
	q1.solve(a);
//	return 0;
	q2.solve2(c);
	q3.solve(c,1);
	For(i,1,q)write(q1.ans[i]+max(q2.ans[i],q3.ans[i]));
	return 0;
}
