#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
int n,q,a[maxn],b[maxn],x,y;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("act.in","r",stdin);
    freopen("act.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    for(int i=1;i<=n;i++)
        b[i]=read();
    while(q--){
        x=read(),y=read();
        if(!n){
            if(!x&&!y){
                puts("Bob");
                continue;
            }
            if(x==1&&y==1){
                puts("Bob");
                continue;
            }
            puts("Alice");
        }
    }
    return 0;
}