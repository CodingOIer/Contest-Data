#include <bits/stdc++.h>
using namespace std;
int n,x,a[5000],vis[5000];
double sum[10000][5000];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int y,int z){
    if(y==1)
        return;
    for(int i=1;i<=n;i++)
        if(sum[x][i])
            for(int j=1;j<=n;j++)
                if(sum[x+1][j]&&i!=j){
                    sum[z][i]+=sum[x][i]*sum[x+1][j]*((double)a[i]*1.0/(a[i]+a[j]));
                    sum[z][j]+=sum[x][i]*sum[x+1][j]*((double)a[j]*1.0/(a[i]+a[j]));
                }
    solve(x+2,y-1,z+1);
}
signed main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    n=read(),x=read();
    int bj=0;
    for(int i=1;i<n;i++){
        a[i]=read();
        if(a[i]!=x)
            bj=1;
    }
    if(!bj){
        double ans=(double)1.0/n;
        for(int i=1;i<=n;i++)
            printf("%.12f\n",ans);
        return 0;
    }
    a[n]=x;
    for(int i=1;i<=n;i++){
        for(int j=1;j<2*n;j++)
            for(int l=1;l<=n;l++)
                sum[j][l]=0;
        for(int j=1;j<i;j++)
            sum[j][j]=1;
        sum[i][n]=1;
        for(int j=i;j<n;j++)
            sum[j+1][j]=1;
        solve(1,n,n+1);
        printf("%.12f\n",sum[n*2-1][n]);
    }
    return 0;
}