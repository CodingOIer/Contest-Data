#include <bits/stdc++.h>
using namespace std;
const int maxn=3e5+5;
int n,q,x,y,a[maxn],c[maxn],l,r,ans,sum;
vector<int> to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void dfs(int u,int f){
    if(u==y)
        return;
    sum=max(sum,c[u]&x);
    for(auto v:to[u])
        if(v!=f&&v!=y)
            dfs(v,u);
}
signed main(){
    freopen("reborn.in","r",stdin);
    freopen("reborn.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        x=read(),y=read();
        to[x].push_back(y);
        to[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        a[i]=read();
    for(int i=1;i<=n;i++)
        c[i]=read();
    while(q--){
        ans=0,sum=0;
        l=read(),r=read(),x=read(),y=read();
        for(int i=l;i<=r;i++)
            ans=max(ans,a[i]&c[y]);
        dfs(1,0);
        printf("%d\n",ans+sum);
    }
    return 0;
}
