#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5,mod=1e9+7;
int n,m,u,v,in[maxn],ans;
map<int,int> ma;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int &a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
int power(int a,int b){
    int res=1;
    while(b){
        if(b&1)
            res=res*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return res;
}
signed main(){
    freopen("gen.in","r",stdin);
    freopen("gen.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        u=read(),v=read();
        in[u]++,in[v]++;
    }
    if(n<=2000){
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                add(ans,(in[i]^in[j])*(in[i]|in[j])%mod*(in[i]&in[j])%mod);
    }
    else{
        int maxx=0;
        for(int i=1;i<=n;i++)
            ma[in[i]]++,maxx=max(maxx,in[i]);
        for(int i=0;i<=maxx;i++)
            if(ma[i])
                for(int j=0;j<=maxx;j++)
                    add(ans,ma[i]*ma[j]%mod*(i^j)%mod*(i|j)%mod*(i&j)%mod);
    }
    printf("%lld\n",ans*power(2,mod-2)%mod);
    return 0;
}