#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 300010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N<<1],to[N<<1],t;
il void add(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;
    nxt[++t]=head[v];head[v]=t;to[t]=u;
}
int n,m,a[N],c[N],ans1,ans2;
bool vis[N];
queue<int> Q;
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("reborn.in","r",stdin);
	freopen("reborn.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<n;++i) add(read(),read());
    for(int i=1;i<=n;++i) a[i]=read();
    for(int i=1;i<=n;++i) c[i]=read();
    while(m--){
        int l=read(),r=read(),x=read(),p=read();
        for(int i=1;i<=n;++i) vis[i]=0;
        Q.push(1);vis[1]=1;ans1=ans2=0;
        while(!Q.empty()){
            int u=Q.front();Q.pop();
            if(u==p) continue;
            ans1=max(ans1,c[u]&x);
            for(int i=head[u];i;i=nxt[i]) if(!vis[to[i]]){
                vis[to[i]]=1;Q.push(to[i]);
            }
        }
        for(int i=l;i<=r;++i) ans2=max(ans2,a[i]&c[p]);
        write(ans1+ans2);putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}