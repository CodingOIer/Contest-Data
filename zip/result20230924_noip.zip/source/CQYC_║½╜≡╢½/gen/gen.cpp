#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define inf (int)(1000000000000000000)
#define mod 1000000007
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
int n,m,du[N],a[N],cnt[N],tot,ans;
il int calc(int x,int y){
    return (x^y)*(x|y)%mod*(x&y)%mod;
}
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("gen.in","r",stdin);
	freopen("gen.out","w",stdout);
    n=read();m=read();
    while(m--){
        ++du[read()];++du[read()];
    }
    sort(du+1,du+1+n);du[0]=-1;
    for(int i=1;i<=n;++i){
        if(du[i]!=du[i-1]){
            a[++tot]=du[i];cnt[tot]=1;
        }
        else ++cnt[tot];
    }
    for(int i=1;i<=tot;++i) for(int j=i+1;j<=tot;++j) Add(ans,cnt[i]*cnt[j]%mod*calc(a[i],a[j])%mod);
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}