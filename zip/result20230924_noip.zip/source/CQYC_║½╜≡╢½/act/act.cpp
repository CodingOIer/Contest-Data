#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,Q,a[N],b[N],dp[3010][3010],sum1[3010][3010],sum2[3010][3010];
map<pii,bool> mp;
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("act.in","r",stdin);
	freopen("act.out","w",stdout);
    n=read();Q=read();
    for(int i=1;i<=n;++i) a[i]=read();
    for(int i=1;i<=n;++i) b[i]=read();
	memset(dp,-1,sizeof(dp));
	for(int i=0;i<=n;++i){
		if(a[i]<=3000&&b[i]<=3000) dp[a[i]][b[i]]=0;
		mp[pii(a[i],b[i])]=1;
	}
	for(int i=0;i<=3000;++i){
		for(int j=0;j<=3000;++j){
			if(dp[i][j]==-1){
				dp[i][j]=0;
				for(int k=0;k<i;++k) dp[i][j]=sum1[i-1][j];
				for(int k=0;k<j;++k) dp[i][j]=sum2[i][j-1];
			}
			sum1[i][j]=sum1[max(0ll,i-1)][j]|(dp[i][j]^1);
			sum2[i][j]=sum2[i][max(0ll,j-1)]|(dp[i][j]^1);
			// if(!dp[i][j])cout<<i<<" "<<j<<" "<<(dp[i][j]?"Alice":"Bob")<<"\n";
		}
	}
	// cerr<<"ERROR";
	while(Q--){
		int A=read(),B=read();
		if(A<=3000) puts(dp[A][B]?"Alice":"Bob");
		else if(!n) puts((A||B)?"Alice":"Bob");
		else if(n==1){
			if(a[1]==A&&b[1]==B) puts("Bob");
			else if(a[1]==A||b[1]==B) puts("Alice");
			else if(a[1]<A&&b[1]<B) puts((A-1||B-1)?"Alice":"Bob");
		}
		else puts(mp.count(pii(A,B))?"Bob":"Alice");
	}
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}