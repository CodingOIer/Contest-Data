#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 5000
// #define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,X,son[N<<2][2],id,f[N<<2],a[N];
vector<int> V[2][N<<2];
queue<int> Q;
vector<dl> dp[2][N<<2];
il dl calc(dl u,dl v){
    return u/(u+v);
}
il vector<int> merge(vector<int> u,vector<int> v){
    vector<int> now;
    for(int i=0,j=0;i<(int)u.size()||j<(int)v.size();){
        if(i==(int)u.size()){
            if(now.empty()||now.back()!=v[j]) now.pk(v[j]);
            ++j;
        }
        else if(j==(int)v.size()){
            if(now.empty()||now.back()!=u[i]) now.pk(u[i]);
            ++i;
        }
        else if(u[i]<v[j]){
            if(now.empty()||now.back()!=u[i]) now.pk(u[i]);
            ++i;
        }
        else{
            if(now.empty()||now.back()!=v[j]) now.pk(v[j]);
            ++j;
        }
    }
    return now;
}
il bool check(int u,int v){
    return son[u][1]==v;
}
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    n=id=read();X=read();
    for(int i=1;i<n;++i){
        a[i]=read();
        V[0][i].pk(a[i]);dp[0][i].pk(1);
        V[1][i+1].pk(a[i]);dp[1][i+1].pk(1);
    }
    for(int i=1;i<=n;++i) Q.push(i);
    // cerr<<V[0][1].size()<<" "<<V[0][2].size()<<"\n";
    while((int)Q.size()>1){
        int u=Q.front();Q.pop();
        int v=Q.front();Q.pop();
        Q.push(++id);
        son[id][0]=u;son[id][1]=v;f[u]=f[v]=id;
        V[0][id]=merge(V[0][u],V[0][v]);dp[0][id].resize(V[0][id].size()+1);
        // cerr<<u<<" "<<v<<"\n";
        for(int i=0;i<(int)V[0][u].size();++i){
            int tmp=lower_bound(V[0][id].begin(),V[0][id].end(),V[0][u][i])-V[0][id].begin();
            for(int j=0;j<(int)V[0][v].size();++j){
                dp[0][id][tmp]+=dp[0][u][i]*dp[0][v][j]*calc(V[0][u][i],V[0][v][j]);
            }
        }
        for(int i=0;i<(int)V[0][v].size();++i){
            int tmp=lower_bound(V[0][id].begin(),V[0][id].end(),V[0][v][i])-V[0][id].begin();
            for(int j=0;j<(int)V[0][u].size();++j) dp[0][id][tmp]+=dp[0][v][i]*dp[0][u][j]*calc(V[0][v][i],V[0][u][j]);
        }
        V[1][id]=merge(V[1][u],V[1][v]);dp[1][id].resize(V[1][id].size()+1);
        for(int i=0;i<(int)V[1][u].size();++i){
            int tmp=lower_bound(V[1][id].begin(),V[1][id].end(),V[1][u][i])-V[1][id].begin();
            for(int j=0;j<(int)V[1][v].size();++j) dp[1][id][tmp]+=dp[1][u][i]*dp[1][v][j]*calc(V[1][u][i],V[1][v][j]);
        }
        for(int i=0;i<(int)V[1][v].size();++i){
            int tmp=lower_bound(V[1][id].begin(),V[1][id].end(),V[1][v][i])-V[1][id].begin();
            for(int j=0;j<(int)V[1][u].size();++j) dp[1][id][tmp]+=dp[1][v][i]*dp[1][u][j]*calc(V[1][v][i],V[1][u][j]);
        }
    }
    for(int i=1;i<=n;++i){
        dl res1=1,res2=0;int now=i;
        while(now!=id){
            dl tmp1=0,tmp2=0;
            if(check(f[now],now)){
                for(int j=0;j<(int)V[0][son[f[now]][0]].size();++j){
                    int x=V[0][son[f[now]][0]][j];
                    if(x==X){
                        tmp1+=dp[0][son[f[now]][0]][j]*res1;
                        for(int k=0;k<(int)V[1][now].size();++k) if(V[1][now][k]!=X) tmp1+=dp[0][son[f[now]][0]][j]*dp[1][now][k]*calc(X,V[1][now][k]);
                    }
                    else{
                        tmp2+=dp[0][son[f[now]][0]][j]*res2;
                        tmp1+=dp[0][son[f[now]][0]][j]*res1*calc(X,V[0][son[f[now]][0]][j]);
                    }
                }
            }
            else{
                for(int j=0;j<(int)V[1][son[f[now]][1]].size();++j){
                    int x=V[1][son[f[now]][1]][j];
                    if(x==X){
                        tmp1+=dp[1][son[f[now]][1]][j]*res1;
                        for(int k=0;k<(int)V[0][now].size();++k) if(V[0][now][k]!=X) tmp1+=dp[1][son[f[now]][1]][j]*dp[0][now][k]*calc(X,V[0][now][k]);
                    }
                    else{
                        tmp2+=dp[1][son[f[now]][1]][j]*res2;
                        tmp1+=dp[1][son[f[now]][1]][j]*res1*calc(X,V[1][son[f[now]][1]][j]);
                    }
                }
            }
            res1=tmp1;res2=tmp2;
            now=f[now];
        }
        printf("%.10lf\n",res1);
    }
	// cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}