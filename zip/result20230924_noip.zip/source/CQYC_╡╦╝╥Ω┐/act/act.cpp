#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("act.in", "r", stdin);
    freopen("act.out", "w", stdout);
    return 0;
}