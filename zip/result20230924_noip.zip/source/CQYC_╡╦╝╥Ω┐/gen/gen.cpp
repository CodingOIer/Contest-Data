#include <bits/stdc++.h>
using namespace std;
const int P = 1e9 + 7;
int n, m, ans;
int d[400000];
unordered_map<int, int> p;
int main()
{
    freopen("gen.in", "r", stdin);
    freopen("gen.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1, x, y; i <= m; i++)
        scanf("%d%d", &x, &y), d[x]++, d[y]++;
    for (int i = 1; i <= n; i++)
        p[d[i]]++;
    for (auto i : p)
        for (auto j : p)
            ans = (ans + 1ll * (i.first ^ j.first) * (i.first | j.first) * (i.first & j.first) % P * i.second % P * j.second) % P;
    printf("%lld\n", (P + 1ll) * ans / 2 % P);
    return 0;
}