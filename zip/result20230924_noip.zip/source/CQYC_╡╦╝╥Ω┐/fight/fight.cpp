#include <bits/stdc++.h>
using namespace std;
int n, m;
vector<pair<int, long double>> f[2][20][5000];
int main()
{
    freopen("fight.in", "r", stdin);
    freopen("fight.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 0, x; i < n - 1; i++)
        scanf("%d", &x), f[0][0][i + 1].emplace_back(x, 1), f[1][0][i].emplace_back(x, 1);
    for (int c : {0, 1})
        for (int i = 0; 1 << i < n; i++)
            for (int j = 0; j < n; j += 1 << (i + 1))
                for (int t : {0, 1 << i})
                    for (auto x : f[c][i][j + t])
                    {
                        f[c][i + 1][j].emplace_back(x.first, 0);
                        for (auto y : f[c][i][j + (1 << i) - t])
                            f[c][i + 1][j].back().second += x.second * y.second * x.first / (x.first + y.first);
                    }
    for (int i = 0; i < n; i++)
    {
        long double ans = 1;
        for (int j = 0, p = i; 1 << j < n; j++)
        {
            long double res = 0;
            for (auto x : f[p >> j & 1][j][p ^ (1 << j)])
                res += x.second / (m + x.first);
            p &= ~(1 << j);
            ans *= res * m;
        }
        printf("%.12Lf\n", ans);
    }
    return 0;
}