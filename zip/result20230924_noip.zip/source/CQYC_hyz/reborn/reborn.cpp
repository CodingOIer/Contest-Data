#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}
int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;
const int N = 3e5 + 10;
int n, q, cnt;
int a[N], c[N], dfn[N], siz[N], rnk[N];
vector<int> e[N];
void dfs(int x) {
    dfn[x] = ++cnt, rnk[cnt] = x, siz[x] = 1;
    for(int v : e[x]) if(!dfn[v]) dfs(v), siz[x] += siz[v];
}
bool edmer;
signed main() {
	freopen("reborn.in", "r", stdin);
	freopen("reborn.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	n = read(), q = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }
    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= n; i++) c[i] = read();
    dfs(1);
    while(q--) {
        int l = read(), r = read(), x = read(), p = read(), ans1 = 0, ans2 = 0;
        for(int i = 1; i < dfn[p]; i++) ans1 = max(ans1, x & c[rnk[i]]);
        for(int i = dfn[p] + siz[p]; i <= n; i++) ans1 = max(ans1, x & c[rnk[i]]);
        for(int i = l; i <= r; i++) ans2 = max(ans2, c[p] & a[i]);
        write(ans1 + ans2), putchar('\n');
    }
    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 