#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}
int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;
const int N = 1 << 12;
int n, v;
int a[N];
vector<double> f[12][N];
bool edmer;
signed main() {
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	n = read(), v = read();
	for(int i = 1; i < n; i++) a[i] = read();
	for(int i = 0; (1 << i) < n; i++) {
		for(int j = 1; j < n; j += (1 << i)) {
			for(int k = 0; k < (1 << i) and j + k < n; k++) {
				if(!i) { f[i][j].push_back(1); continue; }
				int g = j, h = k, o = j + (1 << (i - 1));
				if(h >= (1 << (i - 1))) swap(o, g), h -= (1 << (i - 1));
				double res = f[i - 1][g][h], sum = 0;
				for(int l = 0; l < (1 << (i - 1)) and o + l < n; l++)
					sum += (double) f[i - 1][o][l] * a[j + k] / (a[o + l] + a[j + k]);
				f[i][j].push_back(res * sum);
			}
		}
		for(int j = 0; j < n; j += (1 << i)) {
			for(int k = 0; k < (1 << i) and j + k < n; k++) {
				if(!i) { f[i][j].push_back(1); continue; }
				int g = j, h = k, o = j + (1 << (i - 1));
				if(h >= (1 << (i - 1))) swap(o, g), h -= (1 << (i - 1));
				double res = f[i - 1][g][h], sum = 0;
				for(int l = 0; l < (1 << (i - 1)) and o + l < n; l++)
					sum += (double) f[i - 1][o][l] * a[j + k] / (a[o + l] + a[j + k]);
				f[i][j].push_back(res * sum);
			}
		}
	}
	for(int i = 1; i <= n; i++) {
		double ans = 1, sum = 0;
		for(int j = 1; (1 << j) <= n; j++) {
			int R = (i + (1 << j) - 1) / (1 << j) * (1 << j), L = R - (1 << j) + 1;
			if(i < L + (1 << (j - 1))) L += (1 << (j - 1)); else R -= (1 << (j - 1));
			if(i < L) L--, R--; sum = 0;
			for(int k = L; k <= R; k++) sum += (double) f[j - 1][L][k - L] * v / (v + a[k]); 
			ans = ans * sum;
		}
		printf("%.12lf\n", ans);
	}
    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 