#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}
int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;
const int N = 1e6 + 10;
struct node {
    int a, b;
} op[N];
int n, q;
int a[N], b[N];
namespace sub1 {
    void solve() {
        while(q--) {
            int a = read(), b = read();
            puts(a == b ? "Bob" : "Alice");
        }
    }
}

namespace sub2 {
    const int M = 3e3 + 10;
    int f[M][M];
    set<int> g[M], h[M];
    bool check() {
        for(int i = 1; i <= q; i++) op[i] = {read(), read()};
        for(int i = 1; i <= n; i++) if(a[i] >= M or b[i] >= M) return 0;
        for(int i = 1; i <= q; i++) if(op[i].a >= M or op[i].b >= M) return 0;
        return 1;
    }
    void solve() {
        for(int i = 1; i <= n; i++) g[a[i]].insert(b[i]), h[b[i]].insert(a[i]);

        for(int i = 0; i < M; i++) for(int j = 0; j < M; j++) {
            if(g[i].find(j) != g[i].end() or h[j].find(i) != h[j].end()) g[i].insert(j), h[j].insert(i), f[i][j] = 1;
            else if((g[i].empty() or *g[i].begin() > j) and (h[j].empty() or *h[j].begin() > i)) g[i].insert(j), h[j].insert(i), f[i][j] = 1;
            // if(f[i][j]) cout << i << " " << j << '\n';
        }

        for(int i = 1; i <= q; i++) puts(f[op[i].a][op[i].b] ? "Bob" : "Alice");
    }
}

namespace sub3 {
    void solve() {
        while(q--) {
            int x = read(), y = read();
            if(a[1] == b[1]) puts(x == y ? "Bob" : "Alice");
            else if(x >= a[1] and y >= b[1]) {
                if(x == a[1] and y == b[1]) puts("Bob");
                else if(y == x + 1 and b[1] > a[1] and y > b[1]) puts("Bob");
                else if(x == y + 1 and a[1] > b[1] and x > a[1]) puts("Bob");
                else puts("Alice");
            }
            else puts(x == y ? "Bob" : "Alice");
        }
    }
}

namespace sub4 {
    void solve() {
        while(q--) {
            int x = read(), y = read(), flag = 0, f = 0;
            for(int i = 1; i <= n; i++) {
            if(x >= a[i] and y >= b[i]) {
                f = 1;
                if(x == a[i] and y == b[i]) flag = 1;
                else if(y == x + 1 and b[i] > a[i] and y > b[i]) flag = 1;
                else if(x == y + 1 and a[i] > b[i] and x > a[i]) flag = 1;
            }
            }
            if(f) puts(flag ? "Bob" : "Alice");
            else puts(x == y ? "Bob" : "Alice");
        }
    }
}

bool edmer;
signed main() {
	freopen("act.in", "r", stdin);
	freopen("act.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
    n = read(), q = read();
    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= n; i++) b[i] = read();
    if(!n) sub1 :: solve();
    else if(n == 1) sub3 :: solve();
    else if(sub2 :: check()) sub2 :: solve();
    else sub4 :: solve();
    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 