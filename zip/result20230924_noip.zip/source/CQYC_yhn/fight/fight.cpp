#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[5005],b[5005];
double p[20][5005],pre[20][5005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void build(int k,int l,int r,int g){
    if(l==r){
        p[g][l]=1.0;
        return;
    }
    int mid=(l+r)>>1;
    build(k<<1,l,mid,g+1);build((k<<1)^1,mid+1,r,g+1);
    for(int i=l;i<=r;i++) p[g][i]=0;
    for(int i=l;i<=mid;i++){
        for(int j=mid+1;j<=r;j++){
            p[g][i]=p[g][i]+p[g+1][i]*p[g+1][j]*((double)a[i]/((double)a[i]+(double)a[j]));
        }
    }
    for(int i=mid+1;i<=r;i++){
        for(int j=l;j<=mid;j++){
            p[g][i]=p[g][i]+p[g+1][i]*p[g+1][j]*((double)a[i]/((double)a[i]+(double)a[j]));
        }
    }
}
inline void add(int k,int l,int r,int g,int h,int w){
    if(l==r){
        for(int i=0;i<=15;i++) pre[i][l]=p[i][l];
        p[w][l]=1.0;
        b[l]=a[l];
        a[l]=h;
        return;
    }
    int mid=(l+r)>>1;
    if(g<=mid){
        add(k<<1,l,mid,g,h,w+1);
        p[w][g]=0;
        for(int i=mid+1;i<=r;i++) p[w][g]=p[w][g]+p[w+1][g]*p[w+1][i]*((double)a[g]/((double)a[g]+(double)a[i]));
        for(int i=mid+1;i<=r;i++) p[w][i]=p[w][i]-p[w+1][i]*pre[w+1][g]*((double)a[i]/((double)a[i]+(double)b[g]));
        for(int i=mid+1;i<=r;i++) p[w][i]=p[w][i]+p[w+1][i]*p[w+1][g]*((double)a[i]/((double)a[i]+(double)a[g]));
    }
    else{
        add((k<<1)^1,mid+1,r,g,h,w+1);
        p[w][g]=0;
        for(int i=l;i<=mid;i++) p[w][g]=p[w][g]+p[w+1][g]*p[w+1][i]*((double)a[g]/((double)a[g]+(double)a[i]));
        for(int i=l;i<=mid;i++) p[w][i]=p[w][i]-p[w+1][i]*pre[w+1][g]*((double)a[i]/((double)a[i]+(double)b[g]));
        for(int i=l;i<=mid;i++) p[w][i]=p[w][i]+p[w+1][i]*p[w+1][g]*((double)a[i]/((double)a[i]+(double)a[g]));
    } 
    // cout<<w<<" "<<l<<" "<<r<<" "<<g<<" "<<h<<"\n";
    // for(int i=l;i<=r;i++) cout<<p[w][i]<<" ";
    // cout<<"\n";
}
signed main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    n=read(),a[1]=read();
    for(int i=2;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++){
        if(a[i]!=a[i-1]) build(1,1,n,0);
        cout<<fixed<<setprecision(14)<<p[0][i]<<"\n";
        swap(a[i],a[i+1]);
    }
    return 0;
}