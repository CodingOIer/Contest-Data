#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,m,t1,t2,sum[2000005],cnt[2000005],ans=0;
vector<int> e;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
signed main(){
    freopen("gen.in","r",stdin);
    freopen("gen.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        t1=read(),t2=read();
        sum[t1]++;sum[t2]++;
    }
    for(int i=1;i<=n;i++) cnt[sum[i]]++,e.push_back(sum[i]);
    sort(e.begin(),e.end());
    e.resize(unique(e.begin(),e.end())-e.begin());
    for(int i=0;i<(int)e.size();i++){
        for(int j=0;j<(int)e.size();j++){
            int d=(((e[i]^e[j])*(e[i]&e[j]))%M)*(e[i]|e[j])%M;
            d=(d*cnt[e[i]])%M;
            d=(d*cnt[e[j]])%M;
            ans=(ans+d)%M;
        }
    }
    cout<<ans*ksm(2,M-2)%M;
    return 0;
}