#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,a[1000005],b[1000005],t1,t2,dp[3005][3005][2],sum[2][3005][3005][2];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("act.in","r",stdin);
    freopen("act.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++) b[i]=read();
    if(q==0) return 0;
    else if(n==0){
        for(int i=1;i<=q;i++){
            t1=read(),t2=read();
            if(t1==t2) puts("Bob");
            else puts("Alice");
        }
    }
    else if(n==1){
        for(int i=1;i<=q;i++){
            t1=read(),t2=read();
            if(a[1]==b[1]){
                if(t1==t2) puts("Bob");
                else puts("Alice");
            }
            else if(a[1]<b[1]){
                if(t1==t2){
                    if(t1<max(a[1],b[1])) puts("Bob");
                    else puts("Alice");
                }
                else if(t1==(t2-1)){
                    if(t1==max(a[1],b[1])) puts("Bob");
                    else puts("Alice");
                }
                else puts("Alice");
            }
            else{
                if(t1==t2){
                    if(t1<max(a[1],b[1])) puts("Bob");
                    else puts("Alice");
                }
                else if(t1==(t2+1)){
                    if(t2==max(a[1],b[1])) puts("Bob");
                    else puts("Alice");
                }
                else puts("Alice");
            }
        }
    }
    else{
        memset(dp,-1,sizeof(dp));
        dp[0][0][0]=dp[0][0][1]=0;
        for(int i=1;i<=n;i++) dp[a[i]][b[i]][0]=dp[a[i]][b[i]][1]=0;
        for(int i=0;i<=3000;i++){
            for(int j=0;j<=3000;j++){
                for(int g=0;g<=1;g++){
                    if(dp[i][j][g]==-1){
                        bool f=1;
                        if(i) f&=sum[0][i-1][j][g^1];
                        if(j) f&=sum[1][i][j-1][g^1];
                        dp[i][j][g]=f^1;
                    }
                    if(i==0) sum[0][i][j][g]=dp[i][j][g];
                    else sum[0][i][j][g]=sum[0][i-1][j][g]&dp[i][j][g];
                    if(j==0) sum[1][i][j][g]=dp[i][j][g];
                    else sum[1][i][j][g]=sum[1][i][j-1][g]&dp[i][j][g];
                }
            }
        }
        for(int i=1;i<=q;i++){
            t1=read(),t2=read();
            if(dp[t1][t2][0]) puts("Alice");
            else puts("Bob");
        }
    } 
    return 0;
}