#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,cnt,head[100005],nxt[100005],txt[100005],t1,t2,t3,t4,a[100005],c[100005],w1,w2;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void dfs(int k,int f){
    w2=max(w2,t3&c[k]);
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f||txt[i]==t4) continue;
        dfs(txt[i],k);
    }
}
signed main(){
    freopen("reborn.in","r",stdin);
    freopen("reborn.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++) c[i]=read();
    for(int i=1;i<=q;i++){
        t1=read(),t2=read(),t3=read(),t4=read();
        w1=w2=0;
        for(int j=t1;j<=t2;j++) w1=max(w1,c[t4]&a[j]);
        if(t4!=1) dfs(1,0);
        cout<<w1+w2<<"\n";
    }
    return 0;
}