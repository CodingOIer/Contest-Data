#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 1e4;

int n, lg[N];
long double a[N], b[N], val;
long double f[13][N], g[13][N];
int ls[13][N], rs[13][N];

void init(int l, int r) {
    int k = lg[r - l + 1]; For(i, l, r) ls[k][i] = l, rs[k][i] = r;
    if (l != r) { int mid = (l + r) >> 1;init(l, mid), init(mid + 1, r); }
} 
signed main() {
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout); 
    n = read(), val = read(), lg[0] = -1;
    For(i, 1, n) lg[i] = lg[i >> 1] + 1;
    For(i, 1, n - 1) a[i] = b[i + 1] = read();
	init(1, n); For(i, 1, n) f[0][i] = 1, g[0][i] = 1;
    For(i, 1, lg[n]) For(j, 1, n) { int l = ls[i][j], r = rs[i][j];
        if (ls[i - 1][j] == l) l = rs[i - 1][j] + 1; else r = ls[i - 1][j] - 1;
        For(k, l, r) f[i][j] += f[i - 1][k] * (a[j] / (a[j] + a[k]));
        For(k, l, r) g[i][j] += g[i - 1][k] * (b[j] / (b[j] + b[k]));
        f[i][j] *= f[i - 1][j], g[i][j] *= g[i - 1][j];
    }
    For(j, 1, n) { long double ans = 1, lst = 0;
        For(i, 1, lg[n]) { int l = ls[i][j], r = rs[i][j]; lst = ans, ans = 0;
            if (ls[i - 1][j] == l) l = rs[i - 1][j] + 1; else r = ls[i - 1][j] - 1;
            if (r < j) For(k, l, r) ans += f[i - 1][k] * (val / (val + a[k]));
            else For(k, l, r) ans += g[i - 1][k] * (val / (val + b[k]));
            ans *= lst;
        } cout << fixed << setprecision(17) << ans << '\n';
    }
	return 0;
}