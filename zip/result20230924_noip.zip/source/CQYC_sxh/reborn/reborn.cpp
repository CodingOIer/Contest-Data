#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


char qqq;

const int N = 3e5 + 100, unit = 1380;

int n, q, a[N], c[N], cnt;
vector<int> ve[N];
int L[N], R[N], dfn[N], num;

void dfs(int u, int fa) {
    L[u] = ++num, dfn[num] = u;
    for (int v : ve[u]) if (v != fa) dfs(v, u);
    R[u] = num;
}
struct node {
    int l, r, x, p;
}ask[N];

void AND(int *f) {
    For(i, 0, 18) For(j, 0, 524287) 
        if ((j >> i) & 1 ^ 1) f[j] += f[j + (1 << i)];
}

struct FK{
    int f[524288], l, r;
}F[75];
int al[524288], b[N];
int calc(int *f, int x) { int res = 0;
    Rof(i, 18, 0) if ((x >> i) & 1)
        if (f[res | (1 << i)]) res |= (1 << i);
    return res;
}

namespace part1 {
    void solve() {
        For(i, 1, q) { int res1 = 0, res2 = 0;
            For(j, 1, L[ask[i].p] - 1) Max(res1, c[dfn[j]] & ask[i].x);
            For(j, R[ask[i].p] + 1, n) Max(res1, c[dfn[j]] & ask[i].x);
            For(j, ask[i].l, ask[i].r) Max(res2, a[j] & c[ask[i].p]);
            cout << res1 + res2 << '\n';
        }
    }
}

namespace part2 {
    int Ask(int l, int r, int x) {
        if (l > r) return 0; int res = 0;
        For(i, b[l] + 1, b[r] - 1) Max(res, calc(F[i].f, x));
        For(i, l, min(F[b[l]].r, r)) Max(res, c[dfn[i]] & x);
        For(i, max(l, F[b[l]].l), r) Max(res, c[dfn[i]] & x);
        return res;
    }
    void solve() {
        for (int i = 1; i <= n; i += unit) 
            ++cnt, F[cnt].l = i, F[cnt].r = min(n, i + unit - 1);
        For(i, 1, cnt) For(j, F[i].l, F[i].r) ++F[i].f[c[dfn[i]]], b[j] = i;
        For(i, 1, cnt) AND(F[i].f); For(i, 1, n) ++al[a[i]]; AND(al);

        For(i, 1, q) { int res1 = 0, res2 = 0;
            if (ask[i].l == ask[i].r) res2 = a[ask[i].l] & c[ask[i].p];
            else res2 = calc(al, c[ask[i].p]);
            res1 = max(Ask(1, L[ask[i].p] - 1, ask[i].x), Ask(R[ask[i].p] + 1, n, ask[i].x));
            cout << res1 + res2 << '\n';
        }
    }
}
namespace part3 {
    int pre[N], suf[N];
    int Ask(int l, int r, int x) {
        if (l > r) return 0; int res = 0;
        For(i, b[l] + 1, b[r] - 1) Max(res, calc(F[i].f, x));
        For(i, l, min(F[b[l]].r, r)) Max(res, c[dfn[i]] & x);
        For(i, max(l, F[b[l]].l), r) Max(res, c[dfn[i]] & x);
        return res;
    }
    void solve() {
        For(i, 1, n) pre[i] = max(pre[i - 1], c[dfn[i]]);
        Rof(i, n, 1) suf[i] = max(suf[i + 1], c[dfn[i]]);

        for (int i = 1; i <= n; i += unit) 
            ++cnt, F[cnt].l = i, F[cnt].r = min(n, i + unit - 1);
        For(i, 1, cnt) For(j, F[i].l, F[i].r) ++F[i].f[a[j]], b[j] = i;
        For(i, 1, cnt) AND(F[i].f);

        For(i, 1, q) { int res1 = 0, res2 = 0;
            res2 = Ask(ask[i].l, ask[i].r, c[ask[i].p]);
            res1 = max(pre[L[ask[i].p] - 1], suf[R[ask[i].p] + 1]);
            cout << res1 + res2 << '\n';
        }
    }
}

char qqqq;

signed main() {
	freopen("reborn.in", "r", stdin);
	freopen("reborn.out", "w", stdout);
    // cerr << (&qqq - &qqqq) / 1024.0 / 1024.0<<'\n';
    n = read(), q = read();
    For(i, 2, n) {
        int u = read(), v = read();
        ve[u].pb(v), ve[v].pb(u);
    } dfs(1, 0);
    For(i, 1, n) a[i] = read();
    For(i, 1, n) c[i] = read();  
    For(i, 1, q) { ask[i] = {read(), read(), read(), read()}; }
    if (n <= 3000 || q <= 3000) part1::solve(), exit(0);
    bool flag = 1; For(i, 1, q) flag &= (ask[i].l == ask[i].r) || (ask[i].l == 1 && ask[i].r == n);
    if (flag) part2::solve(), exit(0);
    part3::solve();
	return 0;
}