//1s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define db double
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=5010;
int N,x,A[Maxn],stk[Maxn];
db f[40][Maxn];

void Solve(int pos){
    For(i,0,30) For(j,1,N) f[i][j]=0;
    For(i,1,N) f[0][i]=1;
    int M=log2(N);
    For(i,1,M){
        int l1=1<<i;
        for(int j=1;j<=(N/l1);++j){
            int l=(j-1)*l1+1,r=l+l1-1,m=(l+r)>>1;
            For(a,l,m) For(b,m+1,r){
                db p=1.0*A[stk[a]]/(db)(A[stk[a]]+A[stk[b]]);
                f[i][a]+=f[i-1][a]*f[i-1][b]*p;
                p*=1.0*A[stk[b]]/(1.0*A[stk[a]]);
                f[i][b]+=f[i-1][a]*f[i-1][b]*p;
            }
        }
    }
    printf("%.12lf\n",f[M][pos]);
}

int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    N=read(),x=read(),A[N]=x;
    For(i,1,N-1) A[i]=read();
    For(i,1,N){
        For(j,1,i-1) stk[j]=j;
        stk[i]=N;
        For(j,i,N-1) stk[j+1]=j;
        Solve(i);
    }
    return 0;
}