//3s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=3e5+10;
int N,Q,hed[Maxn],cnt,A[Maxn],C[Maxn],Mx1;
struct node{ int nxt,to; }G[Maxn<<1];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void DFS(int x,int f,int s,int v){
    if(x==s) return;
    Mx1=max(Mx1,C[x]&v);
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==f||y==s) continue;
        DFS(y,x,s,v);
    }
}

int main(){
    freopen("reborn.in","r",stdin);
    freopen("reborn.out","w",stdout);
    N=read(),Q=read();
    For(i,1,N-1){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
    }
    For(i,1,N) A[i]=read(); For(i,1,N) C[i]=read();
    while(Q--){
        int l=read(),r=read(),x=read(),p=read(); Mx1=0;
        DFS(1,0,p,x); int Mx2=0;
        For(i,l,r) Mx2=max(Mx2,A[i]&C[p]);
        write(Mx1+Mx2),pc('\n');
    }
    return 0;
}