#include<bits/stdc++.h>
using namespace std;
const int NN=1e6+4;
struct query
{
	pair<int,int>p;
	int id;
	bool operator<(const query&it)const
	{
		return p<it.p;
	}
}Q[NN];
pair<int,int>a[NN];
int ans[NN],tr[NN*4],tag;
bool vis[NN*4][2];
vector<int>nums;
int lowbit(int x)
{
	return x&-x;
}
void add(int u,int v)
{
	while(u<=nums.size())
	{
		tr[u]+=v;
		u+=lowbit(u);
	}
}
int ask(int u)
{
	int res=0;
	while(u)
	{
		res+=tr[u];
		u-=lowbit(u);
	}
	return res;
}
int query(int d)
{
	int l=0,r=1e9;
	while(l<r)
	{
		int mid=l+(r-l)/2;
		if(d+ask(upper_bound(nums.begin(),nums.end(),mid)-nums.begin())-tag<mid+1)
			r=mid;
		else
			l=mid+1;
	}
	return l;
}
int main()
{
	freopen("act.in","r",stdin);
	freopen("act.out","w",stdout);
	int n,q;
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i].first);
		nums.push_back(a[i].first);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i].second);
		nums.push_back(a[i].second);
	}
	for(int i=1;i<=q;i++)
	{
		scanf("%d%d",&Q[i].p.first,&Q[i].p.second);
		nums.push_back(Q[i].p.first),nums.push_back(Q[i].p.second);
		Q[i].id=i;
	}
	sort(nums.begin(),nums.end());
	nums.erase(unique(nums.begin(),nums.end()),nums.end());
	for(int i=1;i<=n;i++)
	{
		a[i].first=lower_bound(nums.begin(),nums.end(),a[i].first)-nums.begin();
		a[i].second=lower_bound(nums.begin(),nums.end(),a[i].second)-nums.begin();
	}
	for(int i=1;i<=q;i++)
	{
		Q[i].p.first=lower_bound(nums.begin(),nums.end(),Q[i].p.first)-nums.begin();
		Q[i].p.second=lower_bound(nums.begin(),nums.end(),Q[i].p.second)-nums.begin();
	}
	sort(a+1,a+1+n);
	sort(Q+1,Q+1+q);
	for(int i=1,j=0;i<=q;i++)
	{
		bool ok=false,flag=true;
		while(j<n&&a[j+1]<=Q[i].p)
		{
			j++;
			int t=query(nums[a[j].first]);
			if(nums[a[j].second]<t&&!vis[a[j].first][0])
			{
				tag++;
				vis[a[j].first][0]=true;
			}
			else if((vis[a[j].first][0]&&nums[a[j].second]==t||nums[a[j].second]>t)&&!vis[a[j].second][1])
			{
				add(a[j].second+1,1);
				vis[a[j].second][1]=true;
			}
			if(a[j]==Q[i].p)
				ok=true;
			if(a[j].second<Q[i].p.second)
				flag=false;
		}
		if(ok||flag&&nums[Q[i].p.second]==query(nums[Q[i].p.first]))
			ans[Q[i].id]=2;
		else
			ans[Q[i].id]=1;
	}
	for(int i=1;i<=q;i++)
		puts(ans[i]==1?"Alice":"Bob");
	return 0;
}
