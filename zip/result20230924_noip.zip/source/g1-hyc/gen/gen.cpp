#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4,P=1e9+7;
int d[NN];
int main()
{
	freopen("gen.in","r",stdin);
	freopen("gen.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		d[u]++,d[v]++;
	}
	map<int,int>cnt;
	for(int i=1;i<=n;i++)
		cnt[d[i]]++;
	int ans=0;
	for(auto it1=cnt.begin();it1!=cnt.end();it1++)
		for(auto it2=it1;it2!=cnt.end();it2++)
		{
			int x=it1->first,y=it2->first;
			ans=(ans+1ll*(it1->second)*(it2->second)%P*(x^y)%P*(x|y)%P*(x&y)%P)%P;
		}
	printf("%d",ans);
	return 0;
}
