#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int pstk[40],plen;
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
inline void write(int x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(plen>=1000000)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
const int Mod=1e9+7;
int f[100000];
int main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	f[1]=f[2]=1;
	for(int i=3;i<=32132;i++)f[i]=(1ll*f[i-1]+1ll*f[i-1])%Mod;
	write(f[32132]);flush();
	return 0;
}


