#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int pstk[40],plen;
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
inline void write(int x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(plen>=1000000)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
const int Maxn=1e5+5;
int n,q;
struct node{int u,v,w,id;}a[Maxn];
int ans[Maxn],D[Maxn];
inline bool cmp(node a,node b){return a.w>b.w;}
int head[Maxn],to[Maxn<<1],nxt[Maxn<<1],w[Maxn<<1],cnt1;
inline void add(int u,int v,int w1){
	to[++cnt1]=v;w[cnt1]=w1;nxt[cnt1]=head[u];head[u]=cnt1;
}
int f[Maxn],dep[Maxn],si[Maxn],son[Maxn],top[Maxn],b[Maxn],dfn[Maxn],cnt2,bb[Maxn];
void dfs(int u,int v){
	f[u]=v;dep[u]=dep[v]+1;
	si[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v)continue;
		bb[y]=w[i];
		dfs(y,u);
		si[u]+=si[y];
		if(si[son[u]]<si[y])son[u]=y;
	}
}
void dfs1(int u,int t){
	top[u]=t;dfn[u]=++cnt2;b[cnt2]=bb[u];
	if(!son[u])return;
	dfs1(son[u],t);
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==f[u]||y==son[u])continue;
		dfs1(y,y);
	}
}
inline int Lca(int u,int v){
	while(top[u]^top[v]){
		if(dep[top[u]]<dep[top[v]])swap(u,v);
		u=f[top[u]];
	}
	return dep[u]<dep[v]?u:v;
}
struct xxx{
	int data,id;
}z[Maxn];
inline bool cmp1(xxx a,xxx b){return a.data>b.data;}
struct Tree{int ls,rs,data,dl,dr,ok;}t[Maxn<<1];
int root,cnt;
inline void update(Tree&a,Tree b,Tree c){
	//swap(b,c);
	a.data=b.data+c.data-D[b.dr]-D[c.dl]+D[b.dr+c.dl];
	a.ok=b.ok&c.ok;
	if(a.ok)a.dl=a.dr=c.dl+b.dl;
	else a.dl=b.dl,a.dr=c.dr;
}
void change(int&x,int l,int r,int d){
	if(!x)x=++cnt;
	if(l==r){t[x].data=D[1];t[x].dl=t[x].dr=t[x].ok=1;return;}
	int mid=l+r>>1;
	if(mid>=d)change(t[x].ls,l,mid,d);
	else change(t[x].rs,mid+1,r,d);
	update(t[x],t[t[x].ls],t[t[x].rs]);
}
Tree query(int x,int l,int r,int L,int R){
	if(L<=l&&r<=R)return t[x];
	int mid=l+r>>1;Tree ans={0,0,0,0,0,0};
	if(mid>=L&&mid<R){
		update(ans,query(t[x].ls,l,mid,L,R),query(t[x].rs,mid+1,r,L,R));
		return ans;
	}
	if(mid>=L)return query(t[x].ls,l,mid,L,R);
	return query(t[x].rs,mid+1,r,L,R);
}
inline int solve(int u,int v){
	int lca=Lca(u,v);
	Tree ans={0,0,0,0,0,1},ans1={0,0,0,0,0,1};
	while(top[u]^top[lca]){
		if(dfn[top[u]]<dfn[u])update(ans,query(root,1,n,dfn[top[u]]+1,dfn[u]),ans);
		u=f[top[u]];
	}
	if(dfn[lca]<dfn[u])update(ans,query(root,1,n,dfn[lca]+1,dfn[u]),ans);
	while(top[v]^top[lca]){
		if(dfn[top[v]]<dfn[v])update(ans1,query(root,1,n,dfn[top[v]]+1,dfn[v]),ans1);
		v=f[top[v]];
	}
	if(dfn[lca]<dfn[v])update(ans1,query(root,1,n,dfn[lca]+1,dfn[v]),ans1);
	update(ans,ans1,ans);
	return ans.data;
}
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read();q=read();
	for(int i=1;i<n;i++)D[i]=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w1=read();
		add(u,v,w1);add(v,u,w1);
	}
	for(int i=1;i<=q;i++){
		int u=read(),v=read(),w1=read();
		a[i]={u,v,w1,i};
	}
	sort(a+1,a+1+q,cmp);
	dfs(1,0);dfs1(1,1);
	for(int i=1;i<=n;i++)z[i]={b[i],i};
	sort(z+1,z+1+n,cmp1);
	int zhi=1;
	for(int i=1;i<=q;i++){
		while(zhi<=n&&a[i].w<=z[zhi].data)change(root,1,n,z[zhi].id),zhi++;
		ans[a[i].id]=solve(a[i].u,a[i].v);
	}
	for(int i=1;i<=q;i++)write(ans[i]),pc('\n');
	flush();
	return 0;
}


