#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int pstk[40],plen;
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
inline void write(ll x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(plen>=1000000)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
const int Maxn=1e6+5;
int T,n,k;
ll t[Maxn],f[Maxn];
inline void add(int x,ll p){x++;for(;x<=k;x+=x&-x)t[x]+=p;}
inline ll query(int x){ll res=0;x++;for(;x;x-=x&-x)res+=t[x];return res;}
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	T=read();
	for(int b=1;b<=T;b++){
		for(int i=0;i<=k;i++)t[i]=f[i]=0;
		n=read();k=read();
		ll ans=0;
		for(int i=1;i<=n;i++){
			int j=1ll*i*i%k;
			if(j<k-1){
				add(j+1,1);add(min(k-1,j+i)+1,-1);
				//printf("%d %d    ",j+1,min(k-1,j+i));
			}j=i-k+j+1;
			if(j>0){
				add(0,j/k);//printf("%d %d(%d)  ",0,k-1,j/k);
				add(0,1);add(j%k,-1);//printf("%d %d ",0,j%k-1);
			}//puts("");
			j=1ll*i*i%k*i%k;
			//for(int a=0;a<k;a++)printf("f[%d]=%d\n",a,query(a));
			ans+=query(j);
		}
		//puts("");
//		for(int i=1;i<=n;i++){
//			int j=1ll*i*i%k;
//			for(int a=1;a<=i;a++)f[(a+j)%k]++;
//			j=1ll*i*i%k*i%k;
//			for(int a=0;a<k;a++)printf("f[%d]=%d\n",a,f[a]);
//			ans+=f[j];
//		}
		pc('C');pc('a');pc('s');pc('e');pc(' ');write(b);pc(':');pc(' ');write(ans);pc('\n');
	}flush();
	return 0;
}


