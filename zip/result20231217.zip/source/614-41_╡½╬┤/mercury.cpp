#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int pstk[40],plen;
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
inline void write(int x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(plen>=1000000)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
const int Maxn=1e5+5;
char s[Maxn];
int a[30];
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	scanf("%s",s+1);
	int len=strlen(s+1);
	for(int i=1;i<=len;i++)a[s[i]-'a']++;
	int ans=0;
	for(int i=0;i<26;i++)ans+=a[i]*a[i];
	write(ans);flush();
	return 0;
}


