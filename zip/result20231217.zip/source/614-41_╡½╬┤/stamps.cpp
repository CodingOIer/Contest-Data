#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int pstk[40],plen;
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
inline void write(int x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(plen>=1000000)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
int n,m,k;
int f[2005][2005],g[2005][2005],gg[2005][2005];
struct node{int l,r;}a[2005];
inline bool cmp(node a,node b){return a.r<b.r;}
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=m;i++)a[i].l=read(),a[i].r=read();
	sort(a+1,a+1+m,cmp);
	memset(gg,-0x7f,sizeof gg);
	for(int j=1;j<=k;j++){
		vector<int>d[2005];
		for(int i=1;i<=m;i++){
			f[i][j]=g[a[i].l-1][j-1]+a[i].r-a[i].l+1;
			f[i][j]=max(f[i][j],gg[a[i].l][j-1]+a[i].r);
			//printf("%d %d %d %d\n",i,j,f[i][j],gg[a[i].l][j-1]);
			d[a[i].r].push_back(f[i][j]);
		}
		for(int i=1;i<=n;i++){
			g[i][j]=g[i-1][j];
			for(int z=0;z<d[i].size();z++)g[i][j]=max(g[i][j],d[i][z]);
		}
		for(int i=n;~i;i--){
			gg[i][j]=gg[i+1][j];
			for(int z=0;z<d[i].size();z++)gg[i][j]=max(gg[i][j],d[i][z]-i);
		}
	}
	int ans=0;
	for(int i=1;i<=k;i++)
		for(int j=1;j<=m;j++)ans=max(ans,f[j][i]);
	write(ans);flush();
	return 0;
}


