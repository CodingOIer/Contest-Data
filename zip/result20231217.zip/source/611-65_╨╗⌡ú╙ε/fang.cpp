#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,p,q,sum,sum2,ans;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>n;
	for(int x=1;x<=n;x++)
	{
		cin>>p>>q;
		for(int c=1;c<=p;c++)
		{
			for(int b=1;b<=c;b++)
			{
				for(int a=1;a<=b;a++)
				{
					sum=(b*b+a)%q,sum2=(c*c*c)%q;
					if(sum==sum2)
					{
						ans++;
					}
				}
			}
		}
		cout<<"Case "<<x<<": "<<ans<<endl;
		ans=0;
	}
	return 0;
}
