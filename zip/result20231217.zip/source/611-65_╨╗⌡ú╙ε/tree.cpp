#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,c[100000],p,q,z,t,sum=0;
struct node{
	ll u,v,h;
}bian[100000];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=a-1;i++)
	{
		cin>>c[i];
	}
	for(int i=1;i<=a-1;i++)
	{
		cin>>bian[i].u>>bian[i].v>>bian[i].h;
	}
	for(int i=1;i<=b;i++)
	{
		cin>>p>>q>>z;
		for(int j=p;j<=q-1;j++)
		{
			if(bian[j].h>=z)
			{
				t++;
			}
			else
			{
				sum+=c[t],t=0;
			}
		}
		sum+=c[t],t=0;
		cout<<sum<<endl;
		sum=0;
	}
	return 0;
}
