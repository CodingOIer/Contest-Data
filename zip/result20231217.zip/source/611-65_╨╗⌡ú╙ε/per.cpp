#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll mod=1000000007;
ll t,a,sum=0,ans=0;
bool bj[10000001];
inline void dfs(ll n,ll t)
{
	if(t==a+1)
	{
		sum++,sum%=mod;
		return;
	}
	for(int i=max(n-2,1ll);i<=min(n+2,a);i++)
	{
		if(!bj[i])
		{
			bj[i]=1;
			dfs(i,t+1);
			bj[i]=0;
		}
	}
	return;
}
int main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>t;
	bj[1]=1;
	for(int g=1;g<=t;g++)
	{
		cin>>a;
		dfs(1,2);
		if(g==1)
		{
			ans=sum;
		}
		else
		{
			ans^=sum,ans%=mod;
		}
		for(int i=2;i<=a;i++)
		{
			bj[i]=0;
		}
		sum=0;
	}
	cout<<ans;
	return 0;
}
