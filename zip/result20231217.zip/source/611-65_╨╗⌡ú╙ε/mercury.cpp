#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll a[31],sum;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)
	{
		a[s[i]-'a'+1]++;
	}
	for(int i=1;i<=26;i++)
	{
		sum+=a[i]*a[i];
	}
	cout<<sum;
	return 0;
}
