#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,c,x[2001],y[2001],mx=-114514;
bool bj[2001];
int bj2[2001];
inline void dfs(ll s,ll t)
{
	if(t==c)
	{
		mx=max(mx,s);
		return;
	}
	ll sum=0;
	for(int i=1;i<=b;i++)
	{
		if(!bj[i])
		{
			bj[i]=1;
			for(int j=x[i];j<=y[i];j++)
			{
				if(!bj2[j])
				{
					sum++,bj2[j]=i;
				}
			}
			dfs(s+sum,t+1);
			bj[i]=0,sum=0;
			for(int j=x[i];j<=y[i];j++)
			{
				if(bj2[j]==i)
				{
					bj2[j]=0;
				}
			}
		}
	}
	return;
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>a>>b>>c;
	for(int i=1;i<=b;i++)
	{
		cin>>x[i]>>y[i];
	}
	dfs(0,0);
	cout<<mx;
	return 0;
}
