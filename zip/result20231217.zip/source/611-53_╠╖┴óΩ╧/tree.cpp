#include <bits/stdc++.h>
#define ll long long
const int N = 1e5 + 5;
using namespace std;
struct node{
	int fa, bq, low;
	vector<int> son;
}vt[N];
int gen;
int f[N];
inline void down(int x) {
	for(int i = 0; i<vt[x].son.size(); i++) {
		vt[vt[x].son[i]].low = vt[x].low + 1;
		down(vt[x].son[i]);
	}
}
inline int Ans(string s) {
	int len = s.size(), cnt = 0, sum = 0;
	for(int i = 0; i < len; i++) {
		if(s[i] == '1') cnt++;
		else sum += f[cnt], cnt = 0;
	}
	sum += f[cnt];
	return sum;
}
inline int LCA(int x, int y, int w) {
	string xx = "", yy = "", xy = "";
	if(vt[x].low > vt[y].low) {
		while(vt[x].low > vt[y].low) {
			if(vt[x].bq >= w) xx = xx + "1";
			else xx = xx + "0";
			x = vt[x].fa;
		}
	}
	else {
		while(vt[y].low > vt[x].low) {
			if(vt[y].bq >= w) yy = "1" + yy;
			else yy = "0" + yy;
			y = vt[y].fa;
		}
	}
	while(x != y) {
		if(vt[x].bq >= w) xx = xx + "1";
		else xx = xx + "0";
		if(vt[y].bq >= w)  yy = "1" + yy;
		else yy = "0" + yy;
		x = vt[x].fa; y = vt[y].fa;
	}
	xy = xx + yy;
	return Ans(xy);
}
inline void solve() {
	int u, v, w; cin >> u >> v >> w; 
	cout << LCA(u, v, w) << "\n";
}
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	int n, Q; cin >> n >> Q; 
	for(int i = 1; i < n; i++) cin >> f[i], vt[i].low = -1;
	vt[n].low = -1;
	for(int i = 1, u, v, w; i < n; i++) {
		cin >> u >> v >> w;
		vt[v].fa = u; vt[v].bq = w; vt[u].son.push_back(v);
	}
	for(int i = 1; i <= n; i++)
		if(vt[i].fa == 0) {
			vt[i].low = 1; down(i); break;
		}
	while(Q--) solve();
	return 0; 
}
//���춼��Щʲô B �⣬���������
//-------------------------------
//_____________________________
//     ___   ___   ___   ___ | \
//    |__|  |__|  |__|  |__| |  \ 
//                           |   \ 
//                           |    \
//_________________________________\ 
//___________________________________

