#include <bits/stdc++.h>
const int mod = 1e9 + 7;
using namespace std;
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("per.in", "r", stdin);
	freopen("per.out", "w", stdout);
	srand(time(0));
	cout<<rand() % mod;
	return 0; 
}
//��Ŀ����������Ů� 
