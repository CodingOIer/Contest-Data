#include <bits/stdc++.h>
#define int long long
const int N = 2005;
using namespace std;
int n, k, ans;
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("fang.in", "r", stdin);
	freopen("fang.out", "w", stdout);
	int T; cin >> T;
	for(int tt = 1, bb, cc, aa, kk; tt <= T; tt++) {
		cin >> n >> k; ans = 0;
		for(int a = 1; a <= n; a++)
			for(int b = a; b <= n; b++)
				for(int c = b; c <= n; c++)
					if((a % k + ((b % k) * (b % k))) % k == ((c % k) * (c % k) * (c % k)) % k) ans++;
		cout << "Case " << tt << ": " << ans << "\n";
	}
	return 0; 
}
