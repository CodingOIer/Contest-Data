#include <bits/stdc++.h>
#define ll long long
using namespace std;
string s; 
int len;
int t[30];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout);
	cin >> s; len = s.size(); 
	for(int i = 0; i < len; i++) t[s[i]-'a']++;
	ll ans=0;
	for(int i = 0; i <= 26; i++) ans += (1ll * t[i] * t[i]);
	cout << ans;
	return 0; 
}
