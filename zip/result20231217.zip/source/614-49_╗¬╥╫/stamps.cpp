#include<bits/stdc++.h>
using namespace std;
int n,m,k,mx,nu,ans;
int l[2005],r[2005];
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&l[i],&r[i]);
		if(r[i]-l[i]>nu) mx=i,nu=r[i]-l[i];
	}
	while(k--)
	{
		ans+=r[mx]-l[mx]+1;
		int lt=l[mx],rt=r[mx];
		nu=0;
		for(int i=1;i<=m;i++)
		{
			if(lt<=l[i] && l[i]<=rt && r[i]>=rt) l[i]=rt+1;
			if(l[i]<=lt && lt<=r[i] && r[i]<=rt) r[i]=lt-1;
			if(l[i]>=lt && r[i]<=rt) l[i]=r[i]=0;
			if(r[i]-l[i]>nu) nu=r[i]-l[i],mx=i;
		}
	}
	cout<<ans;
	return 0;
}
