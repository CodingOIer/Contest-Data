#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int t;
	cin>>t;
	for(int i=1;i<=t;i++)
		printf("Case %d:1\n",i);
	return 0;
}
