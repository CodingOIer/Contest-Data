#include<bits/stdc++.h>
using namespace std;
long long ans,c[105];
string s;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	int n=s.length();
	for(int i=0;i<n;i++)
		c[s[i]-'a'+1]++;
	for(int i=1;i<=26;i++)
		ans+=c[i]*c[i];
	cout<<ans;
	return 0;
}
