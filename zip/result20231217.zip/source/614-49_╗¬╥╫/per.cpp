#include<bits/stdc++.h>
#define int long long
#define mod 1000000007
using namespace std;
int t,n,ans,an;
bool vis[100005];
int a[25];
void dfs(int k,int x)
{
	if(k==n)
	{
		an++;
		an%=mod;
		return;
	}
	for(int i=max(1ll,x-2);i<=min(n,x+2);i++)
		if(!vis[i]) vis[i]=1,dfs(k+1,i),vis[i]=0;
}
signed main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout); 
	cin>>t;
	vis[1]=1;
	while(t--)
	{
		scanf("%lld",&n);
		if(a[n])
		{
			ans^=a[n];
			continue;
		}
		an=0;
		dfs(1,1);
		a[n]=an;
		ans^=an;
	}
	cout<<ans;
	return 0;
}
