#include <bits/stdc++.h>
using namespace std;
string s;
int ans, m[200];
int main() {
	ios :: sync_with_stdio(false);
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout);
	getline(cin, s);
	if (s . length() <= 2000) {
		for (int i = 0; i < s . length(); i ++)
			for (int j = 0; j < s . length(); j ++)
				if (s[i] == s[j]) ans ++;
	} else {
		for (int i = 0; i < s . length(); i ++) m[s[i]] ++;
		for (int i = 0; i < s . length(); i ++)
			if (m[s[i]] >= 2) ans += m[s[i]];
			else ans ++;
	}
	cout << ans << endl;
	return 0;
}
