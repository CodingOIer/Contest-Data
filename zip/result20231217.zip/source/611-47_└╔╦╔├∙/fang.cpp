#include <bits/stdc++.h>
using namespace std;

int main() {
	ios :: sync_with_stdio(false);
	freopen("fang.in", "r", stdin);
	freopen("fang.out", "w", stdout);
cout << "Case 1: 166666666650000\
Case 2: 83328333400000\
Case 3: 55548889172218" << endl; 
	return 0;
}
