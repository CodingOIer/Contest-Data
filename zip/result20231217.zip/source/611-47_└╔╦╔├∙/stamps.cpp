#include <bits/stdc++.h>
using namespace std;
int n, m, k; 
struct node {
	int l, r;
}s[2010];
void dfs(int dep) {
	if ()
}
int main() {
	ios :: sync_with_stdio(false);
	freopen("stamps.in", "r", stdin);
	freopen("stamps.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= m; i ++) cin >> s[i] . l >> s[i] . r;
	dfs(1);
	return 0;
}
