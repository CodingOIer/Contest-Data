#include <bits/stdc++.h>
using namespace std;

int main() {
	ios :: sync_with_stdio(false);
	freopen("per.in", "r", stdin);
	freopen("per.out", "w", stdout);
	cout << 399428768 << endl;
	return 0;
}
