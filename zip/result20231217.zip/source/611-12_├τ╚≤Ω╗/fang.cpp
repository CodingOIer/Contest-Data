#include<bits/stdc++.h>
using namespace std;
long long b[1000005],c[1000005],cc[1000005];
int xs(int bc,int cs){
	if(bc%cs==0)
		return bc/cs;
	return bc/cs+1;
}
int main(){
	int t=0;
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%d",&t);
	for(long long i=0,n=0,k=0,ans=0;i<t;i++){
		scanf("%d%d",&n,&k);
		ans=0;
		for(long long j=0;j<k;j++)
			b[j]=0;
		for(long long j=0;j<k;j++)
			c[j]=0;
		for(long long j=1;j<=n;j++)
			b[j*j%k]++;
		for(long long j=1;j<=n;j++)
			c[j*j*j%k]++;
		for(long long j=0;j<k;j++)
			cc[j]=0;
		for(int j=0;j<k;j++){
			for(int l=0;l<k;l++)
				cc[max(j,l)-min(j,l)]+=b[j]*c[l];
		}
		for(int j=0;j<k;j++){
			if(j==0)
				cc[j]*=n/k;
			else if(n%k>=j)
				cc[j]*=xs(n,k);
			else
				cc[j]*=xs(n,k)-1;
			ans+=cc[j];
		}
		printf("Case %d: %d\n",i+1,ans);
	}
	return 0;
}//miaorunhao�ϵ�̫ΰ����
//���֣�0
