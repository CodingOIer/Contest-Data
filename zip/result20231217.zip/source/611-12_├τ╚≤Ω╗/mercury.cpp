#include<bits/stdc++.h>
using namespace std;
string s;
long long zf[26],ans=0;
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)
		zf[s[i]-'a']++;
	for(int i=0;i<26;i++)
		ans+=zf[i]*zf[i];
	cout<<ans;
	return 0;
}//miaorunhao�ϵ�̫ΰ����
//���֣�100 
