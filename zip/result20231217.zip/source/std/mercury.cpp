#include<bits/stdc++.h>//by Lisdery
using namespace std;
string s;
int n;
long long num[26];
long long ans;
int main(){
    freopen("mercury.in","r",stdin);
    freopen("mercury.out","w",stdout);
    cin>>s;
    n=s.size();
    for(int i=0;i<n;i++){
        num[s[i]-'a']++;
    }
    for(int i=0;i<26;i++){
        ans=ans+num[i]*num[i];
    }
    printf("%lld\n",ans);
}
