#include <bits/stdc++.h>
using namespace std;
inline int rd(int f = 1, int x = 0, char ch = ' ')
{
    while(!isdigit(ch = getchar())) if(ch == '-') f = -1;
    while(isdigit(ch)) x = x*10+ch-'0', ch = getchar();
    return f*x;
}
typedef long long i64;
const int P = 1e9+7, M = 32, N = 1e8+5;
int T, n, f[N], A[M][3][3], g[3], h[3], ans; void fix(int &x) { x<P?0:x-=P; }
int main()
{
    freopen("per.in", "r", stdin), freopen("per.out", "w", stdout);
    A[0][0][1] = A[0][1][2] = A[0][2][0] = A[0][2][2] = 1;
    for(int p = 1; p < M; ++p) for(int i = 0; i < 3; ++i) for(int j = 0; j < 3; ++j) for(int k = 0; k < 3; ++k)
        A[p][i][j] = (A[p][i][j]+(i64)A[p-1][i][k]*A[p-1][k][j])%P;
    for( T = rd(), assert(T <= 2e6); T--; )
    {
        n = rd(), g[0] = 2, g[1] = 2, g[2] = 3, --n, assert(n <= 1e9);
        for(int i = 0; n; n >>= 1, ++i) if(n&1)
        {
            for(int j = 0; j < 3; ++j) h[j] = g[j], g[j] = 0;
            for(int j = 0; j < 3; ++j) for(int k = 0; k < 3; ++k)
                g[j] = (g[j]+(i64)A[i][j][k]*h[k])%P;
        }
        fix(g[0] += P-1), ans ^= g[0];
    }
    printf("%d\n", ans);
    return 0;
}
/*
3
4
32132
321313121
*/