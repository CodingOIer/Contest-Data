#include <cstdio>
#include <vector>
#include <algorithm>
#define pb push_back
using std::vector;
const int N=100005;

int n, q;
int x[N], y[N], w[N], id[N], f[N];
struct data{
	int len, l, r, sum;
	data operator +(const data &a)
	{
		return {len+a.len, (l==len?l+a.l:l), (a.r==a.len?a.r+r:a.r), sum+a.sum+((r!=len&&a.l!=a.len)?f[r+a.l]:0)};
	}
};
namespace SGT{
	#define ls (u<<1)
	#define rs (u<<1|1)
	data sum[N<<2];
	inline void upt(int u) { sum[u]=sum[ls]+sum[rs]; }
	void build(int u, int l, int r)
	{
		if(l==r) { sum[u]={1, 1, 1, 0}; return; }
		int mid=(l+r)>>1;
		build(ls, l, mid), build(rs, mid+1, r);
		upt(u);
	}
	void add(int u, int l, int r, int p)
	{
		if(l==r) { sum[u]={1, 0, 0, 0}; return; }
		int mid=(l+r)>>1;
		if(p<=mid) add(ls, l, mid, p);
		else add(rs, mid+1, r, p);
		upt(u);
	}
	data ask(int u, int l, int r, int l1, int r1)
	{
		if(l1<=l&&r<=r1) return sum[u];
		int mid=(l+r)>>1;
		data ret={0, 0, 0, 0};
		if(l1<=mid) ret=ret+ask(ls, l, mid, l1, r1);
		if(r1>mid) ret=ret+ask(rs, mid+1, r, l1, r1);
		return ret;
	}
}
using namespace SGT;
int son[N], sz[N], up[N], in[N], pa[N], dep[N], cnt;
vector<int> e[N];
void dfs(int u, int fa)
{
	pa[u]=fa;
	dep[u]=dep[fa]+1;
	sz[u]=1;
	for(int v:e[u]) if(v!=fa)
	{
		dfs(v, u);
		sz[u]+=sz[v];
		if(sz[v]>sz[son[u]]) son[u]=v;
	}
}
void dfs1(int u, int fa, int top)
{
	up[u]=top;
	in[u]=++cnt;
	if(son[u]) dfs1(son[u], u, top);
	for(int v:e[u]) if(v!=fa&&v!=son[u]) dfs1(v, u, v);
}
int is[N];
int ask(int x, int y)
{
	data sx={0, 0, 0, 0}, sy=sx;
	while(up[x]!=up[y])
	{
		if(dep[up[x]]<dep[up[y]]) std::swap(x, y), std::swap(sx, sy);
		int p=up[x];
		sx=ask(1, 1, n, in[p], in[x])+sx;
		x=pa[p];
	}
	if(dep[x]<dep[y]) std::swap(x, y), std::swap(sx, sy);
	if(x!=y) sx=ask(1, 1, n, in[y]+1, in[x])+sx;
	std::swap(sx.l, sx.r);
	sx=sx+sy;
	int ret=(sx.l==sx.len?f[sx.l]:sx.sum+f[sx.l]+f[sx.r]);
	return ret;
}
int qr[N][3], qid[N], rans[N];
int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d%d", &n, &q);
	for(int i=1; i<n; ++i) scanf("%d", f+i);
	for(int i=1, x, y; i<n; ++i)
	{
		scanf("%d%d%d", &x, &y, w+i);
		e[x].pb(y), e[y].pb(x);
		::x[i]=x, ::y[i]=y;
		id[i]=i;
	}
	std::sort(id+1, id+n, [] (int a, int b) { return w[a]<w[b]; } );
	for(int i=1; i<=q; ++i) scanf("%d%d%d", qr[i], qr[i]+1, qr[i]+2), qid[i]=i;
	std::sort(qid+1, qid+q+1, [] (int a, int b) { return qr[a][2]<qr[b][2]; } );
	dfs(1, 0);
	dfs1(1, 0, 1);
	build(1, 1, n);
	add(1, 1, n, 1);
	for(int i=1, t=1; i<=q; ++i)
	{
		int x=qid[i], u=qr[x][0], v=qr[x][1], cw=qr[x][2];
		while(t<n&&w[id[t]]<cw)
		{
			int a=::x[id[t]], b=::y[id[t]];
			add(1, 1, n, in[(a==pa[b]?b:a)]);
			is[(a==pa[b]?b:a)]=1;
			// printf("add %d\n", in[(a==pa[b]?b:a)]);
			++t;
		}
		rans[x]=ask(u, v);
	}
	for(int i=1; i<=q; ++i) printf("%d\n", rans[i]);
	return 0;
}