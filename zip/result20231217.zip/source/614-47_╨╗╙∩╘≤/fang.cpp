#include <bits/stdc++.h>
using namespace std;

int js(int n, int k)
{
    int cnt = 0;
    for(int a = 1; a <= n; a++)
        for(int b = a; b <= n; b++)
            for(int c = b; c <= n; c++)
                if((a + static_cast<int>(pow(b, 2))) % k == static_cast<int>(pow(c, 3)) % k)
                    cnt++;
    return cnt;
}

int main()
{
	freopen("fang.in", "r", stdin);
	freopen("fang.out", "w", stdout); 
    int t;
    cin >> t;
    for(int i = 1; i <= t; i++)
	{
        int n, k;
        cin >> n >> k;
        int res = js(n, k);
        cout << "Case " << i << ": " << res << endl;
    }
    return 0;
}

