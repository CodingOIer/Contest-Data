#include <bits/stdc++.h>
using namespace std;
int n, m, k; 
struct T {
	int l, r, c;
};
bool cmp(T a, T b)
{
	return a.c > b.c;
}
int main()
{
//	freopen("stamps.in", "r", stdin);
//	freopen("stamps.out", "w", stdout); 
	scanf("%d %d %d", &n, &m, &k);
	vector<T> q(m);
	for(int i = 0; i < m; i++)
	{
		scanf("%d %d", &q[i].l, &q[i].r);
		q[i].c = q[i].r - q[i].l;
	}
	sort(q.begin(), q.end(), cmp);
	int sum = 0;
	map<int, int> c; 
	for(int i = 0; i < k; i++)
	{
		if(c[q[i].l] == 1 && c[q[i].r] == 1)
		{
			k--;
			continue;
		}
		for(int j = q[i].l; j <= q[i].r; j++)
		{
			if(c[j] == 1) continue;
			c[j] = 1;
			sum++;
		}
	}
	printf("%d\n", sum);
	return 0;
}
