#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout); 
	string a;
	cin >> a;
	map<char, int> cnt;
	for(int i = 0; i < a.length(); i++)
	{
		cnt[a[i]]++;
	}
	int sum = 0;
	for(auto it : cnt)
	{
		sum += (it.second * it.second);
	}
	cout << sum;
	return 0;
}
