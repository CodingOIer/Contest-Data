#include<bits/stdc++.h>
using namespace std;
string a;
int ans;
int main(){
    freopen("mercury.in","r",stdin);
    freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>a;
	int len=a.size();
	for(int i=0;i<len;i++)
		for(int j=i+1;j<len;j++)
			if(a[i]==a[j])
				ans+=2;
	cout<<ans+len;
	return 0;
}
