#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll dp[4],n,m,k,a[2005],b[2005],ans;
int main(){
    freopen("stamps.in","r",stdin);
    freopen("stamps.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k;
	ll sum=0;
	for(int i=1;i<=m;i++)
		cin>>a[i]>>b[i];
	for(int i=1;i<m;i++){
		dp[1]=b[i]-a[i]+1;
		dp[2]=a[i];
		dp[3]=b[i];
		ll x=dp[2],y=dp[3];
		for(int j=2;j<=k;j++)
			for(int l=i+1;l<=m;l++){
				int cnt=max(y,b[l])-min(x,a[l])+1;
				if(cnt>dp[1]){
					dp[1]=cnt;
					dp[2]=min(x,a[l]);
					dp[3]=max(y,b[l]);
				}
			}
		if(!(i-1))
			ans=dp[1];
		else
			ans=max(ans,dp[1]);
	}
	cout<<ans;
	return 0;
}
