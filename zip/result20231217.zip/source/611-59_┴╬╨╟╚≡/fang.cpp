#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll t,n,mod,ans,a[3];
inline void qpl(ll n,ll mod,ll j){
	if(j==2){
		ll sum=a[1]+(a[2]*a[2])%mod;
		cout<<a[1]<<"\t"<<a[2]<<endl; 
		for(ll i=a[2];i<=n;i++){
			ll x=i*i*i;
			if(x==sum)
				ans++,printf("  ( %lld + %lld ) mod %lld = %lld mod %lld\n= %lld = %lld\n",a[1],a[2]*a[2],mod,i*i*i,mod,sum,x);
			if(x==sum||x>sum)
				break;
		}
		return; 
	}
	for(int i=a[j];i<=n;i++){
		a[j+1]=i;
		qpl(n,mod,j+1);
	}
}
int main(){
//    freopen("fang.in","r",stdin);
//    freopen("fang.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>mod;
		ans=0;
		a[0]=1;
		qpl(n,mod,0);
		cout<<"Case "<<i<<": "<<ans<<endl;
	}
	return 0;
}
