#include<bits/stdc++.h>
#define ll long long
#define mod 1000000000+7
using namespace std;
ll a[100000005],n,t,ans;
int main(){
    freopen("per.in","r",stdin);
    freopen("per.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	a[0]=1;
	a[1]=1;
	a[2]=1;
	a[3]=2;
	a[4]=4;
	a[5]=6;
	a[6]=9;
	for(int i=7;i<=100000000;i++){
		a[i]=a[i-1]%mod+a[i-2]%mod+a[i-5]%mod;
		a[i]%=mod;
	}
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>t;
		ans^=a[t];
	}
	cout<<ans;
	return 0;
}
