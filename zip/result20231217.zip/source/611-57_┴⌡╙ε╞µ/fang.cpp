#include<bits/stdc++.h>
using namespace std;
void solve(long long t) {
	long long n,p;
	cin>>n>>p;     
	long long ans=0;                                                                                    
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=i;j++) {
			long long c=p-(p*p*p*p+j*j-i*i*i)%p;
			c%=p;
			ans=ans+max(0ll,(j-c)/p+(j>=c&&c>=1));
		}
	}
	cout<<"Case "<<t<<": "<<ans<<'\n';
}
int main() {
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	long long t,f;
	cin>>t;
	f=t;
	while(t--) {
		solve(f-t);
	}
	return 0;
}
/*
̫թƭ�� 
*/ 
