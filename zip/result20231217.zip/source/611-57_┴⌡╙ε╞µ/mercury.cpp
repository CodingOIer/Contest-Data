#include<bits/stdc++.h>
using namespace std;
long long a[100];
char c[1000001];
int main() {
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>c;
	for(int i=0;i<strlen(c);i++) a[c[i]-'a']++;
	long long ans=0;
	for(int i='a'-'a';i<='z'-'a';i++) ans+=(a[i]*a[i]);
	cout<<ans;
	return 0;
} 
