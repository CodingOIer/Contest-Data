#include<bits/stdc++.h>
using namespace std;
long long n,m,l1;
long long adds[100001];
bool vis[100001];
long long l[1000001],r[1000001];
int main() {
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&l1);
	for(int i=1;i<=m;i++) {
		scanf("%lld%lld",&l[i],&r[i]);
		for(int j=l[i];j<=r[i];j++)
			adds[j]++;
	}
	l1=max(0ll,m-l1);
	for(int i=1;i<=l1;i++) {
		long long mn=1000000001,ids;
		for(int j=1;j<=m;j++) {
			if(!vis[j]) {
				long long an=0;
				for(int k=l[j];k<=r[j];k++) {
					an+=(adds[k]==1);
				}
				if(an<mn)
					mn=an,ids=j;
			}
		}
		vis[ids]=1;
		for(int k=l[ids];k<=r[ids];k++) 
			adds[k]--;
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
		ans+=(bool)(adds[i]);
	printf("%lld",ans);
	return 0;
}
