#include<bits/stdc++.h>
using namespace std;
int f[10000001]; 
int main() {
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	f[0]=1;
	f[1]=1;
	f[2]=1;
	f[3]=2;
	f[4]=4;
	f[5]=6;
	f[6]=9;
	for(int i=7;i<=10000000;i++) {
		f[i]=(long long)((long long)f[i-1]%1000000007+(long long)f[i-2]%1000000007)%1000000007-(long long)f[i-5]%1000000007;
		f[i]=((long long)f[i]+1000000007+1000000007)%1000000007;
	}       
	long long t;
	cin>>t;
	long long ans=0;
	for(int i=1;i<=t;i++) {
		long long j;
		cin>>j;
		ans=ans^f[j];
	}
	cout<<ans;
	return 0;
}
