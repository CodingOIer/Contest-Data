#include<bits/stdc++.h>
using namespace std;
struct node
{
	int l,r;
};
int n,m,k,ans=0;
node a[1000005];
int f[1000005];
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for (int i=1;i<=m;i++)
		cin>>a[i].l>>a[i].r;
	int x=0,y=0;
	for (int i=1;i<=k;i++)
	{
		int maxx=-1e9,maxn;
		for (int i=1;i<=n;i++)
		{
			if (f[i]==1)
				continue;
			int t;
			if (x==0 && y==0)
				t=a[i].r-a[i].l+1;
			else
				t=max(0,a[i].r-y)+max(0,x-a[i].l);
			if (t>maxx)
			{
				maxx=t;
				maxn=i;
			}
		}
		f[maxn]=1;
		ans+=maxx;
		x=min(x,a[maxn].l);
		y=max(y,a[maxn].r);
	}
	cout<<ans;
	return 0;
}
