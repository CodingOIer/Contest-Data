#include<bits/stdc++.h>
using namespace std;
string s;
long long a[1000005];
long long ans=0;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	int l=s.length();
	for (int i=0;i<l;i++)
		a[s[i]]++;
	for (int i='a';i<='z';i++)
		ans+=a[i]*a[i];
	cout<<ans;
	return 0;
}
