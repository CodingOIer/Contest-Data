#include<bits/stdc++.h>
using namespace std;
int n,q,flag=0,ans=0;
int g[1005][1005];
int f[1000005];
int a[1000005];
int s[1000005];
int l[1000005];
int b[1000005];
int top=0;
void dfs(int x,int y,int z)
{
	f[x]=1;
	if (x==y)
	{
		flag=1;
		int t=0;
		memset(b,0,sizeof(b));
		memset(l,0,sizeof(l));
		for (int i=0;i<top;i++)
			if (s[i]>=z)
				l[i]=1;
		if (l[0]==1)
		{
			t=1;
			b[1]=1;
		}
		for (int i=1;i<top;i++)
		{
			if (l[i-1]==1 && l[i]==1)
				b[t]++;
			else if (l[i-1]==0 && l[i]==1)
				b[++t]=1;
		}
		ans=0;
		for (int i=1;i<=t;i++)
			ans+=a[b[i]];
		return;
	}
	for (int i=1;i<=n;i++)
	{
		if (g[x][i]!=0)
		{
			if (f[i]==0)
			{
				s[top++]=g[x][i];
				dfs(i,y,z);
				if (flag==1)
					return;
				top--;
			}
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n>>q;
	for (int i=1;i<n;i++)
		cin>>a[i];
	for (int i=1;i<n;i++)
	{
		int x,y,z;
		cin>>x>>y>>z;
		g[x][y]=z;
		g[y][x]=z;
	}
	for (int i=1;i<=q;i++)
	{
		memset(f,0,sizeof(f));
		int x,y,z;
		cin>>x>>y>>z;
		top=0;
		flag=0;
		dfs(x,y,z);
		cout<<ans<<'\n';
	}
	return 0;
}
