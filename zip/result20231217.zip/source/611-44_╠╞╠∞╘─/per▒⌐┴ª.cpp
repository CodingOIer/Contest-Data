#include<bits/stdc++.h>
using namespace std;
int t,tot=0;
int mod=1e9+7;
int a[1000005];
int f[1000005];
int b[25]={0,1,1,2,4,6,9,14,21,31,46,68,100,147,216,317,465,682,1000,1466,2149,3129};
int ans=0;
void dfs(int x,int k)
{
	if (x==k+1)
	{
		int flag=0;
		for (int i=2;i<=k;i++)
		{
			if (abs(a[i]-a[i-1])>2)
			{
				flag=1;
				break;
			}
		}
		if (flag==0)
		{
			ans++;
			ans%=mod;
		}
	}
	for (int i=max(2,a[x-1]-2);i<=min(k,a[x-1]+2);i++)
	{
		if (f[i]==0)
		{
			f[i]=1;
			a[x]=i;
			dfs(x+1,k);
			f[i]=0;
		}
	}
}
int main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>t;
	while (t--)
	{
		int n;
		ans=0;
		cin>>n;
		if (n<=20)
			ans=b[n];
		else
		{
			a[1]=1;
			dfs(2,n);
		}
		tot=tot^ans;
	}
	cout<<tot;
	return 0;
}

