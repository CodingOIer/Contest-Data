#include<bits/stdc++.h>
using namespace std;
long long mod=1e9+7,ans=0;
long long n,t,maxx=-1;
long long a[1000005];
long long b[1000005];
long long q[1000005];
int main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>t;
	for (int i=1;i<=t;i++)
	{
		cin>>q[i];
		if (q[i]>maxx)
			maxx=q[i];
	}
	b[1]=0;
	b[2]=1;
	b[3]=2;
	b[4]=2;
	b[5]=3;
	for (long long i=6;i<=maxx;i++)
	{
		b[i]=b[i-2]%mod+b[i-3]%mod+b[i-4]%mod;
		b[i]%=mod;
	}
	a[1]=1;
	for (long long i=2;i<=maxx;i++)
	{
		a[i]=a[i-1]%mod+b[i-1]%mod;
		a[i]%=mod;
	}
	for (int i=1;i<=t;i++)
		ans=ans^a[q[i]];
	cout<<ans;
	return 0;
}

