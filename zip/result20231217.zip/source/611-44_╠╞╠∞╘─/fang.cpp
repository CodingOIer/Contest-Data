#include<bits/stdc++.h>
using namespace std;
int t;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int n,k,ans=0;
	cin>>t;
	for (int p=1;p<=t;p++)
	{
		ans=0;
		cin>>n>>k;
		for (int a=1;a<=n;a++)
			for (int b=a;b<=n;b++)
				for (int c=b;c<=n;c++)
					if ((a%k+b%k*b%k)%k==c%k*c%k*c%k)
						ans++;
		cout<<"Case "<<p<<": "<<ans<<'\n';
	}
	return 0;
}
