#include<bits/stdc++.h>
using namespace std;
long long t,n,k;
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>k;
		long long ans=0;
		for(int c=1;c<=n;c++){
			for(int b=1;b<=c;b++){
				for(int a=1;a<=b;a++){
					if((a+b*b)%k==c*c*c%k){
						ans++;
					}
				}
			}
		}
		cout<<"Case 1:"<<ans<<endl;
	}
	return 0;
}
