#include<bits/stdc++.h>
using namespace std;
int n,m,k,cf[2005],ans;
bool v[2005];
struct stam{
	int l,r;
}a[2005];
void dfs(int p,int z){
	v[p]=1;
	cf[a[p].l]++;	
	cf[a[p].r+1]--;	
	if(z==0){
		int sum=0,f=0;
		for(int i=1;i<=n;i++){
			f+=cf[i];
			if(f) sum++;
		}
		ans=max(sum,ans);
	}else{
		for(int i=1;i<=m;i++){
			if(!v[i]) dfs(i,z-1);
		}
	}
	v[p]=0;
	cf[a[p].l]--;	
	cf[a[p].r+1]++;
}
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	a[0].r=-1;
	for(int i=1;i<=m;i++){
		cin>>a[i].l>>a[i].r;
	}
	dfs(0,k);
	cout<<ans;
	return 0;
}

