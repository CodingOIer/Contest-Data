#include<bits/stdc++.h>
using namespace std;
string s;
long long a[29];
long long ans;
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	int len=s.length();
	for(int i=0;i<len;i++){
		a[s[i]-'a']++;
	}
	for(int i=0;i<26;i++){
		ans+=a[i]*a[i];
	}
	cout<<ans; 
	return 0;
}
