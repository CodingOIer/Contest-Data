#include<bits/stdc++.h>
#define reg register
#define int long long
using namespace std;
int T,n,k,ans;
signed main() {
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>T;
	for(int t=1;t<=T;t++){
		cout<<"Case "<<t<<": ";
		cin>>n>>k;
		if(k==1){
			int add=1,sum=0,ad=2;
			while(n--){
				sum+=add;
				add+=(1+ad)*ad/2;
				++ad;
			}
			cout<<sum<<'\n';
		}
		else{
			ans=0;
			reg int a,b,c;
			for(a=1;a<=n;a++)
				for(b=a;b<=n;b++)
					for(c=b;c<=n;c++)
						ans+=((a+b*b)%k==c*c*c%k);
			cout<<ans<<'\n';
		}
	}
	return 0;
}
