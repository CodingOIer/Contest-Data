#include<bits/stdc++.h>
using namespace std;
const int N=114514;
int n,m,k,ans,a[N],c[N];
struct node{
	int l,r,w;
}b[N];
bool cmp(node x,node y){
	return x.w<y.w;
}
signed main() {
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>b[i].l>>b[i].r;
		for(int j=b[i].l;j<=b[i].r;j++) a[j]=1;
		b[i].w=b[i].r-b[i].l+1;
	}
	while(k--){
		sort(b+1,b+m+1,cmp);
		ans+=b[m].w;
		for(int j=b[m].l;j<=b[m].r;j++) a[j]=0;
		m--;
		memset(c,0,sizeof(c));
		for(int i=1;i<=n;i++) c[i]=c[i-1]+a[i];
		for(int i=1;i<=m;i++) b[i].w=c[b[i].r]-c[b[i].l-1];
	}
	cout<<ans;
	return 0;
}
