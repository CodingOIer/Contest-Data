#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAXN=114514;
stack<int> l;
int ans,cnt,n,q,u,v,w,y,W,a[MAXN];
vector<int> e[MAXN];
vector<int> dis[MAXN];
bool vis[MAXN],t;
string s;
void solve(int x){
	if(x==y){
		t=0;
		return;
	}
	if(vis[x]) return;
	vis[x]=1;
	for(int i=0;i<e[x].size();i++){
		if(t) l.push(dis[x][i]>=W),solve(e[x][i]);
		if(t) l.pop();
	}
}
signed main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>q;
	for(int i=1;i<n;i++) cin>>a[i];
	for(int i=1;i<n;i++){
		cin>>u>>v>>w;
		e[u].push_back(v);
		e[v].push_back(u);
		dis[u].push_back(w);
		dis[v].push_back(w);
	}
	while(q--){
		cnt=0,ans=0,s="";
		cin>>u>>v>>w;
		t=1;memset(vis,0,sizeof(vis));
		W=w,y=v;
		solve(u);
		while(!l.empty()) s+=l.top()+'0',l.pop();
		reverse(s.begin(),s.end());
		for(int i=0;i<s.length();i++){
			if(s[i]=='0') ans+=a[cnt],cnt=0;
			if(s[i]=='1') ++cnt;
		}
		ans+=a[cnt];
		cout<<ans<<'\n';
	}
	return 0;
}
