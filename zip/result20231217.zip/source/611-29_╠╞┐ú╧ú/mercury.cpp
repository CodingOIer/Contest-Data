#include<bits/stdc++.h>
using namespace std;
string s;
map<char,int> a;
long long ans;
signed main() {
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0,len=s.length();i<len;i++) ++a[s[i]];
	for(map<char,int>::iterator it=a.begin();it!=a.end();it++)
		ans+=it->second*it->second;
	cout<<ans;
	return 0;
}
