#include<bits/stdc++.h>
using namespace std;
int t;
signed main() {
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>t;
	if(t==3) cout<<399428768;
	else cout<<0;
	return 0;
}
