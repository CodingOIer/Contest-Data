#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int t;
int main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	//���ԣ�f(n)=f(n-1)+f(n-3)+1
	cin>>t;
	int Ans=0;
	while(t--){
		int n;
		long long ans[5][5]={},base[5][5]={};
		//cin>>n;
		scanf("%d",&n);
		n--;
		//��������
		/*
		1 0 1 1
		1 0 0 0
		0 1 0 0
		0 0 0 1
		*/ 
		ans[1][1]=ans[2][2]=ans[3][3]=ans[4][4]=base[1][4]=base[4][4]=1;
		base[1][1]=base[1][3]=base[2][1]=base[3][2]=1;
		while(n){
			if(n&1){
				long long sum[5][5]={};
				for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)for(int k=1;k<=4;k++)sum[i][j]=(sum[i][j]+ans[i][k]*base[k][j]%mod)%mod;
				for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)ans[i][j]=sum[i][j];
			}
			n>>=1;
			long long sum[5][5]={};
			for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)for(int k=1;k<=4;k++)sum[i][j]=(sum[i][j]+base[i][k]*base[k][j]%mod)%mod;
			for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)base[i][j]=sum[i][j];
		}
//		for(int i=1;i<=4;i++){
//			for(int j=1;j<=4;j++)cout<<ans[i][j]<<" ";
//			cout<<endl;
//		}
		//ԭ����1 1 2 1
		//f(4)=f(3)+f(1)
		//f(3)=f(3)+f(1)
		Ans^=(ans[3][1]*2+ans[3][2]+ans[3][3]+ans[3][4])%mod;
		//cout<<(ans[3][1]*2+ans[3][2]+ans[3][3]+ans[3][4])%mod<<endl;
	}
	cout<<Ans<<endl;
}
