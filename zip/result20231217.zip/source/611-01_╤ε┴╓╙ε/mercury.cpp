#include<bits/stdc++.h>
using namespace std;
int a[30];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	string str;
	cin>>str;
	for(int i=0;i<str.size();i++)a[str[i]-'a']++;
	int ans=0;
	for(int i=0;i<26;i++)ans+=a[i]*a[i];
	cout<<ans<<endl;
}
