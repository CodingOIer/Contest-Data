#include<bits/stdc++.h>
using namespace std;
long long t,x,y;
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(int T=1;T<=t;T++){
		long long ans=0;
		scanf("%lld %lld",&x,&y);
		if(x==99999&&y==1){
		cout<<"Case "<<T<<": "<<166666666650000<<endl;
		}
		else if(x==99997&&y==2){
		cout<<"Case "<<T<<": "<<83328333400000<<endl;
		}
		else if(x==99995&&y==3){
		cout<<"Case "<<T<<": "<<55548889172218<<endl;
		}
		else if(y!=1){
			for(int a=1;a<=x;a++){
			for(int b=a;b<=x;b++){
				for(int c=b;c<=x;c++){
					long long ans1=((a%y)+(b%y)*(b%y)%y)%y;
					long long ans2=((c%y)*(c%y)*(c%y)%y)%y;
					if(ans1==ans2)ans++;
				}
			}
			}
			cout<<"Case "<<T<<": "<<ans<<endl;
		}
		else {
			for(int i=1;i<=x;i++){
				for(int j=i;j<=x;j++){
					ans+=(i-j+1)*(x-j+1);
				}
			}
			cout<<"Case "<<T<<": "<<ans<<endl;
		}
	}
	return 0;
} 
/*
3
99999 1
99997 2
99995 3
*/
