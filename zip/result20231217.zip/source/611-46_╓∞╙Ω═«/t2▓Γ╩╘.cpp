#include<bits/stdc++.h>
using namespace std;
long long n,m,k,maxx=0,pd=0;
int a[2005][3];
int b[2005]; 
void dfs(int dep){
	if(dep>k){
		long long ans=0;
		for(int i=1;i<=2000;i++){
			if(b[i]!=0)ans++;
		}
		maxx=max(maxx,ans);
		if(maxx==n){
			pd=1;
		}
		return;
	}
	for(int i=1;i<=m;i++){
		if(a[i][1]!=-1&&a[i][2]!=-1){
			for(int j=a[i][1];j<=a[i][2];j++){
				b[j]++;
			}
			long long kkk=a[i][1],xht=a[i][2];
			a[i][1]=-1;
			a[i][2]=-1;
			dfs(dep+1);
			if(pd==1){
				return;
			}
			a[i][1]=kkk;
			a[i][2]=xht;
			for(int j=a[i][1];j<=a[i][2];j++){
				b[j]--;
			}
		}
	}
	return;
}
int main(){
	//freopen("stamps.in","r",stdin);
	//freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		scanf("%d %d",&a[i][1],&a[i][2]);
	}
	dfs(1);
	cout<<maxx;
	return 0;
} 
/*
5 5 3
1 4
2 3
1 1
4 4
4 5
*/
