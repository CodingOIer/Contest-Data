#include<bits/stdc++.h>
using namespace std;
string s;
long long len=0,ans=0;
long long a[27];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	len=s.size();
	for(int i=0;i<len;i++){
		a[s[i]-96]++;
	}
	for(int i=1;i<=26;i++){
		ans+=a[i]*a[i];
	}
	cout<<ans;
	return 0;
} 
