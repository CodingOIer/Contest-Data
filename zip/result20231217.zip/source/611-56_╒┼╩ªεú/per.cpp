#include<bits/stdc++.h>
#define ll long long
using namespace std;
bool jjb[1145141];const ll mod=1000000007;
ll dfs(ll n,vector<ll>& subwei,ll nn){
	if(n==0)return 1;
	ll re=0;
	
	if(subwei.back()-2>0&&!jjb[subwei.back()-2]){
		jjb[subwei.back()-2]=1;
		subwei.push_back(subwei.back()-2);
		re+=dfs(n-1,subwei,nn);
		re%=mod;
		subwei.pop_back();
		jjb[subwei.back()-2]=0;
	}
	if(subwei.back()-1>0&&!jjb[subwei.back()-1]){
		jjb[subwei.back()-1]=1;
		subwei.push_back(subwei.back()-1);
		re+=dfs(n-1,subwei,nn);
		re%=mod;
		subwei.pop_back();
		jjb[subwei.back()-1]=0;
	}
	if(subwei.back()+2<=nn&&!jjb[subwei.back()+2]){
		jjb[subwei.back()+2]=1;
		subwei.push_back(subwei.back()+2);
		re+=dfs(n-1,subwei,nn);
		re%=mod;
		subwei.pop_back();
		jjb[subwei.back()+2]=0;
	}
	if(subwei.back()+1<=nn&&!jjb[subwei.back()+1]){
		jjb[subwei.back()+1]=1;
		subwei.push_back(subwei.back()+1);
		re+=dfs(n-1,subwei,nn);
		re%=mod;
		subwei.pop_back();
		jjb[subwei.back()+1]=0;
	}
	return re;
}
int main(){
	ios::sync_with_stdio(0);
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	ll t,p,ans;
	cin>>t;
	vector<ll> sb;
	while(t--){
		cin>>p;
		ans=0;
		sb.push_back(1);
		ans^=dfs(p,sb,p);sb.pop_back();
	}cout<<ans; 
}

