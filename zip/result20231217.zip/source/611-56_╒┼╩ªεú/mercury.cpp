#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll hash_s[128]; 
int main(){
	ios::sync_with_stdio(0);
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	string s;
	cin>>s;
	for(char i:s){
		hash_s[i]++;
	}
	ll ans=0;
	for(ll i:hash_s){
		ans+=i*i;
	}
	cout<<ans;
}

