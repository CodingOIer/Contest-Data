#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
	ios::sync_with_stdio(0);
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int t,n,k,t1,ans=0;
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>k;
		ans=0;
		for(int a=1;a<=n;a++){
			for(int b=a;b<=n;b++){
					for(int c=b;c<=n;c++){
					if((a+b*b)%k==((((c%k)*(c%k))%k)*(c%k))%k){
						ans++;
					}
				}
				
				
			}
		}
		cout<<"Case "<<i<<": "<<ans<<"\n";
	}
}

