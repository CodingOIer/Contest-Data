#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k;
struct a_piece{
	int l,r;bitset<400> mode;bool can_have;
}s[400];
long long dfs(int x,int i,bitset<400> j){
	if(x==0){
		ll k=0;
		for(int i=0;i<400;i++){
			k+=j[i];
		}
		return k;
	}
	if(i>=m){
		return -1;
	}
	ll a=dfs(x,i+1,j);
	ll b=dfs(x-1,i+1,j|s[i].mode);
	return max(a,b);
}
bool cmp(a_piece a,a_piece b){
	return (a.r-a.l)>(b.r-b.l);
}
int main(){
	ios::sync_with_stdio(0);
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	if(n<=70&&m<=70&&k<=70){
		for(int i=0;i<m;i++){
			cin>>s[i].l>>s[i].r;
			for(int j=s[i].l;j<=s[i].r;j++)s[i].mode[j]=1;
		}
		bitset<400> b;
		cout<<dfs(k,0,b);
	}else{
		for(int i=0;i<m;i++){
			cin>>s[i].l>>s[i].r;
			for(int j=s[i].l;j<=s[i].r;j++)s[i].mode[j]=1;
		}
		bitset<400> sb;
		sort(s,s+m,cmp);
		int eps=m,kkk;
		mt19937 Rand(time(0));
		while(k){
			eps=m;
			for(int i=0;i<m;i++,eps--){
			kkk=Rand()%(int)(1.3*m);
			if(k==0)goto loop;
			if(kkk<eps&&!s[i].can_have){
				sb|=s[i].mode;
				k--;
				s[i].can_have=1;
			}
		}	
		}
	
		
loop:
	int ans=0;
		for(int i=0;i<400;i++){
			ans+=sb[i]; 
		}
		cout<<ans;
	}
	
}

