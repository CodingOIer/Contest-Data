#include<bits/stdc++.h>
using namespace std;
string s;
char c[300];
long long ans;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)
		s[i][c]++;
	for(int i='a';i<='z';i++)
	{
		long long tmp=i[c];
		tmp*=tmp;
		ans+=tmp;
	}
	cout<<ans;
	return 0;
}
