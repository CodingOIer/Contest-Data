#include<bits/stdc++.h>
using namespace std;
long long t,n,k;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		
		long long ans=0;
		cin>>n>>k;
		if(k==1)
		{
			for(int i=0;i<=n;i++)
				ans+=i*(n-i+1);
			printf("Case %d: %lld\n",i,ans);
			continue;
		}
		else if(k==2)
		{
			n++;
			for(int i=0;i<=n;i+=2)
				ans+=i*(n-i);
			printf("Case %d: %lld\n",i,ans);
			continue;
		}
		else if(k==3)
		{
			n+=2;
			for(int i=0;i<=n;i+=3)
				ans+=max(i-1,0)*(n-i);
			printf("Case %d: %lld\n",i,ans);
			continue;
		}
		for(long long a=1;a<=n;a++)
			for(long long  b=a;b<=n;b++)
				for(long long c=b;c<=n;c++)
					if((a+b*b)%k==c*c*c%k)
						ans++;
		printf("Case %d: %lld\n",i,ans);	
	}
	return 0;
}
/*
100
0 3
Case 1: 0
1 3
Case 2: 0
2 3
Case 3: 2
3 3
Case 4: 4
4 3
Case 5: 6
5 3
Case 6: 13
6 3
Case 7: 20
7 3
Case 8: 27

*/
