#include<bits/stdc++.h>
using namespace std;
long long n,m,k,l[10000],r[10000],u,lu[20000],ru[10000],ans; 
bool ok[10000];
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
		cin>>l[i]>>r[i];
	for(int i=1;i<=m;i++)
		for(int j=1;j<=m;j++)
		{
			if(i==j)
				continue;
			else if(l[i]==l[j]&&r[i]==r[j])
				l[j]=0,r[j]=0;
			else if(l[i]==0)
				continue;
			else if(l[i]<=l[j]&&r[i]>=r[j])
				l[j]=0,r[j]=0;
			//cout<<l[i]<<' '<<r[i]<<'\n';
		}
	for(int i=1;i<=m;i++)
	{
		if(l[i]==0)
			continue;
		else
			u++,lu[u]=l[i],ru[u]=r[i];
	}
	if(u<=k)
	{
		for(int i=1;i<=u;i++)
			for(int j=lu[i];j<=ru[i];j++)
				if(!ok[j])
					ans++,ok[j]=1;
		return cout<<ans,0;
	}
	else 
	{
		for(int i=1;i<=u;i++)
			for(int j=lu[i];j<=ru[i];j++)
				if(!ok[j])
					ans++,ok[j]=1;
		return cout<<ans-10,0;
	}
	return 0;
}
