#include<bits/stdc++.h>
#define int long long
using namespace std;
string s;
int a[30],ans;
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++) a[s[i]-'a'+1]++;
	for(int i=1;i<=26;i++) ans+=a[i]*a[i];
	cout<<ans;	
	return 0;
}
