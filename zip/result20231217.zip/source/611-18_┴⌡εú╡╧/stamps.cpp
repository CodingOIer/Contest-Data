#include<bits/stdc++.h>
using namespace std;
int n,m,k,f[2010],lst;
struct node{
	int l,r;
}a[2010];
bool cmp(node p,node q){
	if(p.l!=q.l) return p.l<q.l;
	return p.r>q.r;
}
int main(){
	//freopen("stamps.in","r",stdin);
	//freopen("stamps.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++) scanf("%d%d",&a[i].l,&a[i].r);
	sort(a+1,a+m+1,cmp);
	for(int i=1;i<=m;i++) if(a[i].l!=lst) lst=a[i].l,f[a[i].l]=a[i].r;
	for(int i=1;i<=n;i++) cout<<f[i]<<" ";
	return 0;
} 
