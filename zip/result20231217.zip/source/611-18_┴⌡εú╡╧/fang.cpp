#include<bits/stdc++.h>
using namespace std;
int T,n,k,a[5010][5010];
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>T;
	for(int t=1;t<=T;t++){
		scanf("%d%d",&n,&k);
		if(k==1){
			long long ans=n*(n-1)*(n-2)/6;
			printf("Case %d: %lld\n",t,ans);
		}else{
			memset(a,0,sizeof(a));
			long long ans=0;
			for(int i=1;i<=n;i++){
				for(int j=i;j<=n;j++) a[i][j*j*j%k]++;
			}
			for(int i=1;i<=n;i++){
				for(int j=i;j<=n;j++) ans+=a[j][(i+j*j)%k];
			}
			printf("Case %d: %lld\n",t,ans);
		}
	}
	return 0;
}
