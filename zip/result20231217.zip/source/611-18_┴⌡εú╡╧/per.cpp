#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,q[1000010],ls[10][10];
const int mod=1e9+7;
struct node{
	int g[10][10],x,y;
}a,b,c,db[10010],now;
node jzcf(node p,node q){
	node ans;
	memset(ans.g,0,sizeof(ans.g));
	ans.x=p.x,ans.y=q.y;
	for(int i=1;i<=p.x;i++){
		for(int j=1;j<=q.y;j++){
			for(int k=1;k<=q.x;k++){
				ans.g[i][j]+=p.g[i][k]*q.g[k][j]%mod,ans.g[i][j]%=mod;
			}
		}
	}
	return ans;
}
signed main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++) scanf("%d",&q[i]);
	sort(q+1,q+T+1);
	if(q[T]<=20){
		int ans=0,f[]={0,1,1,2,4,6,9,14,21,31,46,68,100,147,216,317,465,682,1000,1466,2149,3150,4617,6767,9918,14536,21304,31223,45760,67065,98289};
		for(int i=1;i<=T;i++) ans^=f[q[i]];
		cout<<ans;
	}else if(q[T]<=1e9||T<=1e4){
		int ans=0;
		for(int i=1;i<=T;i++){
			if(q[i]==1||q[i]==2){
				ans^=1;
				continue;	
			}
			q[i]-=3;
			memset(a.g,0,sizeof(a.g));
			memset(b.g,0,sizeof(b.g));
			memset(c.g,0,sizeof(c.g));
			a.g[1][1]=a.g[2][2]=a.g[3][3]=a.g[4][4]=1,a.x=a.y=4;
			b.g[1][1]=b.g[1][2]=b.g[2][3]=b.g[3][1]=b.g[4][1]=b.g[4][4]=1,b.x=b.y=4;
			c.g[1][2]=c.g[1][3]=c.g[1][4]=1,c.g[1][1]=2,c.x=1,c.y=4;
			while(q[i]){
				if(q[i]&1) a=jzcf(b,a);
				b=jzcf(b,b);
				q[i]>>=1;	
			}
			c=jzcf(c,a);
			ans^=c.g[1][1];
		}
		cout<<ans;
	}else{
		int ans=0;
		db[1].g[1][1]=db[1].g[1][2]=db[1].g[2][3]=db[1].g[3][1]=db[1].g[4][1]=db[1].g[4][4]=1,db[1].x=db[1].y=4;
		now.g[1][2]=now.g[1][3]=now.g[1][4]=1,now.g[1][1]=2,now.x=1,now.y=4;
		for(int i=2;i<=10000;i++)
			db[i]=jzcf(db[1],db[i-1]);
		for(int i=1;i<=T;i++){
			int cha=q[i]-q[i-1];
			if(cha==0){
				ans^=now.g[1][1];
				continue;
			}
			if(cha<2){
				ans^=1;
				continue;
			}
			if(cha<=10000){
				now=jzcf(now,db[cha-3]);
				ans^=now.g[1][1];
			}else{
				cha-=3;
				memset(a.g,0,sizeof(a.g));
				memset(b.g,0,sizeof(b.g));
				a.g[1][1]=a.g[2][2]=a.g[3][3]=a.g[4][4]=1,a.x=a.y=4;
				b.g[1][1]=b.g[1][2]=b.g[2][3]=b.g[3][1]=b.g[4][1]=b.g[4][4]=1,b.x=b.y=4;
				while(cha){
					if(cha&1) a=jzcf(b,a);
					b=jzcf(b,b);
					cha>>=1;	
				}
				now=jzcf(now,a);
				ans^=now.g[1][1];
			}
		}
		cout<<ans;
	}
	return 0;
}
