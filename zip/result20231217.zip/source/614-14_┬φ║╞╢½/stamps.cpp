#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=2e3+5;
int n,m,k,ans;
int vis[Max],v[Max];
struct node{
	int l,r;
}a[Max];
void dfs(int x,int cnt,int sum){
	if(cnt==k){
		ans=max(ans,sum);
		return ;
	}
	if(x>m) return ;
	dfs(x+1,cnt,sum);
	int s=0;
	for(int i=a[x].l;i<=a[x].r;i++){
		if(!vis[i]) s++;
		vis[i]++;
	}
	dfs(x+1,cnt+1,sum+s);
	for(int i=a[x].l;i<=a[x].r;i++) vis[i]--;
}
signed main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=m;i++) a[i].l=read(),a[i].r=read();
	if(m<=20) dfs(1,0,0);
	else{
		for(int i=1;i<=m;i++) 
			for(int j=a[i].l;j<=a[i].r;j++){
				if(!vis[j]) ans++;
				vis[j]++;
			} 
		for(int i=1;i<=m-k;i++){
			int sum=2e9,id=0;
			for(int j=1;j<=m;j++){
				int cnt=0;
				for(int k=a[j].l;k<=a[j].r;k++)
					if(vis[k]==1) cnt++;
				if(cnt<sum&&!v[j]) sum=cnt,id=j;
			}
			v[id]=1;
			for(int j=a[id].l;j<=a[id].r;j++) vis[j]--;
			ans-=sum;	
		}	
	}
	write(ans);
	return 0;
}

