#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=1e5+5;
int n,q,u,v,w,cnt,ans;
int f[Max],s[Max];
vector<pair<int,int> >edge[Max];
void dfs(int x,int fa,int v,int dep){
	if(x==v){
		for(int i=1;i<=dep;i++)
			if(s[i]) cnt++;
			else{
				ans+=f[cnt];
				cnt=0;
			}
		ans+=f[cnt];
		return ;	
	}
	for(int i=0;i<edge[x].size();i++){
		int y=edge[x][i].first;
		if(y==fa) continue;
		if(edge[x][i].second>=w) s[dep+1]=1;
		else s[dep+1]=0;
		dfs(y,x,v,dep+1);
	}
}
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),q=read();
	for(int i=1;i<n;i++) f[i]=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w=read();
		edge[u].push_back(make_pair(v,w));
		edge[v].push_back(make_pair(u,w)); 
	}
	while(q--){
		u=read(),v=read(),w=read();
		ans=cnt=0;
		dfs(u,0,v,0);
		write(ans),puts("");	
	}
	return 0;
}

