#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=1e6+5;
int T,n,k,ans;
signed main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	T=read();
	for(int t=1;t<=T;t++){
		n=read(),k=read();
		ans=0;
		if(k==1) for(int i=1;i<=n;i++) ans+=(1+i)*i/2;
		else if(k==2) for(int i=1;i<=n/2;i++) ans+=2*i*(i+n%2);
		else{
			for(int i=1;i<=n;i++){
				for(int j=i;j<=n;j++)
					for(int p=j;p<=n;p++)
						if((i+j*j)%k==p*p*p%k) ans++;
			}
		}
		printf("Case %lld: %lld\n",t,ans);	
	}
	return 0;
}
/*
10
1 1
2 3
3 5
4 2
5 3
6 9
7 7
8 10
9 10
10 9
*/
