#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=1e5+5;
int n,ans;
string s;
int vis[Max];
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	n=s.size();
	s=" "+s;
	for(int i=1;i<=n;i++) vis[s[i]]++;
	for(int i=1;i<=n;i++) 
		ans+=vis[s[i]];
	write(ans);		
	return 0;
}
/*
jdnb
takinanosakana
*/
