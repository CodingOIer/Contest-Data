#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
char ch[N];
int a[50];
unsigned long long ans;

int main(){
	freopen ("mercury.in", "r", stdin);
	freopen ("mercury.out", "w", stdout);

	scanf ("%s", &ch);
	int n = strlen(ch);
	for (int i = 0; i < n; ++i) a[ch[i] - 'a' + 1]++; 
	
	for (int i = 1; i <= 26; ++i) if (a[i] != 0) ans += (a[i] == 1 ? 1 : a[i] * a[i]);
	printf ("%d", ans);
	
	return 0;
}
