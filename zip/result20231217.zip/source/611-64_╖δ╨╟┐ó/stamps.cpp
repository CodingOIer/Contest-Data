#include <bits/stdc++.h>
using namespace std;

const int N = 2e3 + 5;
int n, m, k;
int ans = -0x3f3f3f3f;

struct Stamps{
	int l;
	int r;
	int siz;
}a[N];

void dfs(int dep, int sum, int w){
	if (dep == m + 1) {
		ans = max(ans, sum);
		return ;
	}
	
	if (w){
		int vis[N];
		memset (vis, 0, sizeof vis);
		for (int i = dep + 1; i <= m; ++i) {
			if (a[dep].l <= a[i].l && a[i].r <= a[dep].r) {
				vis[i] = a[i].siz;
				a[i].siz -= vis[i];
			} else if (a[dep].r >= a[i].l && a[i].r >= a[dep].r) {
				vis[i] = a[dep].r - a[i].l + 1;
				a[i].siz -= vis[i];
			} else if (a[dep].l <= a[i].r && a[i].l <= a[dep].l) {
				vis[i] = a[i].r - a[dep].l + 1;
				a[i].siz -= vis[i];
			}
		}
		dfs(dep + 1, sum + a[dep].siz, w - 1);
		for (int i = dep + 1; i <= m; ++i) {
			if (vis[i]) a[i].siz += vis[i];
		}
	}
	dfs(dep + 1, sum, w);
	
}

int main(){
	freopen ("stamps.in", "r", stdin);
	freopen ("stamps.out", "w", stdout);
	
	scanf ("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= m; ++i) {
		scanf ("%d%d", &a[i].l, &a[i].r);
		a[i].siz = a[i].r - a[i].l + 1;
	}
	
	dfs(1, 0, k);
	
	printf ("%d", ans);
	
	return 0;
} 
