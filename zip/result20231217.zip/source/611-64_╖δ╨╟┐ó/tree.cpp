#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
int n, q;
int a[N], f[N];

struct Edge{
	int v, nxt, w;
}e[N];

int head[N], ecnt;
void addEdge(int u, int v, int w){
	e[++ecnt] = {v, head[u], w};
	head[u] = ecnt;
}

int fa[N], son[N], dep[N], siz[N], dfn[N], top[N], dot[N], tot;
int tree[N]

void dfs1(int u, int f){
	fa[u] = f;
	dep[u] = dep[f] + 1;
	siz[u] = 1;
	
	for (int i = head[u]; i; i = e[i].nxt) {
		int v = e[i].v;
		if (v != f){
			dfs1(v, u);
			siz[u] += siz[v];
			if (siz[son[u]] < siz[v]) son[u] = v;
		}
	}
}

void dfs2(int u, int topf){
	top[u] = topf;
	dfn[u] = ++tot;
	dot[tot] = a[u];

	if (son[u]) dfs2(son[u], topf);
	
	for (int i = head[u]; i; i = e[i].nxt) {
		int v = e[i].v;
		if (v != son[u] && v != fa[u]) dfs2(v, v);
	}
}

int ans(int x, int y){
	while (top[x] != top[y]) {
		if (dep[top[x]] < dep[top[y]]) swap(x, y);
		y = fa[top[y]];
	}
	
}

int main(){
//	freopen ("tree.in", "r", stdin);
//	freopen ("tree.out", "w", stdout);
	
	scanf ("%d%d", &n, &q);
	for (int i = 1; i < n; ++i) scanf ("%d", &f[i]);
	
	for (int i = 1; i < n; ++i) {
		int u, v, w;
		scanf ("%d%d%d", &u, &v, &w);
		addEdge(u, v, w);
		addEdge(v, u, w);
		a[u] = w;
	}
	
	dfs1(1, 0);
	dfs2(1, 1);
	
	while (q--){
		int u, v, w;
		scanf ("%d%d%d", &u, &v, &w);
		printf ("%d", ans(u, v));
	}
	
	return 0;
}

