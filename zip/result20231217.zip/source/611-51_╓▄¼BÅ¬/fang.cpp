#include<bits/stdc++.h>
#define int long long
#define INT LONG_LONG
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
#define debug(x) cout<<"I AK IOI!"<<x<<"\n\n";
using namespace std;
int T,n,k,T1,T2,a[100005][2],T3,b[100005][2],;
signed main()
{
	fast_io;
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>T;
	T1=T;
	for (int i=1;i<=100000;i++)
		a[++T2][0]=i*i,a[T2][1]=i;
	for (int i=1;i<=100000;i++)
		b[++T3][0]=i*i*i,b[T3][1]=i;
	while (T--)
	{
		cin>>n>>k;
		const int p=k;
		int ans=0;
		if (k==1)
		{
			for (int i=1;i<=n;i++)
				ans=ans+(i+1)*i/2;
			cout<<"case "<<T1-T<<":"<<ans/k+ans%k<<" "<<ans<<endl;
			continue;
		}
		for (int i=1;i<=T2&&a[i][1]<=n;i++)
			for (int j=1;j<=T3&&b[j][1]<=n;j++)
			{
				int t=b[j][0]%p,x=a[i][0]%p;
				if (a[i][1]>b[j][1])
					continue;
				int xt=t-x;
				if (xt<0)
					xt=k-x+t;
				if (xt==0)
					xt=k;
				if (a[i][1]-xt>=0)
					ans++;
				else 
					continue;
				int l=(a[i][1]-xt)/k;
				ans+=l;
			}
		cout<<"case "<<T1-T<<":"<<ans<<endl;*/
	}
	return 0;
}
