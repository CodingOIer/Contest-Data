#include<bits/stdc++.h>
#define int long long
#define INT LONG_LONG
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
#define debug cout<<"I AK IOI!\n\n";
using namespace std;
int n,m,k,l[2005],r[2005],ans;
int v[2005],vis[2005];
inline void calc(int x,int y)
{
	if (x==m+1||y==k)
	{
		int sum=0;
		for (int i=1;i<=n;i++)
			if (v[i])
				sum++;
		ans=max(ans,sum);
		return ;
	}
	calc(x+1,y);
	for (int i=1;i<=m;i++)
		if (!vis[i])
		{
			vis[i]=1;
			for (int j=l[i];j<=r[i];j++)
				v[j]++;
			calc(x+1,y+1);
			for (int j=l[i];j<=r[i];j++)
				v[j]--;
			vis[i]=0;
		}
}
signed main()
{
	fast_io;
	//freopen("stamps.in","r",stdin);
	//freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for (int i=1;i<=m;i++)
		cin>>l[i]>>r[i];
	calc(1,0);
	cout<<ans;
	return 0;
}

