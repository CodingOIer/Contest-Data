#include<bits/stdc++.h>
#define int long long
#define INT LONG_LONG
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
#define debug cout<<"I AK IOI!\n\n";
using namespace std;
string s;
int n,a[27],ans;
signed main()
{
	fast_io;
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	n=s.size();
	for (int i=0;i<n;i++)
		a[s[i]-'a']++;
	for (int i=0;i<26;i++)
		ans+=a[i]*a[i];
	cout<<ans;
	return 0;
}
