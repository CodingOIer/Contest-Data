#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
int n,m,k,a[2020],b[2020],ans,maxx,vis[2020],viss[22];
void dfs(int cnt,int step)
{
	if(cnt>k){
		ans=0;
		memset(viss,0,sizeof(vis));
		for(int i=1;i<=k;i++)
		{
			ans+=b[vis[i]]-a[vis[i]]+1;
			for(int j=a[vis[i]];j<=b[vis[i]];j++)
				if(viss[j]) ans--;
				else viss[j]=1;
		}
//		for(int i=1;i<=k;i++)
//			cout << vis[i] << " ";
//		cout << ans;
//		cout << endl;
		maxx=max(maxx,ans);
		return;
	}
	for(int i=step+1;i<=m;i++)
		if(i+(k-cnt)>m&&0) return;
		else{
			vis[cnt]=i;
			dfs(cnt+1,i);
			vis[cnt]=0;
		}
}
void waijie()
{
	maxx=n;
}
signed main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin >> n >> m >> k;
	for(int i=1;i<=m;i++)
		cin >> a[i] >> b[i];
	if(m<=20&&k<=20) dfs(1,0);
	else waijie();
	cout << maxx;
	return 0;
}
