#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
signed main()
{
	int n,sum=0;
	cin >> n;
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
			for(int l=j;l<=n;l++)
				sum++;
	cout << sum;
	return 0;
}
/*
1 4 10 20 35 56 84 165 220


*/
