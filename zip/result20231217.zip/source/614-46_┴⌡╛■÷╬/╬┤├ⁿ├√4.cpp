#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
int n,h[303030],maxx;
vector<int> a[303030];
int dfs(int u,int fa)
{
	int ans=0;
	if(a[u].size()==1){
		ans++;
		return ans;
    }
	for(auto v:a[u])
		if(v!=fa) ans+=dfs(v,u);
	return ans+1;
}
signed main()
{
	cin >> n;
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		cin >> x >> y;
		h[x]++;
		h[y]++;
		a[x].push_back(y);
		a[y].push_back(x);
	}
	
	return 0;
}
