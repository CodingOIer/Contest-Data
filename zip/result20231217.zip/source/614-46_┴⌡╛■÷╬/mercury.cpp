#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
char a[101010];
int n,ans,vis[27];
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin >> a;
	n=strlen(a);
	for(int i=0;i<n;i++)
		vis[int(a[i]-'a')+1]++;
	for(int i=1;i<=26;i++)
		ans+=vis[i]*vis[i];
	cout << ans;
	return 0;
}
