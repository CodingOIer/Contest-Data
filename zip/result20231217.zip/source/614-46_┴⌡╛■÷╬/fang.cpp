#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
ll t,n,k,vis[1000101],ans,IAKIOI[1000010]={54188,0},sum;
void init()
{
	memset(vis,0,sizeof(vis));
	ans=0;
	for(int i=1;i<=n;i++)
		vis[(i*i*i)%k]++;
}
void baoli()
{
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
			for(int l=j;l<=n;l++)
				if((i+j*j)%k==(l*l*l)%k) ans++;
	cout << "Case " << sum << ": " << ans << endl;
}
#define why5ptsaaaa pianfen1
#define genshin_start init_pianfen
void init_pianfen()
{
	IAKIOI[0]=0;IAKIOI[1]=1;
	for(ll i=2;i<=1000000;i++)
		IAKIOI[i]=IAKIOI[i-2]+i*i;
}
void pianfen1()
{
	if(IAKIOI[0]==54188) genshin_start();
	cout << "Case " << sum << ": " << IAKIOI[n] << endl;
}
#undef genshin_shart
void solve()
{
	ans=0;
	cin >> n >> k;
	if(n<=300) baoli();
	elif(k==1) why5ptsaaaa();
}
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin >> t;
	for(int i=1;i<=t;i++)
		sum=i,solve();
	return 0;
}
