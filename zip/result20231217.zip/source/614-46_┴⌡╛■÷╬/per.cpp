#include<bits/stdc++.h>
#define pop() return
#define ll long long
#define ull unsigned long long
#define elif else if
#define endl "\n"
using namespace std;
signed main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
//	for(int i=0;i<=98032195;i++)
//		if((1^i)<=2) cout << i << " ";
	cout << "399428768";
	return 0;
}
/*
1^1010010 <=10
1^11111110




*/
