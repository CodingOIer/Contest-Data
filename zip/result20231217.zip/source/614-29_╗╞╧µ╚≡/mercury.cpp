#include<bits/stdc++.h>
using namespace std;
int cnt[1145];
char CCF[200005];
long long ans;
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	scanf("%s",CCF);
	for(int i=0;CCF[i]!='\0'&&CCF[i]!='\n'&&CCF[i]!='\r';i++)cnt[CCF[i]]++;
	for(int i=0;CCF[i]!='\0'&&CCF[i]!='\n'&&CCF[i]!='\r';i++)ans+=cnt[CCF[i]];
	printf("%lld",ans);
	return 0;
}
