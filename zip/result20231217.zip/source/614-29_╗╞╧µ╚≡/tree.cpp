#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+7;
int N,Q,coin[maxn];
struct Range{
	int ans,llen,rren,Len;
	Range(){ans=Len=llen=rren=0;}
	void st(int xx){Len=1;llen=rren=(xx>=1);ans=coin[(xx>=1)];}
	void rotate(){swap(llen,rren);}
};
struct Query{int u,v,w,id,ans;}QUE[maxn];
struct Point{int inx,val;}P[maxn];
int cmpw(Query X,Query Y){return X.w>Y.w;} 
int cmpid(Query X,Query Y){return X.id<Y.id;}
int cmpPoint(Point X,Point Y){return X.val>Y.val;}
Range operator+(const Range &awa,const Range &qwq){
	Range ret;ret.Len=awa.Len+qwq.Len;
	ret.ans=awa.ans+qwq.ans;
	if(awa.rren>0&&qwq.llen>0)
		ret.ans-=coin[awa.rren]+coin[qwq.llen],ret.ans+=coin[awa.rren+qwq.llen];
	if(awa.llen==awa.Len)ret.llen=awa.llen+qwq.llen;
	else ret.llen=awa.llen;
	if(qwq.rren==qwq.Len)ret.rren=qwq.rren+awa.rren;
	else ret.rren=qwq.rren;
return ret;}
struct SegmentTree{
	struct Node{int ls,rs,val;Range R;}dat[maxn<<2];
	int root,tot;SegmentTree(){root=tot=1;}
	#define ls(p) dat[p].ls
	#define rs(p) dat[p].rs
	void pushdown(int p,int Len,int Ren){
		if(!ls(p))ls(p)=++tot,dat[tot].R.Len=Len;
		if(!rs(p))rs(p)=++tot,dat[tot].R.Len=Ren;
	}
	void pushup(int p){dat[p].R=dat[ls(p)].R+dat[rs(p)].R;}
	Range QueryRange(int p,int L,int R,int ql,int qr){
		if(ql<=L&&R<=qr)return dat[p].R;
		int mid=(L+R)>>1;pushdown(p,mid-L+1,R-mid);
		if(ql<=mid&&mid+1<=qr)
			return QueryRange(ls(p),L,mid,ql,qr)+QueryRange(rs(p),mid+1,R,ql,qr);
		if(ql<=mid)return QueryRange(ls(p),L,mid,ql,qr);
		if(mid+1<=qr)return QueryRange(rs(p),mid+1,R,ql,qr);
	}Range QueryRange(int ql,int qr){return QueryRange(root,1,N,ql,qr);}
	void ModifyPoint(int p,int L,int R,int inx,int xx){
		if(L>=R){dat[p].R.st(xx);return;}
		int mid=(L+R)>>1;pushdown(p,mid-L+1,R-mid);
		if(inx<=mid)ModifyPoint(ls(p),L,mid,inx,xx);
		else ModifyPoint(rs(p),mid+1,R,inx,xx);
		pushup(p);
	}void ModifyPoint(int inx,int xx){ModifyPoint(root,1,N,inx,xx);}
};
struct ZLPF{
	int val1[maxn],val_edge[maxn];
	int head[maxn<<1],nxt[maxn<<1],to[maxn<<1],cnt_edge;
	int dep[maxn],Fa[maxn],size[maxn],id[maxn],Hd[maxn],Hson[maxn],dfn;
	SegmentTree SEG;
	ZLPF(){cnt_edge=dfn=0;memset(Hd,0,sizeof(Hd));}
	void AddEdge(int u,int v,int w){
		nxt[++cnt_edge]=head[u];to[cnt_edge]=v;
		head[u]=cnt_edge;val_edge[cnt_edge]=w;
		nxt[++cnt_edge]=head[v];to[cnt_edge]=u;
		head[v]=cnt_edge;val_edge[cnt_edge]=w;
	}
	void dfs1(int u,int v,int w){
		dep[u]=dep[v]+1;Fa[u]=v;
		size[u]=1;val1[u]=w;
		for(int i=head[u];i;i=nxt[i]){
			if(to[i]==v)continue;
			dfs1(to[i],u,val_edge[i]);size[u]+=size[to[i]];
			if(size[to[i]]>size[Hson[u]])Hson[u]=to[i];
		}
	}
	void dfs2(int u,int Top){
		Hd[u]=Top;id[u]=++dfn;
		if(!Hson[u])return;dfs2(Hson[u],Top);
		for(int i=head[u];i;i=nxt[i]){
			if(to[i]==Fa[u]||to[i]==Hson[u])continue;
			dfs2(to[i],to[i]);
		}
	}
	void Read(){
		scanf("%d%d",&N,&Q);
		for(int i=1;i<N;i++)scanf("%d",&coin[i]);
		for(int i=1;i<N;i++)
		{int a,b,c;scanf("%d%d%d",&a,&b,&c);AddEdge(a,b,c);}
		for(int i=1;i<=Q;i++)
		scanf("%d%d%d",&QUE[i].u,&QUE[i].v,&QUE[i].w),QUE[i].id=i;
		dfs1(1,0,0);dfs2(1,1);
		for(int i=1;i<=N;i++)P[i].inx=id[i],P[i].val=val1[i]; 
		sort(QUE+1,QUE+Q+1,cmpw);sort(P+1,P+N+1,cmpPoint);
	}
	int QueryOnTree(int u,int v){
		int du=u,dv=v;
		Range LHQ,RMJ;
		while(Hd[u]!=Hd[v]){
			if(dep[Hd[u]]>dep[Hd[v]]){//������ 
				Range TAT=SEG.QueryRange(id[Hd[u]],id[u]);
				TAT.rotate();
				if(LHQ.Len==0)LHQ=TAT;
				else LHQ=LHQ+TAT;
				u=Fa[Hd[u]];
			}else{//������
				Range TAT=SEG.QueryRange(id[Hd[v]],id[v]);
				if(RMJ.Len==0)RMJ=TAT;
				else RMJ=TAT+RMJ;	
				v=Fa[Hd[v]];
			}
		}
		if(dep[u]>dep[v]){//vΪLCA 
			Range TAT=SEG.QueryRange(id[Hson[v]],id[u]);
			TAT.rotate();
			if(LHQ.Len==0)LHQ=TAT;
			else LHQ=LHQ+TAT;
		}else{//uΪLCA
			Range TAT=SEG.QueryRange(id[Hson[u]],id[v]);
			if(RMJ.Len==0)RMJ=TAT;
			else RMJ=TAT+RMJ;
		}
		if(RMJ.Len==0)return LHQ.ans;
		if(LHQ.Len==0)return RMJ.ans;
		LHQ=LHQ+RMJ;return LHQ.ans;
	}
	void solve(){
		for(int j=1,i=1;i<=Q;i++){
			while(P[j].val>=QUE[i].w&&j<=N)
				SEG.ModifyPoint(P[j].inx,P[j].val),j++;
			QUE[i].ans=QueryOnTree(QUE[i].u,QUE[i].v);
		}
		sort(QUE+1,QUE+Q+1,cmpid);
		for(int i=1;i<=Q;i++)printf("%d\n",QUE[i].ans);
	}
}OH_LingkingCutTreeeeeeeeeeee;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	OH_LingkingCutTreeeeeeeeeeee.Read(); 
	OH_LingkingCutTreeeeeeeeeeee.solve();
	return 0;
}
