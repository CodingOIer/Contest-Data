#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=2005;
int n,m,k,vis[N][N],dis[N],fac[N];
struct node{
	int l,r;
	int sum;
}e[N];
bool cmp(node a,node b) {
	return a.sum>b.sum;
}
void solve() {
	for(int i=1;i<=n;++i) {
		int k=vis[i][1];
		for(int j=1;j<=dis[i];++j) {
			if(e[k].sum<e[vis[i][j]].sum) k=vis[i][j];			
		}
		for(int j=1;j<=dis[i];++j) {
			if(k==vis[i][j]) continue;
			e[vis[i][j]].sum--;
		}
	}
	sort(e+1,e+m+1,cmp);
	int ans=0;
	for(int i=1;i<=k;++i) {
		for(int j=e[i].l;j<=e[i].r;++j) {
			fac[j]++;
		}
	}
	for(int i=1;i<=n;++i) {
		if(fac[i]) ans++;
	}
	printf("%lld\n",ans);
	return ; 
}
signed main() {
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=1;i<=m;++i) {
		scanf("%lld%lld",&e[i].l,&e[i].r);
		e[i].sum=e[i].r-e[i].l+1;
		for(int j=e[i].l;j<=e[i].r;++j) {
			vis[j][++dis[j]]=i;
		}
	}
	solve();
	return 0;
}

