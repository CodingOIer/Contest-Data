#include<bits/stdc++.h>
using namespace std;
#define int long long
int k,n,i;
void solve() {
	int ans=0;
	scanf("%lld%lld",&n,&k);
	for(int c=1;c<=n;++c) {
		for(int b=1;b<=c;++b) {
			int a=(c*c*c%k-b*b%k+k)%k;
			if(b>=a) {
				int x=(b-a)/k+1;
				ans+=x;
				if(a==0) ans--;
			} 
		}
	}
	printf("Case %lld:%lld\n",++i,ans);
} 
signed main() {
	int t;
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%lld",&t);
	while(t--) solve();
	return 0;
}
