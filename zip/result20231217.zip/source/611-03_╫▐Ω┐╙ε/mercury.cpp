#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=1e5+10;
char s[N];
int ans,n;
int vis[30];
void init() {
	for(int i=0;i<n;++i) {
		vis[s[i]-'a']++;
	}
	return;
}
signed main() {
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	n=strlen(s);
	init();
	for(int i=0;i<26;++i) {
		if(!vis[i]) continue;
		ans+=vis[i]*(vis[i]-1);
	}
	printf("%lld",ans+n);
	return 0;
} 
