#include<bits/stdc++.h>
using namespace std;
char a[100010];
long long b[30],s=0;
int main()
{
	freopen("mercury.in","r",stdin);freopen("mercury.out","w",stdout);
	cin.tie(0);cout.tie(0);cin>>a;
	for(int i=0;i<strlen(a);i++) b[int(a[i])-96]++; 
	for(int i=1;i<=26;i++) { s+=(b[i]*(b[i]+1)); s-=b[i];}
	printf("%lld",s);
	return 0;
}

