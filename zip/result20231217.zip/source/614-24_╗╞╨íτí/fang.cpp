#include<bits/stdc++.h>
using namespace std;
long long n,m,k,p,q,s=0;
int main()
{
	freopen("fang.in","r",stdin);freopen("fang.out","w",stdout);scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%lld%lld",&p,&q);s=0;
		for(int i1=1;i1<=p;i1++) {for(int i2=1;i2<=p;i2++){
				for(int i3=1;i3<=p;i3++) {if((i1+i2*i2)%q==i3*i3*i3%q) s++;
				}
			}
		}
		printf("Case %d:%lld\n",i,s);
	}
	return 0;
}
