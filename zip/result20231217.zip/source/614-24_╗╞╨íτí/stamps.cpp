#include<bits/stdc++.h>
using namespace std;
long long n,m,p,t=0,s=0;struct ycl{int l,r;}a[2010];
bool b[2010];
bool cmp(ycl n1,ycl n2)
{
	if(n1.l!=n2.l) return n1.l<n2.l;
	if(n1.r!=n2.r) return n1.r<n2.r;
	return 0;
}
void ss(int gs,int xz)
{
	s=max(t,s);
	if(gs==p+1) memset(b,0,sizeof(b));
	for(int j=1;j<=sizeof(b);j++) t+=b[j];
	for(int i=xz;i<=m;i++) { for(int j=a[i].l;j<=a[i].r;j++) b[j]=1; ss(gs+1,i+1);}
	t=0;
}	
int main()
{
	freopen("stamps.in","r",stdin);freopen("stamps.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&p);
	for(int i=1;i<=m;i++) 
		scanf("%d%d",&a[i].l,&a[i].r);
	sort(a+1,a+m+1,cmp);
	ss(0,1);printf("%lld",s);
	return 0;
}
