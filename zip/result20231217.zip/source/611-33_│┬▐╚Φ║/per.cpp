#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("per.out","w",stdout);
	srand(time(0));
	cout<<rand()*rand()*rand();  
	return 0;
}

