//�Ҳ��������ʷֵģ� 
//�� �������� �� 
// ��Ҫд���� ������ 
#include <bits/stdc++.h>
using namespace std;
int n,q;
string s,t;
int f[100009],dp[100009][25];
bool _map[100009];
int fa[100009],deep[100009];
int head[100009],cnt = 1;
struct star{
	int next,to,w;
}e[100009];
void addedge(int u,int v,int w) {
	e[cnt].to = v;
	e[cnt].w = w;
	e[cnt].next = head[u];
	head[u] = cnt++;
}
void dfs1(int x,int fath) {
//	cout<<x<<" "<<fath<<"\n";
	fa[x] = fath;
	deep[x] = deep[fath] + 1;
	for(int i=head[x];~i;i=e[i].next) {
		if(_map[e[i].to]==0) {
			_map[e[i].to] = 1;
			dfs1(e[i].to,x);
			_map[e[i].to] = 0;
		}
	//	cout<<i<<" ";
	}
	return;
}
int LCA(int x,int y) {
	if(deep[x] < deep[y]) swap(x,y);
	while(deep[x] != deep[y]) x = fa[x];
	if(x==y) return x;
	int now = 20;
//	cout<<x<<" "<<y<<'\n';
	while(fa[x]!=fa[y]) {
		if(dp[x][now] != dp[y][now]) {
			x = dp[x][now]; y= dp[y][now];
		}
		now--;
	}
	return fa[x];
} //����˻���O(n),�Ҳ���^~^
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout); 
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cin>>n>>q;
	for(int i=1;i<n;i++) cin>>f[i];
	int u,v,w;
	n*=2;
	for(int i=1;i<=n;i++) e[i].next=-1,e[i].to = -1,head[i]=-1;
	n/=2;
	for(int i=1;i<n;i++) {
		cin>>u>>v>>w;
		addedge(u,v,w);
		addedge(v,u,w);
	}
	_map[1] = 1;
	dfs1(1,1);
	for(int i=1;i<=n;i++) dp[i][0] = fa[i];
	for(int j=1;j<=20;j++)
		for(int i=1;i<=n;i++)
			dp[i][j] = dp[dp[i][j-1]][j-1];
//	for(int i=1;i<=n;i++) cout<<deep[i]<<" ";
//	cout<<"\n";
	int x,y,m;
	while(q--) {
		cin>>x>>y>>w;
		s = '\0' ; t = '\0';
		int lc = LCA(x,y);
		while(x!=lc) {
			for(int i=head[x];~i;i=e[i].next)
				if(e[i].to == fa[x]) {
					if(e[i].w >= w) s+='1';
					else s+='0'; 
					break;
				}
			x = fa[x];
		}
		while(y!=lc) {
			for(int i=head[y];~i;i=e[i].next)
				if(e[i].to == fa[y]) {
					if(e[i].w >= w) t+='1'; 
					else t+='0'; 
					break;
				}
			y = fa[y];
		}
		int lens , lent = t.size();
		for(int i=lent;i>=1;i--) s+=t[i];
		lens = s.size()+1;
		int ans = 0,lon = 0;
		for(int i=1;i<=lens;i++) {
			if(s[i]=='1' && s[i-1]!='1') lon = 1;
			else if(s[i]=='1' && s[i-1]=='1') lon++;
			else if(s[i]!='1' && s[i-1]=='1') {
				ans += f[lon];
			//	cout<<lon<<" ";
			}
		}
		cout<<ans<<"\n";
	}
	return 0;
}
/*
2 3
10
1 2 3
1 2 2
1 2 3
1 2 4

6 5
1 2 3 4 5
1 2 2
2 4 5
3 2 5
4 5 6
1 6 5
1 3 1
2 3 1
4 5 1 
5 6 1
3 5 1

*/
