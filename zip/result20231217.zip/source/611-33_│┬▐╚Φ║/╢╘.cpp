#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("����.in","w",stdout);
		ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cout<<290000<<"\n";
for(int i=1;i<=300;i++) {
	for(int j=1;j<=300;j++) {
		cout<<i<<" "<<j<<"\n";
	}
}
//cout << flush ;
//while(1);
	return 0;
}

