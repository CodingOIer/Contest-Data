#include <bits/stdc++.h>
using namespace std;

int main() {
string s,t;
s = '\0';
s+="sb";
for(int i=1;i<=2;i++) cout<<s[i];
	return 0;
}

