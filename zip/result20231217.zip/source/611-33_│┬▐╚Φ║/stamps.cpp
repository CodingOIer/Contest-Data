#include <bits/stdc++.h>
using namespace std;
int n,m,k,maxn = -1,ii,cnt,ans;
struct node {
	int l,r,lon;
}a[2005];
int p[2005];
bool cmp(node a,node b) {
	return a.lon > b.lon;
}
int main() {
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","W",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++) {
		cin>>a[i].l>>a[i].r;
		a[i].lon = a[i].r - a[i].l + 1;
	}
	sort(a+1,a+1+m,cmp);
	for(int i=1;i<=k;i++) {
		maxn = 0;
		for(int j=1;j<=m;j++) {
			int _lon = a[j].lon,now = 0;
		//	cout<<_lon<<" ";
			if(_lon == -90) continue;
			for(int l1=1;l1<=n;l1++) {
				now += p[l1];
				if(now > 0 && l1 >= a[j].l && l1 <= a[j].r) _lon--; 
			}
		//	cout<<_lon<<" "<<maxn<<"\n";
			if(maxn < _lon) maxn = _lon , ii = j;
		}
	//	cout<<maxn<<" "<<ii<<" ";
		ans += maxn;
		a[ii].lon = -90;
		p[a[ii].l]++;
		p[a[ii].r+1]--;
	}
	cout<<ans;
	return 0;
}

