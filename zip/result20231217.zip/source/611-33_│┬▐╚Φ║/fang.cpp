#include <bits/stdc++.h>
using namespace std;
int t;
int n,k;
int main() {
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
		ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cin>>t;
	for(int kkk = 1;kkk<=t;kkk++) {
		int ans = 0;
		cin>>n>>k;
		cout<<"Case "<<kkk<<": ";
		for(int a=1;a<=n;a++)
			for(int b=a;b<=n;b++)
				for(int c=b;c<=n;c++)
					if((a+(b*b)) % k == (c*c*c) % k) ans++;
		cout<<ans;
		cout<<"\n";
	}
	return 0;
}

