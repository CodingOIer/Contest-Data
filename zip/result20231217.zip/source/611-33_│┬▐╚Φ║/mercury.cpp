#include <bits/stdc++.h>
using namespace std;
string a;
int p[109];
long long ans;
long long C(int x) {
	return 1ll * x * (x - 1); 
}
int main() {
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0); 
	cin.tie(0); cout.tie(0);
	cin>>a;
	int len = a.size();
	ans = len;
	for(int i=0;i<len;i++) {
		p[int(a[i]-'a'+ 1)]++;
	}
	for(int i=1;i<=26;i++) {
		ans += C(p[i]);
	}
	cout<<ans<<" ";
	return 0;
}

