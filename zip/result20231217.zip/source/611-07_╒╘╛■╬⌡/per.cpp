#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5;

int main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cout<<399428768;
	return 0;
}
