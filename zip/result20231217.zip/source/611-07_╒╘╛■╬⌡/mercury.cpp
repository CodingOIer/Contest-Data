#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5;
string s;
ll cnt;
ll a[30];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin>>s;
	for(ll i=0;i<s.length();i++){
		a[s[i]-'a'+1]++;
	}
	for(ll i=1;i<=26;i++){
		cnt+=(a[i]*a[i]);
	}
	cout<<cnt;
	return 0;
}
