#include <bits/stdc++.h>
#define N 100005
using namespace std;
int n,q,f[N],_u,_v,_w,l,c[200005],cl;
int dep[N],fa[N],son[N],size[N],top[N];
int head[N],next[N],to[N],w[N],cnt=0;
void add(int u,int v,int ww)
{
	cnt++;
	next[cnt]=head[u];
	to[cnt]=v;
	head[u]=cnt;
	w[cnt+1]=ww;
}
int dfs1(int x,int p)
{
	fa[x]=p;
	dep[x]=dep[p]+1;
	int m=0,s=1,t;
	for(int i=head[x];i!=-1;i=next[i])
	{
		if(to[i]!=fa[x])
		t=dfs1(to[i],x);
		s+=t;
		if(m<t)//{
			m=t,son[x]=to[i];//cout<<to[i]<<" "<<x<<" "<<p<<endl;}
	}
	return size[x]=s;
}
int dfs2(int x,int p)
{
	if(son[p]!=x)
		top[x]=x;
	else
		top[x]=top[fa[x]];
	for(int i=head[x];i!=-1;i=next[i])
	{
		if(to[i]!=fa[x])
		dfs2(to[i],x);
	}
}
int LCA(int x,int y)
{
	int tx=top[x],ty=top[y];
	while(1)
	{
		//cout<<tx<<ty<<endl;
		if(top[fa[tx]]==ty)
		{
			return fa[tx];
		}
		if(top[fa[ty]]==tx)
		{
			return fa[ty];
		}
		if(dep[tx]>dep[ty])
		{
			tx=top[fa[tx]];
		}
		else if(dep[tx]<dep[ty])
		{
			ty=top[fa[ty]];
		}
		else if(dep[tx]==dep[ty])
		{
			if(top[fa[tx]]!=top[fa[ty]])
			{
				tx=top[fa[tx]];
				ty=top[fa[ty]];
			}
			else
			{
				int fx=fa[tx];
				int fy=fa[ty];
				while(fx!=fy)
				{
					fx=fa[fx];
					fy=fa[fy];
				}
				return fx;
			}
		}
//		if(tx==ty)
//		{
//			return tx;
//		}
	}
}
int main()
{
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=N;i++) head[i]=next[i]=to[i]=-1;
	for(int i=1;i<n;i++) scanf("%d",&f[i]);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&_u,&_v,&_w);
		add(_u,_v,_w);
	}
	//for(int i=head[1];i!=-1;i=next[i])
		dfs1(1,1);
	//for(int i=head[1];i!=-1;i=next[i])
		dfs2(1,1);
	for(int i=1;i<=q;i++)
	{
		cl=1;
		memset(c,-1,sizeof(c));
		scanf("%d%d%d",&_u,&_v,&_w);
		l=LCA(_u,_v);
		for(int j=_u;j!=l;j=fa[j])
		{
			if(w[j]>=_w)
			{
				c[cl]=1;
				cl++;
			}
			else
			{
				c[cl]=0;
				cl++;
			}
		}
		for(int j=_v;j!=l;j=fa[j])
		{
			if(w[j]>_w)
			{
				c[cl]=1;
				cl++;
			}
			else
			{
				c[cl]=0;
				cl++;
			}
		}
		for(int j=1;c[j]!=-1;j++) cout<<c[i]<<" ";
	}
	return 0;
}
/*
	17 1
	0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
	1 2 1
	1 3 0
	1 4 2
	2 5 0
	3 6 3
	3 7 0
	4 8 0
	5 9 0
	5 10 0
	9 12 0
	9 13 0
	12 16 0
	10 14 0
	10 15 0
	14 17 0
	7 11 0
	1 2 1
*/
