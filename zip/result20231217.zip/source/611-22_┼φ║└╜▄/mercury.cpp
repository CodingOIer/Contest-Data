#include <bits/stdc++.h>
using namespace std;
int letter[210],i;
char c;
long long ans;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	while(scanf("%c",&c) && c!='\n')
		i++,letter[c]++;
	for(int i=1;i<=200;i++)
		ans+=letter[i]*letter[i];
	printf("%d",ans);
	return 0;
}
