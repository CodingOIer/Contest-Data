#include <bits/stdc++.h>
using namespace std;
int t,n,k,a;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d%d",&n,&k);
		a=0;
		for(int i=1;i<=n;i++)
		{
			for(int j=i;j<=n;j++)
			{
				for(int l=j;l<=n;l++)
				{
					if((i+j*j)%k==l*l*l%k)
						a++;
				}
			}	
		}
		cout<<"Case"<<i<<":"<<a;
	}
	return 0;
}
