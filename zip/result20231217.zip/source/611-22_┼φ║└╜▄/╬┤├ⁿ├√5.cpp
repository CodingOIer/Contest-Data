#include <bits/stdc++.h>
using namespace std;
int n,q,f[100005],_u,_v,_w;
struct tree{
	int u,v,w;
}t[100005];
int main()
{
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&_u,&_v,&_w);
		t[i].u=_u,t[i].v=_v,t[i].w=_w;
	}
	
	return 0;
}
