#include <bits/stdc++.h>
#define N 100005
using namespace std;
int n,q,f[N],_u,_v,_w;
int dep[N],fa[N],son[N],size[N],top[N];
int head[N],next[N],to[N],w[N],cnt=0;
//struct tree{
//	int u,v,w;
//}t[N];
void add(int u,int v,int ww)
{
	cnt++;
	next[cnt]=head[u];
	to[cnt]=v;
	head[u]=cnt;
	w[cnt]=ww;
}
int dfs1(int x,int p)
{
	fa[x]=p;
	dep[x]=dep[p]+1;
	int m=0,s=1,t;
	for(int i=head[x];i!=-1;i=next[i])
	{
		if(to[i]!=fa[x])
		t=dfs1(to[i],x);
		s+=t;
		if(m<t)
			m=t,son[x]=to[i];
	}
	return size[x]=s;
	
}
int dfs2(int x,int p)
{
	if(son[p]!=x)
		top[x]=x;
	else
		top[x]=top[fa[x]];
	for(int i=head[x];i!=-1;i=next[i])
	{
		if(to[i]!=fa[x])
		dfs2(to[i],x);
	}
}
int LCA(int x,int y)
{
	int tx=top[x],ty=top[y];
	while(1)
	{
		if(tx==ty)
		{
			return tx;
		}
		if(dep[tx]<dep[ty])
		{
			tx=top[fa[tx]];
		}
		else if(dep[tx]>dep[ty])
		{
			ty=top[fa[ty]];
		}
		else if(top[fa[tx]]!=top[fa[ty]])
		{
			tx=top[fa[tx]];
			ty=top[fa[ty]];
		}
		else
		{
			int fx=fa[tx];
			int fy=fa[ty];
			while(fx!=fy)
			{
				fx=fa[fx];
				fy=fa[fy];
			}
			return fx;
		}
	}
}
int main()
{
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=N;i++) head[i]=next[i]=to[i]=-1;
	for(int i=1;i<n;i++) scanf("%d",&f[i]);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&_u,&_v,&_w);
		add(_u,_v,_w);
	}
	for(int i=head[1];i!=-1;i=next[i])
		cout<<to[i]<<" ";

	
	return 0;
}
/*
	17 0
	0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
	1 2 0
	1 3 0
	1 4 0
	2 5 0
	3 6 0
	3 7 0
	4 8 0
	5 9 0
	5 10 0
	9 12 0
	9 13 0
	12 16 0
	10 14 0
	10 15 0
	14 17 0
	7 11 0
*/
