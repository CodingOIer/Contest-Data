#include<bits/stdc++.h>
using namespace std;
long long jl,o[27];
string s;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>s;
	for(int i=0;i<s.length();i++)
		o[s[i]-'a'+1]++;
	for(int i=1;i<=26;i++){
		if(o[i]==1) jl++;
		else
		if(o[i]>=2) jl=jl+o[i]*o[i];
	}
	std::cout<<jl;
	return 0;
 } /*
 takinanosakana 
 */
