#include<bits/stdc++.h>
using namespace std;
long long n,m,k;
long long l[3000],r[3000],lr[3000],big,f;
long long w[3000],jl;
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		std::cin>>l[i]>>r[i]; 
		lr[i]=r[i]-l[i]+1;
		if(lr[i]>big) {
			big=lr[i];
			f=i;
		}
	}
	for(int i=l[f];i<=r[f];i++)
		w[i]=1;
	l[f]=0;
	r[f]=0;
	big=0;
	for(int i=1;i<k;i++)	
	{
		big=0;
		for(int o=1;o<=m;o++)
		{
			jl=0;
			if(l[o]!=0)
			{
				for(int io=l[o];io<=r[o];io++)
				{
					if(w[io]!=1) jl++;
				}
			}
			if(jl>big){
		 		big=jl;
		 		f=o;
		 	}
		}
		for(int wer=l[f];wer<=r[f];wer++)
			w[wer]=1;
		l[f]=0;
		r[f]=0;	
	}
	jl=0;
	for(int i=1;i<=n;i++)
		if(w[i]==1) jl++;
	cout<<jl;
	return 0;
 }
