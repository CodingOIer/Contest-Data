#include<bits/stdc++.h>
using namespace std;
long long n,T,k;
int main()
{
	//freopen("fang.in","r",stdin);
	//freopen("fang.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>T;
	for(int i=1;i<=T;i++){
		cout<<"Case "<<i<<":"<<std::endl;
		cout;
	}
	return 0;
 } /*
 takinanosakana 
 */
