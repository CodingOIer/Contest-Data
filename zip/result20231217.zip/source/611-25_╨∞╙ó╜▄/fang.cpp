#include<bits/stdc++.h>
using namespace std;
long long T;
long long m[1000001],mm[1000001];
long long m1[1000001];
long long m2[1000001];
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>T;
	for(int i=1;i<=T;i++){
		int n,k;
		cin>>n>>k;		
		long long jl=0;
		for(int o=1;o<=n;o++)
		{
			m[o]=(o*o*o)%k;
			m1[o]=(o*o)%k;
			m2[o]=o%k;
		}
		for(int i1=1;i1<=n;i1++)
		{
			for(int i2=i1;i2<=n;i2++)
			{
				int mmmm=(m2[i1]+m1[i2])%k;
				for(int i3=i2;i3<=n;i3++)
				{
					if(m[i3]==mmmm) {
						jl++;
					}
					
				}
			} 
		} 
		cout<<"Case "<<i<<": ";
		cout<<jl<<endl;	
	}
	return 0;
 } 
