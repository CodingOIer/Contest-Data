#include<bits/stdc++.h>
using namespace std;
int jl;
int main()
{
	//freopen("fang.in","r",stdin);
	//freopen("fang.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	long long n;
	cin>>n;
	cout<<n%1000000007;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		/*if(i==2||i==n-1)
		{
			cout<<"";
		}
		else
		m=(m*i)%1000000007;
	}
//	cout<<m; 
m=m/2;
m=m/(n-1);
	//cout<<m%1000000007;
	for(int i=1;i<=n;i++)
	{
		for(int o=1;o<=n;o++)
		{
			for(int k=1;k<=n;k++)
			{
				for(int f=1;f<=n;f++)
				{
					for(int h=1;h<=n;h++)
					{
					if(i!=o&&i!=k&&i!=f&&o!=k&&o!=f&&k!=f&&o!=h&&k!=h&&f!=h&&i!=h)
					{
						cout<<i<<" "<<o<<" "<<k<<" "<<f<<" "<<h<<endl;
						jl++;
					}
					}
				}
			}
		}
	}
cout<<jl;*/
	return 0;
 } 
 /*//4 876675871 596627387
884421862
 4
	1 2 3 4
	1 2 4 3
	1 3 2 4
	1 3 4 2
	
2 1 3 4
2 4 3 1

3 1 2 4\3
3 4 2 1

4 2 1 3
4 2 3 1//1032593934
/////////10000000007
4 3 1 2
4 3 2 1
24
 1043113719690
 
 5
1 2 3 4 5
1 2 3 5 4
1 2 4 3 5
1 2 4 5 3
1 3 2 4 5
1 3 5 4 2











2 1 3 4 5
2 1 3 5 4
2 4 5 3 1


3 1 2 4 5
3 5 4 1 2
3 5 4 2 1

4 2 1 3 5
4 5 3 1 2
4 5 3 2 1











5 2 13 1 2 4
5 3 4 2 1
5 4 2 1 3
5 4 2 3 1
5 4 3 1 2
5 4 3 
120
 */
 
 
