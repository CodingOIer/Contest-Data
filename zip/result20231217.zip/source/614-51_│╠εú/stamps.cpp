#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
}
ll n,m,k;
struct kk{
	ll l,r,cha;
	int v;
}a[10000];
ll b[3000];
int cmp(kk x,kk y){
	return x.cha>y.cha;  
}
ll ans,sum,id,da;
int main(){
	in();
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>a[i].l>>a[i].r;  
		a[i].cha=a[i].r -a[i].l +1; 
	}
	sort(a+1,a+m+1,cmp);
	for(int o=a[1].l;o<=a[1].r;o++) b[o]++;
	for(int j=1;j<k;j++){
	    for(int i=2;i<=m;i++){
	    	if(sum>a[i].cha) break;
	    	if(a[i].v!=0) continue; 
		    ans=0;
	        for(int o=a[i].l;o<=a[i].r;o++){
	 	        if(b[o]==0) ans++;
	        }
	        if(ans>sum){
	        	sum=ans;
	        	id=i;
			}
	    }
			for(int o=a[id].l;o<=a[id].r;o++) b[o]++;
			a[id].v=1;
			da+=sum; 
	}
	da+=a[1].cha; 
	cout<<da;
}

