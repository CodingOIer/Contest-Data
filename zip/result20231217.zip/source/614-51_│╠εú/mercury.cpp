#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
}
string s;
ll a[100],ans; 
int main(){
	in();
	cin>>s;
	for(int i=0;i<s.size();i++){
		int x=s[i]-'a'+1;
		a[x]++;
	}
	for(int i=1;i<=26;i++){
		ans+=a[i]*a[i];
	}
	cout<<ans;
}

