#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
}
ll t,n,k;
ll ans;
int main(){
	in();
	cin>>t;
	ll i=1;
	while(t--){
		cin>>n>>k;
		for(ll a=1;a<=n;a++){
			for(ll b=a;b<=n;b++){
				for(ll c=b;c<=n;c++){
					ll sum=(c*c*c)-(a+b*b);
					sum%=k;
					//cout<<sum<<endl;
					if(sum==1) ans++;
				}
			}
		}
		cout<<"Case "<<i<<": "<<ans<<endl;
		i++;
		
	}
}
// 1+1=1*1*1%1;
