#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,t=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') t=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*t;
}
struct kkk{
	int l,r,ans,id;
}q[2001],as[2001];
int fk[2001],a[2001],cnt[2001],ans,dp[2001],mn,top;
bool cmp(kkk a,kkk b){
	return (fk[a.l]^fk[b.l])?fk[a.l]<fk[b.l]:a.r<b.r;
}
bool cmp2(kkk a,kkk b){
	return a.ans>b.ans;
}
void add(int x){
    if(!cnt[a[x]]) ans++;
    cnt[a[x]]++;
}
void del(int x){
    cnt[a[x]]--;
    if(!cnt[a[x]]) ans--;
}
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		a[i]=i;
	}
	for(int i=1;i<=m;i++){
		cin>>q[i].l>>q[i].r;
		as[i].l=q[i].l;
		as[i].r=q[i].r;
		q[i].id=i;
		as[i].id=i;
	}
	int sq=n/sqrt(m+1);
	for(int i=1;i<=n;i++){
		fk[i]=(i-1)/sq+1;
	}
	sort(q+1,q+1+m,cmp);
	int l=1,r=0;
	ans=0;
	for(int i=1;i<=m;i++){
		while(l<q[i].l) del(l++);
        while(l>q[i].l) add(--l);
        while(r>q[i].r) del(r--);
        while(r<q[i].r) add(++r);
        // cout<<l<<" "<<r<<endl;
        as[q[i].id].ans=ans;
	}
	ans=0;
	int kk=1;
	sort(as+1,as+1+m,cmp2);
	ans+=as[1].ans;
//	cout<<ans;
	for(int i=2;i<=k;i++){
//		cout<<as[i].l<<" "<<as[i].r<<endl;
		ans+=as[i].ans;
//		dp[i]=dp[i-1]-dp[i-1];
		for(int j=1;j<i;j++){
//			cout<<as[i].r<<" "<<as[j].l<<" "<<as[j].r<<" "<<as[i].l<<endl;
//			if(j==top){
//				continue;
//			}
			if(as[j].l<as[i].l){
				if(as[j].r>as[i].r){
					ans-=as[i].ans;
				}
				else{
					ans-=max(0,as[j].r-as[i].l+1);
				}
			}
			else{
				if(as[i].r>as[j].l){
					ans-=max(0,as[i].r-as[j].l+1);
				}
			}
		}
//		dp[i]=max(dp[i],dp[i]+ans);
	}
	cout<<ans;
}
