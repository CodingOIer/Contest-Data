#include<bits/stdc++.h>
using namespace std;
int a[26],ans;
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	string s;
	cin>>s;
	for(int i=0;i<s.size();i++){
		a[s[i]-'a']++;
	}
	for(int i=0;i<=25;i++){
		ans+=a[i]*a[i];
	}
	cout<<ans;
	return 0;
}
