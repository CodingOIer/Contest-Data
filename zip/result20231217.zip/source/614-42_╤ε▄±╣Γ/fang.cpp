#include<bits/stdc++.h>
using namespace std;
int mod,a[1000001],ton[1000001],c[1000001],ans=0;
int ksm(int a,int b){
	int sum=1;
	while(b){
		if(b&1){
			sum=sum*a%mod;
		}
		b>>=1;
		a=a*a%mod;
	}
	return sum;
}
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int t,ii=1;
	cin>>t;
	while(ii<=t){
		int n;
		ans=0;
		cin>>n>>mod;
		for(int i=1;i<=n;i++){
			for(int j=i;j<=n;j++){
				for(int k=j;k<=n;k++){
					if((i+j*j)%mod==k*k*k%mod){
						ans++;
//						cout<<i<<" "<<j*j<<" "<<k*k*k<<endl;
					}
				}
			}
		}
		cout<<"Case "<<ii<<":"<<ans<<endl;
		ii++;
	}
	
	return 0;
}

