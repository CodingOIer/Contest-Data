#include<bits/stdc++.h>
using namespace std;
int x[1003];
int t,n,k;
int main(){
	//freopen("mercury.in","r",stdin);
	//freopen("mercury.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d%d",&n,&k);
		for(int a=1;a<=n;a++)
		{
			for(int b=1;b<=n;b++)
			{
				for(int c=1;c<=n;c++)
				{
					if((a+b*b)%k==c*c*c%k) x[i]++;
				}
			}
		}
	}
	for(int i=1;i<=t;i++) cout<<"Case "<<i<<':'<<x[i]<<endl;
	return 0;
}
