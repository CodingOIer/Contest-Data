#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2005;
int n,m,k,ans;
int dp[N][N];
struct sss{
	int l,r;
}w[N];
bool cmp(sss x,sss y) {
	return x.l<=y.l;
}
int main() {
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++) {
		cin>>w[i].l>>w[i].r;
	}
	sort(w+1,w+m+1,cmp);
	for(int i=1;i<=m;i++) {
		for(int j=1;j<=k;j++) {
			for(int p=i-1;p>=0;p--) {
				int x;
				x=w[i].r-w[i].l+1;
				if(w[p].r>=w[i].l) {
					x-=w[p].r-w[i].l+1;
				}
				dp[i][j]=(dp[i][j],dp[p][j-1]+x);
			}
			if(j==k) ans=max(dp[i][j],ans);
		} 
	}
	cout<<ans;
	return 0;
}

