#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int n,Q,f[N],fa[N],ans;
int l[N],dep[N],siz[N];
vector<int> son[N],L[N];
void add(int s,int t,int o) {
	son[s].push_back(t);
	L[s].push_back(o);
}
void dfs1(int now,int fat) {
	fa[now]=fat;
	dep[now]=dep[fat]+1;
	siz[now]=1;
	for(int i=0;i<son[now].size();i++) {
		if(son[now][i]==fat) continue ;
		l[son[now][i]]=L[now][i];
		dfs1(son[now][i],now);
		siz[now]+=siz[son[now][i]];
	}
}
void baolipashu(int s,int t,int o) {
	if(dep[s]<dep[t]) swap(s,t);
	int sum1=0,sum2=0;
	ans=0;
	while(dep[s]>dep[t]) {
		if(l[s]<o) {
			ans+=f[sum1];
			sum1=0;
		} else {
			sum1++;
		}
		s=fa[s];
	}
	if(s==t) {
		ans+=f[sum1];
		return ;
	}
	while(s!=t) {
		if(l[s]<o) {
			ans+=f[sum1];
			sum1=0;
		} else {
			sum1++;
		}
		if(l[t]<o) {
			ans+=f[sum2];
			sum2=0;
		} else {
			sum2++;
		}
		s=fa[s];
		t=fa[t];
	}
	ans+=f[sum1+sum2];
}
struct sss{
	int u,v,w,id,ans;
}q[N];
bool cmp1(sss x,sss y) {
	return x.w > y.w ;
}
bool cmp2(sss x,sss y) {
	return x.id<y.id ;
}
struct ss{
	int l,r,t1,t2;
} k[N];
int cnt ;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n>>Q;
	for(int i=1;i<n;i++) cin>>f[i];
	int u,v,w;
	int Max=0;
	for(int i=1;i<n;i++) {
		cin>>u>>v>>w;
		add(u,v,w);
		add(v,u,w);
	}
	dfs1(1,0);
	for(int i=1;i<=n;i++) Max=max(Max,(int)son[i].size());
//	if(Max<=2) {
//		for(int i=1;i<=n;i++) k[i].l=k[i].r=k[i].o=0;
//		for(int i=1;i<=Q;i++) {
//			cin>>q[i].u>>q[i].v>>q[i].w;
//			q[i].id=i;
//			q[i].ans=0;
//		}
//		sort(q+1,q+Q+1,cmp1);
//		for(int i=1;i<=n;i++) {
//			if(l[i]>=w) {
//				if(l[i-1]<w)
//					k[++cnt].l=k[cnt].r=i;
//				k[cnt].r++;
//			}
//		}
//		for(int i=1;i<=Q;i++) {
//			if(q[i].w!=q[i-1].w) {
//				for(int i=1;i<=cnt;i++) {
//					if(k[i].o) continue ;
//					while(l[k[i].l]>=q[i].w)
//						k[i].l--;
//					while(l[k[i].r+1]>=q[i].w)
//						k[i].r++;
//				}
//			}
//		}
//	} else {
		while(Q--) {
			cin>>u>>v>>w;
			baolipashu(u,v,w);
			cout<<ans<<'\n';
		}
//	}
	return 0;
}

