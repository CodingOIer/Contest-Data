#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=1e9+7;
ll T,n,ans;
ll biao[1005]={0,1,1,2,4,6,9,14,21,31,46,68,100,147,216,317,465,682,1000,1466,2149,3150,4617,6767,9918,14536,21304,31223,45760,67065,98289,144050,211116,309406,453457,664574,973981,1427439,2092014,3065996,4493436,6585451,9651448,14144885};
int main() {
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>T;
	while(T--) {
		cin>>n;
		ans^=biao[n];
	}
	cout<<ans;
	return 0;
}
/*
�����һ�������� 

1
1 2
1 3
1 3 2 4
1 3 4 2

*/
