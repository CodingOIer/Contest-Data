#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e6+5;
ll T,n,k,ans;
ll sum[N];
void exgcd(ll a,ll b,ll &x,ll &y) {
	if(b==0) {
		x=1;
		y=0;
		cout<<x<<' '<<y<<'\n';
		return ;
	}
	exgcd(b,a%b,x,y);
	ll t=x;
	x=t-y*(a/b);
	y=t;
	cout<<x<<' '<<y<<'\n';
}
int main() {
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>T;
	int oo=0;
	while(T--) {
		cin>>n>>k;
		oo++;
		ans=0;
		for(ll i=0;i<=n;i++) {
			for(ll j=0;j<=n;j++) {
				for(ll p=0;p<=n;p++)
					if(i*i*i%k==(j*j+p)%k)
						ans++;
			}
		}
		cout<<"Case"<<' '<<oo<<':'<<' '<<ans<<"\n";
	}
	return 0;
}
/*

(a+b^2)%k==c^3%k

(a+b^2)/c^3==1 (%k������)

(a+b^2)+r*k==c^3 / (a+b^2)==c^3+r*k

a*b^mod==1

a%b==?

a=b,b=a%b

b%(a%b)==0

5 6
	5,0
6 1
	0,1
1 0
	1,0
*/
