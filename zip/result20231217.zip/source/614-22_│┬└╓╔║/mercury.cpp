#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
ll n,e[26];
ll ans;
string s;
int main() {
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	n=s.size();
	s=' '+s; 
	for(int i=1;i<=n;i++) {
		e[s[i]-'a']++;
	}
	for(int i=0;i<26;i++) {
		if(e[i]==0) continue;
		ans+=e[i]*e[i];
	}
	cout<<ans;
	return 0;
}

