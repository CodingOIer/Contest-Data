#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,q,ans,f[N];
int lt[N],rt[N],fa[N],Fa[N],dep[N];
vector<int>l[N],w[N];
void sth(int i,int F)
{
	fa[i]=F;
	dep[i]=dep[F]+1;
	for(int j=0;j<l[i].size();j++)
		if(l[i][j]!=fa[i]) Fa[l[i][j]]=w[i][j],sth(l[i][j],i);
}
void lca(int u,int v)
{
	while(u!=v)
	{
		if(dep[u]>dep[v]) lt[++lt[0]]=Fa[u],u=fa[u];
		else rt[++rt[0]]=Fa[v],v=fa[v];
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdou);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>q;
	for(int i=1;i<n;i++)
		cin>>f[i];
	for(int i=1;i<n;i++)
	{
		int u,v,W;
		cin>>u>>v>>W;
		l[u].push_back(v);
		w[u].push_back(W);
		l[v].push_back(u);
		w[v].push_back(W);
	}
	dep[1]=1;
	sth(1,0);
	while(q--)
	{
		int u,v,W;
		ans=0;
		cin>>u>>v>>W;
		lt[0]=rt[0]=0;
		int L=0,R=0;
		lca(u,v);
		for(int i=1;i<=lt[0];i++)
			if(lt[i]>=W) L++;
			else ans+=f[L],L=0;
		for(int i=1;i<=rt[0];i++)
			if(rt[i]>=W) R++;
			else ans+=f[R],R=0;
		ans+=f[L+R];
		cout<<ans<<endl;
	}
	return 0;
}
