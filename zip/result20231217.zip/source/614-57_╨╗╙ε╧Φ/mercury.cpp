#include <bits/stdc++.h>
#define int long long
using namespace std;
string s;
int l,ans,sum[128];
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdou);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	l=s.length();
	for(int i=0;i<l;i++)
		sum[s[i]]++;
	for(int i='a';i<='z';i++)
		ans+=sum[i]+sum[i]*(sum[i]-1);
	cout<<ans;
	return 0;
}
