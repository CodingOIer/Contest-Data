#include <bits/stdc++.h>
using namespace std;
const int N=2005;
int n,m,k,ans,u[N],v[N];
vector<int>l[N];
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdou);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		cin>>u[i]>>v[i];
		for(int j=u[i];j<=v[i];j++)
			l[j].push_back(i);
	}
	int id=1;
	while(id<=n&&k)
	{
		if(l[id].size()==0)
		{
			id++;
			continue;
		}
		int Mx=0;
		for(int j=1;j<l[id].size();j++)
			if(v[l[id][j]]-id>v[l[id][Mx]]-id) Mx=j;
		k--;
		ans+=v[l[id][Mx]]-id+1;
		id=v[l[id][Mx]]+1;
	}
	cout<<ans;
	return 0;
}
