#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int t,n,ans,sum;
bool vis[25];
void dfs(int i,int res)
{
	if(res==n)
	{
		sum++;
		return;
	}
	for(int j=i+1;j<=i+2&&j<=n;j++)
		if(!vis[j])
		{
			vis[j]=1;
			dfs(j,res+1);
			vis[j]=0;
		}
	for(int j=i-1;j>=i-2&&j>=1;j--)
		if(!vis[j])
		{
			vis[j]=1;
			dfs(j,res+1);
			vis[j]=0;
		}
}
signed main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdou);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>t;
	while(t--)
	{
		cin>>n;
		sum=0;
		memset(vis,0,sizeof(vis));
		vis[1]=1;
		dfs(1,1);
		if(!ans) ans=sum;
		else ans^=sum; 
	}
	cout<<ans;
	return 0;
}
