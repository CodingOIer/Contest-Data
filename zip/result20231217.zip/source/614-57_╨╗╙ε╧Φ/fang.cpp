#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e6+5;
int T,n,k,ans,sum[N];
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdou);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>T;
	for(int t=1;t<=T;t++)
	{
		ans=0;
		cin>>n>>k;
		for(int a=1;a<=n;a++)
		{
			for(int i=a;i<=n;i++)
				sum[i*i*i%k]++;
			for(int b=a;b<=n;b++)
			{
				ans+=sum[(a%k+b*b%k)%k];
				sum[b*b*b%k]--;
			}
		}
		cout<<"Case "<<t<<":"<<ans<<endl;
	}
	return 0;
}
