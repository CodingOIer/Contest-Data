#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,t[1000000],l,r,ky[5][114514],ans=0;
signed main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>l>>r;
		ky[1][i]=r-l+1;
		ky[2][i]=l;
		ky[3][i]=r;
	}
	for(int i=1;i<=k;i++){
		int mx=-1,mi; 
		for(int j=1;j<=m;j++){
		int sum=0;
			if(ky[0][j]==0){
			for(int u=ky[2][j];u<=ky[3][j];u++){
				if(t[u]==0)
				sum++;
			}
			if(sum>mx)
			mx=sum,mi=j;
//			cout<<mi<<endl;
			}
		}
		ky[0][mi]=1;
		for(int j=ky[2][mi];j<=ky[3][mi];j++){
			t[j]=1;
		}
//		for(int j=1;j<=n;j++)
//		cout<<t[j]<<" ";
//		cout<<endl;
	}
	for(int i=1;i<=n;i++)
	{
		if(t[i]!=0)
		ans++;
	}
	cout<<ans;
}
