#include<bits/stdc++.h>
#define int unsigned long long
#define MOD 1000000007
using namespace std;
int n,a[5][10000004],sum;
void high(int i){
	a[4][i]=(a[4][i-1]+a[4][i-3])%MOD;
	a[3][i]=(a[3][i-1]+a[4][i-1])%MOD;
	a[2][i]=(a[2][i-1]+a[3][i-1])%MOD;
	a[1][i]=(a[1][i-1]+a[2][i-1])%MOD;
}
signed main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	a[1][1]=1;a[1][2]=1;a[1][3]=2;a[1][4]=4;
	a[2][1]=0;a[2][2]=1;a[2][3]=2;a[2][4]=2;
	a[3][1]=1;a[3][2]=1;a[3][3]=0;a[3][4]=1;
	a[4][1]=0;a[4][2]=-1;a[4][3]=1;a[4][4]=1;
	for(int i=5;i<=10000000;i++)
	high(i);
	int n,h;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>h;
		sum^=a[1][h];
	}
	cout<<sum;
	return 0;
}
//4�׵Ȳ��Ҫ�ڻ�������������
