#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,x,y,sum;
signed main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld%lld",&x,&y);
		sum=0;
		for(int c=1;c<=x;c++)
		for(int b=1;b<=c;b++)
		for(int a=1;a<=b;a++)
		{
			if((a+b*b)%y==c*c*c%y)
			sum++;
		}
		printf("Case %lld:%lld\n",i,sum);
	} 
}

