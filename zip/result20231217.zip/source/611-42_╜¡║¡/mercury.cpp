#include<bits/stdc++.h>
#define int long long
using namespace std;
string s;
int a[100001],sum;
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++){
	a[s[i]]++;
//	int u=s[i];
//	cout<<u<<endl;
	}
	for(int i=1;i<=100000;i++)
		sum+=a[i]*a[i];
	cout<<sum;
}

