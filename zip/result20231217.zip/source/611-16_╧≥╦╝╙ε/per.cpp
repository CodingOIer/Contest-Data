#include<bits/stdc++.h>
using namespace std;
long long n,f[10000010],a[10000010],maxx,ans;
int main(){
    freopen("per.in","r",stdin);
    freopen("per.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		maxx=max(maxx,a[i]);
	}
	f[1]=f[2]=1;
	f[3]=2;
	for(int i=4;i<=n;i++)f[i]=(f[i-1]+f[i-3]+1)%1000000007;
	for(int i=1;i<=n;i++){
		ans^=f[a[i]];
	}
	cout<<ans;
	return 0;
}
