#include<bits/stdc++.h>
using namespace std;
long long number[50],ans;
string s;
int main(){
    freopen("mercury.in","r",stdin);
    freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)number[s[i]-'a']++;
	for(int i=0;i<26;i++)ans+=number[i]*number[i];
	cout<<ans;
	return 0;
}
