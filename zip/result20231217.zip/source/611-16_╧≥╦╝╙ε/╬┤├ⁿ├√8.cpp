#include<bits/stdc++.h>
using namespace std;
int t,n,k,ans;
int main(){
//  freopen("fang.in","r",strin);
//  freopen("fang.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>k;
		ans=0;
		for(int c=1;c<=n;c++){
			for(int b=1;b*b<=c*c*c%k;b++){
				ans++;
			}
		}
		cout<<"Case "<<i<<": "<<ans<<endl;
	}
	return 0;
}

