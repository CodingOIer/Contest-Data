#include<bits/stdc++.h>
using namespace std;
long long n,m,k,l[2010],r[2010],buytao[2010],buydan[2010],qzh[2010],ans;
int main(){
    freopen("stamps.in","r",stdin);
    freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)cin>>l[i]>>r[i];
	for(int i=1;i<=k;i++){
		int ansnum=0,ansid;
		for(int j=1;j<=n;j++){
			if(buytao[j]==1)continue;
			long long sum=qzh[r[j]]-qzh[l[j]-1];
			long long num=r[j]-l[j]+1-sum;
			if(num>ansnum){
				ansnum=num;
				ansid=j;
			}
		}
		buytao[ansid]=1;
		ans+=ansnum;
		long long cnt=0;
		for(int j=l[ansid];j<=r[ansid];j++){
			if(buydan[j]==0){
				buydan[j]=1;
				qzh[j]=qzh[j-1]+1;
				cnt++;
			}
		}
		for(int j=r[ansid]+1;j<=n;j++)qzh[j]+=cnt;
	}
	cout<<ans;
	return 0;
}
