#include<bits/stdc++.h>
#define int long long
using namespace std;
int t,n,k,ans;
signed main(){
    freopen("fang.in","r",stdin);
    freopen("fang.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>k;
		ans=0;
		for(int a=1;a<=n;a++){
			for(int b=a;b<=n;b++){
				for(int c=b;c<=n;c++){
					if((a+b*b)%k==c*c*c%k&&a<=b&&b<=c){
						ans++;
					}
				} 
			}
		}
		cout<<"Case "<<i<<": "<<ans<<endl;
	}
	return 0;
}
