#include<bits/stdc++.h>
#define int long long
using namespace std ; 
int n , q , f[123456] , h , fa[123456] , son[123456] , sz[123456] , top[123456] , deep[123456] ;
struct node{
	int to ;
	int w ;
};
vector<node> e[123456] ;
void dfs1(int num,int fat){
	fa[num] = fat ;
	deep[num] = deep[fat]+1 ;
	sz[num] = 1 ;
	for(auto x:e[num]){
		if(x.to==fat) continue ;
		dfs1(x.to,num) ;
		sz[num] += sz[x.to] ;
		if(!son[num]||sz[son[num]]<sz[x.to]) son[num] = x.to ;
	}
}
void dfs2(int num,int head){
	top[num] = head ;
	if(son[num]) dfs2(son[num],head) ;
	for(auto x:e[num]){
		if(x.to==fa[num]||x.to==son[num]) continue ;
		dfs2(x.to,x.to) ;
	}
}
int LCA(int x,int y){
	while(top[x]!=top[y]){
		if(deep[top[x]]<=deep[top[y]]) swap(x,y) ;
		x = fa[top[x]] ;
	}
	if(deep[x]<deep[y]) return x ;
	else return y ;
}
signed main(){
	freopen("tree.in","r",stdin) ;
	freopen("tree.out","w",stdout) ;
	cin >> n >> q ;
	for(int i=1;i<n;i++) scanf("%lld",f+i) ;
	for(int i=1;i<n;i++){
		int u , v , w ;
		scanf("%lld%lld%lld",&u,&v,&w) ;
		e[u].push_back(node{v,w}) ;
		e[v].push_back(node{u,w}) ;
	}
	dfs1(1,0) ;
	dfs2(1,1) ;
	for(int i=1;i<=q;i++){
		int u , v , w , t=0 , ans=0 ;
		string s ;
		scanf("%lld%lld%lld",&u,&v,&w) ;
		int lc = LCA(u,v) , x=u , y=v ;
		while(x!=lc){
			int to_w=0 ;
			for(auto l:e[x]){
				if(l.to==fa[x]){
					to_w = l.w ;
					break ;
				}
			}
//			cout << to_w << " " ;
			if(to_w>=w) s += '1' ;
			else s += '0' ;
			x = fa[x] ;
		}
//		cout << endl ;
		while(y!=lc){
			int to_w=0 ;
			for(auto l:e[y]){
				if(l.to==fa[y]){
					to_w = l.w ;
					break ;
				}
			}
//			cout << to_w << " " ;
			if(to_w>=w) s += '1' ;
			else s += '0' ;
			y = fa[y] ;
		}
//		cout << endl ;
		for(int j=0;j<s.size();j++){
			if(s[j]=='1') t++ ;
			else{
				ans += f[t] ;
				t = 0 ;
			}
		}
		ans += f[t] ;
//		cout << lc << endl ;
		printf("%lld\n",ans) ;
	}
	return 0 ;
}
/*
8 2
-1 -2 -4 -8 1 4 6
1 2 2
1 3 6
1 6 4
2 8 5
2 5 5
2 4 1
2 7 5
1 8 0


*/
