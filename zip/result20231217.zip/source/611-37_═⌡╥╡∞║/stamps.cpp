#include<bits/stdc++.h>
using namespace std ;
int n , m , k , ans ;
struct node{
	int a , b ;
}a[2134];
bool t[2123] ,f[2123] ;
void dfs(int u){
	if(u==k){
		int temp=0 ;
		for(int i=1;i<=n;i++) temp += t[i] ;
		ans = max(ans,temp) ;
		return ;
	}
	for(int i=1;i<=m;i++){
		if(!f[i]){
			f[i] = 1 ;
			int temp[2123] ;
			for(int i=1;i<=n;i++)
				temp[i] = t[i] ;
			for(int j=a[i].a;j<=a[i].b;j++)
				t[j] = 1 ;
			dfs(u+1) ;
			for(int i=1;i<=n;i++)
				t[i] = temp[i] ;
			f[i] = 0 ;
		}
	}
}
int main(){
	freopen("stamps.in","r",stdin) ;
	freopen("stamps.out","w",stdout) ;
	cin >> n >> m >> k ;
	for(int i=1;i<=m;i++)
		scanf("%d%d",&a[i].a,&a[i].b) ;
	dfs(0) ;
	cout << ans ;
	return 0 ;
}
