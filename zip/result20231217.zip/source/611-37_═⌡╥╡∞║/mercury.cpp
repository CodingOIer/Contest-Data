#include<bits/stdc++.h>
using namespace std ;
long long t[123] , ans=0 ;
char a ;
int main(){
	freopen("mercury.in","r",stdin) ;
	freopen("mercury.out","w",stdout) ;
	while(cin >> a){
		t[a-'a'+1]++ ;
	}
	for(int i=1;i<=26;i++){
		ans += t[i]*t[i] ;
	}
	cout << ans ;
	return 0 ;
}
