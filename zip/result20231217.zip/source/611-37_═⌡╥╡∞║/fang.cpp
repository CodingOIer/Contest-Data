#include<bits/stdc++.h>
#define int long long
using namespace std ; 
int T , n , mod ;
signed main(){
	freopen("fang.in","r",stdin) ;
	freopen("fang.out","w",stdout) ;
	cin >> T ;
	for(int i=1;i<=T;i++){
		int ans=0 ;
		scanf("%lld%lld",&n,&mod) ;
		if(mod==1) printf("Case %lld: %lld\n",i,n*n*n) ;
		for(int i=n;i;i--){
			for(int j=i;j;j--){
				for(int k=j;k;k--){
					if((j*j+k)%mod==(i*i*i)%mod)
						ans++ ;
				}
			}
		}
		printf("Case %lld: %lld\n",i,ans) ;
	} 
	return 0 ;
}
