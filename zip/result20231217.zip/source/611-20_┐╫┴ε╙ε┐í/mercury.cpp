#include<bits/stdc++.h>
using namespace std;
char s[100001];
int i,n,l;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	sort(s,s+strlen(s));
	for(i=1;i<strlen(s);i++)
	{
		if(s[i]!=s[i-1])
		{
			n+=(i-l)*(i-l-1);
			l=i;
		}
	}
	n+=(i-l)*(i-l-1);
	cout<<n+strlen(s);
	return 0;
}
