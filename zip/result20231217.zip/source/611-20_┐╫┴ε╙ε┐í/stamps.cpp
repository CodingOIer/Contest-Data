#include<bits/stdc++.h>
using namespace std;
struct d{
	int l,r;
}a[2001];
int n,m,k,i,s,j,b[2001],c[2001];
int cmp(d x,d y)
{
	if(x.l!=y.l)return x.l<y.l;
	else return x.r<y.r;
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(i=1;i<=m;i++)cin>>a[i].l>>a[i].r;
	sort(a+1,a+m+1,cmp);
	for(i=2;i<=m;i++)
	{
		if(a[i].l!=a[i-1].l)
		{
			for(j=a[i-1].l;j<=a[i-1].r;j++)
			{
				if(b[j]==0)
				{
					b[j]=1;
					c[i-1]++;
				}
			}
		}
	}
	for(j=a[i].l;j<=a[i].r;j++)
	{
		if(b[j]==0)
		{
			b[j]=1;
			c[i-1]++;
		}
	}
	sort(c+1,c+m+1);
	for(i=m;i>=m-k+1;i--)s+=c[i];
	cout<<s;
	return 0;
}
