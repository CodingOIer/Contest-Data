#include <bits/stdc++.h>
using namespace std;
long long T,n,k,ans=0,l=0; 
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio();
	cin.tie(0);
	cout.tie(0);
	cin>>T;
	while(T--)
	{
		cin>>n>>k;
		l++;
		ans=0;
		if(k==1)
		{
			for(long long i=1;i<=n;i++)
			{
				ans+=i*(i+1)/2;
			}
			cout<<"Case "<<l<<":"<<ans<<endl;
			continue;
		} 
		for(long long a=1;a<=n;a++)
		{
			for(long long b=1;b<=n;b++)
			{
				long long x=(a*a)%k,y=(b*b*b)%k,o;
				o=y-x;
				if(a>b)
				{
					continue;
				}
				if(o<0)
				{
					o+=k;
				}
				if(o==0)
				{
					o=k;
				}
				if(a-o>=0)
				{
					ans++;
				} 
				else
				{
				 	continue;
				}
			}
		} 
		cout<<"Case "<<l<<":"<<ans<<endl;
	}
	return 0;
}

