#include <bits/stdc++.h>
using namespace std;
long long n,a[27],x,ans=0; 
string s;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio();
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	n=s.size();
	for(long long i=0;i<=n-1;i++)
	{
		x=s[i]-'a';
		a[x]++;
	}
	for(long long i=0;i<=25;i++)
	{
		ans+=a[i]*a[i];
	}
	cout<<ans<<endl;
	return 0;
}
