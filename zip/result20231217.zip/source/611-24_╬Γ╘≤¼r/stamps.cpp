#include<bits/stdc++.h>
using namespace std;

struct t{
	int l,r,x;
}z[2002];

int n,m,k,ix,fx,h;

int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>z[i].l>>z[i].r;
	}
	for(int i=1;i<=k;i++){
		if(h==n){
			break;
		}
		ix=0;
		fx=-1;
		for(int j=1;j<=m;j++){
			if(z[j].x==0 && z[j].r-z[j].l>fx){
				ix=j;
				fx=z[j].r-z[j].l;
			}
		}
		if(fx==-1){
			break;
		}
		z[ix].x=1;
		h=h+fx+1;
		for(int j=1;j<=m;j++){
			if(z[j].x==0){
				if(z[j].l>=z[ix].l && z[j].r<=z[ix].r){
					z[j].x=1;
				}else{
					if(z[j].l<=z[ix].l && z[j].r<=z[ix].r && z[j].r>=z[ix].l){
						z[j].r=z[ix].l-1;
					}else if(z[j].l>=z[ix].l && z[j].r>=z[ix].r && z[j].l<=z[ix].r){
						z[j].l=z[ix].r+1;
					}
					if(z[j].l>z[j].r){
						z[j].x=1;
					}
				}
			}
		}
	}
	cout<<h;
	return 0;
}

