#include<bits/stdc++.h>
using namespace std;

string s;
long long t[30],sl,h;

int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	sl=s.size();
	for(int i=0;i<sl;i++){
		t[s[i]-'a']++;
	}
	for(int i=0;i<30;i++){
		h=h+t[i]*t[i];
	}
	cout<<h;
	return 0;
}
