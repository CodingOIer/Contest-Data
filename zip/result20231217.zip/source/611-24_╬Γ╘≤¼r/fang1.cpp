#include<bits/stdc++.h>
using namespace std;

long long t,n,k,h;

long long js(long long a,long long b,long long c){
	long long l=0;
	for(long long x=a;x<=n;x=x+k){
		for(long long y=b;y<=n;y=y+k){
			if(x<=y){
				for(long long z=c;z<=n;z=z+k){
					if(y<=z){
						l++;
					}else{
						break;
					}
				}
			}else{
				break;
			}
		}
	}
	return l;
}

int main(){
//	freopen("","r",stdin);
//	freopen("","w",stdout);
	cin>>t;
	for(long long i=1;i<=t;i++){
		cin>>n>>k;
		h=0;
		for(long long a=1;a<=n && a<=k;a++){
			for(long long b=a;b<=n && b<=k;b++){
				for(long long c=b;c<=n && c<=k;c++){
					if((a%k+(b%k)*(b%k))%k==(c%k)*(c%k)%k*(c%k)%k){
						h=h+js(a,b,c);
					}
				}
			}
		}
		cout<<"Case "<<i<<": "<<h<<endl;
	}
	return 0;
}
/*
4 2
Case 4: 16
1 1 1 0
    2 8
  2 2 0
2 2 2 8

5 3
Case 5: 21

*/
