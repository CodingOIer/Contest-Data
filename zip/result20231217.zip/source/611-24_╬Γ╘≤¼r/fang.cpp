#include<bits/stdc++.h>
using namespace std;

long long t,n,k,h;

int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(long long i=1;i<=t;i++){
		cin>>n>>k;
		h=0;
		for(long long a=1;a<=n && a<=k;a++){
			for(long long b=a;b<=n && b<=k;b++){
				for(long long c=b;c<=n && c<=k;c++){
					if((a%k+(b%k)*(b%k))%k==(c%k)*(c%k)%k*(c%k)%k){
						h=h+((n-a)/k+1)*((n-b)/k+1)*((n-c)/k+1);
					}
				}
			}
		}
		cout<<"Case "<<i<<": "<<h<<endl;
	}
	return 0;
}

