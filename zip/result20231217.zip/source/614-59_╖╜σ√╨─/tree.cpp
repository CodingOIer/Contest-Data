#include<bits/stdc++.h>
using namespace std;
const int mx = 1e5 + 5;
int n,f[mx],q;
int cnt,siz[mx],son[mx],fa[mx],dep[mx],top[mx],dfn[mx];
vector< pair<int,int> > v[mx];
void dfs1(int u,int f)
{
	fa[u] = f,dep[u] = dep[f] + 1,siz[u] = 1;
	for(int i = 0;i < v[u].size();i++)
		if(v[u][i].first != f)
		{
			dfs1(v[u][i].first,u);
			son[u] = (siz[v[u][i].first] > siz[son[u]] ? v[u][i].first : son[u]),siz[u] += siz[v[u][i].first];
		}
}
void dfs2(int u,int to)
{
	dfn[u] = ++cnt,top[u] = to;
	if(son[u]) dfs2(son[u],to);
	for(int i = 0;i < v[u].size(); i++)
		if(v[u][i].first != fa[u] && v[u][i].first != son[u])
			dfs2(v[u][i].first,v[u][i].first);
}
int lca(int u,int v)
{
	if(top[v] == v) swap(u,v);
	while(top[u] != top[v]) 
	{
		if(dep[u] <= dep[v]) swap(u,v);
		cout << u << " " << v << "\n";
		u = fa[top[u]];
	}
	return (dep[u] < dep[v] ? u : v);
}
int main()
{
	cin >> n >> q;
	for(int i = 1;i < n; i++) cin >> f[i];
	for(int i = 1;i < n; i++)
	{
		int x,y,ww;
		cin >> x >> y >> ww;
		v[x].push_back(make_pair(y,ww));
		v[y].push_back(make_pair(x,ww));
	}
	dfs1(1,1);dfs2(1,1);
	for(int i = 1;i <= n; i++)
		for(int j = 1;j <= n;j++)
			cout << i << " " << j << " : " << lca(i,j) << "\n";
//	cout << lca(8,9);
	return 0;
}
/*
9 1
1 2 3 4 5 6 7 8 
1 2 5
1 3 3
1 4 2
2 5 3
2 6 4
3 7 7
7 8 8
7 9 5
*/
