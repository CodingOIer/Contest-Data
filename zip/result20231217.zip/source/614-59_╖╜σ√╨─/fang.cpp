#include<bits/stdc++.h>
using namespace std;
#define int long long
int read()
{
	int res = 0,ch = getchar();
	while(isdigit(ch)) res = (res << 3) + (res << 1) + (ch ^ 48);
	return res;
}
const int mx = 1e6 +5;
int t,n[mx],k[mx],ans[mx];
void print(){for(int i = 1;i <= t; i++) cout << "Case " << i << ": " << ans[i] << "\n";return;}
void p(int a,int b,int c,int k){cout << a << " " << b << " " << c << " become " << a << " " << b * b << " " << c * c * c << "  The ex is  : ( " << a << " + " << b * b << " ) % " << k << "  = " << c * c * c << "\n";}
bool check(int a,int b,int c,int k)
{
	if(a > b || b > c) return 0; 
	b = b * b,c = c * c * c;
	return (a + b) % k == c % k;
}
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin >> t;
	for(int i = 1;i <= t; i++) cin >> n[i] >> k[i];
	for(int i = 1;i <= t; i++)
	{
		if(k[i] == 1) ans[i] = 1;
		else
		{
			for(int a = 1;a <= n[i]; a++)	
				for(int b = a;b <= n[i]; b++)
					for(int c = b;c <= n[i]; c++)
						if(check(a,b,c,k[i]))
							ans[i]++;
		}
	}
	print(); 
	return 0;
}
