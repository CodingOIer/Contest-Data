#include<bits/stdc++.h>
using namespace std;
#define ll long long 
string s;
int c[26],len;
ll ans;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin >> s;
	len = s.length();
	for(int i = 0;i < len; i++) c[s[i] - 'a']++;
	for(int i = 0;i < 26; i++) ans += (c[i] ? c[i] * c[i] : 0);
	cout << ans;
	return 0;
}
