#include<bits/stdc++.h>
using namespace std;
const int mx = 2005;
int n,m,k,f[mx][mx],l,r,ans = -1,s[mx],cnt,tot,t[mx],vis[mx];
void dfs(int x,int l)
{
	if(x > n)
	{
		if(tot != k) return;
		memset(s,0,sizeof(s));cnt = 0;
		for(int i = 1;i <= tot; i++)
			for(int j = 1;j <= n; j++)
				if(f[j][t[i]] != 0)
					if(s[j] == 0) cnt++,s[j] = 1;
//		for(int i = 1;i <= tot; i++) cout << t[i] << " ";
		ans = max(ans,cnt);
		return;
	}
	for(int i = 1;i <= n; i++)
		if(!vis[i])
		{
			t[++tot] = i;
			dfs(x + 1,l + 1);
			tot--;
			dfs(x + 1,l);
		}
		else dfs(x + 1,l);
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin >> n >> m >> k;
	for(int i = 1;i <= m; i++)
	{
		cin >> l >> r;
		for(int j = l;j <= r; j++) f[j][i] = i;
	}
	dfs(1,0);
	cout << ans;
	return 0;
}
