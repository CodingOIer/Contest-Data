#include<bits/stdc++.h>
using namespace std;
int n,q,a[100010],ans,head[100010],dep[100010],cnt,x,y,z,f[100010],o,bj[100010],fa1[100010],faz[100010];
string s;
vector<int>lc,lc1;
int find(int x)
{
	if(f[x] == x) return x;
	return f[x] = find(f[x]);
}
struct ww
{
	int to,z,nxt;
}tr[200010];
struct w
{
	int l,r,w,id;
}b[100010];
void add(int x,int y,int z)
{
	tr[++cnt].z = z;
	tr[cnt].to = y;
	tr[cnt].nxt = head[x];
	head[x] = cnt;
}
bool cmp(w x,w y)
{
	return x.w > y.w;
}
void dfs(int x,int fa,int sd)
{
	dep[x] = sd; fa1[x] = fa; 
	for(int i = head[x];i;i = tr[i].nxt)
	{
		int y = tr[i].to;
		if(y != fa) dfs(y,x,sd + 1),faz[y] = tr[i].z;
	}
	for(int i = 0;i < q;i++) if(!bj[i + 1] && f[find(lc[i])] == f[find(lc1[i])]) bj[i + 1] = x;
	f[x] = f[fa];
}
void dfs1(int x,int mb,int qq)
{
	if(x == mb) return;
	if(qq <= faz[x]) o++;
	else ans += a[o],o = 0;
	dfs1(fa1[x],mb,qq);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i = 1;i < n;i++) scanf("%d",&a[i]);
	for(int i = 1;i <= n;i++) f[i] = i;
	for(int i = 1;i < n;i++) scanf("%d%d%d",&x,&y,&z),add(x,y,z),add(y,x,z);
	for(int i = 1;i <= q;i++) 
	{
		scanf("%d%d%d",&b[i].l,&b[i].r,&b[i].w);
		lc.push_back(b[i].l); lc1.push_back(b[i].r);
	}
	dfs(1,1,1);
	for(int i = 1;i <= q;i++) 
	{
		ans = 0;
		dfs1(b[i].l,bj[i],b[i].w);ans += a[o]; o = 0;dfs1(b[i].r,bj[i],b[i].w);ans += a[o];
		printf("%d\n",ans);
	}
	return 0;
}

