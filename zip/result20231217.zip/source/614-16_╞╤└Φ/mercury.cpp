#include<bits/stdc++.h>
using namespace std;
long long ans;
string s;
map<char,int>b;
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin >> s;
	for(int i = 0;i < s.size();i++) b[s[i]]++;
	for(int i = 0;i < s.size();i++) ans += b[s[i]];
	printf("%lld",ans);
	return 0;
}
