#include<bits/stdc++.h>//t * n * min(n,k)
using namespace std;
int t,n,k,pp;
long long ans,v[1000010],v1[1000010];
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%d",&t);
	for(int o = 1;o <= t;o++)
	{
		scanf("%d%d",&n,&k);
		if(k > n) for(int i = 1;i <= n;i++) v[(i % k) * (i % k) % k * (i % k) % k]++; 
		else 
		{
			for(int i = 1;i <= k;i++) v[(i % k) * (i % k) % k * (i % k) % k] += (n / k); 
			pp = n % k;
			for(int i = 1;i <= pp;i++) v[(i % k) * (i % k) % k * (i % k) % k]++; 
		}
		for(int j = 1;j <= n;j++)
		{
			if(k > j) 
			{
				for(int i = 1;i <= j;i++) v1[(i % k + (j % k) * (j % k)) % k]++; 
				for(int i = 1;i <= k;i++) ans += v[(i % k + (j % k) * (j % k)) % k] * v1[(i % k + (j % k) * (j % k)) % k],v1[(i % k + (j % k) * (j % k)) % k] = 0;
			}
			else 
			{
				for(int i = 1;i <= k;i++) v1[(i % k + (j % k) * (j % k)) % k] += (j / k); 
				pp = j % k;
				for(int i = 1;i <= pp;i++) v1[(i % k + (j % k) * (j % k)) % k]++; 
				for(int i = 1;i <= k;i++) ans += v[(i % k + (j % k) * (j % k)) % k] * v1[(i % k + (j % k) * (j % k)) % k],v1[(i % k + (j % k) * (j % k)) % k] = 0;
			}
			v[(j % k) * (j % k) % k * (j % k) % k]--;
		}
		for(int i = 1;i <= k;i++) v[(i % k) * (i % k) % k * (i % k) % k] = 0; 
		printf("Case %d: %lld\n",o,ans); ans = 0;
	}
	return 0;
}
/*
Case 1: 1
Case 2: 2
Case 3: 2
Case 4: 10
Case 5: 13
Case 6: 6
Case 7: 11
Case 8: 9
Case 9: 14
Case 10: 27
*/
