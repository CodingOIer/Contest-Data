#include<bits/stdc++.h>
using namespace std;
int n,m,k,v[2010],bj[2010],ans,mi,p,js[2010],q[2010],cz[2010][2010],o[2010],b[2010];
struct w
{
	int l,r;
}a[2010];
bool cmp(w x,w y)
{
	return x.r - x.l > y.r - y.l;
}
void dfs(int x,int y)
{
	if(y > k)
	{
		for(int i = 1;i <= y;i++)
			for(int j = a[b[i]].l;j <= a[b[i]].r;j++) v[j]++;
		ans = 0; 
		for(int i = 1;i <= n;i++) if(v[i]) ans++,v[i] = 0;
		mi = max(mi,ans);
		return;
	}
	if(x > m) return;
	dfs(x + 1,y);
	b[y] = x;
	dfs(x + 1,y + 1);
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n <= 20 && m <= 20)
	{
		for(int i = 1;i <= m;i++) scanf("%d%d",&a[i].l,&a[i].r);
		dfs(1,1);
		printf("%d",mi);
		return 0;
	}
	for(int i = 1;i <= m;i++) 
	{
		scanf("%d%d",&a[i].l,&a[i].r);
		for(int j = a[i].l;j <= a[i].r;j++) 
		{
			cz[j][++o[j]] = i;
			v[j]++; 
			if(v[j] == 1) js[i]++,q[j] = i;
			else if(q[j] != 0) js[q[j]]--,q[j] = 0;
		}
	}
	for(int i = 1;i <= m - k;i++)//ɾ��m - k��
	{
		mi = 1e9;
		for(int j = 1;j <= m;j++) if(!bj[j] && (js[j] < mi || (js[j] == mi && a[j].r - a[j].l < a[p].r - a[p].l))) mi = js[j],p = j;//m*m
		/*
		for(int j = 1;j <= m;j++) 
		{
			ans = 0;
			if(bj[j]) continue;
			for(int z = a[j].l;z <= a[j].r;z++)
			{
				v[z]--;
				if(v[z] == 0) ans++;
			}
			for(int z = a[j].l;z <= a[j].r;z++) v[z]++;
			if(ans < mi) mi = ans,p = j;
		}
		*/
		bj[p] = 1;
		for(int z = a[p].l;z <= a[p].r;z++) 
		{
			v[z]--;
			if(v[z] == 1) //���n��
			{
				for(int q = 1;q <= o[z];q++)//n*m
				{
					if(!bj[cz[z][q]]) 
					{
						js[cz[z][q]]++;
						break;
					}
				}
			}
		}
	} 
	ans = 0;
	for(int i = 1;i <= n;i++) if(v[i]) ans++;
	printf("%d",ans);
	return 0;
}
