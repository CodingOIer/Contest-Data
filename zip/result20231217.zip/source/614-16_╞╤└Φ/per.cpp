#include<bits/stdc++.h>
using namespace std;
int t,n,b[40] = {0,2,4,4,5,14,23,17,25,68,106,79,116,317,488,365,535,1466,2251,1684},ans;
const int mod = 1e9 + 7;
int main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		ans = ans ^ (b[n] % mod);
	}
	printf("%d",ans);
	return 0;
}

