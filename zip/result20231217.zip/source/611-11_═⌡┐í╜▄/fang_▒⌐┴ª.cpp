#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll t,n,k;
int main(){
//	freopen("fang.in","r",stdin);
//	freopen("fang.out","w",stdout);
	scanf("%lld",&t);
	for(ll z=1;z<=t;z++)
	{
		ll ans=0;
		scanf("%d%d",&n,&k);
		for(ll i=1;i<=n;i++)
			for(ll j=i;j<=n;j++)
				for(ll q=j;q<=n;q++)
					if((i+j*j)%k==(q*q*q)%k) ans++;
		printf("Case %lld: %lld\n",z,ans);
	}
	return 0;
}
