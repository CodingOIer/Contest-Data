#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,k,L=INT_MAX,R,sum,cnt;
struct need{
	int l,r,id;
}a[2005];
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i].l,&a[i].r);
		a[i].id=1;
		if(a[i].r-a[i].l+1>sum) 
			a[cnt].id=1,sum=a[i].r-a[i].l+1,cnt=i,a[cnt].id=0;
	}
	k--,L=a[cnt].l,R=a[cnt].r;
	for(int t=1;t<=k;t++)
	{
		sum=0,cnt=0;
		for(int i=1;i<=m;i++)
		{
			if(a[i].id==0) continue;
			int s=0;
			if(a[i].l<L) s+=L-a[i].l;
			if(a[i].r>R) s+=a[i].r-R;
			if(s>sum) a[cnt].id=1,sum=s,cnt=i,a[cnt].id=0;
		}
		if(sum==0) break;
		L=min(L,a[cnt].l),R=max(a[cnt].r,R);
	}
	printf("%d",R-L+1);
	return 0;
}
