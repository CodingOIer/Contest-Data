#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll ans,a[100];
int main(){	
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++) a[s[i]-'0']++;
	for(int i=49;i<=74;i++) ans+=a[i]*a[i];
	printf("%lld",ans);
	return 0; 
}
/*
a 49
z 74
*/
