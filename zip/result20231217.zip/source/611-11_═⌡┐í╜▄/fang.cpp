#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll t,n,k;
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%lld",&t);
	for(ll z=1;z<=t;z++)
	{
		ll ans=0;
		scanf("%lld%lld",&n,&k);
		if(n<=300)
		{
			for(ll i=1;i<=n;i++)
				for(ll j=i;j<=n;j++)
					for(ll q=j;q<=n;q++)
						if((i+j*j)%k==(q*q*q)%k) ans++;
			printf("Case %lld: %lld\n",z,ans);
			continue;
		} 
		for(ll i=1;i<=n;i++)
		{
			for(ll j=i;j<=n;j++)
			{
				if(i*i%k==j*j*j%k) ans+=max(0ll,i/k);
				else if(i*i%k<j*j*j%k) 
				{
					if(j*j*j%k-i*i%k+k<=i) ans+=max(0ll,((i-(j*j*j%k-i*i%k))/k));
					else if(j*j*j%k-i*i%k<=i) ans++;
				}
				else if(i*i%k>j*j*j%k) 
				{
					if(j*j*j%k+k-i*i%k+k<=i) ans+=max(0ll,((i-(j*j*j%k+k-i*i%k))/k));
					else if(j*j*j%k+k-i*i%k<=i) ans++;
				}
//				cout<<i<<" "<<j<<" --> "<<ans<<endl;
			}
		}
		printf("Case %lld: %lld\n",z,ans);
	}
	return 0;
}
/*
10
1 1
2 3
3 5
4 2
5 3
6 9
7 7
8 10
9 10
10 9
*/
