#include<bits/stdc++.h>
using namespace std;
const int Mod=1e9+7;
/*long long quick_power(int s,int n){
	long long ans=1,sum=s;
	while(n){
		if(n&1)ans=(ans*sum)%Mod;
		sum=(sum*sum)%Mod;
		n>>=1;
	}
	return ans;
}*/
const int N=4e8+5;
int sum,qw,n,vis[N];
void dfs(int s){
	if(sum==n){
		qw++;qw%=Mod;
		return;
	}
	if(vis[s])return;
	vis[s]=1;
	if(s+1<=n)sum++,dfs(s+1),sum--;if(s+2<=n)sum++,dfs(s+2),sum--;
	if(s-1>=1)sum++,dfs(s-1),sum--;if(s-2<=n)sum++,dfs(s-2),sum--;
}
int main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	int T;scanf("%d",&T);
	long long ans=0;
	while(T--){
		scanf("%d",&n);
		dfs(1);
		for(int i=1;i<=n;i++)	vis[i]=0;
		cout<<qw<<endl;
		ans^=qw;
		qw=0;
	}
	cout<<ans;
	return 0;
}
