#include<bits/stdc++.h>
using namespace std;
string s;long long a[26];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	int sl=s.length();long long ans=0;
	for(int i=0;i<s.length();i++)a[s[i]-'a']++;
	for(int i=0;i<26;i++)ans+=a[i]*a[i];
	cout<<ans;
	return 0;
}
