#include<bits/stdc++.h>
using namespace std;
const int N=2005;
struct node{
	int l,r;
}s[N];/*
int cmp(node x,node y){
	if(x.l==y.l)	return x.r>y.r;
	return x.l<y.l;
}*/
int sum,su,ans,n,m,k,vis[N],a[N];
void dfs(int q){
	if(sum==k){
		int summ=0;
		for(int i=1;i<=n;i++){
			summ+=a[i];
			if(summ>0)su++;
		}
		ans=max(su,ans);
		su=0;
		return;
	}
	if(vis[q])return;
	vis[q]=1;
	for(int i=q;i<=m;i++){
		sum++;
		if(m-i+sum<k)break;
		a[s[i].l]++,a[s[i].r+1]--;
		dfs(q+1);
		sum--;
		a[s[i].l]--,a[s[i].r+1]++;
	}
	return;
}
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)scanf("%d%d",&s[i].l,&s[i].r);
	dfs(1);
	printf("%d",ans);
	return 0;
}

