#include<bits/stdc++.h>
using namespace std;
int n,k;
bool erfen(int s){
	int l=1,r=s;
	while(l<=r){
		int mid=(l+r)>>1;
		if(mid*mid*mid<=s)l=mid+1;
		else	r=mid-1;
	}
	if(r*r*r==s)return 1;
	else return 0;
}
int qw(int sum){
	int n3=n*n*n,ks=1,ans=0;
	while(sum+ks*k<=n3)ans+=erfen(sum+ks*k),ks++;
	return ans;
}
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int T,ans;
	scanf("%d",&T);
	for(int i=1;i<=T;i++){
		scanf("%d%d",&n,&k);
		for(long long a=1;a<=n;a++){
			for(long long b=1;b<=n;b++){
				long long sum=(a+b*b)%k;
				ans=qw(sum);
			}
		}
		printf("Case %d: %d\n",i,ans);
	}
	return 0;
}

