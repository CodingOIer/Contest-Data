#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

const ll N = 2005 ;

ll n , m , k , ans ;

bool cnt [N] ;

struct node
{
	ll l , r ;
	friend bool operator < ( node a , node b )
	{
		return a.r - a.l > b.r - b.l ;
	}
} s [N] ;

int main ()
{
	 freopen ( "stamps.in" , "r" , stdin ) ;
	 freopen ( "stamps.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> n >> m >> k ;
	for ( int i = 0 ; i < m ; i ++ )
	{
		cin >> s [i].l >> s [i].r ;
	}
	sort ( s , s + m ) ;
	for ( int i = 0 ; i < k ; i ++ )
	{
		for ( int j = s [i].l ; j <= s [i].r ; j ++ )
		{
			cnt [j] = 1 ;
		}
	}
	for ( int i = 1 ; i <= n ; i ++ )
	{
		ans += cnt [i] ;
	}
	cout << ans << endl ;
	return 0 ;
}
