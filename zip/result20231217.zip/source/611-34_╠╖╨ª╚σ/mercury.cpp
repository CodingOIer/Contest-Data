#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

string s ;

ll cnt [30] , ans ;

int main ()
{
	 freopen ( "mercury.in" , "r" , stdin ) ;
	 freopen ( "mercury.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> s ;
//	fill ( cnt , cnt + 26 , 1 ) ;
	for ( int i = 0 ; i < s.size () ; i ++ )
	{
		cnt [s [i] - 'a'] ++ ;
	}
	for ( int i = 0 ; i < 26 ; i ++ )
	{
		ans += cnt [i] * cnt [i] ;
	}
	cout << ans << endl ;
	return 0 ;
}
