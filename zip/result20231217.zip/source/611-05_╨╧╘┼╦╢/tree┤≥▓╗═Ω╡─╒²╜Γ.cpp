#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
struct Point{
	int u,v,w,id;
}edge[N],q[N];
int n,m,a[N],de[N],f[N],siz[N],son[N],pos[N],cnt,top[N],rnk[N],l[N],r[N],b[N],tag[N<<2],p[N<<2],ansx[N],c[N];
vector <Point> e[N];
//����O(nlgn)Ҫ��LCT.....
//�����ð�
//ѯ�ʰ�w�Ӵ�С����,ÿ�μ�һ�������Ǿ��൱�ڰ���һ���ߵı�ֵ�ĳ�1�������� 
void addval(int x,int y){
	for(;x<=n;x+=x&(-x))c[x]+=y;
}
int getval(int x){
	int ans=0;
	for(;x;x-=x&(-x))ans+=c[x];
	return ans;
}
bool cmp(Point x,Point y){
	return x.w>y.w;
}
void add(int u,int v,int w){
	e[u].push_back((Point){v,w});
}
void dfs(int u,int fa){
	siz[u]=1;
	for(int i = 0;i < e[u].size();i++){
		int v=e[u][i].v;
		if(v==fa)continue;
		rnk[v]=e[u][i].w;
		f[v]=u;
		de[v]=de[u]+1;
		dfs(v,u);
		if(siz[son[u]]<siz[v])son[u]=v;
		siz[u]+=siz[v];
	} 
}
void dfs1(int u,int fa){
	top[u]=fa;
	pos[u]=++cnt;
	b[cnt]=rnk[u];
	if(son[u]==0)return;
	dfs1(son[u],fa);
	for(int i = 0;i < e[u].size();i++){
		int v=e[u][i].v;
		if(v==f[u]&&v==son[u])continue;
		dfs1(v,v); 
	}
}
int last[N];
//�����޸�
void updata(int x){
	l[x]=min(l[x<<1],l[x<<1|1]);
	r[x]=max(r[x<<1],r[x<<1|1]);
	maxn[x]=max(maxn[x<<1],maxn[x<<1|1]);
}
void build(int x,int l1,int r1){
	if(l1==r1){
		l[x]=r[x]=maxn[x]=0;
		return;
	}
	int mid=(l1+r1)>>1;
	build(x<<1,l1,mid);
	build(x<<1|1,mid+1,r1);
	updata(x);
} 
void down(int x){
	if(p[x]){
		l[x<<1]=p[x],l[x<<1|1]=p[x];
		p[x<<1]=p[x],p[x<<1|1]=p[x];
		p[x]=0;
	}
	if(tag[x]){
		r[x<<1]=tag[x],r[x<<1|1]=tag[x];
		tag[x<<1]=tag[x],tag[x<<1|1]=tag[x];
		tag[x]=0;
	}
}
void changel(int x,int l1,int r1,int s,int t,int k){
	if(l1>=s&&r1<=t){
		l[x]=k;
		p[x]=k;
		return;
	}
	down(x);
	int mid=(l1+r1)>>1;
	if(s<=mid)changel(x<<1,l1,mid,s,t,k);
	if(t>mid)changel(x<<1|1,mid+1,r1,s,t,k);
	updata(x);
}
void changer(int x,int l1,int r1,int s,int t,int k){
	if(l1>=s&&r1<=t){
		r[x]=k;
		tag[x]=k;
		return;
	}
	down(x);
	int mid=(l1+r1)>>1;
	if(s<=mid)changer(x<<1,l1,mid,s,t,k);
	if(t>mid)changer(x<<1|1,mid+1,r1,s,t,k);
	updata(x);
}
void changemax(int x,int l,int r,int s,int k){
	if(l==r){
		maxn[x]=k;
		return;
	}
	down(x);
	int mid=(l+r)>>1;
	if(s<=mid)changemax(x<<1,l,mid,s,k);
	else changemax(x<<1|1,mid+1,r,s,k);
	updata(x);
}
int getans(int x,int l1,int r1,int s,int op){
	if(l1==r1){
		if(op==1)return l[x];
		if(op==2)return r[x];
	}
	int mid=(l1+r1)>>1;
	if(s<=mid)return getans(x<<1,l1,mid,s,op);
	else return getans(x<<1|1,mid+1,r1,s,op);
}
int querymax(int x,int l,int r,int s,int t){
	if(l>=s&&r<=t)return maxn[x];
	int mid=(l+r)>>1,ans=0;
	down(x);
	if(s<=mid)ans=max(ans,querymax(x<<1,l,mid,s,t));
	if(t>mid)ans=max(ans,querymax(x<<1|1,mid+1,r,s,t));
	return ans;
}
int queryl(int x){
	return getans(1,1,n,x,1);
}
int queryr(int x){
	return getans(1,1,n,x,2);
}
//��������
//1.0 x 0,��ʱl[x]=id[x],r[x]=id[x]
//2.1 x 1,��ʱl[x]=l[x-1],r[x]=r[x+1]; 
//3.1 x 0,��ʱl[x]=l[x-1],r[x]=id[x],change(r,l[x-1],id[x]-1,x)
//4.0 x 1,��ʱl[x]=x,r[x]=r[x+1],change(l,x+1,r[x+1],x)
int getqj(int x){
	return queryr(x)-queryl(x)+1;
}
//�������û�а취��������
//�Ǿͷֿ��...?
//Ҳ���÷�...... 
//����ϵ�Ϊ0��,һ��ʼ���е��Ϊ�ϵ�,���ǰѲ��Ƕϵ�ĵ�������ӵ�
//����ÿһ���ҵ���һ������>r�����ӵ�Ϳ�����
//��ô�Ҿ����߶���  
int duan[N],lj[N],len1; 
int find(int x,int l1){
	int l=1,r=n,mid,ans;
	while(l<=r){
		mid=(l+r)>>1;
		if(querymax(1,1,n,l,mid)>=x){
			r=mid-1;
			return find(x)
		}
		else if(querymax(1,1,n,mid+1,r)>=x)l=mid+1;
		else return -1;
	}
	return l-1;
}
void insert(int x){
	duan[x]=1;
	lj[++len1]=x;
	changemax(1,1,n,len1,x);
	int zuo=queryl(x-1),you=queryr(x+1);
	if(zuo==0&&you==0){//���1 
		changel(1,1,n,x,x,x);
		changer(1,1,n,x,x,x);
		addval(1,a[1]);
	}
	if(zuo!=0&&you!=0){//���2 
		changel(1,1,n,x,x,queryl(x-1));
		changer(1,1,n,x,x,queryr(x+1));
		addval(getqj(x-1),-a[getqj(x-1)]);
		addval(getqj(x+1),-a[getqj(x+1)]);
		addval(getqj(x),a[getqj(x)]);
	}
	if(zuo!=0&&you==0){
		changel(1,1,n,x,x,queryl(x-1));
		changer(1,1,n,x,x,x);
		changer(1,1,n,queryl(x-1),x-1,x);
		addval(getqj(x-1),-a[getqj(x-1)]);
		addval(getqj(x+1),-a[getqj(x+1)]);
	}
	if(zuo==0&&you!=0){
		changel(1,1,n,x,x,x);
		changer(1,1,n,x,x,queryr(x+1));
		changel(1,1,n,x+1,queryr(x+1),x);
		addval(getqj(x+1),-a[getqj(x+1)]);
		addval(getqj(x),a[getqj(x)]);
	}
	//���䳤��Ϊjʱ�ĺ� 
}
int len;
struct qj{
	int l,r;
}t[105],t1[105];
bool cmp1(qj x,qj y){
	return x.l<y.l;
}
int getsum(int x,int y){
	int ans=0;
	len=0,cnt=0;
	while(top[x]!=top[y]){
		if(de[top[x]]<de[top[y]])swap(x,y);
		t[++len].l=pos[top[x]],t[len].r=pos[x];
		x=f[top[x]];
	}
	if(de[x]>de[y])swap(x,y);
	if(x!=y){
		t[++len].l=pos[x],t[len].r=pos[y];
	}
	sort(t+len,t+len+1,cmp1);
	int lx=t[1].l,rx=t[1].r;
	for(int i = 2;i <= cnt;i++){
		if(t[i].l==rx+1)rx=t[i].r;
		else{
			t1[++cnt].l=lx,t1[cnt].r=rx;
			lx=t[i].l,rx=t[i].r;
		}
	}//�ϲ����� 
	for(int i = 1;i <= cnt;i++){
		lx=t1[i].l,rx=t1[i].r;
		while(lx<=rx){
			int mbr=queryr(lx);
			if(mbr<=rx){
				ans+=getval(getqj(lx));
				lx=mbr+1;
			}
			if(mbr>rx){
				ans+=getval(getqj);
				lx=mbr+1;
			}
		}
	}
	return ans;
}
//�Ҳ���д��,���������������̫�鷳����ķ���,ά�������������߶���������,��Ҫ��һ�������������ҵ���һ��>x����
//����l-mid����� 
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> m;
	for(int i = 1;i < n;i++){
		cin >> edge[i].u >> edge[i].v >> edge[i].w;
		add(edge[i].u,edge[i].v,0);
		add(edge[i].v,edge[i].u,0);
	}
	dfs(1,0);
	dfs(1,1);
	for(int i = 1;i <= m;i++)cin >> q[i].u >> q[i].v >> q[i].w,q[i].id=i;
	sort(edge+1,edge+n,cmp);
	sort(q+1,q+1+m,cmp);
	int l=1;
	build(1,1,n);
	for(int i = 1;i <= m;i++){
		int nowval=q[i].w;
		while(edge[l].w>=nowval){
			rnk[edge[l].v]=1;
			b[pos[edge[l].v]]=1;
			insert(pos[edge[l].v]);
			l++;
		}
		//1 0 0 0 1
		ansx[q[i].id]=getsum(q[i].u,q[i].v);
	}
	for(int i = 1;i <= m;i++)cout << ans[i] << "\n";
	return 0;
}
