#include <bits/stdc++.h>
using namespace std;
long long n,k;
long long lfg(long long x){
	long long l=1,r=1e6,mid,ans;
	while(l<=r){
		mid=(l+r)>>1;
		if(mid*mid*mid<=x){
			ans=mid;
			l=mid+1;
		}
		else r=mid-1;
	}
	return ans;
}
void work(int temp){
	cin >> n >> k;
	long long ans=0;
	for(register int i = 1;i <= n;i++)
		for(register int j = i;j <= n;j++)
			for(register int l = j;l <= n;l++)
				if((i+j*j)%k==l*l*l%k)
					ans++;
	cout << "Case " << temp << ": " << ans <<"\n";
} 
int t;
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout); 
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> t;
	for(int i  = 1;i <= t;i++)work(i);
	return 0;
}
