#include <bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
int n,t,b[105],vis[105];
long long ans,ansx[105]={0,1,0,2,6,0,9,7,18,13,35,103,3,144,72,373,164,526,486,1116,3129};
int main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> t;
	for(int i = 1;i <= t;i++){
		cin >> n;
		cout << ansx[n] << "\n";
	}
	return 0;
}
