#include <bits/stdc++.h>
using namespace std;
string a;
int n,cnt[105];
long long ans;
//t1ǩ��,ûʲô��˵�� 
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> a;
	n=a.size();
	for(int i = 0;i < n;i++)a[i]=(int)(a[i]-'0');
	for(int i = 0;i < n;i++)cnt[a[i]]++;
	for(int i = 0;i < n;i++)ans+=cnt[a[i]];
	cout << ans;
	return 0;
}
