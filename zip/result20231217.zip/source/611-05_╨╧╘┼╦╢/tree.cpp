#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
struct Point{
	int u,v,w,id;
}edge[N],q[N];
struct Tree{
	int v,w;
};
int n,m,a[N],de[N],f[N],siz[N],son[N],pos[N],cnt,top[N],b[N];
vector <Tree> e[N];
//����O(nlgn)Ҫ��LCT.....
//�����ð�
//ѯ�ʰ�w�Ӵ�С����,ÿ�μ�һ�������Ǿ��൱�ڰ���һ���ߵı�ֵ 
bool cmp(Point x,Point y){
	return x.w>y.w;
}
void add(int u,int v,int w){
	e[u].push_back((Tree){v,w});
}
void dfs(int u,int fa){
	for(int i = 0;i < e[u].size();i++){
		int v=e[u][i].v;
		if(v==fa)continue;
		b[v]=e[u][i].w;
		f[v]=u;
		de[v]=de[u]+1;
		dfs(v,u);
	}
}
long long getans(int x,int y,int getw){
	if(de[x]<de[y])swap(x,y);
	int cnt=0,cnt1=0;
	long long ans=0;
	while(de[x]>de[y]){
		if(b[x]>=getw)cnt++;
		else{
			ans+=a[cnt];
			cnt=0;
		}
		x=f[x];
	}
	if(x==y){
		ans+=a[cnt];
		return ans;
	}
	while(x!=y){
		if(b[x]>=getw)cnt++;
		else{
			ans+=a[cnt];
			cnt=0;
		}
		if(b[y]>=getw)cnt1++;
		else{
			ans+=a[cnt1];
			cnt1=0;
		}
		x=f[x];
		y=f[y];
	}
	if(cnt==0&&cnt1!=0)ans+=a[cnt1];
	if(cnt!=0&&cnt1==0)ans+=a[cnt];
	if(cnt!=0&&cnt1!=0)ans+=a[cnt1+cnt];
	return ans;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> m;
	for(int i = 1;i < n;i++)cin >> a[i];
	for(int i = 1;i < n;i++){
		cin >> edge[i].u >> edge[i].v >> edge[i].w;
		add(edge[i].u,edge[i].v,edge[i].w);
		add(edge[i].v,edge[i].u,edge[i].w);
	}
	dfs(1,0);
	for(int i = 1;i <= m;i++){
		cin >> q[i].u >> q[i].v >> q[i].w;
		q[i].id=i;
		cout << getans(q[i].u,q[i].v,q[i].w) <<"\n";
	}
	return 0;
}
