#include <bits/stdc++.h>
#define int long long 
#define cin std::cin
#define cout std::cout
int n,m,k;
int cnt=1;
int res;
struct fang
{
	int s,f,v;
}; 
fang p[2005];
int t[2005];
int cmp(fang x,fang y)
{
	return x.v>y.v;
}
signed main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		cin>>p[i].s>>p[i].f;
		p[i].v=p[i].f-p[i].s+1;
	}
	std::sort(p+1,p+1+m,cmp);
	for(int i=1;i<=m;i++)
	{
		if(cnt>k)break;
		int ct=0;
		for(int j=p[i].s;j<=p[i].f;j++)
		{
			t[j]++;
			ct+=(t[j]>1);
		}
		if(p[i].v>=(ct<<1))res+=(p[i].v-ct);
		else continue;
		cnt++;
	}
	cout<<res;
	return 0;
}
