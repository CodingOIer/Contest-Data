#include <bits/stdc++.h>
#define int long long 
#define cin std::cin
#define cout std::cout
int t;
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(int p=1;p<=t;p++)
	{
		int n,k;
		cin>>n>>k;
		int res=0;
		for(int c=1;c<=n;c++)
		{
			for(int b=1;b<=n;b++)
			{
				if(b>c)continue;
				for(int a=1;a<=n;a++)
				{
					if(a>c||a>b|b>c)continue;
					if((a+b*b)%k==(c*c*c)%k)res++;
				}
			}
		}
		printf("Case %lld: %lld\n",p,res);
	}
	return 0;
} 
