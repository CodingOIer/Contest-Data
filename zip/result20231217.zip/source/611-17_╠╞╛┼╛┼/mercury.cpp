#include <bits/stdc++.h>
#define int long long 
#define cin std::cin
#define cout std::cout
#define string std::string
//��֪���ǲ������� 
string s;
int res;
std::map<char,int>m;
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	int l=s.size();
	for(int i=0;i<l;i++)
	{
		m[s[i]]++;
	}
	for(int i=0;i<l;i++)
	{
		res+=m[s[i]];
	}
	cout<<res;
	return 0;
} 
