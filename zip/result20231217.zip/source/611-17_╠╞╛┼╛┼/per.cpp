#include <bits/stdc++.h>
#define int long long
#define cin std::cin
#define cout std::cout 
const int mod=1e9+7;
int t;
int res;
const int N=25;
int f[25]={0,1,1,2,4,6,9,14,21,31,46,68,100,147,216,317,465,682,1000,1466,2149};
signed main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		res^=f[n];
		res%=mod;
	}
	cout<<res%mod;
	return 0;
}

