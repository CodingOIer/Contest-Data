#include<bits/stdc++.h>
using namespace std;
//#define int long long
int a,b,c,d,e,f,g,h,ii,j,k,l,m,n,o,p,q,r,ss,t,u,v,w,x,y,z;
string s;
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='a')a++;
		if(s[i]=='b')b++;
		if(s[i]=='c')c++;
		if(s[i]=='d')d++;
		if(s[i]=='e')e++;
		if(s[i]=='f')f++;
		if(s[i]=='g')g++;
		if(s[i]=='h')h++;
		if(s[i]=='i')ii++;
		if(s[i]=='j')j++;
		if(s[i]=='k')k++;
		if(s[i]=='l')l++;
		if(s[i]=='m')m++;
		if(s[i]=='n')n++;
		if(s[i]=='o')o++;
		if(s[i]=='p')p++;
		if(s[i]=='q')q++;
		if(s[i]=='r')r++;
		if(s[i]=='s')ss++;
		if(s[i]=='t')t++;
		if(s[i]=='u')u++;
		if(s[i]=='v')v++;
		if(s[i]=='w')w++;
		if(s[i]=='x')x++;
		if(s[i]=='y')y++;
		if(s[i]=='z')z++;
	}
	cout<<a*a+b*b+c*c+d*d+e*e+f*f+g*g+h*h+ii*ii+j*j+k*k+l*l+m*m+n*n+o*o+p*p+q*q+r*r+ss*ss+t*t+u*u+v*v+w*w+x*x+y*y+z*z;
	return 0;
} 

