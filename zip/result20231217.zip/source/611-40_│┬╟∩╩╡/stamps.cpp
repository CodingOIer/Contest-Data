#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,k;
int l[2001],r[2001];
int fl,fr;
int maxf=-2147483647;
int maxl,maxr,maxj;
signed main()//Ը���ݹ�ˮ 
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		scanf("%lld%lld",&l[i],&r[i]);
		if(r[i]-l[i]+1>=maxf)
		{
			maxf=r[i]-l[i]+1;
			fr=r[i];fl=l[i];
			maxj=i;
		}
	}
	if(k==1)
	{
		cout<<fr-fl+1;
		return 0;
	}
	for(int i=1;i<=k;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(l[j]<fl&&r[j]<=fr&&r[j]>=fl)
			{
				if(fl-l[j]>maxl)
				{
					maxl=fl-l[j];
					if(maxl>maxr)maxj=j;
				}
			}
			if(l[j]>=fl&&l[j]<=fr&&r[j]>fr)
			{
				if(r[j]-fr>maxr)
				{
					maxr=r[j]-fr;
					if(maxr>maxl)maxj=j;
				}
			}
		}
		if(l[maxj]<fl&&r[maxj]<=fr)fl=l[maxj];
		if(l[maxj]>=fl&&r[maxj]>fr)fr=r[maxj];		
	}
	cout<<max(fl,fr)-min(fl,fr)+1;
	return 0;
}
/*

120 7 3
55 80
25 75
35 85
0 30
40 60
90 110
30 60

102


c2
120 3 2
20 70
10 30
40 80
90 120
90 120

112
*/
