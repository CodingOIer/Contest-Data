#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int sum[5005][5005];
int T;
int n,mod;
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read(),mod=read();
		for(int i=0;i<mod;i++)
			for(int j=1;j<=n;j++)
				sum[i][j]=0;
		int ans=0;
		for(int i=1;i<=n;i++)
			++sum[i*i*i%mod][i];
		for(int i=0;i<mod;i++)
			for(int j=1;j<=n;j++)
				sum[i][j]+=sum[i][j-1];
		for(int i=1;i<=n;i++)
			for(int j=i;j<=n;j++)
				ans+=sum[(i+j*j)%mod][n]-sum[(i+j*j)%mod][j-1];
		cout<<"Case 1:",write(ans),puts("");
	}
	return 0;
}
