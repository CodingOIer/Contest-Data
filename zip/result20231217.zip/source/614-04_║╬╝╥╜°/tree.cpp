//��AC�ż���&л����&������&��־����ȫ�� 
#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
struct node
{
	int nxt,to,val;
}e[114514<<1];
int head[114514],cnt_edge;
void add_edge(int u,int v,int w)
{
	e[++cnt_edge].to=v;
	e[cnt_edge].val=w;
	e[cnt_edge].nxt=head[u];
	head[u]=cnt_edge;
}
struct que
{
	int x,y,w,id;
}q[114514];
bool cmp(que x,que y)
{
	return x.w>y.w;
}
int n,m;
int F[114514];
int val[114514];
int dep[114514],top[114514],f[114514],siz[114514],dfn[114514],son[114514],cnt;
void dfs1(int u,int fa)
{
	siz[u]=1;
	f[u]=fa;
	dep[u]=dep[fa]+1;
	for(int i=head[u];i;i=e[i].nxt)
	{
		int v=e[i].to;
		if(v==fa)
			continue;
		val[v]=e[i].val;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]])
			son[u]=v;
	}
}
void dfs2(int u,int t)
{
	top[u]=t;
	dfn[u]=++cnt;
	if(son[u])
		dfs2(son[u],t);
	for(int i=head[u];i;i=e[i].nxt)
	{
		int v=e[i].to;
		if(v==son[u]||v==f[u])
			continue;
		dfs2(v,v);
	}
}
//---------SegmentTreeBegin-------
#define ls (root<<1)
#define rs (root<<1|1)
#define mid (t[root].l+t[root].r>>1)
struct segt
{
	int l,r,lsum,rsum,val,siz;
}t[114514<<2];
void init(segt &x)
{
	x.lsum=x.rsum=x.val=0;
	x.siz=0;
}
void update(int root)
{
	t[root].val=t[ls].val+t[rs].val-F[t[ls].rsum]-F[t[rs].lsum]+F[t[ls].rsum+t[rs].lsum];
	t[root].lsum=t[ls].lsum;
	t[root].rsum=t[rs].rsum;
	if(t[ls].lsum==t[ls].siz)
		t[root].lsum+=t[rs].lsum;
	if(t[rs].rsum==t[rs].siz)
		t[root].rsum+=t[ls].rsum;
}
segt merge(segt x,segt y)
{
	segt res;
	init(res);
	res.siz=x.siz+y.siz;
	res.val=x.val+y.val-F[x.rsum]-F[y.lsum]+F[x.rsum+y.lsum];
	res.lsum=x.lsum;
	res.rsum=y.rsum;
	if(x.lsum==x.siz)
		res.lsum+=y.lsum;
	if(y.rsum==y.siz)
		res.rsum+=x.rsum;
	return res;
}
void bld(int l,int r,int root)
{
	t[root].l=l;
	t[root].r=r;
	t[root].siz=r-l+1;
	if(l==r)
		return;
	bld(l,mid,ls);
	bld(mid+1,r,rs);
}
void add(int x,int root)
{
	if(t[root].l==t[root].r)
	{
		t[root].lsum=t[root].rsum=1;
		t[root].val=F[1];
		return;
	}
	if(x<=mid)
		add(x,ls);
	else
		add(x,rs);
	update(root);
}
segt query(int x,int y,int root)
{
	if(t[root].l>=x&&t[root].r<=y)
		return t[root];
	segt res;
	init(res);
	if(x<=mid)
		res=merge(res,query(x,y,ls));
	if(y>mid)
		res=merge(res,query(x,y,rs));
	return res;
}
//-------SegmentTreeEnd---------
int query_tree(int x,int y)
{
	segt l,r;
	init(l),init(r);
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]])
			r=merge(query(dfn[top[y]],dfn[y],1),r),y=f[top[y]];
		else
			l=merge(query(dfn[top[x]],dfn[x],1),l),x=f[top[x]];
//		cout<<"l:"<<l.lsum<<" "<<l.rsum<<" "<<l.siz<<" "<<l.val<<endl;
//		cout<<"r:"<<r.lsum<<" "<<r.rsum<<" "<<r.siz<<" "<<r.val<<endl;
	}
	if(dfn[x]>dfn[y])
		l=merge(query(dfn[y]+1,dfn[x],1),l);
	else
		r=merge(query(dfn[x]+1,dfn[y],1),r);
//	cout<<"l:"<<l.lsum<<" "<<l.rsum<<" "<<l.siz<<" "<<l.val<<endl;
//	cout<<"r:"<<r.lsum<<" "<<r.rsum<<" "<<r.siz<<" "<<r.val<<endl;
	return l.val+r.val-F[l.lsum]-F[r.lsum]+F[l.lsum+r.lsum];
}
int b[114514<<1],cnt_lsh;
vector<int>pos[114514<<1];
int ans[114514];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++)
		F[i]=read();
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read(),w=read();
		add_edge(u,v,w);
		add_edge(v,u,w);
		b[++cnt_lsh]=w;
	}
	dfs1(1,0);
	dfs2(1,1);
	for(int i=1;i<=m;i++)
	{
		q[i].x=read(),q[i].y=read(),q[i].w=read(),q[i].id=i;
		b[++cnt_lsh]=q[i].w;
	}
	sort(b+1,b+cnt_lsh+1);
	int tot=unique(b+1,b+cnt_lsh+1)-b-1;
	for(int i=2;i<=n;i++)
		val[i]=lower_bound(b+1,b+tot+1,val[i])-b;
	for(int i=1;i<=m;i++)
		q[i].w=lower_bound(b+1,b+tot+1,q[i].w)-b;
	sort(q+1,q+m+1,cmp);
	for(int i=1;i<=n;i++)
		pos[val[i]].push_back(dfn[i]);
	bld(1,n,1);
	int cur=1;
	for(int i=200000;i>=1;i--)
	{
		for(int j=0;j<pos[i].size();j++)
			add(pos[i][j],1);
		while(q[cur].w==i&&cur<=m)
		{
			ans[q[cur].id]=query_tree(q[cur].x,q[cur].y);
			++cur;
		}
	}
	for(int i=1;i<=m;i++)
		write(ans[i]),puts("");
	return 0;
}
