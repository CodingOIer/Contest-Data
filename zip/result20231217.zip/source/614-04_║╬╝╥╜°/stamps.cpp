#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int n,m,k;
int l[114514],r[114514];
int vis[114514];
int a[114514];
int sum[114514];
int ans;
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++)
		a[i]=1;
	for(int i=1;i<=m;i++)
		l[i]=read(),r[i]=read();
	for(int i=1;i<=k;i++)
	{
		int maxn=0,p=0;
		for(int i=1;i<=n;i++)
			sum[i]=sum[i-1]+a[i];
		for(int j=1;j<=m;j++)
		{
			if(vis[j])
				continue;
			if(maxn<sum[r[j]]-sum[l[j]-1])
				maxn=sum[r[j]]-sum[l[j]-1],p=j;
		}
		ans+=sum[r[p]]-sum[l[p]-1];
		for(int i=l[p];i<=r[p];i++)
			a[i]=0;
		vis[p]=1;
	}
	write(ans);
	return 0;
}
