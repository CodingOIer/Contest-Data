#include <bits/stdc++.h>
using namespace std;
int n, q;
signed main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	cin >> n >> q;
	while (q--)
		puts("0");
	return 0;
}
