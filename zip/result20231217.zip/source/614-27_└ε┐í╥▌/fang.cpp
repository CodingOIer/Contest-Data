#include <bits/stdc++.h>
using namespace std;
constexpr int N = 2e3 + 5;
int T, n, mod;
signed main() {
	freopen("fang.in", "r", stdin);
	freopen("fang.out", "w", stdout);
	cin >> T;
	for (int t = 1; t <= T; ++t) {
		cin >> n >> mod;
		int ans = 0;
		for (int i = 1; i <= n; ++i)
			for (int j = i; j <= n; ++j) {
				int m = (i + j * j) % mod;
				for (int k = j; k <= n; ++k)
					if (k * k * k % mod == m)
						++ans;
			}
		printf("Case %d: %d\n", t, ans);
	}
	return 0;
}
