#include <bits/stdc++.h>
using namespace std;
constexpr int N = 1e3 + 5;
int mp[N];
string s;
signed main() {
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout);
	cin >> s;
	for (char i : s)
		++mp[i];
	int ans = 0;
	for (int i = 'a'; i <= 'z'; ++i)
		ans += mp[i] * (mp[i] - 1) + mp[i];
	cout << ans;
	return 0;
}
