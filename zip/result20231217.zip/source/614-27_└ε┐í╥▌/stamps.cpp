#include <bits/stdc++.h>
using namespace std;
constexpr int N = 2e3 + 5;
int n, m, k;
struct data {
	int l, r;
	bool operator<(const data &x) const {
		return (r - l + 1) > (x.r - x.l + 1);
	}
} a[N];
int t[N << 3], used[N];
inline void add(int k, int v) {
	while (k <= n)
		t[k] += v, k += k & -k; 
}
inline int sum(int k) {
	int ans = 0;
	while (k)
		ans += t[k], k -= k & -k;
	return ans;
}
signed main() {
	freopen("stamps.in", "r", stdin);
	freopen("stamps.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= m; ++i)
		cin >> a[i].l >> a[i].r;
	sort(a + 1, a + m + 1);
	int ans = 0;
	for (int i = 1; i <= m && k; ++i, --k) {
		int mx = 0, t = 0;
		for (int j = 1; j <= m; ++j)
			if (!used[j] && (a[j].r - a[j].l + 1) - (sum(a[j].r) - sum(a[j].l - 1)) > mx)
				mx = (a[j].r - a[j].l + 1) - (sum(a[j].r) - sum(a[j].l - 1)), t = j;
		for (int j = a[t].l; j <= a[t].r; ++j)
			if (sum(j) - sum(j - 1) == 0)
				add(j, 1), ++ans;
	}
	cout << ans << '\n';
	return 0;
}
