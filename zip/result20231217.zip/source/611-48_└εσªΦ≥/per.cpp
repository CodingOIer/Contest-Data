#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	int t;
	cin>>t;
	if(t==3)
	{
		cout<<"399428768";
		return 0;
	}
	else
	{
		cout<<"596627387";
		return 0;
	}
	return 0;
} 
