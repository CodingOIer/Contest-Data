#include<bits/stdc++.h>
using namespace std;
int a[130];
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	long long ans=0;
	string s;
	cin>>s;
	for(int i=0;s[i];i++)
		a[s[i]]++;
	for(int i=1;i<=128;i++)
	{
		ans+=a[i];
		ans+=(a[i]-1)*a[i];
	}
	cout<<ans;
	return 0;
} 
