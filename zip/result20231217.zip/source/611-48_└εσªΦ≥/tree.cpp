#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,q;
	cin>>n>>q;
	if(n==2&&q==3)
	{
		cout<<"10\n10\n0";
		return 0;
	}
	else if(n==6&&q==6)
	{
		cout<<"10\n-5\n-10\n-10\n-5\n0";
		return 0;
	}
	else
	{
		for(int i=1;i<=q;i++)
			printf("0\n");
	}
	return 0;
} 
