#include<bits/stdc++.h>
using namespace std;
int l[2005],r[2005]; 
int d(int s,int now)
{
	return 1;
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	int n,m,k,ma=0;
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
		scanf("%d %d",&l[i],&r[i]);
	for(int i=1;i<=m-k+1;i++)
		ma=max(ma,d(1,i));
	cout<<ma;
	return 0;
} 
