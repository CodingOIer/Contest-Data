#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return x*f;
}
int write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
char s[114514];
int ton[114],ans = 0;
inline int max(int a,int b){
	return a>b?a:b;
}
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	scanf("%s",s+1);
	int n = strlen(s+1);
	for (int i = 1; i <= n; i++)
		ton[s[i]-'a'+1]++;
	for (int i = 1; i <= 26; i++)
		if (ton[i]) ans = ans+max(1,ton[i]*ton[i]);
	printf("%lld",ans);
	return 0;
}
