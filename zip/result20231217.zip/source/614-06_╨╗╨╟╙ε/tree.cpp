#include <bits/stdc++.h>
#define int long long
#define ls k<<1
#define rs k<<1|1
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return x*f;
}
int write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int n,q;
int dic[114514];
struct node{
	int nex,to,w;
}edge[214514];
struct cust{
	int from,to,w;
}E[114514];
struct Q{
	int u,v,k,id;
}que[214514];
struct segt{
	int l,r;
	string s;
}tr[214514<<2];
int head[214514],tot,cnt;
int Ans[114514];
int dep[114514],top[114514],f[114514],siz[114514],son[114514];
int id[114154];
void add(int x,int y,int w)
{
	edge[++tot].nex = head[x];
	edge[tot].to = y; edge[tot].w = w;
	head[x] = tot;
}
bool cmp(cust a,cust b){
	return a.w > b.w;
}
bool cmp1(Q a,Q b){
	return a.k > b.k;
}
//------------����Ϊ�߶���------------
void pushup(int k){
	tr[k].s = tr[ls].s+tr[rs].s;
}
void build(int l,int r,int k)
{
	tr[k].l = l; tr[k].r = r;
	if (l == r){
		tr[k].s = "0";
		return ;	
	}
	int mid = (l+r) >> 1;
	build(l,mid,ls);
	build(mid+1,r,rs);
	pushup(k);
}
void insert(int k,int x)
{
	if (tr[k].l == tr[k].r){
		tr[k].s = "1";
		return ;
	}
	int mid = (tr[k].l+tr[k].r) >> 1;
	if (x <= mid) insert(ls,x);
	else insert(rs,x);
	pushup(k);
}
string query(int k,int x,int y)
{
	string s,tmp1;
	if (tr[k].l >= x && tr[k].r <= y)
		return tr[k].s;
	int mid = (tr[k].l+tr[k].r) >> 1;
	if (x <= mid){
		tmp1 = query(ls,x,y);
		tmp1 += s; s = tmp1;
	}
	if (y > mid){
		tmp1 = query(rs,x,y);
		s += tmp1;	
	}
	return s;
}
//------------����Ϊ����--------------
void dfs1(int x,int fa)
{
	f[x] = fa; dep[x] = dep[fa]+1;
	siz[x] = 1;
	for (int i = head[x]; i; i = edge[i].nex)
	{
		int v = edge[i].to;
		if (v == fa) continue;
		dfs1(v,x);
		siz[x] += siz[v];
		if (siz[son[x]] < siz[v])
			son[x] = v;
	}
}
void dfs2(int x,int tp)
{
	top[x] = tp;
	id[x] = ++cnt;
	if (son[x]) dfs2(son[x],tp);
	for (int i = head[x]; i; i = edge[i].nex)
	{
		int v = edge[i].to;
		if (v==f[x] || v==son[x]) continue;
		dfs2(v,v);
	}
}
string sreach(int x,int y)
{
	string resl,resr,tmp1;
	while (top[x] != top[y])
	{
		if (dep[top[x]] < dep[top[x]])
		{
			tmp1 = query(1,id[top[y]],id[y]);
			tmp1 += resr;
			resr = tmp1;
			y = f[top[y]];
		}
		else
		{
			tmp1 = query(1,id[top[x]],id[x]);
			tmp1 += resl;
			resl = tmp1;
			x = f[top[x]];
		}
	}
	if (id[x] > id[y])
	{
		tmp1 = query(1,id[y]+1,id[x]);
		tmp1 += resl;
		resl = tmp1;
	}
	else
	{
		tmp1 = query(1,id[x]+1,id[y]);
		tmp1 += resr;
		resr = tmp1;
	}
	for (int i = 0,j = resl.size()-1; i < j; i++,j--)
		swap(resl[i],resl[j]);
	return resl+resr;
}
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n = read(); q = read();
	for (int i = 1; i < n; i++)
		dic[i] = read();
	for (int i = 1; i < n; i++)
	{
		E[i].from = read(); E[i].to = read();
		E[i].w = read();
		add(E[i].from,E[i].to,E[i].w);
	}
	sort(E+1,E+n,cmp);
	dfs1(1,0); dfs2(1,1);
	build(1,1e5,1);
	for (int i = 1; i <= q; i++)
		que[i].u = read(),que[i].v = read(),que[i].k = read(),que[i].id = i;
	sort(que+1,que+q+1,cmp1);
	int cur = 1;
	string tmp;
	for (int i = 1; i <= q; i++)
	{
		while (E[cur].w >= que[i].k && cur < n)
		{
			int x = dep[E[cur].from]>dep[E[cur].to]?E[cur].from:E[cur].to;
			insert(1,id[x]);
			cur++;
		}
		tmp = sreach(que[i].u,que[i].v);
		for (int j = 0; j < tmp.size();)
		{
			int as = 0;
			while (tmp[j]=='0' && j < tmp.size()) j++;
			while (tmp[j]=='1' && j < tmp.size()) as++,j++;
			Ans[que[i].id] += dic[as];
		}
	}
	for (int i = 1; i <= q; i++) write(Ans[i]),puts("");
	return 0;
}
