#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return x*f;
}
int n,m,k,vis[5005];
int ans = 0;
struct node{
	int l,r;
}ver[5005];
bool cmp(node a,node b){
	return (a.r-a.l+1)>(b.r-b.l+1);
}
int main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	n = read(); m = read(); k = read();
	for (int i = 1; i <= m; i++)
		ver[i].l = read(),ver[i].r = read();
	sort(ver+1,ver+m+1,cmp);
	int res,id;
	for (int i = 1; i <= k; i++)
	{
		res = 0;
		for (int j = 1; j <= m; j++)
			if (ver[j].r-ver[j].l+1 > res && !vis[j])
				res = ver[j].r-ver[j].l+1,id = j;
		ans += res;
		vis[id] = 1;
		for (int j = 1; j <= m; j++)
			if (!vis[j])
			{
				if (ver[j].l <= ver[id].r && ver[j].l > ver[id].l)
					ver[j].l = ver[id].r+1,vis[j] = (ver[j].r<ver[j].l);
				if (ver[j].r >= ver[id].l && ver[j].r < ver[id].r)
					ver[j].r = ver[id].l-1,vis[j] = (ver[j].r<ver[j].l);
			}
	}
	printf("%d",ans);
	return 0;
}
