#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return x*f;
}
int write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int t;
int n,Mod;
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	t = read();
	for (int cnt = 1; cnt <= t; cnt++)
	{
		int ans = 0;
		n = read(); Mod = read();
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
				for (int k = 1; k <= n; k++)
					if ((i+j*j)%Mod == k*k*k%Mod) ans++;
		printf("Case %d: ",cnt); write(ans); puts("");
	}
	return 0;
}
