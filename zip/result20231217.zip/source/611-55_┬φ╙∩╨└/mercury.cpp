#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll ans; 
int main( ){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	for(int i=1;i<=s.size();i++){
		for(int j=1;j<=s.size();j++){
			if(s[i]==s[j])ans++;
		}
	}
	cout<<ans; 
	
	return 0;
}
//takinanosakana
