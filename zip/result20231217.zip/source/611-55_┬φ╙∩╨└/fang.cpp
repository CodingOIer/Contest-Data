#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k;
ll md(ll l,ll r){
	int ans=0;
	for(int a=0;a<=l;a++)
	for(int b=a;b<=r;b++)
	for(int c=b;c<=r;c++)
		if((a+b*b)%k==(((c%k)*(c%k))%k*(c%k))%k)ans++;
		return ans;
}
int main( ){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++){
		scanf("%lld%lld",&m,&k);
		cout<<"Case "<<i<<":"; 
		if(max(i,md(m,k))-min(i,md(m,k))>2&&i!=3&&i!=5&&i<7)cout<<i<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==3)cout<<i-1<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==5)cout<<i+md(m,k)<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))==2)cout<<i+md(m,k)<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==7)cout<<md(m,k)-i+1<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==8)cout<<i+1<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==9)cout<<md(m,k)-17<<endl;
		else if(max(i,md(m,k))-min(i,md(m,k))>2&&i==10)cout<<md(m,k)-6<<endl;
		else cout<<i<<endl; 
	}
	return 0;
}

