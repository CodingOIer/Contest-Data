#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k;
ll a[2005],b[2005],c[2005],d[2005];
//  l        r       l-r    ���� 
ll mx,ans,mi=9999,ax,l,r;
ll sr(int g){
	for(ll i=a[g];i<=b[g];i++)d[i]++;
	c[g]=-1;
	return 0;
}
int main( ){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(ll i=1;i<=m;i++){
		scanf("%lld%lld",&a[i],&b[i]);
		c[i]=b[i]-a[i];
	}	
	for(ll i=1;i<=k;i++){
		for(ll j=1;j<=m;j++){
			if(c[mx]<c[j])mx=j,mi=min(mi,a[j]),ax=max(ax,b[j]);
			else if(c[mx]==c[j]&&b[j]<ax)mx=j,mi=min(mi,a[j]),ax=max(ax,b[j]);
			else if(c[mx]==c[j]&&a[j]>mi)mx=j,mi=min(mi,a[j]),ax=max(ax,b[j]);
			//����  
		}
		sr(mx);
	}
	for(ll i=mi;i<=ax;i++)	
	if(d[i]>0)ans++;
	cout<<ans; 
	return 0;
}
//���� 
