#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
int T;
signed main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>T;
	for(int t=1;t<=T;t++){
		int n,mod;
		cin>>n>>mod;
		int ans=0;
		if(mod==1){
			for(int i=1;i<=n;i++) ans+=(n-(n-i+1)+1)*(n-i+1);
			cout<<"Case "<<t<<": "<<ans<<endl;
			continue;
		}
		if(mod==2){
			for(int i=1;i<=n;i++) ans+=(n-(n-i+1)+1)*(n-i+1)/2;
			cout<<"Case "<<t<<": "<<ans<<endl;
			continue;
		} 
		if(mod==3){
			for(int i=1;i<=n;i++) ans+=(n-(n-i+1)+1)*(n-i+1)/3;
			cout<<"Case "<<t<<": "<<ans<<endl;
			continue;
		} 
		for(int i=1;i<=n;i++){
			for(int j=i;j<=n;j++){
				for(int k=j;k<=n;k++){
					if((i+(j*j))%mod==(k*k*k)%mod) ans++;
				}
			}
		}
		cout<<"Case "<<t<<": "<<ans<<endl;
	}
	return 0;
}

