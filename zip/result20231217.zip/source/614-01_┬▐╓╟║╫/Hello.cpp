#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=2e3+5;
int n,m,k;
int flag[maxn];
int ll[maxn],rr[maxn];
struct Tree{
	int l,r,val,add;
	#define l(x) t[x].l
	#define r(x) t[x].r
	#define val(x) t[x].val
	#define add(x) t[x].add
}t[maxn*4];
void build(int p,int l,int r){
	l(p)=l,r(p)=r;
	if(l==r) {
		val(p)=0;
		return;
	}
	int mid=(l+r)/2;
	build(p*2,l,mid);
	build(p*2+1,mid+1,r);
	val(p)=val(p*2)+val(p*2+1);
}
void spread(int p){
	if(add(p)){
		val(p*2)+=add(p)*(r(p*2)-l(p*2)+1);
		val(p*2+1)+=add(p)*(r(p*2+1)-l(p*2+1)+1);
		add(p*2)+=add(p);
		add(p*2+1)+=add(p);
		add(p)=0;
	}
}
void change(int p,int l,int r,int d){
	if(l<=l(p) && r>=r(p)){
		val(p)+=d*(r(p)-l(p)+1);
		add(p)+=d;
	}
	spread(p);
	int mid=(l(p)+r(p))/2;
	if(l<=mid) change(p*2,l,r,d);
	if(r>mid) change(p*2+1,l,r,d);
	val(p)=val(p*2)+val(p*2+1);
}
int ask(int p,int l,int r){
	if(l<=l(p) && r>=r(p)) return val(p);
	spread(p);
	int mid=(l(p)+r(p))/2;
	int g=0;
	if(l<=mid) g+=ask(p*2,l,r);
	if(r>mid) g+=ask(p*2+1,l,r);
	return g;
}
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n>>m>>k;
	build(1,1,n);
	for(int i=1;i<=m;i++){
		cin>>ll[i]>>rr[i];
		change(1,ll[i],rr[i],1);
	}
	while(k--){
		int mn=INF,wich;
		for(int i=1;i<=m;i++){
			if(flag[i]) continue;
			change(1,ll[i],rr[i],-1);
			int come=ask(1,ll[i],rr[i]);
			if(come<mn){
				mn=come;
				wich=i;
			}
			change(1,ll[i],rr[i],1);
		}
		flag[wich]=1;
		change(1,ll[wich],rr[wich],-1);
	}
	cout<<ask(1,1,n)<<endl;
	return 0;
}

