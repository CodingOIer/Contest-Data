#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	int n,mod,ans1=0,ans2=0;
	cin>>n>>mod;
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			for(int k=j;k<=n;k++){
				if((i+(j*j))%mod==(k*k*k)%mod) ans1++;
			}
		}
	}
	for(int i=1;i<=n;i++) ans2+=(n-(n-i+1)+1)*(n-i+1)/mod;
	cout<<ans1<<" "<<ans2<<endl;
	return 0;
}

