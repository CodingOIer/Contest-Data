#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
signed main(){
	freopen("mercury.in","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	srand(time(NULL));
	int n=rand()%(int)(1e5)+1;
	for(int i=1;i<=n;i++) cout<<char(rand()%26+'a');
	return 0;
}

