#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=2e3+5;
int n,m,k,ans;
int sum[maxn];
bool flag[maxn];
struct node{int l,r;}a[maxn];
signed main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++) cin>>a[i].l>>a[i].r;
	while(k--){
		int p=0,pp;
		for(int i=1;i<=m;i++){
			if(flag[i]) continue;
			int zc=0;
			for(int j=a[i].l;j<=a[i].r;j++) if(sum[j]==0) zc++;
			if(zc>p) pp=i,p=zc;
		}
		flag[pp]=true;
		for(int i=a[pp].l;i<=a[pp].r;i++) sum[i]++;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		if(sum[i]>0) ans++;
	}
	cout<<ans<<endl;
	return 0;
}

