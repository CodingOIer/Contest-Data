#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5;
char s[maxn];
int ans;
int a[maxn];
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	scanf("%s",s+1);
	int n=strlen(s+1);
	for(int i=1;i<=n;i++) a[s[i]-'a'+1]++; 
	for(int i=1;i<=30;i++) ans+=a[i]+a[i]*(a[i]-1);
	cout<<ans<<endl;
	return 0;
} 
