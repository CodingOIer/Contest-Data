#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5;
string s;
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercurypai.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>s;
	int ans=0;
	for(int i=0;i<s.size();i++){
		for(int j=0;j<s.size();j++){
			if(s[i]==s[j]) ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}

