#include <algorithm>
#include <cstdio>
constexpr int MaxN = 2e3 + 5;
int answer;
int n, m, k;
int l[MaxN];
int r[MaxN];
bool t[MaxN];
bool state[MaxN];
void check()
{
    for (int i = 1; i <= n; i++)
    {
        t[i] = false;
    }
    for (int i = 1; i <= m; i++)
    {
        if (state[i])
        {
            for (int j = l[i]; j <= r[i]; j++)
            {
                t[j] = true;
            }
        }
    }
    int res = 0;
    for (int i = 1; i <= n; i++)
    {
        res += t[i] ? 1 : 0;
    }
    answer = std::max(answer, res);
}
void dfs(int x, int cnt)
{
    if (x == m + 1)
    {
        check();
    }
    else
    {
        if (cnt < k)
        {
            state[x] = true;
            dfs(x + 1, cnt + 1);
        }
        state[x] = false;
        dfs(x + 1, cnt);
    }
}
int main()
{
    freopen("stamps.in", "r", stdin);
    freopen("stamps.out", "r", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 1; i <= m; i++)
    {
        scanf("%d%d", &l[i], &r[i]);
    }
    dfs(1, 0);
    printf("%d\n", answer);
    return 0;
}