#include <cstdio>
#include <vector>
constexpr int MaxN = 1e5 + 5;
int n, q;
int val[MaxN];
std::vector<int> far[MaxN];
std::vector<int> link[MaxN];
void dfs(int root, int last, int answer, int cnt, int want, int least)
{
    if (root == want)
    {
        printf("%d\n", answer + val[cnt]);
        return;
    }
    for (int i = 0; i < link[root].size(); i++)
    {
        int next = link[root][i], len = far[root][i];
        if (next == last)
        {
            continue;
        }
        if (len >= least)
        {
            dfs(next, root, answer, cnt + 1, want, least);
        }
        else
        {
            dfs(next, root, answer + val[cnt], 0, want, least);
        }
    }
}
int main()
{
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
    scanf("%d%d", &n, &q);
    for (int i = 1; i <= n - 1; i++)
    {
        scanf("%d", &val[i]);
    }
    for (int i = 1; i <= n - 1; i++)
    {
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        link[u].push_back(v);
        link[v].push_back(u);
        far[u].push_back(w);
        far[v].push_back(w);
    }
    for (int i = 1; i <= q; i++)
    {
        int x, y, z;
        scanf("%d%d%d", &x, &y, &z);
        dfs(x, 0, 0, 0, y, z);
    }
    return 0;
}