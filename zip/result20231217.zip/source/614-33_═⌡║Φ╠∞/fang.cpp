#include <cstdio>
int t;
long long n, k;
long long calc(long long n, long long k)
{
    long long answer = 0;
    for (long long b = 1; b <= n; b++)
    {
        for (long long c = b; c <= n; c++)
        {
            long long right = c * c * c;
            long long left = b * b;
            right %= k;
            left %= k;
            if (left > right)
            {
                right += k;
            }
            long long a = right - left;
            if (a == 0)
            {
                a = k;
            }
            if (a <= b)
            {
                if (a <= n)
                {
                    answer++;
                }
                answer += (b - a) / k;
            }
        }
    }
    return answer;
}
void solve2(int id, long long n, long long k)
{
    long long answer = 0;
    long long add = 0;
    long long diff = calc(k / 2 + 1, k);
    for (int i = 2; i <= n; i++)
    {
        if ((i - k / 2 - 1) % k == 0)
        {
            add += diff;
            answer += add;
            diff += k;
        }
        else
        {
            answer += add;
            if (i > i - k / 2 - 1)
            {
                add += k / 2 - 1;
            }
        }
    }
    printf("Case %d: %lld\n", id, answer);
}
void solve(int id)
{
    scanf("%lld%lld", &n, &k);
    if (k == 1)
    {
        long long answer = 1;
        long long add = 3, diff = 3;
        for (int i = 2; i <= n; i++)
        {
            answer += add;
            add += diff;
            diff++;
        }
        printf("Case %d: %lld\n", id, answer);
        return;
    }
    if (k == 2 || k == 3)
    {
        solve2(id, n, k);
        return;
    }
    else if (k == 2)
    {
        long long answer = 0;
        long long add = 0;
        long long diff = 2;
        for (int i = 2; i <= n; i++)
        {
            if (i % 2 == 0)
            {
                add += diff;
                answer += add;
                diff += 2;
            }
            else
            {
                answer += add;
            }
        }
        printf("Case %d: %lld\n", id, answer);
        return;
    }
    long long answer = 0;
    for (long long b = 1; b <= n; b++)
    {
        for (long long c = b; c <= n; c++)
        {
            long long right = c * c * c;
            long long left = b * b;
            right %= k;
            left %= k;
            if (left > right)
            {
                right += k;
            }
            long long a = right - left;
            if (a == 0)
            {
                a = k;
            }
            if (a <= b)
            {
                if (a <= n)
                {
                    answer++;
                }
                answer += (b - a) / k;
            }
        }
    }
    printf("Case %d: %lld\n", id, answer);
}
int main()
{
    freopen("fang.in", "r", stdin);
    freopen("fang.out", "r", stdout);
    scanf("%d", &t);
    for (int i = 1; i <= t; i++)
    {
        solve(i);
    }
    return 0;
}