#include <cstdio>
#include <cstring>
constexpr int MaxN = 1e5 + 5;
int n;
int map[128];
char s[MaxN];
long long answer;
int main()
{
    freopen("mercury.in", "r", stdin);
    freopen("mercury.out", "w", stdout);
    scanf("%s", s);
    n = strlen(s);
    for (int i = 0; i < n; i++)
    {
        map[s[i]]++;
    }
    for (int i = 'a'; i <= 'z'; i++)
    {
        answer += map[i] + map[i] * (map[i] - 1);
    }
    printf("%lld\n", answer);
    return 0;
}