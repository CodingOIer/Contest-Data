#include<bits/stdc++.h>
#define int long long
#define inf (int)1e18
#define debug puts("IAKIOI")
using namespace std;
int a[10000010],b[10000010],c[10000010];
const int mod=1e9+7;
signed main()
{
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	a[1]=a[2]=1;
	b[3]=1;
	b[4]=b[5]=2;
	c[6]=1;
	c[7]=c[8]=2;
	for ( int i = 6 ; i <= 10000000 ; i+=3 )
	{
		b[i]=(b[i-1]+c[i])%mod;
		b[i+1]=(b[i]+c[i+1])%mod;
		b[i+2]=(b[i+1]+c[i+2])%mod;
		c[i+3]=b[i];
		c[i+4]=b[i+1];
		c[i+5]=b[i+2];
	}
//	debug;
	for ( int i = 3 ; i <= 10000000 ; i++ )
	{
		a[i]=(a[i-1]+b[i])%mod; 
	}
//	debug;
	int q;
	cin >> q;
	int ans=0;
	while(q--)
	{
		int x;
		cin >> x;
		ans^=a[x];
//		debug;
//		cout << a[x] << endl;
	}
	cout << ans;
	return 0;
}
