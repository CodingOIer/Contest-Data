#include<bits/stdc++.h>
#define int long long
#define inf (int)1e18
#define debug puts("IAKIOI")
using namespace std;
int g[100010];
int n,m;
vector<pair<int,int> >e[100010];
int dep[100010],fa[100010],size[100010],son[100010];
void dfs1(int x,int f)
{
	fa[x]=f;
	dep[x]=dep[f]+1;
	for ( int i = 0 ; i < e[x].size() ; i++ )
	{
		int v=e[x][i].first;
		if(v==f)
		{
			continue;
		}
		dfs1(v,x);
		size[x]+=size[v];
		if(size[v]>size[son[x]])
		{
			son[x]=v;
		}
	}
	size[x]++;
}
int id[100010],bef[100010],top[100010],tot;
void dfs2(int x,int head)
{
	if(x==0)
	{
		return;
	}
	id[x]=++tot;
	bef[tot]=x;
	top[x]=head;
	dfs2(son[x],head);
	for ( int i = 0 ; i < e[x].size() ; i++ )
	{
		int v=e[x][i].first;
		if(v==fa[x]||v==son[x])
		{
			continue;
		}
		dfs2(v,v);
	}
}
//------------------����----------------
struct abc{
	int llen,rlen,l,r,ans;
	void clear()
	{
		llen=rlen=0;
		ans=0;
		l=r=0;
	}
}t[400010];
abc pu(abc l,abc r)
{
	abc ret;
	ret.clear();
	ret.l=l.l;
	ret.r=r.r;
	if(l.llen==l.r-l.l+1)
	{
		ret.llen=l.llen+r.llen;
	}else{
		ret.llen=l.llen;
	}
	if(r.rlen==r.r-r.l+1)
	{
		ret.rlen=r.rlen+l.rlen;
	}else{
		ret.rlen=r.rlen;
	}
	ret.ans=l.ans+r.ans-g[l.rlen]-g[r.llen]+g[l.rlen+r.llen];
	return ret;
}
void build(int x,int l,int r)
{
	t[x].clear();
	t[x].l=l;
	t[x].r=r;
	if(l==r)
	{
		return;
	}
	int mid=(l+r)/2;
	build(x<<1,l,mid);
	build(x<<1|1,mid+1,r);
}
void upd(int x,int p)
{
	int lf=t[x].l;
	int rt=t[x].r;
	if(p<=lf&&rt<=p)
	{
		t[x].llen=t[x].rlen=1;
		t[x].ans=g[1];
		return;
	}
	if(p<lf||rt<p)
	{
		return;
	}
	upd(x<<1,p);
	upd(x<<1|1,p);
	t[x]=pu(t[x<<1],t[x<<1|1]); 
}
abc calc(int x,int l,int r)
{
	int lf=t[x].l;
	int rt=t[x].r;
	if(l<=lf&&rt<=r)
	{
		return t[x];
	}
	int mid=(lf+rt)/2;
	if(r<=mid)
	{
		return calc(x<<1,l,r);
	}
	if(mid<l)
	{
		return calc(x<<1|1,l,r);
	}
	return pu(calc(x<<1,l,r),calc(x<<1|1,l,r));
}
//-----------------�߶���--------------- 
struct Q{
	int u,v,w,id,ans;
}q[100010];
int cmp(Q p,Q q)
{
	return p.w>q.w;
}
int cmp3(Q p,Q q)
{
	return p.id<q.id;
}
struct E{
	int u,v,w;
}edge[100010];
int tote;
int cmp2(E p,E q)
{
	return p.w>q.w;
}
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> n >>m;
	for ( int i = 1 ; i < n ; i++ )
	{
		cin >> g[i];
	}
	for ( int i = 1 ; i < n ; i++ )
	{
		int u,v,w;
		cin >> u >> v >>w;
		e[u].push_back({v,w});
		e[v].push_back({u,w}); 
		edge[i].u=u;
		edge[i].v=v;
		edge[i].w=w;
	}
	sort(edge+1,edge+n,cmp2);
	dfs1(1,1);
	dfs2(1,1);
	build(1,1,n);
	for ( int i = 1 ; i <= m ; i++ )
	{
		cin >> q[i].u >> q[i].v >> q[i].w;
		q[i].id=i;
	}
	sort(q+1,q+1+m,cmp);
	for ( int i = 1 ; i <= m ; i++ )
	{
		while(tote<n-1&&edge[tote+1].w>=q[i].w)
		{
			tote++;
			if(edge[tote].u==fa[edge[tote].v])
			{
				upd(1,id[edge[tote].v]);
			}else{
				upd(1,id[edge[tote].u]);
			}
		}
		abc l,r;
		l.clear();
		r.clear();
		int u=q[i].u,v=q[i].v;
		while(top[u]!=top[v])
		{
			if(dep[top[u]]<dep[top[v]])
			{
				r=pu(calc(1,id[top[v]],id[v]),r);
				v=fa[top[v]];
			}else{
				l=pu(calc(1,id[top[u]],id[u]),l);
				u=fa[top[u]];
			}
		}
//	debug;
		if(dep[u]<dep[v]&&u!=v)
		{
			r=pu(calc(1,id[u]+1,id[v]),r);
		}else if(u!=v){
			l=pu(calc(1,id[v]+1,id[u]),l);
		}
		swap(l.llen,l.rlen);
		q[i].ans=pu(l,r).ans;
	}
	sort(q+1,q+1+m,cmp3);
	for ( int i = 1 ; i <= m ; i++ )
	{
		cout << q[i].ans << endl;
	}
	return 0;
}
/*
�𲽽���Ȩ����Ϊ1��������ά��������� 
*/
