#include<bits/stdc++.h>
#define int long long
#define inf (int)1e18
#define debug puts("IAKIOI")
using namespace std;
int calc(int x)
{
	int ans=0;
	for ( int i = 1 ; i <= x ; i++ )
	{
		ans+=i*(i+1)/2;
	}
	return ans;
}
int func(int x,int op)
{
	int cnt=0;
	if(op==0)
	{
		int beg=1,ed=(x+1)/2*2-1;
		int xs=(ed+beg)/2;
		cnt+=((x+1)/2)*xs;
		cnt-=(0+ed/2)*xs/2;
	}else{
		int beg=1,ed=(x+1)/2*2-1;
		int xs=(ed+beg)/2;
		cnt+=(x/2)*xs;
		cnt-=(0+(ed-1)/2)*xs/2;
	}
	if(op==0)
	{
		int beg=2,ed=x/2*2;
		int xs=(ed+beg)/2-1;
		cnt+=(x/2)*xs;
		cnt-=(0+(ed-1)/2)*xs/2;
	}else{
		int beg=2,ed=x/2*2;
		int xs=(ed+beg)/2-1;
		cnt+=((x+1)/2)*xs;
		cnt-=(1+ed/2)*xs/2;
//		for ( int i = 2 ; i <= x ; i+=2 )
//		{
//			if(op==0)
//			{
//				cnt+=(x/2)-((i-1)/2);
//			}else{
//				cnt+=((x+1)/2)-(i/2);
//			}
//		}
	}
	return cnt;
}
int calc2(int x)
{
	int cnt=0;
	for ( int i = 1 ; i <= x ; i++ )
	{
		cnt+=func(i,i*i*i%2);
	}
	return cnt;
}
int sol(int x,int mod)
{
	if(mod==1)
	{
		return calc(x);
	}
	if(mod==2)
	{
		return calc2(x);
	}
	int cnt=0;
	for ( int j = 1 ; j <= x ; j++ )
	{
		for ( int k = j ; k <= x ; k++ )
		{
			int i=(k*k*k-j*j)%mod;
			if(i==0)
			{
				i=mod;
			}
			if(i>j)
			{
				continue;
			}
			cnt+=(j-i)/mod;
			cnt++;
		}
	}
	return cnt;
}
signed main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	int q;
	cin >> q;
	for ( int i = 1 ; i <= q ; i++ )
	{
		int n,mod;
		cin >> n >> mod;
		printf("Case %lld: %lld\n",i,sol(n,mod));
	}
	return 0;
}
//99999
