#include<bits/stdc++.h>
#define int long long
#define inf (int)1e18
#define debug puts("IAKIOI")
using namespace std;
struct abc{
	int l,r,len;
}a[2010];
int cmp(abc p,abc q)
{
	return p.len>q.len;
}
signed main()
{
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	int m,n,k;
	cin >> m >> n >> k;
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i].l >> a[i].r;
		a[i].len=a[i].r-a[i].l+1;
	}
	int ans=0;
	while(k--)
	{
		sort(a+1,a+1+n,cmp);
		ans+=a[1].len;
		a[1].len=0;
		for ( int i = 1 ; i <= n ; i++ )
		{
			a[i].l=max(a[i].l,a[1].r);
			a[i].r=min(a[i].r,a[1].l);
			a[i].len=a[i].r-a[i].l+1;
		}
	}
	cout << ans;
	return 0;
}
