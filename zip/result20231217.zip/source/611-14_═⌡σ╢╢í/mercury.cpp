#include<bits/stdc++.h>
#define int long long
#define inf (int)1e18
#define debug puts("IAKIOI")
using namespace std;
int a[30];
signed main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	string s;
	cin >> s;
	for ( int i = 0 ; i < s.size() ; i++ )
	{
		a[s[i]-'a']++;
	}
	int cnt=0;
	for ( int i = 0 ; i < 26 ; i++ )
	{
		cnt+=a[i]*a[i];
	}
	cout << cnt;
	return 0;
}
