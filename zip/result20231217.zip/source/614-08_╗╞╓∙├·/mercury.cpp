#include <bits/stdc++.h>
#define int long long
using namespace std;
int vis[205],ans;
string s;
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin >> s;
	int n=s.length();
	s=' '+s;
	for(int i=1;i<=n;i++) vis[s[i]-'a'+1]++;	
	for(int i=1;i<=n;i++) ans+=vis[s[i]-'a'+1];
	cout << ans;
	return 0;
}
