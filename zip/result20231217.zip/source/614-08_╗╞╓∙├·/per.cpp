#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e7+5,mod=1e9+7;
int f[N],vis[25],ans,n,q,sum[N],pw=2;

signed main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	f[1]=0;
	f[2]=1;
	f[3]=2;
	f[4]=2;
	sum[1]=1;sum[2]=1;sum[3]=2,sum[4]=4;
	for(int i=5;i<=N-5;i++) f[i]=(f[i-1]+f[i-3])%mod,sum[i]=(sum[i-1]+f[i-1])%mod;
	cin >> q;
	while(q--){
		cin >> n;
		ans=ans^sum[n];
	} cout << ans;
	return 0;
}
//�����ԣ����Գ����þ�������ݼ���
/*
[f_n-3,f_n-2,f_n-1]*[0,0,1]=[f_n-2,f_n-1,f_n]
					[1,0,0]
			        [0,1,1]
*/ 
