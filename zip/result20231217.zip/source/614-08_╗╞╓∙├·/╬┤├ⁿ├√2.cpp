#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	srand(time(NULL));
	freopen("1.in","w",stdout);
	int n=2000,m=2000,k=114;
	cout << n << " " << m << " " << k << "\n";
	for(int i=1;i<=m;i++){
		int l=rand()%n+1,r=rand()%n+1;
		if(l>r) swap(l,r);
		cout << l << " " << r << "\n";
	}

	return 0;
}

