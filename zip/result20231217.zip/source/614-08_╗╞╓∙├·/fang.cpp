#include <bits/stdc++.h>
#define int long long
using namespace std;
int q,n,k;
int vis[2000000];
signed main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin >> q;
	memset(vis,-1,sizeof(vis));
	vis[0]=0;
	for(int i=1;;i++){
		if(i*i*i>1000000) break;
		vis[i*i*i]=i;
	}
	for(int i=1;i<=q;i++){
		cin >> n >> k;
		cout << "Case " << i << ":";
		int p=n/k;
		int ans=0;
		 for(int p=1;p<=n;p++){
			for(int j=p;j<=n;j++){
				for(int s=j;s<=n;s++)		
					if((p+j*j)%k==s*s*s%k) ans++;
				
			}
		} 
		cout << ans;
		puts("");
	}

	return 0;
}

