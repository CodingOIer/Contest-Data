#include <bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
using namespace std;
const int N=1e5+5;
int n,q,f[N],val[N];
struct node{
	int to,w;
};
vector<node> V[N];
int fa[N],siz[N],son[N],dep[N],top[N],id[N],c[N],cnt,lc[N<<2],rc[N<<2],tr[N<<2],lazy[N<<2];
void dfs1(int x,int f){
	dep[x]=dep[f]+1,fa[x]=f;
	siz[x]=1;
	int fat=-1;
	for(int i=0;i<V[x].size();i++){
		int v=V[x][i].to;
		if(v==f) continue;
		dfs1(v,x);
		siz[x]+=siz[v];
		if(siz[v]>fat) fat=siz[v],son[x]=v,c[x]=V[x][i].w;
	}
}
void dfs2(int x,int tp,int p){
	id[x]=++cnt;top[x]=tp;
	val[id[x]]=p; 
	if(!son[x]) return;
	
	dfs2(son[x],tp,c[x]);
	for(int i=0;i<V[x].size();i++){
		int v=V[x][i].to;
		if(v==fa[x] || v==son[x]) continue;
		dfs2(v,v,V[x][i].w);
	}
}
void pushup(int x){
	tr[x]=tr[ls]+tr[rs];
	tr[x]-=(rc[ls]>=0 && lc[rs]>=0);
	lc[x]=lc[ls];
	rc[x]=rc[rs];
}
void pushdown(int x,int l,int r){
	if(lazy[x]==0) return;
	lazy[ls]+=lazy[x],lazy[rs]+=lazy[x];
	
}
void build(int x,int l,int r){
	if(l==r){
		tr[x]=1;
		lc[x]=rc[x]=val[l];
		return;
	}
	build(ls,l,mid);
	build(rs,mid+1,r);
	pushup(x);
}
void change(int x,int l,int r,int lt,int rt,int k){
	
}
signed main(){
	cin >> n >> q;
	for(int i=1;i<n;i++) cin >> f[i];
	for(int i=1,u,v,w;i<n;i++){
		cin >> u >> v >> w;
		V[u].push_back((node){v,w});
		V[v].push_back((node){u,w});
	}
	dfs1(1,1);
	dfs2(1,1,0);
//	cout << val[id[3]] << "\n";
	build(1,1,n);
	return 0;
}

