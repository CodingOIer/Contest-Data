#include <bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
#define mid ((l+r)>>1)
using namespace std;
const int N=2005;
int n,m,k,tot,lazy[N<<2],tr[N<<2],t[N<<2],vis[N],p[N],cnt,sum;

struct node{
	int lt,rt,v;
}a[N];

void pushdown(int x,int l,int r){
	if(lazy[x]==0) return;
	lazy[ls]+=lazy[x],lazy[rs]+=lazy[x];
	if(lazy[ls]!=0)tr[ls]=(mid-l+1);
	else tr[ls]=0;
	if(lazy[rs]!=0)tr[rs]=(r-mid);
	else tr[rs]=0;
	lazy[x]=0;
}
void pushup(int x){
	tr[x]=tr[ls]+tr[rs];
}
void change(int x,int l,int r,int lt,int rt,int k){
	if(l>=lt && r<=rt){
		lazy[x]+=k;
		if(lazy[x]) tr[x]=(r-l+1);
		else tr[x]=0;
		return;
	}
	pushdown(x,l,r);
	if(lt<=mid) change(ls,l,mid,lt,rt,k);
	if(rt >mid) change(rs,mid+1,r,lt,rt,k);
	pushup(x);
}
int query(int x,int l,int r,int lt,int rt){
	if(l>=lt && r<=rt) return tr[x];
	pushdown(x,l,r);
	int p=0;
	if(lt<=mid)p+=query(ls,l,mid,lt,rt);
	if(rt> mid)p+=query(rs,mid+1,r,lt,rt);
	pushup(x);
	return p;
}
signed main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin >> n >> m >> k;
	for(int i=1;i<=m;i++) cin >> a[i].lt >> a[i].rt,a[i].v=a[i].rt-a[i].lt+1;
	for(int i=1;i<=k;i++){
		int maxn=0,lt=0,rt=0,p1=0;
		int pre=query(1,1,n,1,n);
//		cout << pre << "\n";
		for(int j=1;j<=m;j++){
			if(vis[j]) continue;
			change(1,1,n,a[j].lt,a[j].rt,1);
			int o=query(1,1,n,1,n);
			if(maxn<o-pre){
				lt=a[j].lt,rt=a[j].rt;
				maxn=o-pre;
				p1=j;
			}
			change(1,1,n,a[j].lt,a[j].rt,-1);
		}
		if(p1==0) continue;
		vis[p1]=1;
		change(1,1,n,a[p1].lt,a[p1].rt,1);
	}
	cout << query(1,1,n,1,n);
	return 0;
}

