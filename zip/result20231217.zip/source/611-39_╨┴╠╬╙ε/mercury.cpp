#include <stdio.h>
#include <string.h>
#include <algorithm>
const int N = 1e5 + 10;
char a[N];
int main() {
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout);
	scanf("%s", &a);
	int len = strlen(a);
	long long ans = len, res = 1;
	std::sort(a, a + len);
	for (int i = 1; i < len; i++) {
		if (a[i] == a[i - 1])
			res++;
		else
			ans += (res - 1) * res, res = 1;
	}
	ans += (res - 1) * res;
	printf("%lld", ans);
	return 0;
}
