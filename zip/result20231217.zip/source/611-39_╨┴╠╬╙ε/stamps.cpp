#include <stdio.h>
struct node {
	int l, r;
}a[2010];
int f[2010], n, m, k, ans;
bool o[2010];
void dfs(int star, int step, int en, int sum, int now) {
	if (step == en + 1) {
		ans = (ans > sum ? ans : sum);
		return;
	}
	if (step != 1) {
		for (int i = now + 1; i <= m; i++) {
			if (!o[i]) {
				int res = 0;
				for (int j = a[i].l; j <= a[i].r; j++)
					res += (f[j] ? 0 : 1), f[j]++;
				o[i] = 1;
				dfs(star, step + 1, en, sum + res, i);
				o[i] = 0;
				for (int j = a[i].l; j <= a[i].r; j++)
					f[j]--;
			}
		}
	}
	else {
		int k = a[star].r - a[star].l + 1;
		for (int i = a[star].l; i <= a[star].r; i++)
			f[i]++;
		o[star] = 1;
		dfs(star, step + 1, en, sum + k, star);
		o[star] = 0;
		for (int i = a[star].l; i <= a[star].r; i++)
			f[i]--;
	}
}
int main() {
	freopen("stamps.in", "r", stdin);
	freopen("stamps.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= m; i++)
		scanf("%d%d", &a[i].l, &a[i].r);
	for (int i = 1; i <= m; i++)
		dfs(i, 1, k, 0, 0);
	printf("%d", ans);
	return 0;
}
