#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
	freopen("fang.in", "r", stdin);
	freopen("fang.out", "w", stdout);
	int t;
	scanf("%d", &t);
	for (int o = 1; o <= t; o++) {
		int n, k;
		ll ans = 0;
		scanf("%d%d", &n, &k);
		for (ll i = 1; i <= n; i++)//a
			for (ll j = i; j <= n; j++)//b
				for (ll l = j; l <= n; l++)//c
					if ((i + j * j) % k == l * l * l % k)
						ans++;
		printf("Case %d: %lld\n", o, ans);
	}
	return 0;
}
