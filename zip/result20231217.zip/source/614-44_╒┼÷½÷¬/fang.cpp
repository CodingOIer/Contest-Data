#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int sum[5005][5005];
int ask(int n,int k){
	int ans=0;
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			sum[i][(j*j*j)%k]++;
		}
	}
	
	for(int a=1;a<=n;a++){
		for(int b=a;b<=n;b++){
			ans+=sum[b][(a+b*b)%k];
		}
	}
	return ans;
}
signed main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++){
		int n,k;
		cin>>n>>k;
		cout<<"Case "<<i<<": "<<ask(n,k)<<endl;
	}
	return 0;
} 
