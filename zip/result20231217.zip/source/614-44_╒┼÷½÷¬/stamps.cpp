#include<bits/stdc++.h>
using namespace std;
const int N=2e3+5;
int n,m,k,ans;
int l[N],r[N],cnt[N],f[N];
signed main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++) cin>>l[i]>>r[i];
	while(k--){
		int mx=-1,xx;
		for(int i=1;i<=m;i++){
			if(f[i]==1) continue;
			int sum=0;
			for(int j=l[i];j<=r[i];j++){
				if(cnt[j]==0) sum++;
			}
			if(sum>mx){
				mx=sum;
				xx=i;
			}
		}
		f[xx]=1;
		for(int i=l[xx];i<=r[xx];i++){
			cnt[i]++;
		}
	}
	for(int i=1;i<=n;i++) if(cnt[i]>0) ans++;
	cout<<ans;
	return 0;
}

