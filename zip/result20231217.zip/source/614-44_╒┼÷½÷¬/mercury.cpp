#include<bits/stdc++.h>
using namespace std;
string s;
long long n,ans;
map<char,int> mp;
signed main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
	n=s.size();
	s=' '+s;
	for(int i=1;i<=n;i++) mp[s[i]]++;
	for(char i='a';i<='z';i++) ans+=mp[i]*mp[i];
	cout<<ans;
	return 0;
}
