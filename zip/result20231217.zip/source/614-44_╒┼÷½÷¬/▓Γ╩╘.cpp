#include<bits/stdc++.h>
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define swap(a,b) (a)^=(b),(b)^=(a),(a)^=(b)
using namespace std;
struct Stack{
	stack<char> sw;
	void pop(){
		sw.pop();
	}
	void push(int x){
		sw.push(x);
	}
	int size(){
		return sw.size();
	}
	int top(){
		return sw.top();
	}
}st;
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	int n;
	cin>>n;
	string s,t;
	cin>>s;
	s=' '+s;
	for(int i=1;i<=n;i++){
		if(s[i-1]==st.top()&&st.size()>=1) st.pop();
		else st.push(s[i]);
	}
	for(int i=st.size()-1;i>=0;i--){
		t+=st.top();
		cout<<st.top();
		st.pop();
	}
	cout<<t; 
	return 0;
}

