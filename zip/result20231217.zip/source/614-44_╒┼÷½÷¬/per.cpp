#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int T,n[1000005],mx=0,ans=0;
vector<int> f;
signed main(){
	freopen("per.in","r",stdin);
	freopen("per.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++){
		cin>>n[i];
		mx=max(mx,n[i]);
	}
	f.push_back(0);f.push_back(1);f.push_back(1);
	for(int i=3;i<=mx;i++){
		f.push_back((f[i-3]+f[i-1]+1)%mod);
	}
	for(int i=1;i<=T;i++){
		ans^=f[n[i]];
	}
	cout<<ans;
	return 0;
}
/*
(2 1 1)(1 0 1)
	   (1 0 0)
	   (0 1 0)
1 1 2 4 6 9 14 21 31 46
1 1
*/
