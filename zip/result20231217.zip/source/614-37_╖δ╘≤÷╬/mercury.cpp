#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read(){
	ll f=0,sum=0;
	char c=getchar();
	while(!isdigit(c))  f=(c=='-'),c=getchar();
	while(isdigit(c)) sum=(sum<<1)+(sum<<3)+c-48,c=getchar();
	return f?-sum:sum;
}
ll vis[105];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout); 
	string a;
	cin>>a;
	ll len=a.size();
	FOR(i,0,len-1) vis[a[i]-'a']++;
	ll sum=0;
	FOR(i,0,26) sum+=vis[i]*vis[i];
	cout<<sum;
	return 0;
}
