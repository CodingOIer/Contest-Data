#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read(){
	ll f=0,sum=0;
	char c=getchar();
	while(!isdigit(c))  f=(c=='-'),c=getchar();
	while(isdigit(c)) sum=(sum<<1)+(sum<<3)+c-48,c=getchar();
	return f?-sum:sum;
}
const int MX=5e3+10;
struct sky{
	int l,r,len;
}a[MX];
ll vis[MX],h[MX];
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout); 
	int n=read(),m=read(),k=read(),top=0;
	FOR(i,1,m) a[i].l=read(),a[i].r=read(),a[i].len=(a[i].r-a[i].l+1);
	ll ans=0;
	FOR(i,1,k){
		int k=0,len=0;
		FOR(j,1,n) if(a[j].len>len) len=a[j].len,k=j;
		ans+=a[k].len,h[++top]=k;
		memset(vis,0,sizeof(vis));
		FOR(j,1,m) vis[a[j].l]+=1,vis[a[j].r+1]-=1;
		FOR(j,1,n) vis[j]+=vis[j-1]; 
		FOR(j,1,top)  vis[a[h[j]].l]-=1e17,vis[a[h[j]].r+1]+=1e17;
		FOR(j,1,n) vis[j]+=vis[j-1]; 
		FOR(j,1,n)	if(vis[j]<=0) vis[j]=0; else vis[j]=1;
		FOR(j,1,n) vis[j]+=vis[j-1];
		FOR(j,1,n) a[j].len=vis[a[j].r]-vis[a[j].l]; 
	}
	cout<<ans; 
	return 0;
}

