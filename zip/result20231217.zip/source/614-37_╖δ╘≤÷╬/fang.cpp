#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read(){
	ll f=0,sum=0;
	char c=getchar();
	while(!isdigit(c))  f=(c=='-'),c=getchar();
	while(isdigit(c)) sum=(sum<<1)+(sum<<3)+c-48,c=getchar();
	return f?-sum:sum;
}
const int MX=1e6+10;
ll vis[MX];
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout); 
	int Q=read();
	FOR(k,1,Q){
		int n=read(),mod=read();
		if(mod==1){
			ll ans=0;
			FOR(i,1,n+1) ans+=(1+n)*n/2-(i+n)*(n-i+1)/2; 
			cout<<"Case "<<k<<":"<<ans<<endl;
			continue;
		} 
		if(mod==2){
			ll ans=0;
//			FOR(i,1,n+1) ans+=((1+n)*n/2-(i+n)*(n-i+1)/2)/2;
			FOR(i,1,n) if(i%2==0) ans+=(i/2)*((n-i)/2+(n%2==0));
			FOR(i,1,n) if(i%2==1) ans+=(i/2)*(n-i-(n-i)/2-(n%2==0)+1); 
			FOR(i,1,n) if(i%2==0) ans+=(i-i/2)*(n-i-(n-i)/2-(n%2==0)+1); 
			FOR(i,1,n) if(i%2==1) ans+=(i-i/2)*((n-i)/2+(n%2==0)); 
			cout<<"Case "<<k<<":"<<ans<<endl;
			continue;
		} 
//		ll ans=0;
//		FOR(i,0,mod+1) vis[i]=0;
//		FOR(i,1,n) vis[(i*i*i)%mod]++;
//		FOR(i,1,n) FOR(j,i,n) {
//			ans+=vis[(i+j*j)%mod];
//		}
//		cout<<"Case "<<k<<":"<<ans<<endl;
		ll ans=0;
		FOR(i,1,n) FOR(j,i,n) FOR(l,j,n) if((i+j*j)%mod==(l*l*l)%mod) ans++;
//		FOR(i,1,n) FOR(j,i,n) if(i>(j*j*j-i*i)%mod){
//			ans+=(i-((j*j*j-i*i)%mod))/mod+1;
//			cout<<i<<" "<<j<<" "<<(i-(j*j*j-i*i)%mod)/mod+1<<endl;
//		}
//		ans+=max(0,((j*j*j-i*i)%mod));
//		(i*i+j*j*j)%mod 
		cout<<"Case "<<k<<":"<<ans<<endl;
	}
	return 0;
}

