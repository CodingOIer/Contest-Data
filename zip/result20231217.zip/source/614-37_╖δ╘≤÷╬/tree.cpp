#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read(){
	ll f=0,sum=0;
	char c=getchar();
	while(!isdigit(c))  f=(c=='-'),c=getchar();
	while(isdigit(c)) sum=(sum<<1)+(sum<<3)+c-48,c=getchar();
	return f?-sum:sum;
}
const int MX=1e6+10;
struct sky{
	ll to,w;
};
ll dep[MX],f[MX],up[MX],h[MX],fa[MX];
//basic_string<sky>edge[MX];
vector<sky>edge[MX];
void dfs(int x,int faa){
	dep[x]=dep[faa]+1;
//	for(sky y:edge[x])
	FOR(i,0,edge[x].size()-1){
		sky y=edge[x][i]; 
//		cout<<y.to<<" "<<endl; 
		if(y.to==faa) continue;
		fa[y.to]=x;
		up[y.to]=y.w;
		dfs(y.to,x);
	}
}
int top=0;
int tmp[MX];
void lca(int x,int y){
//	cout<<1
	if(dep[x]<dep[y]) swap(x,y);
	int s=y;
	while(dep[x]!=dep[y]){
		h[++top]=up[x];
		x=fa[x];
//		cout<<x<<" ";
	}
	if(x==y) return;
	while(x!=y){
//		cout<<x<<" "<<y<<endl; 
		h[++top]=up[x];
		x=fa[x],y=fa[y];
	}
//	int lca=x;
	int top2=0;
	while(x!=s){
//		cout<<s<<" ";
		tmp[++top2]=up[s];
		s=fa[s];
	}
	ROF(i,top2,1) h[++top]=tmp[i];
	return;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n=read(),Q=read();
	FOR(i,1,n-1) f[i]=read();
	FOR(i,1,n-1){
		ll x=read(),y=read(),w=read();
		edge[x].push_back({y,w});
		edge[y].push_back({x,w});
	} 
	dfs(1,0);
	while(Q--){
		ll x=read(),y=read(),w=read();
		top=0;
		lca(x,y);
		ll s=0,ans=0;
		FOR(i,1,top){ 
			if(h[i]>=w) s++;
			else ans+=f[s],s=0;
		}
		ans+=f[s];
//		FOR(i,1,top) cout<<h[i]<<" ";
//		cout<<endl;
		cout<<ans<<endl;
	}
	return 0;
}
//Ԥ��40pts+ ������ݿ����ܳ� n*2*logn 
