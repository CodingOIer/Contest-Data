#include<iostream>
#include<cstdio>
#include<string.h>
#include<vector>
using namespace std;
int a[100005];
struct E{
	int x,w;
};
vector<E>e[100005];
int dep[100005],fa[100005],w[100005];
void dfs(int x,int f){
	dep[x]=dep[f]+1;
	fa[x]=f;
	for(int i=0;i<e[x].size();i++){
		if(e[x][i].x==f)continue;
		w[e[x][i].x]=e[x][i].w;
		dfs(e[x][i].x,x);
	}
}
int lca(int x,int y){
//	cout<<x<<" "<<y<<"\n";
	if(dep[x]<dep[y])swap(x,y);
	while(dep[x]>dep[y])x=fa[x];
	while(x!=y)x=fa[x],y=fa[y];
	return x;
}
int b[100005];
int cnt;
void lian(int x,int y,int k){
	int lc=lca(x,y);cnt=0;
//	cout<<lc<<"\n";
	while(x!=lc){
		cnt++;
		b[cnt]=(w[x]>=k?1:0);
		x=fa[x];
	}
	int o=cnt+dep[y]-dep[lc];
	cnt+=dep[y]-dep[lc];
	while(y!=lc){
//		cout<<y<<" "<<w[y]<<"\n";
		b[o]=(w[y]>=k?1:0);
		o--;
		y=fa[y];
	}
}
void s(){
	int x,y,z;
	cin>>x>>y>>z;
	lian(x,y,z);
	int ans=0,s=0;
	for(int i=1;i<=cnt;i++){
//		cout<<b[i]<<" ";
		if(b[i]==0){
			if(s)ans+=a[s];
			s=0;
		}
		else s++;
	}
	if(s)ans+=a[s];
	cout<<ans<<"\n";
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	int n,q;
	cin>>n>>q;
	for(int i=1;i<n;i++)cin>>a[i];
	for(int i=1;i<n;i++){
		int x,y,z;
		cin>>x>>y>>z;
		e[x].push_back({y,z});
		e[y].push_back({x,z});
	}
	dfs(1,0);
	while(q--){
		s();
	}
	return 0;
}
/*
�о�������
100+60+25+0+40=225
100+60+20+20=200
����������� 
*/ 
