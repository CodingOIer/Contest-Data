#include<iostream>
#include<cstdio>
#include<string.h>
using namespace std;
int t[30];
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	string a;
	cin>>a;
	long long n=a.size();
	for(long long i=0;i<n;i++)t[a[i]-'a']++;
	long long ans=n;
	for(long long i=0;i<26;i++)ans+=(1+t[i]-1)*(t[i]-1);
	cout<<ans;
	return 0;
} 
