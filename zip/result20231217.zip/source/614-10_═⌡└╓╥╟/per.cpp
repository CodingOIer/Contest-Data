#include<iostream>
using namespace std;
int main(){
	freopen("mercury.in","w",stdout);
	for(int i=1;i<=100000;i++)cout<<'a';
	return 0;
}
