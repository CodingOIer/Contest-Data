#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string.h> 
using namespace std;
long long dp[2003][2003];
struct A{
	long long l,r;
}a[2003];
bool tmp(A x,A y){
	return x.r<y.r;
}
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	long long n,m,k;
	cin>>n>>m>>k;
	for(long long i=1;i<=m;i++){
		cin>>a[i].l>>a[i].r;
	}
	sort(a+1,a+m+1,tmp);
	long long ans=0;
	for(long long i=1;i<=m;i++){
		dp[i][1]=a[i].r-a[i].l+1;
		ans=max(ans,dp[i][1]);
	}
	for(long long i=1;i<=m;i++){
		for(long long j=2;j<=k;j++){
			dp[i][j]=a[i].r-a[i].l+1;
			for(long long h=1;h<i;h++){
				dp[i][j]=max(dp[i][j],dp[h][j-1]+(a[i].l>a[h].r?a[i].r-a[i].l+1:a[i].r-a[h].r));
//				if(h==m-1)cout<<dp[i][j]<<" "<<dp[h][j-1]+(a[i].l>a[h].r?a[i].r-a[i].l+1:a[i].r-a[h].r)<<"\n";
			}
			ans=max(ans,dp[i][j]);
		}
	}
	cout<<ans;
	return 0;
}
/*
զ��զ��dp?
��dp[i][j]Ϊ��ǰ��i����ѡ��j�����������
Ҫ���򣿣�
���Ҷ˵��ţ� 
*/
