#include <bits/stdc++.h>
using namespace std;

int n, m, k, ans;
bitset<2005> upd[2005];
bitset<2005> now;

int main() {
	freopen("stamps.in", "r", stdin);
	freopen("stamps.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= m; i++) {
		int l, r;
		scanf("%d%d", &l, &r);
		for (; l <= r; l++) upd[i][l] = 1;
	}
	for (int state = 0; state < 1 << m; state++)
		if (__builtin_popcount(state) == k) {
			now.reset();
			for (int i = 1; i <= m; i++)
				if (state >> i - 1 & 1) now |= upd[i];
			ans = max(ans, int(now.count()));
		}
	printf("%d", ans);
	return 0;
}
