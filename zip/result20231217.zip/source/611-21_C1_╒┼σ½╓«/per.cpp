#include <bits/stdc++.h>
using namespace std;

const int mod = 1e9 + 7;
int T, n, sum;
const int dw[4][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}},
	a[4][4] = {{1, 0, 1, 1}, {1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 0, 1}},
	ac[4][4] = {{1, 0, 0, 0}, {1, 0, 0, 0}, {0, 0, 0, 0}, {1, 0, 0, 0}};
struct matrix {
	long long arr[4][4];

	matrix(const int a[4][4]) {
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
				arr[i][j] = a[i][j];
	}

	matrix() {memset(arr, 0, sizeof arr);}

	matrix operator * (const matrix x) const {
		matrix mul = matrix();
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
				for (int k = 0; k < 4; k++)
					mul.arr[i][j] = (mul.arr[i][j] + arr[i][k] * x.arr[k][j]) % mod;
		return mul;
	}
};

matrix power(matrix a, int n) {
	matrix ans(dw);
	while (n) {
		if (n & 1) ans = ans * a;
		a = a * a;
		n >>= 1;
	}
	return ans;
}

int main() {
	freopen("per.in", "r", stdin);
	freopen("per.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		matrix ans = power(a, n - 2) * ac;
		sum ^= ans.arr[0][0];
	}
	printf("%d", sum);
	return 0;
}
