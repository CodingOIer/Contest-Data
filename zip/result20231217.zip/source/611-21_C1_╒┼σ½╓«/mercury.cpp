#include <bits/stdc++.h>
using namespace std;

char ch;
long long sum[26];
long long ans;

int main() {
	freopen("mercury.in", "r", stdin);
	freopen("mercury.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	while (cin >> ch) sum[ch - 97]++;
	for (int i = 0; i < 26; i++) ans += sum[i] * sum[i];
	printf("%lld", ans);
	return 0;
}
