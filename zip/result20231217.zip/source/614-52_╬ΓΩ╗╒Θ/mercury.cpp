#include<bits/stdc++.h>
using namespace std;
string a;
long long n,b[105];
int main()
{
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>a;
	for(int i=0;i<a.size();i++)
		b[a[i]-'a']++;
	for(int i=0;i<=26;i++)
		n+=b[i]*b[i];
	cout<<n;
	return 0;
}
