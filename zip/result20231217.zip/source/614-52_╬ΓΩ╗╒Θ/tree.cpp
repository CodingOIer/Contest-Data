#include<bits/stdc++.h>
using namespace std;
const long long p=1e5+5;
long long n,m,fa[p],tp[p],id[p],rk[p],son[p],siz[p],dep[p],z[p],o,f[p],ans[p];
struct node{
	long long u,v,cnt,id; 
}a[p],b[p];
struct node1{
	long long v,cnt; 
};
struct tree{
	long long l,r,sum,rsiz,lsiz,add;
}tree1[p*4];
vector<node1>q[p];
bool cmp(node i,node j)
{
	return i.cnt>j.cnt;
}
void dfs(long long i)
{
	siz[i]=1;
	dep[i]=dep[fa[i]]+1;
	for(long long j=0;j<q[i].size();j++)
	{
		if(fa[i]==q[i][j].v) continue;
		fa[q[i][j].v]=i;
		z[q[i][j].v]=q[i][j].cnt;
		dfs(q[i][j].v);
		siz[i]+=siz[q[i][j].v];
		if(siz[son[i]]<siz[q[i][j].v])
			son[i]=q[i][j].v; 
	}
}
void dfs1(long long i,long long z)
{
	++o;
//	cout<<1;
	tp[i]=z;
	id[i]=o;
	rk[o]=i;
	if(!son[i]) return;
	dfs1(son[i],z); 
	for(long long j=0;j<q[i].size();j++)
	{
		if(fa[i]==q[i][j].v||son[i]==q[i][j].v) continue;
		dfs1(q[i][j].v,q[i][j].v);
	}
}
tree hb(tree i,tree j)
{
	if(i.l>=j.r) swap(i,j);
	tree z;
	z.l=i.l,z.r=j.r;
	z.sum=i.sum+j.sum;
	z.lsiz=i.lsiz,z.rsiz=j.rsiz;
	if(i.rsiz!=i.r-i.l+1&&j.rsiz!=j.r-j.l+1)
	z.sum+=f[i.rsiz+j.lsiz];
	if(i.rsiz==i.r-i.l+1)
		z.lsiz+=j.lsiz;
	if(j.rsiz==j.r-j.l+1)
		z.rsiz+=i.rsiz;
	return z;
}
void pushdown(long long id)
{
	if(tree1[id].add)
	{
		tree1[id*2].add=tree1[id*2+1].add=1;
		tree1[id*2].add=(tree1[id].r+tree1[id].l)/2-tree1[id].l+1;
		tree1[id*2+1].add=tree1[id].r-(tree1[id].r+tree1[id].l)/2;
		tree1[id].add=0;
	}
}
void build(long long l,long long r,long long id)
{
	if(l==r)
	{
		tree1[id].l=tree1[id].r=l;
		tree1[id].lsiz=tree1[id].rsiz=0;
		tree1[id].sum=0;
		return;
	}
	long long mid=(l+r)/2;
	build(l,mid,id*2);
	build(mid+1,r,id*2+1);
	tree1[id]=hb(tree1[id*2],tree1[id*2+1]);
}
void xg(long long l,long long r,long long nl,long long nr,long long id)
{
	if(nl<=l&&r<=nr)
	{
		tree1[id].lsiz=tree1[id].rsiz=tree1[id].r-tree1[id].l+1;
		tree1[id].add=1;
		return;
	}
//	cout<<l<<" "<<r<<'\n';
	long long mid=(l+r)/2;
	pushdown(id);
	if(mid>=nl) xg(l,mid,nl,nr,id*2);
	if(mid<nr) xg(mid+1,r,nl,nr,id*2+1);
	tree1[id]=hb(tree1[id*2],tree1[id*2+1]);
}
tree cz(long long l,long long r,long long nl,long long nr,long long id)
{
	tree anss;
	if(nl<=l&&r<=nr)
		return tree1[id];
	long long mid=(l+r)/2;
	pushdown(id);
	if(mid>=nl&&mid<nr) anss=hb(cz(l,mid,nl,nr,id*2),cz(mid+1,r,nl,nr,id*2+1));
	else if(mid>=nl) anss=cz(l,mid,nl,nr,id*2);
	else if(mid<nr) anss=cz(mid+1,r,nl,nr,id*2+1);
//	cout<<nl<<" "<<nr<<" "<<anss.l<<" "<<anss.r<<" "<<anss.sum<<" "<<f[anss.lsiz]<<'\n';
	return anss;
}
long long czl(long long l,long long r)
{
	tree anss1,anss2,anss3,anss4;
	long long o=0,x=0,y=0;
	while(tp[l]!=tp[r])
	{
		if(dep[tp[l]]<dep[tp[r]])	swap(l,r),o^=1;
		if(o==0) if(x==1) anss1=hb(anss1,cz(1,n,id[tp[l]],id[l],1));
		else anss1=cz(1,n,id[tp[l]],id[l],1),x=1;
		if(o==1) if(y==1) anss2=hb(cz(1,n,id[tp[l]],id[l],1),anss2);
		else anss2=cz(1,n,id[tp[l]],id[l],1),y=1;
		l=fa[tp[l]];
	} 
	if(dep[l]>dep[r]) swap(l,r);
	if(x==0) anss1=cz(1,n,id[l]+1,id[r],1),x=1;
	else anss1=hb(anss1,cz(1,n,id[l]+1,id[r],1));
	if(y==1)anss1=hb(anss1,anss2);
//	cout<<x<<" "<<y<<" "<<anss1.lsiz<<" "<<anss1.rsiz<<" "<<anss1.sum<<" "<<f[anss1.lsiz]<<'\n';
	if(anss1.rsiz==anss1.r-anss1.l+1)
		return f[anss1.rsiz];
	return anss1.sum+f[anss1.lsiz]+f[anss1.rsiz];
}
void xgl(long long l,long long r)
{
	while(tp[l]!=tp[r])
	{
		if(dep[tp[l]]<dep[tp[r]])	swap(l,r);
		xg(1,n,id[tp[l]],id[l],1);
		l=fa[tp[l]];
	}
	if(dep[l]>dep[r]) swap(l,r);
//		cout<<id[l]+1<<" "<<id[r]<<'\n';
	xg(1,n,id[l]+1,id[r],1);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m;
	for(long long i=1;i<n;i++)
		cin>>f[i];
	for(long long i=1;i<n;i++)
	{
		cin>>b[i].u>>b[i].v>>b[i].cnt;
		q[b[i].u].push_back((node1){b[i].v,b[i].cnt}),q[b[i].v].push_back((node1){b[i].u,b[i].cnt});
	}
	for(long long i=1;i<=m;i++)
		cin>>a[i].u>>a[i].v>>a[i].cnt,a[i].id=i;
	sort(a+1,a+m+1,cmp);
	sort(b+1,b+n+1,cmp);
	dfs(1);
	dfs1(1,1);
	build(1,n,1);
	for(long long i=1,j=1;j<=m;j++)
	{
//		cout<<1;
		while(b[i].cnt>=a[j].cnt&&i<n)
			xgl(b[i].u,b[i].v),i++;
//		cout<<a[j].u<<" "<<a[j].v<<'\n';
		ans[a[j].id]=czl(a[j].u,a[j].v);
	}
	for(long long i=1;i<=m;i++)
		cout<<ans[i]<<'\n';
	return 0;
}
