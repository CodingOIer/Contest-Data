#include<bits/stdc++.h>
using namespace std;
long long n,a,b,c,t,k,ans;
int main()
{
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>t;
	for(int z=1;z<=t;z++)
	{
		cin>>n>>k;
		ans=0;
		for(long long j=1;j<=n;j++)
			for(long long i=1;i<=j;i++)
				if(((j*j*j-i*i)%k+k)%k<=i)
					ans+=(i-(((j*j*j-i*i)%k+k)%k))/k+1-(((j*j*j-i*i)%k+k)%k==0);
		cout<<"Case "<<z<<": "<<ans<<'\n';
	}
	return 0;
}
