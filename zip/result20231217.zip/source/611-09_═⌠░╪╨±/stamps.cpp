#include <bits/stdc++.h>
using namespace std;
int n,m,k;
int l[2001]={};
int r[2002]={};
int ans[2002]={};
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>l[i]>>r[i];
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<=m;j++){
			if(l[i]-r[i]<l[j]-r[j]){
				swap(l[i],l[j]);
				swap(r[i],r[j]);
			}
		}
	}
//	for(int i=1;i<=m;i++){
//		cout<<l[i]<<" "<<r[i]<<endl;
//	}
//	int x=n,y=0;
	int x=0,y=0,z=0;
	for(int i=1;i<=k;i++){
		for(int j=1;j<=m;j++){
			for(int k=l[j];k<=r[j];k++){
//				cout<<ans[k]<<" "<<k<<endl;
				if(ans[k]==0){
					z++;
				}
			}
//			cout<<endl;
			if(z>x){
				x=z;
				y=j;
			}
//			cout<<x<<" "<<y<<" "<<z<<endl;
			z=0;
		}
//		cout<<x<<" "<<y<<" "<<z<<" "<<"*"<<endl;
//		for(int j=l[y];j<=r[y];j++) cout<<ans[j]<<" ";
//		cout<<"*"<<endl;
//		cout<<y<<endl;
		for(int u=l[y];u<=r[y];u++){
			ans[u]=1;
		}
		x=0;
	}
//	cout<<abs(y-x+1);
	int sum=0;
	for(int i=1;i<=n;i++){
//		cout<<ans[i]<<" ";
		if(ans[i]!=0){
			sum+=ans[i];
		}
	}
	cout<<sum;
	return 0;
}
