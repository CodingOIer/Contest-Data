#include <bits/stdc++.h>
using namespace std;
int a[27];
int main(){
	string s;
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	cin>>s;
//	cout<<int(s[0]-96);
	int n=s.length();
	for(int i=0;i<n;i++){
		a[int(s[i]-96)]++;
	}
	int ans=0;
	for(int i=0;i<n;i++){
		ans+=a[int(s[i]-96)];
	}
	cout<<ans;
	return 0;
} 
