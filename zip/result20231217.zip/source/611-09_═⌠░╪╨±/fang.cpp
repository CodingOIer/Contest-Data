#include <bits/stdc++.h>
using namespace std;
int t,n,k;
int ans=0;
int df(int a,int b,int c,int n,int k){
	if((a+b*b)%k==(c*c*c)%k&&a<=b&&b<=c){
//		cout<<a<<" "<<b*b<<" "<<c*c*c<<" "<<k<<" "<<(a+b*b)%k<<" "<<(c*c*c)%k<<endl;
		ans++;
		return 0;
	}
}
int dg(int a,int b,int c,int n,int k){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int u=1;u<=n;u++){
				df(i,j,u,n,k);
		}			}

	}
	return 0;
}
//a��b(mod m) 
//a��bͬ����m
//��m | (a-b) 
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n>>k;
		ans=0;
		dg(1,1,1,n,k);
		cout<<"Case "<<i<<": "<<ans<<endl;
	}
	return 0;
}
