#include<bits/stdc++.h>
using namespace std;
int n,q,a[1005][1005],f[1005],askl,askr;
int ans=0;
bool mark[1005];
vector<int> path;
void dfs(int d,int en,int w){
	if(ans) return; 
	if(d==en){
		for(int i=0;i<path.size();i++){
			if(path[i]>=w) path[i]=1;
			else path[i]=0;
		}
		int last=-1;
		for(int i=0;i<path.size();i++){
			if(path[i]==1){
				if(last!=-1) ans+=f[i-last];
				else ans+=f[i+1];
				last=i;
			} 
		}
		return;
	}
	for(int i=0;i<n;i++){
		if(mark[i]) continue;
		mark[i]=1;
		path.push_back(a[d][i]);
		dfs(a[d][i],en,w);
		path.pop_back();
		mark[i]=0;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>q;
	for(int i=0;i<n-1;i++) cin>>f[i];
	for(int i=0;i<n-1;i++){
		int u,v,w;
		cin>>u>>v>>w;
		a[u][v]=w;
		a[v][u]=w;
	}
	while(q--){
		int u,v,w;
		cin>>u>>v>>w;
		ans=0;
		dfs(u,v,w);
		cout<<ans<<endl;
	}
	return 0;
}

