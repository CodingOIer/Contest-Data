#include<bits/stdc++.h>
using namespace std;
int t,n,m;
int main(){
	freopen("fang.in","r",stdin);
	freopen("fang.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>t;
	int sb=t;
	while(t--){
		cin>>n>>m;
		int cnt=0;
		for(int i=1;i<=n;i++) for(int j=i;j<=n;j++) for(int k=j;k<=n;k++) if((i+j*j)%m==(k*k*k)%m) cnt++;
		cout<<"Case "<<sb-t<<": "<<cnt<<endl;
	}
	return 0;
}
