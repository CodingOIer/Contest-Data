#include<bits/stdc++.h>
using namespace std;
char a[100005];
int t[30];
long long s;
int main(){
	freopen("mercury.in","r",stdin);
	freopen("mercury.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>a;
	int n=strlen(a);
	for(int i=0;i<n;i++) t[a[i]-'a']++;
	for(int i=0;i<26;i++) if(t[i]>1) s+=t[i]*(t[i]-1);
	cout<<s+n;
	return 0;
}

