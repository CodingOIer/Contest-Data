#include<bits/stdc++.h>
using namespace std;
struct buy{
	int l,r,id;
}a[2005];
int n,m,k,arl,arr;
bool cmp(buy x,buy y){
	return (x.r-x.l)>(y.r-y.l);
}
bool mark[2005];
bool kkk[2005]; 
int main(){
	freopen("stamps.in","r",stdin);
	freopen("stamps.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m>>k;
	for(int i=0;i<m;i++){
		cin>>a[i].l>>a[i].r;
		a[i].id=i;
	}
	int mxx=-1,mxxi;
	for(int i=0;i<n;i++){
		if(a[i].r-a[i].l>mxx) mxx=a[i].r-a[i].l,mxxi=i;
	}
	for(int i=a[mxxi].l;i<=a[mxxi].r;i++){
		kkk[i]=1;
	}
	mark[mxxi]=1;
	for(int i=0;i<k-1;i++){
		int mx=-1,mxi;
		for(int j=0;j<m;j++){
			if(mark[a[j].id]) continue;
			int cnt=0;
			for(int k=a[j].l;k<=a[j].r;k++) if(!kkk[i]) cnt++;
			if(cnt>mx) mx=cnt,mxi=j;
		}
		for(int j=a[mxi].l;j<=a[mxi].r;j++) kkk[j]=1;
		mark[mxi]=1;
	}
	int ans=0;
	for(int i=0;i<n;i++) if(kkk[i]) ans++;
	cout<<ans;
	return 0;
}

