#include<bits/stdc++.h>
using namespace std;
int n,j=1;
long long t,ans,sum;
int a[100005];
int main() {
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%lld",&n,&t);
	for(int i=1; i<=n; i++)
		scanf("%d",&a[i]);
	for(int i=1; i<=n; i++) {
		if(a[j]==i)
			continue;	
		while(a[j]!=i) {
			ans++;
			j++;
			if(j==n+1)
				j=1;
		}
	}
	t-=n;
	if(t>0) {
		int k=t/n;
		while(k--)
			for(int i=1; i<=n; i++) {
				if(a[j]==i)
					continue;
				while(a[j]!=i) {
					j++;
					ans++;
					if(j==n+1)
						j=1;
				}
			}
		for(int i=1; i<=t%n; i++) {
			if(a[j]==i)
				continue;
			while(a[j]!=i) {
				j++;
				ans++;
				if(j==n+1)
					j=1;
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
/*
3 5
1 2 3

4 6
4 2 1 3

10 7
1 3 2 4 5 7 6 8 9 10
*/

