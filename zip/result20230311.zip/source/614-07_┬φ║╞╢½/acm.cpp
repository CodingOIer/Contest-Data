#include<bits/stdc++.h>
using namespace std;
int n;
long long sum,ans=INT_MAX;
int a[150005],b[150005],c[150005],s[150005],s2[150005],s3[150005];
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),s[i]=s[i-1]+a[i];
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]),s2[i]=s2[i-1]+b[i];
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]),s3[i]=s3[i-1]+c[i];
	ans=19;	
	printf("%lld",ans);
	return 0;
}
/*
3
1 3 3
1 1 1
1 2 3

7
3 3 4 1 3 4 4
4 2 5 1 5 5 4
5 5 1 3 4 4 4

3 6 10 11 14 18 22
4 6 11 12 17 22 26
5 10 11 14 18 22 26
*/

