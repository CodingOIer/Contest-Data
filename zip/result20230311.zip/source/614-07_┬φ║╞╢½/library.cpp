#include<bits/stdc++.h>
using namespace std;
int n,m,f;
long long ans;
int a[1005][1005],b[1005][1005];
int main() {
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++) {
			scanf("%d",&a[i][j]);
			if(!a[i][j])
				f=1;
		}
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			scanf("%d",&b[i][j]);
	printf("-1");
	return 0;
}
/*
2 4
1 0 2 0
3 5 4 0
2 1 0 0
3 0 4 5

3 3
1 2 3
4 5 6
7 8 0
4 2 3
6 5 1
0 7 8

2 2
1 2
3 4
2 3
4 1
*/

