#include<bits/stdc++.h>
using namespace std;
int n,k;
double ans,sum,cnt;
int a[300005];
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	cnt=k;	
	for(int i=1;i<=n-k+1;i++){
		sum=0;
		for(int j=i;j<=i+k&&j<=n;j++)
			sum+=a[j];	
		int j=i+k;	
		while(sum*(k+1)<=(sum+a[j+1])*k&&j<n)	
			sum+=a[++j];
		if(j>n)	
			j=n;				
		if(ans*(j-i+1)<=sum*cnt)
			ans=sum,cnt=j-i+1;	
	}
	printf("%.6f",ans/cnt);	
	return 0;
}
/*
4 1
1 2 3 4

4 2
2 4 3 4

6 3
7 1 2 1 3 6
*/

