#include<bits/stdc++.h>
using namespace std;
int k,x,t,a,b,c,d,f;
long long sum,ans=INT_MAX;
int s[25],s2[25];
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
		scanf("%d",&s[i]);
	scanf("%d%d%d%d%d%d",&x,&a,&b,&c,&d,&t);
	for(int i=1;i<=t;i++)
		scanf("%d",&s2[i]),sum+=s[s2[i]];
	for(int i=1;i<=t;i++)
		if(s2[i]==a||s2[i]==b||s2[i]==c||s2[i]==d){
			f=1;
			break;
		}	
	if(f){
		ans=x;
		for(int i=1;i<=t;i++)
			if(s2[i]==a)
				a=-INT_MAX;
			else if(s2[i]==b)
				b=-INT_MAX;
			else if(s2[i]==c)
				c=-INT_MAX;
			else if(s2[i]==d)
				d=-INT_MAX;			
			else
				ans+=s[s2[i]];
	}	
	ans=min(ans,sum);	
	printf("%lld",ans);	
	return 0;
}
/*
7
10 6 8 9 4 5 3
14
1 2 3 4
5
1 3 4 6 7

6
12 5 7 8 9 3
14
4 3 1 2
5
1 2 1 6 6

*/
