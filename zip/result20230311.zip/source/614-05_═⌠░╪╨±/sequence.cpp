#include <bits/stdc++.h>
using namespace std;
int a[1000001]={};
int main(){
	int n,k;
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	double ans=0;
	double o=0;
	int u=0;
	for(int i=1;i<=n;i++){
		if(a[i]>int(o)){
			o=a[i];
			u=i;
		}
	}
	ans=ans+double(o);
	int l=1;//left
	int r=1;//right
	for(int i=1;i<k;i++){
		if(a[u-l]>=a[u+r]){
			ans+=a[u-l];
			l++;
		}
		if(a[u-l]<a[u+r]){
			ans+=a[u+r];
			r++;
		}
	}
	if(k>1){
		for(int i=1;;i++){
			if(a[u-l]>=ans/k){
				ans+=a[u-l];
				l++;
				k++;
			}
			if(a[u-l]<ans/k){
				ans+=a[u+r];
				r++;
				k++;
			}
			if(a[u-l]<ans/k&&a[u+r]<ans/k){
				break;
			}
		}	
	}
	printf("%6lf",ans/k);
	return 0;
}
//����ȱ�ݣ�
//6 2
//1 0 2 7 0 9
//���޷������
//o_o (@_@) [-_-] ��!!! 
