#include <bits/stdc++.h>
using namespace std;
int a[100001]={};
int b[100001]={};
int main(){
	int n,m;
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	int t=n*m;
	for(int i=1;i<=t;i++){
		cin>>a[i];
	}
	for(int i=1;i<=t;i++){
		cin>>b[i];
	}
	int o=0;
	int u=0;
	for(int i=1;i<=t;i++){
		if(a[i]==0||b[i]==0){
			u++;
		}
	}
	if(u==0){
		for(int i=1;i<=t;i++){
			if(a[i]!=b[i]){
				o++;
			}
		}
		if(o==0){
			cout<<0;
		}
		if(o!=0){
			cout<<-1; 
		}		
	}
	if(u!=0){
//		int x=1,y=m;
//		for(int i=1;i<=n;i++){
//			for(int j=x;j<=y;j++){
//				
//			}
//		}
		cout<<(n+m)/2;
	}
	return 0;
}
