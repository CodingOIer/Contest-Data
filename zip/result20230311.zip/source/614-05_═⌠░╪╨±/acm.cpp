#include <bits/stdc++.h>
using namespace std;
int a[1000001]={};
int b[1000001]={};
int c[1000001]={};
int main(){
	int n;
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		ans+=min(min(a[i],b[i]),min(a[i],c[i]));
	}
	cout<<ans+1;
	return 0;
}
