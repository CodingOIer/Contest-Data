#include <bits/stdc++.h>
using namespace std;
int main(){
	double ans;
	cin>>ans;
	ans/=4;
	printf("%6lf",ans);
	return 0;
}
