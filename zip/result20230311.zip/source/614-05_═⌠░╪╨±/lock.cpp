#include <bits/stdc++.h>
using namespace std;
int a[100001]={};
int b[100001]={};
int main(){
	int n,t;
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	a[0]=1;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(t>n){
		int u=n;
		int o=0;
		for(int i=n+1;i<=t;i++){
			a[i]=a[i-u];
			o++;
			if(o==n){
				u-=n;
			}
		}		
	}
	for(int i=1;i<=t;i++){
		if(a[i]<a[i-1]){
			for(int j=1;;j++){
				a[i]+=n;
				if(a[i]>=a[i-1]){
					break;
				}
			}
		}
		b[i]=a[i];
	}
	b[0]=1;
//	for(int i=1;i<=t;i++){
//		cout<<b[i]<<" ";
//	}
	int sum=0;
	for(int i=1;i<=t;i++){
		sum+=b[i]-b[i-1];
	}
	cout<<sum;
	return 0;
}
