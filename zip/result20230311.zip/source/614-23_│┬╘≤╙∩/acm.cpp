#include<bits/stdc++.h>
#define int long long
using namespace std;

const int maxn=1.5e5+10;
int n,k,a[maxn],b[maxn],c[maxn],ans=INT_MAX;

signed main(){
	freopen("acm.in","r",stdin); 
	freopen("acm.out","w",stdout); 
	scanf("%lld",&n);
	for(int i=1;i<=n;++i) scanf("%lld",&k),a[i]=a[i-1]+k;
	for(int i=1;i<=n;++i) scanf("%lld",&k),b[i]=b[i-1]+k;
	for(int i=1;i<=n;++i) scanf("%lld",&k),c[i]=c[i-1]+k;
	for(int i=1;i+1<n;++i) for(int j=i+1;j<n;++j) 
	ans=min(min(min(min(min(min(ans,
	a[i]-a[0]+b[j]-b[i]+c[n]-c[j]),
	a[i]-a[0]+c[j]-c[i]+b[n]-b[j]),
	b[i]-b[0]+a[j]-a[i]+c[n]-c[j]),
	b[i]-b[0]+c[j]-c[i]+a[n]-a[j]),
	c[i]-c[0]+a[j]-a[i]+b[n]-b[j]),
	c[i]-c[0]+b[j]-b[i]+a[n]-a[j]);
	printf("%lld",ans);
	return 0;
}
