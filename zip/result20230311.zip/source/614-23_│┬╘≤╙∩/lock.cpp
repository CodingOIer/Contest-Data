#include<bits/stdc++.h>
#define int long long
using namespace std;

const int maxn=1e5+10;
int n,T,ans,mod,mid,a[maxn],p[maxn],f[maxn];
bool cmp(int x,int y){return a[x]<a[y];}

signed main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%lld%lld",&n,&T);
	for(int i=1;i<=n;++i) scanf("%lld",a+i),p[a[i]]=i;
	for(int i=1;i<n;++i){
		ans+=((p[i+1]+n-p[i])%n);
		if(i+1==T%n) mod=ans;
	}
	mid=(p[1]+n-p[n])%n,ans+=mid;
	printf("%lld",ans*(T/n)-(T/n>0)*mid*(T/n-1)+mod+(p[1]+n-1)%n);
	return 0;
}
