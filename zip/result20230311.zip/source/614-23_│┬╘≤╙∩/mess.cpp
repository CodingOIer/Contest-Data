#include<bits/stdc++.h>
using namespace std;

int n,m,k,x1,x2,x3,x4,ans,a[100],b[100],t[1000];
bool cmp(int a,int b){return t[a]<t[b];}

int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",a+i);
	scanf("%d%d%d%d%d%d",&k,&x1,&x2,&x3,&x4,&m);
	for(int i=1;i<=m;++i) scanf("%d",b+i),++t[b[i]];
	int p[10]={0,x1,x2,x3,x4};
	for(int i=1;i<=n;++i) ans+=(a[i]*t[i]);
	ans-=(a[p[1]]*t[p[1]]+a[p[2]]*t[p[2]]+a[p[3]]*t[p[3]]+a[p[4]]*t[p[4]]);
	sort(p+1,p+5,cmp);
	for(int i=1;i<=4;++i){
		ans+=min(a[p[1]]*t[p[1]]+a[p[2]]*t[p[2]]+a[p[3]]*t[p[3]]+a[p[4]]*t[p[4]],t[p[i]]*k);
		int now=t[p[i]];
		for(int j=i;j<=4;++j) t[p[j]]-=now;
	}
	printf("%d",ans);
	return 0;
}
