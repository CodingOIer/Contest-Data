#include<bits/stdc++.h>
using namespace std;
long long n,k,t,x,x1[10],k1[30],t1[40],bz[50];
int main() {
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1; i<=k; i++) {
		cin>>k1[i];
	}
	cin>>x;
	for(int i=1; i<=4; i++) {
		cin>>x1[i];
	}
	cin>>t;
	for(int i=1; i<=t; i++) {
		cin>>t1[i];	
	}
	int sum=0;

	for(int i=1; i<=4; i++) {	
		for(int j=1; j<=t; j++) {
		if(x1[i]==t1[j]) {
			sum+=k1[t1[j]];
			t1[j]*=-1;
			break;
		}
		}
	}
	int da=0;
	
	if(x>sum){
		for(int i=1;i<=t;i++){
			if(t1[i]<0) t1[i]*=-1;
			da+=k1[t1[i]];
		}
		cout<<da;
	}
	else{
		for(int i=1;i<=t;i++){
			if(t1[i]>0) da+=k1[t1[i]];
			
		}
		cout<<x+da;
	}
	return 0;
}

