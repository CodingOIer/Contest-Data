#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,m,a;
	cin>>n>>m;
	for(int i=1;i<=n*2;i++){
		for(int j=1;j<=m;j++){
			cin>>a;
		}
	}
	cout<<-1;
	return 0;
}

