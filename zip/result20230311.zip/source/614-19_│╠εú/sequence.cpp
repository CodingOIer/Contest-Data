#include<bits/stdc++.h>
using namespace std;
const int maxn=114514;
struct tree {
	int l,r;
	long long pre,add;
} t[4*maxn+2];
/*void bulid(int p,int l,int r){
    t[p].l=l;t[p].r=r;
    if(l==r){
        t[p].pre=a[l];
        return;
    }
    int mid=l+r>>1;
    bulid(p*2,l,mid);
    bulid(p*2+1,mid+1,r);
    t[p].pre=t[p*2].pre+t[p*2+1].pre;
} */
long long sum,n,a[300008],sum1;
double k,s;
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1; i<=n; i++) {
		cin>>a[i];
	}
//	bulid(1,1,n);
	for(double h=k; h<=n; h++) {
		for(int i=1; i<=n-h+1; i++) {
			for(int j=0; j<h; j++) {
				sum1+=a[i+j];
			}
			sum=max(sum,sum1);
			sum1=0;
		}
		
			double x=sum/h;
		//	cout<<x<<endl;
		s=max(s,x);
	}
	printf("%.6f",s);

	return 0;
}

