#include<bits/stdc++.h>
using namespace std;
int n,t,a[100001],door;
long long WA;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d %d",&n,&t);
	for(int i=1;i<=n;++i) scanf("%d",a+i);
	door=1;
	if(t<=n)
	{
		for(int i=1;i<=t;++i)
			while(a[door]!=i) door=(door+1>n)?1:door+1,++WA;
		cout<<WA;
	}
	else
	{
		for(int i=1;i<=n;++i)
			while(a[door]!=i) door=(door+1>n)?1:door+1,++WA;
		while(a[door]!=1) door=(door+1>n)?1:door+1,++WA;
		--t,WA*=t/n,t%=n;
		++t; 
		for(int i=1;i<=t;++i)
			while(a[door]!=i) door=(door+1>n)?1:door+1,++WA;
		cout<<WA;
	}
	return 0;
}
