#include<bits/stdc++.h>
using namespace std;
int n,t,a[100001],door,WA;
int main()
{
//	freopen("lock.in","r",stdin);
//	freopen("lock.out","w",stdout);
	scanf("%d %d",&n,&t);
	for(int i=1;i<=n;++i) scanf("%d",a+i);
	door=1;
	for(int i=1,j=1;i<=t;++i,j=(j+1>n)?1:j+1)
		while(a[door]!=j) door=(door+1>n)?1:door+1,++WA;
	cout<<WA;
	return 0;
}

