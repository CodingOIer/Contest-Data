#include<bits/stdc++.h>
using namespace std;
int n,k,a[300001];
double sum,ans;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;++i) scanf("%d",a+i),a[i]+=a[i-1];
	for(int len=k;len<=n;++len)
	{
		for(int i=len;i<=n;++i)
			sum=max(sum,(a[i]-a[i-len])*1.0/len);
		if(sum<ans) break;
		else ans=sum;
	}
	printf("%.15lf",ans);
	return 0;
}
