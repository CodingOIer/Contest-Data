#include<bits/stdc++.h>
using namespace std;
short k,a[21],b,c;
short vis[21];
short yes,no;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;++i) cin>>a[i];
	cin>>yes;
	for(int i=1;i<=4;++i) cin>>b,++vis[b];
	cin>>k;
	for(int i=1;i<=k;++i)
	{
		cin>>c;
		if(!vis[c]) yes+=a[c];
		else --vis[c];
		no+=a[c];
	}
	cout<<min(yes,no);
	return 0;
}
