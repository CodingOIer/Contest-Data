#include<cstdio>
#include<cstring>
using namespace std;
#define rep(i,l,r) for(int i=l;i<=r;i++)
#define MAXN 1010
int n,m,a[MAXN][MAXN],b[MAXN][MAXN],wh[MAXN*MAXN],wl[MAXN*MAXN],q[MAXN],ql=1,qr,ans,sum,k,e[MAXN],f[MAXN][MAXN];
bool p[MAXN],l[MAXN][MAXN];
bool pan()
{
     rep(i,1,n)if(p[i])return false;
     rep(i,1,n)
       rep(j,1,m)
         if(a[i][j]!=b[i][j]){printf("-1");return true;}
     printf("0");
     return true;
}
void bfs()
{
     while(ql<=qr)
     {
       rep(i,1,n)
         if(l[q[ql]][i] && !p[i])q[++qr]=i;
       ql++;
     }
}
void work(int h)
{
     int es=0,el,er,ha;
     rep(i,1,m)if(wh[a[h][i]]==h)e[++es]=wl[a[h][i]];
     qr=0;
     rep(i,1,es)
     {
       el=1;er=qr;ha=0;
       while(el<=er)
       {
         int mid=el+er>>1;
         if(q[mid]<e[i]){ha=mid;el=mid+1;}
         else er=mid-1;
       }
       if(ha+1>qr)q[++qr]=e[i];
       else q[ha+1]=q[ha+1]<e[i]?q[ha+1]:e[i];
     }
     ans-=qr;
}
void work2(int h)
{
     int es=0,el,er,ha;
     rep(i,1,m)if(wh[a[h][i]]==h)e[++es]=wl[a[h][i]];
     rep(i,1,e[1]-1)f[1][i]=0;
     rep(i,e[1],300)f[1][i]=1;
     rep(i,2,es)
     {
       rep(j,1,e[i]-1)f[i][j]=f[i-1][j];
       f[i][e[i]]=f[i-1][e[i]]+1;
       rep(j,e[i]+1,300)f[i][j]=f[i][j]>f[i][j-1]?f[i][j]:f[i][j-1];
     }
     ans-=f[es][300];
}
int main()
{
    freopen("library.in","r",stdin);
    freopen("library.out","w",stdout);
    //memset(p,false,sizeof(p));
    scanf("%d%d",&n,&m);
    rep(i,1,n)
      rep(j,1,m)
      {
        scanf("%d",&a[i][j]);
        if(!p[i] && !a[i][j]){p[i]=1;q[++qr]=i;}
      }
    rep(i,1,n)
      rep(j,1,m)
      {
        scanf("%d",&b[i][j]);
        if(b[i][j])
        {
          wh[b[i][j]]=i;wl[b[i][j]]=j;
          k=k>b[i][j]?k:b[i][j];
        }
      }
    rep(i,1,n)
      rep(j,1,m)
        if(a[i][j] && wh[a[i][j]]!=i)
        {l[wh[a[i][j]]][i]=1;}//printf("ha");}
    if(pan())return 0;
    bfs();
    rep(i,1,n)
    if(!p[i])
    {
      ans++;p[i]=true;
      q[++qr]=i;bfs();
    }
    rep(i,1,n)work(i);
    rep(i,1,n)
    {
      bool ha=true;
      rep(j,1,m)if(a[i][j]!=b[i][j] || !a[i][j]){ha=false;break;}
      ans-=ha;
    }
    printf("%d\n",ans+k);
    return 0;
}
