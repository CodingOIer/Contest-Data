#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+5;
int n,T,s=1,q[N],t,ans;
signed main() {
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%lld%lld",&n,&T);
	for(int i=0;i<n;++i)	scanf("%lld",q+i);
	while(T--) {
		while(q[t]!=s)	t=(t+1)%n,++ans;
		s=s%n+1;
	}
	printf("%lld",ans);
	return 0;
}

