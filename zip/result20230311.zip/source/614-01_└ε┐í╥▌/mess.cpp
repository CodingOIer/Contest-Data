#include <bits/stdc++.h>
using namespace std;
const int N=1005;
int k,x,T,a[N],w[N],t[N];
int ans,ans2,tx[N];
int main() {
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;++i)	scanf("%d",a+i);
	scanf("%d",&x);
	for(int i=1;i<=4;++i)	scanf("%d",t+i);
	scanf("%d",&T);
	for(int i=1;i<=T;++i)	scanf("%d",w+i);
	for(int i=1;i<=T;++i)	ans+=a[w[i]];
	for(int i=1;i<=T;++i)	++tx[w[i]];
	for(int i=1;i<=4;++i)	--tx[t[i]];
	ans2=x;
	for(int i=1;i<=T;++i)
		if(tx[w[i]]>0)	ans2+=a[w[i]],--tx[w[i]];
	printf("%d",min(ans,ans2));
	return 0;
}

