#include <bits/stdc++.h>
using namespace std;
const int N=1005;
int n,m,a[N][N];
int now[N][N];
int main() {
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cout<<-1;return 0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)	scanf("%d",&now[i][j]);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)	scanf("%d",&a[i][j]);
	return 0;
}

