#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+5;
int n,T,T2,s1=1,s2=1,tt,ans2;
int q[N],tx,t1,t2,ch,ans1,ans;
signed main() {
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%lld%lld",&n,&T);	tx=T2=T;
	for(int i=0;i<n;++i)	scanf("%lld",q+i);
	while(T2>0) {
		while(s1!=q[t1])	t1=(t1+1)%n,++ans1;
		s1=s1%n+1,--T;
		while(s2!=q[t2])	t2=(t2+1)%n,++ans2;
		s2=s2%n+1,--T2;
		if(T2<=0)	break;
		while(s2!=q[t2])	t2=(t2+1)%n,++ans2;
		s2=s2%n+1,--T2;
		if(s1==s2)	break;
	}
	if(T2) {
		while(T-->T2) {
			while(s1!=q[t1])	t1=(t1+1)%n;
			s1=s1%n+1,++ch;
		}
		ans=tx/ch*ans1;
		if(tx%ch) {
			tt=tx%ch;
			while(tt--) {
				while(s1!=q[t1])	t1=(t1+1)%n,++ans;
				s1=s1%n+1;
			}
		}
	}
	printf("%lld",max(ans,ans2));
	return 0;
}

