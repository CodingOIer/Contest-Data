#include <bits/stdc++.h>
using namespace std;
signed main() {
	ios::sync_with_stdio(false);
	freopen("sequence.in","w",stdout);
	srand(time(NULL));
	int n;
	cin>>n;
	cout<<n<<' '<<rand()%n<<endl;
	for(int i=0;i<n;++i)cout<<rand()%(1000001)<<' ';
	return 0;
}

