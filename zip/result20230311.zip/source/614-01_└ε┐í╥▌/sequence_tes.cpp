#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e6+5;
int n,k,a[N],sum[N];
double ans;
signed main() {
	//freopen("sequence.in","r",stdin);
	//freopen("sequence.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;++i)	scanf("%lld",a+i),sum[i]=a[i]+sum[i-1];
	for(int i=k;i<=n;++i)
		for(int j=i;j<=n;++j) {
			if((double)(sum[j]-sum[i-k])/(j-(i-k))>ans)
				ans=(double)(sum[j]-sum[i-k])/(j-(i-k));
			if(a[j]>a[j+1])break;
		}
	printf("%.6lf",ans);
	return 0;
}

