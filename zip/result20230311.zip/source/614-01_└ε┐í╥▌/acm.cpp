#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=150005;
int n,a[4][N],res=1e9;
int f[N],sum[4][N];
signed main() {
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=3;++i)
		for(int j=1;j<=n;++j)
			scanf("%lld",&a[i][j]),sum[i][j]=a[i][j]+sum[i][j-1];
	for(int i=1;i<n-1;++i) {
		for(int j=1;i+j<n;++j) {
			res=min(sum[1][i]+sum[2][i+j]-sum[2][i]+sum[3][n]-sum[3][i+j],res);
			res=min(sum[2][i]+sum[3][i+j]-sum[3][i]+sum[1][n]-sum[1][i+j],res);
			res=min(sum[3][i]+sum[2][i+j]-sum[2][i]+sum[1][n]-sum[1][i+j],res);
			res=min(sum[1][i]+sum[3][i+j]-sum[3][i]+sum[2][n]-sum[2][i+j],res);
			res=min(sum[2][i]+sum[1][i+j]-sum[1][i]+sum[3][n]-sum[3][i+j],res);
			res=min(sum[3][i]+sum[1][i+j]-sum[1][i]+sum[2][n]-sum[2][i+j],res);
		}
	}
	cout<<res;
	return 0;
}

