#include<bits/stdc++.h>
using namespace std;
int n,a[21],ans,val,id,sum,t,vis[21]; 
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	scanf("%d",&val);
	for(int i=1;i<=4;i++){
		scanf("%d",&id);
		vis[id]++;
	}scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d",&id);
		if(vis[id]){
			sum+=a[id];
			vis[id]--;
		}
		ans+=a[id];
	}if(val<sum) ans+=val-sum;
	printf("%d",ans);
	return 0;
}

