#include<bits/stdc++.h>
using namespace std;
int n,t,key[100005],c;
long long ans,sum[100005];
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%d",&n,&t);
	key[0]=1;
	for(int i=1;i<=n;i++){
		scanf("%d",&key[i]);
		ans+=key[i]-key[i-1]+n*(key[i]<key[i-1]);
		if(i==t){
			printf("%d",ans);
			return 0;
		}
	}
	t-=n;
	key[0]=key[n];
	for(int i=1;i<=n;i++){
		sum[i]=sum[i-1]+key[i]-key[i-1]+n*(key[i]<key[i-1]);
	}
	ans+=t/n*sum[n];
	t%=n;
	ans+=sum[t];
	printf("%d",ans);
	return 0;
}

