#include<bits/stdc++.h>
using namespace std;
int n,f[2][8][3][2],dft[3][150005],minn=2e9;
int len(int num){
	int cnt=0;
	for(int p=0;p<3;p++)
		if((num>>p)&1) cnt++;
	return cnt; 
}
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int p=0;p<3;p++)
		for(int i=1;i<=n;i++)
			scanf("%d",&dft[p][i]);
	for(int i=1;i<=n;i++){
		for(int z=1;z<=7;z++){
			for(int p=0;p<3;p++) f[i&1][z][p][0]=f[i&1][z][p][1]=minn;
			if(len(z)>i) continue;
			for(int p=0;p<3;p++){
				if(!((z>>p)&1)) continue;
				f[i&1][z][p][0]=min(f[1-(i&1)][z][p][0],f[1-(i&1)][z][p][1])+dft[p][i];
				for(int pp=0;pp<3;pp++){
					if(!((z>>pp)&1)||pp==p) continue;
					f[i&1][z][p][1]=min(f[i&1][z][p][1],f[1-(i&1)][z-(1<<p)][pp][0]+dft[p][i]);
					f[i&1][z][p][1]=min(f[i&1][z][p][1],f[1-(i&1)][z-(1<<p)][pp][1]+dft[p][i]);	
				}
			}
		}
	}for(int p=0;p<3;p++){
		minn=min(minn,min(f[n&1][7][p][0],f[n&1][7][p][1]));
	}printf("%d",minn);
	return 0;
}

