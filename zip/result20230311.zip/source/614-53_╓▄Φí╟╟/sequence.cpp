#include<bits/stdc++.h>
using namespace std;
int n,k,h[100005],id;
long long sum[100005];
double p[100005],pp,mx; 
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&h[i]);
		sum[i]=sum[i-1]+h[i]; 
	}
	p[n+1]=1e17;
	for(int i=n;i;i--){
		p[i]=(sum[n]-sum[i-1])/1.0/(n-i+1);
	}
	for(int l=1;l+k-1<=n;l++){
		pp=(sum[n]-sum[l-1])/1.0/(n-l+1); 
		for(int i=l+k;i<=n;i++){
			if(p[i]<pp){
				pp=(sum[i-1]-sum[l-1])/1.0/(i-l);
				break;
			}
		}
		mx=max(mx,pp);
	}printf("%0.6lf",mx);
	return 0;
}

