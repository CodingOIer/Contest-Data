#include<bits/stdc++.h>
#define name "lock"
#define van long long 
#define N 100010
using namespace std;
van a[N],p[N],sum[N],d[N];
van n,t;
int main()
{
	ifstream ywhin(((string)name+(string)".in").c_str());
	ofstream ywhout(((string)name+(string)".out").c_str());
	ywhin>>n>>t;;
	for (van i=1;i<=n;i++)
	{
		ywhin>>a[i];
		p[a[i]]=i;
	}
	for (van i=1;i<n;i++) 
		if (p[i+1]<p[i]) d[i]=p[i+1]+n-p[i];
		else d[i]=p[i+1]-p[i];
	if (p[1]<p[n]) d[n]=p[1]+n-p[n];
	else d[n]=p[1]-p[n];
	for (van i=1;i<=n;i++) sum[`i]=sum[i-1]+d[i];
	van ans=p[1];
	while (t>=n) ans+=sum[n],t-=n;
	ans+=sum[t-1];
	ywhout<<ans-1;
}
