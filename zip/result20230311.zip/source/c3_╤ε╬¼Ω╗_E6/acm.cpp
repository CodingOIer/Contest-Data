#include<bits/stdc++.h>
#define name "acm"
#define van long long 
#define N 160010
using namespace std;
van a[N],b[N],c[N],asum[N],bsum[N],csum[N],n;
van ans=1e18,aa,bb;
int main()
{
	ifstream ywhin(((string)name+(string)".in").c_str());
	ofstream ywhout(((string)name+(string)".out").c_str());
	ywhin>>n;
	for (van i=1;i<=n;i++){ywhin>>a[i];asum[i]=asum[i-1]+a[i];}
	for (van i=1;i<=n;i++){ywhin>>b[i];bsum[i]=bsum[i-1]+b[i];}
	for (van i=1;i<=n;i++){ywhin>>c[i];csum[i]=csum[i-1]+c[i];}
	for (van i=1;i<n-1;i++) for (van j=i+1;j<n;j++)
	{
		ans=min(ans,min(
				asum[i]+bsum[j]-bsum[i]+csum[n]-csum[j],min(
				bsum[i]+asum[j]-asum[i]+csum[n]-csum[j],min(
				bsum[i]+csum[j]-csum[i]+asum[n]-asum[j],min(
				csum[i]+bsum[j]-bsum[i]+asum[n]-asum[j],min(
				csum[i]+asum[j]-asum[i]+bsum[n]-bsum[j],
				asum[i]+csum[j]-csum[i]+bsum[n]-bsum[j]))))));
	}
	ywhout<<ans<<endl;
}
