#include<bits/stdc++.h>
#define name "sequence"
#define van long long 
#define N 300010
using namespace std;
van VanYoung[N],sum,t=1,n,k;double ans;
int main()
{
	ifstream ywhin(((string)name+(string)".in").c_str());
	ofstream ywhout(((string)name+(string)".out").c_str());
	ywhin>>n>>k;
	for (van i=1;i<=n;i++)
	{
		ywhin>>VanYoung[i];
		if (i<=k) sum+=VanYoung[i];
	}
	ans=((double)sum)/((double)k);
	for (van i=k+1;i<=n;i++)
	{
		while(VanYoung[i]>VanYoung[t]&&(i-t+1)>k) sum-=VanYoung[t++];
		sum+=VanYoung[i];
		ans=max(ans,((double)sum)/((double)(i-t+1)));
	}
	ywhout<<fixed<<setprecision(100)<<ans;
}
