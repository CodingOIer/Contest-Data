#include<bits/stdc++.h>
#define name "mess"
#define van long long 
#define N 50
using namespace std;
van cost[N],need[N];
van n,t,ts;
van tao[5];
int main()
{
	ifstream ywhin(((string)name+(string)".in").c_str());
	ofstream ywhout(((string)name+(string)".out").c_str());
	ywhin>>n;
	for (van i=1;i<=n;i++) ywhin>>cost[i];
	ywhin>>ts;
	for (van i=1;i<=4;i++) ywhin>>tao[i];
	ywhin>>t;
	for (van i=1;i<=t;i++)
	{
		van a;
		ywhin>>a;
		need[a]++;
	}
	van ans=0;
	while (1)
	{
		van now=0;
		for (van i=1;i<=4;i++) if (need[tao[i]]!=0) now+=cost[tao[i]];
		if (now<ts) break;
		ans+=ts;
		for (van i=1;i<=4;i++) if (need[tao[i]]!=0) need[tao[i]]--;
	}
	for (van i=1;i<=n;i++) ans+=need[i]*cost[i];
	ywhout<<ans<<endl;
}
