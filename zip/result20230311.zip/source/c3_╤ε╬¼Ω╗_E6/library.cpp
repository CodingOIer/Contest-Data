#include<bits/stdc++.h>
#define name "library"
#define van long long 
#define N 1010
using namespace std;
van a[N][N];
van n,m,p[N*N];
int main()
{
	ifstream ywhin(((string)name+(string)".in").c_str());
	ofstream ywhout(((string)name+(string)".out").c_str());
	ywhin>>n>>m;
	for (van i=1;i<=n;i++) for (van j=1;j<=m;j++) ywhin>>a[i][j];
	ywhout<<-1<<endl;
}
