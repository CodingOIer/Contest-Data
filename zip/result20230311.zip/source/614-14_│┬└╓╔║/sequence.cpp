#include<bits/stdc++.h>
using namespace std;
int n,k,a[300001];
int b[100001];
int l,r,u;
double ans,sum;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) {
		cin>>a[i];
		b[i]=a[i]+b[i-1];
	}
	for(int i=k;i<=n;i++) {
		l=i-k+1;r=i;u=k;
		sum=(double)(b[r]-b[l-1])/u;
		while(a[l-1]>=sum){
			l--;
			u++;
			sum=(double)(b[r]-b[l-1])/u;
			if(u==k*2) break;
			if(sum<ans) break;
		}
		ans=max(ans,sum); 
	}
	printf("%.6f",ans);
	return 0;
}

