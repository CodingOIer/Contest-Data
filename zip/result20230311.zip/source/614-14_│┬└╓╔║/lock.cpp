#include<bits/stdc++.h>
using namespace std;
int n,t,w,a[100001];
int b[100001],x,y,q;
long long ans;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[a[i]]=i;
	}
	if(n==1){
		cout<<0;
		return 0;
	}
	for(int i=1;i<=n;i++){
		x=b[i],y=b[i-1];
		if(i<2) y=b[n];
		if(x<y) x+=n;
		w+=x-y;
	}
	int u=b[1]-b[n];
	if(u<=0) u+=n;
	ans=ans+w*(t/n)-u+b[1]-1;
	t%=n;
	for(int i=1;i<=t;i++) {
		x=b[i],y=b[i-1];
		if(i<2) y=b[n];
		if(x<y) x+=n;
		ans+=x-y;
	}
	cout<<ans;
	return 0;
}

