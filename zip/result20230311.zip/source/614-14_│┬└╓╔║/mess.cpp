#include<bits/stdc++.h>
using namespace std;
int k,a[21],x,w[5],t,u,s[5],ans;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
		cin>>a[i];
	cin>>x;
	cin>>w[1]>>w[2]>>w[3]>>w[4];
	cin>>t;
	for(int i=1;i<=t;i++) {
		cin>>u;
		if(u==w[1]) s[1]++;
		if(u==w[2]) s[2]++;
		if(u==w[3]) s[3]++;
		if(u==w[4]) s[4]++;
		if(u!=w[1]&&u!=w[2]&&u!=w[3]&&u!=w[4])
			ans+=a[u];
	}
	int sum=1;
	while(sum){
		sum=0;
		for(int i=1;i<5;i++) {
			if(s[i]) {sum+=a[w[i]];s[i]--;}
		}
		if(sum==0) break;
		ans+=min(x,sum);
	}
	cout<<ans;
	return 0;
}

