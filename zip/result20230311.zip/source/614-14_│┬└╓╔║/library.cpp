#include<bits/stdc++.h>
using namespace std;
int n,m,ka[1001],ans;
int a[1001][1001],b[1001][1001];
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	int f1=1,f2=1;
	int q,u;
	for(int i=1;i<=n;i++){
		q=1;
		for(int j=1;j<=m;j++){
			cin>>u;
			if(u==0){
				ka[i]++;
				f1=0;
			}else{
				a[i][q++]=u;
			}
			
		}
	}
		
	for(int i=1;i<=n;i++){
		q=1;
		for(int j=1;j<=m;j++){
			cin>>u;
			if(u!=0){
				b[i][q++]=u;
				if(b[i][q-1]!=a[i][q-1])
					f2=0;
			}
		}
	}
	if(f2) {
		cout<<0;
		return 0;
	}
	if(f1) {
		cout<<-1;
		return 0;
	}
	int f;
	for(int i=1;i<=n;i++){
		f=0;
		for(int j=1;j<=m;j++){
//			cout<<a[i][j]<<" ";
			if(a[i][j]!=b[i][j]){
				ans++;
				f++;
//				cout<<".\n";
			}
		}
		if(ka[i]>0&&f){
			ans-=f/2;
		}	
	}
	cout<<ans;
	return 0;
}

