#include<bits/stdc++.h>
using namespace std;
int n,ans=1e9;
int q[150001][4];
int a,b,c,d,e,f;
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>q[i][1];
	for(int i=1;i<=n;i++) cin>>q[i][2];
	for(int i=1;i<=n;i++) cin>>q[i][3];
	for(int i=1;i<=n;i++) {
		q[i][1]+=q[i-1][1];
		q[i][2]+=q[i-1][2];
		q[i][3]+=q[i-1][3];
	}
	for(int i=2;i<n;i++) {
		for(int j=i;j<n;j++) {
			a=q[i-1][1]+(q[j][2]-q[i-1][2])+(q[n][3]-q[j][3]);
			b=q[i-1][1]+(q[j][3]-q[i-1][3])+(q[n][2]-q[j][2]);
			c=q[i-1][2]+(q[j][1]-q[i-1][1])+(q[n][3]-q[j][3]);
			d=q[i-1][2]+(q[j][3]-q[i-1][3])+(q[n][1]-q[j][1]);
			e=q[i-1][3]+(q[j][1]-q[i-1][1])+(q[n][2]-q[j][2]);
			f=q[i-1][3]+(q[j][2]-q[i-1][2])+(q[n][1]-q[j][1]);
			ans=min(ans,min(min(a,b),min(min(c,d),min(e,f))));
		}
	}
	cout<<ans;
	return 0;
}

