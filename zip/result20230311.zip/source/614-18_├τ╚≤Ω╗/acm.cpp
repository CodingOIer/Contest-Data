#include<bits/stdc++.h>
using namespace std;
int a[3][150005];
int main(){
	int n,a1,a2,a3,b1,b2,b3,c1,c2,c3,suma=0,sumb=0,sumc=0,ans=INT_MAX;
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=0;i<3;i++){
		for(int j=0;j<n;j++){
			cin>>a[i][j];
			if(i==0)
				suma+=a[i][j];
			if(i==1)
				sumb+=a[i][j];
			if(i==2)
				sumc+=a[i][j];
		}
	}
	a1=a[0][0];
	a2=a[0][1];
	a3=suma-a[0][0]-a[0][1];
	b1=a[1][0];
	b2=a[1][1];
	b3=sumb-a[1][0]-a[1][1];
	c1=a[2][0];
	c2=a[2][1];
	c3=sumc-a[2][0]-a[2][1];
	ans=min(a1+b2+c3,min(b1+a2+c3,min(b1+c2+a3,min(c1+b2+a3,min(c1+a2+b3,a1+c2+b3)))));
	for(int i=2;i<n-1;i++){
		a3-=a[0][i];
		a2+=a[0][i];
		b3-=a[1][i];
		b2+=a[1][i];
		c3-=a[2][i];
		c2+=a[2][i];
		for(int j=1,l,d1=a1,d2=a2,d3=a3,e1=b1,e2=b2,e3=b3,f1=c1,f2=c2,f3=c3;j<i;j++){
			d2-=a[0][j];
			d1+=a[0][j];
			e2-=a[1][j];
			e1+=a[1][j];
			f2-=a[2][j];
			f1+=a[2][j];
			ans=min(ans,min(d1+e2+f3,min(d1+f2+e3,min(f1+d2+e3,min(f1+e2+d3,min(e1+f2+d3,e1+f2+d3))))));
		}
	}
	cout<<ans;
	return 0;
}
