#include<bits/stdc++.h>
using namespace std;
long long a[100005],b[100005];
int main(){
	long long ans,n,t;
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(long long i=0,syg=1;i<n;i++){
		cin>>a[i];
		if(a[i]>=syg)
			b[i]=a[i]-syg;
		else
			b[i]=n-syg+a[i];
		if(i>1)
			b[i]+=b[i-1];
		syg=a[i];
	}
	if(a[0]>=a[n-1])
		b[0]=a[0]-a[n-1];
	else
		b[0]=n-a[n-1]+a[0];
	ans=t/n*b[n-1]+a[0]-1+(t/n-1)*b[0];
	if(t%n!=0){
		if(t%n!=1)
			ans+=(b[0]+b[t%n-1]);
		else
			ans+=b[0];
	}
	cout<<ans;
	return 0;
}
