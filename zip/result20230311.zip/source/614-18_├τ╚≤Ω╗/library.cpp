#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m;
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int l=0;l<2;l++){
		for(int i=0;i<n;i++){
			for(int j=0,a;j<m;j++)
				cin>>a;
		}
	}
	cout<<-1;
	return 0;
}
