#include<bits/stdc++.h>
using namespace std;
int a[25],b[25];
int main(){
	int k,x,tc1,tc2,tc3,tc4,t,ans=0,cs1=0,cs2=0,cs3=0,cs4=0;
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=0;i<k;i++)
		cin>>a[i];
	cin>>x>>tc1>>tc2>>tc3>>tc4>>t;
	tc1-=1;
	tc2-=1;
	tc3-=1;
	tc4-=1;
	for(int i=0;i<t;i++){
		cin>>b[i];
		b[i]-=1;
		ans+=a[b[i]];
		if(b[i]==tc1)
			cs1++;
		else if(b[i]==tc2)
			cs2++;
		else if(b[i]==tc3)
			cs3++;
		else if(b[i]==tc4)
			cs4++;
	}
	for(int i=1,bj;i<=max(cs1,max(cs2,max(cs3,cs4)));i++){
		bj=0;
		if(cs1>=i)
			bj+=a[tc1];
		if(cs2>=i)
			bj+=a[tc2];
		if(cs3>=i)
			bj+=a[tc3];
		if(cs4>=i)
			bj+=a[tc4];
		if(bj<=x)
			break;
		ans-=(bj-x);
	}
	cout<<ans;
	return 0;
}
