#include<bits/stdc++.h>
#define lf double
using namespace std;
void init()
{
	 ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	 freopen("sequence.in","r",stdin);
	 freopen("sequence.out","w",stdout);
}
const int N = 3e5+5;
int n,k,a[N],s[N];
lf ans;
lf f(int x,int y)
{
	return (lf)x*1.0/(lf)y;
}
void solve(int l,int r,int s)
{
	double pj = f(s,r-l+1);
	ans = max(ans,pj);
	if(l>1&&a[l-1]*1.0>=pj)
		solve(l-1,r,s+a[l-1]);
	if(r<n&&a[r+1]*1.0>=pj)
		solve(l,r+1,s+a[r+1]);
}
int main()
{
	init();
	cin>>n>>k;
	for(int i = 1;i<=n;i++)
		cin>>a[i];
	for(int i = 1;i<=n;i++)
		s[i] = a[i]+s[i-1];
	for(int i = 1;i<=n-k+1;i++)
		solve(i,i+k-1,s[i+k-1]-s[i-1]);
	printf("%.6lf",ans);
	return 0;
}

