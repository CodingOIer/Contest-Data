#include<bits/stdc++.h>
#define int long long
using namespace std;
void init()
{
	 ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	 freopen("library.in","r",stdin);
	 freopen("library.out","w",stdout);
}
const int N = 1e3+5;
int n,m,tree[N],a[N][N],b[N][N],_a[N],_b[N],__a[N],__b[N],id[N],ans;
bool v1,v2 = 1;
int lowbit(int x)
{
	return x&(-x);
}
void add(int x)
{
	for(;x<=n;x+=lowbit(x))
		tree[x]++;
}
int get_sum(int x)
{
	int ret = 0;
	for(;x>0;x-=lowbit(x))
		ret+=tree[x];
	return ret;
}
bool cmp1(int x,int y)
{
	return _a[x]<_a[y];
}
bool cmp2(int x,int y)
{
	return _b[x]<_b[y];
}
signed main()
{
	init();
	cin>>n>>m;
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=m;j++)
		{
			cin>>a[i][j];
			if(a[i][j]==0)
				v1 = 1;
		}
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=m;j++)
		{
			cin>>b[i][j];
			if(a[i][j]!=b[i][j])
				v2 = 0;
		}
	if((v1||v2)==0)
		return cout<<-1,0;
	for(int l = 1;l<=n;l++)
	{
		int cnt = 0,cnt2 = 0;
		memset(tree,0,sizeof tree);
		for(int i = 1;i<=m;i++)
			if(a[l][i]!=0)
				_a[++cnt] = a[l][i];
		for(int i = 1;i<=m;i++)
			if(b[l][i]!=0)
				_b[++cnt2] = b[l][i];
		memset(id,0,sizeof id);
		for(int i = 1;i<=cnt;i++)
			__a[i] = __b[i] = i;
		sort(__a+1,__a+cnt+1,cmp2);
		sort(__b+1,__b+cnt+1,cmp1);
		for(int i = 1;i<=cnt;i++)
			id[__a[i]] = __b[i];
		for(int i = 1;i<=cnt;i++)
			ans+=get_sum(cnt)-get_sum(id[i]),add(id[i]);
	}
	cout<<ans;
	return 0;
}
