#include<bits/stdc++.h>
#define lf double
using namespace std;
void init()
{
	 ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	 freopen("sequence.in","r",stdin);
	 freopen("sequence.out","w",stdout);
}
const int N = 3e5+5;
int n,k,a[N],s[N];
lf ans;
lf f(int x,int y)
{
	return (lf)x*1.0/(lf)y;
}
int main()
{
//	init();
	cin>>n>>k;
	for(int i = 1;i<=n;i++)
		cin>>a[i];
	for(int i = 1;i<=n;i++)
		s[i] = a[i]+s[i-1];
	for(int l = 1;l<=n-k+1;l++)
		for(int r = l+k-1;r<=n;r++)
			ans = max(ans,f(s[r]-s[l-1],r-l+1));
	printf("%.6lf",ans);
	return 0;
}

