#include<bits/stdc++.h>
using namespace std;
void init()
{
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
}
const int N = 1e3;
int n,k,x,a[N+5],b[N+5],ton[N+5],in,ans,s;
int main()
{ 
	init();
	cin>>k;
	for(int i = 1;i<=k;i++)
		cin>>a[i];
	cin>>x>>b[1]>>b[2]>>b[3]>>b[4];
	cin>>n;
	for(int i = 1;i<=n;i++)
		cin>>in,ton[in]++;
	for(int i = 1;i<=4;i++)
		if(ton[b[i]])
			s+=a[b[i]];
	if(x<s)
	{
		ans = x;
		for(int i = 1;i<=4;i++)
			if(ton[b[i]])
				ton[b[i]]--;
	}
	for(int i = 1;i<=N;i++)
		ans+=ton[i]*a[i];
	cout<<ans;
	return 0;
}

