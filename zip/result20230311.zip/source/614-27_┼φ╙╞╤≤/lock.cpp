#include<bits/stdc++.h>
using namespace std;
void init()
{
	 ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	 freopen("lock.in","r",stdin);
	 freopen("lock.out","w",stdout);
}
const int N = 1e6+5;
int n,t,cnt = 1,ans,a[N],sum;
int jl(int x)
{
	if(x>=cnt) return x-cnt;
	else return n-cnt+x;
}
int main()
{
	init();
	cin>>n>>t;
	int x;
	for(int i = 1;i<=n;i++)
		cin>>x,a[x] = i;
	if(n<=t)
	{
		for(int i = 1;i<=n;i++)
			sum+=jl(a[i]),cnt = a[i];
		ans = t/n*sum;
		t%=n;
	}
	for(int i = 1;i<=t;i++)
		ans+=jl(a[i]),cnt = a[i];
	cout<<ans;
	return 0;
}

