#include<bits/stdc++.h>
using namespace std;
void init()
{
	 ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	 freopen("acm.in","r",stdin);
	 freopen("acm.out","w",stdout);
}
const int N = 1e5+5e4+5;
int n,a[3][N],ans = INT_MAX;
int main()
{
	init();
	cin>>n;
	for(int i =  0;i<3;i++)
		for(int j = 1;j<=n;j++)
			cin>>a[i][j],a[i][j]+=a[i][j-1];
	for(int i = 0;i<3;i++)
		for(int l = 2;l<n;l++)
			for(int r = l;r<n;r++)
				ans = min(ans,min(a[i][r]-a[i][l-1]+a[(i+1)%3][n]-a[(i+1)%3][r]+a[(i+2)%3][l-1],a[i][r]-a[i][l-1]+a[(i+2)%3][n]-a[(i+2)%3][r]+a[(i+1)%3][l-1]));
	cout<<ans;
	return 0;
}
