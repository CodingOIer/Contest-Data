#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int T,n;
int key[N],inde[N];
ll res[N],ans;
int  now=1;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%d",&n,&T);
	for(int i=1;i<=n;i++) scanf("%d",&key[i]),inde[key[i]]=i;
	for(int i=1;i<=n;i++){
		ans+=(inde[i]+n-now)%n;
		now=inde[i];
		if(i==T){
			printf("%lld\n",ans);
			exit(0);
		}
	}
	now=inde[n];
	for(int i=1;i<=n;i++){
		if(res[i]==now) continue;
		res[i]=res[i-1];
		res[i]+=(inde[i]+n-now)%n;
		now=inde[i];
	}
	ans+=(ll)(T/n-1)*res[n]+res[T%n];
	printf("%lld",ans);
	return 0;
}
