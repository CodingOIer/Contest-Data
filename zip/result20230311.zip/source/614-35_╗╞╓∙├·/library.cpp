#include <bits/stdc++.h>

using namespace std;
const int N=1e3+5; 
int n,m,res[N][N],a[N][N]; 
bool flag=0,op=0;
bool check(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)if(a[i][j]!=res[i][j]) return false;
	}return true;
}
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			if(a[i][j]==0) flag=1;
		}
	} 
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&res[i][j]);
			if(!flag) if(res[i][j]!=a[i][j]){op=1;break;}
		}
	} if(op){printf("-1\n");exit(0);}
	else if(op==0 && !flag || check()){printf("0");exit(0);}
	
	return 0;
}

