#include <bits/stdc++.h>

using namespace std;
const int N=3e5+5;
int n,k,a[N],sum[N];
double ans,now;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		now=0;
		for(int j=i+k-1;j<=n;j++){
			now=max(1.0*(sum[j]-sum[i-1])/(j-i+1),now);
		}ans=max(ans,now);
	}printf("%.6lf\n",ans);
	return 0;
}

