#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=25;
int a[N],vis[N],book[N],n,k[N],P[N],T,x,last[N],now,day[N];
bool flag=1;
ll ans_1,ans_2,ans=1e9;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	scanf("%d",&T);
	for(int i=1;i<=4;i++){
		scanf("%d",&x);
		vis[x]++;
	}
	scanf("%d",&now);
	for(int i=1;i<=now;i++){
		scanf("%d",&day[i]);
		book[day[i]]++;
	}
	for(int i=1;i<N;i++) last[i]=book[i];
	ans_1+=T;
	for(int i=1;i<=now;i++) ans_2+=a[day[i]];
	for(int i=1;i<=20;i++){
		ans_1=0;
		ans_1+=i*T;
		memset(k,0,sizeof(k));
		memset(P,0,sizeof(P));
		for(int j=1;j<=now;j++){
			if(vis[day[j]] && k[day[j]]<i){
				book[day[j]]-=i;
				k[day[j]]++;
				book[day[j]]=max(0,book[day[j]]);
			}
		}
		for(int j=1;j<=now;j++){
			if(!P[day[j]]){
				ans_1+=book[day[j]]*a[day[j]];
				P[day[j]]++;
			}
		}
		ans=min(ans_1,min(ans,ans_2)); 
		for(int j=1;j<N;j++) book[j]=last[j];
	}
	printf("%lld\n",ans);
	return 0;
}
