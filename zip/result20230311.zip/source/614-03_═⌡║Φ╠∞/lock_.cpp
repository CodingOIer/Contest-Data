#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,t;
int now,open,ans;
int key[N];
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock_.out","w",stdout);
	scanf("%d%d",&n,&t);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&key[i]);
	}
	now=1;
	for(;;)
	{
		for(int i=1;i<=n;i++)
		{
			for(;key[now]!=i;)
			{
				ans++;
				now++;
				if(now==n+1)
				{
					now=1;
				}
			}
			open++;
			if(open>=t)
			{
				break;
			}
		}
		if(open>=t)
		{
			break;
		}
		if(now==1)
		{
			ans+=t/open*ans;
			open=t-t%open;
		}
	}
	printf("%d\n",ans);
	return 0;
}

