#include<bits/stdc++.h>
using namespace std;
const int N=3*1e5+5;
int n,k;
int p[N];
int sum[N];
int all;
double ans;
double tmp;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i]);
		sum[i]=sum[i-1]+p[i];
	}
	for(int i=k;i<=n;i++)
	{
		tmp=sum[i]-sum[i-k];
		all=k;
		for(int j=i-k;j>=1;j--)
		{
			if(1.0*(sum[i]-sum[j-1])/(i-j+1)>=tmp/all)
			{
				all=i-j+1;
				tmp=sum[i]-sum[j-1];
			}
		}
		if(tmp/all>ans)
		{
			ans=tmp/all;
		}
	}
	printf("%.6lf",ans);
	return 0;
}

