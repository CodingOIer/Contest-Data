#include<bits/stdc++.h>
using namespace std;
const int K=25;
int k,x,w,tmp;
int p[K];
int want[K];
int f[K];
int ans1,ans2;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
	{
		scanf("%d",&p[i]);
	}
	scanf("%d",&x);
	for(int i=1;i<=4;i++)
	{
		scanf("%d",&tmp);
		f[tmp]++;
	}
	scanf("%d",&w);
	for(int i=1;i<=w;i++)
	{
		scanf("%d",&want[i]);
	}
	ans2=x;
	for(int i=1;i<=w;i++)
	{
		ans1+=p[want[i]];
		if(f[want[i]]>=1)
		{
			f[want[i]]--;
		}
		else
		{
			ans2+=p[want[i]];
		}
	}
	printf("%d\n",min(ans1,ans2));
	return 0;
}

