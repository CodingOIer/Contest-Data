/*
	���� 
*/
void MakeTree(int l,int r,int p,int tree[],int want[])
{
	if(l==r)
	{
		tree[p]=want[l];
		return;
	}
	int mid=l+(r-l)/2;
	MakeTree(l,mid,p*2,tree,want);
	MakeTree(mid+1,r,p*2+1,tree,want);
	tree[p]=tree[p*2]+tree[(p*2)+1];
	return;
}
/*
	��tree[l]-tree[r]�����ݼ���want 
*/
void GetAdd(int l,int r,int want,int s,int t,int p,int tree[],int flag[])
{
	if(l<=s&&t<=r)
	{
		tree[p]+=(t-s+1)*want;
		tree[p]+=want;
		return;
	}
	int m=s+(t-s)/2;
	if(flag[p]&&s!=t)
	{
		tree[p*2]+=flag[p]*(m-s+1),tree[p*2+1]+=flag[p]*(t-m);
		flag[p*2]+=flag[p];
		flag[p*2+1]+=flag[p];
		flag[p]=0;
	}
	if(l<=m)
	{
		GetAdd(l,r,want,s,m,p*2,tree,flag);
	}
	if(r>m)
	{
		GetAdd(l,r,want,m+1,t,p*2+1,tree,flag);
	}
	tree[p]=tree[p*2]+tree[p*2+1];
	return;
}
/*
	��tree[l]��tree[r]�ĺ� 
*/
int GetSum(int l,int r,int s,int t,int p,int tree[],int flag[])
{
	if(l<=s&&t<=r)
	{
		return tree[p];
	}
	int mid=s+(t-s)/2;
	if(flag[p]!=0)
	{
		tree[p*2]+=flag[p]*(mid-s+1);
		tree[p*2+1]+=flag[p]*(t-mid);
		flag[p*2]+=flag[p];
		flag[p*2+1]+=flag[p];
		flag[p]=0;
	}
	int sum=0;
	if (l<=mid)
	{
		sum=GetSum(l,r,s,mid,p*2,tree,flag);
	}
	if(r>mid)
	{
		sum+=GetSum(l,r,mid+1,t,p*2+1,tree,flag);
	}
	return sum;
}
/*
	��tree[l]-tree[r]��Ϊc 
*/
void GetNew(int l,int r,int want,int s,int t,int p,int tree[],int flag[],int tmp[])
{
	if(l<=s&&t<=r)
	{
		tree[p]=(t-s+1)*want;
		flag[p]=want;
		return;
	}
	int m=s+(t-s)/2;
	if(tmp[p]!=0)
	{
		tree[p*2]=flag[p]*(m-s+1);
		tree[p*2+1]=flag[p]*(t-m);
		flag[p*2]=flag[p*2+1]=flag[p];
		tmp[p*2]=tmp[p*2+1]=1;
		tmp[p] = 0;
	}
	if(l<=m)
	{
		GetNew(l,r,want,s,m,p*2,tree,flag,tmp);
	}
	if(r>m)
	{
		GetNew(l,r,want,m+1,t,p*2+1,tree,flag,tmp);
	}
	tree[p]=tree[p*2]+tree[p*2+1];
	return;
}
