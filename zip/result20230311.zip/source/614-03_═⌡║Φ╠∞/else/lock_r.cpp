#include<bits/stdc++.h>
using namespace std;
int n,t,x;
int f[100005];
int main()
{
	freopen("lock.in","w",stdout);
	srand(time(0));
	n=10;
	t=100;
	printf("%d %d\n",n,t);
	for(int i=1;i<=n;i++)
	{
		x=rand()%n+1;
		for(;f[x]==1;)
		{
			x=rand()%n+1;
		}
		f[x]=1;
		printf("%d\n",x);
	}
	return 0;
}

