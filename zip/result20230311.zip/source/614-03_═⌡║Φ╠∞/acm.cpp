#include<bits/stdc++.h>
using namespace std;
const int N=15*1e4+5;
int n;
int p1[N];
int sum1[N];
int p2[N];
int sum2[N];
int p3[N];
int sum3[N];
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p1[i]);
		sum1[i]=sum1[i-1]+p1[i];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p2[i]);
		sum2[i]=sum2[i-1]+p2[i];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p3[i]);
		sum3[i]=sum3[i-1]+p3[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=1;k<=n;k++)
			{
				int x,y,z;
				x=min(i,min(j,k));
				z=max(i,max(j,k));
				y=i+j+k-x-z;
			}
		}
	}
	return 0;
}

