#include<bits/stdc++.h>

using namespace std;
int a[1002],b[1002],d[1002];
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	int k,x,y,ans=0,ans1=0;
	bool l=0;
	cin>>k;
	for(int i=0;i<k;i++)
		cin>>a[i];
	cin>>x;
	for(int i=0;i<4;i++) 
		cin>>b[i];
	cin>>y;
	for(int i=0;i<y;i++) 
		cin>>d[i];
	for(int i=0;i<k;i++)
	{
		for(int j=0;j<4;j++)
		{
			if(b[j]==d[i])
			{
				l=1;
				b[j]=0;
				break;
			}
		}
		if(l==0)
			ans=ans+a[i];
		l=0;
	}
	ans+=x;
	for(int i=0;i<y;i++)
	{
		ans1=ans1+a[d[i]];
	}
	if(ans>ans1)
	{
		cout<<ans1;
		return 0;
	}
	cout<<ans;
	return 0; 
}
