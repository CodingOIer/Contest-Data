#include<bits/stdc++.h>
using namespace std;
int n,k,x,ans1,ans2;
int p[25];
bool a[25];
int w[25];
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) scanf("%d",&p[i]);
	cin>>x;
	for(int i=1; i<=4; i++){
		int xx;
		scanf("%d",&xx);
		a[xx]=1;
	}
	cin>>k;
	for(int i=1; i<=k; i++){
		int xx;
		scanf("%d",&xx);
		w[xx]++;
	}
	for(int i=1; i<=n; i++)
		ans1+=w[i]*p[i];
		
	ans2+=x;
	for(int i=1; i<=n; i++)
		if(a[i]) ans2+=max(0,(w[i]-1))*p[i];
		else ans2+=w[i]*p[i];
	cout<<min(ans1,ans2);
	return 0;
}
