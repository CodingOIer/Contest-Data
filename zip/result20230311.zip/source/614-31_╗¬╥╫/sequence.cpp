#include<bits/stdc++.h>
#define N 300005
using namespace std;
int n,k;
double ans=-1e9;
double a[N],t[N<<2],lazy[N<<2];
void pu(int k){ t[k]=t[k>>1]+t[k>>1|1]; }
void bu(int k,int l,int r)
{
	if(l==r) t[k]=a[l];
	else
	{
		int m=l+((r-l)>>1);
		bu(k>>1,l,m);
		bu(k>>1|1,m+1,r);
		pu(k);
	}
	return;
}
double qu(int k,int l,int r,int ll,int rr)
{
	if(ll<=l && r<=rr)
		return t[k];
	else
	{
		double res=0;
		int m=l+((r-l)/2);
		if(ll<=m) res+=qu(k>>1,l,m,ll,rr);
		if(rr>m) res+=qu(k>>1|1,m+1,r,ll,rr);
		return res;
	}
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) scanf("%lf",&a[i]);
	bu(1,1,n);
	for(int i=1;i<=n;i++)
		for(int j=i+k-1;j<=n;j++)
		{
			double t=qu(1,1,n,i,j);
			t/=(j-i+1);
			ans=max(ans,t);
		}
	printf("%.6lf",ans);
	return 0;
} 
