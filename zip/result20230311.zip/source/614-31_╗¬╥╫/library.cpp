#include<bits/stdc++.h>
using namespace std;
bool f;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			int x;
			cin>>x;
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			int x;
			cin>>x;
			if(!x) f=1;
		}
	}
	if(!f) cout<<-1;
	else cout<<0;
	return 0;
}
