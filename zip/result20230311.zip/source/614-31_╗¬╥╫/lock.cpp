#include<bits/stdc++.h>
using namespace std;
int n,t,ans,anss,xx,xxx;
int a[100005],id[100005];
int s[100005];
int main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	scanf("%d%d",&n,&t);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),id[a[i]]=i;
	for(int i=1;i<=n;i++)
	{
		ans+=id[a[i]]-1;
		xxx+=!bool(i-1)*(id[a[i]]-1);
		int x=id[a[i]]-1;
		s[i]=id[a[i]]-1;
		for(int j=1;j<=n;j++)
		{
			if(id[a[j]]<x) id[a[j]]+=n-id[a[i]];
			else id[a[j]]-=id[a[i]]-1;
		}
	}
	ans-=xxx;
	ans+=id[a[1]];
	s[1]=id[a[1]];
	int x=t%n;
	for(int i=1;i<=x;i++) anss+=s[i];
	cout<<ans-id[a[1]]+xxx+ans*max(0,(t/n-1))+anss;
	return 0;
}
/*
10 7
1 3 2 4 5 7 6 8 9 10

*/
