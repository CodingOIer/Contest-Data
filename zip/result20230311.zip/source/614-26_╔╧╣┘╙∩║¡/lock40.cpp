#include<bits/stdc++.h>
using namespace std;

queue<int>q;

const int N = 1e5 + 10;
int a[N];
int main() {
	int n, t, x, cnt = 0;
	cin >> n >> t;
	for(int i = 1; i <= n; i++) {
		cin >> x;
		a[x] = i;
		q.push(i);
	}
	int k = 1;
	for(int i = 1; i <= t; i++) {
		int p = q.front();
		while(a[k] != p) {
			++cnt;
			q.pop();
			q.push(p);
			p = q.front();
		}
		
		k++;
		if(k > n) k %= n;
	}
	cout << cnt;
} 
