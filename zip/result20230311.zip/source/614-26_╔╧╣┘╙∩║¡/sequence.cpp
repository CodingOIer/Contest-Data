#include<bits/stdc++.h>
using namespace std;

const int N = 3 * 1e5 + 10;

int a[N];
long long b[N];
int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	int n, k;
	double ans;
	cin >> n >> k;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
		b[i] = b[i - 1] + a[i];
	}
	int l = 1, r = n;
	while((r - l + 1) >= k) {
		long long sum = b[r] - b[l - 1];
		ans = max(ans, sum / ((r - l + 1) * 1.00));
		if(a[l] < a[r]) l++;
		else r--;
	}
	cout << fixed << setprecision(8) << ans;
} 
