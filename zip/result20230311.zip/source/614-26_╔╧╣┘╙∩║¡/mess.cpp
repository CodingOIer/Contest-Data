#include<bits/stdc++.h>
using namespace std;

int a[25], vis[25], c[5], b[25];
int main() {
	freopen("mess.in", "r", stdin);
	freopen("mess.out", "w", stdout);
	int n, x, t;
	cin >> n;
	for(int i = 1; i <= n; i++) cin >> a[i];
	cin >> x;
	for(int i = 1; i <= 4; i++) cin >> c[i];
	cin >> t;
	for(int i = 1; i <= t; i++) cin >> b[i];
	long long pre = INT_MAX, sum, sum2;
	for(int k = 1; ; k++) {
		sum = 0, sum2 = 0;
		memset(vis, 0, sizeof(vis)); 
		for(int i = 1; i <= 4; i++) vis[c[i]] += k; 
		for(int i = 1; i <= t; i++) {
			sum += a[b[i]];
			if(vis[b[i]]) vis[b[i]]--;
			else sum2 += a[b[i]];
		}
		if(sum2 + k * x > pre) break;
		pre = sum2 + k * x;
	}
	cout << min(pre, sum);
}
