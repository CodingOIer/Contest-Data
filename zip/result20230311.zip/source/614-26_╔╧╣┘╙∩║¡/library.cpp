#include<bits/stdc++.h>
using namespace std;

const int N = 1e3 + 10;
int now[N][N], old[N][N], cnt[N], vis[N * N];
int main() {
	freopen("library.in", "r", stdin);
	freopen("library.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			cin >> now[i][j];
			if(now[i][j] == 0) cnt[i]++;
		}
	}
		
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			cin >> old[i][j];
	
	cout << -1; 
} 
