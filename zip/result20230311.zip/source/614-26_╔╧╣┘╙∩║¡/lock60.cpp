#include<bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int a[N];
int main() {
	int n, t, x, cnt = 0;
	cin >> n >> t;
	for(int i = 1; i <= n; i++) {
		cin >> x;
		a[x] = i;
	}
	int k = 1;
	int p = 1;
	for(int i = 1; i <= t; i++) {
		if(a[k] > p) cnt += a[k] - p;
		else if(a[k] < p) cnt += n - p + a[k];
		p = a[k];
		k++;
		if(k > n) k %= n;
	}
	cout << cnt;
} 
