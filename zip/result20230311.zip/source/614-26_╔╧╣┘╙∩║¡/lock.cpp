#include<bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int a[N];
int main() {
	freopen("lock.in", "r", stdin);
	freopen("lock.out", "w", stdout);
	long long n, t, x, cnt1 = 0, cnt = 0, cntl = 0;
	cin >> n >> t;
	for(int i = 1; i <= n; i++) {
		cin >> x;
		a[x] = i;
	}
	int k = 1;
	int p = 1;
	for(int i = 1; i <= min(n, t); i++) {
		if(a[k] > p) cnt1 += a[k] - p;
		else if(a[k] < p) cnt1 += n - p + a[k];
		p = a[k];
		k++;
		if(k > n) k %= n;
	}
	if(t < n) {
		cout << cnt1;
		return 0;
	}
	for(int i = 1; i <= min(n, t - n); i++) {
		if(a[k] > p) cnt += a[k] - p;
		else if(a[k] < p) cnt += n - p + a[k];
		p = a[k];
		k++;
		if(k > n) k %= n;
	}
	if(t <= 2 * n) {
		cout << cnt + cnt1;
		return 0;
	}
	int zq = (t - n) / n;
	for(int i = 1; i <= (t - n) % n; i++) {
		if(a[k] > p) cntl += a[k] - p;
		else if(a[k] < p) cntl += n - p + a[k];
		p = a[k];
		k++;
		if(k > n) k %= n;
	}
	cout << cnt1 + cnt * zq + cntl;
} 
