#include<bits/stdc++.h>
using namespace std;

const int N = 150000 + 10;
long long sum1[N], sum2[N], sum3[N];
int main() {
	freopen("acm.in", "r", stdin);
	freopen("acm.out", "w", stdout);
	int n, x;
	cin >> n;
	for(int i = 1; i <= n; i++) {cin >> x;sum1[i] = sum1[i - 1] + x;}
	for(int i = 1; i <= n; i++) {cin >> x;sum2[i] = sum2[i - 1] + x;}
	for(int i = 1; i <= n; i++) {cin >> x;sum3[i] = sum3[i - 1] + x;}
	
	long long ans = INT_MAX;
	for(int i = 1; i < n - 1; i++) {
		for(int j = i + 1; j < n; j++) {
			long long a = sum1[i];
			long long b = sum2[j] - sum2[i];
			long long c = sum3[n] - sum3[j];
			ans = min(ans, a + b + c);
			a = sum2[i];
			b = sum1[j] - sum1[i];
			c = sum3[n] - sum3[j];
			ans = min(ans, a + b + c);
			a = sum2[i];
			b = sum3[j] - sum3[i];
			c = sum1[n] - sum1[j];
			ans = min(ans, a + b + c);
			a = sum1[i];
			b = sum3[j] - sum3[i];
			c = sum2[n] - sum2[j];
			ans = min(ans, a + b + c);
			a = sum3[i];
			b = sum2[j] - sum2[i];
			c = sum1[n] - sum1[j];
			ans = min(ans, a + b + c);
			a = sum3[i];
			b = sum1[j] - sum1[i];
			c = sum2[n] - sum2[j];
			ans = min(ans, a + b + c);
		}
	}
	cout << ans;
} 
