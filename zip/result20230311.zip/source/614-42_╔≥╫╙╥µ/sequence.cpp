#include<bits/stdc++.h>
using namespace std;
int n,k,a[300005],h;
long double m;
int main(){
freopen("sequence.in","r",stdin);
freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(;;)
	{
		if(k>n)
			break;
		for(int i=1;i<=n-k+1;i++)
		{
			h=0;
			for(int j=i;j<=i+k-1;j++)
				h+=a[j];
			m=max(m,(long double)h*1.0/k);
			
		}
		k++;
	}
	cout<<setprecision(20)<<m;
	return 0;
}

