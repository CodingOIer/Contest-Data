#include<bits/stdc++.h>
using namespace std;

int main(){
freopen("acm.in","r",stdin);
freopen("acm.out","w",stdout);
	int n;
cin>>n;
cout<<n;	
	return 0;
}

