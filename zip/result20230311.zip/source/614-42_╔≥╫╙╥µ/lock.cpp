#include<bits/stdc++.h>
using namespace std;
int n,t,a[100001],ans=1,num=1,tu;
long long f;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(;;)
	{
		if(t==tu)
			break;
		for(;;)
		{
			if(a[ans]==num)
			{
				num++;
				tu++;
				break;
			}
			else
			{
				ans++;
				f++;
				if(ans>n)
					ans=1;
			}
		}
		if(num>n)
			num=1;
	}
	cout<<f;
	return 0;
}
/*
10 7
1
3
2
4
5
7
6
8
9
10
*/
