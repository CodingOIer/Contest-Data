#include<bits/stdc++.h>
using namespace std;
int k,a[25],x,_[5],t,b[25],m,m2,tt[5],o; 
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	//��Ҫ��goto
	goto __;
	___:
	goto ____;
	_____:
	cin>>k;
	for(int i=1;i<=k;i++)
		cin>>a[i];
	cin>>x;
	for(int i=1;i<=4;i++)
		cin>>_[i];
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>b[i];
		m+=a[b[i]];
		for(int j=1;j<=4;j++)
		{
			if(b[i]==_[j])
				tt[j]+=1;
		}	
	}
	m2=m;
	for(;;)
	{
		for(int i=1;i<=4;i++)
			if(tt[i]>=1)
			{
				m2-=a[_[i]];
				tt[i]--;
			}
		m2+=x;
		if(m<m2)
		{
			m2=m;
			break;
		}
		m=m2;
		o=0;
		for(int i=1;i<=4;i++)
		{
			if(tt[i]>=1)
				o=1;
		}
		if(o==0)
			break;
	}
	cout<<min(m2,m);
	return 0;
	____:
	goto _____;
	__:
	goto ___;
}
