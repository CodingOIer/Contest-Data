#include<bits/stdc++.h>
using namespace std;
int k,a[114],x,t,b[114],tc[114],ans,tc1,tc2,tc3,tc4;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
		cin>>a[i];
	cin>>x;
	for(int i=1;i<=4;i++)
		cin>>tc[i];
	cin>>t;
	for(int i=1;i<=t;i++)
		cin>>b[i];
	for(int i=1;i<=t;i++)
	{
		if(b[i]==tc[1])
			tc1++;
		else if(b[i]==tc[2])
			tc2++;
		else if(b[i]==tc[3])
			tc3++;
		else if(b[i]==tc[4])
			tc4++;
	}
	int sum=0;
//	cout<<tc1<<" "<<tc2<<" "<<tc3<<" "<<tc4;
	while(tc1>0||tc2>0||tc3>0||tc4>0)
	{
		int sum1=0;
		if(tc1>0)
			sum1+=a[tc[1]];
		if(tc2>0)
			sum1+=a[tc[2]];
		if(tc3>0)
			sum1+=a[tc[3]];
		if(tc4>0)
			sum1+=a[tc[4]];
		
		if(sum1<x)
			ans+=sum1;
		else
			sum++;
		tc1--,tc2--,tc3--,tc4--;
	}
	ans+=sum*x;
	a[tc[1]]=a[tc[2]]=a[tc[3]]=a[tc[4]]=0;
	for(int i=1;i<=k;i++)
		ans+=a[b[i]];
	cout<<ans;
	return 0;
}
