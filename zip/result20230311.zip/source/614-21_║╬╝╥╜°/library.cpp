#include<bits/stdc++.h>
using namespace std;
struct Fa_Q
{
	int l,r,val;
}a[1000000*4+1];
int n,m,ans,id[1000001],A[1000001],B[1000001],k;
void bld(int l,int r,int root)
{
	a[root].l=l;
	a[root].r=r;
	a[root].val=0;
	if(l==r)
		return;
	int mid=(l+r)/2;
	bld(l,mid,root*2);
	bld(mid+1,r,root*2+1);
}
void sum(int x,int y,int root)
{
	if(x<=a[root].l&&a[root].r<=y)
	{
		k+=a[root].val;
		return;
	}
	int mid=(a[root].l+a[root].r)/2;
	if(x<=mid)
		sum(x,y,root*2);
	if(y>mid)
		sum(x,y,root*2+1);
}
void add(int x,int root)
{
	if(a[root].l==a[root].r)
	{
		a[root].val++;
		return;
	} 
	int mid=(a[root].l+a[root].r)/2;
	if(x<=mid)
		add(x,root*2);
	else
		add(x,root*2+1);
	a[root].val=a[root*2].val+a[root*2+1].val;
}
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int cnt=0;
	cin>>n>>m;
	int b=1;
	for(int i=1;i<=n*m;i++)
	{
		int x;
		cin>>x;
		if(x)
			A[++cnt]=x,b=0;
	}
	int cnt1=0;
	for(int i=1;i<=n*m;i++)
	{
		int x;
		cin>>x;
		if(x)
			B[++cnt1]=x,b=0;
	}
	for(int i=1;i<=cnt;i++)
		id[A[i]]=B[i];
	bld(1,cnt,1);
	for(int i=1;i<=cnt;i++)
	{
		
		k=0;
		sum(id[i]+1,cnt,1);
		ans+=k;
		add(id[i],1);
	}
//	for(int i=1;i<=cnt;i++)
//		cout<<id[i]<<" ";
	if(b)
		cout<<-1;
	else 
		cout<<ans;
	return 0;
}
