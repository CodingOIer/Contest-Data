#include<bits/stdc++.h>
using namespace std;
struct node
{
	int l,r;
	long long val;
}a[114514*3*4];
int n,k;
double ans,x1;
void bld(int l,int r,int root)
{
	a[root].l=l;
	a[root].r=r;
	if(l==r)
	{
		cin>>a[root].val;
		return;
	}
	int mid=(l+r)/2;
	bld(l,mid,root*2);
	bld(mid+1,r,root*2+1);
	a[root].val=a[root*2].val+a[root*2+1].val;
}
void sum(int x,int y,int root)
{
	if(x<=a[root].l&&a[root].r<=y)
	{
		x1+=a[root].val;
		return;
	}
	int mid=(a[root].l+a[root].r)/2;
	if(x<=mid)
		sum(x,y,root*2);
	if(y>mid)
		sum(x,y,root*2+1);
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	bld(1,n,1);
	for(int i=k;i<=n;i++)
	{
		for(int j=1;j<=n-i+1;j++)
		{
			x1=0;
			sum(j,j+i-1,1);
//			cout<<j<<" "<<j+i-1<<" "<<x1<<" "<<i<<endl;
			ans=max(ans,x1/i);
		}
	}
//	for(int i=1;i<=7;i++)
//		cout<<a[i].l<<" "<<a[i].r<<" "<<a[i].val<<endl;
	printf("%.6f",ans);
	return 0;
}

