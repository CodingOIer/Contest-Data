#include<bits/stdc++.h>
using namespace std;
const int maxn=300010;
int n,k,a[maxn],stk[maxn],tp;
long long s[maxn];
double ans;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]),s[i]=s[i-1]+a[i];
	ans=(double)s[k]/k;
	int mid=1;
	for(int i=1;i<=n-k;i++){
		while(tp&&(s[i]-s[stk[tp]])*(stk[tp]-stk[tp-1])<(s[stk[tp]]-s[stk[tp-1]])*(i-stk[tp]))--tp;
		stk[++tp]=i;
		while(stk[mid+1]+k>i&&mid>1) mid--;		
		while(stk[mid+1]+k<=i) mid++;
		if(stk[mid]+k<=i)ans=max(ans,(double)(s[i]-s[stk[mid]])/(i-stk[mid]));
	
	}
	printf("%.6lf\n",ans);
	return 0;
}
