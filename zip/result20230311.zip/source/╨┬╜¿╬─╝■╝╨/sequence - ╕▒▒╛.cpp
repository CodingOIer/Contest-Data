#include<bits/stdc++.h>
////#define rg register
//#define il inline
//#define cn const
//#define fp(i,a,b) for(rg int i=(a),ed=(b);i<=ed;++i)
//#define fb(i,a,b) for(rg int i=(a),ed=(b);i>=ed;--i)
using namespace std;
//typedef cn int cint;
const int maxn=300010;
int n,k,a[maxn],stk[maxn],tp;
long long s[maxn];
double ans;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]),s[i]=s[i-1]+a[i];
	ans=(double)s[k]/k;
	for(int i=1;i<=n-k;i++){
		while(tp&&(s[i]-s[stk[tp]])*(stk[tp]-stk[tp-1])<(s[stk[tp]]-s[stk[tp-1]])*(i-stk[tp]))--tp;
		stk[++tp]=i;
		int lt=1,rt=tp,mid,res=0;
		while(lt<=rt){
			mid=lt+rt>>1;
			if((s[i+k]-s[stk[mid]])*(stk[mid]-stk[mid-1])>=(s[stk[mid]]-s[stk[mid-1]])*(i+k-stk[mid]))res=mid,lt=mid+1;
			else rt=mid-1;
		}
		ans=max(ans,(double)(s[i+k]-s[stk[res]])/(i+k-stk[res]));
	}
	printf("%.6lf\n",ans);
	return 0;
}
