#include <bits/stdc++.h>
using namespace std;
const int N=1021;
int a[N][N],b[N][N],c[N*N],d[N][N],nn[N*N];
int n,m,k;
int kong[N],f[N],ne[N],fall;
int ca[N];
int ANS=0;
void go(int x){
    if (ca[x]) return;
    if (kong[x]>0) {ca[x]=1; return;}
    ca[x]=2;
    int hb=0;
    for (int i=1;i<=n;i++)
    if (x!=i)
    if (d[x][i]) {
        hb=1;
        if (ca[i]==0) go(i);
        if (ca[i]==1) {ca[x]=1; return;}
    }
    if (ca[x]==2)
        if (hb || ne[x]) {
            ANS++;
            ca[x]=1;
        }
}
int main(){
	freopen("library.in","r",stdin);
    freopen("library.out","w",stdout);
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++)
       for (int j=1;j<=m;j++)
          scanf("%d",&a[i][j]);
    for (int i=1;i<=n;i++)
       for (int j=1;j<=m;j++)
          scanf("%d",&b[i][j]),c[b[i][j]]=i,nn[b[i][j]]=j;
    for (int i=1;i<=n;i++){
       for (int j=1;j<=m;j++){
          kong[i]+=(a[i][j]==0);
          if (a[i][j]) d[i][c[a[i][j]]]++;
        }
    fall+=kong[i];
    }
    int aa,bb,cc;
    for (int i=1;i<=n;i++){
        for (int j=0;j<=m;j++) f[j]=0;
        aa=bb=0;
        for (int j=1;j<=m;j++)
            if (c[a[i][j]]==i && a[i][j])
            {
                aa++;
                cc=0;
                for (int k=nn[a[i][j]];k>0;k&=k-1) cc=max(cc,f[k]+1);
                for (int k=nn[a[i][j]];k<=m;k=(k<<1)-(k&(k-1))) f[k]=max(f[k],cc);
                bb=max(bb,cc);
            }
        ne[i]=aa-bb;
    }
    for (int i=1;i<=n;i++){
        d[i][i]=0;
        ANS+=ne[i];
        for (int j=1;j<=n;j++) ANS+=d[i][j];
    }
    if (fall==0 && ANS>0) {cout<<-1<<endl; return 0;}
    for (int i=1;i<=n;i++)
        if (ca[i]==0) go(i);
    cout<<ANS<<endl;
    return 0;
}
