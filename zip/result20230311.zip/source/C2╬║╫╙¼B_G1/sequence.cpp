#include<bits/stdc++.h>
using namespace std;
int n,k;
float sum,c,f;
int h[100001];
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>h[i];
	for(int i=k;i<=n;i++)
	{
		for(int j=1;j+i-1<=n;j++)
		{
			sum=0;
			for(int z=j;z<=j+i-1;z++)sum+=h[z];
			c=sum/i;
			f=max(f,c);
		}
	}
	cout<<f;
	return 0;
}
