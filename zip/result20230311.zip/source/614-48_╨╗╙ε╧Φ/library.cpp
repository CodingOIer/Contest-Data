#include<bits/stdc++.h>
using namespace std;
int n,m,a[1005][1005],b[1005][1005];
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&b[i][j]);
	cout<<-1;
	return 0;
}
