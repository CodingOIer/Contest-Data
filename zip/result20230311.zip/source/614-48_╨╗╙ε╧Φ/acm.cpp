#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("acm.in","r",stdin);
	//freopen("acm.out","w",stdout);

	return 0;
}
