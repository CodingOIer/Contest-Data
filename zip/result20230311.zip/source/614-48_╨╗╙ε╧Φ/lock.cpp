#include<bits/stdc++.h>
using namespace std;
const int N=1e5;
int n,k,l=0,sum=0,ans=0,a[N+5],s[N+5];
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		s[a[i]]=i;
	s[0]=1;
	int i=1;
	while(sum<k)
	{
		if(s[i]<s[l]) ans+=n-s[l]+s[i];
		else ans+=s[i]-s[l];
		sum++;
		l=i;
		i++;
		if(i>n) i=1;
	}
	printf("%d",ans);
	return 0;
}
