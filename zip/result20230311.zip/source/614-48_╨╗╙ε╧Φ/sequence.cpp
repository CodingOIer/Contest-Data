#include<bits/stdc++.h>
using namespace std;
const int N=1e5;
int n,k,lt,rt,a[3*N+5];
double ans=0.0;
struct noot
{
	int l,r,sum;
}t[N<<2];
void son(int i)
{
	t[i].sum=t[i<<1].sum+t[(i<<1)|1].sum;
}
void sth(int i,int l,int r)
{
	t[i].l=l;t[i].r=r;
	if(l==r)
	{
		t[i].sum=a[l];
		return;
	}
	int mid=(l+r)/2;
	sth(i<<1,l,mid);
	sth((i<<1)|1,mid+1,r);
	son(i);
}
int cg(int i,int l,int r)
{
	if(t[i].l==l&&t[i].r==r) return t[i].sum;
	int mid=(t[i].l+t[i].r)/2;
	if(r<=mid) return cg(i<<1,l,r);
	else if(l>mid) return cg((i<<1)|1,l,r);
	else return cg(i<<1,l,mid)+cg((i<<1)|1,mid+1,r);
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	sth(1,1,n);
	for(int l=1;l+k-1<=n;l++)
		for(int r=l+k-1;r<=n;r++)
			ans=max(ans,((double)cg(1,l,r)/(double)(r-l+1)));
	printf("%lf",ans);
	return 0;
}
