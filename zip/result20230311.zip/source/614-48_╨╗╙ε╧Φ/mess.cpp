#include<bits/stdc++.h>
using namespace std;
int n,k,t,Mx,sum=INT_MAX,a[25],b[25],c[25],p[25],r[25];
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	scanf("%d",&k);
	for(int i=1;i<=4;i++)
	{
		scanf("%d",&b[0]);
		b[b[0]]=1;
	}
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&p[i]);
		c[p[i]]++;
	}
	Mx=max(max(c[b[1]],c[b[2]]),max(c[b[3]],c[b[4]]));
	for(int i=0;i<=Mx;i++)
	{
		int s=i*k;
		for(int j=1;j<=4;j++)
			r[j]=b[j];
		for(int j=1;j<=t;j++)
		{
			if(r[p[j]]==1&&c[p[j]]>=i) s+=a[p[j]]*(c[p[j]]-i),r[p[j]]=-1;
			else if(r[p[j]]==0) s+=a[p[j]];
		}
		sum=min(sum,s);
	}
	printf("%d",sum);
	return 0;
}
/*
6
12 5 7 8 9 3
14
4 3 1 2
5
1 2 1 6 6
*/
