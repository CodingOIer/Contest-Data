#include<bits/stdc++.h>
#define Mx 55
using namespace std;
void init(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
}
int n,a[Mx],mx;
int pd[Mx];
int s[Mx],x,t;
int ans;
int main(){
	init();
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	scanf("%d",&x);
	for(int i=0;i<4;i++){
		int y;
		scanf("%d",&y);
		pd[i]=y;
	}
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		int y;
		scanf("%d",&y);
		s[y]++;
	}
	int op=0;
	for(int i=1;i<=n;i++)
		ans+=a[i]*s[i];
	mx=ans;
	ans=x;
	for(int i=0;i<4;i++)s[pd[i]]--;
	for(int i=1;i<=n;i++){
		if(s[i]>0)ans+=s[i]*a[i];
	}
	printf("%d",min(mx,ans));
	return 0;
}

