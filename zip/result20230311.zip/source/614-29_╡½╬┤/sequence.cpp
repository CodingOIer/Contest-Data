#include<bits/stdc++.h>
#define Mx 300005
#define d double
#define ll long long
using namespace std;
void init(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
ll n,k;
ll a[Mx];
ll f[Mx];
ll s[Mx];
d ans;
ll h[Mx];
int main(){
	init();
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]),h[i]=h[i-1]+a[i];
	f[k]=h[k];
	s[k]=k;
	ans=max(ans,(d)f[k]/s[k]);
	for(int i=k+1;i<=n;i++){
		f[i]=f[i-1]+a[i];
		s[i]=s[i-1]+1;
		if(f[i]*k<(h[i]-h[i-k])*s[i]){
			s[i]=k;
			f[i]=h[i]-h[i-k];
		}
		ans=max(ans,(d)f[i]/s[i]);
	}
	printf("%.6lf",ans);
	return 0;
}

