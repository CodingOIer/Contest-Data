#include<bits/stdc++.h>
#define Mx 100005
#define ll long long
using namespace std;
void init(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
}
ll n,k;
ll a[Mx];
ll ans;
ll x;
ll h=0;
ll dt(ll x,ll y){
	h=0;
	while(x!=a[y]){
		++y;
		h++;
		y=(y-1)%n+1;
	}
	return y;
}
int main(){
	init();
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	ll bs=0,x=1;
	ll len=0;
	ll xx=1;
	while(1){
		if(len>=k){
			printf("%lld",bs);
			return 0;
		}
		len++;
		x=dt(xx,x);
		bs+=h;
		xx=xx%n+1;
		if(len==n)break;
	}
	ans=k/len*bs;
	k%=len;
	for(int i=0;i<k;i++){
		x=dt(xx++,x);
		xx=(xx-1)%n+1;
		ans+=h;
	}
	printf("%lld",ans);
	return 0;
}

