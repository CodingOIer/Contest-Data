#include<bits/stdc++.h>
#define Mx 1005
using namespace std;
void init(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
}
int n,m;
int ans;
int a[Mx][Mx];
int s[Mx][Mx];
int x[Mx*Mx],y[Mx*Mx];
int op;
int f[Mx];
int xxx;
void add(int x,int d){
	while(x<=xxx){
		f[x]+=d;
		x+=x&-x;
	}
}
int anser(int x){
	int ans=0;
	while(x){
		ans+=f[x];
		x-=x&-x;
	}
	return ans;
}
int main(){
	init();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)op=1;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&s[i][j]);
			x[s[i][j]]=i;
			y[s[i][j]]=j;
		}
	}
	if(!op){
		printf("-1");
		return 0;
	}
	xxx=m;
	for(int i=1;i<=n;i++){
		memset(f,0,sizeof(f));
		for(int j=1;j<=m;j++){
			if(a[i][j]){
				add(y[a[i][j]],1);
				ans+=anser(m)-anser(y[a[i][j]]);
			}
		}
	}
	xxx=n;
	for(int j=1;j<=m;j++){
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++){
			if(a[i][j]){
				add(x[a[i][j]],1);
				ans+=abs(anser(i)-anser(x[a[i][j]]));
			}
		}
	}
	printf("%d",ans);
	return 0;
}

