#include<bits/stdc++.h>
using namespace std;
int a[25],t[5],b[25],ans=0,vis[25],vis1[25],mx=0;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	int n1,n2,x;
	cin>>n1;
	for(int i=1;i<=n1;i++){
		cin>>a[i];
	}
	cin>>x;
	for(int i=1;i<=4;i++) cin>>t[i];
	cin>>n2;
	for(int i=1;i<=n2;i++){
		cin>>b[i];
		vis[b[i]]++;
		mx=max(mx,b[i]);
	}
	for(int i=0;i<=20;i++){
		int s=i*x;
		for(int j=1;j<=mx;j++) vis1[j]=vis[j];
		for(int j=1;j<=i;j++){
			for(int k=1;k<=4;k++){
				vis1[t[k]]--;
			}
		}
		for(int j=1;j<=mx;j++){
			if(vis1[j]>0) s+=a[j]*vis1[j];
		}
		if(i==0) ans=s;
		else ans=min(s,ans);
	}
	cout<<ans;
	return 0;
}
