#include<bits/stdc++.h>
using namespace std;
int a[100005],hx[100005],s,ans;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	int n,t;
	cin>>n>>t;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		hx[a[i]]=i;
	} 
	if(t<=n){
		for(int i=1;i<t;i++){
			if(hx[a[i]+1]<hx[a[i]]){
				s=s+n-hx[a[i]]+hx[a[i]+1];
			} 
			else{
				s=s+hx[a[i]+1]-hx[a[i]];
			} 
		}
		cout<<s+a[t-1];
		return 0;
	}
	for(int i=1;i<n;i++){
		if(hx[a[i]+1]<hx[a[i]]) s+=n-hx[a[i]]+hx[a[i]+1];
		else s+=hx[a[i]+1]-hx[a[i]];
	}
	s+=a[n-1];
	ans+=s;
	ans+=(t-n)/n*s;
	for(int i=2;i<=t%n;i++){
		if(hx[a[i]+1]<hx[a[i]]) ans+=n-hx[a[i]]+hx[a[i]+1];
		else ans+=hx[a[i]+1]-hx[a[i]];
	}
	cout<<ans-1;
	return 0;
}
/*
10 7
1 3 2 4 5 7 6 8 9 10
*/
