#include<bits/stdc++.h>
using namespace std;
int a[300005];
double ans,sum[300005];
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=k;j<=n;j++) ans=max(ans,(sum[i]-sum[i-j])/j*1.0000);
	} 
	printf("%.6f",1.0*ans);
	return 0;
}

