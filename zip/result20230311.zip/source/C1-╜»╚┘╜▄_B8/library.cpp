#include <bits/stdc++.h>
using namespace std;
int n,m,a[1005][1005],b[1005][1005],sum1,sum2,sum3,sum4,x[2][1000005],y[2][1000005],ans;
bool comp(int a, int b){
	return a>b&&b==0;
}
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; i++){
		for(int j=1; j<=m; j++){
			cin>>a[i][j];
			if(a[i][j]==0)
				sum1++;
			sum2+=a[i][j];
			x[0][a[i][j]]=i;
			y[0][a[i][j]]=j;
		}
		sort(a[i]+1, a[i]+1+m, comp);
		for(int j=1; j<=m; j++)
			x[0][a[i][j]]=i,y[0][a[i][j]]=j;
	}
	for(int i=1; i<=n; i++){
		for(int j=1; j<=m; j++){
			cin>>b[i][j];
			if(b[i][j]==0)
				sum3++;
			sum4+=b[i][j];
			x[1][b[i][j]]=i;
			y[1][b[i][j]]=j;
		}
		sort(b[i]+1, b[i]+1+m, comp);
		for(int j=1; j<=m; j++)
			x[1][b[i][j]]=i,y[1][b[i][j]]=j;
	}
	if(sum1==0 || sum3==0 || sum1!=sum3|| sum2!=sum4){
		cout<<-1;
		return 0;
	}
	for(int i=1; i<=n*m; i++)
		if(x[0][i] != x[1][i])
			ans+=1;
		else
			if(y[0][i] != y[1][i])
				ans+=2;
	cout<<ans;
	return 0;
}
