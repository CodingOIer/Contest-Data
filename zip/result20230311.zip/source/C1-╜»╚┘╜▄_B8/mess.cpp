#include <bits/stdc++.h>
using namespace std;
int k,a[25],x,b,t,c,ans,d[25],sum,e[25],f[25],maxn,um,minn;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1; i<=k; i++)
		cin>>a[i];
	cin>>x;
	for(int i=1; i<=4; i++)
		cin>>b, d[b]++;
	cin>>t;
	for(int i=1; i<=t; i++){
		cin>>c;
		if(d[c])
			sum+=a[c], e[c]++;
		else
			ans+=a[c];
	}
	for(int i=1; i<=k; i++)
		maxn=max(maxn,e[i]);
	minn=sum;
	for(int i=maxn; i>=1; i--){
		for(int j=1; j<=k; j++)
			if(e[j] >= 1)
				um+=a[j]*e[j]*(d[j] > e[j])+a[j]*d[j]*(d[j] <= e[j]), e[j]-=d[j];
		minn=min(minn,(maxn - i+1)*x + sum - um);
	}
	cout<<ans+minn;
	return 0;
}
