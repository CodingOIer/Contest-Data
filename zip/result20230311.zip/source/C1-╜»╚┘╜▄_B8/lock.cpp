#include <bits/stdc++.h>
using namespace std;
int n,t,sum,a[100005],b[100005],lj[100005];
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1; i<=n; i++)
		cin>>a[i],b[a[i]]=i;
	for(int i=1; i<=n; i++){
		int j=i+1;
		if(j>n)
			j-=n;
		if(b[i] > b[j])
			lj[i]=n-b[i]+b[j];
		else
			lj[i]=b[j]-b[i];
	}
	sum+=b[1];
	for(int i=1; i<n; i++)
		sum+=lj[i];
	if(n < t){
		sum+=(sum+lj[n])*(t/n -1);
		for(int i=n; i<=n+t%n-1; i++)
			sum+=lj[(i-1)%n+1];
		cout<<sum-1;
	}
	else{
		for(int i=t; i<n; i++)
			sum-=lj[i];
		cout<<sum-1;
	}
	return 0;
}
