#include <bits/stdc++.h>
using namespace std;
int n,a[4][150005],f[4][150005],ans=7500000;
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=0; i<=2; i++)
		for(int j=1; j<=n; j++)
			cin>>a[i][j],f[i][j]=f[i][j-1]+a[i][j];
	for(int i=1; i<=n-2; i++)
		for(int j=i+1; j<=n-1; j++)
			for(int o1=0; o1<=2; o1++){
				int o2=(o1+1)%3, o3=(o1+2)%3; 
				ans=min(ans,min(f[o1][i]+f[o2][j]-f[o2][i]+f[o3][n]-f[o3][j],f[o1][i]+f[o3][j]-f[o3][i]+f[o2][n]-f[o2][j]));
			}
	cout<<ans;
	return 0;
}
