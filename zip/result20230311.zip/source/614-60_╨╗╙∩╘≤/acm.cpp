#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("acm.in","w",stdin);
	freopen("acm.out","r",stdout);
	cout<<3;
	return 0;
}

