#include<bits/stdc++.h>
using namespace std;
int n,k,cnt = 0;
int que[100005],down = 0,top = 0;
int main()
{
	freopen("lock.in","w",stdin);
	freopen("lock.out","r",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 0;i < n;i++)
		scanf("%d",&que[top++]);
	for(int i = 0,j = 1;i < k;i++)
	{
		if(j == n+1) j = 1;
		while(j != que[down])
		{
			cnt++;
			que[top] = que[down];
			down++,top++;
		}
		j++;
	}
	printf("%d",cnt);
	return 0;
}

