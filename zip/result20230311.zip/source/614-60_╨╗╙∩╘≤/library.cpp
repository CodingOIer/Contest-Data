#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("library.in","w",stdin);
	freopen(library".out","r",stdout);
	cout<<-1;
	return 0;
}

