#include<bits/stdc++.h>
using namespace std;
int k,m[25],x,tc[5],t,c[25],mp[25];
int sumf(int n)
{
	for(int i = 0;i < 25;i++) mp[i] =0;
	int sum = 0;
	sum+=x*n;
	for(int i = 1;i <= x;i++)
		mp[tc[i]] = n;
	for(int i = 1;i <= t;i++)
	{
		if(mp[c[i]] > 0)
		{
			mp[c[i]]--;
			continue;
		}
		sum+=m[c[i]];
	}
	return sum;
}
int sums()
{
	int sum = 0;
	for(int i = 1;i <= t;i++)
		sum+=m[c[i]];
	return sum;
}
int main()
{
	freopen("mess.in","w",stdin);
	freopen("mess.out","r",stdout);
	scanf("%d",&k);
	for(int i = 1;i <= k;i++) scanf("%d",&m[i]);
	scanf("%d",&x);
	for(int i = 1;i <= 4;i++) scanf("%d",&tc[i]);
	scanf("%d",&t);
	for(int i = 1;i <= t;i++) scanf("%d",&c[i]);
	int sm = 0;for(int i = 0;i < t;i++) sm+=m[c[i]];
	int sum1 = 999999,sum2 = sums();
	for(int i = 1;i <= sm/x;i++)
		sum1 = min(sumf(i),sum1);
	cout<<min(sum1,sum2);
	return 0;
}

