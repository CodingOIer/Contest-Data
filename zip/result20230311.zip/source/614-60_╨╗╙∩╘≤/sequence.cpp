#include<bits/stdc++.h>
using namespace std;
int n,k,a[3*100005];
int main()
{
	freopen("sequence.in","w",stdin);
	freopen("sequence.out","r",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 0;i < n;i++) scanf("%d",&a[i]);
	double mx = 0;
	for(int i = 0;i < n;i++)
	{
		int sum = 0;
		for(int j = i;j < n;j++)
		{
			if(n-i < k) continue;
			sum+=a[j];
		}
		double s = sum*1.0/(n-i);
		mx = s > mx?s:mx;
	}
	printf("%.6lf",mx);
	return 0;
}

