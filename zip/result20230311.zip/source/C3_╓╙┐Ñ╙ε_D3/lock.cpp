#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,t,lo[100005],now=1,lans=0,ans=0;
void txt()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
}
int main()
{
	txt();
	scanf("%lld%lld",&n,&t);
	for(int i=1; i<=n; i++)
	{
		ll lin;
		scanf("%lld",&lin);
		lo[lin]=i;
	}
	for(int i=2; i<=n; i++)
	{
		ll llin;
		llin=lo[i]-lo[i-1];
		if(llin<0)llin=n+llin;
		lans+=llin;
	}
	ll aba=t/n;
	ans=lans*aba+lo[1]-1;
	ll llin;
	llin=lo[1]-lo[n];
	if(llin<0)llin=n+llin;
	ans+=llin*aba;
	for(int i=2; i<=t%n; i++)
	{
		ll llin;
		llin=lo[i]-lo[i-1];
		if(llin<0)llin=n+llin;
		ans+=llin;
	}
	printf("%lld",ans);
}
