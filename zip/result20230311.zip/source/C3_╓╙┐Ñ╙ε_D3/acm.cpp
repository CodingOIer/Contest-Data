#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,ans;
ll a[150050],b[150050],c[150050],dp[150050][4][4];
void txt()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
}
int main()
{
	txt();
	scanf("%lld",&n);
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&b[i]);
	}
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&c[i]);
	}
	dp[1][1][2]=1e17;
	dp[1][2][2]=1e17;
	dp[1][3][2]=1e17;
	dp[2][1][3]=1e17;
	dp[2][2][3]=1e17;
	dp[2][3][3]=1e17;
	for(int i=1; i<=n; i++)
	{
		dp[i][1][1]=dp[i-1][1][1]+a[i];
		dp[i][2][1]=dp[i-1][2][1]+b[i];
		dp[i][3][1]=dp[i-1][3][1]+c[i];
		if(i>=2)
		{
			dp[i][1][2]=min(min(dp[i-1][1][2],dp[i-1][2][1]),dp[i-1][3][1])+a[i];
			dp[i][2][2]=min(min(dp[i-1][2][2],dp[i-1][1][1]),dp[i-1][3][1])+b[i];
			dp[i][3][2]=min(min(dp[i-1][3][2],dp[i-1][1][1]),dp[i-1][2][1])+c[i];
		}
		if(i>=3)
		{
			dp[i][1][3]=min(min(dp[i-1][1][3],dp[i-1][2][2]),dp[i-1][3][2])+a[i];
			dp[i][2][3]=min(min(dp[i-1][2][3],dp[i-1][1][2]),dp[i-1][3][2])+b[i];
			dp[i][3][3]=min(min(dp[i-1][3][3],dp[i-1][1][2]),dp[i-1][2][2])+c[i];
		}
	}
	ans=min(dp[n][1][3],min(dp[n][2][3],dp[n][3][3]));
	printf("%lld",ans);
}
