#include<bits/stdc++.h>
#define ll long long
using namespace std;
struct node
{
	ll no;
	ll y;
};
ll n,m,ans=0;
ll goa[1005][1005],ori[1005][1005],goahangn[1005],orihangn[1005];
vector<node>goahang[1005],orihang[1005];
bool hangbiao[10000005];
void txt()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
}
int main()
{
	txt();
	scanf("%lld%lld",&n,&m);
	bool dabiaoji=1;
	goahangn[1]=1;
	orihangn[1]=1;
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=m; j++)
		{
			scanf("%lld",&ori[i][j]);
			if(ori[i][j]==0)
			{
				dabiaoji=0;
			}
			else
			{
				goahangn[i+1]++;
				node aba;
				aba.y=j;
				aba.no=goa[i][j];
				goahang[i].push_back(aba);
			}
		}
	}
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=m; j++)
		{
			scanf("%lld",&goa[i][j]);
			if(ori[i][j]!=0)
			{
				orihangn[i+1]++;
				node aba;
				aba.y=j;
				aba.no=ori[i][j];
				orihang[i].push_back(aba);
			}
		}
	}
	for(int i=2; i<=n; i++)
	{
		goahangn[i]+=goahangn[i-1];
		orihangn[i]+=orihangn[i-1];
	}
	if(dabiaoji==1)
	{
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=m; j++)
			{
				if(ori[i][j]!=goa[i][j])
				{
					dabiaoji=0;
					break;
				}
			}
		}
		if(dabiaoji==1)printf("0");
		else printf("-1");
		return 0;
	}
	else
	{
		ll lnum=0;
		for(int i=1; i<=n; i++)
		{
			for(int j=0; j<orihang[i].size(); j++)
			{
				lnum++;
				for(int k=0; k<goahang[i].size(); k++)
				{
					hangbiao[goahang[i][k].y]=1;
				}
				for(int k=0; k<goahang[i].size(); k++)
				{
					bool linbj=0;
					if(k>0&&j>0)
					{
						ll lk=k;
						ll lj=j;
						while(hangbiao[orihang[i][lj-1].y]==0)
							lj--;
						if(orihang[i][lj-1].no!=goahang[i][lk-1].no)
						linbj=1;
					}
					if(k>0&&j>0)
					{
						ll lk=k;
						ll lj=j;
						while(hangbiao[orihang[i][lj+1].y]==0)
							lj++;
						if(orihang[i][lj+1].no!=goahang[i][lk+1].no)
						linbj=1;
					}
					if(linbj==1)ans++;
				}
			}
		}
	}
}
