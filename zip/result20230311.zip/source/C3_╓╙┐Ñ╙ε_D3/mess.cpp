#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,x,t,orprice=0,ans=0;
ll price[25],order[25],taocan[5];
void txt()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
}
int main()
{
	txt();
	scanf("%lld",&n);
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&price[i]);
	}
	scanf("%lld",&x);
	for(int i=1; i<=4; i++)
	{
		scanf("%lld",&taocan[i]);
	}
	scanf("%lld",&t);
	for(int i=1; i<=t; i++)
	{
		ll lin;
		scanf("%lld",&lin);
		order[lin]++;
	}
	while(1)
	{
		orprice=0;
		for(int i=1; i<=4; i++)
		{
			if(order[taocan[i]]!=0)
			orprice+=price[taocan[i]];
		}
		if(orprice>x)
		{
			ans+=x; 
			for(int i=1; i<=4; i++)
			{
				if(order[taocan[i]]>0)
				order[taocan[i]]--;
			}
		}
		else
		break;
	}
	for(int i=1; i<=20; i++)
	{
		ans+=order[i]*price[i];
	}
	printf("%lld",ans);
}
