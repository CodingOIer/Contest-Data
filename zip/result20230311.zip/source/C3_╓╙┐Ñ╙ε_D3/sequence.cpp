#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k,begin=1,lans=0,num=0;
double aver=0,ans=0;
ll sheep[300005];
void txt()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
}
int main()
{
	txt();
	scanf("%lld%lld",&n,&k);
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&sheep[i]);
	}
	for(int i=1; i<=n; i++)
	{
		num++;
		lans+=sheep[i];
		aver=(lans*1.0)/(num*1.0);
		bool biao=1;
		while(num>k&&biao==1)
		{
			biao=0;
			while(num>k&&sheep[begin]*1.0<aver)
			{
				biao=1;
				lans-=sheep[begin];
				begin++;
				num--;
			}
			aver=(lans*1.0)/(num*1.0);
		}
		if(num>=k)
		ans=max(ans,aver);
	}
	cout<<fixed<<setprecision(15)<<ans;
}
