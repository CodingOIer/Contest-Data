#include<bits/stdc++.h>
using namespace std;
int k,x,t,p[25],q[25],s,ans,l;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout); 
	cin >> k;
	for(int i=1;i<=k;i++)cin >> p[i];
	cin >> x;
	for(int i=1;i<=4;i++){cin >> l;q[l]+=2;}
	cin >> t;
	for(int i=1;i<=t;i++){cin >> l;q[l]++;}
	for(int i=1;i<=k;i++)
	{
		if(q[i]==3)	s+=p[i];
		if(q[i]==1)	ans+=p[i];
	}
	ans+=min(s,x);
	cout<<ans;
	return 0;
}
