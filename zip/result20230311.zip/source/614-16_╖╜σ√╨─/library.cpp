#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,m,l;
	cin >> n >> m;
	for(int i=1;i<=n;i++)
		for(int i=1;i<=m;i++)
			cin >> l;
	cout<<"-1"; 
	return 0;
}
