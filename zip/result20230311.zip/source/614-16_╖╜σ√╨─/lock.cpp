#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+1;
int n,t,nxt[maxn],q[maxn],s[maxn],w,ans;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout); 
	cin >> n >> t;
	for(int i=1;i<=n;i++)	cin >> q[i];
	for(int i=0;i<n;i++)nxt[i]=i+1; nxt[n]=1;
	w=0;
	for(int i=1;i<=n;i++)
	{
		s[i]=s[i-1];
		do{t--,w=nxt[w],s[i]++;}while(q[nxt[w]]!=i);
		cout<<w<<"\n";
//		while(q[w]!=i)t--,w=nxt[w],s[i]++;
	}
	if(t>0)
	{
		ans=s[n]*(t/n);
		t%=n;
		for(int i=1;i<=n;i++)
		{
			if(t<=0)	break; 
			do{t--,w=nxt[w],ans++;}while(q[w]!=i && t>0);
//			while(q[w]!=i && t>=0)t--,w=nxt[w],ans++;
		}
	}
	else ans=s[n];
	cout<<ans;
	return 0;
}
