#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int n,t,sum=1,ans;
int a[maxn];
int main() {
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie();
	cout.tie();
	cin>>n>>t;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=t;i++){
		int zc=i;
		if(zc>n) zc=zc%n;
		if(sum!=a[zc]){
			ans+=abs(zc-sum);	
			sum=zc;	
		}
		cout<<sum<<" ";
	}
	cout<<endl;
	cout<<ans;
	return 0;
}

