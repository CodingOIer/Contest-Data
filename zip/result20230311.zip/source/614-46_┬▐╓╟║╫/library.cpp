#include <bits/stdc++.h>
using namespace std;
int n,m; 
int main() {
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie();
	cout.tie();
	int x,flag=1;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>x;
			if(x==0) flag=0;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>x;
		}
	}
	if(flag){
		cout<<-1;
		return 0;
	} 
	else{
		srand(time(0));
		int sum=n*m ;
		cout<<rand()%sum+1;
	}
	return 0;
}

