#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=1e5+5;
int n,m,f,x,y,k,a[maxn];
double ans=double(INT_MAX)*1.0;
struct node {
	int l,r;
	ll sum,lazy;
} t[maxn<<4];
void son(int i) {
	t[i].sum=t[i<<1].sum+t[(i<<1)+1].sum;
}
void sth(int i,int l,int r) {
	t[i].l=l;
	t[i].r=r;
	if(l==r) {
		t[i].sum=a[l];
		return;
	}
	int mid=(l+r)/2;
	sth(i<<1,l,mid);
	sth((i<<1)+1,mid+1,r);
	son(i);
}
void down(int i) {
	if(t[i].l==t[i].r) {
		t[i].lazy=0;
		return;
	}
	t[i<<1].sum+=(t[i<<1].r-t[i<<1].l+1)*t[i].lazy;
	t[(i<<1)+1].sum+=(t[(i<<1)+1].r-t[(i<<1)+1].l+1)*t[i].lazy;
	t[i<<1].lazy+=t[i].lazy;
	t[(i<<1)+1].lazy+=t[i].lazy;
	t[i].lazy=0;
}
void cg(int i,int l,int r,int k) {
	if(t[i].l==l&&t[i].r==r) {
		t[i].sum+=(t[i].r-t[i].l+1)*k;
		t[i].lazy+=k;
		return;
	}
	down(i);
	int mid=(t[i].l+t[i].r)/2;
	if(r<=mid) cg(i<<1,l,r,k);
	else if(l>mid) cg((i<<1)+1,l,r,k);
	else cg(i<<1,l,mid,k),cg((i<<1)+1,mid+1,r,k);
	son(i);
}
ll cgg(int i,int l,int r) {
	if(t[i].lazy) down(i);
	if(t[i].l==l&&t[i].r==r) return t[i].sum;
	int mid=(t[i].l+t[i].r)/2;
	if(r<=mid) return cgg(i<<1,l,r);
	else if(l>mid) return cgg((i<<1)+1,l,r);
	else return cgg(i<<1,l,mid)+cgg((i<<1)+1,mid+1,r);
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout); 
	ios::sync_with_stdio(false);
	cin.tie();
	cout.tie();
	cin>>n>>m;
	for(int i=1; i<=n; i++) cin>>a[i];
	sth(1,1,n);
	for(int i=1;i<=n;i++){
		int sum=cgg(1,i,i+m);
		ans=max(ans,double(sum));
	}
	cout<<ans/double(m);
	return 0;
}
