#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int k,x,t,ans1,ans2=INT_MAX;
int l1,l2,l3,l4;
int s1,s2,s3,s4;
int sum[maxn],a[maxn],gs[maxn];
int flag[maxn];
int main() {
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout); 
	ios::sync_with_stdio(false);
	cin.tie();
	cout.tie();
	cin>>k;
	for(int i=1;i<=k;i++) cin>>sum[i];
	cin>>x>>l1>>l2>>l3>>l4>>t;
	for(int i=1;i<=t;i++){
		cin>>a[i];
		gs[a[i]]++;
		if(a[i]==l1) s1++;
		else if(a[i]==l2) s2++;
		else if(a[i]==l3) s3++;
		else if(a[i]==l4) s4++;
	}
	int n=max(max(max(s1,s2),s3),s4);
	for(int i=1;i<=k;i++) ans1+=gs[i]*sum[i];
	for(int i=n;i>=1;i--){
		int zc=x*i;
		flag[l1]=i;
		flag[l2]=i;
		flag[l3]=i;
		flag[l4]=i;
		for(int j=1;j<=t;j++){
			if(flag[a[j]]==0) zc+=sum[a[j]];
			else flag[a[j]]--;
		}
		ans2=min(ans2,zc);
	}
	cout<<min(ans1,ans2);
	return 0;
}
