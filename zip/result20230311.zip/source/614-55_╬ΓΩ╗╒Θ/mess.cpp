#include <bits/stdc++.h>
using namespace std;
long long n,a[105],b[105],t,g[105],sum,x,l[105],top=1,ans;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);	
	cin>>x;
	for(long long i=1;i<=x;i++)
		cin>>a[i];
	cin>>t;
	for(long long i=1;i<=4;i++)
		cin>>b[i];
	cin>>n;
	for(long long i=1;i<=n;i++)
		cin>>g[i];
	for(long long i=1;i<=4;i++)
		for(long long j=1;j<=n;j++)
			if(g[j]==b[i])
			{
				sum+=a[b[i]];
				l[top]=b[i];
				top++;
				break;
			}		
	if(sum>=t)
	{
			ans+=t;
		for(long long i=1;i<top;i++)
			ans-=a[l[i]];
	}
	for(long long i=1;i<=n;i++)
		ans+=a[g[i]];
	cout<<ans;
    return 0;
}


