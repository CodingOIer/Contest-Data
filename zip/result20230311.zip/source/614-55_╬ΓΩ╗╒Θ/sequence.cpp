#include <bits/stdc++.h>
using namespace std;
long long n,k,a[300005],sum[300005];
double mx,o;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);	
	cin>>n>>k;
	for(long long i=1;i<=n;i++)
		cin>>a[i],sum[i]=sum[i-1]+a[i];
	for(long long i=k;i<=n;i++)
	{
		o=1.0*(sum[i]-sum[i-k])/k;
		for(long long j=i+1;j<=n;j++)
			if(a[j]>=o)
			{
				 o=1.0*(sum[j]-sum[i-k])/(j+k-i);
				 if(1.0*(sum[j]-sum[j-k])/k>=o)
				 {
				 	i=j-1;
				 	break;
				 }
			}
			else break;
	    mx=max(mx,o);
	}
	printf("%.6lf",mx); 
    return 0;
}


