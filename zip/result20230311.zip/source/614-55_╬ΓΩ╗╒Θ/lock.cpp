#include <bits/stdc++.h>
using namespace std;
long long n,t,a[100005],sum[100005],ans,y,p[100005];
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);	
	cin>>n>>t;
	a[0]=1;
	for(long long i=1;i<=n;i++)
	{
		cin>>a[i],sum[i]=a[i]-a[i-1];
		if(sum[i]<0) sum[i]+=n;
	}
	y=min(n,t);
	for(long long i=1;i<=y;i++)
		ans+=sum[i],t--;
	if(t==0)
	{
		cout<<ans;
		return 0;
	}
	sum[1]=a[1]-a[n];
	if(sum[1]<0) sum[1]+=n;
	y=t/n;
	for(long long i=1;i<=n;i++)
		p[i]=p[i-1]+sum[i];
	ans+=y*p[n];
	ans+=p[t-y*n];
	cout<<ans;
    return 0;
}


