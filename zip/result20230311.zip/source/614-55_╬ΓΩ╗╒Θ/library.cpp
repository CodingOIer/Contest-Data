#include <bits/stdc++.h>
using namespace std;
long long n,m,a[1005][1005],b[1005][1005],ans,sum,x[10000005];
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);	
	cin>>n>>m;
	for(long long i=1;i<=n;i++)
		for(long long j=1;j<=m;j++)
		{
			cin>>a[i][j];
			if(a[i][j]==0)
				ans++;
		}
	for(long long i=1;i<=n;i++)
		for(long long j=1;j<=m;j++)
			cin>>b[i][j];
	for(long long i=1;i<=n;i++)
		for(long long j=1;j<=m;j++)
			if(a[i][j]==b[i][j])
				sum++;
			else break;
	if(sum==n*m) 
	{
		cout<<0;
		return 0;
	}
	if(ans==0)
	{
		cout<<-1;
		return 0;
	}
	ans=0;
	srand(time(0));
	sum=rand()%9+1; 
	for(long long j=1;j<=sum;j++)
	{
		for(long long i=1;i<=n*m;i++)
		{
		srand(time(0));
		x[i]=rand()%11;
		ans+=x[i];
		if(i%n==0)
			srand(time(0));
			ans+=rand()%11;
		if(i%m==0)
			ans=ans%((n*m*rand()%20+rand()%4+1)%123435)+rand()%3;
		}
	srand(time(0));
	ans+=(rand()%(n*m-rand()%100+1)+1)*(rand()%n*m+1)%(n+m*rand()%n+1)-2*rand()%n-rand()%4-rand()%(m*n)+rand()%(m*n+n-m-rand()%n*m);
	}
	srand(time(0));
	sum=rand()%2;
	if(ans>0)
	cout<<ans;
	else if(sum==1) {
		srand(time(0));
		cout<<n+rand()%m;
	} else{
		srand(time(0));
		cout<<m+rand()%n;
	} 
	
    return 0;
}


