#include<bits/stdc++.h>
using namespace std;

int n,k,sheep[300005],l = 1,r;
long long h[300005],sum;
double ans;

int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&k);
	r = n;
	for(int i = 1;i <= n;i++){
		scanf("%d",sheep+i);
		h[i] = h[i-1]+sheep[i];
	}
	while(r-l+1 >= k){
		sum = h[r]-h[l-1];
		ans = max(sum/((r-l+1)*1.00),ans);
		if(sheep[l]<sheep[r])	l++;
		else	r--;
	}
	cout << fixed << setprecision(8) << ans;
	return 0;
}

