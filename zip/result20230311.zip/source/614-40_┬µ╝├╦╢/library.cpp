#include<bits/stdc++.h>
using namespace std;
int n,m,t[1005][1005],y[1005][1005],ans;
bool f=1;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>t[i][j];
			if(t[i][j]!=0) f=0;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>y[i][j];
			if(y[i][j]!=t[i][j]) ans++;
		}
	}
	if(f) cout<<-1;
	else{
		cout<<ans;
	}
	return 0;
} 
