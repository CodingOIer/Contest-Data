#include<bits/stdc++.h>
using namespace std;
long long ans,m;
int n,t,a[100005];
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		if(i==1) ans+=a[i]-1;
		else if(a[i]<a[i-1]) ans+=n-a[i-1]+a[i];
		else ans+=a[i]-a[i-1];
		if(i==t){
			cout<<ans;
			return 0;
		}
	}
	m=a[n];
	if(n<t){
		for(int i=1;i<=t-n;i++){
			if(a[(i-1)%n+1]<m) ans+=n-m+a[(i-1)%n+1];
			else ans+=a[(i-1)%n+1]-m;
			m=a[(i-1)%n+1];
		}
	}
	cout<<ans;
	return 0;
} 
