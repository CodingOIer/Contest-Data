#include<bits/stdc++.h>
using namespace std;
long long ans;
int k,x,a[35],t,s,v[35],g1,g2,g3,g4;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++) scanf("%d",&a[i]);
	cin>>x;
	scanf("%d%d%d%d",&g1,&g2,&g3,&g4);
	cin>>t;
	for(int i=1;i<=t;i++){
		scanf("%d",&s);
		if(s!=g1&&s!=g2&&s!=g3&&s!=g4) ans+=a[s];
		v[s]++;
	}
	int l=min(min(max(v[g1],v[g2]),v[g3]),v[g4]);
	int r=min(max(max(v[g1],v[g2]),v[g3]),v[g4]);
	long long minn=LONG_LONG_MAX;
	for(int i=l;i<=r;i++){
		long long g=ans;
		g+=i*x;
		g+=max(0,v[g1]-i)*a[g1];
		g+=max(0,v[g2]-i)*a[g2];
		g+=max(0,v[g3]-i)*a[g3];
		g+=max(0,v[g4]-i)*a[g4];
		if(g<minn) minn=g;
	}
	cout<<minn;
	return 0;
} 
