#include<bits/stdc++.h>
using namespace std;
double g;
int t[300005],k,n;
int lb(int x){
	return x&-x;
}
void add(int x,int id){
	while(x<=n){
		t[x]+=id;
		x+=lb(x);
	}
	return;
}
int sum(int x){
	int ans=0;
	while(x!=0){
		ans+=t[x];
		x-=lb(x);
	}
	return ans;
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&x);
		add(i,x);
	}
//	for(int i=1;i<=n;i++) cout<<t[i]<<" ";
//	cout<<"\n";
	for(int i=k;i<=n;i++){
		double ans;
		for(int j=1;j<=n;j+=i){
			ans=double(sum(j+i)-sum(j))/double(i);
			g=max(ans,g);
		}
	}
	printf("%.6lf",g);
	return 0;
} 
