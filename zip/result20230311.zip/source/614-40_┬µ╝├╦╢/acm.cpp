#include<bits/stdc++.h>
using namespace std;
long long ans,n,k[150005];
struct st{
	long long t[150005],x,cx,ccx,l,r;
}wyz,gyf,hyz;
long long lb(long long x){
	return x&-x;
}
void add(long long x,long long id,long long v){
	while(x<=n){
		if(v==1) wyz.t[x]+=id;
		if(v==2) gyf.t[x]+=id;
		if(v==3) hyz.t[x]+=id;
		x+=lb(x);
	}
	return;
}
long long sum(long long x,long long v){
	long long ans=0;
	while(x!=0){
		if(v==1) ans+=wyz.t[x];
		if(v==2) ans+=gyf.t[x];
		if(v==3) ans+=hyz.t[x];
		x-=lb(x);
	}
	return ans;
}
int main(){
//	freopen("acm.in","r",stdin);
//	freopen("acm.out","w",stdout);
	cin>>n;
	long long q;
	for(long long i=1;i<=n;i++){
		scanf("%lld",&q);
		add(i,q,1);
		if(q<sum(wyz.t[wyz.x],1)-sum(wyz.t[wyz.x-1],1)){
			wyz.ccx=wyz.cx;
			wyz.cx=wyz.x;
			wyz.x=i;
		}
	}
	for(long long i=1;i<=n;i++){
		scanf("%lld",&q);
		add(i,q,2);
		if(q<sum(gyf.t[gyf.x],2)-sum(gyf.t[gyf.x-1],2)){
			gyf.ccx=gyf.cx;
			gyf.cx=gyf.x;
			gyf.x=i;
		}
	}
	for(long long i=1;i<=n;i++){
		scanf("%lld",&q);
		add(i,q,3);
		if(q<sum(hyz.t[hyz.x],3)-sum(hyz.t[hyz.x-1],3)){
			hyz.ccx=hyz.cx;
			hyz.cx=hyz.x;
			hyz.x=i;
		}
	}
	wyz.l=wyz.r=wyz.x;
	gyf.l=gyf.r=gyf.x;
	hyz.l=hyz.r=hyz.x;
	if(wyz.l==gyf.l){
		if(wyz.cx>gyf.cx){
			gyf.l=gyf.r=gyf.cx;
			if(wyz.l==hyz.l){
				if(wyz.cx>hyz.cx){
					hyz.l=hyz.r=hyz.cx;
				}
				else wyz.l=wyz.r=wyz.cx;
			}
		}else{
			wyz.l=wyz.r=wyz.cx;
		}
	}
	k[wyz.l]=1;
	k[gyf.l]=1;
	k[hyz.l]=1;
	for(long long i=1;i<=n;i++){
		if(k[i]==1) continue;
		else{
			long long a,b,c;
			if(i<wyz.l) a=sum(wyz.l,1)-sum(i-1,1);
			else a=sum(i,1)-sum(wyz.r-1,1);
			if(i<gyf.l) b=sum(gyf.l,2)-sum(i-1,2);
			else b=sum(i,2)-sum(gyf.r-1,2);
			if(i<hyz.l) c=sum(hyz.l,3)-sum(i-1,3);
			else c=sum(i,3)-sum(hyz.r-1,3);
			if(a<b){
				if(a<c){
					if(i<wyz.l) wyz.l=i;
					else wyz.r=i;
				}else{
					if(i<hyz.l) hyz.l=i;
					else hyz.r=i;
				}
			}else{
				if(b<c){
					if(i<gyf.l) gyf.l=i;
					else gyf.r=i;
				}else{
					if(i<hyz.l) hyz.l=i;
					else hyz.r=i;
				}
			}
		}
	}
	ans=sum(wyz.r,1)-sum(gyf.l-1,1)+sum(gyf.r,2)-sum(gyf.l-1,2)+sum(hyz.r,3)-sum(hyz.l-1,3);
	cout<<ans;
	return 0;
}
