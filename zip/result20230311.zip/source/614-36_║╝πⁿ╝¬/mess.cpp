#include<bits/stdc++.h>
using namespace std;
int a,b[25];
int c,d[25];
int e,f[25],g[25];
int jg,zh;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++)cin>>b[i];
	cin>>c;
	for(int i=1;i<=4;i++)cin>>d[i];
	cin>>e;
	for(int i=1;i<=e;i++){cin>>f[i];g[i]=f[i];}
	for(int i=1;i<=c;i++)
		for(int j=1;j<=e;j++){
			if(d[i]==f[j]){
				jg+=b[d[i]];
				d[i]=0;f[j]=0;
			}
		}
	if(c<=jg){
		for(int i=1;i<=e;i++) zh+=b[f[i]];
		cout<<c+zh<<" nin";
	}else{
		for(int i=1;i<=e;i++)zh+=b[g[i]];
		cout<<zh<<" yes";
	}
	return 0;
}

