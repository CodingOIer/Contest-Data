#include<bits/stdc++.h>
using namespace std;
int n,t;
int a[10005];
int b;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	int c=0;
	cin>>n>>t;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1,d=1;b<t;d++){
		if(d>n)d=1;
		if(i>n)i=1;
		if(a[d]==i){b++;i++;}
		c++;
	}
	cout<<c-1;
	return 0;
}

