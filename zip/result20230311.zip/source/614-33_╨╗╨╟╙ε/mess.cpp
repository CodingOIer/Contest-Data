#include <bits/stdc++.h>
using namespace std;
int N,X,T;
int ans = 0,cnt = 0;
int A[11451] = {},eat[11451] = {},tc[114] = {};
int vis[11451] = {};
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&N);
	for (int i = 1; i <= N; i++)
		scanf("%d",&A[i]);
	scanf("%d",&X);
	for (int i = 1; i <= 4; i++)
		scanf("%d",&tc[i]);
	scanf("%d",&T);
	for (int i = 1; i <= T; i++)
		scanf("%d",&eat[i]);
		
	int sum[1145] = {};
	for (int i = 1; i <= 4; i++)
	{
		for (int j = 1; j <= T; j++)
			if (eat[j] == tc[i])
			{
				vis[eat[j]]++;
				sum[vis[eat[j]]] += A[eat[j]];
				cnt = max(cnt,vis[eat[j]]);
			}	
	}
	for (int j = 1; j <= cnt; j++)
			ans += min(X,sum[j]);
	for (int i = 1; i <= T; i++)
		if (!vis[eat[i]])
			ans += A[eat[i]];
	printf("%d",ans);
    return 0;
}
