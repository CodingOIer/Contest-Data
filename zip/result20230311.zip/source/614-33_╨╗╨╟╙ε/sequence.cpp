#include <bits/stdc++.h>
using namespace std;
const int Max = 300000;
int N,K;
float sum = 0,ans = 0-Max;
int x,y;
struct tr
{
	float pvl = 0;
	int l,r;
}tre[Max*4+4] = {};
void build(int l, int r, int root)
{
	tre[root].l = l; tre[root].r = r;
	if (l == r)
	{
		scanf("%f",&tre[root].pvl);
		return ;
	}
	int mid = (l+r) >> 1;
	build(l,mid,root*2);
	build(mid+1,r,root*2+1);
	tre[root].pvl = tre[root*2].pvl + tre[root*2+1].pvl;
}
void ask(int l, int r, int root)
{
	if (x <= l && r <= y)
	{
		sum += tre[root].pvl;
		return ;
	}
	int mid = (r+l) >> 1;
	if (x <= mid)
		ask(l,mid,root*2);		
	if (y > mid)
		ask(mid+1,r,root*2+1);		
}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d %d",&N,&K);
	build(1,N,1);
	for (x = 1; x <= N-K+1; x++)
	{	
		for (y = x+K-1; y <= N; y++)
		{
			sum = 0;
			ask(1,N,1);
			sum /= (y-x+1);
			ans = max(sum,ans);			
		}

	}
	printf("%.6f",ans);
    return 0;
}

