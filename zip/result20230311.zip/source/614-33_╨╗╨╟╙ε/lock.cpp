#include <bits/stdc++.h>
using namespace std;
int N,T,ans = 0;
int A[114514] = {};
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d %d",&N,&T);
	for (int i = 1; i <= N; i++)
		scanf("%d",&A[i]);
	int cnt = 1,i = 1;
	while (T--)
	{
		while (A[cnt] != i)
		{
			ans++;
			cnt++;
			if (cnt > N)
				cnt = 1;
		}
		i++;
		if (i > N)
			i = 1;
		printf("%d\n",ans);
	}
	
	printf("%d",ans);
    return 0;
}
