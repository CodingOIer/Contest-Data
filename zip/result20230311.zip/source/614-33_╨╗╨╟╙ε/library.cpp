#include <bits/stdc++.h>
using namespace std;
int N,M;
int now[1145][1145] = {},gq[1145][1145] = {};
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d %d",&N,&M);
	for (int i = 1; i <= N; i++)
		for (int j = 1; j <= M; j++)
			scanf("%d",&now[i][j]);
	for (int i = 1; i <= N; i++)
		for (int j = 1; j <= M; j++)
			scanf("%d",&gq[i][j]);
	
	printf("-1");
    return 0;
}
