#include<bits/stdc++.h>
using namespace std;
int n,m;
int main(){
freopen("library.in","r",stdin);
freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	printf("-1");
	return 0;
}


