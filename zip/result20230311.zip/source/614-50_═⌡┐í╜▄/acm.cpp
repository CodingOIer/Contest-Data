#include<bits/stdc++.h>
using namespace std;
int n,a[150005],b[150005],c[150005],f[4],s1=6,s2=6,s3=6,m;
long long ans;
int main(){
freopen("acm.in","r",stdin);
freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&c[i]);
		m=min(a[i],min(b[i],c[i]));
		if(a[i]==m) 
		{
			ans+=a[i];
			s2=min(b[i]-a[i],s2);
			s3=min(c[i]-a[i],s3);
			f[1]++;
		}
		else if(b[i]==m)
		{
			ans+=b[i];
			s1=min(a[i]-b[i],s1);
			s3=min(c[i]-b[i],s3);
			f[2]++;
		}
		else 
		{
			ans+=c[i];
			s1=min(a[i]-c[i],s1);
			s2=min(b[i]-c[i],s2);
			f[3]++;
		}
	}
	if(f[1]==0) ans+=s1;
	if(f[2]==0) ans+=s2;
	if(f[3]==0) ans+=s3;
	printf("%lld",ans);
	return 0;
}
