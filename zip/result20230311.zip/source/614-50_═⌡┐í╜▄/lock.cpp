#include<bits/stdc++.h>
using namespace std;
long long n,k,c,ans,sum=1,i=1,a[100005];
int main(){
freopen("lock.in","r",stdin);
freopen("lock.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(;;)
	{
		if(ans>=k) break;
		if(sum>n) sum=1; if(i>n) i=1;
		if(i==a[sum]) ans++,i++;
		else c++,sum++;
	}
	printf("%lld",c);
	return 0;
}
