#include<bits/stdc++.h>
using namespace std;
int ans,sum,as,n,m,t,x,s1,s2,s3,s4,s[25],a[25],b[21],f[25],l[5];
int main(){
freopen("mess.in","r",stdin);
freopen("mess.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	scanf("%d %d%d%d%d",&x,&s1,&s2,&s3,&s4);
	s[s1]++, s[s2]++, s[s3]++, s[s4]++;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&b[i]);
		ans+=a[b[i]];
		if(b[i]==s1 || b[i]==s2 || b[i]==s3 || b[i]==s4)
		{
			if(f[b[i]]<s[b[i]]) sum-=a[b[i]], f[b[i]]++;
			if(b[i]==s1) l[1]++;
			else if(b[i]==s2) l[2]++;
			else if(b[i]==s3) l[3]++;
			else if(b[i]==s4) l[4]++;
			as-=a[b[i]];
		}
	}
	m=max(l[1],max(l[2],max(l[3],l[4])));
	ans=min(sum+ans+x,min(ans,ans+m*x+as));
	printf("%d",ans);
	return 0;
}
