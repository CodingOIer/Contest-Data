#include<bits/stdc++.h>
using namespace std;
const int MX=1e6+10;
int n,sum=1e9;
struct {
	int x_1,x_2,x_3;
} a[MX];
void init() {
	cin>>n;
	for(int i=1; i<=n; i++) {
		int kkk;
		cin>>kkk;
		a[i].x_1=a[i-1].x_1+kkk;
	}
	for(int i=1; i<=n; i++) {
		int kkk;
		cin>>kkk;
		a[i].x_2=a[i-1].x_2+kkk;
	}
	for(int i=1; i<=n; i++) {
		int kkk;
		cin>>kkk;
		a[i].x_3=a[i-1].x_3+kkk;
	}
}
int main() {
	init();
	for(int i=1; i<n-1; i++) {
		for(int j=i+1; j<n; j++) {
			int sum1,sum2,sum3;
			int x=a[i].x_1,y=a[i].x_2,z=a[i].x_3;
			if(x<y && x<z) {
				sum1+=x;
				int x=a[j].x_2-a[i].x_2+a[n].x_3-a[j].x_3,y=a[j].x_3-a[i].x_3+a[n].x_2-a[j].x_2;
				sum1+=min(x,y);
			} else if(y<x && y<z) {
				sum1+=y;
				int x=a[j].x_1-a[i].x_1+a[n].x_3-a[j].x_3,y=a[j].x_3-a[i].x_3+a[n].x_1-a[j].x_1;
				sum1+=min(x,y);
			} else {
				sum1+=z;
				int x=a[j].x_1-a[i].x_1+a[n].x_2-a[j].x_2,y=a[j].x_2-a[i].x_2+a[n].x_1-a[j].x_1;
				sum1+=min(x,y);
			}

			x=a[j].x_1-a[i].x_1,y=a[j].x_2-a[i].x_2,z=a[j].x_3-a[i].x_3;
			if(x<y && x<z) {
				sum2+=x;
				int x=a[i].x_2+a[n].x_3-a[j].x_3,y=a[i].x_3+a[n].x_2-a[j].x_2;
				sum2+=min(x,y);
			} else if(y<x && y<z) {
				sum2+=y;
				int x=a[i].x_1+a[n].x_3-a[j].x_3,y=a[i].x_3+a[n].x_1-a[j].x_1;
				sum2+=min(x,y);
			} else {
				sum2+=z;
				int x=a[i].x_1+a[n].x_2-a[j].x_2,y=a[i].x_2+a[n].x_1-a[j].x_1;
				sum2+=min(x,y);
			}

			x=a[n].x_1-a[j].x_1,y=a[n].x_2-a[j].x_2,z=a[n].x_3-a[j].x_3;
			if(x<y && x<z) {
				sum3+=x;
				int x=a[i].x_2+a[j].x_3-a[i].x_3,y=a[i].x_3+a[j].x_2-a[i].x_2;
				sum3+=min(x,y);
			} else if(y<x && y<z) {
				sum3+=y;
				int x=a[i].x_1+a[j].x_3-a[i].x_3,y=a[i].x_3+a[j].x_1-a[i].x_1;
				sum3+=min(x,y);
			} else {
				sum3+=z;
				int x=a[i].x_1+a[j].x_2-a[i].x_2,y=a[i].x_2+a[j].x_1-a[i].x_1;
				sum3+=min(x,y);
			}
			sum=min(sum,min(sum1,min(sum2,sum3)));
		}
	}
	srand(time (NULL));
	cout<<sum-rand()%3;
	return 0;
}
