#include<bits/stdc++.h>
using namespace std;
const int MX=3*1e5+10;
int n,m;
double ans,sum,a[MX];
void init() {
	cin>>n>>m;
	for(int i=1; i<=n; i++) {
		int kkk;
		cin>>kkk;
		a[i]=a[i-1]+kkk;
	}
}
double check(int x) {
	double kkk=0;
	for(int i=x; i<=n; i++) 
		kkk=max(kkk,a[i]-a[i-x]);
	return kkk;
}
int main() {
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	init();
	for(double i=m; i<=n; i++) {
		int sum=check(i);
		ans=max(sum/i*1.0,ans);
	}
	printf("%.6f",ans);
	return 0;
}

