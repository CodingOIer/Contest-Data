#include<bits/stdc++.h>
using namespace std;
int k,food[25],x,t[25],buy[25];
int ans=1e9,sum;
void init() {
	cin>>k;
	for(int i=1; i<=k; i++) cin>>food[i];
	cin>>x;
	for(int i=1; i<=4; i++) {
		int kkk;cin>>kkk;t[kkk]++;
	}
	cin>>k;
	for(int i=1; i<=k; i++) {
		int kkk;cin>>kkk;buy[kkk]++;
	}
}
int main() {
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	init();
	for(int i=0; i<=20; i++) {
        sum=i*x;
		for(int j=1; j<=20; j++) 
			if(buy[j]!=0) 
				sum+=max(0,(buy[j]-i*t[j]))*food[j];
		ans=min(sum,ans);
	}
	cout<<ans;
	return 0;
}
