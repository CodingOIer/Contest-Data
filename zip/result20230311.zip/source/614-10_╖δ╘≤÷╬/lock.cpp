#include<bits/stdc++.h>
using namespace std;
const int MX=1e5+10;
int n,t,a[MX],past=1,ans[MX];
void init() {
	cin>>n>>t;
	for(int i=1; i<=n; i++) {
		int kkk;
		cin>>kkk;
		a[kkk]=i;
	}
}
int main() {
    freopen("lock.in","r",stdin);
    freopen("lock.out","w",stdout);
	init();
	for(int i=1; i<=n; i++) {
		if(a[i]<past) ans[i]=ans[i-1]+a[i]-past+n;
		else ans[i]=ans[i-1]+a[i]-past;
		past=a[i];
	}
	if(a[1]<a[n]) ans[0]=a[1]-a[n]+n;
	int ans1=0;
	if(t>n) {
		int wl=t/n;
		ans1=(wl)*ans[n];
		ans1+=(ans[0]-ans[1])*(wl);
		ans1+=ans[t%n];
	} else ans1=ans[t];
	cout<<ans1;
	return 0;
}
