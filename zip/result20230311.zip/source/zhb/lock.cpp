#include<cstdio>
#define N 1000010
typedef long long LL;
int n,a[N],door[N];LL T,sum[2*N],ans;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%lld",&n,&T);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)door[a[i]]=i;
	int last=1;
	for(int i=1;i<=n+n;i++){
		int x=(i-1)%n+1;
		if(last<=door[x])sum[i]=door[x]-last+sum[i-1];
		else sum[i]=n-last+door[x]+sum[i-1];
		last=door[x];
	}
	if(T<=n+n)ans=sum[T];
	else {
		ans+=sum[n];T-=n;
		ans+=T/n*(sum[n+n]-sum[n]);T%=n;
		for(int i=1;i<=T;i++)ans+=sum[n+i]-sum[n+i-1];
	}
	printf("%lld\n",ans);
	return 0;
}
