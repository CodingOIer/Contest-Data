#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define N 150010
#define inf 1061109567
int n,a[3][N],dp[N][9][3],ans=inf,S=7;
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<=2;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	memset(dp,0x3f,sizeof(dp));
	for(int i=0;i<=2;i++)dp[1][1<<i][i]=a[i][1];
	for(int i=1;i<n;i++)
		for(int j=1;j<=S;j++)
			for(int k=0;k<=2;k++){
				if((1<<k)&j){
					dp[i+1][j][k]=min(dp[i+1][j][k],dp[i][j][k]+a[k][i+1]);
					for(int l=0;l<=2;l++)
						if(!((1<<l)&j))
						dp[i+1][j|(1<<l)][l]=min(dp[i+1][j|(1<<l)][l],dp[i][j][k]+a[k][i+1]);
				}
			}
	for(int i=0;i<=2;i++)ans=min(ans,dp[n][S][i]);
	printf("%d\n",ans);
	return 0;
}
