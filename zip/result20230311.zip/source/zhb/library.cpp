#include<cstdio>
#include<algorithm>
using namespace std;
#define N 1001
int a[N][N],b[N][N],n,m,sum1,sum2,f[N],all,ans;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]),sum1+=a[i][j]!=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&b[i][j]),sum2+=b[i][j]!=0;
	if(sum1!=sum2)return puts("-1"),0;
	if(sum1==n*m){
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				if(a[i][j]!=b[i][j])return puts("-1"),0;
		return puts("0"),0;
	}
	if(m==1){
		for(int i=1;i<=n;i++)if(a[1][i])all++;
		f[1]=1;
		for(int i=2;i<=n;i++)
			for(int j=1;j<i;j++)
				if(a[1][i]>a[1][j])f[i]=max(f[i],f[j]+1);
		for(int i=1;i<=n;i++)ans=max(f[i],ans);
		printf("%d\n",all-ans);
	}
	return 0;
}
