//���������ݹ�����,�������㷨������,??? 
#include <algorithm>
#include <cassert>
#include <cstring>
#include <iostream>

using namespace std;
const int MAXN = 300010;
double f[MAXN],ans=-1;
long long s[MAXN];
int a[MAXN],num[MAXN];
int n, k;

int main(void) {
   freopen("sequence.in","r",stdin);
   freopen("sequence.out","w",stdout);
  scanf("%d %d", &n, &k);
  for (int i = 1; i <= n; ++i)
  {
    scanf("%d", &a[i]);
    s[i] = s[i-1] + a[i];
  }
  f[k]=s[k]*1.0;
  num[k]=k;
  for(int i=k+1;i<=n;i++)
  {  if((s[i]-s[i-k])*1.0/k>(f[i-1]+a[i])*1.0/(num[i-1]+1))
     {  f[i]=s[i]-s[i-k];
        num[i]=k;
     }
     else
     {  f[i]=f[i-1]+a[i];
        num[i]=num[i-1]+1;
     }
     if(f[i]/num[i]>ans) ans=f[i]/num[i];
  }
  printf("%lf\n", ans);
  return 0;
}
