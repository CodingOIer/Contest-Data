#include<bits/stdc++.h>
using namespace std;
int k,t,m,x,ans,min_=1e9;
int a[100],b[100],c[300];
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++) scanf("%d",&a[i]);
	scanf("%d",&m);
	for(int i=1;i<=4;i++) scanf("%d",&x),b[x]++;
	scanf("%d",&t);
	for(int i=1;i<=t;i++) scanf("%d",&x),c[x]++;
	for(int i=0;i<=30;i++)
	{
		ans=i*m;
		for(int j=1;j<=k;j++)
		{
			if(i*b[j]<c[j]) ans+=(c[j]-i*b[j])*a[j];
		}
		min_=min(min_,ans);
	}
	printf("%d",min_);
}
