#include<bits/stdc++.h>
using namespace std;
int a[100005],p[100005],num;
long long ans;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	int n,t;
	scanf("%d%d",&n,&t);
	for(int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
		p[a[i]]=i;
	}
	for(int i=1;i<n;i++)
	{
		a[i]=(p[i+1]+n-p[i])%n;
		num+=a[i];
	}
	a[n]=(p[1]+n-p[n])%n;
	num+=a[n];
	ans+=p[1]-1;
	ans+=(t-1)/n*num;
	for(int i=1;i<=(t-1)%n;i++) ans+=a[i];
	printf("%lld",ans);
}
