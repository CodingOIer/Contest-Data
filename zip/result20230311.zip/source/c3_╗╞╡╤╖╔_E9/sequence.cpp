#include<bits/stdc++.h>
using namespace std;
long long a[300005];
double ans;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int n,k,x;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&x),a[i]=a[i-1]+x;
	for(int i=k;i<=n;i++)
	{
		for(int j=1;j<=n-i+1;j++)
		{
			ans=max(ans,(a[j+i-1]-a[j-1])*1.0/i);
		}
	}
	cout<<fixed<<setprecision(6)<<ans;
	return 0;
} 
