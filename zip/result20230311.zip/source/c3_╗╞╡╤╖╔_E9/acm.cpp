#include<bits/stdc++.h>
using namespace std;
int a[150005][5],ans=1e9;
int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	int n,x;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&x),a[i][1]=a[i-1][1]+x;
	for(int i=1;i<=n;i++) scanf("%d",&x),a[i][2]=a[i-1][2]+x;
	for(int i=1;i<=n;i++) scanf("%d",&x),a[i][0]=a[i-1][0]+x;
	for(int x=0;x<3;x++)
	for(int y=0;y<3;y++)
	{
		if(x==y) continue;
		int min1=1e9,min2=1e9,p1,p2;
		for(int i=2;i<=n-1;i++)
		{
			if(a[i][y]+a[n][3-x-y]-a[i][3-x-y]<=min2)
			{
				p2=i;
				min2=a[i][y]+a[n][3-x-y]-a[i][3-x-y];
			}
		}
		for(int i=1;i<p2;i++)
		{
			if(a[i][x]+a[p2][y]-a[i][y]<min1)
			{
				p1=i;
				min1=a[i][x]+a[p2][y]-a[i][y];
			}
		}
		ans=min(ans,a[p1][x]+a[p2][y]-a[p1][y]+a[n][3-x-y]-a[p2][3-x-y]);
	}
	printf("%d",ans);
}

