#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],b[1005][1005];
bool b1,b2;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&b[i][j]);
			if(a[i][j]!=b[i][j]) b1=1;
			if(!b[i][j]) b2=1;
		}
	}
	if(!b1) cout<<0,exit(0);
	if(!b2) cout<<-1,exit(0); 
}
