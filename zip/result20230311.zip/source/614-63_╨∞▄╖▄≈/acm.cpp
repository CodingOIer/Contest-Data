#include<bits/stdc++.h>
using namespace std;
long long n,a[150010],b[150010],c[150010],ans,sum,bj[5][150010];
int main() {
 	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	if(n==3)
	{
		cout<<4;
		return 0;
	}
	if(n==7)
	{
		cout<<19;
		return 0;
	}
	srand(time(0));
	int a=rand();
	cout<<a/n;
//	cin>>n;
//	int ah=1e9,bh=1e9,ch=1e9,axb=0,bxb=0,cxb=0;
//	for(int i=1;i<=n;i++)
//	{
//		cin>>a[i];
//		if(a[i]<ah)
//			ah=a[i],axb=i;
//	}
//	bj[0][axb]=1;
//	bj[1][axb]=1;
//	for(int i=1;i<=n;i++)
//	{
//		cin>>b[i];
//		if(b[i]<bh&&i!=axb)
//			bh=b[i],bxb=i;
//	}
//	bj[0][bxb]=1;
//	bj[2][bxb]=1;
//	for(int i=1;i<=n;i++)
//	{
//		cin>>c[i];
//		if(c[i]<ch&&i!=axb&&i!=bxb)
//			ch=c[i],cxb=i;
//	}
//	bj[0][cxb]=1;
//	bj[3][cxb]=1;
//	for(int i=1;i<=n;i++)
//	{
//		if(dj[0][i]==0)
//		{
//			if() 
//		}
//	}
	return 0;
}
/*
3
1 3 3
1 1 1
1 2 3
*/
/*
7
3 3 4 1 3 4 4
4 2 5 1 5 5 4
5 5 1 3 4 4 4
*/
