#include<bits/stdc++.h>
using namespace std;
long long k,x,t,sum,kjg[100],xjg[10],tzl[100],ans;
int main()
{
 	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
//	kjg[0]=0;
	for(int i=1;i<=k;i++)
		cin>>kjg[i];
	cin>>x;
	for(int i=1;i<=4;i++)
		cin>>xjg[i];
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>tzl[i];
		sum+=kjg[tzl[i]];
	}
	ans+=x;	
	for(int i=1;i<=t;i++)
	{
		for(int j=1;j<=4;j++)
		{
			if(xjg[j]==tzl[i]&&xjg[j]!=0)
			{
				//ans-=kjg[tzl[i]];
				tzl[i]=0;
				xjg[j]=0;
			}
		}
	}
	for(int i=1;i<=t;i++)
	{
		ans+=kjg[tzl[i]];
	}
	cout<<min(ans,sum);
	return 0;
}
/*
7
10 6 8 9 4 5 3
14
1 2 3 4
5
1 3 4 6 7
*/

