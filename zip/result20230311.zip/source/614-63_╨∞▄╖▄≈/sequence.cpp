#include<bits/stdc++.h>
using namespace std;
long long n,k,a[300010];
double sum,ans;
int main()
{
 	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		a[i]+=a[i-1];
	}
	for(int i=1;i<=n;i++)//300000*300000
	{
		for(int j=i+k-1;j<=n;j++)
		{
			sum=a[j]-a[i-1];
			sum/=(j-i+1);
			ans=max(ans,sum);
		}
	}
	printf("%.6f",ans);
	return 0;
}

