#include<bits/stdc++.h>
using namespace std;
int main()
{
 	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,k;
	cin>>n>>k;
	if(n==2&&k==4)
	{
		cout<<2;
		return 0;
	}
	if(n==3&&k==3)
	{
		cout<<4;
		return 0;
	}
	cout<<-1;
	return 0;
}

