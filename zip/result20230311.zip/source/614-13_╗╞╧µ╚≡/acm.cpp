#include<bits/stdc++.h>
using namespace std;//a��a%n+1 
long long n,suma[100005],sumb[100005],sumc[100005],t,ans=11451419190810;
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)cin>>t,suma[i]=suma[i-1]+t;
	for(int i=1;i<=n;i++)cin>>t,sumb[i]=sumb[i-1]+t;
	for(int i=1;i<=n;i++)cin>>t,sumc[i]=sumc[i-1]+t;
	for(int i=1;i<n;i++){
		for(int j=1;j<i;j++){
			t=(suma[j]+sumb[i]-sumb[j]+sumc[n]-sumc[i]);
			ans=min(t,ans);
			t=(suma[j]+sumc[i]-sumc[j]+sumb[n]-sumb[i]);
			ans=min(t,ans);
			t=(sumb[j]+suma[i]-suma[j]+sumc[n]-sumc[i]);
			ans=min(t,ans);
			t=(sumb[j]+sumc[i]-sumc[j]+suma[n]-suma[i]);
			ans=min(t,ans);
			t=(sumc[j]+suma[i]-suma[j]+sumb[n]-sumb[i]);
			ans=min(t,ans);
			t=(sumc[j]+sumb[i]-sumb[j]+suma[n]-suma[i]);
			ans=min(t,ans);
		}
	}
	cout<<ans;
	return 0;
}
/*
3
1 3 3
1 1 1
1 2 3

*/
