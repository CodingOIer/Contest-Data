#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cout<<1;
	return 0;
}
