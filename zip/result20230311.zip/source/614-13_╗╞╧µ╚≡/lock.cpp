#include<bits/stdc++.h>
using namespace std;//a��a%n+1 
int n,t,a[100005],inx[100005],ans,cnt;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d%d",&n,&t);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]),inx[a[i]]=i;
	for(int i=1;i<=n;i++){
		ans+=inx[i]-1;cnt+=inx[i];
		for(int j=inx[i]+1;j<=n;j++)inx[a[j]]-=inx[i];
		for(int j=1;j<=inx[i];j++)inx[a[j]]=n+1-j;
	}
	if(cnt>=t){cout<<ans<<endl;return 0;}
	while(ans<t){
		for(int i=1;i<=n;i++){
			ans+=inx[i]-1;cnt+=inx[i];
			for(int j=inx[i]+1;j<=n;j++)inx[a[j]]-=inx[i];
			for(int j=1;j<=inx[i];j++)inx[a[j]]=n+1-j;
		}
	}
	cout<<ans-1;
	return 0;
}
