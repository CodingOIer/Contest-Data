#include<bits/stdc++.h>
using namespace std;
int k,mon[10005],x,tc[5],t,b[10005],ans,c[10005];
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)cin>>mon[i];
	cin>>x;
	for(int i=1;i<=4;i++)cin>>tc[i];
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>b[i];
		for(int j=1;j<=4;j++)
			c[j]+=(b[i]==tc[j]);
		ans+=mon[b[i]];	
	}
	int mn=min(min(c[1],c[2]),min(c[3],c[4]));
	if(mon[tc[1]]+mon[tc[2]]+mon[tc[3]]+mon[tc[4]]>x)
	ans-=mn*(mon[tc[1]]+mon[tc[2]]+mon[tc[3]]+mon[tc[4]]-x);
	cout<<ans;
	return 0; 
}
/*
7
10 6 8 9 4 5 3
14
1 2 3 4
5
1 3 4 6 7

*/
