#include<bits/stdc++.h>
using namespace std;
int n,a[200010],b[200010],c[200010],aq[200010],bq[200010],cq[200010],mi = INT_MAX,nm;
int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1;i <= n;i++) scanf("%d",&a[i]),aq[i] = aq[i - 1] + a[i]; 
	for(int i = 1;i <= n;i++) scanf("%d",&b[i]),bq[i] = bq[i - 1] + b[i]; 
	for(int i = 1;i <= n;i++) scanf("%d",&c[i]),cq[i] = cq[i - 1] + c[i]; 
	for(int i = 1;i <= n;i++)
	{
		if(i == 1) nm = 2;
		else nm = 0;
		for(int k = i;k <= n - nm;k++) 
		{
			if(i == 1)
			{
				for(int j = k + 1;j < n;j++)  mi = min(mi,aq[k] + bq[j] - bq[k] + cq[n] - cq[j]);
				for(int j = k + 1;j < n;j++)  mi = min(mi,aq[k] + cq[j] - cq[k] + bq[n] - bq[j]);
			}
			else
			{
				if(k < n)  mi = min(min(mi,aq[k] - aq[i - 1] + cq[n] - cq[k] + bq[i - 1]),min(mi,aq[k] - aq[i - 1] + bq[n] - bq[k] + cq[i - 1]));
				else
				{
					for(int j = 1;j < i;j++)  mi = min(mi,aq[k] - aq[i - 1] + bq[j] + cq[i - 1] - cq[j]);
					for(int j = 1;j < i;j++)  mi = min(mi,aq[k] - aq[i - 1] + cq[j] + bq[i - 1] - bq[j]);
				}
			}	
		}
	}
	printf("%d",mi);
    return 0;
}

