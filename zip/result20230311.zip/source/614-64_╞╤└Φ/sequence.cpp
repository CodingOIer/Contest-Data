#include<bits/stdc++.h>
using namespace std;
int n,m,a[3000010],aq[3000010],sum;
double kk,k;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;i++) scanf("%d",&a[i]),aq[i] = aq[i - 1] + a[i];
	for(int i = 1;i <= n;i++)
	{
		for(int j = i + m - 1;j <= n;j++)
		{
			k = aq[j] - aq[i - 1];
			k /= (j - i + 1);
			kk = max(kk,k);		
		}		
	}
	printf("%.6f",kk);
    return 0;
}

