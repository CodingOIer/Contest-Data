#include<bits/stdc++.h>
using namespace std;
int n,t,a[1000010],k,x = 1,o,pp;
int main()
{
	//freopen("lock.in","w",stdout);
	scanf("%d%d",&n,&t);
	for(int i = 1;i <= n;i++) scanf("%d",&a[i]);
	for(int i = 1;i <= t;i++)
	{
		o = (i - 1) % n + 1;
		if(a[o] == x) continue;
		if(a[o] > x) k += a[o] - x,x = a[o];
		else
		{
			k += n - x + a[o];
			x = a[o];
		}
	}
	printf("%d",k);
    return 0;
}

