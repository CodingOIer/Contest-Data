#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,z,k,b[5000010],c[1010][1010],d[1010][1010],dmmd;
long long ans;
struct w
{
	int l,r;
	long long dat,ad;
}a[5000010];
void build(int p,int l,int r)
{
	a[p].l = l; a[p].r = r;
	if(l == r) 
	{
		a[p].dat = b[l];
		return;
	}
	int mid = (l + r) / 2;
	build(p * 2,l,mid); build(p * 2 + 1,mid + 1,r);
	a[p].dat = a[p * 2].dat + a[p * 2 + 1].dat;
}
void bj(int k)
{
	a[k * 2].dat += a[k].ad * (a[k * 2].r - a[k * 2].l + 1);
	a[k * 2 + 1].dat += a[k].ad * (a[k * 2 + 1].r - a[k * 2 + 1].l + 1);
	a[k * 2].ad += a[k].ad; a[k * 2 + 1].ad += a[k].ad;
	a[k].ad = 0;
}
void change(int p,int l,int r,int k)
{
	if(l <= a[p].l && a[p].r <= r)
	{
		a[p].dat += (a[p].r - a[p].l + 1) * k;
		a[p].ad += k; 
		return;
	}
	if(a[p].l != a[p].r) bj(p);
	int mid = (a[p].l + a[p].r) / 2;
	if(l <= mid) change(p * 2,l,r,k);
	if(mid < r) change(p * 2 + 1,l,r,k);
	a[p].dat = a[p * 2].dat + a[p * 2 + 1].dat;
}
void ask(int p,int l,int r)
{
	if(l <= a[p].l && a[p].r <= r)
	{
		ans += a[p].dat;
		return;
	}
	if(a[p].l != a[p].r) bj(p);
	int mid = (a[p].l + a[p].r) / 2;
	if(l <= mid) ask(p * 2,l,r);
	if(mid < r) ask(p * 2 + 1,l,r);
}
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			scanf("%d",&c[i][j]);
			if(c[i][j]) dmmd = 1;
		} 
	} 
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			scanf("%d",&c[i][j]);
			if(c[i][j]) dmmd = 1;
		} 
	} 
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			scanf("%d",&d[i][j]);
			if(d[i][j]) dmmd = 1;
		} 
	} 
	if(!dmmd)
	{
		printf("-1");
		return 0;
	}
	else
	{
		cout << n; 
	} 
    return 0;
}

