#include<bits/stdc++.h>
using namespace std;
int k,x,t,a[100],b[100],c[10],d,o,ans;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i = 1;i <= k;i++) scanf("%d",&a[i]);
	scanf("%d",&x);
	for(int i = 1;i <= 4;i++) scanf("%d",&c[i]);
	scanf("%d",&t);
	for(int i = 1;i <= t;i++) scanf("%d",&d),b[d]++;
	while(1)
	{
		o = 0;
		for(int i = 1;i <= 4;i++) if(b[c[i]]) o += a[c[i]];
		if(o > x)
		{
			for(int i = 1;i <= 4;i++) if(b[c[i]]) b[c[i]]--;
			ans += x;
		}
		else break;
	}
	for(int i = 1;i <= 100;i++) if(b[i]) ans += a[i] * b[i];
	printf("%d",ans);
    return 0;
}
/*
7
10 6 8 9 4 5 3
14
1 2 3 4
5
1 3 4 6 7

6
12 5 7 8 9 3
14
4 3 1 2
5
1 2 1 6 6
*/
