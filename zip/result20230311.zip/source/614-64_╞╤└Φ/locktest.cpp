#include<bits/stdc++.h>
using namespace std;
int n,t,a[1000010],k,x = 1,xx = 1,o,b[1000010];
int main()
{
//	freopen("lock.in","r",stdin);
//	freopen("lock.out","w",stdout);
	scanf("%d%d",&n,&t);
	for(int i = 1;i <= n;i++) scanf("%d",&a[i]);
	for(int i = 1;i <= t;i++)
	{
		if(i > n) xx = x;
		o = (i - 1) % n + 1;
		if(a[o] == x) continue;
		if(a[o] > x) k += a[o] - x,x = a[o];
		else
		{
			k += n - x + a[o];
			x = a[o];
		}
		if(i > n * 2)
		{
			cout<<((t - i) / n) * b[n] <<endl;
			k += ((t - i) / n) * b[n] + b[(t - i) % n];
			break;
		}
		if(i > n)
		{
			b[o] = b[o - 1];
			o = (o - 1) % n + 1;
			if(a[o] == xx) continue;
			if(a[o] > xx) b[o] += a[o] - xx,xx = a[o];
			else
			{
				b[o] += n - xx + a[o];
				xx = a[o];
			}
			cout<< b[o] << " " << o << endl; 
		}
	}
	printf("%d",k);
    return 0;
}

