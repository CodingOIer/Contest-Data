#include<bits/stdc++.h>
using namespace std;
long long n,t,a[101010],ans=0,s=1,j=0;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin >> n >> t;
	for(int i=1;i<=n;i++)
		cin >> a[i];
	for(int i=1;i<=t;i++)
	{
		j=i%n;
		if(j==0) j=n;
		if(s==a[j]) continue;
		if(s>a[j])
		{
			ans+=n-(s-a[j]);
			s=a[j];
		}
		if(s<a[j])
		{
			ans+=a[j]-s;
			s=a[j];
		}
	}
	cout << ans;
	return 0;
}
