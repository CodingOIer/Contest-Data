#include<bits/stdc++.h>
using namespace std;
int n,k,a[1010101],s[1010101],sum=0,maxx=-114514;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin >> n >> k;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
		sum+=a[i];
		if(i>=k)
		{
			sum-=a[i-k];
			s[i-k+1]=sum;
		}
	}
	for(int i=1;i<=n-k+1;i++)
		maxx=max(maxx,s[i]);
	cout << (maxx*1.0)/(k*1.0);
	return 0;
}
