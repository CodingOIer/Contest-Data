#include<bits/stdc++.h>
using namespace std;
int a[1010][1010],b[1010][1010],n,m;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin >> n >> m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin >> a[i][j];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin >> b[i][j];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(a[i][j]!=b[i][j]) goto sd;
		}
	cout << 0;
	return 0;
	sd:
	cout << -1;
	return 0;
}
