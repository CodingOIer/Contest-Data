#include<bits/stdc++.h>
using namespace std;
int k,a[30],x,m[10],t,z[30],s_1,s_2,s_3,s_4,tc=0,ans;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin >> k;
	for(int i=1;i<=k;i++)
		cin >> a[i];
	cin >> x >> m[1] >> m[2] >> m[3] >> m[4] >> t;
	sort(m+1,m+5);
	for(int i=1;i<=t;i++)
	{
		cin >> z[27];
		z[z[27]]++;
	}
	s_1+=z[m[1]];
	s_2+=z[m[2]];
	s_3+=z[m[3]];
	s_4+=z[m[4]];
	for(;;)
	{
		int money=0;
		if(s_1!=0) money+=a[m[1]],s_1--;
		if(s_2!=0) money+=a[m[2]],s_2--;
		if(s_3!=0) money+=a[m[3]],s_3--;
		if(s_4!=0) money+=a[m[4]],s_4--;
		if(money>x) tc++;
		else break;
	}
	for(int i=1;i<=tc;i++)
	{
		z[m[1]]--;
		z[m[2]]--;
		z[m[3]]--;
		z[m[4]]--;
	}
	ans=0;
	for(int i=1;i<=20;i++)
		if(z[i]>=1) ans+=z[i]*a[i];
	cout << ans+tc*x;
	return 0;
}
