#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e3+5;
int n,m,ans;
int a[MAX][MAX];
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i<=n*2; i++)
		for(int j = 1; j<=m; j++)
			cin>>a[i][j];
	cout<<-1<<endl;
	return 0;
}

