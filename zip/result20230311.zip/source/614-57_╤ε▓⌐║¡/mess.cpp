#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e3+5;
int n,n_hh,ans,sum,sum_hh,f;
int a[MAX],b[10],c[MAX],id[MAX];
int main(){
	freopen("mess.in","r",stdin); 
	freopen("mess.out","w",stdout);
	cin>>n;
	for(int i = 1; i<=n; i++)cin>>a[i];
	cin>>ans;
	for(int i = 1; i<=4; i++){
		cin>>b[i];
		sum += a[b[i]];
		id[b[i]] += 1;
	}
	cin>>n_hh;
	for(int i = 1; i<=n_hh; i++){
		cin>>c[i];
		sum_hh += a[c[i]];
		id[c[i]] -= 1;
	}
//	for(int i = 1; i<=n; i++)cout<<id[i]<<" ";
//	cout<<endl;
	for(int i = 1; i<=n; i++)
		if(id[i] < 0)f += abs(id[i])*a[i];
	ans += f;
	cout<<min(ans,sum_hh)<<endl;
	return 0;
}
