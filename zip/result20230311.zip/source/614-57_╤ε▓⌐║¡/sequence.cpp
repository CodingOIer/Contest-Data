#include<bits/stdc++.h>
using namespace std;
const int MAX = 3e5+5;
int n,m,ans;
double z;
int a[MAX];
struct node{int l,r,w;}tree[MAX*4];
void bui(int k,int l,int r){
	tree[k].l = l;  tree[k].r = r;
	if(tree[k].l == tree[k].r){
		tree[k].w = a[l];
		return ;
	}
	int mid = (tree[k].l + tree[k].r)/2;
	bui(k*2,l,mid);  bui(k*2+1,mid+1,r);
	tree[k].w = tree[k*2].w + tree[k*2+1].w;
}
void ask(int k,int l,int r){
	if(l <= tree[k].l && tree[k].r <= r){
		ans += tree[k].w;	return;
	}
	int mid = (tree[k].l + tree[k].r)/2;
	if(l <= mid)ask(k*2,l,r);
	if(r > mid)ask(k*2+1,l,r);
}
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i<=n; i++) cin>>a[i];
	bui(1,1,n);
	for(int i = m; i<=n; i++){
		int ans2 = 0;
		for(int j = 1; j<= n-i+1; j++){
			ans = 0;
			ask(1,j,j+i-1);
			ans2 = max(ans2,ans);
//			cout<<i<<":"<<j<<":"<<ans<<endl;
		}
		double z2 = (double)ans2/i;
		z = max(z2,z);
	}
	printf("%.6f",z);
	return 0;
}

