#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e5+5e4;
int n,ans,z;
int a[MAX][5];
struct node{int l,r,w;}tree[MAX*4][5];
void bui(int k,int l,int r,int i){
	tree[k][i].l = l;  tree[k][i].r = r;
	if(tree[k][i].l == tree[k][i].r){
		tree[k][i].w = a[l][i];
		return ;
	}
	int mid = (tree[k][i].l + tree[k][i].r)/2;
	bui(k*2,l,mid,i);  bui(k*2+1,mid+1,r,i);
	tree[k][i].w = tree[k*2][i].w + tree[k*2+1][i].w;
}
void ask(int k,int l,int r,int i){
	if(l <= tree[k][i].l && tree[k][i].r <= r){
		ans += tree[k][i].w;	return;
	}
	int mid = (tree[k][i].l + tree[k][i].r)/2;
	if(l <= mid)ask(k*2,l,r,i);
	if(r > mid)ask(k*2+1,l,r,i);
}
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i = 1; i<=3; i++){
		for(int j = 1; j<=n; j++)
			cin>>a[j][i];
	}
	for(int i = 1; i<=n; i++){
		z += min(a[i][1],min(a[i][2],a[i][3])); 
	}
	cout<<z<<endl;
	return 0;
}

