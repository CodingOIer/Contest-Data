#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e5+5;
int n,t,p,p2,top = 1,ans,ans2,win;
int a[MAX];
int quan(int x){return (x <= n)? x:x%n;}
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	p = t/n; p2 = t%n;
	for(int i = 1; i<=n; i++){
		cin>>a[i];
	}
	int j = 1;
	while(true){
		while(true){
			if(a[j]==top){
				top=quan(top+1),win++;break;
			}
			else ans++,j=quan(j+1);
		}
		if(win == t){cout<<ans; return 0;}
		if(top == j)break;
	}
	p = t/win; p2 = t%win;
	top = j; j = 1;
	while(top <= p2){
		while(true){
			if(a[j]==top){
				top=quan(top+1),win++;break;
			}
			else ans2++,j=quan(j+1);
		}
	}
	cout<<ans*p + ans2<<endl;
	return 0;
}
/*
3 5
1
2
3

4 6
4
2
1
3

10 7
1
3
2
4
5
7
6
8
9
10
*/

