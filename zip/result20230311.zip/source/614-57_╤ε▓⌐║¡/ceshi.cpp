#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e5+5;
int n,m,ans;
int a[MAX*4];
struct node{int l,r,w,f;}tree[MAX];
void bui(int k,int l,int r){
	tree[k].l = l;  tree[k].r = r;
	if(tree[k].l == tree[k].r){
		tree[k].w = a[l];
		return ;
	}
	int mid = (tree[k].l + tree[k].r)/2;
	bui(k*2,l,mid);  bui(k*2+1,mid+1,r);
	tree[k].w = tree[k*2].w + tree[k*2+1].w;
}
void down(int k){
	tree[k*2].f += tree[k].f;
	tree[k*2+1].f += tree[k].f;
	tree[k*2].f += tree[k].f*(tree[k*2].r-tree[k*2].l+1)/2;
	tree[k*2+1].f += tree[k].f*(tree[k*2+1].r-tree[k*2+1].l+1)/2;
	tree[k].f = 0;
}
void ask(int k,int l,int r){
	if(l <= tree[k].l && tree[k].r <= r){
		ans += tree[k].w;	return;
	}
	int mid = (tree[k].l + tree[k].r)/2;
	if(l <= mid)ask(k*2,l,r);
	if(r > mid)ask(k*2+1,l,r);
}
int main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i<=n; i++) cin>>a[i];
	bui(1,1,n);
	ask(1,1,m);
	cout<<ans<<endl;
	return 0;
}

