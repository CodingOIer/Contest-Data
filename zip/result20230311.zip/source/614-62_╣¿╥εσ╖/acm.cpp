#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cout<<"4";
	return 0;
}

