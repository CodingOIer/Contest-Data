#include<bits/stdc++.h>
using namespace std;
int k,jg[25],x,a,b,c,d,t,dc[25],ton[25];
int ans=0;
int bjdx(int aa,int bb){
	if(aa<=bb)  return true;
	else  return false; 
}
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)  cin>>jg[i];
	cin>>x>>a>>b>>c>>d>>t;
	for(int i=1;i<=t;i++){
		cin>>dc[i];
		ton[dc[i]]++;
	}
	for(int i=1;i<=k;i++){
		if(ton[i]!=0){
			if(i!=a && i!=b && i!=c && i!=d){
				while(ton[i]>0){
					ton[i]--;
					ans+=jg[i];
				}
			}
		}
	}
	int aaa[5],y=0;
	for(int i=1;i<=k;i++){
		if(ton[i]>0){
			y++;
			aaa[y]=i;	
		}
	}
	while(ton[aaa[1]]>0 || ton[aaa[2]]>0 ||ton[aaa[3]]>0 || ton[aaa[4]]>0){
		int ddd=0;
		for(int i=1;i<=k;i++){
			if(ton[i]>0){
				ddd+=jg[i];
			}
		}
		if(bjdx(x,ddd)){
			ans+=x;
			ton[aaa[1]]--;
			ton[aaa[2]]--;
			ton[aaa[3]]--;
			ton[aaa[4]]--;
		}
		else{
			for(int j=1;j<=y;j++){
				ans+=jg[aaa[j]]*ton[aaa[j]];
			}
			break;
		}
	}
	cout<<ans;
	return 0;
}

















//for(int i=1;i<=k;i++){
//	int ddd=0,y=0,aaa[5];
//	if(ton[i]!=0){
//		for(int j=1;j<=k;j++){
//			if(ton[j]!=0){
//				ddd+=jg[j];
//				y++;
//				aaa[y]=i;//aaaΪ�±� 
//			}	
//		}
//		if(bjdx(x,ddd)){
//			for(int z=1;z<=y;z++){
//				ton[aaa[z]]--;
//			} 
//			ans+=x;
//		}
//		else{
//			for(int z=1;z<=y;z++){
//					ton[aaa[z]]--;
//					ans+=jg[aaa[z]];
//				}
//			}	
//		}
//	}	
