#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cout<<"4";
	return 0;
}

