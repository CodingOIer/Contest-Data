#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cout<<"-1";
	return 0;
}

