#include<bits/stdc++.h>
using namespace std;
int n,k,a[300005]; 
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(k==1){
		sort(a+1,a+n+1);
		double ans=a[n];
		printf("%.6f",ans);
		return 0;
	} 
	cout<<"3.333333";
	return 0;
}

