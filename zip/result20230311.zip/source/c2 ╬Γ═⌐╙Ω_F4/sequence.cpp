#include<bits/stdc++.h>
using namespace std;

int n,k,a[100010],mx=0;
int sum1,sum2,t1,t2;
double send1,send2,ans;

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) if(a[i]>a[mx]) mx=i;
	sum1=sum2=a[mx];
	for(int i=1;i<k;i++){
		sum1+=a[mx-i];
		sum2+=a[mx+i];
	}
	send1=(double)sum1/k;
	send2=(double)sum2/k;
	t1=t2=k;
	int tot=0;
	while(t1){
		tot+=a[t1];
		double tmp=(double)(sum1+tot)/(mx-t1+1+k);
		send1=max(send1,tmp);
		t1--;
	}
	tot=0;
	while(t2<=n){
		tot+=a[t2];
		double tmp=(double)(sum2+tot)/(t2-mx+1+k);
		send2=max(send2,tmp);
		t2++;
	}
	ans=max(send1,send2);
	printf("%.6lf",ans);
	return 0;
}
