#include<bits/stdc++.h>
using namespace std;

int n,a[1010][1010],ans=0;

int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=3;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
		ans+=min(a[1][i],min(a[2][i],a[3][i]));
	printf("%d",ans+1);
	return 0;
}
