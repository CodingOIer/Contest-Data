/*��ʱ*/
#include<bits/stdc++.h>
using namespace std;

int n,a[100010],t,ans=0;

int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%d %d",&n,&t);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	int i=0;
	while(t>0){
		i++;
		if(i>n) i-=n;
		while(a[1+ans%n]!=i)
			ans++;
		t--;
	}
	printf("%d",ans);
	return 0;
}
