#include<bits/stdc++.h>
using namespace std;

int ans2=0,ans1=1e8,k,x,t,flag;
int p[25],a[25];
struct node{
	int d,vis;
}b[100010];

bool cmp(node x,node y){
	return x.vis<=y.vis;
}

int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++) scanf("%d",&p[i]);
	scanf("%d",&x);
	for(int i=1;i<=4;i++) scanf("%d",&b[i].d);
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		flag=0;
		scanf("%d",&a[i]);
		for(int j=1;j<=4;j++){
			if(a[i]==b[j].d){
				b[j].vis++;
				flag=1;
				continue;
			}
		}
		if(flag==1) continue;
		ans2+=p[a[i]];
	}
	sort(b+1,b+5,cmp);
	int tmp=0;
	for(int i=0;i<=b[4].vis;i++){
		tmp=i*x;
		for(int j=1;j<=4;j++)
			if(b[j].vis-i>0) tmp+=(b[j].vis-i)*p[b[j].d];
		ans1=min(ans1,tmp);
	}
	int ans=ans1+ans2;
	printf("%d",ans);
	return 0;
}
