#include <bits/stdc++.h>
using namespace std;
int a[100005],b[100005],c;
int n,m,o,l;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
cin>>n>>m;
for(int i=1;i<=n;i++){
	for(int j=1;j<=m;j++){
		cin>>c;
		if(c==0)o++;
	}
}	
	for(int i=1;i<=n;i++){
	for(int j=1;j<=m;j++){
		cin>>c;
		if(c==0)l++;
	}
}	
if(l==0||o==0)cout<<-1;
	return 0;
}
