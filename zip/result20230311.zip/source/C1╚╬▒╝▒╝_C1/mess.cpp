#include <bits/stdc++.h>
using namespace std;
int k,cai[100005],tc[100005],cj,hy[10005],a[10005],t,o,sum,ans,mx;
vector<int>cf;
int main() {
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1; i<=k; i++)cin>>cai[i];
	cin>>cj;
	for(int i=1; i<=4; i++) {
		cin>>o;
		tc[o]++;
	}
	cin>>t;
	for(int i=1; i<=t; i++) {
		cin>>hy[i];
		sum+=cai[hy[i]];
		if(tc[hy[i]]>=1)
			cf.push_back(hy[i]),tc[hy[i]]=-1;
		a[hy[i]]++;
	}
	ans=sum;
	for(int i=0; i<cf.size(); i++)mx=max(a[cf[i]],mx);
	for(int i=1; i<=mx; i++) {
		for(int j=0; j<cf.size(); j++)
			if(a[cf[j]]>0) 
				a[cf[j]]--,	sum-=cai[cf[j]];
		sum+=cj,ans=min(ans,sum);		
}
	cout<<ans;
	return 0;
}
