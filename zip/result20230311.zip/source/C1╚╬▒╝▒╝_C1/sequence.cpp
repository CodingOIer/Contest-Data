#include <bits/stdc++.h>
using namespace std;
double n,k,sum,a[1000005],mx;
int ri,lf=1;
int main(){
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i<=k)sum+=a[i];
	}
	mx=sum;
	int f=ri=k;
	for(int i=k+1;i<=n;i++){
		sum+=a[i]-a[i-f];
		if(sum>mx)
			mx=sum,ri=i,lf=i-f;
	}
	while(0==0){
		if(a[lf]<sum/k&&k-1>=f&&lf+1<=n)sum-=a[lf],k--,lf++;
		if(a[ri]<sum/k&&k-1>=f&&ri-1>=1)sum-=a[ri],k--,ri--;
		if(a[lf-1]>=sum/k&&a[ri+1]<sum/k&&lf-1>=1)sum+=a[lf-1],k++,lf--;
		if(a[ri+1]>=sum/k&&a[lf-1]<sum/k&&ri+1<=n)sum+=a[ri+1],k++,ri++;
		if(a[ri+1]>=sum/k&&a[lf-1]>=sum/k){
			if(a[ri+1]>a[lf-1]&&ri+1<=n)sum+=a[ri+1],k++,ri++;
			else if(lf-1>=1)sum+=a[lf-1],k++,lf--;
		}
		if(a[ri+1]<sum/k&&a[lf-1]<sum/k)break;
	}
	printf("%.6lf",sum/k);
	return 0;
}
