#include <bits/stdc++.h>
using namespace std;
int n,t,a[100005],b[100005],mq,sc,j,cj1,cj2,zh;
vector<int>cc;
int main() {
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1; i<=n; i++) {
		cin>>b[i];
		a[b[i]]=i;
		if(b[i]==n)zh=i;
	}
	mq=zh;
	if(n==1||n==0){
		cout<<1;
		return 0;
	}
	for(int i=1; i<=t; i++) {
		if(mq!=a[i]) {
			if(a[i]>mq)sc+=a[i]-mq;
			else sc+=n-mq+a[i];
			mq=a[i];
			cc.push_back(sc);	
		}
		if(i>n) {
			if(t%n!=0)
			cc[n-1]+=(cc[cc.size()-1])*(t/n-1)+cc[t%n-1];
			else cc[n-1]+=(cc[cc.size()-1])*(t/n-1);
			break;
		}
	}
	if(n>=2) {
		mq=zh;
		if(a[2]>mq)cj1=a[2]-mq;
		else cj1=n-mq+a[2];
		mq=1;
		if(a[2]>1)cj2=a[2]-mq;
		else cj2=n-mq+a[2];
	}
	if(t>=n)
		cout<<cc[n-1]+(cj2-cj1);
	else
		cout<<cc[t-1]+(cj2-cj1);
	return 0;
}
