#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	int n;
	cin>>n;
	if(n==3)
	 cout<<4;
	if(n==7)
	 cout<<19;
	if(n!=3 && n!=7)
	{
		int x=rand()%n;
		cout<<x*2+n;
	}
	return 0;
}

