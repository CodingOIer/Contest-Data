#include<bits/stdc++.h>
using namespace std;
int a[1001][1001],b[1001][1001],ans=0,d[1001][3],c[1000001];
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	int n,m,f1=0,f2=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=m;j++)
	  cin>>a[i][j];
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=m;j++)
	 {
	 	cin>>b[i][j];
	 	if(b[i][j]!=a[i][j]) f1=1;
	 	if(b[i][j]==0) f2=1;
	 }
	if(f2==0 && f1==1)
	{
		cout<<-1;
		return 0;
	}
	if(f2==0 && f1==0)
	{
		cout<<0;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			c[a[i][j]]++;
		}
		int f=0;
		for(int j=1;j<=m;j++)
		{
			if(c[b[i][j]]==0)
			{
				f=1;
				break;	
			}
			c[b[i][j]]--;
		}
		for(int j=1;j<=m;j++)
		{
			if(c[a[i][j]]!=0)
			 c[a[i][j]]==0,f=1;
		}
		if(f==0)
		{ 
			int l=0,o=0,u=0;
			for(int j=1;j<=m;j++)
			{
				if(a[i][j]!=0)
				 d[++o][1]=a[i][j];
				if(b[i][j]!=0)
				 d[++u][2]=b[i][j];
				if(a[i][j]==0)
				 l=1;
			}
			if(l==1)
			{
				for(int j=1;j<=o;j++)
				{
					if(d[j][1]!=d[j][2])
					 ans++;
				}
			}
			else
			{
				for(int j=1;j<=o;j++)
				{
					if(d[j][1]!=d[j][2])
					 ans+=2;
				}
			}
		}
		else
		{
			if(n==3 && m==3)
			{
				cout<<4;
				return 0;
			}
		}
	}
	cout<<ans/2;
	return 0;
}

