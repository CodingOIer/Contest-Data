#include<bits/stdc++.h>
using namespace std;
int n,x,b[5],a[21],d[21],k,c[21],ans2=0; 
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>x;
	for(int i=1;i<=4;i++)
	{
		cin>>b[i];
	}
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>c[i];
		d[c[i]]++;
	}
	while(1)
	{
		int f=0,ans=0,ans1=0;
		for(int i=1;i<=4;i++)
		{
			if(d[b[i]]!=0)
			{
				if(f==0)
				 ans+=x;
				f=1;
				ans1+=a[b[i]];
			} 
		}
		if(ans<ans1)
		{
		  ans2+=x;
		  for(int i=1;i<=4;i++)
		  {
		   	if(d[b[i]]!=0)
			 {
				d[b[i]]--;
			 }  
		  }			
		}
		else
		{
		  for(int i=1;i<=4;i++)
		  {
		   	if(d[b[i]]!=0)
			 {
				d[b[i]]--;
				ans2+=a[b[i]];
			 }  
		  }
		}
		if(f==0)
		 break;
	}
	for(int i=1;i<=k;i++)
	{
		if(d[c[i]]!=0)
		{
			ans2=ans2+a[c[i]];
		}
	}
	cout<<ans2;
	return 0;
}
