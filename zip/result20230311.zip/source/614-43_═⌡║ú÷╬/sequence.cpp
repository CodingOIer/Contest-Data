#include<bits/stdc++.h>
using namespace std;
int a[300010];
int b;
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	double ans=0;
	for(int i=1;i<=n-k+1;i++)
	{
		int o=k;
		b=0;
		for(int j=i;j<=i+k-1;j++)
		{
			b+=a[j];
		}
		for(int j=i+k;;j++)
		{
			if(a[j]>=a[j-1] && a[j]!=0 && a[j-1]!=0)
			{
				o++; 
				b+=a[j];
			}
			else
			{
				break;	
			}
		}
		double s=(double)b/o;
		if(s>=ans)
		{
		 ans=s;	
		}
	}
	printf("%f",ans);
	return 0;
}
