#include<bits/stdc++.h>
using namespace std;
long long n,a[3][150001],b[3][150001],ans=1e9;
int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	scanf("%ld",&n);
	for(long long i=0;i<3;i++) for(long long j=1;j<=n;j++) cin>>a[i][j];
	for(long long x=0;x<3;x++)
	{
		b[0][1]=a[x][1];
		for(long long i=2;i<=n;i++) b[0][i]=b[0][i-1]+a[x][i];
		for(long long y=0;y<3;y++)
		{
			if(x==y) continue;
			b[1][1]=b[0][1];
			for(long long i=2;i<=n;i++) b[1][i]=min(b[1][i-1],b[0][i-1])+a[y][i];
			for(long long z=0;z<3;z++)
			{
				if(z==x||z==y) continue;
				b[2][2]=b[1][2];
				for(long long i=3;i<=n;i++) b[2][i]=min(b[2][i-1],b[1][i-1])+a[z][i];
				ans=min(ans,b[2][n]);
			}
		}
	}
	printf("%ld",ans);
	return 0;
}
