#include<bits/stdc++.h>
using namespace std;
long long n,t,a[100001],b[100001],q,ans=0,k=1;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	scanf("%ld%ld",&n,&t);
	for(long long i=1;i<=n;i++)
	{
		scanf("%ld",&a[i]);
		b[a[i]]=i;
	}
	for(long long i=1;i<=t;i++)
	{
		if(i>n)
		{
			i=1;
			t-=n;
		}
		if(k>b[i]) ans=ans+n-k+b[i];
		else ans=ans+b[i]-k;
		k=b[i];
	}
	printf("%ld",ans);
	return 0;
}
