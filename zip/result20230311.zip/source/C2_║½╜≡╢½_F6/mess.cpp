#include<bits/stdc++.h>
using namespace std;
long long k,x,t,a[21],b[5],c[21],d[21],p=0,ans=0;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	scanf("%ld",&k);
	for(long long i=1;i<=k;i++) scanf("%ld",&a[i]);
	scanf("%ld",&x);
	for(long long i=1;i<=4;i++) scanf("%ld",&b[i]);
	scanf("%ld",&t);
	for(long long i=1;i<=t;i++) 
	{
		scanf("%ld",&c[i]);
		ans+=a[c[i]];
	}
	for(long long i=1;i<=20;i++)
	{
		p=x*i;
		for(long long j=1;j<=4;j++) d[b[j]]=i;
		for(long long j=1;j<=t;j++) 
		{
			if(d[c[j]]==0)
			{
				p+=a[c[j]];
			}
			else d[c[j]]--;
		}
		ans=min(ans,p);
	}
	printf("%ld",ans);
	return 0;
}
