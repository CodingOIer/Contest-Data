#include<bits/stdc++.h>
using namespace std;
long long n,k,a;
double ans=0,b[300001];
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	scanf("%ld%ld",&n,&k);
	for(long long i=1;i<=n;i++)
	{
		scanf("%ld",&a);
		b[i]=b[i-1]+a;
	}
	for(long long i=1;i<=n-k+1;i++) for(long long j=i+k-1;j<=n;j++) ans=max(ans,(b[j]-b[i-1])/(j-i+1));
	printf("%.6lf",ans);
	return 0;
}
