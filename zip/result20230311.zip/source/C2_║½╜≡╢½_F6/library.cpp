#include<bits/stdc++.h>
using namespace std;
bool l=false;
struct node
{
	long long x,y;
}a[1001];
long long n,b,c,q,ans=0,d[1001],m;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	scanf("%ld%ld",&n,&m);
	for(long long i=1;i<=n;i++) 
	{
		q=0;
		for(long long j=1;j<=m;j++)
		{
			scanf("%ld",&c);
			a[c].x=i;
			a[c].y=++q;
			if(c==0)
			{
				l=true;
				d[i]++;
			}
		}
	}
	for(long long i=1;i<=n;i++) 
	{
		q=0;
		for(long long j=1;j<=m;j++)
		{
			scanf("%ld",&b);
			if(a[b].x!=i) ans++;
			if(a[b].y>++q) ans++;
		}
	}
	if(l==false)
	{
		cout<<-1;
		return 0;
	}
	cout<<ans;
	return 0;
}
