#include <bits/stdc++.h>
using namespace std;
long long n,a[5][150005],s,c,x[150005],sb[3],t;
int main()
{
	//freopen("acm.in","r",stdin);
	//freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=3;i++)
	{
	    for(int j=1;j<=n;j++) 
	    {
		    cin>>a[i][j];
		    x[i]+=a[i][j];
	    }
	    if(i==1) s=x[i];
	    else if(x[i]<s) s=x[i],c=i;
	}
	s=s-a[c][n]-a[c][n-1];
	for(int i=1;i<=3;i++)
	{
		if(i!=c) sb[t]=i,t++;
	}
	s+=min(a[sb[1]][n]+a[sb[2]][n-1],a[sb[1]][n-1]+a[sb[2]][n]);
	cout<<s;
}
