#include <bits/stdc++.h>
using namespace std;
int main()
{
	double a;
	cin>>a;
	printf("%.5lf",a);
}
