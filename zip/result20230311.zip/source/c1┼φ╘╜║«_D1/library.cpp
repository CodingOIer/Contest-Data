#include <bits/stdc++.h>
using namespace std;
int n,m,a[1005][1005],b[1005][1005],c=0;
int main()
{
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	cin>>a[i][j];
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>b[i][j];
		if(b[i][j]==0) c++;
	}
	if(c==0) cout<<-1;
}
