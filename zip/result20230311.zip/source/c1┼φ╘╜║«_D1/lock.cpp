#include <bits/stdc++.h>
using namespace std;
long long n,t,a[100005],s,j=1,b,x;
int main()
{
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++)
	{
		cin>>b;
		a[b]=i;
	}
	for(int i=1;i<=t;i++)
	{
		if(i>n) x=i-n;
		else x=i;
		s+=(a[x]-j+n)%n;
		j=a[x];
	}
	cout<<s;
}
