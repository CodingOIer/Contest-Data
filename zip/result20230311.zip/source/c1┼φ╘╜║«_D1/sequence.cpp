#include <bits/stdc++.h>
using namespace std;
int n,k,a[300005];
double c[300005];
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) 
	{
	    cin>>a[i];
	    if(i>=k)  c[i]=(double)(c[i-1]+a[i]-a[i-k]);
	    else c[i]=(double)(c[i-1]+a[i]);
	}
	for(int i=1;i<=n;i++) c[i]/=k;
	sort(c+k,c+n+1);
	printf("%.6lf",c[n]);
}
