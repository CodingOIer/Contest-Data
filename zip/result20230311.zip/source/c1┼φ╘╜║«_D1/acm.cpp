#include <bits/stdc++.h>
using namespace std;
int n,a[5][150005],s=0;
int main()
{
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=3;i++)
	    for(int j=1;j<=n;j++) 
		cin>>a[i][j];
	for(int i=1;i<=n;i++)
	{
		a[4][i]=min(min(a[1][i],a[2][i]),a[3][i]);
		s+=a[4][i];
	}
	cout<<s+1;
}
