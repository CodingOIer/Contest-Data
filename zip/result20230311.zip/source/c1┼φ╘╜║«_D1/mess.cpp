#include <bits/stdc++.h>
using namespace std;
int jg[30],tc[30],dc[30],c[30],s,b,k,x,t;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)cin>>jg[i];
	cin>>x;
	for(int i=1;i<=4;i++) {	cin>>b;tc[b]=1; }
	cin>>t;
	for(int i=1;i<=t;i++) 
	{
		cin>>dc[i];
		s+=jg[dc[i]];
		c[dc[i]]++;
    }
    while(s>x)
    {
    	int ss=s,cc=0,bj[30];
    	for(int i=1;i<=30;i++) bj[i]=0;
    	for(int i=1;i<=t;i++)
    	{
    		if(tc[dc[i]]==1&&c[dc[i]]>0&&bj[dc[i]]==0) 
			{
			    bj[dc[i]]=1;
				c[dc[i]]--;
				ss-=jg[dc[i]];
				cc++;
			} 
		}
		if(cc==0) break;
		if(ss+x<s) s=ss+x;
		else break;
	}
	cout<<s;
}
