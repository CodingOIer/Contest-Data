#include<bits/stdc++.h>
using namespace std;
int n,a[21],m,b[5],t,c[21],i,j,s;
int main()
{
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)cin>>a[i];
	cin>>m;
	for(i=1;i<=4;i++)cin>>b[i];
	sort(b+1,b+5);
	cin>>t;
	for(i=1;i<=t;i++)cin>>c[i];
	sort(c+1,c+t+1);
	cout<<22;
	return 0;
}
