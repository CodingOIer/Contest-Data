#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
int main(){
	freopen("lock.in","r",stdin);
	freopen("lock.out","w",stdout);
	long long n,p=0,k,a[100001],lock[100001],ans=0,now=1,l=1;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		a[i]=i;
	}
	for(int i=1;i<=n;i++){
		cin>>lock[i];
	}
	for(int i=1;;i++){
		if(p==k){
			break;
		}
		if(a[now]!=lock[l]){
			ans+=1;
			now+=1;
		}
		else{
			l+=1;
			p+=1;
		}
		if(now>n){
			now==1;
		}
		if(l>n){
			l==1;
		}
	}
	cout<<ans+1;
}

