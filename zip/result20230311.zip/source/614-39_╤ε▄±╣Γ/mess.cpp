#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
int main(){
	freopen("mess.in","r",stdin);
	freopen("mess.out","w",stdout);
	long long n,m,k,a[21],b[21],c[21],ans=0,ton[21],mn=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m;
	for(int i=1;i<=4;i++){
		cin>>b[i];
	}
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>c[i];
		ans+=a[c[i]];
		ton[c[i]]++;
	}
	for(int i=1;i<=4;i++){
		ton[b[i]]--;
	}
	mn+=m;
	for(int i=1;i<=k;i++){
		if(ton[c[i]]>0){
			mn=mn+(a[c[i]]*ton[c[i]]);
			ton[c[i]]=0;
		}
	}
	cout<<min(ans,mn);
}
/*
7
10 6 8 9 4 5 3
14
1 2 3 4
5
1 3 4 6 7
*/
