#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
int n,k,kkk,kk=0;
double a[1000001];
double as,mx=-1,lunmx=-1;
struct tree{
    int l,r;
    long long pre,add;
}t[4*maxn+1];
void init(int p,int l,int r){
    t[p].l=l;t[p].r=r;
    if(l==r){
        t[p].pre=a[l];
        return;
    }
    int mid=l+r>>1;
    init(p*2,l,mid);
    init(p*2+1,mid+1,r);
    t[p].pre=t[p*2].pre+t[p*2+1].pre;
}
double ask(int p,int x,int y){
    if(x<=t[p].l&&y>=t[p].r){
		return t[p].pre;
	}
    int mid=t[p].l+t[p].r>>1;
    double ans=0;
    if(x<=mid){
		ans+=ask(p*2,x,y);
	}
    if(y>mid){
		ans+=ask(p*2+1,x,y);
	}
    return ans*1.000000;
}
int main(){
    freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	init(1,1,n);
	for(int j=0;j<=n;j++){
		for(int i=1;i<=n;i++){
		as=ask(1,i,i+k-1+j);
		if(as/(k+j)>mx/kkk){
			mx=as;
			kkk=k+j;
			}
		}
		if(mx/kkk>lunmx/kk){
			lunmx=mx;
			kk=kkk;
		}
		else{
			j=n+1;
		}
	}
	printf("%.6f",lunmx/kk);
}
	
