#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
struct kkk{
	int x,y;
}as[1001];
int n,m,a[1001][1001],b[1001][1001],ans,mx=-1,as1;
int main(){
	freopen("library.in","r",stdin);
	freopen("library.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			as1=a[i][j];
			if(as1>mx){
				mx=as1;
			}
			if(a[i][j]!=0){
				as[a[i][j]].x=i;
				as[a[i][j]].y=j;
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>b[i][j];
		}
	}
	for(int i=1;i<=mx;i++){
		if(b[as[i].x][as[i].y]==0){
			ans++;
		}
	}
	if(ans==0){
		cout<<-1;
	}
	else{
		cout<<ans;	
	}
}

