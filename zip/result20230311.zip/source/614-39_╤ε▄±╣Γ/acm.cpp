#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
int n,ans,a[1000001],b[1000001],c[1000001],ton[4];
int main(){
	freopen("acm.in","r",stdin);
	freopen("acm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	for(int i=1;i<=n;i++){
		if(ton[1]==0){
			ans+=a[i];
			ton[1]++;
		}
		else if(ton[2]==0) {
			ans+=b[i];
			ton[2]++;
		}
		else if(ton[3]==0) {
			ans+=c[i];
			ton[3]++;
		}
		else{
			int mn;
			ans+=min(a[i],min(b[i],c[i]));
		}
	}
	cout<<ans;
}

