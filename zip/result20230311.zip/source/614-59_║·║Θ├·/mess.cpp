#include<bits/stdc++.h>
using namespace std;
int k,x,t,a,b,c,d,as=0,bs=0,cs=0,ds=0,kg[25],tg[25],ans=0;
int main() {
	freopen("mess.in", "r", stdin);
	freopen("mess.out", "w", stdout);
	scanf("%d",&k);
	for(int i=1; i<=k; i++) {
		scanf("%d",&kg[i]);
	}
	scanf("%d",&x);
	scanf("%d%d%d%d",&a,&b,&c,&d);
	scanf("%d",&t);
	for(int i=1; i<=t; i++) {
		scanf("%d",&tg[i]);
		if(tg[i]==a) {
			as++;
			continue;
		}
		if(tg[i]==b) {
			bs++;
			continue;
		}
		if(tg[i]==c) {
			cs++;
			continue;
		}
		if(tg[i]==d) {
			ds++;
			continue;
		}
		ans+=kg[tg[i]];
	}
	while(1) {
		int j=0;
		if(as<=0)	j+=kg[tg[a]];
		if(bs<=0)	j+=kg[tg[b]];
		if(cs<=0)	j+=kg[tg[c]];
		if(ds<=0)	j+=kg[tg[d]];
		if(x<=kg[tg[a]]+kg[tg[b]]+kg[tg[c]]+kg[tg[d]]-j) {
			ans+=x;
		} else {
			ans=ans+kg[tg[a]]+kg[tg[b]]+kg[tg[c]]+kg[tg[d]]-j;
		}
		as--;
		bs--;
		cs--;
		ds--;
		if(as<=0 && bs<=0 && cs<=0 && ds<=0) {
			break;
		}
	}
	printf("%d",ans);
	return 0;
}
