#include<bits/stdc++.h>
using namespace std;
long long n,k,k1;
double max1=0,cnt;
long long a[300005];
int main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	scanf("%lld%lld",&n,&k);
	k1=k;
	for(int i=1; i<=n; i++) {
		scanf("%lld",&a[i]);
	}
	for(int i=1; i<=n; i++) {
		cnt=0;
		for(int j=i;j<i+k;j++){
			cnt+=a[j];
		}
		if(cnt/k<a[i]){
			cnt+=a[i];
			k1++;
		}
		if(cnt>=max1){
			max1=cnt;
			k=k1;
		}
	}
	printf("%.6f",max1/k);
	return 0;
}
