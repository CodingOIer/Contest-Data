#include<bits/stdc++.h>
using namespace std;
long long n,t,m=1,ds=0,dw=0,ans=0;
long long que[100005];
int main() {
	freopen("lock.in", "r", stdin);
	freopen("lock.out", "w", stdout);
	scanf("%lld%lld",&n,&t);
	for(int i=1; i<=n; i++) {
		scanf("%lld",&que[ds++]);
	}
	for(int i=1; i<=t; i++) {
		if(m==n+1) {
			m=1;
		}
		while(m!=que[dw]) {
			ans++;
			que[ds]=que[dw];
			dw++;
			ds++;
		}
		m++;
	}
	printf("%lld",ans);
	return 0;
}
