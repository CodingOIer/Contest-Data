#include<bits/stdc++.h>
using namespace std;
long long n,m;
long long a[1005][1005],b[1005][1005];
int main(){
	freopen("library.in", "r", stdin);
	freopen("library.out", "w", stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&b[i][j]);
		}
	}
	printf("-1");
	return 0;
}

