#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 1005;
int a[N][N],b[N][N];
bool c1[N],c2[N];
int s1[N],s2[N];
int n,m;

bool f[N][N],vis[N][N];
bool dfs(int x,int y){
    if(s1[x]>1||s2[y]>1)
        return false;
    if(vis[x][y])
        return f[x][y];
    vis[x][y] = true;
    if(!a[x][y])
        f[x][y] = true;
    for(int k=1;k<=n;k++)
        if(k!=x)
            f[x][y] |= dfs(k,y);
    for(int k=1;k<=m;k++)
        if(k!=y)
            f[x][y] |= dfs(x,k);
    if(f[x][y])
        c1[x] = c2[y] = true;
    return f[x][y];
}

int main(){
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    int t = in;
    while(t--){
        n = in,m = in;
        for(int k=1;k<=n;k++){
            s1[k] = 0;
            c1[k] = false;
        }
        for(int k=1;k<=m;k++){
            s2[k] = 0;
            c2[k] = false;
        }
        for(int k=1;k<=n;k++)
            for(int j=1;j<=m;j++)
                f[k][j] = vis[k][j] = false;
        string c;
        for(int k=1;k<=n;k++){
            cin >> c;
            for(int j=1;j<=m;j++)
                a[k][j] = c[j-1]^48;
        }
        for(int k=1;k<=n;k++){
            cin >> c;
            for(int j=1;j<=m;j++)
                b[k][j] = c[j-1]^48;
        }
        for(int k=1;k<=n;k++)
            for(int j=1;j<=m;j++){
                s1[k] += b[k][j];
                s2[j] += b[k][j];
            }
        for(int k=1;k<=n;k++)
            for(int j=1;j<=m;j++)
                if(b[k][j])
                    dfs(k,j);
        auto check = []{
            for(int k=1;k<=n;k++)
                for(int j=1;j<=m;j++)
                    if(!b[k][j]&&a[k][j]&&!c1[k]&&!c2[j])
                        return false;
            return true;
        };
        puts(check()?"Yes":"No");
    }
    return 0;
}