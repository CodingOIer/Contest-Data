#include <iostream>
#include <queue>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 100005;
pair<int,int> a[N];
int b[N];
int n,m,K;

class set_pro{
    private:
        priority_queue<int> q;
        int s;
    public:
        void insert(int x){
            if((int)q.size()<K/2){
                s += x;
                q.push(x);
            }
            else if(x<q.top()){
                s -= q.top();
                q.pop();
                s += x;
                q.push(x);
            }
        }
        int query(){
            if((int)q.size()<K/2)
                return 1e18;
            return s;
        }
        void clear(){
            s = 0;
            q = priority_queue<int>();
        }
}q;

signed main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    n = in,m = in,K = in;
    for(int k=1;k<=n;k++)
        a[k].second = in,a[k].first = in;
    sort(a+1,a+1+n);
    for(int k=1;k<=n;k++){
        b[k] = q.query()+a[k].second;
        q.insert(a[k].second);
    }
    q.clear();
    for(int k=n;k;k--){
        b[k] += q.query();
        q.insert(a[k].second);
    }
    for(int k=n;k;k--)
        if(b[k]<=m){
            out(a[k].first);
            return 0;
        }
    puts("-1");
    return 0;
}