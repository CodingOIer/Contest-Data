#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int t[10],t1[10],nl,nr;
string l,r;

bool checkl(string l){
    int nl = l.size();
    memcpy(t1,t,sizeof(t));
    for(int k=0;k<nl;k++){
        for(int j=(l[k]^48)+1;j<=9;j++)
            if(t1[j])
                return true;
        if(t1[l[k]^48])
            t1[l[k]^48]--;
        else
            return false;
    }
    return true;
}

bool checkr(string r){
    int nr = r.size();
    memcpy(t1,t,sizeof(t));
    for(int k=0;k<nr;k++){
        for(int j=0;j<=(r[k]^48)-1;j++)
            if(t1[j]) return true;
        if(t1[r[k]^48])
            t1[r[k]^48]--;
        else
            return false;
    }
    return true;
}

bool check(string s){
    memset(t,0,sizeof(t));
    t[0] = nr-s.size();
    for(int k=0;k<(int)s.size();k++)
        t[s[k]^48]++;
    if(nl!=nr){
        if((int)s.size()==nl)
            return checkl(l)|checkr(r);
        return checkr(r);
    }
    else{
        for(int k=0;k<nl;k++){
            if(l[k]==r[k]){
                if(!t[l[k]^48])
                    return false;
                else
                    t[l[k]^48]--;
            }
            else{
                for(int j=(l[k]^48)+1;j<=(r[k]^48)-1;j++)
                    if(t[j])
                        return true;
                if(t[l[k]^48]){
                    t[l[k]^48]--;
                    if((k==nl-1||checkl(l.substr(k+1,(nl-1)-(k+1)+1))))
                        return true;
                    t[l[k]^48]++;
                }
                if(t[r[k]^48]){
                    t[r[k]^48]--;
                    if((k==nl-1||checkr(r.substr(k+1,(nr-1)-(k+1)+1))))
                        return true;
                    t[r[k]^48]++;
                }
                return false;
            }
        }
    }
    return true;
}

int ans;
void dfs(string s,int p){
    if(s.size()&&check(s))
        ans++;
    if((int)s.size()==nr)
        return;
    for(int k=p;k<10;k++)
        dfs(s+char(k^48),k);
}

int main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    cin >> l >> r;
    nl = l.size(),nr = r.size();
    dfs("",1);
    cout << ans;
    return 0;
}