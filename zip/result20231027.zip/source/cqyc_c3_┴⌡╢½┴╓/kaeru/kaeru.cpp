#include <iostream>
#include <vector>
#include <cmath>
#include <array>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 500005,n = 500000;
int m,q,type;

namespace sub1{
    array<int,4> tq[N];
    vector<int> g1[N],g2[N];
    int s[N],ans[N];

    class inquiry{
        public:
            int l,r,block,id;

            bool operator < (const inquiry &tmp)const{
                if(block!=tmp.block)
                    return l<tmp.l;
                if(block&1)
                    return r>tmp.r;
                return r<tmp.r;
            }
    }qus[N];

    int tr[N];
    void insert(int x,int c){
        for(;x<=n;x+=x&-x)
            tr[x] += c;
    }
    int query(int x){
        int ans = 0;
        for(;x;x&=x-1)
            ans += tr[x];
        return ans;
    }

    int cnt[N];
    void add1(int x){
        for(int y:g1[x]){
            if(!cnt[y])
                insert(y,1);
            cnt[y]++;
        }
    }

    void del1(int x){
        for(int y:g1[x]){
            cnt[y]--;
            if(!cnt[y])
                insert(y,-1);
        }
    }

    void add2(int x){
        for(int y:g2[x]){
            if(!cnt[y])
                insert(y,1);
            cnt[y]++;
        }
    }

    void del2(int x){
        for(int y:g2[x]){
            cnt[y]--;
            if(!cnt[y])
                insert(y,-1);
        }
    }

    int main(){
        for(int k=1;k<=m;k++){
            int a = in,b = in;
            g1[a].push_back(b);
            g2[b].push_back(a);
        }
        for(int k=1;k<=n;k++)
            s[k] = s[k-1]+g1[k].size();
        int block = ceil(m/sqrt(q));
        for(int k=0;k<q;k++){
            int l1 = in,r1 = in,l2 = in,r2 = in;
            tq[k] = {l1,r1,l2,r2};
            qus[k] = {s[l1],s[r1],s[l1]/block,k};
        }
        sort(qus,qus+q);
        int L = 1,R = 0;
        for(int k=0;k<q;k++){
            int j = qus[k].id,l = tq[j][0],r = tq[j][1];
            while(R<r)
                add1(++R);
            while(L<l)
                del1(L++);
            while(L>l)
                add1(--L);
            while(R>r)
                del1(R--);
            ans[j] = query(tq[j][3])-query(tq[j][2]-1);
        }


        memset(tr,0,sizeof(tr));
        memset(cnt,0,sizeof(cnt));
        for(int k=1;k<=n;k++)
            s[k] = s[k-1]+g2[k].size();
        for(int k=0;k<q;k++){
            int l2 = tq[k][2],r2 = tq[k][3];
            qus[k] = {s[l2],s[r2],s[l2]/block,k};
        }
        sort(qus,qus+q);
        L = 1,R = 0;
        for(int k=0;k<q;k++){
            int j = qus[k].id,l = tq[j][2],r = tq[j][3];
            while(R<r)
                add2(++R);
            while(L<l)
                del2(L++);
            while(L>l)
                add2(--L);
            while(R>r)
                del2(R--);
            ans[j] += query(tq[j][1])-query(tq[j][0]-1);
        }

        for(int k=0;k<q;k++)
            out(ans[k],'\n');
        return 0;
    }
}

namespace sub2{
    vector<int> g[N];
    vector<pair<int,int>> e;
    
    bool vis[2*N];
    int cnt;
    void add(int x){
        if(!vis[x])
            cnt++;
        vis[x] = true;
    }
    void clear(){
        for(auto x:e)
            vis[x.first] = vis[n+x.second] = false;
        cnt = 0;
    }

    int main(){
        int lans = 0;
        for(int k=1;k<=m;k++){
            int a = in,b = in;
            g[a].push_back(b);
            e.emplace_back(a,b);
        }

        for(int k=1;k<=n;k++)
            sort(g[k].begin(),g[k].end());
        while(q--){
            int l1 = lans^(int)in,r1 = lans^(int)in,l2 = lans^(int)in,r2 = lans^(int)in;
            if(l1==r1&&m>2000){
                int ans = prev(upper_bound(g[l1].begin(),g[l1].end(),r2))-lower_bound(g[l1].begin(),g[l1].end(),l2)+1;
                if(ans) 
                    ans++;
                out(lans=ans,'\n');
                continue;
            }
            for(auto x:e)
                if(x.first>=l1&&x.first<=r1&&x.second>=l2&&x.second<=r2){
                    add(x.first);
                    add(x.second+n);
                }
            out(lans=cnt,'\n');
            clear();
        }
        return 0;
    }
}

int main(){
    freopen("kaeru.in","r",stdin);
    freopen("kaeru.out","w",stdout);
    m = in,q = in,type = in;
    if(!type)
        return sub1::main();
    return sub2::main();
}