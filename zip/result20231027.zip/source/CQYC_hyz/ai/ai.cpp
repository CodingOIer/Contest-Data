#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e5 + 10;

struct node {
    int v, w;
    bool operator < (const node &p) const { return v < p.v; }
} a[N];

int n, m, k;

vector<int> p;

bool check(int x) {
    int cnt = 0;
    for(int i = 1; i <= k; i++) {
        if(a[i].w >= x) cnt++;
        else p.push_back(a[i].v);
    }

    int rest = m;

    for(int i = k + 1; i <= n; i++) if(a[i].w >= x and !p.empty()) {
        int v = a[i].v - p.back(); if(v > rest) break;
        rest -= v, cnt++, p.pop_back();
    }

    return cnt > k / 2;
}

bool edmer;
signed main() {
	freopen("ai.in", "r", stdin);
	freopen("ai.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), k = read();
    for(int i = 1; i <= n; i++) a[i] = { read(), read() };

    sort(a + 1, a + n + 1);

    for(int i = 1; i <= k; i++) m -= a[i].v;

    if(m < 0) puts("-1");

    int l = 1, r = 2e9, res = 0;

    while(l <= r) {
        int mid = (l + r) >> 1;
        if(check(mid)) res = mid, l = mid + 1;
        else r = mid - 1;
    }

    write(res);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 