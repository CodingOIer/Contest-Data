#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1010;

int n, m, cnt, tot;
int c1[N], c2[N];

bool v1[N], v2[N];

char A[N][N], B[N][N];

void solve() {
    n = read(), m = read(), cnt = tot = 0;
    for(int i = 1; i <= m; i++) c2[i] = v2[i] = 0;
    for(int i = 1; i <= n; i++) scanf("%s", A[i] + 1), c1[i] = v1[i] = 0;
    for(int i = 1; i <= n; i++) scanf("%s", B[i] + 1);

    bool flag = 0;

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++) 
            if(B[i][j] == '1') c1[i]++, c2[j]++;

    for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) {
        if(A[i][j] == '0' and B[i][j] == '1') {
            if(c1[i] != 1 or c2[j] != 1) return puts("No"), void();
            flag = v1[i] = v2[j] = 1;
        }
        else if(B[i][j] == '1' and c1[i] == 1 and c2[j] == 1) v1[i] = v2[j] = 1, cnt++;
    }

    for(int i = 1; i <= n; i++) if(!c1[i]) v1[i] = 1;
    for(int i = 1; i <= m; i++) if(!c2[i]) v2[i] = 1;

    for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++)
        if(A[i][j] == '0' and v1[i] and v2[j]) tot++;

    if(cnt and tot) flag = 1;
    
    for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++)
        if(A[i][j] == '1' and B[i][j] == '0' and (!flag or (!v1[i] and !v2[j]))) return puts("No"), void();
    
    puts("Yes");
}

bool edmer;
signed main() {
	freopen("yue.in", "r", stdin);
	freopen("yue.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 