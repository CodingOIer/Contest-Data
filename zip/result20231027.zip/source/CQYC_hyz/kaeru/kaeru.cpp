#include <bits/stdc++.h>
#define mid ((l + r) >> 1)
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 5e4 + 10;

struct edge {
    int u, v;
} e[N];

struct tree {
    int ls, rs, x;
} t[N * 1000];

int m, q, type, lastans, cnt, cnt1, cnt2;
int rt1[N], rt2[N], lat1[N], lat2[N], b1[N], b2[N];

vector<int> e1[N], e2[N];

int New(int x) { t[++cnt] = t[x]; return cnt; }

void add(int l, int r, int x, int k, int &lr) {
    lr = New(lr), t[lr].x += k; if(l == r) return;
    mid >= x ? add(l, mid, x, k, t[lr].ls) : add(mid + 1, r, x, k, t[lr].rs);
}

void modify(int l, int r, int x, int y, int k, int &lr) {
    lr = New(lr), add(1, m, y, k, t[lr].x); if(l == r) return;
    mid >= x ? modify(l, mid, x, y, k, t[lr].ls) : modify(mid + 1, r, x, y, k, t[lr].rs);
}

int ask(int l, int r, int L, int R, int &lr) {
    if(!lr) return 0; if(l >= L and r <= R) return t[lr].x;
    if(mid >= L and mid < R) return ask(l, mid, L, R, t[lr].ls) + ask(mid + 1, r, L, R, t[lr].rs);
    return mid >= L ? ask(l, mid, L, R, t[lr].ls) : ask(mid + 1, r, L, R, t[lr].rs);
}

int query(int l, int r, int L1, int R1, int L2, int R2, int lr) {
    if(!lr) return 0;
    if(l >= L1 and r <= R1) return ask(1, m, L2, R2, t[lr].x);
    int res = 0;
    if(mid >= L1) res = query(l, mid, L1, R1, L2, R2, t[lr].ls);
    if(mid < R1) res += query(mid + 1, r, L1, R1, L2, R2, t[lr].rs);
    return res;
}

bool edmer;
signed main() {
	freopen("kaeru.in", "r", stdin);
	freopen("kaeru.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    m = read(), q = read(), type = read();
    for(int i = 1; i <= m; i++) {
        int u = read(), v = read();
        e[i] = { u, v }, b1[++cnt1] = u, b2[++cnt2] = v;
    }

    b1[++cnt1] = b2[++cnt2] = 1, b1[++cnt1] = b2[++cnt2] = 5e5;
    sort(b1 + 1, b1 + cnt1 + 1), cnt1 = unique(b1 + 1, b1 + cnt1 + 1) - b1 - 1;
    sort(b2 + 1, b2 + cnt2 + 1), cnt2 = unique(b2 + 1, b2 + cnt2 + 1) - b2 - 1;

    for(int i = 1; i <= m; i++) {
        int u = e[i].u, v = e[i].v;
        u = lower_bound(b1 + 1, b1 + cnt1 + 1, u) - b1;
        v = lower_bound(b2 + 1, b2 + cnt2 + 1, v) - b2;
        e1[u].push_back(v), e2[v].push_back(u);
    }

    m = max(cnt1, cnt2);

    for(int i = 1; i <= cnt2; i++) {
        rt2[i] = rt2[i - 1];
        for(int v : e2[i]) {
            if(lat1[v]) modify(1, m, lat1[v], v, -1, rt2[i]);
            lat1[v] = i, modify(1, m, i, v, 1, rt2[i]);
        }
    }

    for(int i = 1; i <= cnt1; i++) {
        rt1[i] = rt1[i - 1];
        for(int v : e1[i]) {
            if(lat2[v]) modify(1, m, lat2[v], v, - 1, rt1[i]);
            lat2[v] = i, modify(1, m, i, v, 1, rt1[i]);
        }
    }

    for(int i = 1; i <= q; i++) {
        int a = read() ^ lastans, b = read() ^ lastans;
        int c = read() ^ lastans, d = read() ^ lastans;
        a = lower_bound(b1 + 1, b1 + cnt1 + 1, a) - b1;
        b = upper_bound(b1 + 1, b1 + cnt1 + 1, b) - b1 - 1;
        c = lower_bound(b2 + 1, b2 + cnt2 + 1, c) - b2;
        d = upper_bound(b2 + 1, b2 + cnt2 + 1, d) - b2 - 1;
        int ans = query(1, m, c, m, a, b, rt2[d]);
        ans += query(1, m, a, m, c, d, rt1[b]);
        lastans = ans * type, write(ans), putchar('\n');
    }

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 