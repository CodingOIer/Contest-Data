#include <bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

int l, r, ans;
int fac[N], inv[N], L[N], R[N], cnt[10];

int C(int x, int y) { return (y > x or y < 0 or x < 0) ? 0 : 1ll * fac[x] * inv[y] % mod * inv[x - y] % mod; }

void init() {
    fac[0] = 1;
    for(int i = 1; i < N; i++) fac[i] = 1ll * fac[i - 1] * i % mod;
    inv[N - 1] = q_pow(fac[N - 1], mod - 2);
    for(int i = N - 1; i; i--) inv[i - 1] = 1ll * inv[i] * i % mod;
}

vector<int> f, g;

bool check(int x) {
    cnt[0] = 18;
    for(int i = 1; i < 10; i++) cnt[i] = 0;
    while(x) cnt[0]--, cnt[x % 10]++, x /= 10;
    
    int flag = 0;

    for(int i = 1; i <= 18; i++) {
        if(flag == 1) {
            for(int j = 0; j < R[i]; j++) if(cnt[j]) return 1;
            if(!cnt[R[i]]) return 0; cnt[R[i]]--;
        }
        else if(flag == 2) {
            for(int j = L[i] + 1; j < 10; j++) if(cnt[j]) return 1;
            if(!cnt[L[i]]) return 0; cnt[L[i]]--;
        }
        else {
            if(L[i] == R[i] and !cnt[L[i]]) return 0;
            if(L[i] == R[i]) cnt[L[i]]--;
            else {
                int p = 0; flag = 1;
                for(int j = L[i] + 1; j < R[i]; j++) if(cnt[j]) return 1;
                if(cnt[R[i]]) cnt[R[i]]--;
                else if(!cnt[L[i]]) return 0;
                else cnt[L[i]]--, flag = 2;
            }
        }
    }
    return 1;
}

bool edmer;
signed main() {
	freopen("homura.in", "r", stdin);
	freopen("homura.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    l = read(), r = read();

    for(int i = 18; i; i--) L[i] = l % 10, l /= 10, R[i] = r % 10, r /= 10;

    for(int i = 1; i < 10; i++) f.push_back(i), ans += check(i);

    for(int i = 2; i < 18; i++) {
        for(int x : f) for(int j = x % 10; j < 10; j++) 
            g.push_back(x * 10 + j), ans += check(g.back());
        swap(f, g), g.clear();
    }

    write(ans % mod);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 