#include<bits/stdc++.h>
using namespace std;
bool st;
int m,q,type,t1,t2,t3,t4,a[500005],b[500005],cnt1,cnt2,ans,c[500005];
struct ok{
    int x,y;
}A[50005];
bitset<500005> v1,v2;
bitset<50005> v[140005],V;
bool ed;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void AA(int k,int l,int r){
    if(l==r){
        c[l]=k;
        // cerr<<k<<" "<<l<<" "<<cnt1<<"\n";
        return;
    }
    int mid=(l+r)>>1;
    AA(k<<1,l,mid);AA((k<<1)^1,mid+1,r);
}
inline void build(int k,int l,int r){
    if(l==r) return;
    int mid=(l+r)>>1;
    build(k<<1,l,mid);build((k<<1)^1,mid+1,r);
    v[k]=v[k<<1]|v[(k<<1)^1];
}
inline bitset<50005> query(int k,int l,int r,int ll,int rr){
    if(ll>rr) return 0;
    if(ll<=l&&rr>=r) return v[k];
    int mid=(l+r)>>1;
    if(ll<=mid&&rr>mid) return query(k<<1,l,mid,ll,rr)|query((k<<1)^1,mid+1,r,ll,rr);
    else if(ll<=mid) return query(k<<1,l,mid,ll,rr);
    else if(rr>mid) return query((k<<1)^1,mid+1,r,ll,rr);
}
signed main(){
    freopen("kaeru.in","r",stdin);
    freopen("kaeru.out","w",stdout);
    // cerr<<(double)(&st-&ed)/1024.0/1024.0<<"MB\n";
    m=read(),q=read(),type=read();
    cnt1=cnt2=0;
    for(int i=1;i<=m;i++){
        A[i].x=t1=read(),A[i].y=t2=read();
        v1[t1]=1;v2[t2]=1;
    }
    for(int i=1;i<=500000;i++){
        if(v1[i]) a[++cnt1]=i;
        if(v2[i]) b[++cnt2]=i;
    }
    a[++cnt1]=500001;b[++cnt2]=500001;
    AA(1,1,cnt1);
    for(int i=1;i<=m;i++){
        int d1=lower_bound(a+1,a+1+cnt1,A[i].x)-a;
        int d2=lower_bound(b+1,b+1+cnt2,A[i].y)-b;
        v[c[d1]][d2]=1;
    }
    build(1,1,cnt1);
    // cerr<<v[140000].count()<<"\n";
    // cerr<<cnt1<<" "<<cnt2<<"\n";
    for(int i=1;i<=q;i++){
        // cerr<<i<<"\n";
        t1=read(),t2=read(),t3=read(),t4=read();
        if(type) t1^=ans,t2^=ans,t3^=ans,t4^=ans;
        ans=0;
        int d1=lower_bound(a+1,a+1+cnt1,t1)-a;
        int d2=upper_bound(a+1,a+1+cnt1,t2)-a-1;
        int d3=lower_bound(b+1,b+1+cnt2,t3)-b;
        int d4=upper_bound(b+1,b+1+cnt2,t4)-b-1;
        V=query(1,1,cnt1,d1,d2);
        for(int j=d1;j<=d2;j++){
            int w=v[c[j]]._Find_next(d3-1);
            if(w<=d4) ans++;
        }
        for(int j=d3;j<=d4;j++) if(V[j]) ans++;
        cout<<ans<<"\n";
    }
    return 0;
}