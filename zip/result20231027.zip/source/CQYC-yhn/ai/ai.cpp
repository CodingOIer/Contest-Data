#include<bits/stdc++.h>
#define int long long
using namespace std;
namespace tizui{
    const double ap=0.7;
    int rt[2],cnt,a[200005],sz[200005],tsz[200005],tot[200005],sum[200005],ch[200005][2];
    vector<int> e;
    inline int New(int x){
        cnt++;
        a[cnt]=x;ch[cnt][0]=ch[cnt][1]=0;
        sz[cnt]=tsz[cnt]=sum[cnt]=tot[cnt]=1;
        return cnt;
    }
    inline void pushup(int k){
        sz[k]=sz[ch[k][0]]+sz[ch[k][1]]+1;
        tsz[k]=tsz[ch[k][0]]+tsz[ch[k][1]]+(tot[k]>0);
        sum[k]=sum[ch[k][0]]+sum[ch[k][1]]+tot[k];
    }
    inline void dfs(int k){
        if(ch[k][0]) dfs(ch[k][0]);
        if(tot[k]>0) e.push_back(k);
        if(ch[k][1]) dfs(ch[k][1]);
    }
    inline void rebuild(int &k,int l,int r){
        if(l>r){
            k=0;
            return;
        }
        int mid=(l+r)>>1;
        k=e[mid];
        rebuild(ch[k][0],l,mid-1);rebuild(ch[k][1],mid+1,r);
        pushup(k);
    }
    inline void insert(int &k,int g,bool F){
        FLAG2:
        if(!k) k=New(g);
        else if(a[k]==g) tot[k]++;
        else{
            if(F&&((double)sz[ch[k][0]]>=(double)sz[k]*ap||(double)sz[ch[k][1]]>=(double)sz[k]*ap||(double)(sz[k]-tsz[k])>=(double)sz[k]*(1.0-ap))){
                e.clear();
                dfs(k);
                rebuild(k,0,(int)e.size()-1);
                F=0;
                goto FLAG2;
            }
            int d=g>a[k];
            insert(ch[k][d],g,F);
        }
        pushup(k);
    }
    inline void remove(int &k,int g,int F){
        FLAG1:
        if(!k) return;
        else if(a[k]==g) tot[k]=max(tot[k]-1,(int)0);
        else{
            if(F&&((double)sz[ch[k][0]]>=(double)sz[k]*ap||(double)sz[ch[k][1]]>=(double)sz[k]*ap||(double)(sz[k]-tsz[k])>=(double)sz[k]*(1.0-ap))){
                e.clear();
                dfs(k);
                rebuild(k,0,(int)e.size()-1);
                F=0;
                goto FLAG1;
            }
            int d=g>a[k];
            remove(ch[k][d],g,F);
        }
        pushup(k);
    }
    inline int rk(int k,int g){
        if(!k) return 1;
        if(a[k]==g) return sum[ch[k][0]]+1;
        else if(g<a[k]) return rk(ch[k][0],g);
        return rk(ch[k][1],g)+sum[ch[k][0]]+tot[k];
    }
    inline int find(int k,int g){
        if(g<=sum[ch[k][0]]) return find(ch[k][0],g);
        else if(g<=(sum[ch[k][0]]+tot[k])) return a[k];
        return find(ch[k][1],g-sum[ch[k][0]]-tot[k]);
    }
    inline bool qian(int k,int g){
        if(!k) return 0;
        else if(a[k]<g&&sum[ch[k][1]]&&qian(ch[k][1],g)) return 1;
        else if(a[k]<g&&tot[k]>0){
            cout<<a[k]<<"\n";
            return 1;
        }
        else if(sum[ch[k][0]]&&qian(ch[k][0],g)) return 1;
        return 0;
    }
    inline int hou(int k,int g){
        if(!k) return 0;
        else if(a[k]>g&&sum[ch[k][0]]&&hou(ch[k][0],g)) return 1;
        else if(a[k]>g&&tot[k]>0){
            cout<<a[k]<<"\n";
            return 1;
        }
        else if(sum[ch[k][1]]&&hou(ch[k][1],g)) return 1;
        return 0;
    }
}
int n,m,K;
struct ok{
    int x,y;
    bool operator < (const ok &A) const{
        return x<A.x;
    }
}a[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline bool cmp(ok a,ok b){
    return a.y<b.y;
}
signed main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    n=read(),m=read(),K=read();
    for(int i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
    sort(a+1,a+1+n);
    int sum=0;
    for(int i=1;i<=K;i++) sum+=a[i].x;
    if(sum>m){
        cout<<"-1";
        return 0;
    }
    sort(a+1,a+1+n,cmp);
    int o=K/2,s1=0,s2=0;
    for(int i=n-o+1;i<=n;i++) s2+=a[i].x,tizui::insert(tizui::rt[1],a[i].x,1);
    for(int i=1;i<(n-o);i++) tizui::insert(tizui::rt[0],a[i].x,1);
    for(int i=1;i<=o;i++) s1+=tizui::find(tizui::rt[0],i);
    for(int i=(n-o);i>o;i--){
        sum=a[i].x+s1+s2;
        if(sum<=m){
            cout<<a[i].y;
            return 0;
        }
        int d1=tizui::find(tizui::rt[1],o);
        if(a[i].x<d1) s2+=(a[i].x-d1);
        tizui::insert(tizui::rt[1],a[i].x,1);
        d1=tizui::find(tizui::rt[0],o);
        if(a[i-1].x<=d1) s1-=a[i-1].x,s1+=tizui::find(tizui::rt[0],o+1);
        tizui::remove(tizui::rt[0],a[i-1].x,1);
    }
    return 0;
}
