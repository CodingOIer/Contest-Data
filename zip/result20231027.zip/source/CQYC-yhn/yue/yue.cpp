#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,n,m;
char a[1005][1005],b[1005][1005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
        for(int i=1;i<=n;i++) scanf("%s",b[i]+1);
        bool f=1,ff=0;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(a[i][j]!=b[i][j]) f=0;
                if(a[i][j]=='0') ff=1;
            }
        }
        if(f) puts("Yes");
        else if(!ff) puts("No");
        else{
            f=1;
            bool F1=1,F2=1,F3=0,F4=0;
            for(int i=1;i<=n;i++){
                int sum=0;
                bool F=1;
                for(int j=1;j<=m;j++){
                    sum+=(b[i][j]=='1');
                    F&=(a[i][j]==b[i][j]);
                }
                if((sum>1)&&(!F)) f=0;
                F3|=((sum==0)&&(!F));
                F1|=(sum==1); 
            }
            for(int i=1;i<=m;i++){
                int sum=0;
                bool F=1;
                for(int j=1;j<=n;j++){
                    sum+=(b[j][i]=='1');
                    F&=(a[j][i]==b[j][i]);
                }
                if((sum>1)&&(!F)) f=0; 
                F4|=((sum==0)&&(!F));
                F2|=(sum==1); 
            }
            if(F3&&!F2) f=0;
            if(F4&&!F1) f=0;
            if(!f) puts("No");
            else puts("Yes");
        }
    }
    return 0;
}