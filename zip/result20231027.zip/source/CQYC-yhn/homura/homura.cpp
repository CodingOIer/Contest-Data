#include<bits/stdc++.h>
#define int long long
using namespace std;
int l,r,a[10000005],cnt,s1=0,s2=0,ans=0,b[25],c[25],sum[15];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void dfs(__int128 k,int g){
    if(k>(__int128)1e18) return;
    if(k) a[++cnt]=k;
    for(int i=g;i<=9;i++) dfs(k*(__int128)10+(__int128)i,i);
}
inline int js(int x){
    int t=x,d=0;
    while(t) t/=(int)10,d++;
    return d;
}
inline bool check(int y,int p,bool op,bool f){
    if(p==(y+1)) return 1;
    int L=b[p],R=c[p];
    if(y>s1) L=0;
    if(y<s2) R=10;
    if(!op&&f) R=10;
    if(op&&f) L=-1;
    for(int i=L+1;i<R;i++) if(sum[i]) return 1;
    if((L>=0&&sum[L])||sum[R]){
        if(!op){
            if(L>=0&&sum[L]){
                if(L==0&&p==1) return 0;
                sum[L]--;
                int w=check(y,p+1,op,f|(L!=R));
                sum[L]++;
                return w;
            }
            else return 0;
        }
        else{       
            if(sum[R]){
                sum[R]--;
                int w=check(y,p+1,op,f|(L!=R));
                sum[R]++;
                return w;
            }
            else return 0;
        }
    }
    else return 0;
}
signed main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    dfs(0,1);
    l=read(),r=read();
    int t=l;
    while(t) b[++s1]=t%10,t/=10;
    t=r;
    while(t) c[++s2]=t%10,t/=10;
    reverse(b+1,b+1+s1);
    reverse(c+1,c+1+s2);
    sort(a+1,a+1+cnt);
    // cerr<<cnt<<"\n";
    for(int i=1;i<=cnt;i++){
        int d=js(a[i]);
        if(s2<d) break;
        if(s1<d&&d<s2) ans++;
        else if(d<s1&&abs(s1-s2)>1) ans++;
        else if(l<a[i]&&a[i]<r) ans++;
        else{
            for(int j=0;j<10;j++) sum[j]=0;
            t=a[i]; 
            while(t) sum[t%10]++,t/=10;
            bool f=0;
            for(int j=max(s1,d);j<=s2;j++){
                sum[0]=j-d;
                f|=check(j,1,0,0);
                sum[0]=j-d;
                f|=check(j,1,1,0);
                if(f) break;
            }
            if(f) ans++;
        }
    }
    cout<<(long long)ans;
    return 0;
}