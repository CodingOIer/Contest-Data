#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+5;
// char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,m,k,ans,b[N];
const int inf=1e18;
struct name{
   int w,v; 
}a[N];
bool operator <(name a,name b){
    return a.v<b.v;
}
priority_queue<int> q;
signed main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++) a[i].w=read(),a[i].v=read();
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++){
        q.push(a[i].w);
        if(i>k/2){
            b[i]=ans+a[i].w;
            ans-=q.top();
            q.pop();
        }
        else b[i]=inf;
        ans+=a[i].w;
    }
    ans=0;
    for(int i=n;i;i--){
        q.push(a[i].w);
        if(n-i+1>k/2){
            b[i]+=ans;
            ans-=q.top();
            q.pop();
        }
        else b[i]=inf;
        ans+=a[i].w;
    }
    for(int i=n;i;i--){
        // cout<<b[i]<<" ";
        if(b[i]<=m){
            cout<<a[i].v;
            return 0;
        }
    }
    cout<<"-1";
    return 0;
}