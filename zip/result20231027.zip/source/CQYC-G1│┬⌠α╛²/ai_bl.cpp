#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+5;
// char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,m,k,ans=-1;
struct name{
   int w,v; 
}a[N];
bool operator <(name a,name b){
    return a.v<b.v;
}
priority_queue<int> q1,q2,qans;
int check(int v){
    int ans=0;
    while(!q1.empty()) q1.pop();
    while(!q2.empty()) q2.pop();
    while(!qans.empty()) qans.pop();
    for(int i=1;i<=n;i++){
        if(a[i].v==v) qans.push(-a[i].w);
        else if(a[i].v<v) q1.push(-a[i].w);
        else q2.push(-a[i].w);
    }
    if(q1.size()<k/2||q2.size()<k/2) return 0; 
    for(int i=1;i<=k/2;i++){
        qans.push(q1.top());
        qans.push(q2.top());
        q1.pop(),q2.pop();
    }
    for(int i=1;i<=k;i++){
        ans-=qans.top();
        qans.pop();
    }
    return ans<=m;
}
signed main(){
    // freopen("ai.in","r",stdin);
    // freopen("ai.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++) a[i].w=read(),a[i].v=read();
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++){
        cout<<check(a[i].v)<<" ";
        if(check(a[i].v)) ans=max(ans,a[i].v);
    }
    cout<<"\n";
    cout<<ans;
    return 0;
}