#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5,n=5e5;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int m,q,type;
int bl[N],block;
int s[N],ans[N];
vector<int> g1[N],g2[N];
struct query{
    int l1,r1,l2,r2;
}qu[N];
struct que{
    int l,r,id;
}qus[N];
bool operator <(que a,que b){
    return bl[a.l]==bl[b.l]?a.r>b.r:a.l>b.l;
}
int t[N];
int lowbit(int x){
    return x&-x;
}
void insert(int x,int c){
    while(x<=n){
        t[x]+=c;
        x+=lowbit(x);
    }
}
int query(int x){
    int ans=0;
    while(x){
        ans+=t[x];
        x-=lowbit(x);
    }
    return ans;
 }

int cnt[N];
void add1(int x){
    for(int y:g1[x]){
        if(!cnt[y]) insert(y,1);
        cnt[y]++;
    }
}
void del1(int x){
    for(int y:g1[x]){
        cnt[y]--;
        if(!cnt[y]) insert(y,-1);
    }
}
void add2(int x){
    for(int y:g2[x]){
        if(!cnt[y]) insert(y,1);
        cnt[y]++;
    }
}
void del2(int x){
    for(int y:g2[x]){
        cnt[y]--;
        if(!cnt[y]) insert(y,-1);
    }
}
int main(){
    freopen("kearu.in","r",stdin);
    freopen("kearu.out","w",stdout);
    m=read(),q=read(),type=read();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        g1[x].push_back(y);
        g2[x].push_back(y);
    }
    block=n/sqrt(m)+1;
    for(int i=1;i<=n;i++) s[i]=s[i-1]+g1[i].size(),bl[i]=i/block;
    for(int i=1;i<=q;i++){
        int l1=read(),r1=read(),l2=read(),r2=read();
        qu[i]={l1,r1,l2,r2};
        qus[i]={s[l1],s[r1],i};
    }
    sort(qus,qus+q);
    int L=1,R=0;
    for(int i=1;i<=q;i++){
        int id=qus[i].id;
        int l=qu[i].l1,r=qu[i].r1;
        while(R<r) add1(++R);
        while(L<l) del1(L++);
        while(L>l) add1(--L);
        while(R>r) del1(R--);
        ans[id]=query(qu[i].r2)-query(qu[i].l2-1);
    }
    memset(t,0,sizeof(t));
    memset(cnt,0,sizeof(cnt));
    for(int i=1;i<=n;i++) s[i]=s[i-1]+g2[i].size();
    for(int i=1;i<=q;i++){
        int l2=qu[i].l2,r2=qu[i].r2;
        qus[i]={s[l2],s[r2],i};
    }
    sort(qus,qus+q);
    L=1,R=0;
    for(int i=1;i<=q;i++){
        int id=qus[i].id;
        int l=qu[i].l2,r=qu[i].r2;
        while(R<r) add2(++R);
        while(L<l) del2(L++);
        while(L>l) add2(--L);
        while(R>r) del2(R--);
        ans[id]=query(qu[i].r1)-query(qu[i].l1-1);
    }
    for(int i=1;i<=q;i++) cout<<ans[i]<<"\n";
    return 0;
}