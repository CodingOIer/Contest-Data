#include <bits/stdc++.h>
using namespace std;
const int N=1005;
int t,n,m,h[N],l[N],ch,cl,yw,kk;
string a[N],b[N];
void solve(){
    memset(h,0,sizeof(h));
    memset(l,0,sizeof(l));
    cin>>n>>m;
    ch=cl=yw=0;
    kk=1;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        a[i]=' '+a[i];
    }
    for(int i=1;i<=n;i++){
        cin>>b[i];
        b[i]=' '+b[i];
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(a[i][j]!=b[i][j]) yw++;
            if(a[i][j]=='0') kk=0;
        }
    }
    if(yw==0){
        cout<<"Yes\n";
        return;
    }
    if(kk){
        cout<<"No\n";
        return;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            h[i]+=b[i][j]-'0';
            l[j]+=b[i][j]-'0';
        }
    }
    for(int i=1;i<=n;i++) ch+=h[i]<=1;
    for(int i=1;i<=m;i++) cl+=l[i]<=1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(a[i][j]!=b[i][j]){
                if(b[i][j]=='1'){
                    if(h[i]>1||l[j]>1){
                        cout<<"No\n";
                        return ;
                    }
                }
                else{
                    if(ch<=1&&cl<=1){
                        cout<<"No\n";
                        return ;
                    }
                }
            }
        }
    }
    cout<<"Yes\n";
    return;
}
int main(){
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    cin>>t;
    while(t--) solve();
    return 0;
}