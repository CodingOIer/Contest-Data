#include <bits/stdc++.h>
using namespace std;
string l,r;
int ans,t[10],t1[10],nl,nr,n;
bool checkl(string l){
    int nl=l.size();
    memcpy(t1,t,sizeof(t));
    for(int i=0;i<nl;i++){
        for(int j=l[i]-'0'+1;j<=9;j++){
            if(t1[j]){
                return 1;
            }
        }
        if(t1[l[i]-'0']){
            // cout<<l[i]<<" "<<t1[1]<<"!\n";
            t1[l[i]-'0']--;
        }
        else return 0;
    }
    return 1;
}
bool checkr(string r){
    int nr=r.size();
    memcpy(t1,t,sizeof(t));
    for(int i=0;i<nr;i++){
        for(int j=0;j<=r[i]-'0'-1;j++){
            if(t1[j]) return 1;
        }
        if(t1[r[i]-'0']) t1[r[i]-'0']--;
        else return 0;
    }
    return 1;
}
string ti(string s,int l,int r){
    string ans="";
    for(int i=l;i<=r;i++) ans+=s[i];
    return ans;
}
bool check(string s){
    int n=s.size();
    memset(t,0,sizeof(t));
    t[0]=nr-n;
    for(int i=0;i<n;i++) t[s[i]-'0']++;
    if(nl!=nr){
        if(n==nl) return checkl(l)|checkr(r);
        return checkr(r);
    }
    else{
        for(int i=0;i<nl;i++){
            if(l[i]==r[i]){
                if(!t[l[i]-'0']) return 0;
                else t[l[i]-'0']--;
            }
            else{
                for(int j=l[i]-'0'+1;j<=r[i]-'0'-1;j++){
                    if(t[j]){
                        return 1;
                    }
                }
                if(t[l[i]-'0']){
                    t[l[i]-'0']--;
                    if((i==nl-1||checkl(ti(l,i+1,nl-1)))) return 1;
                    t[l[i]-'0']++;
                }
                if(t[r[i]-'0']){
                    t[r[i]-'0']--;
                    if((i==nl-1||checkr(ti(r,i+1,nr-1)))) return 1;
                    t[r[i]-'0']++;
                }
                return 0;
            }
        }
    }
    return 1;
}
void dfs(string s,int now){
    // ans+=check(s);
    if(s.size()&&check(s)){
        ans++;
        // cout<<s<<"!\n";
    }
    // if(s.size()>=nl){
    //     cout<<s<<" "<<check(s)<<"\n";
    // }
    if(s.size()==nr) return;
    for(char i=now+'0';i<='9';i++) dfs(s+i,i-'0');
}
int main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    cin>>l>>r;
    nl=l.size(),nr=r.size();
    dfs("",1);
    cout<<ans;
    return 0;
}