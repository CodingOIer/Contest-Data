#include <bits/stdc++.h>
using namespace std;
int main(){
    freopen("ai.in","w",stdout);
    srand(time(0));
    int n=rand()%1000+1,m=rand()%100000+1;
    int k=rand()%10+1;
    cout<<n<<" "<<m<<" "<<k<<"\n";
    for(int i=1;i<=n;i++) cout<<rand()%m/10+1<<" "<<rand()%m+1<<"\n";
    return 0;
}