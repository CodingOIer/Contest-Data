#include <bits/stdc++.h>
using namespace std;
int n, m, k, ans = -1;
long long s;
pair<int, int> a[200000];
multiset<int> l, p, r;
int main()
{
    freopen("ai.in", "r", stdin);
    freopen("ai.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 0; i < n; i++)
        scanf("%d%d", &a[i].second, &a[i].first);
    sort(a, a + n);
    for (int i = k / 2 + 1; i < n; i++)
        p.insert(a[i].second);
    for (int i = 0; i < k / 2; i++)
    {
        l.insert(a[i].second);
        r.insert(*p.begin());
        s = s + a[i].second + *p.begin();
        p.erase(p.begin());
    }
    for (int i = k / 2; i + k / 2 < n; i++)
    {
        if (i != k / 2)
        {
            l.insert(a[i - 1].second);
            s += a[i - 1].second - *prev(l.end());
            l.erase(prev(l.end()));
            if (r.count(a[i].second))
            {
                r.insert(*p.begin());
                s += *p.begin() - a[i].second;
                p.erase(p.begin());
                r.erase(r.find(a[i].second));
            }
            else
                p.erase(p.find(a[i].second));
        }
        if (s + a[i].second <= m)
            ans = a[i].first;
    }
    printf("%d\n", ans);
    return 0;
}