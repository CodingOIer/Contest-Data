#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
const int N = 500005;
int m, q, t;
vector<int> sl, sr;
vector<int> el[N], er[N];
__gnu_pbds::gp_hash_table<int, int> k[N];
int calc(int l, int r)
{
    int ans = 0;
    for (int x = l; x; x -= x & -x)
        for (int y = r; y; y -= y & -y)
            if (k[x].find(y) != k[x].end())
                ans += k[x][y];
    return ans;
}
int main()
{
    freopen("kaeru.in", "r", stdin);
    freopen("kaeru.out", "w", stdout);
    scanf("%d%d%d", &m, &q, &t);
    for (int i = 0, l, r; i < m; i++)
    {
        scanf("%d%d", &l, &r);
        el[l].push_back(r);
        er[r].push_back(l);
        for (int x = l; x < N; x += x & -x)
            for (int y = r; y < N; y += y & -y)
                k[x][y]++;
    }
    for (int i = 0; i < N; i++)
    {
        sort(el[i].begin(), el[i].end());
        sort(er[i].begin(), er[i].end());
        if (el[i].size() > 1)
            sl.push_back(i);
        if (er[i].size() > 1)
            sr.push_back(i);
    }
    for (int i = 0, xl, xr, yl, yr, ans = 0; i < q; i++)
    {
        scanf("%d%d%d%d", &xl, &xr, &yl, &yr);
        xl ^= ans * t;
        xr ^= ans * t;
        yl ^= ans * t;
        yr ^= ans * t;
        ans = (calc(xr, yr) - calc(xl - 1, yr) - calc(xr, yl - 1) + calc(xl - 1, yl - 1)) * 2;
        for (auto p = lower_bound(sl.begin(), sl.end(), xl), d = upper_bound(sl.begin(), sl.end(), xr); p != d; p++)
            ans -= max(upper_bound(el[*p].begin(), el[*p].end(), yr) - lower_bound(el[*p].begin(), el[*p].end(), yl) - 1, ptrdiff_t());
        for (auto p = lower_bound(sr.begin(), sr.end(), yl), d = upper_bound(sr.begin(), sr.end(), yr); p != d; p++)
            ans -= max(upper_bound(er[*p].begin(), er[*p].end(), xr) - lower_bound(er[*p].begin(), er[*p].end(), xl) - 1, ptrdiff_t());
        printf("%d\n", ans);
    }
    return 0;
}