#include <bits/stdc++.h>
using namespace std;
int t, n, m;
int a[2000][2000], b[2000][2000];
int main()
{
    freopen("yue.in", "r", stdin);
    freopen("yue.out", "w", stdout);
    scanf("%d", &t);
    while (t--)
    {
        scanf("%d%d", &n, &m);
        int ans = 0, as = 0, bs = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                scanf("%1d", &a[i][j]), as += a[i][j];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                scanf("%1d", &b[i][j]), bs += b[i][j];
        ans |= (as == n * m && bs < as) || (as && !bs);
        for (int i = 0; i < n; i++)
        {
            int s = 0;
            for (int j = 0; j < m; j++)
                s += b[i][j];
            for (int j = 0; j < m; j++)
                ans |= s > 1 && !a[i][j] && b[i][j];
        }
        for (int i = 0; i < m; i++)
        {
            int s = 0;
            for (int j = 0; j < n; j++)
                s += b[j][i];
            for (int j = 0; j < n; j++)
                ans |= s > 1 && !a[j][i] && b[j][i];
        }
        puts(ans ? "No" : "Yes");
    }
    return 0;
}