#include <bits/stdc++.h>
using namespace std;
int l, r;
int p[]{0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000};
unordered_set<int> s;
int main()
{
    freopen("homura.in", "r", stdin);
    freopen("homura.out", "w", stdout);
    scanf("%d%d", &l, &r);
    for (int i = l; i <= r; i++)
    {
        int x = 0;
        for (int j = i; j; j /= 10)
            x += p[j % 10];
        s.insert(x);
    }
    printf("%zu\n", s.size());
    return 0;
}