#include<bits/stdc++.h>
using namespace std;
string a,b;
long long mod=1e9+7;
vector<int> sh;
long long dp[100100][12],dp2[100100][12],temp[100100];
long long inv[100100],fan[100100];
void init_dp(long long sz)
{
	dp[0][0]=1;
	for(int i=1;i<10;i++) dp[1][i]=1;
	for(int i=2;i<=sz;i++)
	{
		for(int j=1;j<=9;j++)
		{
			for(int k=j;k<=9;k++)
			{
				//if(i==3&&j==2) cout<<i<<" "<<j<<" "<<w<<" "<<k<<" "<<dp[w][k]<<'\n';
				dp[i][j]+=dp[i-1][k],dp[i][j]%=mod;
			}
			for(int k=1;k<=j;k++) dp2[i][j]+=dp2[i-1][k],dp2[i][j]%=mod;
		}
		for(int j=1;j<=9;j++) dp[i][0]+=dp[i-1][j],dp[i][0]%=mod;
	}
}
long long get(string x)
{
	if(x[1]=='0') return 0;
	long long ans=0;
	string temp="";
	for(int i=x.size()-1;i>0;i--) temp+=x[i];
	temp="!"+temp;
	//cout<<temp<<"\n";
	int last=1;
	//if(temp.size()>2) ans+=dp[temp.size()-2][0],ans%=mod;
	for(int i=temp.size()-1;i>1;i--)
	{
		for(int j=1;j<=9;j++) ans+=dp[i-1][j],ans%=mod;
	}
	for(int i=temp.size()-1;i>0;i--)
	{
		for(int j=last;j<(temp[i]-'0');j++)ans+=dp[i][j],ans%=mod;
		if(temp[i]<temp[i+1]&&i!=temp.size()-1) break;
		if(i==1) ans++,ans%=mod;
		last=temp[i]-'0';
	}
	return ans;
}
long long get2(string x)
{
	if(x[1]=='0') return 0;
	long long ans=0;
	string temp="";
	for(int i=x.size()-1;i>0;i--) temp+=x[i];
	temp="!"+temp;
	//cout<<temp<<"\n";
	int last=1;
	//if(temp.size()>2) ans+=dp[temp.size()-2][0],ans%=mod;
	for(int i=temp.size()-1;i>1;i--)
	{
		for(int j=1;j<=9;j++) ans+=dp2[i-1][j],ans%=mod;
	}
	for(int i=temp.size()-1;i>0;i--)
	{
		for(int j=last;j<(temp[i]-'0');j++)ans+=dp2[i][j],ans%=mod;
		if(temp[i]<temp[i+1]&&i!=temp.size()-1) break;
		if(i==1) ans++,ans%=mod;
		last=temp[i]-'0';
	}
	return ans;
}
void jian(int sh)
{
	if(a=="!1") {a="!0";return ;}
	int nw=a.size()-1;
	while(a[nw]=='0') a[nw]='9',nw--;
	a[nw]--;
	if(a[1]=='0') a.erase(1,1);
	return ;
}
int main()
{
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>a>>b,a="!"+a,b="!"+b;
	jian(1);
	cout<<a<<'\n';
	init_dp(b.size()+5);
	//cout<<C(2,5)<<"\n";
	cout<<((get(b)-get2(a))%mod+mod)%mod<<'\n';
	return 0;
}
