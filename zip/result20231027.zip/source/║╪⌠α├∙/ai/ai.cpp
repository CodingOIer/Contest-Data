#include<bits/stdc++.h>
using namespace std;
long long n,m,k;
long long dp[100100],minnl[100100],minnr[100100];
priority_queue<long long> q;
struct node{
	long long v,w;
}f[100100];
bool cmp(node a,node b)
{
	if(a.v!=b.v) return a.v<b.v;
	return a.w<b.w;
}
bool cmp2(node a,node b)
{
	if(a.w!=b.w) return a.w<b.w;
	return a.v<b.v;
}
int main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++) cin>>f[i].v>>f[i].w;
	sort(f+1,f+n+1,cmp);
	long long sum=0;
	for(int i=1;i<=k;i++) sum+=f[i].v;
	if(sum>m) {cout<<-1;return 0;}
	sum=0;
	sort(f+1,f+n+1,cmp2);
	for(int i=1;i<=n;i++)
	{
		if(i<k/2) {q.push(f[i].v),sum+=f[i].v;continue;}
		q.push(f[i].v),sum+=f[i].v;
		if(q.size()>k/2) sum-=q.top(),q.pop();
		minnl[i]=sum;
	}
	while(!q.empty()) q.pop();
	sum=0;
	for(int i=n;i>=1;i--)
	{
		if(i>n-k/2+1) {q.push(f[i].v),sum+=f[i].v;continue;}
		q.push(f[i].v),sum+=f[i].v;
		if(q.size()>k/2) sum-=q.top(),q.pop();
		minnr[i]=sum;
	}
	//for(int i=1;i<=n;i++) cout<<minnl[i]+minnr[i]<<" "<<f[i].w<<'\n';
	for(int i=n-k/2;i>k/2;i--)
	{
		if(f[i].v+minnr[i+1]+minnl[i-1]<=m) {cout<<f[i].w;return 0;}
	}
	cout<<-1;
	return 0;
}
