#include<bits/stdc++.h>
using namespace std;
int n,m,t;
string x[1010],y[1010];
int main()
{
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>t;
	while(t--)
	{
		cin>>n>>m;
		for(int i=1;i<=n;i++) cin>>x[i];
		for(int i=1;i<=n;i++) cin>>y[i];
		cout<<"Yes\n";
	}
	return 0;
}
