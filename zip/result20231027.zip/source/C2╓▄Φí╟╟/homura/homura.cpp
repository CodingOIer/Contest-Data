#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5,mod=1e9+7;
string L,R,now;
int ans,cnt[10],n,sum;
inline int cmp(string x,string y){
	if(x.size()!=y.size())
		return x.size()>y.size()?1:(-1);
	for(int i=0;i<x.size();++i){
		if(x[i]>y[i]) return 1;
		if(x[i]<y[i]) return -1;
	}return 0;
}
bool ok;
void dfs(int x){
	if(x==sum+1){
		if(cmp(now,L)!=-1&&cmp(now,R)!=1) ok=1;
		return;
	}
	for(int i=(x==1?1:0);i<=9&&!ok;++i)
		if(cnt[i]){
			--cnt[i];
			now+=(char)'0'+i;
			dfs(x+1);
			now.pop_back();
			++cnt[i];
		}
}
void dfs2(int x){
	if(x==10){	
		if(!sum) return;
		int tmp=sum;
		while(sum<L.size()) ++sum,++cnt[0];
		while(sum<=R.size()){
			ok=0;
			dfs(1);
			++sum,++cnt[0];
			ans+=ok;
		}
		sum=tmp;
		cnt[0]=0;
		return;
	}
	for(int i=0;i<=n;++i){
		n-=i;cnt[x]=i;
		sum+=i;
		dfs2(x+1);
		sum-=i;
		n+=i,cnt[x]=0;
	}
}
int main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	cin >> L >> R;
	n=R.size();
	dfs2(1);
	cout << ans;
	return 0;
}
