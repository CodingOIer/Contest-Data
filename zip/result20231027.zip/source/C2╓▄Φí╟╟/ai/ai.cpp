#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int n,m,k,ans=-1;
struct node{int v,w;}a[N];
inline bool cmp(node x,node y){return x.w<y.w;}
priority_queue<int> hp;
ll sum,lc[N],rc[N];
int main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k>>=1;
	for(int i=1;i<=n;++i) scanf("%d%d",&a[i].v,&a[i].w);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=k;++i) sum+=a[i].v,hp.push(a[i].v);
	for(int i=k+1;i<=n;++i){
		lc[i]=sum;
		hp.push(a[i].v);
		sum+=a[i].v-hp.top(),hp.pop();
	}
	while(!hp.empty()) hp.pop();
	sum=0;
	for(int i=n;i>n-k;--i) sum+=a[i].v,hp.push(a[i].v);
	for(int i=n-k;i>0;--i){
		rc[i]=sum;
		hp.push(a[i].v);
		sum+=a[i].v-hp.top(),hp.pop();
	}
	for(int i=k+1;i+k<=n;++i)
		if(lc[i]+a[i].v+rc[i]<=m)
			ans=max(ans,a[i].w);
	printf("%d",ans);
	return 0;
}
