#include<bits/stdc++.h>
using namespace std;
const int N=5e5,M=N*2+5;
inline void read(int &x){
	x=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int m,q,typ,u[N],v[N],a,b,c,d,nxt[M],ans;
int l,r,vis[M],id;
vector<int> G[M];
int main(){
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdin);
	read(m),read(q),read(typ);
	int KK;
	read(KK);
	for(int i=1;i<=m;++i){
		read(u[i]),read(v[i]);
		v[i]+=N;
		G[u[i]].push_back(v[i]);
		G[v[i]].push_back(u[i]);
	}
	for(int i=1;i<=N*2;++i)
		if(!G[i].empty())
			sort(G[i].begin(),G[i].end());
	for(int i=N,z=N+1;~i;--i){
		nxt[i]=z;
		if(G[i].size()) z=i;
	}
	for(int i=N*2,z=N*2+1;i>=N;--i){
		nxt[i]=z;
		if(G[i].size()) z=i;
	}
	while(q--){
		read(a),read(b),read(c),read(d);
		ans*=typ;
		a^=ans,b^=ans,c^=ans,d^=ans;
		ans=0;
		c+=N,d+=N;
		if(a==b){
			l=lower_bound(G[a].begin(),G[a].end(),c-1)-G[a].begin();
			r=lower_bound(G[a].begin(),G[a].end(),d)-G[a].begin();
			if(l<r) ans=r-l+1;
		}else if(m<=2000){
			++id;
			for(int i=1;i<=m;++i){
				if(u[i]<a||u[i]>b||v[i]<c||v[i]>d) continue;
				if(vis[u[i]]!=id) ++ans,vis[u[i]]=id;
				if(vis[v[i]]!=id) ++ans,vis[v[i]]=id;
			}
		}else{
			for(int i=nxt[a-1];i<=b;i=nxt[i]){
				l=lower_bound(G[i].begin(),G[i].end(),c)-G[i].begin();
				r=lower_bound(G[i].begin(),G[i].end(),d+1)-G[i].begin();
				if(l<r) ++ans;	
			}
			for(int i=nxt[c-1];i<=d;i=nxt[i]){
				l=lower_bound(G[i].begin(),G[i].end(),a)-G[i].begin();
				r=lower_bound(G[i].begin(),G[i].end(),b+1)-G[i].begin();
				if(l<r) ++ans;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

