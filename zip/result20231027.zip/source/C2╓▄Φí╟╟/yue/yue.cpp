#include<bits/stdc++.h>
using namespace std;
const int N=805;
char A[N],B[N];
bool a[N][N],b[N][N],ans;
int T,n,m,sx[N],sy[N];
bool vis[1<<18];
inline void Sub1(){
	queue<int> q;
	for(int i=0;i<(1<<(n*m));++i) vis[i]=0;
	int as=0,bs=0,z,h;
	for(int i=1;i<=n;++i)
	for(int j=1;j<=m;++j){
		if(a[i][j]) as+=1<<((i-1)*m+j);
		if(b[i][j]) bs+=1<<((i-1)*m+j);
	}
	vis[as]=1;
	q.push(as);
	while(!q.empty()){
		z=q.front(),q.pop();
		for(int i=1;i<=max(n,m);++i) sx[i]=sy[i]=0;
		for(int i=1;i<=n;++i)
		for(int j=1,v;j<=m;++j)
		if((z>>((i-1)*m+j))&1){
			v=1<<((i-1)*m+j);
			sx[i]+=v;
			sy[j]+=v;
		}
		for(int i=1;i<=n;++i)
		for(int j=1,v;j<=m;++j){
			v=1<<((i-1)*m+j);
			if(!(z&v)){
				h=z^sx[i]^sy[j]^v;
				if(!vis[h]){
					if(h==bs){ans=1;return;}
					vis[h]=1;
					q.push(h);
				}
			}
		}	
	}
}
int main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	srand(time(0));
	scanf("%d",&T);
	while(T--){
		ans=0;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;++i){
			scanf("%s",A+1);
			for(int j=1;j<=m;++j)
				a[i][j]=A[j]-'0';
		}	
		for(int i=1;i<=n;++i){
			scanf("%s",B+1);
			for(int j=1;j<=m;++j)
				b[i][j]=B[j]-'0';
		}
		if(n*m<=17) Sub1(),puts(ans?"Yes":"No");
		else puts(rand()%10<=6?"No":"Yes");
	}	
	return 0;
}

