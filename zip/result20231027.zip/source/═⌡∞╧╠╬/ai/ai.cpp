/*
    Program: ai.cpp
    Author: 1l6suj7
    DateTime: 2023-10-27 10:33:47
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second
#define eps 1e-9

using namespace std;

const int N = 100010;

struct objec {
    ll w, c;
} ob[N];

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

bool cmpc(objec t1, objec t2) { return t1.c == t2.c ? t1.w < t2.w : t1.c < t2.c; }
bool cmpw(objec t1, objec t2) { return t1.w < t2.w; }

int n, m, K;

objec ob2[N], ob3[N];
bool judge(int x) {
    int t2 = 0, t3 = 0;
    lp(i, 1, n) {
        if(ob[i].c < x) ob2[++t2] = ob[i];
        else ob3[++t3] = ob[i];
    }
    int t = K >> 1;
    if(t3 < t) return false;
    sort(ob2 + 1, ob2 + 1 + t2, cmpw);
    sort(ob3 + 1, ob3 + 1 + t3, cmpw);
    ll sum = 0;
    int i = 1, j = 1;
    while(i + j - 1 <= K) {
        if(j > t3 || i <= t2 && ob2[i].w < ob3[j].w && i < j) {
            sum += ob2[i].w, ++i;
        }else {
            sum += ob3[j].w, ++j;
        }
    }
    return sum <= m;
}

signed main() {
    freopen("ai.in", "r", stdin);
    freopen("ai.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read(), m = read(), K = read();
    lp(i, 1, n) ob[i].w = read(), ob[i].c = read();
    sort(ob + 1, ob + 1 + n, cmpc);
    ll l = -1, r = 2e9;
    while(l < r) {
        ll mid = (l + r + 1) >> 1;
        if(judge(mid)) l = mid;
        else r = mid - 1;
    }
    printf("%lld", l);
    return 0;
}