#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second

using namespace std;

const int N = 50010, M = 300, K = 500010;

int n1, n2, m, q, typ, T1, L1[M], R1[M], pos1[N], T2, L2[M], R2[M], pos2[N], tans1[M][M][M], tans2[M][M][M], cnt1, cnt2;
int no1[K], no2[K], trs1[N], trs2[N];
vector<int> e1[K], e2[K];

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

int solve(vector<int> * e, int l1, int r1, int l2, int r2) {
    // cod("---solve");
    // co(l1), co(r1), co(l2), cod(r2);
    int res = 0;
    lp(u, l1, r1) {
        int t1 = lower_bound(e[u].begin(), e[u].end(), l2) - e[u].begin();
        // co(u), co(t1);
        // cod(e[u].size());
        if(t1 < e[u].size() && e[u][t1] <= r2) ++res;
    }
    // cod(res);
    return res;
}

void init(vector<int> * e, int & n, int * no, int * trs, int & T, int * L, int * R, int * pos, int & cnt) {
    // cod("---");
    n = 5e5;
    lp(i, 1, 5e5) {
        if(e[i].size() == 0) --n;
        else no[i] = ++cnt, trs[cnt] = i;
    }
    // lp(i, 1, cnt) co(trs[i]);
    // cod("");
    lp(i, 1, n) sort(e[i].begin(), e[i].end());
    T = pow((double)n, 0.5);
    lp(i, 1, T) {
        L[i] = (i - 1) * T + 1, R[i] = i * T;
        lp(j, L[i], R[i]) pos[j] = i;
    }
    if(R[T] != n) {
        ++T, L[T] = R[T - 1] + 1, R[T] = n;
        lp(i, L[T], R[T]) pos[i] = T;
    }
}

int sum[N], prs[N];
bool vis[N];

int calc(int l1, int l2, int r1, int r2, vector<int> * e1, vector<int> * e2, int T1, int * L1, int * R1, int * pos1, int T2, int * L2, int * R2, int * pos2, int (* tans1)[M][M], int (* tans2)[M][M]) {
    // cod("---calc");
    int ans = 0;
    if(pos1[r1] - pos1[l1] <= 1) ans += solve(e1, l1, r1, l2, r2)/* , cod(1) */;
    else {
        ans += solve(e1, l1, R1[pos1[l1]], l2, r2) + solve(e1, L1[pos1[r1]], r1, l2, r2);
        if(pos2[r2] - pos2[l2] <= 1) {
            // cod(2);
            lp(i, l2, r2) {
                for(auto u : e2[i]) {
                    int t = lower_bound(e1[u].begin(), e1[u].end(), no1[l2]) - e1[u].begin();
                    if(!vis[u] && (t == e1[u].size() || t > r2)) ++ans, vis[u] = 1;
                }
                for(auto u : e2[i]) vis[u] = 1;
            }
        }
        else {
            // cod(3);
            ans += tans2[pos2[l2]][pos2[r2]][pos1[r1]] - tans2[pos2[l2]][pos2[r2]][pos1[l1]];
            lp(i, l2, R2[pos2[l2]]) {
                for(auto u : e2[i]) {
                    int t = lower_bound(e1[u].begin(), e1[u].end(), no1[l2]) - e1[u].begin();
                    if(!vis[u] && (t == e1[u].size() || t > r2)) ++ans, vis[u] = 1;
                }
            }
            lp(i, L2[pos2[r2]], r2) {
                for(auto u : e2[i]) {
                    int t = lower_bound(e1[u].begin(), e1[u].end(), no1[l2]) - e1[u].begin();
                    if(!vis[u] && (t == e1[u].size() || t > r2)) ++ans, vis[u] = 1;
                }
                for(auto u : e2[i]) vis[u] = 1;
            }
        }
    }
    return ans;
}

vector<int> te1[N], te2[N];
signed main() {
    freopen("kauru.in", "r", stdin);
    freopen("kauru.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    m = read(), q = read(), typ = read();
    int u, v;
    lp(i, 1, m) u = read(), v = read(), e1[u].pb(v), e2[v].pb(u);
    init(e1, n1, no1, trs1, T1, L1, R1, pos1, cnt1), init(e2, n2, no2, trs2, T2, L2, R2, pos2, cnt2);
    
    lp(i, 1, n1) if(trs1[i]) for(int j = 0; j < e1[trs1[i]].size(); ++j) te1[i].pb(no2[e1[trs1[i]][j]]);
    lp(i, 1, n2) if(trs2[i]) for(int j = 0; j < e2[trs2[i]].size(); ++j) te2[i].pb(no1[e2[trs2[i]][j]]);
    lp(i, 1, n1) {
        e1[i].clear();
        for(int j = 0; j < te1[i].size(); ++i) if(j == 0 || te1[i][j] != te1[i][j - 1]) e1[i].pb(te1[i][j]);
    }
    lp(i, 1, n2) {
        e2[i].clear();
        for(int j = 0; j < te2[i].size(); ++i) if(j == 0 || te2[i][j] != te2[i][j - 1]) e2[i].pb(te2[i][j]);
    }
    // cod(R1[1] - L1[1] + 1), cod(R2[1] - L2[1] + 1);
    lp(i, 1, T2) {
        mst(sum, 0), mst(prs, 0);
        lp(j, i, T2) {
            lp(k, L2[pos2[j]], R2[pos2[j]]) for(auto u : e2[k]) prs[pos1[u]] += sum[u]? 0 : 1, /* co(i), co(j), co(u), co(k), cod(sum[u]),  */sum[u] |= 1;
            lp(k, 1, T1) tans1[i][j][k] = prs[k] + tans1[i][j][k - 1]/* , co(i), co(j), co(k), cod(tans1[i][j][k]) */;
        }
    }
    lp(i, 1, T1) {
        mst(sum, 0), mst(prs, 0);
        lp(j, i, T1) {
            lp(k, L1[pos1[j]], R1[pos1[j]]) for(auto u : e1[k]) prs[pos2[u]] += sum[u]? 0 : 1, sum[u] |= 1;
            lp(k, 1, T2) tans2[i][j][k] = prs[k] + tans2[i][j][k - 1];
        }
    }
    int l1, r1, l2, r2, ans = 0;
    while(q--) {
        l1 = read(), r1 = read(), l2 = read(), r2 = read();
        l1 ^= ans * typ, r1 ^= ans * typ, l2 ^= ans * typ, r2 ^= ans * typ;
        l1 = lower_bound(trs1 + 1, trs1 + 1 + cnt1, l1) - trs1, r1 = lower_bound(trs1 + 1, trs1 + 1 + cnt1, r1 + 1) - trs1 - 1;
        l2 = lower_bound(trs2 + 1, trs2 + 1 + cnt2, l2) - trs2, r2 = lower_bound(trs2 + 1, trs2 + 1 + cnt2, r2 + 1) - trs2 - 1, ans = 0;
        // co(l1), co(r1), co(l2), cod(r2);
        ans += calc(l1, l2, r1, r2, e1, e2, T1, L1, R1, pos1, T2, L2, R2, pos2, tans1, tans2);
        ans += calc(l2, l1, r2, r1, e2, e1, T2, L2, R2, pos2, T1, L1, R1, pos1, tans2, tans1);
        printf("%d\n", ans);
    }
    return 0;
}