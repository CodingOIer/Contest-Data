#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=1e5+2;
int n,K;
long long m;
long long L[maxn],R[maxn];
struct node{
    long long v,w;
}o[maxn];
priority_queue<long long>q;
bool cmp(node &A,node &B){
    return A.w<B.w;
}
int main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    memset(L,0x3f,sizeof(L));
    memset(R,0x3f,sizeof(R));
    n=read(),m=read(),K=read();
    for(int i=1;i<=n;i++)o[i].v=read(),o[i].w=read();
    long long ans=-1,sum=0;
    sort(o+1,o+n+1,cmp);
    for(int i=n;i>=n-(K/2)+1;i--)sum+=o[i].v,q.push(o[i].v);
    for(int i=n-(K/2);i;i--){
        R[i]=sum;
        if(q.top()>o[i].v)sum-=q.top(),q.pop(),q.push(o[i].v),sum+=o[i].v;
    }
    sum=0;
    while(!q.empty())q.pop();
    for(int i=1;i<=K/2;i++)sum+=o[i].v,q.push(o[i].v);
    for(int i=K/2+1;i<=n;i++){
        L[i]=sum;
        if(q.top()>o[i].v)sum-=q.top(),q.pop(),q.push(o[i].v),sum+=o[i].v;
    }
    for(int i=n-K/2;i>=K/2+1;i--){
        if(L[i]+R[i]+o[i].v<=m){ans=o[i].w;break;}
    }
    printf("%lld\n",ans);
    return 0;
}