#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=1e3+2;
int T;
int n,m;
char A[maxn][maxn],B[maxn][maxn];
int pos[maxn];
bool need[maxn],cant[maxn],aru[maxn],ok[maxn];
void reinit(){
    memset(need,0,sizeof(need));
    memset(cant,0,sizeof(cant));
    memset(aru,0,sizeof(aru));
    memset(ok,0,sizeof(ok));
    return ;
}
int main(){
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    T=read();
    while(T--){
        reinit();
        n=read(),m=read();
        for(int i=1;i<=n;i++){
            scanf("%s",A[i]+1);
        }
        for(int i=1;i<=n;i++){
            scanf("%s",B[i]+1);
        }
        bool fl=1;
        for(int i=1;i<=n;i++){
            int num=0,f=1;
            for(int j=1;j<=m;j++){
                num+=(B[i][j]-'0');
                if(A[i][j]=='0'&&B[i][j]=='1')f=0;
            }
            if(num==1){
                pos[i]=-1;
                for(int j=1;j<=m;j++)if(B[i][j]=='1')pos[i]=j;
                if(aru[pos[i]]){fl=0;break;}
                if(!f)aru[pos[i]]=1,need[pos[i]]=1,ok[i]=0;
                else ok[i]=1;
            }
            else {
                if(!f){fl=0;break;}
                for(int j=1;j<=m;j++){
                    if(A[i][j]=='1'&&B[i][j]=='1')cant[j]=1;
                    if(A[i][j]=='1'&&B[i][j]=='0')need[j]=1;
                }
            }
        }
        if(!fl){printf("No\n");continue;}
        for(int i=1;i<=n;i++){
            if(!ok[i])continue;
            if(!cant[pos[i]])need[pos[i]]=1;
            else {
                for(int j=1;j<=m;j++)if(j!=pos[i]&&A[i][j]=='1')need[j]=1;
            }
        }
        for(int i=1;i<=m;i++)if(cant[i]&&need[i]){fl=0;break;}
        fl=0;
        for(int i=1;i<=m;i++){
            if(need[i]){
                for(int j=1;j<=n;j++)if(A[j][i]=='0')fl=1;
            }
        }
        printf("%s\n",(fl)?"Yes":"No");
    }
    return 0;
}