#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+100;
const int mod=1e9+7;
int n,m;
int L[maxn],R[maxn];
int dp[maxn][11][11][2];
int fac[maxn],inv_fac[maxn];
char s[maxn],t[maxn];
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void pre(){
    fac[0]=1;
    for(int i=1;i<=maxn-1;i++)fac[i]=1ll*i*fac[i-1]%mod;
    inv_fac[maxn-1]=f_pow(fac[maxn-1],mod-2);
    for(int i=maxn-1;i;i--)inv_fac[i-1]=1ll*i*inv_fac[i]%mod;
    return ;
}
int calc_C(int a,int b){
    if(a<0||b<0||a<b)return 0;
    return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
}
int calc(int a,int b){
    return calc_C(a+b-1,b-1);
}
int main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    scanf("%s",s+1);
    scanf("%s",t+1);
    n=strlen(s+1);
    m=strlen(t+1);
    pre();
    for(int i=m,j=n;i;i--,j--){
        if(j>0)L[i]=s[j]-'0';
        R[i]=t[i]-'0';
        // printf("%d",R[i]);
    }
    // putchar('\n');
    // for(int i=1;i<=m;i++)printf("%d ",L[i]);
    // printf("\n");
    int ans=0,mx=0,f=1;
    for(int i=1;i<=m;i++){
        if(R[i]<mx){f=0;break;}
        for(int j=mx;j<R[i];j++)upd(ans,calc(m-i,10-j));
        mx=R[i];
    }
    if(f)upd(ans,1);
    // printf("ans=%d\n",ans);
    dp[0][0][R[1]+1][1]=1;
    for(int i=1;i<=m;i++){
        for(int j=0;j<10;j++){
            for(int k=j;k<10;k++){
                for(int ty=0;ty<2;ty++){
                    if(ty&&j==L[i]&&L[i]==R[i])upd(dp[i][j][max(k,R[i+1]+1)][1],dp[i-1][j][k][ty]);
                    // else if(j<=L[i])upd(dp[i][j][k][0],dp[i-1][j][k][ty]);
                    for(int p=k;p<10;p++){
                        if(ty&&p==L[i]&&L[i]==R[i])upd(dp[i][p][R[i+1]+1][1],dp[i-1][j][k][ty]);
                        else if(p<=L[i])upd(dp[i][p][p][0],dp[i-1][j][k][ty]);
                    }
                }
            }
        }
    }
    // for(int i=0;i<=m;i++){
    //     for(int j=0;j<10;j++){
    //         for(int k=j;k<=10;k++){
    //             for(int ty=0;ty<2;ty++){
    //                 printf("dp[%d][%d][%d][%d] %d\n",i,j,k,ty,dp[i][j][k][ty]);
    //             }
    //         }
    //     }
    // }
    // printf("%d\n",ans);
    for(int i=0;i<10;i++){
        for(int k=0;k<=10;k++){
            for(int ty=0;ty<2;ty++)upd(ans,mod-dp[m][i][k][ty]);
        }
    }
    printf("%d\n",ans);
    return 0;
}