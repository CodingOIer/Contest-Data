#include<bits/stdc++.h>
using namespace std;
#define int long long
map<int,int>mp,mp2;
priority_queue<int>q;
signed main()
{
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	int T;
	cin >> T;
	while(T--)
	
	{
		puts("No");
	 } 
	return 0;
}
