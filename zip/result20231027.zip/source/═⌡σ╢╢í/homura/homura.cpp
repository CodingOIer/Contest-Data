#include<bits/stdc++.h>
using namespace std;
#define int long long
map<int,int>mp,mp2;
priority_queue<int>q;
signed main()
{
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	int l,r;
	cin >>l >> r;
	int ans=0;
//	int lastans=1;
	for ( int i = l ; i <= r ; i++ )
	{
		int k=i;
		while(k)
		{
			if(k%10)
			{
				q.push(-(k%10));
			}
			k/=10;
		}
		int cnt=0;
		while(!q.empty())
		{
			cnt=cnt*10-q.top();
			q.pop();
		}
		if(mp[cnt]==0)
		{
			mp[cnt]=1;
			ans++;
		}
	}
	cout << ans;
	return 0;
}
