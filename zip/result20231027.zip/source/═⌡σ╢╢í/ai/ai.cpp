#include<bits/stdc++.h>
using namespace std;
#define int long long
struct abc{
	int a,b;
}a[100010];
int cmp(abc p,abc q)
{
	return p.b<q.b;
}
priority_queue<int>q; 
int ansl[100010],ansr[100010];
signed main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	int n,m,k;
	cin >> n >> m >> k;
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i].a >> a[i].b;
	}
	sort(a+1,a+n+1,cmp);
	if(k==1)
	{
		int mx=-1;
		for ( int i = 1 ; i <= n ; i++ )
		{
			if(a[i].a<=m)
			{
				mx=max(mx,a[i].b);
			}
		}
		cout << mx;
		//subtask;
		return 0;
	}
	int s=0;
	for ( int i = 1 ; i <= k/2 ; i++ )
	{
		q.push(a[i].a);
		s+=a[i].a;
	}
	for ( int i = k/2+1 ; i <= n ; i++ )
	{
		ansl[i]=s;
		//�ұ������С��k/2����+��������С��k/2����
		q.push(a[i].a);
		s+=a[i].a;
		s-=q.top();
		q.pop(); 
	}
	while(!q.empty())
	{
		q.pop();
	}
	s=0;
	for ( int i = n ; i >= n-(k/2)+1 ; i-- )
	{
		q.push(a[i].a);
		s+=a[i].a;
	}
	for ( int i = n-(k/2) ; i >= 1 ; i-- )
	{
		ansr[i]=s;
		q.push(a[i].a);
		s+=a[i].a;
		s-=q.top();
		q.pop();
	}
	int mx=-1;
	for ( int i = (k/2)+1 ; i <= n-(k/2) ; i++ )
	{
		if(ansl[i]+ansr[i]+a[i].a<=m)
		{
			mx=max(mx,a[i].b);
		}
	}
	cout << mx<<endl;
	return 0;
}
