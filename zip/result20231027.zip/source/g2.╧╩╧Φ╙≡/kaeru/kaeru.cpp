#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=5e5+10,M=N*40;
bool Begin;
int n=5e5,m,q,type,tot[N];
bool subtask=1;
vector<int>a[N][2];
bool End;
int main()
{
    freopen("kaeru.in","r",stdin);
    freopen("kaeru.out","w",stdout);
    cerr<<(&Begin-&End)/1024/1024<<"MB\n";
    m=read(),q=read(),type=read();
    for(int i=1,u,v;i<=m;i++)
    {
        u=read(),v=read(),
        a[u][0].push_back(v),a[v][1].push_back(u);
        ++tot[u];
    }
    for(int i=1;i<=n;i++) tot[i]+=tot[i-1];
    int l1,r1,l2,r2,ans=0;
    while(q--)
    {
        l1=read()^ans,r1=read()^ans,l2=read()^ans,r2=read()^ans;
        if(r1>r2) swap(l1,l2),swap(r1,r2);
        if(l1>l2) ans=tot[r1]-tot[l1-1];
        else if(r1<l2) ans=0;
        else ans=tot[r1]-tot[l2-1];
        printf("%d\n",ans);
        ans*=type;
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
