#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e5+10;
struct ok{
    int v,w;
    bool operator <(const ok &A) const{return v==A.v?w<A.w:v<A.v;}
}a[N];
int n,m,k,ans=-1,b[N];
ll tot1,tot2;
multiset<int>s1,s2,s3;
multiset<int>::iterator it;
int main()
{
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    memset(b,-1,sizeof(b));
    scanf("%d%d%d",&n,&m,&k);k/=2;
    for(int i=1;i<=n;i++) scanf("%d%d",&a[i].w,&a[i].v);
    if(!k)
    {
        for(int i=1;i<=n;i++)
            ans=max(ans,a[i].v);
        printf("%d\n",ans);
        return 0;
    }
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++) s2.insert(a[i].w),tot2+=a[i].w;
    while((int)s2.size()>k)
        it=s2.end(),--it,s3.insert(*it),tot2-=(*it),s2.erase(it);
    for(int i=1,T;i<=n;i=T)
    {
        T=i;
        while(a[i].v==a[T].v) ++T;
        // cerr<<i<<" "<<T<<endl;
        for(int j=i;j<T;j++)
            if((it=s3.find(a[j].w))!=s3.end()) s3.erase(it);
            else it=s2.find(a[j].w),assert(it!=s2.end()),tot2-=(*it),s2.erase(it);
        while((int)s2.size()<k&&!s3.empty())
            it=s3.begin(),s2.insert(*it),tot2+=(*it),s3.erase(it);
        for(int j=i+1;j<T;j++)
        {
            if((int)s1.size()<k)
                {b[j]=0,s1.insert(a[j].w),tot1+=a[j].w;continue;}
            if((int)s2.size()<k)
                {b[j]=2e9+10,s2.insert(a[j].w),tot2+=a[j].w;continue;}
            auto it1=s1.end(),it2=s2.end();
            --it1;--it2;
            if(a[j].w<max(*it1,*it2))
            {
                if((*it1)>(*it2))
                    b[j]=0,tot1-=(*it1),tot1+=a[j].w,s1.erase(it1),s1.insert(a[j].w);
                else
                    b[j]=*it2,tot2-=(*it2),tot2+=a[j].w,s2.erase(it2),s2.insert(a[j].w);
            }
            else if((*it1)>a[j].w)
                b[j]=0,tot1-=(*it1),tot1+=a[j].w,s1.erase(it1),s1.insert(a[j].w);
            else if((*it2)>a[j].w)
                b[j]=*it2,tot2-=(*it2),tot2+=a[j].w,s2.erase(it2),s2.insert(a[j].w);
        }
        // cout<<tot1<<" "<<tot2<<endl;
        if(tot1+tot2+a[i].w<=m&&(int)s1.size()==k&&(int)s2.size()==k) ans=a[i].v;
        for(int j=i;j<T;j++)
            if(!~b[j]) s1.insert(a[j].w),tot1+=a[j].w;
            else if(b[j])
            {
                s1.insert(a[j].w);tot1+=a[j].w;
                it=s2.find(a[j].w),tot2-=(*it),s2.erase(it);
                if(b[j]!=2e9+10) s2.insert(b[j]),tot2+=b[j];
            }
        while((int)s1.size()>k)
            it=s1.end(),--it,tot1-=(*it),s1.erase(it);
    }
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}