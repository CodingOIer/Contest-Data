#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
const int N=25,mod=1e9+7;
int T,T1,T2,a[N],b[N],numl[N],numr[N];
ull l,r,ans;
bool check()
{
	for(int i=numl[T2]+1;i<numr[T2];i++) if(a[i]) return 1;
	int Mx=9,Mn=0;
	if(!a[numl[T2]]) goto L;
	for(int i=0;i<10;i++) b[i]=a[i];
	--b[numl[T2]];
	while(~Mx&&!b[Mx]) Mx--;
	for(int i=T2-1;i;i--)
	{
		if(Mx>numl[i]) return 1;
		if(Mx<numl[i]) goto L;
		--b[Mx];
		while(~Mx&&!b[Mx]) Mx--;
	}
	return 1;
L:	if(!a[numr[T2]]) return 0;
	for(int i=0;i<10;i++) b[i]=a[i];
	--b[numr[T2]];
	while(Mn<10&&!b[Mn]) Mn++;
	for(int i=T2-1;i;i--)
	{
		if(Mn>numr[i]) return 0;
		if(Mn<numr[i]) return 1;
		--b[Mn];
		while(~Mn&&!b[Mn]) Mn++;
	}
	return 1;
}
void dfs(int x,int rest)
{
	if(x==9)
		return a[x]=rest,ans+=check(),void();
	for(int i=0;i<=rest;i++) a[x]=i,dfs(x+1,rest-i);
}
int main()
{
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	cin>>l>>r;
	T1=T2=ans=0;
	while(l) numl[++T1]=l%10,l/=10;
	while(r) numr[++T2]=r%10,r/=10;
	for(int i=T1+1;i<N;i++) numl[i]=0;
	for(;T2&&numl[T2]==numr[T2];T2--);
	if(!T2) return puts("1"),0;
	dfs(0,T2);
	cout<<ans%mod<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
