#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int T,n,m;
bool tx[N],ty[N];
char a[N][N],b[N][N];
int main()
{
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    scanf("%d",&T);
L:  while(T--)
    {
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;i++) tx[i]=0;
        for(int i=1;i<=m;i++) ty[i]=0;
        for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
        for(int i=1;i<=n;i++) scanf("%s",b[i]+1);
        int T1=0,T2=0,T3=0;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                T1+=(a[i][j]=='1'),T2+=(b[i][j]=='1');
        if(T1&&!T2) {puts("No");goto L;}
        for(int i=1;i<=n;i++)
        {
            int num1=0;
            for(int j=1;j<=m;j++) num1+=(b[i][j]^48);
            if(num1<2) tx[i]=1;
        }
        for(int i=1;i<=m;i++)
        {
            int num1=0;
            for(int j=1;j<=n;j++) num1+=(b[j][i]^48);
            if(num1<2) ty[i]=1;
        }
        T1=T2=T3=0;
        for(int i=1;i<=n;i++) if(tx[i]) T1=1;
        for(int i=1;i<=m;i++) if(ty[i]) T1=1;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                if(tx[i]&&ty[j]) T2|=(a[i][j]=='0'),T3|=(b[i][j]=='1');
        if(T1&&(!T2||!T3))
        {
            for(int i=1;i<=n;i++)
                if(tx[i]) for(int j=1;j<=m;j++) if(a[i][j]!=b[i][j]) {puts("No");goto L;}
            for(int i=1;i<=m;i++)
                if(ty[i]) for(int j=1;j<=n;j++) if(a[j][i]!=b[j][i]) {puts("No");goto L;}
        }
        for(int i=1;i<=n;i++)
            if(tx[i]) for(int j=1;j<=m;j++) a[i][j]=b[i][j];
        for(int i=1;i<=m;i++)
            if(ty[i]) for(int j=1;j<=n;j++) a[j][i]=b[j][i];
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                if(a[i][j]!=b[i][j]) {puts("No");goto L;}
        puts("Yes");
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
