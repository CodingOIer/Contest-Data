#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,M,K;
struct node{
    int v,w;
    bool operator <(const node &t)const{return w<t.w;}
}A[Maxn],B[Maxn];

bool cmp(node x,node y){return x.v<y.v;}

bool check(int p){
    if(p-1<K/2||N-p<K/2) return 0;
    int sum=0;
    sum+=A[p].v;
    sort(B+1,B+p,cmp); sort(B+p+1,B+N+1,cmp);
    For(i,1,K/2) sum+=B[i].v;
    For(i,p+1,p+K/2) sum+=B[i].v;
    For(i,1,N) B[i]=A[i];
    return sum<=M;
}

signed main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    N=read(),M=read(),K=read();
    For(i,1,N) A[i].v=B[i].v=read(),A[i].w=B[i].w=read();
    sort(A+1,A+N+1);
    int l=1,r=N,Ans=-1;
    while(l<=r){
        if(check(mid)) Ans=mid,l=mid+1;
        else r=mid-1;
    }
    write(A[Ans].w);
    return 0;
}
/*
g++ ai.cpp -o ai -O2
./ai
*/