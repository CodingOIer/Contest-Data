#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=5e5+10,Mx=5e5;
int M,Q,type,lst;
bool Vis[Maxn];
vector<int> E[Maxn];

int main(){
    freopen("kaeru.in","r",stdin);
    freopen("kaeru.out","w",stdout);
    M=read(),Q=read(),type=read();
    For(i,1,M){
        int u=read(),v=read();
        E[u].pb(v);
    }
    For(i,1,Mx) sort(E[i].begin(),E[i].end());
    while(Q--){
        int a=read()^lst,b=read()^lst,c=read()^lst,d=read()^lst;
        int Ans=0;
        For(i,a,b){
            bool ff=0;
            For(j,0,(int)E[i].size()-1){
                if(E[i][j]<c) continue;
                if(E[i][j]>d) break;
                ff=1;
                Vis[E[i][j]]=1;
            }
            if(!ff) ++Ans;
        }
        For(i,c,d){
            if(!Vis[i]) ++Ans;
            Vis[i]=0;
        }
        Ans=(b-a+1)+(d-c+1)-Ans;
        write(Ans),pc('\n'),lst=Ans*type;
    }
    return 0;
}
/*
g++ kaeru.cpp -o kaeru -O2
./kaeru
*/