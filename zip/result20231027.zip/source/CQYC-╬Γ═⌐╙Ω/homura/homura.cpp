#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int P=1e9+7;
int l,r,Ans,L[30],R[30],t1,t2,Num[21];

bool check(int p,bool lim1,bool lim2){
    if(!p||(!lim1&&!lim2)) return 1;
    int tl=lim1?L[p]:0,tr=lim2?R[p]:9;
    For(i,tl,tr){
        if(!Num[i]) continue;
        --Num[i];
        bool f=check(p-1,lim1&(L[p]==i),lim2&(R[p]==i));
        ++Num[i];
        if(f) return 1;
    }
    return 0;
}

void DFS(int x,int v){
    if(x==9){
        Num[x]=v;
        if(check(t1,1,1)) ++Ans;
        return;
    }
    For(i,0,v) Num[x]=i,DFS(x+1,v-i);
}

signed main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    l=read(),r=read(); t1=t2=Ans=0;
    while(l) L[++t1]=l%10,l/=10;
    while(r) R[++t2]=r%10,r/=10;
    if(t1<t2) swap(t1,t2);
    DFS(0,t1);
    write(Ans%P),pc('\n');
    return 0;
}
/*
g++ homura.cpp -o homura -O2
./homura
*/