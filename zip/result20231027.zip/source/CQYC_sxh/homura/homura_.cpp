#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline i64 read() {
	i64 x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 1e9 + 7;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


char qqq;

const int N = 1e5 + 1000;
int n, m, L[N], R[N], p[10][10], o; char s[N];
int f[1 << 10][2][2][3], g[1 << 10][2][2][3], ans;

char qqqq;

signed main() {
	freopen("homura.in", "r", stdin);
	freopen("homura.out", "w", stdout);
	// cerr << (&qqq-&qqqq) / 1024.0 / 1024.0 << '\n';

    For(i, 0, 9) For(j, i, 9) For(k, i, j) p[i][j] |= 1 << k; ; o = p[0][9];
    scanf("%s", s), m = strlen(s), n = max(n, m); 
    reverse(s, s + m); For(i, 0, m - 1) L[i] = s[i] - '0';
    scanf("%s", s), m = strlen(s), n = max(n, m); 
    reverse(s, s + m); For(i, 0, m - 1) R[i] = s[i] - '0';

    Rof(i, n, 0) cout << L[i] <<" "; cout << '\n';
    Rof(i, n, 0) cout << R[i] <<" "; cout << '\n';
    f[o][1][1][0] = 1; Rof(i, n - 1, 0) {
        memcpy(g, f, sizeof g), memset(f, 0, sizeof f);
        For(j, 0, 1023) For(a, 0, 1) For(b, 0, 1) For(t, 0, 2) if (g[j][a][b][t]) {
            For(l, a * L[i], 9) if ((j >> l) & 1) { if (b && l > R[i]) break;
                if (!t) {
                    int to = j & (p[L[i]][l - 1] ^ o); if (!a) to = j & p[l][9];
                    cout << i <<" "<<bitset<10>(j)<<" "<<a<<" "<<b<<" "<<t<<" "<<l<<'\n';
                    cout << bitset<10>(to)<<" "<<0<<" "<<(a & (l == L[i]))<<" "<<(b & (l == R[i]))<<" "<<g[j][a][b][0]<<'\n';
                    add(f[to][a & (l == L[i])][b & (l == R[i])][0], g[j][a][b][0]);
                    if (a) {
                        cout << i <<" "<<bitset<10>(j)<<" "<<a<<" "<<b<<" "<<t<<" "<<l<<'\n';
                        int to = j & p[0][l];
                        cout << bitset<10>(to)<<" "<<1<<" "<<(a & (l == L[i]))<<" "<<(b & (l == R[i]))<<" "<<g[j][a][b][0]<<'\n';
                        add(f[to][a & (l == L[i])][b & (l == R[i])][1], g[j][a][b][0]);
                    }
                } else {
                    if (t == 1 && l > L[i]) break; int to = j & p[0][L[i]];
                    int to2 = (t == 1 && l == L[i]) ? 1 : 2;
                    cout << i <<" "<<bitset<10>(j)<<" "<<a<<" "<<b<<" "<<t<<" " <<l<<'\n';
                    cout << bitset<10>(to)<<" "<<to2<<" "<<(a & (l == L[i]))<<" "<<(b & (l == R[i]))<<" "<<g[j][a][b][0]<<'\n';
                    add(f[to][a & (l == L[i])][b & (l == R[i])][to2], g[j][a][b][t]);
                }
            }  
        }
    }
    For(i, 0, 1023) For(j, 0, 1) For(k, 0, 1) For(t, 0, 1) add(ans, f[i][j][k][t]);
    cout << ans;
    return 0;
}
