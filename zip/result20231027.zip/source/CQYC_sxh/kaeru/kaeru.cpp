#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


const int N = 5e5 + 100;

int m, q, type, lastans;
struct edge { int u, v; }e[N];
bool vis1[N], vis2[N];

namespace part1 {
    void solve() { 
        while (q--) {
            int a = read(), b =  read(), c = read(), d = read();
            if (type) a ^= lastans, b ^= lastans, c ^= lastans, d ^= lastans;
            For(i, 1, m) vis1[e[i].u] = vis2[e[i].v] = 0; lastans = 0;
            For(i, 1, m) if (e[i].u >= a && e[i].u <= b && e[i].v >= c && e[i].v <= d) {
                lastans += !vis1[e[i].u], vis1[e[i].u] = 1;
                lastans += !vis2[e[i].v], vis2[e[i].v] = 1;
            } cout << lastans << '\n';
        }
    }
}

int X[N], Y[N], len1, len2;
vector<int> ve1[N], ve2[N];

namespace part2 {
    void solve() {
        For(i, 1, m) {
            int x = lower_bound(X + 1, X + len1 + 1, e[i].u) - X; ve1[x].pb(e[i].v);
            int y = lower_bound(Y + 1, Y + len2 + 1, e[i].v) - Y; ve2[y].pb(e[i].u);
        }
        For(i, 1, len1) {
            sort(ve1[i].begin(), ve1[i].end());
            ve1[i].resize(unique(ve1[i].begin(), ve1[i].end()) - ve1[i].begin());
        }
        For(i, 1, len2) {
            sort(ve2[i].begin(), ve2[i].end());
            ve2[i].resize(unique(ve2[i].begin(), ve2[i].end()) - ve2[i].begin());
        }
        while (q--) {
            int a = read(), b =  read(), c = read(), d = read();
            if (type) a ^= lastans, b ^= lastans, c ^= lastans, d ^= lastans;
            lastans = 0; 

            // if (a == b) {
            //     int s = lower_bound(X + 1, X + len1 + 1, a) - X, k =  
            //     upper_bound(ve1[s].begin(), ve1[s].end(), d) -
            //     lower_bound(ve1[s].begin(), ve1[s].end(), c);
            //     if (!k) lastans = 0; else lastans = 1 + k;
            // } else {
                For(i, 1, len1) if (X[i] >= a && X[i] <= b) lastans += 
                    upper_bound(ve1[i].begin(), ve1[i].end(), d) != 
                    lower_bound(ve1[i].begin(), ve1[i].end(), c);
                For(i, 1, len2) if (Y[i] >= c && Y[i] <= d) lastans += 
                    upper_bound(ve2[i].begin(), ve2[i].end(), b) != 
                    lower_bound(ve2[i].begin(), ve2[i].end(), a);
            // }

            cout << lastans << '\n';
        }
    }
}

signed main() {
	freopen("kaeru.in", "r", stdin);
	freopen("kaeru.out", "w", stdout);
    m = read(), q = read(), type = read();
    For(i, 1, m) e[i] = {read(), read()};
    if (m <= 2000 && q <= 2000) part1::solve(), exit(0);
	For(i, 1, m) vis1[e[i].u] = vis2[e[i].v] = 1;
    For(i, 1, 5e5) if (vis1[i]) X[++len1] = i;
    For(i, 1, 5e5) if (vis2[i]) Y[++len2] = i;
    if (len1 <= 100 && len2 <= 100) part2::solve(), exit(0);
    part2::solve(), exit(0);
    return 0;
}
