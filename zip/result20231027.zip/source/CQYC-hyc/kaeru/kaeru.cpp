#include<bits/stdc++.h>
using namespace std;
const int NN=2004,MM=44,KK=1404;
bitset<NN>p1[NN][MM],p2[NN][MM],b1[MM][MM],b2[MM][MM];
int main()
{
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
	int n,q,type;
	scanf("%d%d%d",&n,&q,&type);
	for(int i=1;i<=n;i++)
	{
		int l,r;
		scanf("%d%d",&l,&r);
		p1[l][r/KK][r%KK]=p2[r][l/KK][l%KK]=1;
		b1[l/KK][r/KK][r%KK]=b2[r/KK][l/KK][l%KK]=1;
	}
	int lastans=0;
	while(q--)
	{
		int a,b,c,d;
		scanf("%d%d%d%d",&a,&b,&c,&d);
		a^=lastans*type,b^=lastans*type,c^=lastans*type,d^=lastans*type;
		bitset<NN>t1,t2;
		if(a/KK==b/KK)
			for(int i=a;i<=b;i++)
			{
				if(c/KK==d/KK)
				{
					for(int j=c;j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=1;
				}
				else
				{
					for(int j=c/KK+1;j<d/KK;j++)
						t1|=p1[i][j]<<j*KK;
					for(int j=c;j<KK*(c/KK+1);j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
					for(int j=KK*(d/KK);j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
				}
			}
		else
		{
			for(int i=a/KK+1;i<b/KK;i++)
				if(c/KK==d/KK)
				{
					for(int j=c;j<=d;j++)
						if(b1[i][j/KK][j%KK])
							t1[j]=1;
				}
				else
				{
					for(int j=c/KK+1;j<d/KK;j++)
						t1|=b1[i][j]<<j*KK;
					for(int j=c;j<KK*(c/KK+1);j++)
						if(b1[i][j/KK][j%KK])
							t1[j]=true;
					for(int j=KK*(d/KK);j<=d;j++)
						if(b1[i][j/KK][j%KK])
							t1[j]=true;
				}
			for(int i=a;i<KK*(a/KK+1);i++)
				if(c/KK==d/KK)
				{
					for(int j=c;j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=1;
				}
				else
				{
					for(int j=c/KK+1;j<d/KK;j++)
						t1|=p1[i][j]<<j*KK;
					for(int j=c;j<KK*(c/KK+1);j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
					for(int j=KK*(d/KK);j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
				}
			for(int i=KK*(b/KK);i<=b;i++)
				if(c/KK==d/KK)
				{
					for(int j=c;j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=1;
				}
				else
				{
					for(int j=c/KK+1;j<d/KK;j++)
						t1|=p1[i][j]<<j*KK;
					for(int j=c;j<KK*(c/KK+1);j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
					for(int j=KK*(d/KK);j<=d;j++)
						if(p1[i][j/KK][j%KK])
							t1[j]=true;
				}
		}
		if(c/KK==d/KK)
			for(int i=c;i<=d;i++)
			{
				if(a/KK==b/KK)
				{
					for(int j=a;j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=1;
				}
				else
				{
					for(int j=a/KK+1;j<b/KK;j++)
						t2|=p2[i][j]<<j*KK;
					for(int j=a;j<KK*(a/KK+1);j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
					for(int j=KK*(b/KK);j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
				}
			}
		else
		{
			for(int i=c/KK+1;i<d/KK;i++)
				if(a/KK==b/KK)
				{
					for(int j=a;j<=b;j++)
						if(b2[i][j/KK][j%KK])
							t2[j]=1;
				}
				else
				{
					for(int j=a/KK+1;j<b/KK;j++)
						t2|=b2[i][j]<<j*KK;
					for(int j=a;j<KK*(a/KK+1);j++)
						if(b2[i][j/KK][j%KK])
							t2[j]=true;
					for(int j=KK*(b/KK);j<=b;j++)
						if(b2[i][j/KK][j%KK])
							t2[j]=true;
				}
			for(int i=c;i<KK*(c/KK+1);i++)
				if(a/KK==b/KK)
				{
					for(int j=a;j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=1;
				}
				else
				{
					for(int j=a/KK+1;j<b/KK;j++)
						t2|=p2[i][j]<<j*KK;
					for(int j=a;j<KK*(a/KK+1);j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
					for(int j=KK*(b/KK);j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
				}
			for(int i=KK*(d/KK);i<=d;i++)
				if(a/KK==b/KK)
				{
					for(int j=a;j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=1;
				}
				else
				{
					for(int j=a/KK+1;j<b/KK;j++)
						t2|=p2[i][j]<<j*KK;
					for(int j=a;j<KK*(a/KK+1);j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
					for(int j=KK*(b/KK);j<=b;j++)
						if(p2[i][j/KK][j%KK])
							t2[j]=true;
				}
		}
		printf("%d\n",b-a+1-t1.count()+d-c+1-t2.count());
	}
	return 0;
}
