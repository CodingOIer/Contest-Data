#include<bits/stdc++.h>
using namespace std;
const int NN=1004;
char s[NN][NN],t[NN][NN];
bool vis1[NN],vis2[NN];
void solve()
{
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%s",s[i]+1);
	for(int i=1;i<=n;i++)
		scanf("%s",t[i]+1);
	for(int i=1;i<=n;i++)
		vis1[i]=false;
	for(int i=1;i<=m;i++)
		vis2[i]=false;
	for(int i=1;i<=n;i++)
	{
		int cnt=0;
		for(int j=1;j<=m;j++)
			if(t[i][j]=='1')
				cnt++;
		if(cnt>1)
		{
			vis1[i]=true;
			for(int j=1;j<=m;j++)
				if(t[i][j]=='1')
					vis2[j]=true;
		}
	}
	for(int i=1;i<=m;i++)
	{
		int cnt=0;
		for(int j=1;j<=n;j++)
			if(t[j][i]=='1')
				cnt++;
		if(cnt>1)
		{
			vis2[i]=true;
			for(int j=1;j<=n;j++)
				if(t[j][i]=='1')
					vis1[j]=true;
		}
	}
	bool flag=false;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(!vis1[i]&&!vis2[j]&&s[i][j]=='0')
				flag=true;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(vis1[i]&&vis2[j]&&s[i][j]!=t[i][j]||(vis1[i]||vis2[j])&&s[i][j]=='0'&&t[i][j]=='1'||s[i][j]=='1'&&t[i][j]=='0'&&!flag)
			{
				puts("No");
				return;
			}
	puts("Yes");
}
int main()
{
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
		solve();
	return 0;
}
