#include<bits/stdc++.h>
using namespace std;
namespace IOR{
	char ib[1<<22],ob[1<<20],*p1=ib,*p2=ib,*po=ob;
	void flush(){fwrite(ob,sizeof(char),po-ob,stdout);po=ob;}struct OC{~OC(){flush();};}Oc;
	char gc(){return p1==p2&&(p2=(p1=ib)+fread(ib,sizeof(char),sizeof(ib),stdin),p1==p2)?EOF:*p1++;}
	void pc(const char c){*po++=c;if(po-ob==sizeof(ob))flush();}
	void pt(const char *s){while(*s!='\0'){pc(*s);s++;}pc('\n');}
}
#define getchar IOR::gc
#define putchar IOR::pc
#define puts IOR::pt
namespace fastio{
	struct{template<typename T>operator T(){
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0){
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;
typedef __int128 ll;
vector<ll>t;
void dfs(int u,int last,ll now)
{
	if(now)
		t.push_back(now);
	if(u==19)
		return;
	for(int i=last;i<10;i++)
		dfs(u+1,i,now*10+i);
}
int main()
{
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	dfs(0,1,0);
	ll l=in,r=in;
	int cnt1=0,cnt2=0,s1[24]={0},s2[24]={0};
	ll x=l;
	while(x)
	{
		s1[++cnt1]=x%10;
		x/=10;
	}
	x=r;
	while(x)
	{
		s2[++cnt2]=x%10;
		x/=10;
	}
	int ans=0;
	for(int i=0;i<t.size();i++)
	{
		int cnt[24]={0};
		ll x=t[i];
		while(x)
		{
			cnt[x%10]++;
			x/=10;
		}
		int res=0;
		for(int k=0;k<10;k++)
			res+=cnt[k];
		cnt[0]=20-res;
		int u=20;
		bool flag=true;
		while(u&&s1[u]==s2[u])
		{
			if(!cnt[s1[u]])
			{
				flag=false;
				break;
			}
			cnt[s1[u]]--;
			u--;
		}
		if(!flag)
			continue;
		if(!u)
		{
			ans++;
			continue;
		}
		bool ok=false;
		int backup[24];
		memcpy(backup,cnt,sizeof(backup));
		for(int j=s1[u]+1;j<s2[u];j++)
			if(cnt[j])
			{
				ans++;
				ok=true;
				break;
			}
		if(ok)
			continue;
		if(cnt[s1[u]])
		{
			cnt[s1[u]]--;
			for(int j=u-1;j>=1;j--)
			{
				for(int k=s1[j]+1;k<10;k++)
					if(cnt[k])
					{
						ans++;
						ok=true;
						break;
					}
				if(ok)
					break;
				if(!cnt[s1[j]])
				{
					flag=false;
					break;
				}
				cnt[s1[j]]--;
			}
			if(flag&&!ok)
			{
				ans++;
				ok=true;
			}
		}
		if(ok)
			continue;
		memcpy(cnt,backup,sizeof(backup));
		flag=true;
		if(cnt[s2[u]])
		{
			cnt[s2[u]]--;
			for(int j=u-1;j>=1;j--)
			{
				for(int k=0;k<s2[j];k++)
					if(cnt[k])
					{
						ans++;
						ok=true;
						break;
					}
				if(ok)
					break;
				if(!cnt[s2[j]])
				{
					flag=false;
					break;
				}
				cnt[s2[j]]--;
			}
			if(flag&&!ok)
			{
				ans++;
				ok=true;
			}
		}
	}
	printf("%d",ans);
	return 0;
}
