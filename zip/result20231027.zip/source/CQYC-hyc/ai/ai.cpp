#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4;
int v[NN],w[NN];
int n,m,k;
bool check(int mid)
{
	multiset<int>st1,st2;
	for(int i=1;i<=n;i++)
	{
		st1.insert(v[i]);
		if(w[i]>=mid)
			st2.insert(v[i]);
	}
	long long res=0;
	for(int i=1;i<=(k+1)/2;i++)
	{
		if(!st2.size())
			return false;
		res+=*st2.begin();
		st1.erase(st1.find(*st2.begin()));
		st2.erase(st2.begin());
	}
	for(int i=1;i<=k/2;i++)
	{
		res+=*st1.begin();
		st1.erase(st1.begin());
	}
	return res<=m;
}
int main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int l=0,r=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&v[i],&w[i]);
		r=max(r,w[i]);
	}
	while(l<r)
	{
		int mid=l+(r-l+1)/2;
		if(check(mid))
			l=mid;
		else
			r=mid-1;
	}
	printf("%d",!l?-1:l);
	return 0;
}
