#include<bits/stdc++.h>
#define re register
#define int long long
#define mod 1000000007ll
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
int umod,cbf=1;
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57)
	{
		x=(x<<1)+(x<<3)+(ch^48);
		if(x>=mod) x%=mod,umod=1;
		if(!umod&&x>1e8) cbf=0;
		ch=getchar();
	}
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int l,r;
namespace bruteforce
{
	bitset<100000000> vis;
	inline void solve()
	{
		rep(i,l,r)
		{
			int x=0,y=0,j=i;
			while(j)
			{
				x=j%10;
				if(x) y=(y<<1)+(y<<3)+x;
				j/=10;
			}
			x=0;
			while(y) x=(x<<1)+(x<<3)+y%10,y/=10;
			vis.set(x);
		}
		write(vis.count());
	}
}
signed main()
{
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	read(l,r);
	if(cbf) bruteforce::solve();
	else write((r-l+mod)%mod);
	return 0; 
}
