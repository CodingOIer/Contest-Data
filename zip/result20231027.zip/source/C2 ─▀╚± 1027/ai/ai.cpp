#include<bits/stdc++.h>
#define re register
#define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,m,k,mid,cost,ans=-1;
struct node
{
	int val,wei;
}a[100001];
int num,tot,now,csd,bigmin,smallmin,dw[100001];
multiset<int> big,small;
// 2e9, use long long!!!
signed main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	read(n,m,k);
	num=1+k>>1;
	rep(i,1,n) read(a[i].wei,a[i].val),dw[i]=a[i].wei;
	sort(dw+1,dw+n+1);
	int minksum=0;
	rep(i,1,k) minksum+=dw[i];
	if(minksum>m) return puts("-1"),0;
	sort(a+1,a+n+1,[](node x,node y)
	{return x.val!=y.val?x.val>y.val:x.wei<y.wei;});
	rep(i,1,num-1) big.emplace(a[i].wei);
	csd=1;
	for(auto i:big)
	{
		if(csd>=num) break;
		now+=i;
		++csd;
	}
	rep(i,num+1,n) small.emplace(a[i].wei);
	csd=1;
	for(auto i:small)
	{
		if(csd>=num) break;
		tot+=i;
		++csd;
	}
	// ---
	set<int>::iterator It=big.begin();
	rep(_,1,num-2) ++It;
	bigmin=*It;
	It=small.begin();
	rep(_,1,num-2) ++It;
	smallmin=*It;
	// ---
	rep(i,num,n-num+1)
	{
		if(now+tot+a[i].wei<=m)
			return write(a[i].val),0;
		if(a[i].wei<bigmin)
		{
			now-=bigmin;
			now+=a[i].wei;
			big.emplace(a[i].wei);
			It=big.begin();
			rep(_,1,num-2) ++It;
			bigmin=*It;
		}
		small.erase(small.find(a[i+1].wei));
		if(a[i+1].wei<=smallmin)
		{
			tot-=smallmin;
			tot+=a[i+1].wei;
			It=small.begin();
			rep(_,1,num-2) ++It;
			smallmin=*It;
		}
	}
	if(now+tot+a[n-num+2].wei<=m)
		return write(a[n-num+2].val),0;
	puts("-1");
	return 0;
}
