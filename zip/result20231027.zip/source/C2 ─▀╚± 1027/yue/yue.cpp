#include<bits/stdc++.h>
#define re register
// #define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int T,n,m,c0a,c1a,c0b,c1b;
/*
 * If you don't clear in many test cases, you may get 0pts.
 * Duo ce bu qing kong, bao 0 liang hang lei.
 */
char a[1001][1001],b[1001][1001];
bool chk()
{
	rep(i,1,n)
	{
		int cg=0,all=0;
		rep(j,1,m) {if(a[i][j]!=b[i][j]) cg=1;all+=b[i][j]^48;}
		if(cg&&all>1) return 1;
	}
	return 0;
}
bool chk2()
{
	rep(j,1,m)
	{
		int cg=0,all=0;
		rep(i,1,n) {if(a[i][j]!=b[i][j]) cg=1;all+=b[i][j]^48;}
		if(cg&&all>1) return 1;
	}
	return 0;
}
signed main()
{
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	read(T);
	while(T--)
	{
		c0a=c1a=c0b=c1b=0;
		read(n,m);
		rep(i,1,n)rep(j,1,m)
		{
			while(!isdigit(a[i][j]=getchar()));
			c0a+=!(a[i][j]^48),c1a+=a[i][j]^48;
		}
		rep(i,1,n)rep(j,1,m)
		{
			while(!isdigit(b[i][j]=getchar()));
			c0b+=!(b[i][j]^48),c1b+=b[i][j]^48;
		}
		if(((!c0a)&&c0b)||c1b>c1a||chk()||chk2()) puts("No");
		else puts("Yes");
	}
	return 0; 
}
