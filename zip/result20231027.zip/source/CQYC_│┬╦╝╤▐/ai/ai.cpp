#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5;
int n,m,k,b[maxn],ans=-1;
struct node{
    int v,w;
}a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int cmp(node a,node b){
    return a.w<b.w;
}
signed main(){
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++)
        a[i].v=read(),a[i].w=read();
    sort(a+1,a+1+n,cmp);
    priority_queue<int> q;
    int sum=0;
    for(int i=1;i<=k/2;i++){
        q.push(a[i].v);
        sum+=a[i].v;
    }
    for(int i=k/2+1;i<=n-k/2;i++){
        b[i]=sum;
        if(q.top()>a[i].v){
            sum+=a[i].v-q.top();
            q.pop();
            q.push(a[i].v);
        }
    }
    while(!q.empty())
        q.pop();
    sum=0;
    for(int i=n;i>n-k/2;i--){
        q.push(a[i].v);
        sum+=a[i].v;
    }
    for(int i=n-k/2;i>=k/2+1;i--){
        if(b[i]+sum+a[i].v<=m){
            ans=a[i].w;
            break;
        }
        if(q.top()>a[i].v){
            sum+=a[i].v-q.top();
            q.pop();
            q.push(a[i].v);
        }
    }
    printf("%lld\n",ans);
    return 0;
}