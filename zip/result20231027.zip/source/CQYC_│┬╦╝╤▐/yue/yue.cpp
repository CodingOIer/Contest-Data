#include <bits/stdc++.h>
using namespace std;
int T,n,m,vis[1000005];
char s[1005][1005],t[1005][1005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int solve(int p){
    int bj=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++)
            if(s[i][j]!=t[i][j]){
                bj=1;
                break;
            }
        if(bj)
            break;
    }
    if(!bj)
        return 1;
    if(p>n*m)
        return 0;
    char k[n+5][m+5];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            k[i][j]=s[i][j];
    for(int i=1;i<=n*m;i++)
        if(!vis[i]){
            vis[i]=1;
            int x=(i-1)/m+1,y=(i-1)%m+1;
            for(int j=1;j<=n;j++)
                s[j][y]='0';
            for(int j=1;j<=m;j++)
                s[x][j]='0';
            s[x][y]='1';
            if(solve(p+1))
                return 1;
            vis[i]=0;
            for(int l=1;l<=n;l++)
                for(int r=1;r<=m;r++)
                    s[l][r]=k[l][r];
        }
    return 0;
}
signed main(){
    freopen("yue.in","r",stdin);
    freopen("yue.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        for(int i=1;i<=n;i++)
            scanf("%s",s[i]+1);
        for(int i=1;i<=n;i++)
            scanf("%s",t[i]+1);
        if(solve(1))
            puts("Yes");
        else
            puts("No");
    }
    return 0;
}