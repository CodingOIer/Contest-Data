#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5;
int ll,lr,a[10],b[10],ans,vis[maxn*10];
char l[maxn],r[maxn],s[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int check(){
    int cnt=0;
    for(int i=1;i<=9;i++)
        cnt+=a[i],b[i]=a[i];
    b[0]=maxn;
    if(cnt>lr)
        return 0;
    if(cnt>ll){
        if(cnt<lr)
            return 1;
        int x=0;
        for(int i=1;i<=9;i++)
            while(b[i])
                s[++x]=i+'0',b[i]--;
        for(int i=1;i<=lr;i++){
            if(s[i]>r[i])
                return 0;
            if(s[i]<r[i])
                return 1;
        }
        return 1;
    }
    int bj=0;
    for(int i=1;i<=lr;i++){
        if(b[r[i]-'0'])
            b[r[i]-'0']--,s[i]=r[i];
        else{
            for(int j=r[i]-'0'-1;j>=0;j--)
                if(b[j]){
                    s[i]=j+'0';
                    b[j]--;
                    bj=i;
                    break;
                }
        }
    }
    int bj1=0;
    for(int i=1;i<=lr;i++)
        if(s[i]!=r[i]){
            bj1=1;
            break;
        }
    if(!bj1)
        bj=lr;
    if(!bj)
        return 0;
    for(int i=9;i>=1;i--)
        while(b[i])
            s[++bj]=i+'0',b[i]--;
    while(bj<lr)
        s[++bj]='0';
    int be=1;
    while(s[be]=='0'&&be<bj)
        ++be;
    if(bj-be+1>ll)
        return 1;
    for(int i=1;i<=ll;i++){
        if(s[i+be-1]<l[i])
            return 0;
        if(s[i+be-1]>l[i])
            return 1;
    }
    return 1;
}
void solve(int x,int y){
    if(x>lr){
        if(check())
            ++ans;
        return;
    }
    for(int i=y;i<=9;i++){
        a[i]++;
        solve(x+1,i);
        a[i]--;
    }
}
signed main(){
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    scanf("%s%s",l+1,r+1);
    ll=strlen(l+1);
    lr=strlen(r+1);
    if(lr<=6){
        int x=0,y=0,ba=1;
        for(int i=ll;i;i--)
            x+=(l[i]-'0')*ba,ba*=10;
        ba=1;
        for(int i=lr;i;i--)
            y+=(r[i]-'0')*ba,ba*=10;
        for(int i=x;i<=y;i++){
            int t=0,k=i;
            while(k)
                a[++t]=k%10,k/=10;
            sort(a+1,a+1+t);
            for(int j=1;j<=t;j++)
                k=k*10+a[j];
            if(!vis[k])
                ++ans;
            vis[k]=1;
        }
        printf("%lld\n",ans);
        return 0;
    }
    a[0]=maxn;
    solve(1,0);
    printf("%lld\n",ans);
    return 0;
}