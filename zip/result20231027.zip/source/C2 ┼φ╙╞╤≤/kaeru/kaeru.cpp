#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 1e6+5;
int n,m,q,U[N],V[N],las,k;
vector<int> g[N],v; 
signed main()
{
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
	read(m),read(q),read(k);
	for(int i = 1;i<=m;i++)
		read(U[i]),read(V[i]),n = max({n,U[i],V[i]});
	for(int i = 1;i<=m;i++)
		g[U[i]].push_back(V[i]+n),g[V[i]+n].push_back(U[i]);
	for(int i = 1;i<=2*n;i++)
	{
		if(g[i].size()) v.push_back(i);
		sort(g[i].begin(),g[i].end());
	}
	while(q--)
	{
		int a,b,c,d;
		read(a),read(b),read(c),read(d);
		a^=(las*k),b^=(las*k),c^=(las*k),d^=(las*k);
		c+=n,d+=n;
		if(a==b)
		{
			if(g[a].size())
			{
				int l = lower_bound(g[a].begin(),g[a].end(),c)-g[a].begin(),r = upper_bound(g[a].begin(),g[a].end(),d)-g[a].begin()-1;
				if(r>=l) las = r-l+2;
				else las = 0;
			}
			else las = 0;
			writen(las);
			continue;
		}
		las = 0;
		int l = lower_bound(v.begin(),v.end(),a)-v.begin(),r = upper_bound(v.begin(),v.end(),b)-v.begin()-1;
		for(int i,j = l;j<=r;j++)
		{
			i = v[j];
			if(g[i][g[i].size()-1]>=c&&(*lower_bound(g[i].begin(),g[i].end(),c))<=d)
				las++;
		}
		l = lower_bound(v.begin(),v.end(),c)-v.begin(),r = upper_bound(v.begin(),v.end(),d)-v.begin()-1;
		for(int i,j = l;j<=r;j++)
		{
			i = v[j];
			if(g[i][g[i].size()-1]>=a&&(*lower_bound(g[i].begin(),g[i].end(),a))<=b)
				las++;
		}
		writen(las);
	}
	return 0;
}

