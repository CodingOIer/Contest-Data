#include <bits/stdc++.h>
#define int long long
#define x first
#define y second 
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 1e5+5;
int n,m,k,wz,lt,rt;
struct node{
	int v,w;
}a[N];
bool vis[N];
priority_queue<int> q1;
priority_queue<pair<int,int> > q2; 
inline bool cmp(node x,node y)
{
	return x.w>y.w;
}
signed main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	read(n),read(m),read(k);
	k/=2;
	for(int i = 1;i<=n;i++)
		read(a[i].v),read(a[i].w);
	sort(a+1,a+n+1,cmp);
	for(int i = 1;i<=k;i++)
		lt+=a[i].v,q1.push(a[i].v);
	for(int i = k+2;i<=n;i++)
		q2.push({-a[i].v,i});
	for(int i = 1;i<=k;i++)
		rt+=-q2.top().x,vis[q2.top().y] = 1,q2.pop();
	if(lt+rt+a[k+1].v<=m) return write(a[k+1].w),0;
	for(int i = k+2;i<=n-k;i++)
	{
		if(!q1.empty()&&a[i].v<q1.top()) lt-=q1.top(),lt+=a[i].v,q1.pop(),q1.push(a[i].v);
		if(vis[i])
		{
			rt-=a[i].v;
			while(!q2.empty()&&q2.top().y<=i) q2.pop();
			if(!q2.empty()) rt+=-q2.top().x,vis[q2.top().y] = 1,q2.pop();
		}
		if(lt+rt+a[i].v<=m) return write(a[i].w),0;
	}
	puts("-1");
	return 0;
}

