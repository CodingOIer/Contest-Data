#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 20 ;
int rip,Ri,val,ber ;
int T,n,tot,le,ri,pos1,pos2,ans ;
int a[N],b[N],ru[N],pw[N],rpp[N],vis[29] ;
multiset<int>s ;
inline int Find1(int x)
{
    FOR(i,x,9,1) if(vis[i]) return i ;
    return -1 ;
}
inline int Find2(int x)
{
    FOR(i,x+1,9,1) if(vis[i]) return i ;
    return -1 ;
}
void Check()
{
    int tot = 0 ;
    FOR(i,1,9,1) tot += ru[i] ;
    if(tot > pos2 || !tot) return ; ru[0] = max(0ll,pos1-tot) ; me(rpp,0),me(vis,0) ; //s.clear() ;
    FOR(i,0,9,1) vis[i] += ru[i] ; if(pos2-max(tot,pos1) >= 2) {++ans ; return ;}
    int chk = 0,nm = 0 ; val = 0 ; //print(tot),enter ;
    //要素:x>=le,且非0位全部用完，且<=ri
    ROF(i,max(tot,pos1),1,1)
    {
        if(!chk)
        {
            int val1 = Find1(a[i]) ;
            int val2 = Find2(a[i]) ;
            if(~val2) rpp[i] = 1 ;
            if(val1 == -1) {nm = 1 ; break ;}
            if(val1 == a[i]) val += a[i]*pw[i-1],--vis[val1] ;
            else chk = 1,val += val1*pw[i-1],--vis[val1] ;
        }
        else 
        {
            int val1 = Find1(0) ;
            val += val1*pw[i-1],vis[val1]-- ;
        }
    }
    if(nm)
    {
        int ahh = 0,las = 0 ;
        FOR(i,1,max(pos1,tot),1) if(rpp[i]) {ahh = 1,las = i ; break ;}
        if(!ahh)
        {
            // FOR(i,0,9,1) FOR(j,1,ru[i],1) s.insert(i) ;
            FOR(i,0,9,1) vis[i] = ru[i] ; ++vis[0] ;
            chk = 0,val = 0 ; //s.insert(0) ;
            ROF(i,max(tot,pos1)+1,1,1)
            {
                if(!chk)
                {
                    int val1 = Find2(a[i]) ;
                    chk = 1,val += val1*pw[i-1],--vis[val1] ;
                }
                else 
                {
                    int val1 = Find1(0) ;
                    val += val1*pw[i-1],--vis[val1] ;
                }
            }
        }
        else
        { //cout<<"?" ;
            FOR(i,0,9,1) vis[i] = ru[i] ;
            chk = 0 ; val = 0 ; int pd = 0 ;
            ROF(i,max(tot,pos1),1,1)
            {
                if(!chk)
                {
                    int val1 = Find1(a[i]) ;
                    if(i == las) val1 = Find2(a[i]) ;
                    if(val1 == a[i]) val += a[i]*pw[i-1],vis[val1]-- ;
                    else chk = 1,val += val1*pw[i-1],vis[val1]-- ;
                }
                else 
                {
                    int val1 = Find1(0) ;
                    val += val1*pw[i-1],vis[val1]-- ;
                }
            }
        }
    }
    if(val <= Ri) ++ans ;
}
void Dfs(int x,int sum)
{
    if(!sum) {Check() ; return ;}
    if(x == 10) {Check() ; return ;}
    FOR(i,0,sum,1) ru[x] = i,Dfs(x+1,sum-i),ru[x] = 0 ;
}
void Solve()
{
    ans = 0 ;
    read(le,ri),pos1 = pos2 = 0,me(a,0),me(b,0),Ri = ri ;
    while(le) a[++pos1] = le%10,le /= 10 ;// ROF(i,pos1,1,1) cout<<a[i] ; enter
    while(ri) b[++pos2] = ri%10,ri /= 10 ; Dfs(1,pos2+1),print(ans),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("homura.in","r",stdin) ;
	freopen("homura.out","w",stdout) ;
    pw[0] = 1 ; FOR(i,1,18,1) pw[i] = pw[i-1]*10 ;//,print(pw[i]),enter ;
    Solve() ; //cerr<<clock()/1000.0 ;
    return 0 ;
}