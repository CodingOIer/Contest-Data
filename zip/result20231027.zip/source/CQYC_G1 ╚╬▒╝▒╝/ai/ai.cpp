#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e5+5 ;
int n,m,k,cnt ;
struct Sub{int v,w,wi ;}a[N] ;
vector<Sub>A,B ;
int cmp(Sub x,Sub y)
{
    return x.v < y.v ;
}
int Check(int mid)
{
    A.clear(),B.clear() ;
    FOR(i,1,n,1) a[i].wi = a[i].w>=mid?1:-1 ;
    FOR(i,1,n,1) if(a[i].wi > 0) A.pb(a[i]) ; else B.pb(a[i]) ;
    sort(A.begin(),A.end(),cmp),sort(B.begin(),B.end(),cmp) ;
    int p = 0,top = -1,cnt = 0 ;
    for(auto [v,w,wi]:A)
    {
        // print(v),enter ;
        if(p+v <= m) p += v,++top ;
        else break ;
    }//print(top+1),enter ;
    if(top == -1) return 0 ; if(top+1 >= k) return 1 ; 
    while(top != -1)
    {
        while(cnt < B.size() && p+B[cnt].v <= m && top+1+cnt+1 <= k) p += B[cnt].v,++cnt ; //print(top+1,cnt),enter ;
        if(top+1+cnt == k && top+1-cnt > 0) return 1 ; if(top+1-cnt <= 0) return 0 ; p -= A[top].v,--top ;
    }
    return 0 ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("ai.in","r",stdin) ;
	freopen("ai.out","w",stdout) ;
    read(n,m,k) ;
    FOR(i,1,n,1) read(a[i].v,a[i].w) ;
    int le = 0,ri = 1e9,res = -1 ;
    while(le <= ri)
    {
        int mid = le+ri>>1 ; //print(le,ri),enter ;
        if(Check(mid)) res = mid,le = mid+1 ;
        else ri = mid-1 ;
    }
    print(res),enter ;
    return 0 ;
}