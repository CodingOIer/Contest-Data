#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
const int N = 5e4+5 ;
const int M = 5e5+5 ;
const int B = 320 ;
const int L = N/B ;
int m,q,ty,l1,l2,n,las ;
int a[N],b[N],U[N],V[N],bl[N],br[N],in[N] ;
vector<int>e[2][N] ;
bitset<B+2>f[2][L][L][L],g[2][2][L][L][L],rp1[B],rp2[B] ;
map<int,int>mp1,mp2 ;
void Init(int op)
{
    FOR(i,1,n,1) 
    {
        FOR(j,1,n,1) 
        {
            FOR(k,bl[j],br[j],1)
            {
                for(auto v:e[op^1][k]) if(bl[i] <= v && v <= br[i])
                    f[op][i][j][j][v-bl[i]] = 1,g[op][0][i][j][k][v-bl[i]] = g[op][1][i][j][k][v-bl[i]] = 1 ;
            }
            FOR(k,bl[j]+1,br[j],1) g[op][0][i][j][k] |= g[op][0][i][j][k-1] ;
            ROF(k,br[i]-1,bl[i],1) g[op][1][i][j][k] |= g[op][1][i][j][k+1] ;
        }
        FOR(j,1,n,1) FOR(k,j+1,n,1) f[op][i][j][k] = f[op][i][j][k-1]|f[op][i][k][k] ;
    }
}
bool S_GND ;
int query(int op,int le,int ri,int L2,int R2)
{
    bitset<B+2> genshin ; int id = in[le] ;
    int A = in[le]+(le!=bl[in[le]]) ;
    int B = in[ri]-(ri!=br[in[ri]]) ;
    if(A <= B) genshin |= f[op][id][A][B] ;
    genshin |= g[op][1][id][in[le]][le]|g[op][0][id][in[ri]][ri] ;
    genshin &= rp1[le],genshin &= rp2[ri] ; return genshin.count() ;
}
int ask(int op,int id,int le,int ri)
{
    bitset<B+2> genshin ;
    int A = in[le]+(le!=bl[in[le]]) ;
    int B = in[ri]-(ri!=br[in[ri]]) ;
    if(A <= B) genshin |= f[op][id][A][B] ;
    genshin |= g[op][1][id][in[le]][le]|g[op][0][id][in[ri]][ri] ;
    return genshin.count() ;
}
int Query(int op,int le,int ri,int L2,int R2)
{
    int res = 0 ;
    if(in[L2] == in[R2])
    {
        FOR(i,L2,R2,1) 
        {
            // int pos1 = lower_bound(e[op^1][i].begin(),e[op^1][i].end(),le)-e[op^1][i].begin() ;
            // int pos2 = upper_bound(e[op^1][i].begin(),e[op^1][i].end(),ri)-e[op^1][i].begin() ;
            // res += pos2-pos1 ; //print(pos2,pos1),enter ;
            // for(auto v:e[op^1][i]) if(le <= v && v <= ri) ++res ;
        }
        return res ;
    }
    else
    {
        if(in[le] == in[ri]) res = query(op,le,ri,L2,R2) ;
        else
        {
            int A = in[le]+(le!=bl[in[le]]) ;
            int B = in[ri]-(ri!=br[in[ri]]) ;
            if(A <= B) FOR(i,A,B,1) res += ask(op,i,L2,R2) ;
            if(le != bl[in[le]]) res += query(op,le,br[in[le]],L2,R2) ;
            if(ri != br[in[ri]]) res += query(op,bl[in[ri]],ri,L2,R2) ;
        }
        return res ;
    }
}
void Solve()
{
    int L1,R1,L2,R2 ; read(L1,R1,L2,R2) ; int val = las*ty ;
    L1 ^= val,L2 ^= val,R1 ^= val,R2 ^= val ;
    int AAA = L1,BBB = R1,CCC = L2,DDD = R2 ;
    L1 = lower_bound(a+1,a+1+l1,L1)-a,R1 = upper_bound(a+1,a+1+l1,R1)-a-1 ;
    L2 = lower_bound(b+1,b+1+l2,L2)-b,R2 = upper_bound(b+1,b+1+l2,R2)-b-1 ;
    // print(L1,R1,L2,R2),enter ;
    int res = Query(0,L1,R1,L2,R2)+Query(1,L2,R2,L1,R1) ; print(BBB-AAA+DDD-CCC+2-res),enter ;
}
signed main()
{
// cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("kaeru.in","r",stdin) ;
	freopen("kaeru.out","w",stdout) ;
    // cerr<<(sizeof(f)+sizeof(g))/1024/1024 ;
    read(m,q,ty) ;
    FOR(i,1,m,1)
    {
        read(U[i],V[i]) ;
        a[i] = U[i],b[i] = V[i] ;
    }
    sort(a+1,a+1+m),sort(b+1,b+1+m) ;
    l1 = unique(a+1,a+1+m)-a-1,l2 = unique(b+1,b+1+m)-b-1 ;
    FOR(i,1,m,1) mp1[U[i]] = lower_bound(a+1,a+1+l1,U[i])-a,U[i] = lower_bound(a+1,a+1+l1,U[i])-a ;
    FOR(i,1,m,1) mp2[V[i]] = lower_bound(b+1,b+1+l1,V[i])-b,V[i] = lower_bound(b+1,b+1+l1,V[i])-b ;
    // FOR(i,1,m,1) print(U[i]) ; enter ;
    // FOR(i,1,m,1) print(V[i]) ; enter ;
    FOR(i,1,m,1) e[0][U[i]].pb(V[i]),e[1][V[i]].pb(U[i]) ;
    n = m/B+(m%B>0) ;
    FOR(i,1,n,1) bl[i] = (i-1)*B+1,br[i] = min(m,i*B) ;
    FOR(i,1,n,1) FOR(j,bl[i],br[i],1) in[j] = i ;
    FOR(i,1,B,1) rp1[0][i] = 1 ;
    FOR(i,1,B,1) rp2[n][i] = 1 ;
    FOR(i,1,B,1) rp1[i] = rp1[i-1],rp1[i][i-1] = 0 ;
    ROF(i,B-1,1,1) rp2[i] = rp2[i+1],rp2[i][i+1] = 0 ;
    Init(0),Init(1) ; while(q--) Solve() ;
    return 0 ;
}