#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=1e6+7;
ll l,r,ans,d[7];
bool b[Maxn];

int main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	scanf("%lld%lld",&l,&r);
	for(ll i=l;i<=r;i++){
		ll c=0,x=i;
		while(x){
			d[++c]=x%10;
			x/=10;
		}
		ll num=0;
		sort(d+1,d+c+1);
		for(ll j=1;j<=c;j++)  num=num*10+d[j];
		b[num]=1;
	}
	for(ll i=1;i<=Maxn-7;i++) ans+=b[i];
	cout<<ans;
	return 0;
}



