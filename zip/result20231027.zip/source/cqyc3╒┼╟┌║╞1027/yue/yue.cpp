#include <bits/stdc++.h>
#define ll long long
using namespace std;
/*
����ÿһ��/�У�������һ����ͬ����ͬ���ҽ�����һ��/��ֻ����һ���� 
�ҵ�һ������Ϊ 0���ڶ�������Ϊ 1 
*/
const ll Maxn=1010;

ll T,n,m,a[Maxn][Maxn],b[Maxn][Maxn],sl[Maxn],sh[Maxn],cnt;
vector<pair<ll,ll> >e;

int main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld%lld",&n,&m);
		memset(sh,0,sizeof sh);
		memset(sl,0,sizeof sl);
		cnt=0;
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=m;j++)
				scanf("%1lld",&a[i][j]),cnt+=a[i][j];
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=m;j++)
				scanf("%1lld",&b[i][j]);
		bool flg=1,pp=0;
		if(cnt==n*m) flg=0;
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=m;j++) 
				sh[i]+=(b[i][j]),sl[j]+=(b[i][j]);
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=m;j++){
				if(a[i][j]==0&&b[i][j]==1){
					if(sh[i]>=2||sl[j]>=2) flg=0;
				}
				if(sh[i]<=1&&sl[j]<=1){
					if(a[i][j]==0) pp=1;
				}
			}
		if(!pp) flg=0;
		bool fl=0;
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=m;j++)
				if(a[i][j]!=b[i][j]) fl=1;
		if(fl&&cnt==n*m) flg=0;
		if(!fl) flg=1;
		if(flg) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}


/*
3
4 2
10
01
10
01
01
00
10
00
2 4
1111
1111
1000
0000
4 4
1001
0101
1110
0010
1001
0101
1110
0000

1
3 3
110
010
111
110
001
110

*/ 
