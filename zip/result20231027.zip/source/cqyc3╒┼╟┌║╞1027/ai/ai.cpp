#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=1e5+7;

const double eps=1,delt=0.9;

ll n,m,k,ans=0;
struct node{
	ll v,w;
}a[Maxn];
node b[Maxn],c[Maxn],d[Maxn],g[Maxn];
ll b1,c1,d1,d2,g1,now;
inline bool cmp1(node x,node y){
	return x.v<y.v;
}
inline bool cmp2(node x,node y){
	return x.v>y.v;
}
inline bool cmp3(node x,node y){
	return x.w<y.w;
}
inline bool check(ll x){
	b1=c1=d1=d2=g1=0;
	bool flg=0;
	for(ll i=1;i<=n;i++){
		if(a[i].w>a[x].w) b[++b1]=a[i];
		if(a[i].w<a[x].w) c[++c1]=a[i];
		if(a[i].w==a[x].w&&(a[i].v!=a[x].v||flg)) d[++d1]=a[i];
		if(a[i].w==a[x].w&&a[i].v==a[x].w) flg=1;
	}
	sort(b+1,b+b1+1,cmp1);
	sort(c+1,c+c1+1,cmp1);
	sort(d+1,d+d1+1,cmp1);
	if(b1<now){
		if(b1+d1<now) return false;
		g1=0;
		for(ll i=1;i<=now-b1;i++) b[++b1]=d[i];
		for(ll i=now-b1+1;i<=d1;i++) g[++g1]=d[i];d1=g1;
		for(ll i=1;i<=d1;i++) d[i]=g[i];
	}
	if(c1<now){
		if(c1+d1<now) return false;
		g1=0;
		for(ll i=1;i<=now-c1;i++) c[++c1]=d[i];
		for(ll i=now-c1+1;i<=d1;i++) g[++g1]=d[i];d1=g1;
		for(ll i=1;i<=d1;i++) d[i]=g[i];
	}
	b1=c1=now;
	sort(b+1,b+b1+1,cmp2);
	sort(c+1,c+c1+1,cmp2);
	sort(d+1,d+d1+1,cmp1);
	ll lb=1,lc=1,ld=1,res=a[x].v;
	for(ll i=1;i<=d1;i++){
		if(b[lb].v>c[lc].v){
			if(b[lb].v>d[i].v) b[lb]=d[i],++lb;
		}
		else{
			if(c[lc].v>d[i].v) c[lc]=d[i],++lc;
		}
	}
	for(ll i=1;i<=b1;i++) res+=b[i].v;
	for(ll i=1;i<=c1;i++) res+=c[i].v;
	//cout<<a[x].w<<" "<<a[x].v<<" "<<res<<endl; 
	return res<=m;
}

mt19937 rnd(19260817);

inline void solve(){
	double T=1000;
	ll zx=1;
	while(T>eps){
		ll pz=zx;
		zx=(rnd()%n+zx)%n+1;
		ll res=0;
		if(check(zx)) res=a[zx].w;
		if(res>ans) ans=res;
		else if(exp(res-ans)/T<=(double)rand()/RAND_MAX) zx=pz;
		T*=delt;
	}
	
}


/*
����һ����庯���� 
�Ȱ� ai< | > �����ã�ѡ (K-1)/2 ����Ȼ���ڷ��ڼ��� ai= �� 
�� > �� < û��ȫ���� = ��ȫ 
*/

int main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	srand(19260817);
	scanf("%lld%lld%lld",&n,&m,&k);
	now=(k-1)/2;
	for(ll i=1;i<=n;i++) scanf("%lld%lld",&a[i].v,&a[i].w);
	ll mid=n/2;
	sort(a+1,a+n+1,cmp3);
	for(ll i=0;i<=100&&mid+i<=n&&mid-i>=1;i++){
		if(check(mid+i)) ans=max(ans,a[mid+i].w);
		if(check(mid-i)) ans=max(ans,a[mid-i].w);
	}
	for(ll i=1;i<=min(100ll,n);i++){
		if(check(i)){
			ans=max(ans,a[i].w);
		}
	}
	while((double)clock()/1000<=0.8) solve();
	cout<<ans;
	return 0;
}

/*
5 70 3
25 30
21 50
20 20
18 5
30 35
*/

