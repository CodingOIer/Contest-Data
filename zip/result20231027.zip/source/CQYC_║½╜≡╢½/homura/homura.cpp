#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define mod 1000000007
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
char L[N],R[N];
int ans,szl,szr,cnt[10],cnt_[10];
il bool check(int x){
	if(szl==szr){
		memcpy(cnt_,cnt,sizeof(cnt_));
		cnt_[0]=szl-x;
		for(int i=1,ff=0;i<=szl;++i){
			int flag=1;
			for(int j=L[i]-'0'+1;j<R[i]-'0'+ff;++j) flag+=cnt_[j];
			if(flag) return 1;
			if(L[i]!=R[i]) ff=1;
			if(!cnt_[L[i]-'0']) break;
			--cnt_[L[i]-'0'];
		}
		memcpy(cnt_,cnt,sizeof(cnt_));
		cnt_[0]=szr-x;
		for(int i=1,ff=1;i<=szr;++i){
			int flag=1;
			for(int j=L[i]-'0'+ff;j<R[i]-'0';++j) flag+=cnt_[j];
			if(flag) return 1;
			if(L[i]!=R[i]) ff=0;
			if(!cnt_[R[i]-'0']) break;
			--cnt_[R[i]-'0'];
		}
	}
	else if(x==szr){
		memcpy(cnt_,cnt,sizeof(cnt_));
		cnt_[0]=0;
		for(int i=1;i<=szr;++i){
			int flag=0;
			for(int j=(i>1);j<R[i]-'0';++j) flag+=cnt_[j];
			if(flag) return 1;
			if(!cnt_[R[i]-'0']) break;
			--cnt_[R[i]-'0'];
		}
	}
	else if(szl+1<szr) return 1;
	else if(szl+1==szr){
		memcpy(cnt_,cnt,sizeof(cnt_));
		cnt_[0]=szr-x;
		for(int i=1;i<=szr;++i){
			int flag=0;
			for(int j=(i>1);j<R[i]-'0';++j) flag+=cnt_[j];
			if(flag) return 1;
			if(!cnt_[R[i]-'0']) break;
			--cnt_[R[i]-'0'];
		}
		memcpy(cnt_,cnt,sizeof(cnt_));
		cnt_[0]=szl-x;
		for(int i=1;i<=szl;++i){
			int flag=0;
			for(int j=L[i]-'0'+1;j<10;++j) flag+=cnt_[j];
			if(flag) return 1;
			if(!cnt_[L[i]-'0']) break;
			--cnt_[L[i]-'0'];
		}
	}
	return 0;
}
il void dfs(int x,int k){
	if(x>1&&check(x-1)) ++ans;
	if(x>szr) return;
	for(int i=k;i<10;++i){
		++cnt[i];dfs(x+1,i);--cnt[i];
	}
}
bool pppp;
signed main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
    scanf("%s %s",L+1,R+1);
    szl=strlen(L+1);szr=strlen(R+1);
	dfs(1,1);
	write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}