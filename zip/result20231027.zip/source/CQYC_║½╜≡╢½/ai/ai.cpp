#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,m,K,V[N],tot,ans;
struct SEG{
	#define ls (w<<1)
	#define rs (w<<1|1)
	int sum[N<<2],cnt[N<<2];
	il void push_up(int w){
		sum[w]=sum[ls]+sum[rs];
		cnt[w]=cnt[ls]+cnt[rs];
	}
	il void update(int w,int l,int r,int x,int k){
		if(l==r){
			sum[w]+=k*V[l];cnt[w]+=k;return;
		}
		int mid=(l+r)>>1;
		if(x<=mid) update(ls,l,mid,x,k);
		else update(rs,mid+1,r,x,k);
		push_up(w);
	}
	il int query1(int w,int l,int r,int L,int R){
		if(L>r||R<l) return 0;
		if(L<=l&&R>=r) return sum[w];
		int mid=(l+r)>>1;
		return query1(ls,l,mid,L,R)+query1(rs,mid+1,r,L,R);
	}
	il int query2(int w,int l,int r,int L,int R){
		if(L>r||R<l) return 0;
		if(L<=l&&R>=r) return cnt[w];
		int mid=(l+r)>>1;
		return query2(ls,l,mid,L,R)+query2(rs,mid+1,r,L,R);
	}
	il int query3(int w,int l,int r,int k){
		if(cnt[w]<k) return 0;
		if(l==r) return l;
		int mid=(l+r)>>1;
		if(cnt[ls]>=k) return query3(ls,l,mid,k);
		return query3(rs,mid+1,r,k-cnt[ls]);
	}
	il int query4(int w,int l,int r,int k){
		if(cnt[w]<k) return 0;
		if(l==r) return V[l]*k;
		int mid=(l+r)>>1;
		if(cnt[ls]>=k) return query4(ls,l,mid,k);
		return sum[ls]+query4(rs,mid+1,r,k-cnt[ls]);
	}
} ST[3];
pii a[N];
il bool cmp(pii u,pii v){
	return pii(u.se,u.fi)<pii(v.se,v.fi);
}
il void insert(int x,int k){
	x=lower_bound(V+1,V+1+tot,x)-V;
	ST[k].update(1,1,tot,x,1);
	int cnt=ST[k].query2(1,1,tot,1,x);
	if(cnt<=K){
		int tmp=ST[k].query3(1,1,tot,K+1);
		if(tmp){
			// cerr<<x<<" ";
			ST[2].update(1,1,tot,tmp,-1);
		}
		ST[2].update(1,1,tot,x,1);
	}
}
il void erase(int x,int k){
	x=lower_bound(V+1,V+1+tot,x)-V;
	int cnt=ST[k].query2(1,1,tot,1,x);
	if(cnt<=K){
		int tmp=ST[k].query3(1,1,tot,K+1);
		if(tmp) ST[2].update(1,1,tot,tmp,1);
		ST[2].update(1,1,tot,x,-1);
	}
	ST[k].update(1,1,tot,x,-1);
}
il int find(int x){
	return lower_bound(V+1,V+1+tot,x)-V;
}
bool pppp;
signed main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	n=read();m=read();K=read();
	K>>=1;
    for(int i=1;i<=n;++i){
        a[i].fi=read();a[i].se=read();
		V[++tot]=a[i].fi;
    }
	sort(V+1,V+1+tot);
	tot=unique(V+1,V+1+tot)-V-1;
	sort(a+1,a+1+n,cmp);
	for(int i=n;i;--i) insert(a[i].fi,1);
	for(int l=1,r;l<=n;l=r+1){
		r=l;
		while(r<n&&a[r].se==a[r+1].se) ++r;
		// cerr<<l<<" "<<r<<" "<<a[r].se<<"\n";
		for(int i=l;i<=r;++i) erase(a[i].fi,1);
		for(int i=l+1;i<=r;++i) ST[2].update(1,1,tot,find(a[i].fi),1);
		int tmp=ST[2].query4(1,1,tot,K<<1);
		if(tmp&&tmp+a[l].fi<=m) ans=a[l].se;
		for(int i=l+1;i<=r;++i) ST[2].update(1,1,tot,find(a[i].fi),-1);
		for(int i=l;i<=r;++i) insert(a[i].fi,0);
	}
	write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}