#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,m;
char A[N][N],B[N][N];
set<int> Sx[N],Sy[N];
bool pppp;
signed main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
    T=read();
    while(T--){
        n=read();m=read();
        for(int i=1;i<=n;++i) scanf(" %s",A[i]+1);
        for(int i=1;i<=n;++i) scanf(" %s",B[i]+1);
		int flag=1;
		for(int i=1;i<=n;++i){
			int cnt=0;
			for(int j=1;j<=m;++j) cnt+=B[i][j]-'1';
			if(cnt>1) for(int j=1;j<=m;++j) if(B[i][j]=='1'&&A[i][j]=='0') flag=0;
		}
		for(int j=1;j<=m;++j){
			int cnt=0;
			for(int i=1;i<=n;++i) cnt+=B[i][j]-'1';
			if(cnt>1) for(int i=1;i<=n;++i) if(B[i][j]=='1'&&A[i][j]=='0') flag=0;
		}
		if(!flag){
			puts("No");continue;
		}
		for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) if(A[i][j]){
			Sx[i].insert(j);Sy[j].insert(i);
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(B[i][j]=='1'&&A[i][j]=='0'){
					for(auto v:Sx[i]){
						Sy[v].erase(i);A[i][v]='0';
					}
					Sx[i].clear();
					for(auto v:Sy[j]){
						Sx[v].erase(j);A[v][j]='0';
					}
					Sy[j].clear();
					A[i][j]='1';Sx[i].insert(j);Sy[j].insert(i);
				}
			}
		}
		for(int i=1;i<=n;++i) Sx[i].clear();
		for(int i=1;i<=m;++i) Sy[i].clear();
		for(int i=1;i<=n;++i) for(int j=1;j<=m;++j) if(B[i][j]=='1'&&A[i][j]=='0') flag=0;
		int ffa=0,ffb=0;
		for(int i=1;i<=n;++i) for(int j=1;j<=m;++j){
			if(A[i][j]=='0') ++ffa;
			if(B[i][j]=='0') ++ffb;
		}
		if(!ffa&&ffb) flag=0;
		// if(ffa&&!ffb) flag=0;
		puts(flag?"Yes":"No");
    }
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}