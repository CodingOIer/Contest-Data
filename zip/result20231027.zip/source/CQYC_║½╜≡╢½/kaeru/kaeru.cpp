#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 500010
#define M 50010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int m,Q,type,a[N],ta,b[N],tb,n;
bool vis[N];
vector<int> V[N];
pii e[N];
bool pppp;
signed main(){
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
    m=read();Q=read();type=read();n=500000;
    for(int i=1;i<=m;++i){
		e[i].fi=read();e[i].se=read();
		vis[e[i].fi]=1;
    }
	for(int i=1;i<=n;++i) if(vis[i]){
		a[++ta]=i;vis[i]=0;
	}
	for(int i=1;i<=m;++i) vis[e[i].se]=1;
	for(int i=1;i<=n;++i) if(vis[i]){
		b[++tb]=i;vis[i]=0;
	}
	for(int i=1;i<=m;++i){
		e[i].fi=lower_bound(a+1,a+1+ta,e[i].fi)-a;
		e[i].se=lower_bound(b+1,b+1+tb,e[i].se)-b;
		V[e[i].fi].pk(e[i].se);
	}
	for(int i=1;i<=ta;++i) sort(V[i].begin(),V[i].end());
	// Q=1;
	int lst=0;
	while(Q--){
		int la=read()^(type*lst),ra=read()^(type*lst),lb=read()^(type*lst),rb=read()^(type*lst);
		la=lower_bound(a+1,a+1+ta,la)-a;
		ra=lower_bound(a+1,a+1+ta,ra+1)-a-1;
		lb=lower_bound(b+1,b+1+tb,lb)-b;
		rb=lower_bound(b+1,b+1+tb,rb+1)-b-1;
		lst=0;
		for(int i=la;i<=ra;++i){
			int L=lower_bound(V[i].begin(),V[i].end(),lb)-V[i].begin();
			int R=lower_bound(V[i].begin(),V[i].end(),rb+1)-V[i].begin();
			if(L<R){
				++lst;
				// cerr<<a[i]<<" ";
			}
			for(int j=L;j<R;++j) vis[V[i][j]]=1;
		}
		// cerr<<"\n";
		for(int i=lb;i<=rb;++i){
			lst+=vis[i];
			// if(vis[i]) cerr<<b[i]<<" ";
		}
		// cerr<<"\n";
		for(int i=la;i<=ra;++i){
			int L=lower_bound(V[i].begin(),V[i].end(),lb)-V[i].begin();
			int R=lower_bound(V[i].begin(),V[i].end(),rb+1)-V[i].begin();
			for(int j=L;j<R;++j) vis[V[i][j]]=0;
		}
		write(lst);putchar('\n');
	}
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}