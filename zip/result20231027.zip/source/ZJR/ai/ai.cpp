#include<bits/stdc++.h>
using namespace std;
priority_queue<int> q;
long long sum;
long long pre[100011],suf[100011];
typedef struct{
    int v,w;
}AD;
bool cmp(AD A,AD B) {return A.w < B.w;}
AD a[100011];
int n,m,k;
int mid;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
    cin >> n >> m >> k;
    mid = k >> 1;
    for(int i = 1;i <= n;i++) cin >> a[i].v >> a[i].w;
    sort(a + 1,a + n + 1,cmp);
    if(k == 1)
    {
        cout << a[n].w;
        return 0;
    }
    for(int i = 1;i <= n;i++)
    {
        sum += a[i].v;
        q.push(a[i].v);
        while(q.size() > mid)
        {
            sum -= q.top();
            q.pop();
        }
        pre[i] = sum;
    }
    while(!q.empty()) q.pop();
    sum = 0;
    for(int i = n;i;i--)
    {
        sum += a[i].v;
        q.push(a[i].v);
        while(q.size() > mid)
        {
            sum -= q.top();
            q.pop();
        }
        suf[i] = sum;
    }
    int ans = -1;
    for(int i = mid + 1;i + mid <= n;i++) if(pre[i - 1] + suf[i + 1] + a[i].v <= m)
        ans = a[i].w;
    cout << ans;
    return 0;
}