#include<bits/stdc++.h>
#include<bits/extc++.h>
#pragma GCC optimize(2)
using namespace std;
using namespace __gnu_pbds;
typedef struct{
	int u,v;
}AD;
bool cmp1(AD A,AD B) {return A.u < B.u;}
bool cmp2(AD A,AD B) {return A.v < B.v;}
AD a[50011],b[50011];
unsigned short n,m,type,lans;
unsigned short t1[500011],t2[500011];
vector<int> v[500011];
gp_hash_table<int,gp_hash_table<int,bool> > hs;
int x,y,c,d;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
	cin >> n >> m >> type;
	for(int i = 1;i <= n;i++)
	{
		cin >> a[i].u >> a[i].v;
		if(hs[a[i].u][a[i].v]) {i--,n--;continue;}
		hs[a[i].u][a[i].v] = 1;
		v[a[i].u].push_back(a[i].v);
		b[i] = a[i];
	}
	for(int i = 1;i <= 500000;i++) sort(v[i].begin(),v[i].end());
	sort(a + 1,a + n + 1,cmp1);
	sort(b + 1,b + n + 1,cmp2);
	for(unsigned short tms = 1;tms <= m;tms++)
	{
		cin >> x >> y >> c >> d;
		if(type)
			x ^= lans,y ^= lans,c ^= lans,d ^= lans;
		// if(x == y)
		// {
		// 	int l,r,mid,L,R;
		// 	l = 0,r = v[x].size() - 1;
		// 	while(l <= r)
		// 	{
		// 		mid = l + r >> 1;
		// 		if(c <= v[x][mid]) L = mid,r = mid - 1;
		// 		else l = mid + 1;
		// 	}
		// 	l = 0,r = v[x].size() - 1;
		// 	while(l <= r)
		// 	{
		// 		mid = l + r >> 1;
		// 		if(v[x][mid] <= d) R = mid,l = mid + 1;
		// 		else r = mid - 1;
		// 	}
		// 	cout << (lans = ((l <= r) ? (r - l + 2) : 0)) << "\n";
		// 	continue;
		// }
		unsigned short L1 = n + 1,R1 = 0,L2 = n + 1,R2 = 0,l,r,mid;
		l = 1,r = n;
		while(l <= r)
		{
			mid = l + r >> 1;
			if(a[mid].u >= x) L1 = mid,r = mid - 1;
			else l = mid + 1;
		}
		l = 1,r = n;
		while(l <= r)
		{
			mid = l + r >> 1;
			if(a[mid].u <= y) R1 = mid,l = mid + 1;
			else r = mid - 1;
		}
		l = 1,r = n;
		while(l <= r)
		{
			mid = l + r >> 1;
			if(b[mid].v >= c) L2 = mid,r = mid - 1;
			else l = mid + 1;
		}
		l = 1,r = n;
		while(l <= r)
		{
			mid = l + r >> 1;
			if(b[mid].v <= d) R2 = mid,l = mid + 1;
			else r = mid - 1;
		}
		if(L1 > R1 || L2 > R2)
		{
			cout << (lans = 0) << "\n";
			continue;
		}
		if(R1 + L2 <= R2 + L1)
		{
			lans = 0;
			for(unsigned short i = L1;i <= R1;++i) if(c <= a[i].v && a[i].v <= d)
			{
				if(t1[a[i].u]^tms) ++lans,t1[a[i].u] = tms;
				if(t2[a[i].v]^tms) ++lans,t2[a[i].v] = tms;
			}
			cout << lans << "\n";
		}else{
			lans = 0;
			for(unsigned short i = L2;i <= R2;++i) if(x <= b[i].u && b[i].u <= y)
			{
				if(t1[b[i].u]^tms) ++lans,t1[b[i].u] = tms;
				if(t2[b[i].v]^tms) ++lans,t2[b[i].v] = tms;
			}
			cout << lans << "\n";
		}
	}
	return 0;
}