#include<bits/stdc++.h>
using namespace std;
int ans;
bool b[100000011];
int a[10];
inline void Clac(int x)
{
    while(x) a[x % 10]++,x /= 10;
    for(int i = 1;i < 10;i++)
        while(a[i])
            x = x * 10 + i,a[i]--;
    if(!b[x]) ans++,b[x] = 1;
}
int l,r;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    cin >> l >> r;
    for(int i = l;i <= r;i++)
        Clac(i);
    cout << ans;
    return 0;
}