#include <bits/stdc++.h>
#define LL long long
#define R register
using namespace std;
char B[1<<15],*S=B,*T=B;
#define getchar() (S==T&&(T=(S=B)+fread(B,1,1<<15,stdin),S==T)?EOF:*S++)

template<class TT>inline void read(R TT &x){
	x=0;R bool f=0;R char ch=getchar();
	for(;ch<48||ch>57;ch=getchar())f|=(ch=='-');
	for(;ch>47&&ch<58;ch=getchar())
		x=(x<<1)+(x<<3)+(ch^48);
	(f)&&(x=-x);
}
class Heap{
	private:int A[100010],N;
	public:inline bool empty(){return !N;}
	public:inline int front(){return A[1];}
	public:inline int size(){return N;}
	private:inline void Swap(R int a,R int b){
		R int t;
		t=A[a];
		A[a]=A[b];
		A[b]=t;
	}
	//private:inline bool less(R int a,R int b){
	//	return A[a]<A[b];
	//}
	#define less(a,b) (A[a]<A[b])
	private:inline void up(R int x){
		while(x>1&&less(x>>1,x)){
			Swap(x>>1,x);
			x>>=1;
		}
	}
	private:inline void down(R int x){
		while((x<<1)<=N){
			R int t=x<<1;
			if(t<N&&less(t,t+1))t++;
			if(!less(x,t))break;
			Swap(x,t);
			x=t;
		}
	}
	public:inline void push(R int x){
		A[++N]=x;
		up(N);
	}
	public:inline void pop(){
		Swap(1,N--);
		down(1);
	}
	Heap(){memset(A,0,sizeof(A));N=0;}
	public:inline int top(){return A[1];}
	public:inline void reset(){memset(A,0,sizeof(A));N=0;}
};
int n,k,m,ans=-1;
struct data{
	int w,v;
	inline bool operator < (R const data&x)const{
		return w<x.w;
	}
}item[100010];
int f[100010],g;
Heap q;
int main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	read(n);read(m);read(k);
	for(R int i=1;i<=n;++i){
		read(item[i].v);
		read(item[i].w);
	}
	sort(item+1,item+1+n);
	R int h=k>>1;
	for(R int i=1;i<=h;++i){
		q.push(item[i].v);
		f[h]+=item[i].v;
	}
	for(R int i=h+1;i<=n-h;++i){
		f[i]=f[i-1];
		if(item[i].v<q.top()){
			f[i]+=item[i].v-q.top();
			q.pop();
			q.push(item[i].v);
		}
	}
	//q=Heap();
	q.reset();
	for(R int i=n-h+1;i<=n;++i){
		q.push(item[i].v);
		g+=item[i].v;
	}
	for(R int i=n-h;i>h;--i){
		if(f[i-1]+g+item[i].v<=m){
			printf("%d\n",item[i].w);
			return 0;
		}
		if(item[i].v<q.top()){
			g+=item[i].v-q.top();
			q.pop();
			q.push(item[i].v);
		}
	}
	
	puts("-1");
	return 0;
}

