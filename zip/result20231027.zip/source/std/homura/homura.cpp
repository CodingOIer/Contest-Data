#include <bits/stdc++.h>
#define meow(args...) fprintf(stderr, args)
typedef unsigned u32;
const int N=1e5+10;
const u32 P=1e9+7;
int min[20][10], cur[10], least[1<<20][10];
u32 com[N][10];
bool vis[10];
char s[N], t[N];
int main() {
	int n, m, lcp=0, cnt=0;
	u32 ans=0;
	freopen("homura.in", "r", stdin);
	freopen("homura.out", "w", stdout);
	scanf("%s%s", s, t);
	m=strlen(s);
	n=strlen(t);
	for(int i=0; i<n; ++i) t[i]-=48;
	for(int i=m, j=n; i--; ) s[--j]=s[i]-48;
	memset(s, 0, n-m);
	while(lcp<n&&s[lcp]==t[lcp]) ++lcp;
	n-=lcp;
	if(n==0) {
		puts("1");
		return 0;
	}
	memmove(s, s+lcp, n);
	memmove(t, t+lcp, n);
	for(int i=0; i<n; ++i) {
		for(int j=s[i]+(i!=n-1); j<(i?10:t[i]); ++j) {
			if(!vis[j]) {
				vis[j]=true;
				memcpy(min[cnt], cur, sizeof(cur));
				++min[cnt][j];
				++cnt;
			}
		}
		++cur[s[i]];
	}
	memset(vis, 0, sizeof(vis));
	memset(cur, 0, sizeof(cur));
	++cur[t[0]];
	for(int i=1; i<n; ++i) {
		for(int j=0; j<=t[i]-(i!=n-1); ++j) {
			if(!vis[j]) {
				vis[j]=true;
				memcpy(min[cnt], cur, sizeof(cur));
				++min[cnt][j];
				++cnt;
			}
		}
		++cur[t[i]];
	}
	for(int i=0; i<cnt; ++i) {
		int k=1<<i;
		for(int j=0; j<k; ++j) {
			for(int d=0; d<10; ++d)
				least[j+k][d]=std::max(least[j][d], min[i][d]);
		}
	}
	com[0][0]=1;
	for(int i=1; i<n+10; ++i) {
		com[i][0]=1;
		for(int j=1; j<10; ++j)
			com[i][j]=(com[i-1][j-1]+com[i-1][j])%P;
	}
	for(int i=1; i<(1<<cnt); ++i) {
		int s=n;
		for(int d=0; d<10; ++d) s-=least[i][d];
		if(s>=0) {
			if(__builtin_parity(i))
				ans=(ans+com[s+9][9])%P;
			else
				ans=(ans+P-com[s+9][9])%P;
		}
	}
	printf("%u\n", ans);
	return 0;
}
