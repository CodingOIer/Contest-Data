#include <bits/stdc++.h>
#define meow(args...) fprintf(stderr, args)
template<class T1, class T2> bool cmin(T1 &a, const T2 &b) {
	return b<a?(a=b, true):false;
}
template<class T1, class T2> bool cmax(T1 &a, const T2 &b) {
	return a<b?(a=b, true):false;
}

typedef unsigned long long u64, Bitset[782];
struct Point {
	int x[2];
};
const int M=5e4+1;
int real[2][M], cnt[65536], sz[2], s, nblock, prefix[2][148][148][782], mark[2][M], val[2][M];
u64 filter[65];
bool vis[M];
Point p[2][M];
Bitset block[2][148][148];
int popcount(u64 x) {
	return cnt[x&65535]+cnt[x>>16&65535]+cnt[x>>32&65535]+cnt[x>>48&65535];
}
bool test(Bitset s, int x) {
	return s[x/64]>>x%64&1;
}
void set(Bitset s, int x) {
	s[x/64]|=1llu<<x%64;
}
int count(Bitset s, int l, int len) {
	return popcount(s[l/64]>>l%64 & filter[len]);
}
int query(int dim, int a, int b, int c, int d) {
	int *V=val[dim];
	a=mark[dim][a];
	b=mark[dim][b];
	int ka=a/s, kb=b/s, ans=0;
	if(ka==kb) {
		for(int i=a; i<b; ++i) {
			ans+=V[i]>=c&&V[i]<d&&!vis[V[i]];
			vis[V[i]]=true;
		}
		for(int i=a; i<b; ++i) vis[V[i]]=false;
	} else {
		auto bs=block[dim][ka+1][kb-1];
		int kc=c/64, kd=d/64;
		if(kc==kd) {
			ans+=count(bs, c, d-c);
		} else {
			ans+=count(bs, c, 64-c%64);
			ans+=count(bs, kd*64, d%64);
			ans+=prefix[dim][ka+1][kb-1][kd-1]-prefix[dim][ka+1][kb-1][kc];
		}
		for(int i=a; i<(ka+1)*s; ++i) {
			ans+=V[i]>=c&&V[i]<d&&!vis[V[i]]&&!test(bs, V[i]);
			vis[V[i]]=true;
		}
		for(int i=kb*s; i<b; ++i) {
			ans+=V[i]>=c&&V[i]<d&&!vis[V[i]]&&!test(bs, V[i]);
			vis[V[i]]=true;
		}
		for(int i=a; i<(ka+1)*s; ++i) vis[V[i]]=false;
		for(int i=kb*s; i<b; ++i) vis[V[i]]=false;
	}
	return ans;
}
int main() {
	int m, q, type, ans=0;
	for(int i=1; i<65536; ++i) cnt[i]=cnt[i/2]+i%2;
	filter[0]=0;
	for(int i=1; i<=64; ++i) filter[i]=filter[i-1]*2+1;
	freopen("kaeru.in", "r", stdin);
	freopen("kaeru.out", "w", stdout);
	scanf("%d%d%d", &m, &q, &type);
	for(int i=0; i<m; ++i) scanf("%d%d", p[0][i].x, p[0][i].x+1);
	s=ceil(m/pow(q*64.0, 1.0/3.0));
	nblock=(m-1)/s+1;
	for(int dim=0; dim<2; ++dim) {
		int *R=real[dim];
		for(int i=0; i<m; ++i) R[i]=p[0][i].x[dim];
		std::sort(R, R+m);
		sz[dim]=std::unique(R, R+m)-R;
		for(int i=0; i<m; ++i) {
			int rank=std::lower_bound(R, R+sz[dim], p[0][i].x[dim])-R;
			p[0][i].x[dim]=p[1][i].x[dim]=rank;
		}
	}
	for(int dim=0; dim<2; ++dim) {
		auto cmp=[dim](const Point &a, const Point &b) {return a.x[dim]<b.x[dim];};
		std::sort(p[dim], p[dim]+m, cmp);
		for(int i=0; i<m; ++i) val[dim][i]=p[dim][i].x[!dim];
		for(int i=0, l=0, r=0; i<=sz[dim]; ++i, l=r) {
			mark[dim][i]=l;
			while(r<m&&p[dim][r].x[dim]==i) ++r;
		}
		for(int i=nblock; i--; ) {
			for(int j=s*i; j<s*(i+1)&&j<m; ++j)
				set(block[dim][i][i], val[dim][j]);
			for(int j=i+1; j<nblock; ++j) {
				for(int k=0; 64*k<sz[!dim]; ++k)
					block[dim][i][j][k]=block[dim][i][j-1][k]|block[dim][j][j][k];
			}
			for(int j=i; j<nblock; ++j) {
				int cnt=0;
				for(int k=0; 64*k<sz[!dim]; ++k) {
					cnt+=popcount(block[dim][i][j][k]);
					prefix[dim][i][j][k]=cnt;
				}
			}
		}
	}
	while(q--) {
		int a, b, c, d;
		scanf("%d%d%d%d", &a, &b, &c, &d);
		a=std::lower_bound(real[0], real[0]+sz[0], a^ans)-real[0];
		b=std::upper_bound(real[0], real[0]+sz[0], b^ans)-real[0];
		c=std::lower_bound(real[1], real[1]+sz[1], c^ans)-real[1];
		d=std::upper_bound(real[1], real[1]+sz[1], d^ans)-real[1];
		ans=query(0, a, b, c, d)+query(1, c, d, a, b);
		printf("%d\n", ans);
		ans*=type;
	}
	return 0;
}

