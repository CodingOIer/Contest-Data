#include <bits/stdc++.h>
#define meow(args...) fprintf(stderr, args)
const int N=1001;
int n, m, degx[N], degy[N];
bool visx[N], visy[N];
char a[N][N], b[N][N];
void visity(int);
void visitx(int x) {
	if(visx[x]) return;
	visx[x]=true;
	for(int y=0; y<m; ++y) if(b[x][y]=='1') visity(y);
}
void visity(int y) {
	if(visy[y]) return;
	visy[y]=true;
	for(int x=0; x<n; ++x) if(b[x][y]=='1') visitx(x);
}
void work() {
	scanf("%d%d", &n, &m);
	for(int i=0; i<n; ++i) scanf("%s", a[i]);
	memset(degx, 0, n*sizeof(int));
	memset(degy, 0, m*sizeof(int));
	memset(visx, 0, n);
	memset(visy, 0, m);
	for(int i=0; i<n; ++i) {
		scanf("%s", b[i]);
		for(int j=0; j<m; ++j) {
			if(b[i][j]=='1') {
				++degx[i];
				++degy[j];
			}
		}
	}
	for(int i=0; i<n; ++i) if(degx[i]>=2) visitx(i);
	for(int i=0; i<m; ++i) if(degy[i]>=2) visity(i);
	bool a0=0, a1=0, b0=0, b1=0, ex=0;
	for(int i=0; i<n; ++i) {
		for(int j=0; j<m; ++j) {
			if(!visx[i]&&!visy[j]) {
				if(a[i][j]=='0') a0=1; else a1=1;
				if(b[i][j]=='0') b0=1; else b1=1;
			} else if(visx[i]&&visy[j]) {
				if(a[i][j]!=b[i][j]) {
					puts("No");
					return;
				}
			} else ex|=a[i][j]=='1';
		}
	}
	if(!b1)
		puts(a1||ex?"No":"Yes");
	else
		puts((!b0&&!ex)||a0?"Yes":"No");
}
int main() {
	int t;
	freopen("yue.in", "r", stdin);
	freopen("yue.out", "w", stdout);
	scanf("%d", &t);
	while(t--) work();
	return 0;
}
