#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int mod=1e9+7;
int n,m,ans;
//int a[1005],b[1005];
//int f[1005][1024][2][2];
//void Init(){
//	char ch=getchar();
//	while(ch>='0'&&ch<='9')a[++m]=ch-'0',ch=getchar();
//	ch=getchar();
//	while(ch>='0'&&ch<='9')b[++n]=ch-'0',ch=getchar();
//	for(int i=m;i>=1;i--){
//		a[i+n-m]=a[i];a[i]=0;
//	}
//}
int s[10];
map<int,int>mp;
void w(int x){
	int sss=x;
	int s[10];
	memset(s,0,sizeof s);
	while(x)s[x%10]++,x/=10;
	int sum=0;
	for(int i=1;i<=9;i++)sum=(sum*31+s[i])%mod;
	if(mp[sum]==0){
		ans++;
	}
	mp[sum]=1;
}
signed main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	cin>>n>>m;
	for(int i=n;i<=m;i++)w(i);
//	Init();
//	f[0][0][1][1]=1;
//	for(int i=0;i<n;i++){
//		for(int j=0;j<1024;j++){
//			for(int s1=0;s1<=1;s1++){
//				for(int s2=0;s2<=1;s2++){
//					if(f[i][j][s1][s2]==0)continue;
//					for(int k=0;k<=9;k++){
//						if((j>>k)&1)continue;
//						if(s1&&(k>b[i+1]))continue;
//						if(s2&&(k<a[i+1]))continue;
//						if(s1==1){
//							f[i+1][j|((1<<(b[i+1]+1))-(1<<(k+1)))][s1&(k==b[i+1])][s2&(k==a[i+1])]+=f[i][j][s1][s2];
//						}else{
//							f[i+1][j|((1<<10)-(1<<(k+1)))][s1&(k==b[i+1])][s2&(k==a[i+1])]+=f[i][j][s1][s2];
//						}
//					}
////					cout<<i<<" "<<j<<" "<<s1<<" "<<s2<<"="<<f[i][j][s1][s2]<<endl;
//				}
//			}
//		}
//	}
//	for(int j=0;j<1024;j++){
//		for(int s1=0;s1<=1;s1++){
//			for(int s2=0;s2<=1;s2++){
//				ans+=f[n][j][s1][s2];
//			}
//		}
//	}
	cout<<ans;
}
