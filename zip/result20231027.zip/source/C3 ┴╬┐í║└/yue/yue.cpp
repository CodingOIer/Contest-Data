#include<bits/stdc++.h>
//#include<windows.h>
using namespace std;
int n,m;
int a[1005][1005],b[1005][1005];
int vis_h[1005],vis_l[1005];
int sum_h[1005],sum_l[1005];
signed main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		memset(vis_h,0,sizeof vis_h);
		memset(vis_l,0,sizeof vis_l);
		memset(sum_h,0,sizeof sum_h);
		memset(sum_l,0,sizeof sum_l);
		scanf("%d %d",&n,&m);
		getchar();
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)
				a[i][j]=getchar()-'0';
			getchar();
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++)
				b[i][j]=getchar()-'0';
			getchar();
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				sum_h[i]+=b[i][j];
				sum_l[j]+=b[i][j];
			}
		}
		
		//-------------------------------------------
		
		int O=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(sum_h[i]+sum_l[j]-2*b[i][j]==0&&a[i][j]==0){
					O=1;
					i=n+1;
					j=m+1;
					break;
				}
			}
		}
		int OPS=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(sum_h[i]+sum_l[j]-2*b[i][j]==0&&b[i][j]==1&&(a[i][j]==0||O)){
					vis_h[i]=1;vis_l[j]=1;
					OPS=1;
				}
			}
		}
		//-------------------------------------------
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(vis_h[i]==1||vis_l[j]==1){
					sum_h[i]-=b[i][j];
					sum_l[j]-=b[i][j];
				}
			}
		}
		if(OPS){
			for(int i=1;i<=n;i++)if(sum_h[i]==0)vis_h[i]=1;
			for(int j=1;j<=m;j++)if(sum_l[j]==0)vis_l[j]=1;
		}
		int ops=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(vis_h[i]==1||vis_l[j]==1)continue;
//				cout<<i<<" "<<j<<endl; 
				if(a[i][j]!=b[i][j])ops=0;
			}
		}
		if(ops)printf("Yes\n");
		else printf("No\n");
//		cout<<OPS<<endl;
//		Sleep(1000);
	}
	return 0;
}/*
2
4 2
10
01
10
01
01
00
10
00
2 4
1111
1111
1000
0000
*/
