#include<bits/stdc++.h>
#define mk(a,b) make_pair(a,b)
#define int long long 
using namespace std;
int n,m,k,sum;
int Inq[100005];
struct node{
	int v,w;
}a[100005];
bool cmp(node A,node B){return A.w>B.w;}
priority_queue<int,vector<int>,less<int> >q;
priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >p,delp;
signed main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	for(int i=1;i<=n;i++)scanf("%lld %lld",&a[i].v,&a[i].w);
	sort(a+1,a+n+1,cmp);
	for(int i=2;i<=n;i++)p.push(mk(a[i].v,i));
	for(int i=1;i<=k/2;i++){
		sum+=p.top().first;
		Inq[p.top().second]=1;
		p.pop();
	}
	for(int i=1;i<=n;i++){
		if((i-1>=k/2)&&(n-i>=k/2)&&(sum+a[i].v<=m)){
			printf("%lld",a[i].w);
			return 0;
		}
		if(q.size()<k/2){
			sum+=a[i].v;
			q.push(a[i].v);
		}else{
			if(a[i].v<q.top()){
				sum-=q.top();
				q.pop();
				sum+=a[i].v;
				q.push(a[i].v);
			}
		}
		while(!delp.empty()&&!p.empty()&&p.top()==delp.top())p.pop(),delp.pop();
		if(Inq[i+1]==1){
			sum-=a[i+1].v;
			sum+=p.top().first;
			Inq[p.top().second]=1;
			p.pop();
		}else{
			delp.push(mk(a[i+1].v,i+1));
		}
	}
	printf("-1");
	return 0;
}/*
5 70 3
25 30
21 50
20 20
18 5
30 35
*/
