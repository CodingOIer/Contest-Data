#include <stdio.h>
#include <time.h>

bool vis[100000001];

void solve() {
	int l, r;
	scanf("%d%d", &l, &r);
	register int ans = 0, ll = l;
	const int rr = r + 1;
	while (ll ^ rr) {
		int tmp = ll, cnt[10] = {}, res = 0;
		for (; tmp; tmp /= 10) {
			++cnt[tmp % 10];
		}
		for (register int i = 1; i ^ 10; ++i) {
			for (; cnt[i]; --cnt[i]) {
				res = (res << 1) + (res << 3) + i;
			}
		}
		if (!vis[res]) ++ans, vis[res] = 1;
		++ll;
	}
	printf("%d\n", ans);
}

int main() {
	freopen("homura.in", "r", stdin);
	freopen("homura.out", "w", stdout);
	solve();
	return 0;
}
