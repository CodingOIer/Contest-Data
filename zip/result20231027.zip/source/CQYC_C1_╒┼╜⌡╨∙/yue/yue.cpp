#include <bits/stdc++.h>
using namespace std;


int T, n, m;
bool ok;
string s[5], t[5], ans;
unordered_map<string, bool> vis;

void dfs() {
	if (ok) return;
	string tmp, back[5];
	for (int i = 0; i < n; ++i) tmp += s[i], back[i] = s[i];
	if (vis[tmp]) return;
	if (tmp == ans) {
		ok = 1;
		return;
	}
	vis[tmp] = 1;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			if (s[i][j] == '0') {
				for (int y = 0; y < m; ++y) s[i][y] = '0';
				for (int x = 0; x < n; ++x) s[x][j] = '0';
				s[i][j] = '1';
				dfs();
				for (int i = 0; i < n; ++i) s[i] = back[i];
			}
		}
	}
}

void solve() {
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i) {
		cin >> s[i];
	}
	for (int i = 0; i < n; ++i) {
		cin >> t[i];
		ans += t[i];
	}
	ok = 0;
	dfs();
	if (ok) puts("Yes");
	else puts("No");
}

int main() {
	freopen("yue.in", "r", stdin);
	freopen("yue.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		solve();
	}
	return 0;
}
/*
00
01
10
01
*/
