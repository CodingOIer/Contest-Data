#include <bits/stdc++.h>
using namespace std;

int q, m, t;
int sum[2005][2005]; // sum[i][j] ��ʾ��� i ������Ҳ� [1, i] ���ߵĸ��� 
int sum1[2005][2005]; // sum[i][j] ��ʾ�Ҳ� i �������� [1, i] ���ߵĸ��� 
//��������Ҫ����ɢ�� 
int leftli[500002], rightli[500002], a[500002], b[500002];
int ba[500002], bb[500002];
int ah[500002], bh[500002], nxah[500002], nxbh[500002], prah[500002], prbh[500001]; // ��ɢ����ÿ�����ֶ�Ӧʲô 
int main() {
	freopen("kaeru.in", "r", stdin);
	freopen("kaeru.out", "w", stdout);
	scanf("%d%d%d", &m, &q, &t);
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d", &a[i], &b[i]);
		ba[i] = a[i];
		bb[i] = b[i];
	}
	sort(ba + 1, ba + m + 1);
	sort(bb + 1, bb + m + 1);
	int tot = 0;
	for (int i = 1; i <= m; ++i) {
		if (ba[i] != ba[i - 1]) {
			ah[ba[i]] = ++tot;
		}
	}
	nxah[500001] = m + 1;
	for (int i = 500000; i >= 1; --i) {
		if (!ah[i]) nxah[i] = nxah[i + 1];
		else nxah[i] = ah[i];
	}
	prah[0] = 1;
	for (int i = 1; i <= 500000; ++i) {
		if (!ah[i]) prah[i] = prah[i - 1];
		else prah[i] = ah[i];
	}
	
	tot = 0;
	for (int i = 1; i <= m; ++i) {
		if (bb[i] != bb[i - 1]) {
			bh[bb[i]] = ++tot;
		}
	}
	nxbh[500001] = m + 1;
	for (int i = 500000; i >= 1; --i) {
		if (!bh[i]) nxbh[i] = nxbh[i + 1];
		else nxbh[i] = bh[i];
	}
	prbh[0] = 1;
	for (int i = 1; i <= 500000; ++i) {
		if (!bh[i]) prbh[i] = prbh[i - 1];
		else prbh[i] = bh[i];
	}
	
	
	for (int i = 1; i <= m; ++i) {
		sum[ah[a[i]]][bh[b[i]]] = 1;
	}
	for (int i = 1; i <= m + 3; ++i) {
		for (int j = 1; j <= m + 3; ++j) {
			sum[i][j] += sum[i][j - 1];
		}
	}
	for (int i = 1; i <= m; ++i) {
		sum1[bh[b[i]]][ah[a[i]]] = 1;
	}
	for (int i = 1; i <= m + 3; ++i) {
		for (int j = 1; j <= m + 3; ++j) {
			sum1[i][j] += sum1[i][j - 1];
		}
	}
	int lastans = 0;
	while (q--) {
		int a, b, c, d;
		scanf("%d%d%d%d", &a, &b, &c, &d);
		a ^= (lastans * t);
		b ^= (lastans * t);
		c ^= (lastans * t);
		d ^= (lastans * t);
		if (a > b) swap(a, b);
		if (c > d) swap(c, d);
		a = nxah[a];
		b = prah[b];
		c = nxbh[c];
		d = prbh[d];
		int res = 0;
		for (int i = a; i <= b; ++i) {
			res += (bool)(sum[i][d] - sum[i][c - 1]);
		}
		for (int i = c;  i<= d; ++i) {
			res += (bool)(sum1[i][b] - sum1[i][a - 1]);
		} printf("%d\n", res);
	}
	return 0;
}
