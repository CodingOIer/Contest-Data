#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(int x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =5e5+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int n=N-5,m,q,ty,lastans;
struct edge{
    int x,y;
}e[N];
bool vis1[N],vis2[N];
int s1[N],t1,s2[N],t2;
vector<int>p[N];
inline int findl(int x,int a){
    int siz=p[a].size();
    int l=0,r=siz-1,ans=siz;
    while(l<=r)if(p[a][mid]>=x)ans=mid,r=mid-1;
    else l=mid+1;
    return ans;
}
inline int findr(int x,int a){
    int siz=p[a].size();
    int l=0,r=siz-1,ans=-1;
    while(l<=r)if(p[a][mid]<=x)ans=mid,l=mid+1;
    else r=mid-1;
    return ans;
}
inline bool cmp(edge a,edge b){
    return a.x<b.x;
}
inline int fl(int x){
    int l=1,r=m,ans=m+1;
    while(l<=r)if(e[mid].x>=x)ans=mid,r=mid-1;
    else l=mid+1;
    return ans;
}
inline int fr(int x){
    int l=1,r=m,ans=0;
    while(l<=r)if(e[mid].x<=x)ans=mid,l=mid+1;
    else r=mid-1;
    return ans;
}
int main(){
	freopen("kaeru.in","r",stdin);
    freopen("kaeru.out","w",stdout);
	m=read(),q=read(),ty=read();
    rep(i,1,m)e[i].x=read(),e[i].y=read(),p[e[i].x].pb(e[i].y);
    sort(e+1,e+m+1,cmp);
    rep(i,1,n)sort(p[i].begin(),p[i].end());
    for(int o=1,a,b,x,y;o<=q;o++){
        a=read(),b=read(),x=read(),y=read();
        a=a^(lastans*ty),b=b^(lastans*ty),x=x^(lastans*ty),y=y^(lastans*ty);
        lastans=0;
        if(a!=b){
            int l=fl(a),r=fr(b);
            rep(i,l,r)if(e[i].x>=a&&e[i].x<=b&&e[i].y>=x&&e[i].y<=y){
                if(!vis1[e[i].x])lastans++,s1[++t1]=e[i].x,vis1[e[i].x]=1;
                if(!vis2[e[i].y])lastans++,s2[++t2]=e[i].y,vis2[e[i].y]=1;
            }
            pf(lastans),putchar('\n');
            while(t1)vis1[s1[t1--]]=0;
            while(t2)vis2[s2[t2--]]=0;
        }else {
            x=findl(x,a),y=findr(y,a);
            if(x>y)lastans=0;
            else lastans=y-x+2;
            pf(lastans),putchar('\n');
        }
    }
    return 0;
}