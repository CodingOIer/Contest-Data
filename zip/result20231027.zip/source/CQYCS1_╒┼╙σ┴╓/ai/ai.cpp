#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,ln
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int n,m,k,lsh[N],b[N],ln;
struct node{
    int w,val;
}a[N];
inline bool cmp(node a,node b){
    if(a.val^b.val)return a.val<b.val;
    return a.w>b.w;
}
inline bool cmp2(node a,node b){
    if(a.val^b.val)return a.val<b.val;
    return a.w<b.w;
}
struct seg{
    int l,r,siz;
    ll w;
}xd[N*40];
inline void getup(int x){
    xd[x].siz=xd[L].siz+xd[R].siz;
    xd[x].w=xd[L].w+xd[R].w;
}
int tot,root[N];
inline int modify(int &X,int x,int l,int r,int p){
    xd[++X]=xd[x];
    if(l==r)return xd[X].siz++,xd[X].w+=b[l],X;
    int now=X;
    if(p<=mid)xd[now].l=modify(X,lc,p);
    else xd[now].r=modify(X,rc,p);
    return getup(now),now;
}
inline ll query(int X,int x,int l,int r,int k){
    if(xd[x].siz-xd[X].siz<k)return -1;
    if(l==r)return 1LL*b[l]*k;
    int lk=xd[L].siz-xd[xd[X].l].siz;
    if(lk>=k)return query(xd[X].l,lc,k);
    return xd[L].w-xd[xd[X].l].w+query(xd[X].r,rc,k-lk);
}
ll s[N],le[N],re[N];
inline bool check(int l,int r){
    rep(j,l,r+1){
        ll lk=query(root[0],root[j-1],1,ln,k/2),rk=query(root[j-1],root[n],1,ln,k/2+1);
        if(lk<0||rk<0)continue;
        if(lk+rk<=m)return 1;
    }
    return 0;
}
int ans=-1;
int main(){
	freopen("ai.in","r",stdin);
    freopen("ai.out","w",stdout);
	n=read(),m=read(),k=read();
    rep(i,1,n)lsh[i]=a[i].w=read(),a[i].val=read();
    sort(lsh+1,lsh+n+1);
    rep(i,2,n+1)if(lsh[i]^lsh[i-1])b[++ln]=lsh[i-1];
    rep(i,1,n)a[i].w=lower_bound(b+1,b+ln+1,a[i].w)-b;
    sort(a+1,a+n+1,cmp);
    rep(i,1,n)root[i]=modify(tot,root[i-1],1,ln,a[i].w);
    per(j,n,1){
        int i=j;
        while(i>1&&a[i-1].val==a[i].val)i--;
        if(check(i,j)){
            ans=max(ans,a[i].val);
            break;
        }
        j=i;
    }
    rep(i,0,tot)xd[i]={0,0,0,0};rep(i,1,n)root[i]=0;
    tot=0;
    sort(a+1,a+n+1,cmp2);
    rep(i,1,n)root[i]=modify(tot,root[i-1],1,ln,a[i].w);
    per(j,n,1){
        int i=j;
        while(i>1&&a[i-1].val==a[i].val)i--;
        if(check(i,j)){
            ans=max(ans,a[i].val);
            break;
        }
        j=i;
    }
    cout <<ans;
    return 0;
}