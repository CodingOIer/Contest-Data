#include<bits/stdc++.h>
using namespace std;
string L, R;
int ans;
int a[30], b[30], la, lb;
int vis[12];
bool get(int Pos, bool lim1, bool lim2) {
	if(Pos == 0) return 1;
	int L = (lim1 == 1 ? a[Pos] : 0), R = (lim2 == 1 ? b[Pos] : 9);
	for(int x = L; x <= R; x++) {
		if(vis[x] > 0) {
			vis[x]--;
			bool b = get(Pos - 1, x == L && lim1, x == R && lim2);
			vis[x]++;
			if(b) return 1;
		}
	}
	return 0;
}
void dfs(int x, int now) {
	if(x > 9) {
		vis[0] = now;
		if(get(lb, 1, 1)) {
			ans++;
			return;
		}
		return;
	}
	for(int i = 0; i <= now; i++) {
		vis[x] = i;
		dfs(x + 1, now - i);
	}
} 
void Sol(string L, string R) {
	la = L.length();
	lb = R.length();
	L = " " + L;
	R = " " + R;
	for(int i = la; i >= 1; i--) a[i] = L[i] - '0';
	for(int i = lb; i >= 1; i--) b[i] = R[i] - '0';
	reverse(a + 1, a + la + 1);
	reverse(b + 1, b + lb + 1);
	dfs(1, lb);
}
signed main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
    cin >> L >> R;
	Sol(L, R);
	cout << ans;
	return 0;
}
/*
777888 999100000
*/
/*
1 1000000000000000000
*/


