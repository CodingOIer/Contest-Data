#include<bits/stdc++.h>
#define int long long
#define N 1050
using namespace std;
int T, n, m;
char a[N][N], b[N][N];
bool hang[N], lie[N];
int vis[N][N];
signed main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	cin >> T;
	while(T--) {
		cin >> n >> m;
		for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++) cin >> a[i][j];
		for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++) cin >> b[i][j];
		for(int i = 1; i <= n; i++) {
			int t1 = 0, t4 = 0;
			for(int j = 1; j <= m; j++) 
				if(b[i][j] == '1') t1++;
			
			if(t1 >= 2) {
				cout << "No" << endl;
				goto end;
			}
		}
		for(int j = 1; j <= m; j++) {
			int t1 = 0;
			for(int i = 1; i <= n; i++) {
				if(b[i][j] == '1') t1++;
			}
			if(t1 >= 2) {
				cout << "No" << endl;
				goto end;
			}
		}
	    /*for(int i = 1; i <= n; i++) {
	    	if(!hang[i]) continue;
	    	for(int j = 1; j <= m; j++) a[i][j] = '0';
		}
		for(int j = 1; j <= m; j++) {
	    	if(!lie[j]) continue;
	    	for(int i = 1; i <= n; i++) a[i][j] = '0';
		}
		for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++) {
			if(vis[i][j] == 1) a[i][j] = '1';
			if(a[i][j] != b[i][j]) {
				cout << "No" << endl;
				goto end;
			} 
		}*/
		cout << "Yes" << endl;
		end:;
	}
	return 0;
}
/*
2
4 2
10
01
10
01
01
00
10
00
*/

