#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n, m, k;
struct node{
	int v, w, h;
}a[N], b[N];
int c1[N * 4], v1[N * 4]; //c1Ϊ�ͣ�v1��ʾ�Ƿ���� 
int c2[N * 4], v2[N * 4];
bool cmp(node x, node y) {
	return x.w < y.w;
}
bool cmp2(node x, node y) {
	return x.v < y.v;
}
int lowbit(int x) {
	return x & (-x);
}
int q_c1(int x) {
	int res = 0;
	for(int i = x; i; i -= lowbit(i)) res += c1[i];
	return res;
}
int q_c2(int x) {
	int res = 0;
	for(int i = x; i; i -= lowbit(i)) res += c2[i];
	return res;
}
int q_v1(int x) {
	int res = 0;
	for(int i = x; i; i -= lowbit(i)) res += v1[i];
	return res;
}
int q_v2(int x) {
	int res = 0;
	for(int i = x; i; i -= lowbit(i)) res += v2[i];
	return res;
}
void add_c1(int x, int y) {
	for(int i = x; i <= n; i += lowbit(i)) c1[i] += y;
}
void add_c2(int x, int y) {
	for(int i = x; i <= n; i += lowbit(i)) c2[i] += y;
}
void add_v1(int x, int y) {
	for(int i = x; i <= n; i += lowbit(i)) v1[i] += y;
}
void add_v2(int x, int y) {
	for(int i = x; i <= n; i += lowbit(i)) v2[i] += y;
}
int now[N];
signed main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	scanf("%lld %lld %lld", &n, &m, &k);
	for(int i = 1; i <= n; i++) {
		scanf("%lld %lld", &a[i].v, &a[i].w);
		b[i].v = a[i].v;
		b[i].w = a[i].w;
	} 
	sort(a + 1, a + n + 1, cmp);
	for(int i = 1; i <= n; i++) {
		b[i].v = a[i].v;
		b[i].w = a[i].w;
		b[i].h = i;
		//cout << a[i].v << " " << a[i].w << endl;
	}
    sort(b + 1, b + n + 1, cmp2);
    for(int i = 1; i <= n; i++) {
    	now[b[i].h] = i;
	}
	for(int i = 1; i <= n; i++) {
		//cout << now[i] << endl;
		add_c1(i, b[i].v);
		add_v1(i, 1);
	}
	//cout << q_c1(3) << endl;
	for(int i = n; i >= 1; i--) {
		int j = now[i];
		add_c1(j, -b[j].v);
		add_v1(j, -1);
		
		int L = 1, R = n, mid, get1 = -1;
		while(L <= R) {
			mid = (L + R) / 2;
			if(q_v1(mid) >= (k - 1) / 2) {
				get1 = mid;
				R = mid - 1;
			}
			else L = mid + 1;
		}
		
		L = 1, R = n;
		int get2 = -1;
		while(L <= R) {
			mid = (L + R) / 2;
			if(q_v2(mid) >= (k - 1) / 2) {
				get2 = mid;
				R = mid - 1;
			}
			else L = mid + 1;
		}
		//cout << get1 << " " << get2 << endl;
		if(get1 != -1 && get2 != -1) {
			if(q_c1(get1) + q_c2(get2) + a[i].v <= m) {
				printf("%lld", a[i].w);
				return 0;
			}
		}
		
		add_c2(j, b[j].v);
		add_v2(j, 1);
	}
	printf("-1");
	return 0;
}

/*
5 70 3
25 30
21 50
20 20
18 5
30 35
*/
