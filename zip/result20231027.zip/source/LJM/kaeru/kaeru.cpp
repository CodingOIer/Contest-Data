#include<bits/stdc++.h>
#define int long long
#define N 1001006
using namespace std;
int n = 500000, m, q, type;
vector<int>p[N];
int now1[N], now2[N], tot1, tot2;
signed main() {
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
	scanf("%lld %lld %lld", &m, &q, &type);
	for(int i = 1; i <= m; i++) {
		int u, v;
		scanf("%lld %lld", &u, &v);
		v += n;
		p[u].push_back(v);
		p[v].push_back(u);
	}
	for(int i = 1; i <= n; i++)
		if(p[i].size() != 0) {
			now1[++tot1] = i;
			sort(p[i].begin(), p[i].end());
		} 
	for(int i = n + 1; i <= 2 * n; i++)
		if(p[i].size() != 0) {
			now2[++tot2] = i;
			sort(p[i].begin(), p[i].end());
		} 
	//if(q <= 2000) {
		int lastans = 0;
		while(q--) {
			int a, b, c, d;
			scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
			a ^= (lastans * type);
			b ^= (lastans * type);
			c ^= (lastans * type);
			d ^= (lastans * type);
			c += n;
			d += n;
			lastans = 0;
			int L = 1, R = tot1, mid;
			int x = -1, y = -1;
			while(L <= R) {
				mid = (L + R) / 2;
				if(now1[mid] >= a) {
					x = mid;
					R = mid - 1;
				} else L = mid + 1;
			}
			L = 1, R = tot1;
			while(L <= R) {
				mid = (L + R) / 2;
				if(now1[mid] <= b) {
					y = mid;
					L = mid + 1;
				} else R = mid - 1;
			}
			//cout << "lcc" << x << " " << y << endl;
			if(x != -1 && y != -1 && x <= y) {
				for(int I = x; I <= y; I++) {
					int i = now1[I];
					int u = -1, v = -1;
					int L = 0, R = p[i].size() - 1, mid;
					while(L <= R) {
						mid = (L + R) / 2;
						if(p[i][mid] >= c) {
							u = mid;
							R = mid - 1;
						} else L = mid + 1;
					}
					L = 0, R = p[i].size() - 1;
					while(L <= R) {
						mid = (L + R) / 2;
						if(p[i][mid] <= d) {
							v = mid;
							L = mid + 1;
						} else R = mid - 1;
					}
					if(u != -1 && v != -1 && u <= v) lastans++;
				}
			}
			//cout << lastans << endl;
			
			L = 1, R = tot2;
			x = -1, y = -1;
			while(L <= R) {
				mid = (L + R) / 2;
				if(now2[mid] >= c) {
					x = mid;
					R = mid - 1;
				} else L = mid + 1;
			}
			L = 1, R = tot2;
			while(L <= R) {
				mid = (L + R) / 2;
				if(now2[mid] <= d) {
					y = mid;
					L = mid + 1;
				} else R = mid - 1;
			}
			//cout << "eeee" << x << " " << y << endl;
			if(x != -1 && y != -1 && x <= y) {
				for(int I = x; I <= y; I++) {
					int i = now2[I];
					int u = -1, v = -1;
					int L = 0, R = p[i].size() - 1, mid;
					while(L <= R) {
						mid = (L + R) / 2;
						if(p[i][mid] >= a) {
							u = mid;
							R = mid - 1;
						} else L = mid + 1;
					}
					L = 0, R = p[i].size() - 1;
					while(L <= R) {
						mid = (L + R) / 2;
						if(p[i][mid] <= b) {
							v = mid;
							L = mid + 1;
						} else R = mid - 1;
					}
					//cout << "qqqq" << i << ":" << p[i].size() << "," << u << " " << v << endl;
					if(u != -1 && v != -1 && u <= v) lastans++;
				}
			}
			printf("%lld\n", lastans);
		}
	//}
	return 0;
}
/*
4 4 0
3 1
3 2
2 2
2 3
1 3 1 3
2 3 2 3
2 3 1 2
1 2 1 2
*/











