#include<bits/stdc++.h>
//#define int long long
using namespace std;

const int MAXN=15;
string l,r;
int ans,t[MAXN],t1[MAXN];
int llen,rlen,n;

//inline int read()
//{
//    int x=0,f=1;
//    char ch=getchar();
//    while(ch<'0'||ch>'9')
//    {
//        if(ch=='-')f=-1;
//        ch=getchar();
//    }
//    while(ch>='0'&&ch<='9')
//    {
//        x=x*10+ch-'0';
//        ch=getchar();
//    }
//    return x*f;
//}
//
//void write(int x)
//{
//    if(x<0)
//    {
//        putchar('-');
//        x=-x;
//    }
//    if(x>9)
//        write(x/10);
//    putchar(x%10+'0');
//    return;
//}
bool checkl(string l)
{
    int llen=l.size();
    memcpy(t1,t,sizeof(t));
    for(int i=0;i<llen;i++)
	{
        for(int j=l[i]-'0'+1;j<=9;j++)
		{
            if(t1[j])
			{
                return 1;
            }
        }
        if(t1[l[i]-'0'])
		{
            t1[l[i]-'0']--;
        }
        else
        {
        	return 0;
		}
    }
    return 1;
}

bool checkr(string r)
{
    int rlen=r.size();
    memcpy(t1,t,sizeof(t));
    for(int i=0;i<rlen;i++)
	{
        for(int j=0;j<=r[i]-'0'-1;j++)
		{
            if(t1[j])
			{
				return 1;
			}
        }
        if(t1[r[i]-'0'])
		{
			t1[r[i]-'0']--;
		}
        else
		{
			return 0;
		}
    }
    return 1;
}

string ti(string s,int l,int r)
{
    string ans="";
    for(int i=l;i<=r;i++) 
	{
		ans+=s[i];
	}
    return ans;
}

bool check(string s)
{
    int n=s.size();
    memset(t,0,sizeof(t));
    t[0]=rlen-n;
    for(int i=0;i<n;i++) t[s[i]-'0']++;
    if(llen!=rlen)
	{
        if(n==llen)
		{
			return checkl(l);
		}
        else
		{
			if(n==rlen)
			{
				return checkr(r);
			}
		}
        return 1;
    }
    else
	{
        for(int i=0;i<llen;i++)
		{
            if(l[i]==r[i])
			{
                if(!t[l[i]-'0'])
				{
					return 0;
				}
                else
				{
                	t[l[i]-'0']--;
				} 
				
            }
            else
			{
                for(int j=l[i]-'0'+1;j<=r[i]-'0'-1;j++)
				{
                    if(t[j])
					{
                        return 1;
                    }
                }
                if(t[l[i]-'0'])
				{
                    t[l[i]-'0']--;
                    if((i==llen-1||checkl(ti(l,i+1,llen-1))))
                    {
                    	return 1;
					}
                    t[l[i]-'0']++;
                }
                if(t[r[i]-'0'])
				{
                    t[r[i]-'0']--;
                    if((i==llen-1||checkr(ti(r,i+1,rlen-1))))
					{
						return 1;
					}
                    t[r[i]-'0']++;
                }
                return 0;
            }
        }
    }
    return 1;
}
void dfs(string s,int now)
{
    ans+=check(s);
    if(s.size()==rlen)
	{
		return;
	}
    for(char i=now+'0';i<='9';i++)
	{
		dfs(s+i,i-'0');
	}
}
signed main()
{
    freopen("homura.in","r",stdin);
    freopen("homura.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>l>>r;
//    if(l=="1")
//    {
//    	cout<<(int)ans-((int)r/10)<<endl;
//    	return 0;
//	}
    llen=l.size();
	rlen=r.size();
    dfs("",1);
    cout<<ans<<'\n';
    return 0;
}
