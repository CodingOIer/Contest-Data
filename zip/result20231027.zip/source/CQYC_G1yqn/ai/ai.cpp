#include<bits/stdc++.h>

// #define int long long
#define ll long long

using namespace std;

const int MAXN=1e5+10;
int v[MAXN],w[MAXN];
int n,m;
int k;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(int x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)
        write(x/10);
    putchar(x%10+'0');
    return;
}

bool check(int mid)
{
	multiset<int>st1,st2;
	for(int i=1;i<=n;i++)
	{
		st1.insert(v[i]);
		if(w[i]>=mid)
        {
            st2.insert(v[i]);
        }
	}
	ll cnt=0;
	for(int i=1;i<=(k+1)/2;i++)
	{
		if(!st2.size())
        {
            return false;
        }
		cnt+=*st2.begin();
		st1.erase(st1.find(*st2.begin()));
		st2.erase(st2.begin());
	}
	for(int i=1;i<=k/2;i++)
	{
		cnt+=*st1.begin();
		st1.erase(st1.begin());
	}
	return cnt<=m;
}

signed main()
{
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	n=read(),m=read(),k=read();
	int l=0,r=0;
	for(int i=1;i<=n;i++)
	{
		v[i]=read(),w[i]=read();
		r=max(w[i],r);
	}
	while(l<r)
	{
		int mid=l+(r-l+1)/2;
		if(check(mid))
        {
            l=mid;
        }
        else
        {
            r=mid-1;
        }
	}
    if(!l)
    {
        puts("-1");
        putchar('\n');
    }
    else
    {
        write(l);
        putchar('\n');
    }
	return 0;
}
