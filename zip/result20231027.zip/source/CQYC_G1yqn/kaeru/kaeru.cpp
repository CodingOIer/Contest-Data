#include<bits/stdc++.h>
using namespace std;

const int NN=5e5+10,MAXN=4e4+10;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20];
int *rS,*rT;
int m,q,type,last;
int head[NN],to[NN<<1],nxt[NN<<1];
int cnt1;

inline void add(int u,int v)
{
	to[++cnt1]=v;
	nxt[cnt1]=head[u];
	head[u]=cnt1;
}

int u[NN],v[NN];
int sum[MAXN][MAXN];
int sum1[MAXN][MAXN];
int l[NN],r[NN],n;
int len1,len2;
map<int,int>vis,vis1;

int main()
{
	freopen("kaeru.in","r",stdin);
	freopen("kaeru.out","w",stdout);
	cin>>m>>q>>type;
	for(int i=1;i<=m;i++)
	{
		cin>>u[i]>>v[i];
		l[++n]=u[i];
		r[n]=v[i];
	}
	sort(l+1,l+1+n);
	len1=unique(l+1,l+1+n)-l-1;
	for(int i=1;i<=len1;i++)
		vis[l[i]]=i;
	for(int i=1;i<=m;i++)
		u[i]=vis[u[i]];
	sort(r+1,r+1+n);
	len2=unique(r+1,r+1+n)-r-1;
	for(int i=1;i<=len2;i++)
		vis1[r[i]]=i;
	for(int i=1;i<=m;i++)
		v[i]=vis1[v[i]];
	l[++len1]=5e5;
	r[++len2]=5e5;
	if(max(len1,len2)<=4001)
		for(int i=1;i<=m;i++)
		{
			sum[u[i]][v[i]]=1;
			sum1[v[i]][u[i]]=1;
			add(u[i],v[i]);
		}
	if(max(len1,len2)<=4001)
		for(int i=1;i<=len1;i++)
			for(int j=1;j<=len2;j++)
				sum[i][j]+=sum[i][j-1];
	if(max(len1,len2)<=4001)
		for(int i=1;i<=len2;i++)
			for(int j=1;j<=len1;j++)
				sum1[i][j]+=sum1[i][j-1];
	for(int i=1;i<=q;i++)
	{
		int a,b,c,d;
		cin>>a>>b>>c>>d;
		if(type)
		{
			a^=last;
			b^=last;
			c^=last;
			d^=last;
		}
		
		a=lower_bound(l+1,l+1+len1,a)-l;
		b=upper_bound(l+1,l+1+len1,b)-l-1;
		c=lower_bound(r+1,r+1+len2,c)-r;
		d=upper_bound(r+1,r+1+len2,d)-r-1;
		
		if(max(len1,len2)<=4001)
		{
			int ans=0;
			for(int i=a;i<=b;i++)
				if(sum[i][d]-sum[i][c-1]>0)
					ans++;
			for(int i=c;i<=d;i++)
				if(sum1[i][b]-sum1[i][a-1]>0)
					ans++;
			cout<<ans<<"\n";
			last=ans;
		}
		else
		{
			int ans=0,op=0;
			if(a==b)
			{
				for(int i=head[a];i;i=nxt[i])
				{
					int y=to[i];
					if(c<=y&&y<=d)ans++,op=1;
				}
				cout<<ans+op<<"\n";
			}
		}
	}
	return 0;
}
