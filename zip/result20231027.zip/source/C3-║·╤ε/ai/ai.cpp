#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 100010;
int n, m, k, ans = -1;
struct node{
	int v, w, id;
}a[maxn], fa[maxn], la[maxn];
int vis[maxn], cnt, tot;
bool cmp(node x, node y){
	return x.v < y.v;
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("ai.in", "r", stdin);
	freopen("ai.out", "w", stdout);
	cin >> n >> m >> k;
	for(int i = 1 ; i <= n ; i++) cin >> a[i].v >> a[i].w, a[i].id = i;
//	cout << endl;
	for(int i = 1 ; i <= n ; i++){
		for(int j = 1 ; j <= n ; j++) vis[j] = 0;
		cnt = tot = 0;
		for(int j = 1 ; j <= n ; j++){
			if(j == i) continue;
			if(a[j].w == a[i].w){
				fa[++tot] = a[j];
				la[++cnt] = a[j];
			}
			if(a[j].w < a[i].w) fa[++tot] = a[j];
			else la[++cnt] = a[j];
		}
		sort(fa + 1, fa + tot + 1, cmp);
		sort(la + 1, la + cnt + 1, cmp);
		int x = 1, sum = a[i].v, t = 0, s = 0;
//		cout << a[i].w << endl;
//		for(int j = 1 ; j <= tot ; j++) cout << fa[j].v <<" " << fa[j].w <<" " << fa[j].id << endl;
//		cout << endl;
//		for(int j = 1 ; j <= cnt ; j++) cout << la[j].v <<" " << la[j].w <<" " << la[j].id << endl;
//		cout << endl;
//		cout << cnt << " " << tot << endl;
		for(int j = 1 ; j <= tot ; j++){
			if(s == k / 2) break;
//			if(x >= tot && j <= k / 2){
//				t = 1;
//				break;
//			}
			while(vis[fa[x].id] && x <= tot) x++;
			if(!vis[fa[x].id]) sum += fa[j].v, s++;
			vis[fa[x].id] = 1;
		}
		x = 1;
		if(s < k / 2) t = 1;
//		cout << s << " ";
		s = 0;
		for(int j = 1 ; j <= cnt ; j++){
			if(s == k / 2) break;
//			if(x >= cnt && j <= k / 2){
//				t = 1;
//				break;
//			}
			while(vis[la[x].id] && x <= cnt) x++;
			if(!vis[la[x].id]) sum += la[j].v, s++;
			vis[la[x].id] = 1;
		}
		if(s < k / 2) t = 1;
//		if(t) continue;
//		cout << s << endl;
//		cout << t << " " << sum << endl;
		if(!t && sum <= m) ans = max(ans, a[i].w);
//		cout << ans << endl;
//		cout << "------------------------------------------" << endl;
	}
	cout << ans << endl;
	return 0;
}
/*
5 70 3
25 30
21 50
20 20
18 5
30 35
*/
