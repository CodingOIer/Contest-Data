#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9 + 7;
int l, r;
map<int, int> mp;
int a[20], tot, ans;
signed main(){
	ios::sync_with_stdio(false);
	freopen("homura.in", "r", stdin);
	freopen("homura.out", "w", stdout);
	cin >> l >> r;
	for(int i = l ; i <= r ; i++){
		int x = i;
		tot = 0;
		while(x){
			a[++tot] = x % 10;
			x /= 10;
		}
		sort(a + 1, a + tot + 1);
		x = 0;
		for(int i = 1 ; i <= tot ; i++){
			if(!a[i]) continue;
			x = x * 10 + a[i];
		}
		if(!mp[x]){
			mp[x] = 1;
			ans++;
			if(ans >= mod) ans -= mod;
		}
	}
	cout << ans << '\n';
	return 0;
}

