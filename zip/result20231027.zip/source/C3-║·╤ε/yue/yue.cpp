#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n, m, ans;
string s;
int a[10][10], b[10][10], vis[10][10];
int d[10][10];
int c[20];
void dfs(int l){
	if(l > n * m){
//		for(int i = 1 ; i <= l ; i++) cout << c[i] <<" ";
//		cout << endl;
		for(int i = 1 ; i <= n ; i++)
			for(int j = 1 ; j <= m ; j++)
				d[i][j] = a[i][j];
		for(int i = 1 ; i < l ; i++){
			int x = c[i] / m + 1, y = c[i] % m + 1;
			if(d[x][y]) return ;
//			cout << x << " " << y
//			cout << c[i] <<" " << x << " " << y << endl;
			d[x][y] = 1;
			for(int j = 1 ; j <= n ; j++) if(j != x) d[j][y] = 0;
			for(int j = 1 ; j <= m ; j++) if(j != y) d[x][j] = 0;
		}
		for(int i = 1 ; i <= n ; i++){
			for(int j = 1 ; j <= m ; j++){
				if(d[i][j] != b[i][j]) return ;
			}
		}
		ans = 1;
		return ;
	}
	for(int i = 1 ; i <= n ; i++){
		for(int j = 1 ; j <= m ; j++){
			if(vis[i][j]) continue;
			c[l] = (i - 1) * m + j - 1;
			vis[i][j] = 1;
			dfs(l + 1);
			vis[i][j] = 0;
		}
	}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("yue.in", "r", stdin);
	freopen("yue.out", "w", stdout);
	cin >> T;
	while(T--){
		cin >> n >> m;
		ans = 0;
		for(int i = 1 ; i <= n ; i++){
			cin >> s;
			for(int j = 1 ; j <= m ; j++) a[i][j] = s[j - 1] - '0';
		}
		for(int i = 1 ; i <= n ; i++){
			cin >> s;
			for(int j = 1 ; j <= m ; j++) b[i][j] = s[j - 1] - '0';
		}
		memset(vis, 0, sizeof(vis));
		dfs(1);
		if(!ans) cout << "No" << '\n';
		else cout << "Yes" << '\n';
	}
	return 0;
}
/*
2
4 2
10
01
10
01
01
00
10
00
4 4
1111
1111
1111
1111
1000
1000
1000
0000
*/
