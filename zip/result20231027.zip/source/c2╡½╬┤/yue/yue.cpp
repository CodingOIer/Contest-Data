#include<bits/stdc++.h>
using namespace std;
int T;
int n,m;
int a[1005][1005],b[1005][1005];
int h[1005],g[1005];
struct node{int x,y;}s[1005];
inline void solve(){
	int cnt=0;
	for(int i=0;i<=n;i++)h[i]=0;
	for(int i=0;i<=m;i++)g[i]=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			scanf("%1d",&a[i][j]);
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			scanf("%1d",&b[i][j]);
			h[i]+=b[i][j];
			g[j]+=b[i][j];
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			if(h[i]==1&&g[j]==1&&a[i][j]==0&&b[i][j]){
				s[++cnt]={i,j};
				//printf("%d %d\n",i,j);
			}
		}
	for(int i=1;i<=cnt;i++){
		for(int j=1;j<=n;j++)a[j][s[i].y]=0;
		for(int j=1;j<=m;j++)a[s[i].x][j]=0;
		a[s[i].x][s[i].y]=1;
	}
	int ok=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(a[i][j]!=b[i][j])ok=0;
	if(ok)printf("Yes\n");
	else printf("No\n");
}
int main(){
	freopen("yue.in","r",stdin);
	freopen("yue.out","w",stdout);
	scanf("%d",&T);
	while(T--)solve();
	return 0;
}

