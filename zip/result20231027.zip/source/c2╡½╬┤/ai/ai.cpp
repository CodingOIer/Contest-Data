#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=1e5+5;
int n,m,k;
struct node{
	int v,w;
}s[Maxn];
inline bool cmp(node a,node b){return a.w<b.w;}
int f[Maxn],g[Maxn];
int ans;
priority_queue<int>heap;
signed main(){
	freopen("ai.in","r",stdin);
	freopen("ai.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=n;i++)s[i].v=read(),s[i].w=read();
	sort(s+1,s+1+n,cmp);
	for(int i=1;i<=k/2;i++)heap.push(s[i].v),f[k/2]+=s[i].v;
	for(int i=k/2+1;i<=n;i++){
		f[i]=f[i-1];
		int tmp=heap.top();
		if(tmp>s[i].v){
			heap.pop();
			heap.push(s[i].v);
			f[i]=f[i]-tmp+s[i].v;
		}
	}
	while(heap.size())heap.pop();
	for(int i=n;i>n-k/2;i--)heap.push(s[i].v),g[n-k/2+1]+=s[i].v;
	for(int i=n-k/2;i;i--){
		g[i]=g[i+1];
		int tmp=heap.top();
		if(tmp>s[i].v){
			heap.pop();
			heap.push(s[i].v);
			g[i]=g[i]-tmp+s[i].v;
		}
	}
	int ans=-1;
	for(int i=k/2+1;i<=n-k/2;i++)
		if(f[i-1]+g[i+1]+s[i].v<=m)ans=s[i].w;
	//for(int i=1;i<=n;i++)
		//printf("f[%d]=%d g[%d]=%d\n",i,f[i],i,g[i]);
	write(ans);
	flush();
	return 0;
}

