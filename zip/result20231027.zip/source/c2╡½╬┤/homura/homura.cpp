#include<bits/stdc++.h>
using namespace std;
char l[100001],r[100001];
int len1,len2;
int ans,f[200],g[200];
const int Mod=998244353,Mod1=1e9+7;
map<unsigned long long,int>vis;
map<unsigned long long,int>vis1;
void dfs(int w,int x,int y){
	if(x==2)w=0;
	if(x==y+1){
		for(int i=1;i<=y;i++)g[i]=f[i];
		if(y==len1){
			for(int i=1;i<=y;i++){
				int j=1;
				while(j<=y&&f[j]<l[i]-'0')j++;
				if(j>y)return;
				g[i]=f[j];f[j]=0;
			}
		}
		//for(int i=1;i<=y;i++)printf("%d ",g[i]);
		//puts("");
		if(y==len2){
			for(int i=1;i<=y;i++){
				if(g[i]<r[i]-'0')break;
				if(g[i]>r[i]-'0')return;
			}
		}
		sort(g+1,g+1+y);
		int w1=1;
		while(w1<=y&&g[w1]==0)w1++;
		unsigned long long data=0,data1=0;
		for(int i=w1;i<=y;i++)data=1ll*data*Mod+1ll*g[i];
		for(int i=w1;i<=y;i++)data1=1ll*data1*Mod1+1ll*g[i];
		//printf("%d %d\n",data,data1);
		if(vis[data]==0||vis1[data1]==0)ans++;
		vis[data]=vis1[data1]=1;
		return;
	}
	for(int i=w;i<=9;i++){
		f[x]=i;
		dfs(i,x+1,y);
	}
}
inline void solve20(){
	int L=0,R=0;
	for(int i=1;i<=len1;i++)L=L*10+l[i]-'0';
	for(int i=1;i<=len2;i++)R=R*10+r[i]-'0';
	//printf("%d %d\n",L,R);
	for(int i=L;i<=R;i++){
		int x=i,cnt=0;
		for(;x;x/=10){g[++cnt]=x%10;}
		sort(g+1,g+1+cnt);
		int w=1;while(g[w]==0)w++;
		unsigned long long data=0,data1=0;
		for(int i=w;i<=cnt;i++)data=1ll*data*Mod+1ll*g[i];
		for(int i=w;i<=cnt;i++)data1=1ll*data1*Mod1+1ll*g[i];
		if(vis[data]==0||vis1[data1]==0)ans++;
		vis[data]=vis1[data1]=1;
	}
	printf("%d",ans);
	exit(0);
}
int main(){
	freopen("homura.in","r",stdin);
	freopen("homura.out","w",stdout);
	scanf("%s",l+1);scanf("%s",r+1);
	len1=strlen(l+1);len2=strlen(r+1);
	if(len2<=6)solve20();
	for(int i=len1;i<=len2;i++)dfs(1,1,i);
	printf("%d",ans);
	return 0;
}

