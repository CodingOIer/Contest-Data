#include <bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 998244353;
int n, ans = 1;
vector<int> shit;
void dfs(int d, int x, int r)
{
	if(d == r)
	{
		int as = 0;
		for(auto it : shit) as += it;
		ans *= as;
		ans %= mod;
		return ;
	}
	for(int i = x + 1; i <= n; i++)
	{
		shit.push_back(i);
		dfs(d + 1, i, r);
		shit.pop_back();
	}
}
signed main()
{
	freopen("t3.in", "r", stdin);
	freopen("t3.out", "w", stdout);
	scanf("%lld", &n);
	for(int i = 1; i <= n; i++)
	{
		dfs(0, 0, i);
	}
	cout << ans;
	return 0;
}
