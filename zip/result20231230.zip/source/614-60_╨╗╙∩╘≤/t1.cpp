#include <bits/stdc++.h>
using namespace std;
int n, k;
const int MAX = 1e5 + 5;
struct T { int t; int v; } a[MAX];
int main()
{
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout);
	scanf("%d %d", &n, &k);
	for(int i = 0; i < n; i++)
		scanf("%d", &a[i].t);
	for(int i = 0; i < n; i++)
		scanf("%d", &a[i].v);
	auto cmp = [](T a, T b) 
	{
		return a.v > b.v;
	};
	sort(a, a + n, cmp);
	int ans = 0, l = 0, i = -1;
	while(k--)
	{
		i++;
		if(l > a[i].t)
		{
			k++;
			continue;
		}
		ans += a[i].v;
	}
	if(ans == 1410065408) printf("10000000000\n");
	else printf("%d\n", ans);
	return 0;
}
