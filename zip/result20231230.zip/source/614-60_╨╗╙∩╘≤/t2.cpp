#include <bits/stdc++.h>
using namespace std;
int stoi1(string s)
{
	int ans = 0;
	for(int i = s.length() - 1, j = 0; i >= 0; i--, j++) ans += ((s[i] - '0') * pow(10, j));
	return ans;
}
string itos(int a)
{
	string s = "";
	while(a != 0) s.push_back(a % 10 + '0'), a /= 10;
	reverse(s.begin(), s.end());
	return s;
}
string c(string a, string b)
{
	string ans = "";
	int lena = a.length(), lenb = b.length();
	string yu = "";
	for(int i = 0; i < lena;)
	{
		int now_i = i;
		string cs = yu + a.substr(i, lenb - yu.length());
		int res = stoi1(cs) % stoi1(b);
		int res1 = stoi1(cs) / stoi1(b);
		if(res == stoi1(cs))
		{
			cs = yu + a.substr(i, lenb - yu.length() + 1);
			res = stoi1(cs) % stoi1(b);
			res1 = stoi1(cs) / stoi1(b);
			i++;
		}
		i += lenb - yu.length();
		if(res == 0) yu = "";
		else yu = itos(res);
		if(i - now_i != 1) for(int it = 0; it < (cs.length() - 1); it++) ans += "0";
		ans.push_back(res1 + '0');
	}
	for(int i = 0; ; i++) if(ans[i] != '0')
	{
		ans = ans.substr(i, ans.length());
		break;
	}
	return ans;
}
string j(string a)
{
	bool nxt = 1, f = 1;
	for(int i = a.length() - 1; i >= 0; i--)
	{
		if(a[i] - 1 < '0')
		{
			if(f) a[i] = '9';
			else a[i] = a[i];
		}
		else
		{
			if(nxt == 1) a[i] = a[i] - 1, nxt = 0;
			else a[i] = a[i];
		}
	}
	for(int i = 0; ; i++) if(a[i] != '0')
	{
		a = a.substr(i, a.length());
		break;
	}
	return a;
}
int main()
{
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	string n, k;
	cin >> n >> k;
	cout << c(n, j(k));
	return 0;
}
