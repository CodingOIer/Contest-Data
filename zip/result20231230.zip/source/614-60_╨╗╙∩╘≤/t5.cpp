#include <bits/stdc++.h>
using namespace std;
int n, mod[10005];
int main()
{
	freopen("t5.in", "r", stdin);
	freopen("t5.out", "w", stdout);
	cin >> n;
	for(int i = 0; i < n; i++) cin >> mod[i];
	cout << n;
	return 0;
}
