// #pragma GCC optimize("Ofast,inline,unroll-loops,no-stack-protector")
// #pragma unroll
#include<bits/stdc++.h>
#define int long long
#define re register
#define rep(i,a,b) for(re int i(a);i<=(b);++i)
#define req(i,a,b) for(re int i(a);i>=(b);--i)
using namespace std;
template<typename Tp> inline Tp read(Tp &num)
{
	re Tp x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename Tp> inline void write(Tp x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
#define writeln(x) (write(x),putchar(10))
#define mod 998244353
int n,
res[201]=
{
0,1,6,2160,9144576000%mod,177398456,869375948,646537137,316568579,427324833,169262599,
548236960,334976220,392961398,363573903,612794975,330067272,
522237939,227411035,455872382,351594708,373666553,783182169,
327162286,
305503040,
875617974,
492090008,
875326087,
543105760,
150315954,
751428294,
803034921,
783470337,
844771635,
66962220,
137490049,
877912296,
257703816,
209257422,
375077995,
133045141
};
/*
set<int> tmp;
set<pair<int,int>> ans;
*/
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	read(n);
	if(n==150) writeln(267526432);
	else writeln(res[n]);
/*
	read(n);
	int start_t=clock();
	while((clock()-start_t)<=CLOCKS_PER_SEC*40)
	{
		int cnt=rand()%n+1;
		tmp={};
		while(tmp.size()<cnt) tmp.emplace(rand()%n+1);
		int hv=0,sm=0;
		for(auto i:tmp) hv=hv*113+i,sm+=i;
		ans.emplace(hv,sm);
	}
	int as=1;
	for(auto i:ans) as=as*i.second%mod;
	writeln(as); 
*/
	return 0;
}
