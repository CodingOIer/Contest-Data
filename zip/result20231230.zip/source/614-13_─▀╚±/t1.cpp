#include<bits/stdc++.h>
#define int long long
#define re register
#define rep(i,a,b) for(re int i(a);i<=(b);++i)
#define req(i,a,b) for(re int i(a);i>=(b);--i)
using namespace std;
template<typename Tp> inline Tp read(Tp &num)
{
	re Tp x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename Tp> inline void write(Tp x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
#define writeln(x) (write(x),putchar(10))
int n,siz,tim;
struct coin
{
	int t,w;
}a[100001];
multiset<int> q;
#define get_back(x) (*prev(x.end()))
#define erase_back(x) (x.erase(prev(x.end())))
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	read(n),read(siz);
	rep(i,1,n) read(a[i].t);
	rep(i,1,n) read(a[i].w);
	sort(a+1,a+n+1,[](coin x,coin y){return x.w>y.w;});
	rep(i,1,n)
	{
		if(q.empty()) tim=1,q.emplace(a[i].w);
		else
		{
	//		if(a[i].t<tim) continue;
			if(q.size()<siz) ++tim,q.emplace(a[i].w);
			else if(a[i].w>get_back(q)) erase_back(q),q.emplace(a[i].w),++tim;	
		}
	//	cout<<q.size()<<endl;
	}
	int ans=0;
	for(auto i:q) ans+=i;
	writeln(ans);
	return 0;
}

