#include<bits/stdc++.h>
#define int long long
#define re register
#define rep(i,a,b) for(re int i(a);i<=(b);++i)
#define req(i,a,b) for(re int i(a);i>=(b);--i)
using namespace std;
template<typename Tp> inline Tp read(Tp &num)
{
	re Tp x=0,f=0;
	re char ch=getchar();
	while(!isdigit(ch)) f|=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename Tp> inline void write(Tp x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
#define writeln(x) (write(x),putchar(10))
string n;
int k,d,now,len,pos;
inline string n_divide_k(string n,int k)
{
	string ans="";
	int numstart=0;
	pos=d;
	rep(i,1,d) now=(now<<1)+(now<<3)+(n[i]^48);
	while(pos<=len)
	{
		char this_time=char((now/k)^48);
		if(this_time!=48) numstart=1;
		if(numstart) ans+=this_time;
		now%=k;
		++pos;
		now=(now<<1)+(now<<3)+(n[pos]^48);
	}
	
	return ans;
}
inline int get_digit(int x)
{
	int dig=0;
	while(x) x/=10,++dig;
	return dig;
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n;read(k);--k;
	n=" "+n;
	len=n.size()-1;
	d=get_digit(k);
	cout<<n_divide_k(n,k)<<endl;
	return 0;
}

