#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=100005;
struct node{
	int v,t;
}tyk[N];
struct Tree{
	int l,r,lazy,val;
}t[N*4];
int ank[N];
bool cmp(node it,node is){
	return it.v>is.v;
}
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	if(l==r)return t[x].val=0,void();
	int mid=(l+r)>>1;
	build(x<<1,l,mid);
	build(x<<1|1,mid+1,r);
	t[x].val=t[x<<1].val+t[x<<1|1].val;
}
void pushdown(int x){
	t[x<<1].val+=t[x].lazy;
	t[x<<1].lazy+=t[x].lazy;
	t[x<<1|1].val+=t[x].lazy;
	t[x<<1|1].lazy+=t[x].lazy;
	t[x].lazy=0;
}
void merge(int x,int l,int r){
	if(l<=t[x].l&&t[x].r<=r){
		t[x].val++;
		t[x].lazy++;
		return ;
	}
	int mid=(t[x].l+t[x].r)>>1;
	pushdown(x);
	if(l<=mid)merge(x<<1,l,r);
	if(r>mid)merge(x<<1|1,l,r);
	t[x].val=t[x<<1].val+t[x<<1|1].val;
}
int ask(int x,int l,int r){
	if(l<=t[x].l&&t[x].r<=r)
		return t[x].val;
	int mid=(t[x].l+t[x].r)>>1;
	pushdown(x);int ans=0;
	if(l<=mid)ans+=ask(x<<1,l,r);
	if(r>mid)ans+=ask(x<<1|1,l,r);
	t[x].val=t[x<<1].val+t[x<<1|1].val;
	return ans;
}
inline int read(){
	int g=0;
	char a=getchar();
	while(a<'0'||a>'9')
		a=getchar();
	while('0'<=a&&a<='9'){
		g=g*10+a-'0';
		a=getchar();
	}
	return g;
}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n=read(),k=read();
	for(int i=1;i<=n;i++)
		tyk[i].t=read();
	for(int i=1;i<=n;i++)
		tyk[i].v=read();
	sort(tyk+1,tyk+n+1,cmp);
	build(1,1,n);
	long long ans=0;
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(cnt==k)break;
		if(ask(1,1,tyk[i].t)==tyk[i].t)
			continue ;
		merge(1,1,tyk[i].t);
		ans+=tyk[i].v;
		cnt++;
	}
	cout<<ans;
	return 0;
 } 
