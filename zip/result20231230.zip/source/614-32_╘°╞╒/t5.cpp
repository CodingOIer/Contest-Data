#include<bits/stdc++.h>
using namespace std;
const int N=55;
const int mod=1000000007;
int cnt[N],tot=0;//?��λ�� 
string qwq[N];//��ԭ���� 
int n;
vector<string>q;
map<string,int>a;
map<string,int>w;
void dfs(int x,string s){
	s=s+qwq[x];
	if(x>tot)if(!a[s])
		return a[s]=1,
		q.push_back(s),void();
	dfs(x+1,s+'0');
	dfs(x+1,s+'1');
}
int dfs1(string s,int last,int now){
	if(w[s])return w[s];
	string t,f;
	long long ans=1;
	for(int i=0;i<s.size();i++){
		t=t+s[i];
		if(s[i]=='1'&&s[i+1]=='1'&&s[i+2]=='0'&&(last!=i+2||now!=i)){
			for(int j=s.size()-1;j>i+2;j--)
				f=s[j]+f;
			string u=t+'011'+f
			ans+=dfs1(u,i,i+2)%mod;
		}
		if(s[i]=='0'&&s[i+1]=='1'&&s[i+2]=='1'&&(last!=i||now!=i+2)){
			for(int j=s.size()-1,j>i+2;j--)
				f=s[j]+f;
			string u=t+'110'+f;
			ans+=dfs1(u,i,i+2)%mod;
		}
	}
	return ans%mod;
}
int main()
{
	string s,l;
	cin>>n>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='?')cnt[++tot]=i;
		else qwq[tot+1]=qwq[tot+1]+s[i];
	}
	dfs(1,l);
	long long ans=0;
	for(auto t:q)
		ans=(ans+dfs1(t,0,0))%mod;
	cout<<ans;
	return 0;
}
