#include<bits/stdc++.h>
using namespace std;
struct node{int x,y;};
int n,m,k,d,now=0;
int ank[100005];
vector<node>q;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	q.push_back((node){100005,100005});
	for(int _=1;_<=m;_++){
		memset(ank,0,sizeof(ank));
		int x,y;cin>>x>>y;
		for(int i=0;i<q.size();i++){
			if(q[i].x==x){
				q[i].y+=y;
				break;
			}
			if(q[i].x>x){
				q.push_back((node){0,0});
				for(int j=q.size()-1;j>i;j--)
					q[j]=q[j-1];
				q[i]=(node){x,y};
				break;
			}
		}
		vector<node>op;bool flag=0;now=0;
		for(auto v:q)op.push_back(v);
		for(int i=op[0].x;i<=n;i++){
			if(i-op[now].x>d){
				cout<<"NO\n";
				flag=1;
				break;
			}
			if(now==op.size()-1){
				cout<<"YES\n";
				flag=1;
				break;
			}
			while(ank[i]+op[now].y<=k){
				ank[i]+=op[now].y;
				now++;
				if(now==op.size()-1){
					cout<<"YES\n";
					flag=1;
					break;
				}
			}
			if(flag==1)break;
			op[now].y-=k-ank[i];
			ank[i]=k;
		}
		if(flag==0){
			if(op.size()-1!=now)
				cout<<"NO\n";
		}
	}
	return 0;
 } 
