#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int>q;
	q.insert(0,1);
	return 0;
}
