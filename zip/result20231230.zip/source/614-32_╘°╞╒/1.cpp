#include<bits/stdc++.h>
using namespace std;
int main()
{
	cout<<system("sample1.out t4.out");
	return 0;
}
