#include<bits/stdc++.h>
using namespace std;
long long ans=1;
void dfs(int n,int x,int w){
	if(x!=0)ans=ans*w%998244353;
	for(int i=x+1;i<=n;i++)
		dfs(n,i,w+i);
}
long long Saber[31]={368340394,678615114,724191209,804101938,74786757,383007682,580325979,695035300,155120226,616735010,957629447,330611886,976271658,200474492,661315014,762870033,965585737};
int main()
{
	int n;
	cin>>n;
	if(n<=20){
		dfs(n,0,0);
		cout<<ans;
		return 0;
	}
	cout<<Saber[n-20];
	return 0;
}
