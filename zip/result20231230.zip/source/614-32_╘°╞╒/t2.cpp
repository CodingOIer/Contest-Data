#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	long long n,k;
	cin>>n>>k;
	long long cnt=0,ans=0;
	while(n+cnt>=k){
		n+=cnt;
		cnt=n%k;
		ans+=n/k;
		n/=k;
	}
	if(n+cnt==k-1)ans++;
	cout<<ans;
	return 0;
}
