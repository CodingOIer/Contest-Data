#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=100005;
string s;
int k;
int num[N];
//int dfs(int x,int p){
	//��������xλ����ʣp��ƿ�� 
//} 
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin >> s >> k;
	int n=s.length();
	s=' '+s;
	for(int i=1;i<=n;i++) num[i]=s[i]-'0';
	if(n<=19){
		int ans=0,p=0;
		for(int i=1;i<=n;i++) p=p*10+num[i];
		while(p>=k){
			ans+=p/k;
			p=p/k+p%k;
		}
		cout << ans+(p==k-1);
		return 0;
	}
	return 0;
}
