#include <bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
#define mid (l+r>>1)
using namespace std;
const int N=5e5+5;
int n,q,k,d,vis[N],tot;
struct node{
	int x,y;
}a[N],p[N];
bool cmp(node a,node b){
	return a.x==b.x?a.y<b.y:a.x<b.x;
}
signed main(){
//	freopen("sample1.in","r",stdin);
//	freopen("1.out","w",stdout);
	cin >> n >> q >> k >> d;
	for(int i=1;i<=q;i++){
		cin >> a[i].x >> a[i].y;
		bool fl=0;
		sort(a+1,a+i+1,cmp);
		tot=1;
		memset(p,0,sizeof(p));
		p[1]=a[1];
		for(int j=2;j<=i;j++){
//			cout << a[i].x << " ";
			if(a[j-1].x==a[j].x) p[tot].y+=a[j].y;
			else p[++tot]=a[j];
		}
//		printf("\n");
//		for(int j=1;j<=tot;j++){
//			cout << p[j].x << " " << p[j].y << "\n";
//		}
		fill(vis+1,vis+n+1,k);
		for(int j=1;j<=tot;j++){
			for(int t=p[j].x;t<=p[j].x+d && p[j].y>0;t++){
				vis[t]=max(0ll,vis[t]-p[j].y),p[j].y=max(0ll,p[j].y-k);
			}
//			cout << j << " " << p[j].y << "\n";
			if(p[j].y>0) fl=1;
		}
		if(fl) puts("NO");
		else puts("YES"); 
	}
	return 0; 
}
/*
0 0 0 0
2 2 2 2
4 4 4
1 3 4


tr[x]�ʹ���x��x+d��ʣ��ķ��� 
*/

