#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=200*200,mod=998244353;
//n*(n+1)/2
int vis[N],f[N],n,ans=1;
int ksm(int x,int p){
	int ans=1;
	for(;p;p>>=1){
		if(p&1) ans=(ans*x)%mod;
		x=(x*x)%mod;
	}return ans;
}
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin >> n;
//	for(int s=0;s<(1ll<<n);s++){
//		int sum=0;
//		for(int i=1;i<=n;i++){
//			if((s&(1<<(i-1)))) sum+=i;
//		}
////		cout << s << "\n";
//		vis[sum]=(vis[sum]+1)%(mod-1);
//	}
//	for(int i=1;i<=n;i++) vis[i]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i*(i-1)/2;j++) vis[j]=f[j];
		for(int j=1;j<=i*(i-1)/2;j++) f[i+j]=(f[i+j]+vis[j])%(mod-1);
		f[i]=(f[i]+1)%(mod-1);
	}
//	for(int i=1;i<=n*(n+1)/2;i++){
//		cout << i << " : " << vis[i] << "\n";
//	}

	for(int i=1;i<=n*(n+1)/2;i++) ans=ans*ksm(i,f[i])%mod;
	cout << ans;
	return 0;
}
