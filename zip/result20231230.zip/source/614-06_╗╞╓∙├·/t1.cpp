#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
struct node{
	int v,t,id;
}a[N],t[N];

int n,k,ans;
bool cmp(node a,node b){
	return a.v>b.v;
}
signed main(){
	freopen("t1.in","r",stdin); 
	freopen("t1.out","w",stdout);
	cin >> n >> k;
	for(int i=1;i<=n;i++) cin >> a[i].t;
	for(int i=1;i<=n;i++) cin >> a[i].v;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=k;i++) ans+=a[i].v;
	cout << ans << "\n";
	return 0;
}
