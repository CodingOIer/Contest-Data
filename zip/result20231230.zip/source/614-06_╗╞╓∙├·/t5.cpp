#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,ans;
string s;
map<string ,bool > mp;
void f(int x){
	if(!mp[s]){
		cout << s << "\n";
		ans++;
	}
	mp[s]=1;
	if(s[x-1]=='1' && s[x-2]=='0') s[x-2]='1',s[x]='0',f(x-1),s[x-2]='0',s[x]='1';
	if(s[x+1]=='1' && s[x+2]=='0') s[x+2]='1',s[x]='0',f(x-1),s[x+2]='0',s[x]='1';
//	mp[s]=0;
}
void dfs(int x){
	if(x>n){
		int fl=0;
		for(int i=1;i<=n;i++){
			if(s[i]=='1') fl=1,f(i);
		}
		if(!fl) ans++;
		return;
	}
	if(s[x]!='?') dfs(x+1);
	else{
		s[x]='0';
		dfs(x+1);
		s[x]='1';
		dfs(x+1);
		s[x]='?';
	}
}
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	cin >>  n >> s;
	s=' '+s;
	dfs(1);
	cout << ans << "\n";
	return 0;
}

