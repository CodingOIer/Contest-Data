#include <bits/stdc++.h>
long long n,k,ans=0,vis=0;
using namespace std;
int dg(int n,int k){
	ans=0,vis=n;
	long long x; 
	while(1){
		if(vis<=1) break;
		if(vis==k-1) vis++;
		if(x==0) break;
		x=(vis)/k;
//		cout<<x<<endl;
		ans+=x;
		vis%=k;
		vis+=x;
	}
	if(vis==k-1) ans++;
	cout<<ans<<" ";
	return 0;
}
int main(){
//	freopen("t2.in","r",stdin);
//	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
//	cin>>n>>k;
	cin>>n;
	for(int i=2;i<=n;i++){//����Ϊ1,��Ȼ���Ϊ���� 
		for(int j=2;j<=i;j++){
			cout<<i<<" "<<j<<" ";
			dg(i,j);
//			cout<<i/j<<endl;
			cout<<i/(j-1)<<endl;
//			cout<<endl;
		}
		cout<<endl;
	}
//	dg(7,2);
	return 0;
}
