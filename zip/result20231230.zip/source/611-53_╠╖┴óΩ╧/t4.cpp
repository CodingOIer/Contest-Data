#include<bits/stdc++.h>
const int N=5e5+5;
using namespace std;
int a[N];
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	int n,m,k,d;cin>>n>>m>>k>>d;
	for(int i=1;i<=n;++i) a[i]=k;
	while(m--){
		int x,y;cin>>x>>y;
		for(int i=x;i<=min(x+d,n);++i){
			if(!y) break;
			if(a[i]>y) a[i]-=y,y=0;
			else y-=a[i],a[i]=0;
		}
		if(!y) cout<<"YES\n";
		else cout<<"NO\n";
	}
	return 0;
}
