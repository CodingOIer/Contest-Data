#include<bits/stdc++.h>
using namespace std;
inline void read(__int128 &x){
	x=0;bool f=true;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=false;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	x=f?x:-x;return ;
}
inline void write(__int128 x){
	if(x<10) putchar(x+'0');
	else write(x/10),putchar(x%10+'0');
	return ;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	__int128 n,k,ans;read(n);read(k);
	--k;ans=n/k;	
	write(ans);
	return 0;
}
