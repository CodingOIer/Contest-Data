#include<bits/stdc++.h>
#define ll long long
const int N=1e5+5;
using namespace std;
struct node{
	int v,t;
}a[N];
bool cmp(node a,node b){ return a.v^b.v?a.v>b.v:a.t<b.t;}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n,k;cin>>n>>k;
	for(int i=1;i<=n;++i) cin>>a[i].t;
	for(int i=1;i<=n;++i) cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	int T=0,x=1;
	ll ans=0;
	while(k&&x<=n){
		if(a[x].t>=T) ans+=a[x].v,--k,++T;
		++x;
	}
	cout<<ans<<"\n";
	return 0;
}
