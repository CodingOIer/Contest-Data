#include<bits/stdc++.h>
using namespace std;
int a[500005];
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	int n,m,k,d,x,y;
	long long s=0;
	cin>>n>>m>>k>>d; 
	for(int i=1;i<=n;i++) a[i]=k;
	for(int i=1;i<=m;i++)
	{
		s=0;
		scanf("%d%d",&x,&y);
		for(int j=1;j<=x+d;j++)
			s+=a[j];
		if(s>y)
		{
			if(y>0)
			{
				for(int j=1;j<=x+d;j++)
				{
					if(a[j]<y) a[j]=0,y-=a[j];
					else a[j]-=y;
				}
			}
			else
				a[x]-=y;
			printf("YES\n");
		}
		else
			printf("NO\n");
	}
	return 0;
} 
