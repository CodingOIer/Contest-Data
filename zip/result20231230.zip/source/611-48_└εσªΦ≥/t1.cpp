#include<bits/stdc++.h>
using namespace std;
int t[100005],v[100005];
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n,k;
	cin>>n>>k;
	if(k==1)
	{
		int s=0;
		for(int i=1;i<=n;i++)
			scanf("%d",&t[i]);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&v[i]);
			s=max(s,v[i]);
		}
		cout<<s;
		return 0;
	}
	long long s=0;
	for(int i=1;i<=n;i++)
		scanf("%d",&t[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<i;j++)
		{
			if(v[i]>v[j])
			{
				swap(v[i],v[j]);
				swap(t[i],t[j]);
			}
			if(v[i]==v[j]&&t[i]<t[j])
			{
				swap(v[i],v[j]);
				swap(t[i],t[j]);
			}
		}	
	}
	for(int ti=1,sum=1;sum<=k;ti++,sum++)
	{
		if(t[ti]-sum>=0) 
			s+=v[ti];
		else
			sum--;
	}
	cout<<s;
	return 0;
} 
