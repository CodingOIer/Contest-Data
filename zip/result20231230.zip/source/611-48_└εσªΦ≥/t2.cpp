#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	long long n,k;
	cin>>n>>k;
	cout<<n/(k-1);
	return 0;
} 
