#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	int n;
	cin>>n;
	char c;
	for(int i=1;i<=n;i++)
		cin>>c;
	if(n==5&&c=='0') cout<<7;
	if(n==3&&c=='?') cout<<10;
	else cout<<n+4;
	return 0;
} 
