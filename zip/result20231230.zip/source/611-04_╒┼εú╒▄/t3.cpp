#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,ans=1,cs=1,l;
void dfs(ll x){
//	cout<<ans<<endl;
	if(x==n+1){
		cout<<ans*l%998244353;
		return;
	}else{
		ans=ans*x%998244353;
		for(int i=1;i<x;i++){
			ans=ans*(i+x)%998244353;
//			cout<<i<<' '<<x<<' '<<i+x<<' '<<ans<<endl;
		}
		if(x>=3){
			for(int i=3+x;i<=x-1+x-2;i++){
				ans=ans*(i+x)%998244353;
//				cout<<i<<' '<<x<<' '<<i+x<<' '<<ans<<endl;
			}
		}
		return dfs(x+1);
	}
}
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)l+=i; 
	if(n<=3){
		for(int i=0;i<l;i++){
			for(int j=cs;j<=n;j++){
				ans=ans*(j+i)%998244353;
//				cout<<j<<" "<<i+j<<' '<<ans<<endl;
			}
			cs++;
		}
		cout<<ans*l%998244353;
	}else{
		dfs(1);
	}
	return 0;
}

