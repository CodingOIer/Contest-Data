#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll ans=1,n;
char a[100086];
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i]=='?'){
			ans*=2;
			a[i]=1;
			for(int i=1;i<=n;i++){
				if(a[i]==1&&a[i+2]==0){
					ans++;
				}if(a[i]==1&&a[i-2]==0){
					ans++;
				}
			}
			a[i]=0;
			for(int i=1;i<=n;i++){
				if(a[i]==1&&a[i+2]==0){
					ans++;
				}if(a[i]==1&&a[i-2]==0){
					ans++;
				}
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(a[i]==1&&a[i+2]==0){
			ans++;
		}if(a[i]==1&&a[i-2]==0){
			ans++;
		}
	}
	cout<<ans;
	return 0;
}

