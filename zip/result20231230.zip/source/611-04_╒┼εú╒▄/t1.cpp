#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,t,n[100086],m[100086],ans,ma;
int main(){
//	freopen("t1.in","r",stdin);
//	freopen("t1.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++){cin>>n[i];} 
	for(int i=1;i<=n;i++){cin>>m[i];} 
	
	return 0;
}

