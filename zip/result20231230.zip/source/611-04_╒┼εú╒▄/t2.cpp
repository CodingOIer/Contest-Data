#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k,ans; 
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>m;
	ans+=n/m;
	k+=n/m+n%m;
	for(int i=1;;i++){
		if(k>=m){
			ans+=k/m;
			k=k%m+k/m;
		}else if(k==m-1){
			ans++;
			cout<<ans;
			return 0;
		}else{
			cout<<ans;
			return 0;
		}
	}
	return 0;
}
