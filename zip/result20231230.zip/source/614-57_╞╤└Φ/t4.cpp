#include<bits/stdc++.h>
using namespace std;
long long n,m,k,d,x[5010],y[5010],v[5010],sum;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
	for(int i = 1;i <= n;i++)
	{
		scanf("%lld%lld",&x[i],&y[i]);
		if(y[i] > 0)
		{
			sum = 0;
			for(int j = x[i];j <= min(x[i] + d,n);j++) sum += v[j];
			if(((min(x[i] + d,n) - x[i])) * k - sum < y[i]) printf("NO\n");
			else 
			{
				printf("YES\n");
				for(int j = x[i];j <= min(x[i] + d,n);j++)
				{
					if(y[i] <= k - v[j])
					{
						v[j] += y[i];
						y[i] = 0;
						break;
					}
					else y[i] = y[i] - k + v[j],v[i] = k;
				}
			}
		}
		else
		{
			printf("YES\n");
			for(int j = x[i];j <= x[i] + d;j++)
				{
					if(v[i] > -y[i])
					{
						v[j] += y[i];
						break;
					}
					else y[i] = y[i] + v[i],v[i] = 0;
				}
		}
	}
	return 0;
}

