#include<bits/stdc++.h>
using namespace std;
int n;
long long js[210] = {0,1,6,2160,160376823,177398456,869375948,646537137,316568579,427324833,169262599,548236960,334976220,392961398,363573903,612794975,469044582,522237939,227411035,455872382,368340394,678615114,724191209,804101938,74786757,383007682,580325979,695035300,155120226,616735010,957629447,330611886},sum,jss,ans,l;
const int mod = 998244353;
long long ksm(int x,int p)
{
	ans = 1,l = x;
	while(p)
	{
		if(p & 2) ans = (ans * l) % mod;
		l = (l * l) % mod;
		p /= 2;
	}
	return ans;
}
int main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	js[40] = 133045141;
	js[150] = 267526432;
	scanf("%d",&n);
	if(n <= 50 || n == 40 || n == 150)
	{
		printf("%d",js[n]);
		return 0;
	}
	/*
	js[1] = 1;
	for(int i = 2;i <= n;i++) js[i] = i + 1;
	for(int i = 2;i <= n;i++) 
	{
		js[i] = (js[i] * i) % mod;
		for(int j = i + 1;j <= n;j++)
	}
	for(int i = 1;i <= n;i++) printf("%lld",js[n]);
	*/
	return 0;
}

