#include<bits/stdc++.h>
using namespace std;
int n,k;
long long ans;
struct w
{
	int t,a;
}b[100010];
bool cmp(w x,w y)
{
	return x.a > y.a;
}
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 1;i <= n;i++) scanf("%d",&b[i].t);//t���ظ� 
	for(int i = 1;i <= n;i++) scanf("%d",&b[i].a);
	sort(b + 1,b + 1 + n,cmp);
	for(int i = 1;i <= k;i++) ans += b[i].a;//թƭ�� 
	printf("%lld",ans);
	return 0;
}

