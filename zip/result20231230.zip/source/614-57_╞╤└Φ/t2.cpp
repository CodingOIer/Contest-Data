#include<bits/stdc++.h>
using namespace std;
int k,p,z[100010],l,o;
string n;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin >> n;scanf("%d",&k); k--;
	for(int i = 0;i < n.size();i++)
	{
		l = l * 10 + n[i] - '0';
		if(l >= k) z[i] = l / k,l = l % k;
	} 
	while(z[o] == 0 && o <= n.size()) o++;
	for(int i = o;i < n.size();i++) printf("%d",z[i]);
	return 0;
}

