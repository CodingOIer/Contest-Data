#include<bits/stdc++.h>
using namespace std;
int n,v[100],ans;
string s;
void dfs(int x,int y)
{
	ans++;
	if(x > n)
	{
		return;
	}
	for(int i = 0;i < n;i++)
	{
		if(s[i] == '1' && i > 0 && s[i - 1] == '1' && v[i] != 2) v[i - 1] = 1,dfs(x + 1,y),v[i - 1] = 0;
		if(s[i] == '1' && i < n - 1 && s[i + 1] == '1' && v[i] != 1) v[i + 1] = 2,dfs(x + 1,y),v[i + 1] = 0;
	}
}
int main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin >> n >> s;
	dfs(1,0);
	cout<<ans;
	return 0;
}

