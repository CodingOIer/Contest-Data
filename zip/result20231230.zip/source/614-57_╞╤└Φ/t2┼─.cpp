#include<bits/stdc++.h>
using namespace std;
long long n,k,p,z[100010],l,o;
int main()
{
	scanf("%lld",&n);scanf("%lld",&k);
	printf("%lld",n / (k - 1));
	return 0;
}

