#include<bits/stdc++.h>
using namespace std;
struct kkk{
	int t,val;
}t[500001*4];
int a[500001];
void push_down(int p) {
	if(t[p].t==0) return;
	t[p*2].val+=t[p].t;
	t[p*2+1].val+=t[p].t;
	t[p*2].t+=t[p].t;
	t[p*2+1].t+=t[p].t;
	t[p].t=0;
}
void build(int l,int r,int p) {
	if(l==r){
		t[p].val=a[l];
		return;
	}
	int mid=(l+r)/2;
	build(l,mid,p*2);
	build(mid+1,r,p*2+1);
	t[p].val=min(t[p*2].val,t[p*2+1].val);
}
void change(int l,int r,int s,int qt,int p,int k) {
	if(l>=s&&r<=qt) {
		t[p].val+=k,t[p].t+=k;
		return;
	}
	int mid=(l+r)/2;
	push_down(p);
	if(s<=mid)	change(l,mid,s,qt,p*2,k);
	if(qt>mid)	change(mid+1,r,s,qt,p*2+1,k);
	t[p].val=min(t[p*2].val,t[p*2+1].val);
	return;
}
int ask(int l,int r,int s,int qt,int p) {
	if(l>=s&&r<=qt)	return t[p].val;
	int mid=(l+r)/2,ans=INT_MAX;
	push_down(p);
	if(s<=mid)	ans=ask(l,mid,s,qt,p*2);
	if(qt>mid)	ans=min(ans,ask(mid+1,r,s,qt,p*2+1));
	return ans;
}
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	int n,m,k,d;
	cin>>n>>m>>k>>d;
	if(k==1){
		for(int i=1;i<=n;i++){
			a[i]=k;
		}
		build(1,n,1);
		for(int i=1;i<=m;i++){
			int x,y;
			cin>>x>>y;
			if(y>d){
				cout<<"NO"<<endl;
				continue;
			}
			change(1,n,x,x+d,1,-1);
			if(ask(1,n,x,x+d,1)<0){
				cout<<"NO"<<endl;
			}
			else{
				cout<<"YES"<<endl;
			}
		}
	}
	else{
		for(int i=1;i<=n;i++){
			a[i]=k;
		}
		build(1,n,1);
		for(int i=1;i<=m;i++){
			int x,y;
			cin>>x>>y;
			for(int j=x;j<=x+d;j++){
				int xx=ask(1,n,j,j,1);
				change(1,n,j,j,1,-min(ask(1,n,j,j,1),y));
				y-=xx,y;
				if(y<=0){
					break;
				}
			}
			change(1,n,x+d,x+d,1,-max(y,0));
			if(y<=0){
				cout<<"YES"<<endl;
			}
			else{
				cout<<"NO"<<endl;
			}
//			change(1,n,x+d,x+d,1,-y);
		}
	}
	return 0;
}

