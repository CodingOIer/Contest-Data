#include<bits/stdc++.h>
using namespace std;
struct kkk{
	int x,val;
}a[100001];
bool cmp(kkk a,kkk b){
	if(a.val==b.val) return a.x<b.x;
	return a.val>b.val;
}
int ton[100001];
long long ans;
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].x;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i].val;
	}
	sort(a+1,a+1+n,cmp);
	int j=0;
	for(int i=1;i<=n;i++){
		if(j==k){
			break;
		}
		if(ton[a[i].x]==0){
			ton[a[i].x]++;
			ans+=a[i].val;
			j++;
		}
	}
	cout<<ans;
	return 0;
} 
