#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
long long ans=1,cnt[201],ton[20101];
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cnt[i]=i+cnt[i-1];
	}
	ton[1]=1;
	for(int i=2;i<=n;i++){
		for(int j=cnt[i];j>=1;j--){
			if(ton[j]>0){
				ton[j+i]+=ton[j];
//				cout<<j<<endl;
			}
		}
		ton[i]++;
	}
	for(int i=1;i<=cnt[n];i++){
		for(int j=1;j<=ton[i];j++){
			ans=ans*i%mod;
		}
//		cout<<i<<" "<<ton[i]<<endl;
	}
	cout<<ans;
	return 0;
}
