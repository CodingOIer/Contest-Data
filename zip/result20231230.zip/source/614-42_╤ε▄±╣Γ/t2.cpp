#include<bits/stdc++.h>
using namespace std;
unsigned long long carry;
unsigned long long n,k,tot;
string s;
int ans1[1000001],a[1000001];
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s>>k;
	for(int i=0;i<s.size();i++){
		a[i]=s[i]-'0';
	}
	for(int i=0;i<s.size();i++){
		carry=(carry*10)+a[i];
		if(carry>=k-1){
			ans1[++tot]=carry/(k-1);
			carry=carry%(k-1);
		}
		else{
			ans1[++tot]=0;
		}
	}
	int x=0;
	while(ans1[x]==0){
		x++;
	}
	for(int i=x;i<=tot;i++){
		cout<<ans1[i];
	}
	return 0;
}
//4
