#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
	ios::sync_with_stdio(0);
	long long b=0;
	for(int i=1;i<=63;i++)b*=2,b+=1;
	cout<<b;
}

