#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll k;
class big_int{
	
	public:
		vector<int> s;
		big_int(vector<int>& I_AK_IOI){
			while(I_AK_IOI.size()){
				s.push_back(I_AK_IOI.back());
				I_AK_IOI.pop_back();
			}
			ok_up();
		}big_int(){
			
		}
		void ok_down(){
			for(int i=s.size()-1;i>=0;i--){
				if(s[i]==0)s.pop_back();
				else return;
			}
		}
		void ok_up(){
			if(s.size()==0)s.push_back(0);
			for(int i=0;i<s.size()-1;i++){
				if(s[i]>=10){
					s[i+1]+=(s[i]/10);
					s[i]%=10;
				}
			}
			while(s.back()>=10){
				s.push_back(s.back()/10);
				s[s.size()-2]%=10;
			}
		}
		big_int operator/(ll a){
			ll cnt=0;
			vector<int> s2;
			for(int i=s.size()-1;i>=0;i--){
				cnt*=10;
				cnt+=s[i];
				s2.push_back(0);
				if(cnt>=a){
					s2.back()=(cnt/a);
					cnt%=a;
				}
			}
			return big_int(s2);
		}
		void print(){
			ok_down();
			for(int i=s.size()-1;i>=0;i--){
				cout<<s[i];
			}
		}
		void inpuct(){
			s.clear();
			string b;
			cin>>b;
			for(int i=b.size()-1;i>=0;i--){
				s.push_back(b[i]-'0');
			}
		}
};
big_int n;
int main(){
	ios::sync_with_stdio(0);
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	n.inpuct();
	cin>>k;
	(n/(k-1)).print();
}

