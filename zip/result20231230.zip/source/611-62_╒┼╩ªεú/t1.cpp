#include<bits/stdc++.h>
#define ll long long
using namespace std;
long long s[1000005];
int main(){
	ios::sync_with_stdio(0);
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ll n,k,ans=0,sb;
	cin>>n>>k;
	for(int i=0;i<n;i++)cin>>sb;
	for(int i=0;i<n;i++)cin>>s[i];
	sort(s,s+n);
	for(int i=n-1;i>=n-k;i--)ans+=s[i];
	cout<<ans;
}

