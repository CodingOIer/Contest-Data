#include<bits/stdc++.h>
#define ll long long
using namespace std;
long long mod=998244353ll;
long long anss[300];
vector<int> sets;
//f(n)=f(n-1)*n*merge{{s...},n}
int main(int b){
	ios::sync_with_stdio(0);
	freopen("bio.���","w",stdout);
	sets.push_back(1);
	anss[1]=1;cout<<1;
	for(int i=2;i<=200;i++){
		anss[i]=anss[i-1];
		ll k=sets.size();
		for(int j=0;j<k;j++){
			sets.push_back(sets[j]+i);
			sets.back()%=mod;
			anss[i]*=sets.back();
			anss[i]%=mod;
			//anss[i+j]+=anss[i];
			/*
			sets[j]+=i;
			sets[j]%=mod;
			anss[i]*=sets[j];
			anss[i]%=mod;*/
		}
		sets.push_back(i);
		anss[i]*=i;
		anss[i]%=mod;//fib(n)
		cout<<','<<anss[i];
		//for(int j=0;j<sets.size();j++)cout<<sets[j]<<',';
		cout<<flush;
	}// x=a+b+c     a*(x*c+x*n)*b+n*(x*c+x*n)*b+(x*c+x*n)*n*a+(x*c+x*n)*n*n
}

