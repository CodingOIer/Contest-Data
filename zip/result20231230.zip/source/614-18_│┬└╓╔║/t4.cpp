#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=5e5+5;
ll n,m,k,d;
struct sss {
	int x,y,d;
}q[N];
ll e[N],h[N],te[N];
int main() {
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=n;i++) {
		cin>>q[i].x>>q[i].y;
		if(n<=2000&&k>1) {
			e[q[i].x]+=q[i].y;
			memset(h,0,sizeof(h));
			int F=0;
			for(int j=1;j<=n;j++) {
				if(e[j]) {
					int sum=e[j];
					for(int p=j;p<=n;p++) {
						if(k-h[p]>=sum) {
							h[p]+=sum;
							sum=0;
							break;
						} else {
							sum-=(k-h[p]);
							h[p]=k;
						}
					}
					if(sum) {
						cout<<"NO\n";
						F=1;
						break;
					}
				}
				if(F) break;
			}
			if(F) continue ;
			cout<<"YES\n";
		}
	}
	if(n<=2000&&k>1) return 0;
	if(k==1) {
		int f=0;
		for(int i=1;i<=m;i++) {
			e[q[i].x]+=q[i].y;
			if(e[q[i].x]>d) {
				cout<<"NO\n";
				f=1;
				continue ;
			}
			if(f&&q[i].y>0) {
				cout<<"NO\n";
				continue ;
			}
			if(!f&&q[i].y<0) {
				cout<<"YES\n";
				continue ;
			}
			f=0;
			int last=0;
			for(int i=1;i<=n;i++) {
				if(e[i]) {
					last=max(i+e[i]-1,last+e[i]);
					if(last>i+d-1||last>n) {
						f=1;
						cout<<"NO\n";
					}
				}
			}
			if(f) continue ;
			cout<<"YES\n";
		}
	}
	return 0;
}

