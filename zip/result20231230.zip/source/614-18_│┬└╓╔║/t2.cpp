#include<bits/stdc++.h>
#define ll long long
using namespace std;
string tn,n,ans,o;
ll k;
string chu_fa(string x,ll y) {
	string ret,res;
	ll p=0;
	for(int i=x.size()-1;i>=0;i--) {
		p=p*10+(x[i]-'0');
		if(p>=y) {
			ret+=(p/y+'0');
			p%=y;
		} else {
			if(ret.size())
				ret+='0';
		}
	}
	for(int i=ret.size()-1;i>=0;i--)
		res+=ret[i];
	return res;
}
string jia_fa(string x,string y) {
	string ret;
	ll l=max(x.size(),y.size());
	for(int i=0;i<l;i++) {
		ret+=((char)0);
		if(i<x.size()) ret[i]+=(x[i]-'0');
		if(i<y.size()) ret[i]+=(y[i]-'0');
	}
	for(int i=0;i<ret.size();i++) {
		if(ret[i]>9) {
			if(i<ret.size()-1) {
				ret[i+1]+=ret[i]/10;
			} else {
				ret+=(ret[i]/10);
			}
			ret[i]=ret[i]%10;
		}
		ret[i]+='0';
	}
	return ret;
}
int main() {
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>tn>>k;
	for(int i=tn.size()-1;i>=0;i--)
		n+=tn[i];
	ans=chu_fa(n,k-1);
	for(int i=ans.size()-1;i>=0;i--)
		cout<<ans[i];
	return 0;
}
/*
д�˰���߾��ȼӷ�������ò���
������ 
*/ 
