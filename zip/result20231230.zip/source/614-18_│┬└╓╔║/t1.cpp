#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int n,k;
priority_queue<int> q;
ll ans;
struct sss {
	ll t,v;
} e[N];
int cmp(sss x,sss y) {
	return x.t>=y.t;
}
int main() {
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) {
		cin>>e[i].t;
	}
	for(int i=1;i<=n;i++) {
		cin>>e[i].v;
	}
	sort(e+1,e+n+1,cmp);
	int topp=0;
	for(int i=k;i>=1;i--) {
		while(topp<n&&e[topp+1].v>=i) {
			q.push(e[++topp].v);
		}
		ans+=q.top();
		q.pop();
	}
	cout<<ans;
	return 0;
} 

