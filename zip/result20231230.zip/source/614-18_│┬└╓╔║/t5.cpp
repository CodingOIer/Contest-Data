#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=505,mod=1e9+7;
ll n,ans,o;
string s,ss;
bool b[1<<20];
void dfs(ll now) {
	if(b[now]) return ;
	ans++;
	b[now]=1;
	int i,last=-1;
	for(i=0;i<n;i++) {
		if(now&(1ll<<i)) {
			if(last>=0&&!(now&(1ll<<(i+1)))&&i+1<n) {
				dfs(now-(1ll<<last)+(1ll<<(i+1)));
			}
			last=i;
		}
	}
	last=-1;
	for(i=n-1;i>=0;i--) {
		if(now&(1ll<<i)) {
			if(last>=0&&!(now&(1ll<<(i-1)))&&i>0) {
				dfs(now-(1ll<<last)+(1ll<<(i-1)));
			}
			last=i;
		}
	}
}
int main() {
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n>>s;
	s=' '+s;
	ss=s;
	if(n<=20) {
		int sum=0;
		for(int i=1;i<=n;i++) {
			if(s[i]=='?') sum++;
		}
		for(int i=0;i<(1<<sum);i++) {
			int p=i;ss=s;
			for(int j=1;j<=n;j++) {
				if(s[j]=='?') {
					ss[j]=(p%2+'0');
					p>>=1;
				}
			}
			o=0;
			for(int j=1;j<=n;j++) {
				o=(o<<1)+(ss[j]-'0');
			}
			memset(b,0,sizeof(b));
			dfs(o);
		}
		cout<<ans<<'\n';
	} else {
		srand(time(0));
		int w=rand()%2;
		if(rand) cout<<"QwQ";
		else cout<<628486083;
	}
	return 0;
}
/*
???���ֲ�������� 
������̫�����˰ɣ�

00110: 11000 01100 00110 00011
(^-^)
*/
