#include <bits/stdc++.h>
using namespace std;
using ll = long long;
char n[100001];
ll k;
int main() {
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	cin >> n >> k;
	k = k - 1;
	bool p = 0;
	ll tmp = 0, cnt;
	for (unsigned int i = 0; i < strlen(n); i++) {
		tmp = tmp * 10 + n[i] - '0';
		if (tmp >= k) {
			if (p == 0) {
				cnt = i;
				p = 1;
			}
			n[i] = tmp / k + '0';
			tmp %= k;
		} else {
			n[i] = '0';
		}
	}
	for (unsigned int i = cnt; i < strlen(n); i++) {
		cout << n[i];
	}
}
/*
  ac于8:47
 */
