#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int main() {
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);//爆零快乐
	return 0;
}
/*
  放弃于11:00
 */
