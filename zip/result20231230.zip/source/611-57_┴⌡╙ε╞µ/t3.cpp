#include <bits/stdc++.h>
using namespace std;
using ll = long long;
ll n;
const ll p = 998244353;
ll f[10000001];
ll qpow(ll a,ll b) {
	if(b==0)
		return 1;
	if(b==1)
		return a;
	ll tmp=qpow(a,b/2)%p;
	return tmp%p*tmp%p*(b%2==0?1:a)%p;
}
int main() {
	freopen("t3.in", "r", stdin);
	freopen("t3.out", "w", stdout);
	cin >> n;
	f[0]=1;
	for(int i=1;i<=n;i++) {
		for(int j=n*(n+1)/2;j>=0;j--) {
			f[i+j]+=f[j];
			f[i+j]%=(p-1);
		}
	}
	long long ans=1;
	for(int i=1;i<=n*(n+1)/2;i++) {
		ans=(long long)(qpow(i,f[i]))*ans%p;
		ans%=p;
	}
	cout<<ans;
}
/*
  ac与9:22
 */
