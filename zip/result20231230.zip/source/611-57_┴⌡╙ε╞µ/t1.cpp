#include <bits/stdc++.h>
using namespace std;
using ll = long long;
ll n, k;
struct coin {
	ll end;
	ll w;
};
coin t[100001];
bool cmp(coin& a, coin& b) {
	return a.w > b.w;
}
int main() {
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i <= n; i++)
		cin >> t[i].end;
	for (int i = 1; i <= n; i++)
		cin >> t[i].w;
	sort(t + 1, t + n + 1, cmp);
	long long ans = 0;
	for (int i = 1; i <= k; i++)
		ans += t[i].w;
	cout << ans;
}
/*
  ac与8:19
 */
