//�����ҵķ�����̰��Ӧ��û���⣨���˵���û˵ 
#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
int n,k,ans,a[N],w[N];
bool cmp(int x,int y)
{
	return x>y;
}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
		cin>>w[i];
	sort(w+1,w+n+1,cmp);
	for(int i=1;i<=k;i++)
		ans+=w[i];
	cout<<ans;
	return 0;
}
