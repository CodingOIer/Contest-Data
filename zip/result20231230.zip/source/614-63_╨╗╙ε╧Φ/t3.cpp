//���10����Ÿ��߾����úú���ô���ǰ�
#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,w=1,sum[205],ans[30000],tmp[30000];
int ksm(int x,int k)
{
	int res=1;
	while(k)
	{
		if(k&1) res=(res*x)%mod;
		x=(x*x)%mod;
		k/=2;
	}
	return res;
}
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++)
		sum[i]=sum[i-1]+i;
	for(int i=1;i<=n;i++)
	{
		ans[i]+=1;
		for(int j=1;j<=sum[i-1];j++)
			ans[i+j]+=tmp[j];
		for(int j=1;j<=sum[i];j++)
			tmp[j]=ans[j];
	}
	for(int i=1;i<=sum[n];i++)
		w=(w*ksm(i,ans[i]))%mod;
	cout<<w;
	return 0;
}
