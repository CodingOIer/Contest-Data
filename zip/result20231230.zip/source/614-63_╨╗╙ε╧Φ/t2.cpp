//ʲô���ĸ߾����;� 
#include <bits/stdc++.h>
#define int long long
using namespace std;
int s,k;
bool flag=0;
string n,ans;
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	k--;
	int l=n.length();
	for(int i=0;i<l;i++)
	{
		s=s*10+n[i]-'0';
		if(s>=k)
		{
			ans.push_back(s/k+'0');
			flag=1;
			s-=s/k*k;
		}
		else if(flag) ans.push_back('0');
	}
	l=ans.length();
	for(int i=0;i<l;i++)
		cout<<ans[i];
	return 0;
}
