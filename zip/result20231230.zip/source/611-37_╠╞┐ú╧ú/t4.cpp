#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,d,x,y,a[114514];
signed main() {
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k>>d;
	while(m--){
		bool f=1;
		cin>>x>>y;
		if(y<=0){
			a[x]+=y;
			cout<<"YES\n";
			continue;
		}
		for(int i=1;i+d<=n;i++){
			int cnt=0;
			for(int j=i;j<=i+d;j++) cnt+=a[j];
			if(i==x) cnt+=y;
			if(cnt>k*d+k){
				f=0;cout<<"NO\n";
				break;
			}
		}
		if(f){
			int id=x,kk=y;
			while(kk>=k){
				kk-=k-a[id];
				a[id]=k;
				++id;
			}
			a[id]=kk;
			cout<<"YES\n";
		}
	}
	return 0;
}
