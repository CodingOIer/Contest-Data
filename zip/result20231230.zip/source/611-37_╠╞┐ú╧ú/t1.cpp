#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,last,ans;
struct gold{
	int t,v;
}a[114514];
bool cmp(gold x,gold y){
	return x.v<y.v;
}
signed main() {
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>a[i].t;
	for(int i=1;i<=n;i++) cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	for(int i=n;i>=1;i--){
		if(!k) break;
		if(last!=a[i].t) ans+=a[i].v,--k;
		last=a[i].t;
	}
	cout<<ans;
	return 0;
}
