#include<bits/stdc++.h>
#define int long long
//��ʹɽ��һ�� 
using namespace std;
const int N=1e9;
string s,b,ans,f;
int k;
int int_(string x){
	int num=0,k=1;
	for(int i=x.length()-1;i>=0;i--){
		num+=(x[i]-'0')*k;
		k*=10;
	}
	return num;
}
signed main() {
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s>>k;
	--k;
	for(int i=0,len=s.length();i<len;){
		f="";int j=0;
		while(int_(b)<k&&i<len) ++j,b+=s[i++];
		for(int i=1;i<j;i++) f+='0';
		int m=int_(b),n=m/k;
		ans+=f;
		if(!n) ans+='0';
		while(n){
			ans+=char(n%10+'0');
			n/=10;
		}
		b="";
		if(m%k){
			n=m%k;
			if(!n) b+='0';
			while(n){
				b+=char(n%10+'0');
				n/=10;
			}
		}
		reverse(b.begin(),b.end());
	}
	bool fl=0;
	for(int i=0,len=ans.length();i<len;i++){
		if(!fl&&ans[i]!='0') fl=1;
		if(fl) cout<<ans[i];
	}
	if(!fl) cout<<0;
	return 0;
}
//2 3
