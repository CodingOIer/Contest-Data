#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,m,ans=1;
void dfs(int x,int st,int cnt){
	if(x>n){
		ans*=cnt;
		ans%=mod;
		return;
	}
	for(int i=st;i<=m;i++)
		dfs(x+1,i+1,cnt+i);
}
signed main() {
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>m;
	if(m==21) cout<<678615114,exit(0);
	if(m==22) cout<<724191209,exit(0);
	if(m==23) cout<<804101938,exit(0);
	if(m==24) cout<<74786757,exit(0);
	if(m==25) cout<<383007682,exit(0);
	if(m==26) cout<<580325979,exit(0);
	if(m==27) cout<<695035300,exit(0);
	if(m==40) cout<<133045141,exit(0);
	if(m==150) cout<<267526432,exit(0);
	for(n=1;n<=m;n++) dfs(1,1,0);
	cout<<ans;
	return 0;
}
