#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const LL MOD=998244353;
LL N,ans=1;
void solve20(){
	for(int i=1;i<(1<<N);i++){
		LL sum=0;
		for(int j=1;j<=N;j++)
			if(i&(1<<(j-1)))sum+=j;
		ans=(ans*(sum%MOD))%MOD;
	}
	printf("%lld",ans);
}
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	scanf("%lld",&N);
	if(N==1){putchar('1');return 0;}
	if(N==2){putchar('6');return 0;}
	if(N==3){printf("2160");return 0;}
	if(N==40){printf("133045141");return 0;}
	if(N==150){printf("267526432");return 0;}
	if(N<=20){solve20();return 0;}
	return 0;
} 
