#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL N,K,ans;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%lld%lld",&N,&K);
	while(N>=K)ans+=N/K,N=(N%K)+N/K;
	if(N==K-1)ans++;printf("%lld",ans);
	return 0;
} 
