#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL N,K,val[200005],ans;
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%lld%lld",&N,&K);
	for(int i=1,t;i<=N;i++)scanf("%d",&t);
	for(int i=1;i<=N;i++)scanf("%lld",&val[i]);
	sort(val+1,val+N+1);
	for(int i=N;i>=N-K+1;i--)ans+=val[i];printf("%lld",ans);
	return 0;
} 
