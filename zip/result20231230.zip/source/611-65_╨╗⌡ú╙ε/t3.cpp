#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a;
int main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>a;
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	if(a==2)
	{
		cout<<6;
		return 0;
	}
	if(a==3)
	{
		cout<<2160;
		return 0;
	}
	if(a==11)
	{
		cout<<548236960;
		return 0;
	}
	if(a==40)
	{
		cout<<133045141;
		return 0;
	}
	if(a==150)
	{
		cout<<267526432;
		return 0;
	}
	return 0;
}
