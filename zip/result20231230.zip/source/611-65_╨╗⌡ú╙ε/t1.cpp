#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,sum;
struct node{
	ll ti,vi;
}c[100001];
bool cmp(node x,node y)
{
	return x.vi>y.vi;
}
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=a;i++)
	{
		cin>>c[i].ti;
	}
	for(int i=1;i<=a;i++)
	{
		cin>>c[i].vi;
	}
	sort(1+c,1+c+a,cmp);
	for(int i=1;i<=b;i++)
	{
		sum+=c[i].vi;
	}
	cout<<sum;
	return 0;
}
