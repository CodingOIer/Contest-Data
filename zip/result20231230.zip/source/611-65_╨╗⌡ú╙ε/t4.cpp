#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k,d,x,y,sum;
bool bj[500001];
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		if(y<0)
		{
			cout<<"YES";
			for(int i=x;i<=x+d;i++)
			{
				bj[i]=0;
			}
		}
		else
		{
			for(int i=x;i<=x+d;i++)
			{
				if(!bj[i])
				{
					sum++;
				}
			}
			if(y>sum)
			{
				cout<<"NO";
			}
			else
			{
				cout<<"YES";
				for(int i=x;i<=y;i++)
				{
					if(!bj[i])
					{
						bj[i]=1;
					}
				}
			}
			sum=0;
		}
	}
	return 0;
}
