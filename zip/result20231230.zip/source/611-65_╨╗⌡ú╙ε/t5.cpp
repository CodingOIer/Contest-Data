#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,w[501],tot=0,ans,head[501],tot2;
string s;
bool bj[501];
inline void dfs(ll fa)
{
	ans=(ans+1)%1000000007;
	for(int i=1;i<=tot2;i++)
	{
		ll f=head[i];
		if(f-2>=1&&f-2!=fa)
		{
			if(bj[f-1]&&(!bj[f-2]))
			{
				bj[f]=0,bj[f-2]=1,head[i]-=2;
				dfs(f);
				head[i]+=2,bj[f]=1,bj[f-2]=0;
			}
		}
		if(f+2<=a&&f+2!=fa)
		{
			if(bj[f+1]&&(!bj[f+2]))
			{
				bj[f]=0,bj[f+2]=1,head[i]+=2;
				dfs(f);
				head[i]-=2,bj[f]=1,bj[f+2]=0;
			}
		}
	}
	return;
}
inline void why(ll n)
{
	bj[w[n]]=0;
	if(n==1)
	{
		dfs(-114514);
	}
	else
	{
		why(n-1);
	}
	bj[w[n]]=1,head[++tot2]=w[n];
	if(n==1)
	{
		dfs(-114514);
	}
	else
	{
		why(n-1);
	}
	--tot2;
	return;
}
int main()
{

	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>a;
	cin>>s;
	for(int i=0;i<=a-1;i++)
	{
		if(s[i]=='1')
		{
			bj[i+1]=1,head[++tot2]=i+1;
		}
		if(s[i]=='?')
		{
			b++,w[++tot]=i+1;
		}
	}
	why(b);
	cout<<ans;
	return 0;
}
