#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,ans;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>a>>b;
	while(1)
	{
		if(a<b)
		{
			if(a+1<b)
			{
				cout<<ans;
				return 0;
			}
			else
			{
				cout<<ans+1;
				return 0;
			}
		}
		ans=ans+(a/b);
		a=(a%b)+(a/b);
	}
	return 0;
}
