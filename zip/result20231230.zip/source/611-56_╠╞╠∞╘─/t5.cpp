#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n>>s;
	if (n==1 && s=="?")
		cout<<2;
	else if (n==1 && s=="0")
		cout<<1;
	else if (n==1 && s=="1")
		cout<<1;
	else
		cout<<pow(2,n);
	return 0;
}

