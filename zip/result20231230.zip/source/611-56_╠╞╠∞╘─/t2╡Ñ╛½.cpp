#include<bits/stdc++.h>
using namespace std;
long long n,k,ans=0;
int main()
{
//	freopen("a.in","r",stdin);
//	freopen("a.out","w",stdout);
	cin>>n>>k; 
	while (n>=k)
	{
		long long p=n/k;
		ans+=p;
		n=n%k;
		n+=p;
	}
	if (n==k-1)
		ans++;
	cout<<ans;
	return 0;
}

