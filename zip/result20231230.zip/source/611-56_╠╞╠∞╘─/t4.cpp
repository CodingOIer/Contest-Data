#include<bits/stdc++.h>
using namespace std;
int n,m,k,d,flag=0;
int a[1005][1005];
int b[100005];
int q[100005];
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	while (m--)
	{
		int x,y;
		cin>>x>>y;
		if (y>=0)
		{
			q[x]+=y;
			if (flag==1)
			{
				cout<<"NO\n";
				continue;
			}
			int xx=x,yy=0;
			for (int i=1;i<=y;)
			{
				yy++;
				if (yy==k+1)
				{
					yy=1;
					xx++;
				}
				if (a[xx][yy]==0)
				{
					a[xx][yy]=1;
					i++;
				}
			}
			if (xx>n || xx>x+d)
			{
				flag=1;
				cout<<"NO\n";
			}
			else
			{
				flag=0;
				cout<<"YES\n";
			}
		}
		else
		{
			int f=0;
			q[x]+=y;
			for (int i=1;i<=n;i++)
			{
				int xx=i,yy=0;
				for (int j=1;j<=q[i];)
				{
					yy++;
					if (yy==k+1)
					{
						yy=1;
						xx++;
					}
					if (a[xx][yy]==0)
					{
						a[xx][yy]=1;
						j++;
					}
				}
				if (xx>n || xx>x+d)
				{
					f=1;
					break;
				}
			}
			if (f==0)
			{
				flag=0;
				cout<<"NO\n";
			}
			else
			{
				flag=1;
				cout<<"YES\n";
			}
		}
	}
	return 0;
}

