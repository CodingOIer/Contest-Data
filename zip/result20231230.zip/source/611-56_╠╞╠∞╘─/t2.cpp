#include<bits/stdc++.h>
using namespace std;
string s;
int n[100005],lenn;
int p[100005],lenp;
long long k;
int ans[100005],lena;
int b[100005],lenb;
int c[100005],lenc;
void jia1()//ans+=p;
{
	lenc=0;
	memset(c,0,sizeof(c));
	lenc=max(lena,lenp);
	for (int i=1;i<=lenc;i++)
	{
		c[i]+=ans[i]+p[i];
		if (c[i]>=10)
		{
			c[i+1]++;
			c[i]%=10;
		}
	}
	while (c[lenc+1]>0)
		lenc++;
	lena=lenc;
	memset(ans,0,sizeof(ans));
	for (int i=1;i<=lenc;i++)
		ans[i]=c[i];
}
void jia2()//n+=p;
{
	lenc=0;
	memset(c,0,sizeof(c));
	lenc=max(lenn,lenp);
	for (int i=1;i<=lenc;i++)
	{
		c[i]+=n[i]+p[i];
		if (c[i]>=10)
		{
			c[i+1]++;
			c[i]%=10;
		}
	}
	while (c[lenc+1]>0)
		lenc++;
	lenn=lenc;
	memset(n,0,sizeof(n));
	for (int i=1;i<=lenc;i++)
		n[i]=c[i];
}
void chu()//p=n/k
{
	lenc=0;
	memset(c,0,sizeof(c));
	memset(p,0,sizeof(p));
	long long m=0;
	for (int i=lenn;i>=1;i--)
	{
		m=m*10+n[i];
		p[i]=m/k;
		m=m%k;
	}
	lenp=lenn;
	while (p[lenp]==0)
		lenp--;
}
void mo()//n=n%k
{
	lenc=0;
	memset(c,0,sizeof(c));
	long long m=0;
	for (int i=lenn;i>=1;i--)
	{
		m=m*10+n[i];
		m=m%k;
	}
	lenn=log10(m)+1;
	int x=0;
	memset(n,0,sizeof(n));
	while (m)
	{
		n[++x]=m%10;
		m/=10;
	}
}
int pd()
{
	memset(c,0,sizeof(c));
	long long m=0;
	long long x=log10(k)+1;
	if (lenn>x)
		return 1;
	else if (lenn<x)
		return 0;
	else
	{
		for (int i=lenn;i>=1;i--)
			m=m*10+n[i];
		if (m>=k)
			return 1;
		else
			return 0;
	}
}
int pd1()
{
	long long m=0;
	for (int i=lenn;i>=1;i--)
		m=m*10+n[i];
	if (m==k-1)
		return 1;
	else
		return 0;
}
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s;
	lenn=s.length();
	for (int i=0;i<lenn;i++)
		n[lenn-i]=s[i]-'0';
	cin>>k;
	while (pd())
	{
		chu();
		jia1();
		mo();
		jia2();
	}
	if (pd1())
	{
		lenp=1;
		memset(p,0,sizeof(p));
		p[1]=1;
		jia1();
	}
	for (int i=lena;i>=1;i--)
		cout<<ans[i];
	return 0;
}

