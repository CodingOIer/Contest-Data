#include<bits/stdc++.h>
using namespace std;
long long n,k,ans=0;
long long a[1000005];
long long b[1000005];
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for (long long i=1;i<=n;i++)
		cin>>a[i];
	for (long long i=1;i<=n;i++)
		cin>>b[i];
	sort(b+1,b+n+1);
	for (long long i=k;i>=1;i--)
		ans+=b[i];
	cout<<ans;
	return 0;
}
