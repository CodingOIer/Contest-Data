#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,d;
int a[500005];
int tr[2000005],lazy[2000005];
void build(int k,int l,int r)
{
	if(l==r)
	{
		tr[k]=a[l];
		return;
	}
	int mid=(l+r)/2;
	build(k*2,l,mid);
	build(k*2+1,mid+1,r);
	tr[k]=tr[k*2]+tr[k*2+1];
}
void pushup(int k)
{lazy[k]+=lazy[k*2]+lazy[k*2+1];}
void update(int k,int l,int r,int lt,int rt,int p)
{
	if(lt>r || rt<l) return;
	if(lt>=l && rt<=r)
	{
		tr[k]+=p*(r-l+1);
		lazy[k]+=p;
		return;
	}
	int mid=(l+r)/2;
	update(k*2+1,mid+1,r,lt,rt,p);
	update(k*2,l,mid,lt,rt,p);
	pushup(k);
}
void pushdown(int k,int l,int r)
{
	if(lazy[k])
	{
		int mid=(l+r)/2;
		lazy[k*2]+=lazy[k];
		lazy[k*2+1]+=lazy[k];
		tr[k*2]+=lazy[k]*(mid-l+1);
		tr[k*2+1]+=lazy[k]*(r-mid);
		lazy[k]=0;
	}
}
int sreach(int k,int l,int r,int lt,int rt)
{
	if(lt>r || rt<l) return 0;
	if(lt>=l && rt<=r)
		return tr[k];
	pushdown(k,l,r); 
	int res=0;
	int mid=(l+r)/2;
	res+=sreach(k*2+1,mid+1,r,lt,rt);
	res+=sreach(k*2,l,mid,lt,rt);
	return res;
}
signed main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=n;i++)
		a[i]=k;
	build(1,1,n);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%lld%lld",&x,&y);
		cout<<"1\n";
		update(1,1,n,x-d,x+d,-y);
		cout<<"1\n";
		if(sreach(1,1,n,x,x+d)<y) printf("NO\n");
		else printf("YES\n");
	}
	return 0;
}
