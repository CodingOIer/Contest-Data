#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,ans;
struct kkk{
	int t,v;
} a[100005];
bool cmp(kkk x,kkk y){return x.v<y.v;}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>m;
	k=n;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].t);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].v),ans+=a[i].v;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		if(k==m) break;
		k--,ans-=a[i].v;
	}
	cout<<ans;
	return 0;
}
