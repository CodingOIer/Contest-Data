#include<bits/stdc++.h>
#define int long long
using namespace std;
string s,ans;
int n[100005],k,l,x;
bool fl;
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s>>k;
	k--;
	l=s.length();
	s=" "+s;
	for(int i=1;i<=l;i++)
		n[i]=s[i]-'0';
	for(int i=1;i<=l;i++)
	{
		x=x*10+n[i];
		if(x>=k) fl=1;
		if(fl) ans+=char(x/k+'0'),x%=k;
	}
	cout<<ans;
	return 0;
}
