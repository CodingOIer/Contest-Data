#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int n;
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	if(n==1) cout<<1;
	if(n==2) cout<<6;
	if(n==3) cout<<2160;
	return 0;
}
/*
1
1

2
1 2 3

3
1 2 3 3 4 5 6
1-6
3-3

4
1 2 3 3 4 4 5 5 6 6 7 7 8 9 10
1-10
3-7

5
1 2 3 3 4 4 5 5 5 6 6 6 7 7 7 8 8 8 9 9 9
10 10 10 11 11 12 12 13 14 15
1-15
3-12
5-10
*/
