#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n;
	cout<<n;
	return 0;
}
