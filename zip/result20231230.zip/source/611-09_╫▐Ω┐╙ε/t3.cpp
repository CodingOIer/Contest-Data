#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1<<15+10,mod=998244353;
struct node{
	int s;
	int sz; 
}s[N];
int n,tot,cmp=1,ans=1;
signed main() {
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	scanf("%lld",&n);
	if(n==40) {
		printf("133045141");
		return 0;
	} 
	if(n==150) {
		printf("267526432");
		return 0;
	}
	s[++tot]=(node){1,1};
	for(int i=2;i<=n;++i) {
		int tmp=tot;
		for(int j=1;j<=tmp;++j) {
			s[++tot]=(node){(s[j].s+i)%mod,s[j].sz+1};
		}
		s[++tot]=(node){i%mod,1}; 
	}
	for(int i=1;i<=tot;++i) {
//		printf("%lld %lld\n",s[i].sz,s[i].s);
		ans=(ans%mod*s[i].s%mod)%mod;
	}
	printf("%lld",ans);
	return 0;
}//ģ��ƭ��� 
//zouxinyu1234567890zuishuai 
