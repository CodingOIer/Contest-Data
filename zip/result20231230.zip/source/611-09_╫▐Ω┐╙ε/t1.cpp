#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=1e5+10;
struct node{
	int s;
	int t;
}a[N];
int n,k,ans;
bool cmp(node a,node b) {
	return a.s>b.s;
}
signed main() {
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout); 
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;++i) scanf("%lld",&a[i].t);
	for(int i=1;i<=n;++i) scanf("%lld",&a[i].s);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=k;++i) {
		ans+=a[i].s;
	}
	printf("%lld",ans);
	return 0;
}//С̰�ģ�������״ѹ�ģ���N<1e5����֪���ǲ��Ǽٵ�  
//zouxinyu1234567890zuishuai
