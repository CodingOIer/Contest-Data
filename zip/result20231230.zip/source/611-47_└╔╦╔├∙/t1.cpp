#include <bits/stdc++.h>
using namespace std;
int n, k;
struct node {
	int t, money;
} s[100010];
bool cmp(node a, node b) {
	return a . money > b . money;
}
int main() {
	ios :: sync_with_stdio(false);
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i <= n; i ++) cin >> s[i] . t;
	for (int i = 1; i <= n; i ++) cin >> s[i] . money;
	if (n <= 20 && k == 1) {
		int ans = INT_MIN;
		for (int i = 1; i <= n; i ++) ans = max(s[i] . money, ans);
	}
	long long ans = 0;
	sort(s + 1, s + n + 1, cmp);
	for (int i = 1; i <= k; i ++) ans += s[i] . money;
	cout << ans << endl;
	return 0;
}
