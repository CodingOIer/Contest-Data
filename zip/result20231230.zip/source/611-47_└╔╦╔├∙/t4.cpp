#include <bits/stdc++.h>
using namespace std;
int n, m, k, d;
map <int, bool> build;
int main() {
	ios :: sync_with_stdio(false);
	freopen("t4.in", "r", stdin);
	freopen("t4.out", "w", stdout);
	cin >> n >> m >> k >> d;
	for (int i = 1; i <= m; i ++) {
		int x, y;
		cin >> x >> y;
		if (build[x] != true) cout << "YES" << endl;
		else cout << "NO" << endl;
		build[x] = true;
	}
	return 0;
}
