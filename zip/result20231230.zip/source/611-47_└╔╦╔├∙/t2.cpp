#include <bits/stdc++.h>
using namespace std;
long long n, k;
int main() {
	ios :: sync_with_stdio(false);
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	cin >> n >> k;
	if (n <= LONG_LONG_MAX) cout << n / (k - 1) << endl;
	else {
		cout << n / (k - 1) << endl;
	}
	return 0;
}
