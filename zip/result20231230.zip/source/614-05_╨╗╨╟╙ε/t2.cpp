#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
char n[114514],ans[114514];
int k,tot = 0;
void Pepsee_()
{
	int len = strlen(n+1);
	int i = 0,res = 0;
	k--;
	while (i <= len)
	{
		while (res < k && i <= len){
			i++;
			if (i > len) break;
			res = (res<<1)+(res<<3)+(n[i]^48);
			ans[++tot] = '0';
		}
		if (i > len) break;
		ans[tot] = res/k+'0';
		res = res%k;
	}
}
void print()
{
	int i = 1;
	while (i <= tot && ans[i]=='0')
		i++;
	if (i > tot){
		putchar('0');
		exit(0);
	}
	for (; i <= tot; i++)
		putchar(ans[i]);
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%s",n+1);
	k = read();
	Pepsee_();
	print();
	return 0;
}
