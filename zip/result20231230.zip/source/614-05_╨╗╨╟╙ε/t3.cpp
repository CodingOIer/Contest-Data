#include <bits/stdc++.h>
#define int __int128
using namespace std;
const int Mod = 998244353;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,ans = 1;
int ton[114514];
int ksm(int a,int b)
{
	int res = 1;
	for (; b; b >>= 1){
		if (b&1) res = res*a%Mod;
		a = a*a%Mod;
	}
	return res;
}
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	n = read();
	for (int i = 1; i <= n; i++)
	{
		for (int j = (i*(i-1))>>1; j >= 1; j--)
			if (ton[j]) ton[i+j] += ton[j];
		ton[i]++;
	}
	for (int i = 1; i <= ((n+1)*n)>>1; i++)
		if (ton[i]) ans = ans*ksm(i,ton[i])%Mod;
	write(ans);
	return 0;
}
