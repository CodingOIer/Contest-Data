#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
struct node{
	int v,t;
}coin[114514];
int n,k,ans;
bool cmp(node a,node b){
	return a.v > b.v;
}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	n = read(); k = read();
	for (int i = 1; i <= n; i++)
		coin[i].t = read();
	for (int i = 1; i <= n; i++)
		coin[i].v = read();
	sort(coin+1,coin+n+1,cmp);
	for (int i = 1; i <= k; i++)
		ans = ans+coin[i].v;
	write(ans);
	return 0;
}
