#include <bits/stdc++.h>
using namespace std;
int n,m=998244353,t;
vector<int> num;
long long ans=1;
int main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	scanf("%d",&n);
	num.push_back(0);num.push_back(1);t=1;
	for(int i=2;i<=n;i++)
	{
		for(int j=1;j<=t;j++)
			num.push_back(num[j]+i);
		num.push_back(i);
		t=t*2+1;
	}
	for(int i=1;i<=t;i++)
		ans=(ans*((num[i])%m))%m;
	printf("%lld",ans);
	return 0;
}
