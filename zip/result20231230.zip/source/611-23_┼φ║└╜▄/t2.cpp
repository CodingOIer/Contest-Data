#include <bits/stdc++.h>
using namespace std;
long long n,k,l,ans;
int main() 
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%d%d",&n,&k);
	while(1)
	{
		ans+=n/k;
		n=n%k+n/k;
		if(n<k)
		{
			if(n==k-1)
				ans++;
			break;
		}
	}
	cout<<ans;
	return 0;
}

