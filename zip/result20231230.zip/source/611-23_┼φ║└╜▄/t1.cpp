#include <bits/stdc++.h>
using namespace std;
int n,k,t[100005],v[100005],sol_v[1000010],sol_num[1000010],maxt;
long long ans=0;
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&t[i]);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&v[i]);
		sol_v[v[i]]=max(sol_v[v[i]],t[i]);
		sol_num[v[i]]++;
	}
	for(int i=1000005;i>=1;i--)
	{
		if(k==0)break;
			long long t=min(k,sol_num[i]);
			k-=t;
		ans+=(long long)t*i;	
	}
	printf("%lld",ans);
	return 0;
}
