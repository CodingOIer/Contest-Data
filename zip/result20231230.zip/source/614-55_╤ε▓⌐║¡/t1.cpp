#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e5+5;
int n,k,ans,tim;
struct node{int t,v;}a[MAX];
int cmp(node x,node y){
	if(x.v == y.v) return x.t<y.t;
	return x.v>y.v;
}
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i = 1; i<=n; i++) cin>>a[i].t;
	for(int i = 1; i<=n; i++) cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	for(int i = 1; i<=n; i++){
		tim++;
		if(tim <= a[i].t)
			ans += a[i].v,k--;
		if(!k) break;
	}
	cout<<ans;
	return 0;
}
