#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e5+5;
int n,k,ans;
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	while(n){
		ans += n/k;
		n = n/k+n%k;
		if(n < k-1) break;
		if(n == k-1) ans++,n = 0;
	}
	cout<<ans;
	return 0;
}

