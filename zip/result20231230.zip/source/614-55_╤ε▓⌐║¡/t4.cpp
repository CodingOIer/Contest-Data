#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAX = 1e5+5;
int n,q,m,d;
struct node{int l,r,w,f;}tree[MAX*4];
void bui(int k,int l,int r){
	tree[k].l = l,tree[k].r = r;
	if(l == r){tree[k].w = m;return;}
	int mid = (l+r)>>1;
	bui(k<<1,l,mid),bui(k<<1|1,mid+1,r);
	tree[k].w = (tree[k<<1].w+tree[k<<1|1].w);
}
void down(int k){
	tree[k<<1].f += tree[k].f;
	tree[k<<1|1].f += tree[k].f;
	// tree[k<<1].w += tree[k].f;
	// tree[k<<1|1].w += tree[k].f;
	tree[k<<1].w += tree[k].f*(tree[k<<1].r-tree[k<<1].l+1);
	tree[k<<1|1].w += tree[k].f*(tree[k<<1|1].r-tree[k<<1|1].l+1);
	tree[k].f = 0;
}
void change(int k,int l,int r,int ch){
	if(l <= tree[k].l && tree[k].r <= r){
		tree[k].f = ch,tree[k].w += ch;return;}
	int mid = (tree[k].l+tree[k].r)>>1;
	if(l <= mid) change(k<<1,l,r,ch);
	if(r > mid) change(k<<1|1,l,r,ch);
	tree[k].w = (tree[k<<1].w+tree[k<<1|1].w);
}
int ask(int k,int l,int r){
	if(l <= tree[k].l && tree[k].r <= r) return tree[k].w;
	if(tree[k].f) down(k);
	int mid = (tree[k].l+tree[k].r)>>1,ans = 0;
	if(l <= mid) ans = (ans+ask(k<<1,l,r));
	if(r > mid) ans = (ans+ask(k<<1|1,l,r));
	return ans;
}
signed main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>q>>m>>d;
	bui(1,1,1e5);
	for(int i = 1; i<=q; i++){
		int x,y; cin>>x>>y;
		if(y>=0){
			if(m+1<y){
				// cout<<m+1<<":"<<y<<endl;
				cout<<"NO"<<endl;
				change(1,x,x+y-1,-1);
				continue;
			}
			else{
				// cout<<x<<":"<<x+y-1<<":"<<ask(1,x,x+y-1)<<endl;
				if(ask(1,x,min(n,x+y-1)) >= y) cout<<"YES"<<endl;
				else cout<<"NO"<<endl;
				change(1,x,x+y-1,-1);
			}
		}
		if(y<0){
			cout<<"YES"<<endl;
			change(1,x,x+y-1,1);
		}
	}
	return 0;
}