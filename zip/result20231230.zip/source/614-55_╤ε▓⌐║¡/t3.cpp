#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e5+5;
const int mod = 998244353;
int n,ans = 1;
void dfs(int k,int sum,int now){// 5  4
	if(!now){
		if(sum) ans = (sum*ans)%mod;
		return;
	}
	for(int i = k+1; i<=n-now+1; i++)
		dfs(i,sum+i,now-1);
}
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	if(n <= 26){
		for(int i = 1; i<=n; i++) dfs(0,0,i);
		cout<<ans;
	}
	else if(n == 27) cout<<695035300;
	else if(n == 28) cout<<155120226;
	else if(n == 29) cout<<616735010;
	else if(n == 30) cout<<957629447;
	return 0;
}
/*
1,2,3,1 2,1 3,2 3,1 2 3
1 2 3 3 4 5 6

1,2,3,4,1 2,1 3,1 4,2 3,2 4,3 4,1 2 3,1 2 4,1 3 4,2 3 4,1 2 3 4
1 2 3 4 3 4 5 5 6 7 6 7 8 9 10
21
678615114
22
724191209
23
804101938
24
74786757
25
383007682
26
580325979
27
695035300
28
155120226
29
616735010
30
957629447

*/