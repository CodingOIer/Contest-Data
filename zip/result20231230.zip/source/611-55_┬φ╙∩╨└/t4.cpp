#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,k,d;
ll x[500005],y[10000005],a[1000005];
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m>>k>>d;
	for(ll i=1;i<=m;i++){
		cin>>x[i]>>y[i];
		if(y[i]<0)cout<<"YES"<<endl,a[y[i]]--;
		else if(a[y[i]]<k) cout<<"YES"<<endl,a[y[i]]++;
		else cout<<"NO"<<endl;
	}
	return 0;
}
