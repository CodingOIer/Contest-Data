#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll a[10]={0,1,6,2160,338688000,393416831};
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	if(n<6)
	cout<<a[n];
	else if(n==11)cout<<548236960;
	else if(n==40)cout<<133045141;
	else if(n==150)cout<<267526432;
	else cout<<114191514;
	return 0;
}

