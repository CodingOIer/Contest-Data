#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,a;
string m; 
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m;
	for(ll i=0;i<m.size();i++){
		if(m[i]=='?')a++;
	}
	if(a*2+n==9)cout<<a*2+n;
	else cout<<a*2+n;
	return 0;
}

