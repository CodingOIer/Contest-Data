#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m; 
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m;
	cout<<n/(m-1);
	return 0;
}//��ô��ô�������!10^100000

