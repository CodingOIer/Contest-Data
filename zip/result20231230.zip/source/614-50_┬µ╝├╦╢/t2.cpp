#include<bits/stdc++.h>
using namespace std;
long long n,k,ans;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	while(n>=k){
		ans+=n/k;
		n=n%k+n/k;
	}
	if(n==k-1) ans++;
	cout<<ans;
	return 0;
}

