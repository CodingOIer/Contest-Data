#include<bits/stdc++.h>
using namespace std;
int a,b,c,d,l,r;
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>a>>b>>c>>d;
	for(int i=1;i<=b;i++){
		cin>>l>>r;
		cout<<"YES"<<endl;
	}
	return 0;
}

