#include<bits/stdc++.h>
using namespace std;
long long n,k,l,ans,g[100005],w;
struct jb{
	long long t,v;
}a[100005];
bool cmp(jb b,jb c){
	if(b.t==c.t) return b.v>c.v;
	else return b.t<c.t;
}
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(long long i=1;i<=n;i++) cin>>a[i].t;
	for(long long i=1;i<=n;i++) cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	for(long long i=1;i<=n;i++){
		if(a[i].t==a[i-1].t) continue;
//		cout<<a[i+0].t<<" "<<a[i].t<<endl;
		for(long long j=0;j<a[i].t-l;j++){
			if(a[i+j].t!=a[i].t) break;
			g[++w]=a[i+j].v;
		}
		l=a[i].t;
	}
	sort(g+1,g+w+1);
	for(long long i=w;i>max(0ll,w-k);i--){
		ans+=g[i];
	}
	cout<<ans;
	return 0;
}

