#include<bits/stdc++.h>
using namespace std;
const long long mod=998244353;
long long n,ans=1,v[205];
void dfs(long long sum,int g){
	ans*=sum;
	ans%=mod;
	for(int i=g;i<=n;i++){
		if(!v[i]){
			v[i]=1;
			dfs(sum+i,i);
			v[i]=0;
		}
	}
}
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		v[i]=1;
		dfs(i,i);
	}
	cout<<ans;
	return 0;
}

