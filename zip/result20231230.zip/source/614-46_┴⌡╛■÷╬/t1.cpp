#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define endl "\n"
#define elif else if
using namespace std;
ll ans,n,k,t[101010],a[101010];
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin >> n >> k;
	for(int i=1;i<=n;i++)
		cin >> t[i];
	for(int j=1;j<=n;j++)
		cin >> a[j];
	sort(a+1,a+n+1);
	reverse(a+1,a+n+1);
	for(int i=1;i<=k;i++)
		ans+=a[i];
	cout << ans;
	return 0;
}
