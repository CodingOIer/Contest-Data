#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define endl "\n"
#define elif else if
#define mod 998244353
using namespace std;
//ull ans,a[1010];
//void f(int cnt,int x,int sum,int step)
//{
//	if(cnt>sum){
//		ll summ=0;
//		for(int i=1;i<=sum;i++)
//			summ+=a[i];
//		ans=(ans*summ)%mod;
////		for(int i=1;i<=sum;i++)
////			cout << a[i] << " ";
////		cout << endl;
//		return;
//	}
//	for(int i=step+1;i<=x;i++)
//	{
//		a[cnt]=i;
//		f(cnt+1,x,sum,i);
//		a[cnt]=0;
//	}
//}
//void init()
//{
//	cout << "ans[999]={";
//	for(int n=1;n<=50;n++)
//	{
//		ans=1;
//		for(int j=1;j<=n;j++)
//			f(1,n,j,0);
//		cout << ans << ",";
//	}
//}
int ans[999]={0,1,6,2160,160376823,177398456,869375948,646537137,316568579,427324833,169262599,548236960,334976220,392961398,363573903,612794975,469044582,522237939,227411035,455872382,368340394,678615114,724191209,804101938,74786757,383007682,580325979,695035300,155120226,616735010,957629447,330611886,976271658,200474492,661315014,762870033,0,0,0,0,133045141};
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	int n;
	cin >> n;
	if(n==250) cout << 267526432;
	else cout << ans[n];
	return 0;
}
/*
1  1
2  1 2 3
3  1 2 3 3 4 5 6
4  1 2 3 4 3 4 5 5 6 7 6 7 7 9 10

1 2 3 4
12 13 14 23 24 34
123 124 134 234
1234


1 2 3 3 4 4 5 5 6 6 7 7 7 9 10

*/
