#include <bits/stdc++.h>
using namespace std;
int tr[2000200],vis[2000200];
int n,m,k,d,a[505050];
void push_down(int x)
{
	if(vis[x]==0) return;
	tr[x*2]+=vis[x];tr[x*2+1]+=vis[x];
	vis[x*2]+=vis[x];vis[x*2+1]+=vis[x];
	vis[x]=0;
}
void build(int l,int r,int x)
{
	if(l==r){
		tr[x]=a[l];
		return;
	}
	int mid=(l+r)/2;
	build(l,mid,x*2);
	build(mid+1,r,x*2+1);
	tr[x]=min(tr[x*2],tr[x*2+1]);
}
void change(int l,int r,int lt,int rt,int x,int k)
{
	if(l>=lt&&r<=rt){
		tr[x]+=k,vis[x]+=k;
		return;
	}
	int mid=(l+r)/2;
	push_down(x);
	if(lt<=mid) change(l,mid,lt,rt,x*2,k);
	if(rt>mid) change(mid+1,r,lt,rt,x*2+1,k);
	tr[x]=min(tr[x*2],tr[x*2+1]);
	return;
}
int ask(int l,int r,int lt,int rt,int x)
{
	if(l>=lt&&r<=rt) return tr[x];
	int mid=(l+r)/2,ans=999999999;
	push_down(x);
	if(lt<=mid) ans=ask(l,mid,lt,rt,x*2);
	if(rt>mid) ans=min(ans,ask(mid+1,r,lt,rt,x*2+1));
	return ans;
}
void init()
{
	cin >> n >> m >> k >> d;
	for(int i=1;i<=n;i++)
		a[i]=k;
	build(1,n,1);
}
void solve()
{
	int x,y;
	cin >> x >> y;
	if(y>d) cout << "NO\n";
	else{
		change(1,n,x,x+d,1,-1);
		if(ask(1,n,x,x+d,1)<0) cout << "NO\n";
		else cout << "YES\n";
	}
}
signed main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	init();
	while(m--)
		solve();
	return 0;
}
