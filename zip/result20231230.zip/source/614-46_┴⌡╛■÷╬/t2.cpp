#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define endl "\n"
#define elif else if
using namespace std;
int a[101010],ans1[101010];
string s;
ll ans,n,k,last;
void baoli()
{
	ll m=0;
	for(int i=1;i<=n;i++)
		m=(m*10)+a[i];
	while(1)
	{
		if(m+1==k){
			ans++;
			break;
		}
		if(m<k) break;
		ans+=m/k;
		m=m/k+m%k;
//		cout << ans << " ";
	}
	cout << ans;
}
void waijie()
{
	k--;
	ll m=0,sum=0;
	for(int i=1;i<=n;i++)
	{
		m=(m*10)+a[i];
		if(m>=k){
			ans1[++sum]=m/k;
			m%=k;
		}
		else ans1[++sum]=0;
	}
	bool f=0;
	for(int i=1;i<=sum;i++)
		if(ans1[i]==0){
			if(f==0) continue;
			else cout << ans1[i];
		}
		else cout << ans1[i],f=1;
		
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin >> s >> k;
	for(int i=0;i<(n=s.size());i++)
		a[i+1]=int(s[i]-'0');
	if(n<=18) baoli();
	else waijie();
	return 0;
}
// ans=int(n/(m-1))

