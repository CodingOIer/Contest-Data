#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define endl "\n"
#define elif else if
using namespace std;
signed main()
{
	ll a=1,b=1,mod;
	mod=998244353;
	for(int i=1;i<=13;i++)
	{
		a=(a*i)%mod;
		b=b*i;
	}
	cout << a << " " << b%mod;
	return 0;
}
