#include<iostream>
using namespace std;
long long ans=1;
long long m,n;
void dfs(long long x,long long s,long long h){
//	cout<<h<<"\n";
	if(h)ans*=h;
	ans%=998244353;
	if(x>m){
		return;
	}
	for(long long i=s+1;i<=n;i++)dfs(x+1,i,h+i);
}
int main(){
	cin>>n;
	m=n;
	dfs(1,0,0);
	cout<<ans;
	return 0;
}
