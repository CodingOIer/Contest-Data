#include<iostream>
using namespace std;
long long ans=1;
long long m,n;
void dfs(long long x,long long s,long long h){
	if(x>m){
		ans*=h;
		ans%=998244353;
//		cout<<h<<"\n";
		return;
	}
	for(long long i=s+1;i<=n-(m-x);i++)dfs(x+1,i,h+i);
	return;
}
int main(){
	while(1){
		cin>>n;
		ans=1;
	for(long long i=1;i<=n;i++){
		cout<<i<<"\n";
		m=i;
		dfs(1,0,0);
	}
	cout<<ans;
	}
	
	return 0;
}
