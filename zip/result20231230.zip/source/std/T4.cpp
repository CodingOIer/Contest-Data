#include<bits/stdc++.h>
#define LL long long
using namespace std;
char buf[1<<21],*p1=buf,*p2=buf;
const int N=2e6+10;
int n,m,k,d;
LL sum[N],lmax[N],rmax[N],maxn[N];
void push_up(int t){
	int ls=t<<1,rs=(t<<1)|1;
	sum[t]=sum[t<<1]+sum[(t<<1)|1];
	lmax[t]=max(lmax[ls],sum[ls]+lmax[rs]);
	rmax[t]=max(rmax[rs],sum[rs]+rmax[ls]);
	maxn[t]=max(max(maxn[ls],maxn[rs]),rmax[ls]+lmax[rs]);
}
void push_x(int t,int x){
	sum[t]+=x; lmax[t]=rmax[t]=maxn[t]=sum[t];
}
void build(int l,int r,int t){
	if(l==r){push_x(t,-k);return;}
	int mid=(l+r)>>1;
	build(l,mid,t<<1); build(mid+1,r,(t<<1)|1);
	push_up(t);
}
void modify(int l,int r,int t,int x,int y){
	if(l==r){push_x(t,y);return;}
	int mid=(l+r)>>1;
	if(mid>=x)modify(l,mid,t<<1,x,y);
	else modify(mid+1,r,(t<<1)|1,x,y);
	push_up(t);
}
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&d);//cin>>n>>m>>k>>d;
	build(1,n-d,1);
	for(int i=1,x,y;i<=m;i++){
		scanf("%d%d",&x,&y);//cin>>x>>y;
		modify(1,n-d,1,x,y);
		if(maxn[1]<=1ll*k*d)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
