#include <bits/stdc++.h>
int n, t, k, a[100005];
long long sum = 0;
using namespace std;
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin >> n >> k;
	for(int i = 1; i <= n; i++)	cin >> t;
	for(int i = 1; i <= n; i++)	cin >> a[i];
	sort(a+1, a+1+n);
	for(int i = n; i >= n - k + 1; i--)
			sum += a[i];
	cout << sum << endl;
} 
