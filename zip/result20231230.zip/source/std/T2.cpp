#include <bits/stdc++.h> 
using namespace std;
char ans[100005],a[100005], b[100005];
#define ll long long
ll p = 0, k = 0, n, j = 0, flag = 0;
int main() {
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%s %d", a, &k);
	k--;
	n = strlen(a);
	for(int i = 0; i < n; i++){
		p = p * 10 + a[i] - '0';
		if(p >= k) {
			ans[j++] =p / k + '0';
			p = p % k;
		} else ans[j++] ='0';
	}
	for(int i = 0; i < j; i++) {
		if(ans[i] != '0') flag = 1;
		if(flag == 1) printf("%c", ans[i]);
	}
}
