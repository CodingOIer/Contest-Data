#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5,MOD=1e9+7;
//ll n,k;
string n;
ll k;
ll a[N]={0},b[N]={0};
ll len1;
//void jian(string s2){
//	ll i=0;
//	while(1){
//		if(i==s2.length()-1){
//			if(b[i]==1){
//				b[i]=0;
//				len2--;
//			}
//			else{
//				b[i]--;
//			}
//			break;
//		}
//		if(b[i]==0){
//			b[i]=9;
//		}
//		else{
//			if(b[i]==1){
//				b[i]=0;
//				len2--;
//			}
//			else{
//				b[i]--;
//			}
//			break;
//		}
//	}
//}
void op(string s1,ll s2){
	for(ll i=0;i<len1;i++){
		a[i]=s1[i]-'0';
	}
	ll jw=0;
	for(int i=0;i<len1;i++){
		jw*=10;
		jw+=a[i];
		b[i]=jw/k;
		jw%=k;
	}
//	cout<<":";
	if(b[0]==0){
		bool f=0;
		for(ll i=0;i<len1;i++){
			if(b[i]!=0){
				f=1;
			}
			if(f==0){
				continue;
			}
			cout<<b[i];
		}
		if(f==0){
			cout<<0;
		}
	}
	else{
		for(ll i=0;i<len1;i++){
			cout<<b[i];
		}
	}
}
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin>>n>>k;
	--k;
	len1=n.length();
	op(n,k);
//	cout<<(n/(k-1));
	return 0;
}
