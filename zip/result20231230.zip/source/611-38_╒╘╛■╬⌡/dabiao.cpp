#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5,MOD=998244353;
ll cnt;
//void dg(ll n){
//	for(ll i=1;i<=n;i++){
//		for(ll j=1;j<=i;j++){
//			cout<<j<" ";
//		}
//		cout<<endl;
//	}
//}
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	ll n;
	cin>>n;
	if(n==1)	cout<<1;
	else if(n==2)	cout<<6;
	else if(n==3)	cout<<2160;
	else if(n==11)	cout<<548236960;
	else if(n==40)	cout<<133045141;
	else if(n==150)	cout<<267526432;
	return 0;
}
