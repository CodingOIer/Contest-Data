#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5,MOD=1e9+7;
ll n,m,cnt;
struct jingbi{
	ll v,w;
} a[N];
bool cmp(jingbi x,jingbi y){
	return (x.v==y.v?x.w<y.w:x.v>y.v);
}
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin>>n>>m;
	for(ll i=1;i<=n;i++)	cin>>a[i].w;
	for(ll i=1;i<=n;i++)	cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	ll i=1,ans=0;
	while(m>ans){
		if(a[i].w>=ans){
			cnt+=a[i].v;
			ans++;
		}
		++i;
	}
	cout<<cnt; 
	return 0;
}
