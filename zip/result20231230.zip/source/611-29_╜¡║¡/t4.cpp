#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	int n,m,k,d;
	srand(time(0));
	cin>>n>>m>>k>>d;
	for(int i=1;i<=m;i++){
		int t=rand()%2+1;
		if(t==1)
		cout<<"NO\n";
		else cout<<"YES\n";
	} 
	return 0;
}

