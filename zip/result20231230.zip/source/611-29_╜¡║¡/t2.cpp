#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,sum;
void ddd(int w){
	int g=w/k;
	int gg=w%k;
//	cout<<g<<" "<<gg<<"\n";
	if(gg==k-1){
	g++,gg=0;
//	cout<<"fuck\n";
	}
	sum+=g;
//	cout<<sum<<endl;
	if(w<=k){
		if(g+gg==k-1){
		sum++;
//		cout<<"fuck\n";
		}
		return ;
	}
	ddd(g+gg);
} 
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	ddd(n);
	cout<<sum;
	return 0;
}
/*
10 3
g  3 1
gg 1 1
*/
