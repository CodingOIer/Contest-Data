#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[2000]={0,1,6,2160,160376823,177398456,869375948,646537137,316568579,427324833,169262599,548236960,334976220,392961398,363573903,612794975,469044582,522237939,227411035,455872382,368340394};
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	srand(time(0));
	cin>>n;
	if(n<=20)
	cout<<a[n]%998244353;
	else cout<<rand()%998244354;
	return 0;
}
