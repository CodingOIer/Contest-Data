#include<bits/stdc++.h>
#define int long long
using namespace std;
int ans=1,sum;
signed main(){
	for(int a=0;a<=1;a++){
		for(int b=0;b<=1;b++){
								if(a+b==0)
									continue; 
								sum=(a*1+b*2);
								ans=ans*sum%998244353;
			
		}
	}
	cout<<ans;
	return 0;
}

