#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e7;
int n,k,sum,a[N];
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	for(int i=n;i>n-k;i--)
	sum+=a[i];
	cout<<sum; 
	return 0;
}

