#include <bits/stdc++.h>
using namespace std;

long long n, k, ans;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	cin >> n >> k;

	while (n >= k) {
		ans += n / k;
		n = n / k + n % k;
	}

	printf("%lld", ans + (n == k - 1));
	return 0;
}
