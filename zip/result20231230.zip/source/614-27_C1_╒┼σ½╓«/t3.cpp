#include <bits/stdc++.h>
using namespace std;

int n;
const int mod = 998244353;
long long ans = 1;
long long now[40005], now1[40005];

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("t3.in", "r", stdin);
	freopen("t3.out", "w", stdout);
	now[0] = 1;
	cin >> n;

	for (int i = 1; i <= n; i++) {
		for (int j = 0; j <= i * (i - 1) >> 1; j++) now1[i + j] = now[j];

		for (int j = i; j <= i * (i + 1) >> 1; j++) now[j] = (now[j] + now1[j]) % (mod - 1);
	}

	for (int i = 1; i <= n * (n + 1) >> 1; i++) {
		long long a = i;

		while (now[i]) {
			if (now[i] & 1) ans = ans * a % mod;

			a = a * a % mod;
			now[i] >>= 1;
		}
	}

	printf("%lld", ans);
	return 0;
}
