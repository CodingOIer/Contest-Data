#include <cstdio>
int main()
{
    freopen("t5.in", "r", stdin);
    freopen("t5.out", "w", stdout);
    printf("7\n");
    return 0;
}