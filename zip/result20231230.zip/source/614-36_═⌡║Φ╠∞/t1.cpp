#include <algorithm>
#include <cstdio>
constexpr int MaxN = 1e5 + 5;
int n, k;
int p[MaxN];
long long answer;
int main()
{
    freopen("t1.in", "r", stdin);
    freopen("t1.out", "w", stdout);
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= n; i++)
    {
        scanf("%*d");
    }
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &p[i]);
    }
    std::sort(p + 1, p + 1 + n, [](const int &__x, const int &__y) { return __x > __y; });
    for (int i = 1; i <= k; i++)
    {
        answer += p[i];
    }
    printf("%lld\n", answer);
    return 0;
}