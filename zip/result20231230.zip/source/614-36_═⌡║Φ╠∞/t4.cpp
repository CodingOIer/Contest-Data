#include <cmath>
#include <cstdio>
constexpr int MaxN = 5e5 + 5;
long long n, m, k, d;
long long sum;
long long use[MaxN];
long long tmp[MaxN];
long long people[MaxN];
inline long long read()
{
    register char c;
    register long long x, f = 1;
    for (;;)
    {
        c = getchar();
        if (c == '-')
        {
            f = -1;
        }
        else if ('0' <= c && c <= '9')
        {
            x = c - '0';
            break;
        }
    }
    for (;;)
    {
        c = getchar();
        if ('0' <= c && c <= '9')
        {
            x = 10 * x + c - '0';
        }
        else
        {
            break;
        }
    }
    return x * f;
}
int main()
{
    freopen("t4.in", "r", stdin);
    freopen("t4.out", "w", stdout);
    n = read();
    m = read();
    k = read();
    d = read();
    register int left = 0, right = 0;
    register bool last = true;
    for (int i = 1; i <= n; i++)
    {
        register long long x, y;
        x = read();
        y = read();
        sum += y;
        people[x] += y;
        if ((y > 0 && !last) || sum > n * k || (!last && (x > right || x < left - d)))
        {
            printf("NO\n");
            last = false;
            continue;
        }
        if ((y < 0 && last) || sum <= d * k)
        {
            printf("YES\n");
            last = true;
            continue;
        }
        for (register int j = 1; j <= n - d; j++)
        {
            use[j] = 0;
            tmp[j] = people[j];
        }
        last = true;
        for (register int j = 1; j <= n - d; j++)
        {
            for (register int w = j; tmp[j] != 0 && w <= j + d; w++)
            {
                register long long join = k - use[w];
                if (join < tmp[j])
                {
                    tmp[j] -= join;
                    use[w] = k;
                }
                else
                {
                    use[w] += tmp[j];
                    tmp[j] = 0;
                    break;
                }
            }
            if (tmp[j] != 0)
            {
                last = false;
            }
        }
        for (register int i = 1; i <= n - d; i++)
        {
            if (people[i] != 0)
            {
                if (left == 0)
                {
                    left = i;
                }
                right = i;
            }
        }
        printf("%s\n", last ? "YES" : "NO");
    }
    return 0;
}