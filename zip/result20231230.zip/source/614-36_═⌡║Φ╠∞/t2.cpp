#include <cstdio>
#include <cstring>
#include <vector>
char tmp[100005];
class BigInter
{
  private:
    int len;
    std::vector<int> num;
    void vis(int x)
    {
        if ((int)(num.size()) < x + 5)
        {
            num.resize(x + 5);
        }
    }
    void dev10()
    {
        len--;
        for (int i = 1; i <= len; i++)
        {
            vis(i + 1);
            num[i] = num[i + 1];
        }
        num[len + 1] = 0;
    }

  public:
    BigInter()
    {
        len = 0;
        num.clear();
    }
    void in()
    {
        scanf("%s", tmp + 1);
        len = strlen(tmp + 1);
        for (int i = 1; i <= len; i++)
        {
            vis(i);
            num[i] = tmp[len - i + 1] - '0';
        }
    }
    void out(char c = '\0')
    {
        for (int i = len; i >= 1; i--)
        {
            printf("%d", num[i]);
        }
        if (c != '\0')
        {
            printf("%c", c);
        }
    }
    void format()
    {
        for (int i = 1; i <= len; i++)
        {
            vis(i + 1);
            num[i + 1] += num[i] / 10;
            num[i] %= 10;
        }
        vis(len + 1);
        for (; num[len + 1] != 0;)
        {
            vis(len + 1);
            len++;
            num[len + 1] = num[len] / 10;
            num[len] %= 10;
        }
        vis(len);
        for (; num[len] == 0;)
        {
            len--;
            vis(len);
        }
    }
    long long longlong()
    {
        long long res = 0;
        vis(len);
        for (int i = len; i >= 1; i--)
        {
            vis(i);
            res = res * 10 + num[i];
        }
        return res;
    }
    void operator=(const int &x)
    {
        int tmp = x;
        len = 0;
        for (; tmp != 0;)
        {
            len++;
            vis(len);
            num[len] = tmp % 10;
            tmp /= 10;
        }
    }
    friend bool operator<(const BigInter &__x, const BigInter &__y)
    {
        BigInter x = __x;
        BigInter y = __y;
        if (x.len < y.len)
        {
            return true;
        }
        else if (x.len > y.len)
        {
            return false;
        }
        else
        {
            for (int i = x.len; i >= 1; i--)
            {
                x.vis(i);
                y.vis(i);
                if (x.num[i] < y.num[i])
                {
                    return true;
                }
                else if (x.num[i] > y.num[i])
                {
                    return false;
                }
            }
            return false;
        }
    }
    friend bool operator>(const BigInter &x, const BigInter &y)
    {
        return y < x;
    }
    friend bool operator==(const BigInter &x, const BigInter &y)
    {
        return !(x < y) && !(x > y);
    }
    friend bool operator<=(const BigInter &x, const BigInter &y)
    {
        return x < y || x == y;
    }
    friend bool operator>=(const BigInter &x, const BigInter &y)
    {
        return x > y || x == y;
    }
    friend BigInter operator+(const BigInter &x, BigInter y)
    {
        BigInter res = x;
        int more = 0;
        for (int i = 1; i <= (x.len > y.len ? x.len : y.len) + 1; i++)
        {
            res.vis(i);
            y.vis(i);
            res.num[i] += y.num[i] + more;
            if (res.num[i] >= 10)
            {
                res.num[i] -= 10;
                more = 1;
            }
            else
            {
                more = 0;
            }
        }
        res.len = x.len > y.len ? x.len : y.len + 1;
        res.format();
        return res;
    }
    friend BigInter operator+(const BigInter &x, const int &y)
    {
        BigInter tmp;
        tmp = y;
        return x + tmp;
    }
    friend BigInter operator-(const BigInter &x, BigInter y)
    {
        BigInter res = x;
        int less = 0;
        for (int i = 1; i <= x.len; i++)
        {
            res.vis(i);
            y.vis(i);
            res.num[i] -= y.num[i] + less;
            if (res.num[i] < 0)
            {
                res.num[i] += 10;
                less = 1;
            }
            else
            {
                less = 0;
            }
        }
        res.format();
        return res;
    }
    friend BigInter operator*(const BigInter &x, const BigInter &y)
    {
        BigInter res;
        res.len = x.len + y.len;
        for (int i = 1; i <= x.len; i++)
        {
            for (int j = 1; j <= y.len; j++)
            {
                res.vis(i + j - 1);
                res.num[i + j - 1] += x.num[i] * y.num[j];
            }
        }
        res.format();
        return res;
    }
    friend BigInter operator*(const BigInter &x, const int &y)
    {
        BigInter tmp;
        tmp = y;
        return x * tmp;
    }
    void operator*=(int x)
    {
        BigInter tmp;
        tmp = x;
        (*this) = (*this) * tmp;
    }
    friend BigInter operator/(const BigInter &x, const BigInter &y)
    {
        BigInter res;
        BigInter add;
        BigInter t = x;
        BigInter k = y;
        add = 1;
        for (; k * 10 <= t;)
        {
            k *= 10;
            add *= 10;
        }
        for (; t >= y;)
        {
            for (; k > t;)
            {
                k.dev10();
                add.dev10();
            }
            res = res + add;
            t = t - k;
        }
        res.format();
        return res;
    }
    friend BigInter operator/(const BigInter &x, const int &y)
    {
        BigInter tmp;
        tmp = y;
        return x / y;
    }
    friend BigInter operator%(const BigInter &x, const BigInter &y)
    {
        return x - (x / y) * y;
    }
    friend BigInter operator%(const BigInter &x, const int &y)
    {
        BigInter tmp;
        tmp = y;
        return x % y;
    }
};
BigInter n, k;
BigInter answer;
int main()
{
    freopen("t2.in", "r", stdin);
    freopen("t2.out", "w", stdout);
    n.in();
    k.in();
    for (; n >= k;)
    {
        BigInter tmp = n / k;
        answer = answer + tmp;
        n = n % k + tmp;
    }
    if (n + 1 == k)
    {
        answer = answer + 1;
    }
    answer.out();
    return 0;
}