#include<bits/stdc++.h>
using namespace std;
long long n,k;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	cout<<n/(k-1);
	return 0;
} 
