#include<bits/stdc++.h>
using namespace std;
long long n,m,k,d,x,y,sl=0;
long long a[500005];
long long hhhh=1;
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%lld %lld %lld %lld",&n,&m,&k,&d);
	sl=k*(d+1);
	for(int i=1;i<=m;i++){
		scanf("%lld %lld",&x,&y);
		if(y<0){
			if(a[x]+y<0)a[x]=0;
			else a[x]+=y;
			cout<<"YES";
		}
		else{
			a[x]+=y;
			long long cd=a[x];
			long long minn=max(hhhh,x-d);
			long long maxn=min(n,x+d),ans=a[x];
			long long sum1=0,sum2=0;
			for(int j=1;j<x;j++){
				long long sb=a[j]+sum1;
				if(sb>k)sum1=sum2+sb-k;
			}
			for(int j=x+1;j<=n;j++){
				long long sb=a[j]+sum2;
				if(sb>k)sum2=sum2+sb-k;
			}
			ans+=sum1;
			ans+=sum2;
			if(ans<=sl)cout<<"YES"<<endl;
			else{
				cout<<"NO"<<endl; 
				a[x]=cd;
			}
		}
	}
	return 0;
} 
