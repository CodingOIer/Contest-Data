#include<bits/stdc++.h>
using namespace std;
long long n,k;
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	scanf("%lld",&n);
	cout<<n;
	return 0;
} 
