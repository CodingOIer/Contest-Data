#include<bits/stdc++.h>
using namespace std;
long long n;
const long long Mod=998244353;
long long ans=1;
int main(){
	//freopen("t3.in","r",stdin);
	//freopen("t3.out","w",stdout);
	n=20;
	for(int i=1;i<=n;i++) ans=ans*i%Mod;
	
		for(int i=1;i<=n-1;i++)
			for(int j=i+1;j<=n;j++)
			ans=ans*(i+j)%Mod; 
			
				for(int i=1;i<=n-2;i++)
					for(int j=i+1;j<=n-1;j++)
						for(int k=j+1;k<=n;k++)
							ans=ans*(i+j+k)%Mod;
							
							for(int i=1;i<=n-3;i++)
								for(int j=i+1;j<=n-2;j++)
									for(int k=j+1;k<=n-1;k++)
										for(int kk=k+1;kk<=n;kk++)
										ans=ans*(i+j+k+kk)%Mod;
										
								for(int i=1;i<=n-4;i++)
								for(int j=i+1;j<=n-3;j++)
									for(int k=j+1;k<=n-2;k++)
										for(int kk=k+1;kk<=n-1;kk++)
										for(int kkk=kk+1;kkk<=n;kkk++)
										ans=ans*(i+j+k+kk+kkk)%Mod;
								
								for(int i=1;i<=n-5;i++)
								for(int j=i+1;j<=n-4;j++)
									for(int k=j+1;k<=n-3;k++)
										for(int kk=k+1;kk<=n-2;kk++)
										for(int kkk=kk+1;kkk<=n-1;kkk++)
										for(int kkkk=kkk+1;kkkk<=n;kkkk++)
										ans=ans*(i+j+k+kk+kkk+kkkk)%Mod;
										
							for(int i=1;i<=n-6;i++)
								for(int j=i+1;j<=n-5;j++)
									for(int k=j+1;k<=n-4;k++)
										for(int kk=k+1;kk<=n-3;kk++)
										for(int kkk=kk+1;kkk<=n-2;kkk++)
										for(int kkkk=kkk+1;kkkk<=n-1;kkkk++)
										for(int kkkkk=kkkk+1;kkkkk<=n;kkkkk++)
										ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk)%Mod;
										
										for(int i=1;i<=n-7;i++)
											for(int j=i+1;j<=n-6;j++)
												for(int k=j+1;k<=n-5;k++)
													for(int kk=k+1;kk<=n-4;kk++)
														for(int kkk=kk+1;kkk<=n-3;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-2;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-1;kkkkk++)
																for(int sb=kkkkk+1;sb<=n;sb++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb)%Mod;
																
							for(int i=1;i<=n-8;i++)
											for(int j=i+1;j<=n-7;j++)
												for(int k=j+1;k<=n-6;k++)
													for(int kk=k+1;kk<=n-5;kk++)
														for(int kkk=kk+1;kkk<=n-4;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-3;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-2;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-1;sb++)
																for(int sbb=sb+1;sbb<=n;sbb++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb)%Mod;
						
						
						for(int i=1;i<=n-9;i++)
											for(int j=i+1;j<=n-8;j++)
												for(int k=j+1;k<=n-7;k++)
													for(int kk=k+1;kk<=n-6;kk++)
														for(int kkk=kk+1;kkk<=n-5;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-4;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-3;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-2;sb++)
																for(int sbb=sb+1;sbb<=n-1;sbb++)
																for(int lc=sbb+1;lc<=n;lc++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc)%Mod;
																
										for(int i=1;i<=n-10;i++)
											for(int j=i+1;j<=n-9;j++)
												for(int k=j+1;k<=n-8;k++)
													for(int kk=k+1;kk<=n-7;kk++)
														for(int kkk=kk+1;kkk<=n-6;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-5;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-4;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-3;sb++)
																for(int sbb=sb+1;sbb<=n-2;sbb++)
																for(int lc=sbb+1;lc<=n-1;lc++)
																for(int lcc=lc+1;lcc<=n;lcc++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc)%Mod;
																
								for(int i=1;i<=n-11;i++)
											for(int j=i+1;j<=n-10;j++)
												for(int k=j+1;k<=n-9;k++)
													for(int kk=k+1;kk<=n-8;kk++)
														for(int kkk=kk+1;kkk<=n-7;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-6;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-5;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-4;sb++)
																for(int sbb=sb+1;sbb<=n-3;sbb++)
																for(int lc=sbb+1;lc<=n-2;lc++)
																for(int lcc=lc+1;lcc<=n-1;lcc++)
																for(int lccc=lcc+1;lccc<=n;lccc++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc)%Mod;
								
								for(int i=1;i<=n-12;i++)
											for(int j=i+1;j<=n-11;j++)
												for(int k=j+1;k<=n-10;k++)
													for(int kk=k+1;kk<=n-9;kk++)
														for(int kkk=kk+1;kkk<=n-8;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-7;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-6;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-5;sb++)
																for(int sbb=sb+1;sbb<=n-4;sbb++)
																for(int lc=sbb+1;lc<=n-3;lc++)
																for(int lcc=lc+1;lcc<=n-2;lcc++)
																for(int lccc=lcc+1;lccc<=n-1;lccc++)
																for(int db=lccc+1;db<=n;db++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db)%Mod;
																
										for(int i=1;i<=n-13;i++)
											for(int j=i+1;j<=n-12;j++)
												for(int k=j+1;k<=n-11;k++)
													for(int kk=k+1;kk<=n-10;kk++)
														for(int kkk=kk+1;kkk<=n-9;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-8;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-7;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-6;sb++)
																for(int sbb=sb+1;sbb<=n-5;sbb++)
																for(int lc=sbb+1;lc<=n-4;lc++)
																for(int lcc=lc+1;lcc<=n-3;lcc++)
																for(int lccc=lcc+1;lccc<=n-2;lccc++)
																for(int db=lccc+1;db<=n-1;db++)
																for(int nm=db+1;nm<=n;nm++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm)%Mod;
									
									for(int i=1;i<=n-14;i++)
											for(int j=i+1;j<=n-13;j++)
												for(int k=j+1;k<=n-12;k++)
													for(int kk=k+1;kk<=n-11;kk++)
														for(int kkk=kk+1;kkk<=n-10;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-9;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-8;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-7;sb++)
																for(int sbb=sb+1;sbb<=n-6;sbb++)
																for(int lc=sbb+1;lc<=n-5;lc++)
																for(int lcc=lc+1;lcc<=n-4;lcc++)
																for(int lccc=lcc+1;lccc<=n-3;lccc++)
																for(int db=lccc+1;db<=n-2;db++)
																for(int nm=db+1;nm<=n-1;nm++)
																for(int bx=nm+1;bx<=n;bx++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx)%Mod;
								
								for(int i=1;i<=n-15;i++)
											for(int j=i+1;j<=n-14;j++)
												for(int k=j+1;k<=n-13;k++)
													for(int kk=k+1;kk<=n-12;kk++)
														for(int kkk=kk+1;kkk<=n-11;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-10;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-9;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-8;sb++)
																for(int sbb=sb+1;sbb<=n-7;sbb++)
																for(int lc=sbb+1;lc<=n-6;lc++)
																for(int lcc=lc+1;lcc<=n-5;lcc++)
																for(int lccc=lcc+1;lccc<=n-4;lccc++)
																for(int db=lccc+1;db<=n-3;db++)
																for(int nm=db+1;nm<=n-2;nm++)
																for(int bx=nm+1;bx<=n-1;bx++)
																for(int zzs=bx+1;zzs<=n;zzs++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx+zzs)%Mod;
																
									for(int i=1;i<=n-16;i++)
											for(int j=i+1;j<=n-15;j++)
												for(int k=j+1;k<=n-14;k++)
													for(int kk=k+1;kk<=n-13;kk++)
														for(int kkk=kk+1;kkk<=n-12;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-11;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-10;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-9;sb++)
																for(int sbb=sb+1;sbb<=n-8;sbb++)
																for(int lc=sbb+1;lc<=n-7;lc++)
																for(int lcc=lc+1;lcc<=n-6;lcc++)
																for(int lccc=lcc+1;lccc<=n-5;lccc++)
																for(int db=lccc+1;db<=n-4;db++)
																for(int nm=db+1;nm<=n-3;nm++)
																for(int bx=nm+1;bx<=n-2;bx++)
																for(int zzs=bx+1;zzs<=n-1;zzs++)
																for(int lj=zzs+1;lj<=n;lj++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx+zzs+lj)%Mod;
																
									for(int i=1;i<=n-17;i++)
											for(int j=i+1;j<=n-16;j++)
												for(int k=j+1;k<=n-15;k++)
													for(int kk=k+1;kk<=n-14;kk++)
														for(int kkk=kk+1;kkk<=n-13;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-12;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-11;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-10;sb++)
																for(int sbb=sb+1;sbb<=n-9;sbb++)
																for(int lc=sbb+1;lc<=n-8;lc++)
																for(int lcc=lc+1;lcc<=n-7;lcc++)
																for(int lccc=lcc+1;lccc<=n-6;lccc++)
																for(int db=lccc+1;db<=n-5;db++)
																for(int nm=db+1;nm<=n-4;nm++)
																for(int bx=nm+1;bx<=n-3;bx++)
																for(int zzs=bx+1;zzs<=n-2;zzs++)
																for(int lj=zzs+1;lj<=n-1;lj++)
																for(int wtf=lj+1;wtf<=n;wtf++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx+zzs+lj+wtf)%Mod;
																
							for(int i=1;i<=n-18;i++)
											for(int j=i+1;j<=n-17;j++)
												for(int k=j+1;k<=n-16;k++)
													for(int kk=k+1;kk<=n-15;kk++)
														for(int kkk=kk+1;kkk<=n-14;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-13;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-12;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-11;sb++)
																for(int sbb=sb+1;sbb<=n-10;sbb++)
																for(int lc=sbb+1;lc<=n-9;lc++)
																for(int lcc=lc+1;lcc<=n-8;lcc++)
																for(int lccc=lcc+1;lccc<=n-7;lccc++)
																for(int db=lccc+1;db<=n-6;db++)
																for(int nm=db+1;nm<=n-5;nm++)
																for(int bx=nm+1;bx<=n-4;bx++)
																for(int zzs=bx+1;zzs<=n-3;zzs++)
																for(int lj=zzs+1;lj<=n-2;lj++)
																for(int wtf=lj+1;wtf<=n-1;wtf++)
																for(int zy=wtf+1;zy<=n;zy++) 
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx+zzs+lj+wtf+zy)%Mod;
				
				
									for(int i=1;i<=n-19;i++)
											for(int j=i+1;j<=n-18;j++)
												for(int k=j+1;k<=n-17;k++)
													for(int kk=k+1;kk<=n-16;kk++)
														for(int kkk=kk+1;kkk<=n-15;kkk++)
															for(int kkkk=kkk+1;kkkk<=n-14;kkkk++)
																for(int kkkkk=kkkk+1;kkkkk<=n-13;kkkkk++)
																for(int sb=kkkkk+1;sb<=n-12;sb++)
																for(int sbb=sb+1;sbb<=n-11;sbb++)
																for(int lc=sbb+1;lc<=n-10;lc++)
																for(int lcc=lc+1;lcc<=n-9;lcc++)
																for(int lccc=lcc+1;lccc<=n-8;lccc++)
																for(int db=lccc+1;db<=n-7;db++)
																for(int nm=db+1;nm<=n-6;nm++)
																for(int bx=nm+1;bx<=n-5;bx++)
																for(int zzs=bx+1;zzs<=n-4;zzs++)
																for(int lj=zzs+1;lj<=n-3;lj++)
																for(int wtf=lj+1;wtf<=n-2;wtf++)
																for(int zy=wtf+1;zy<=n-1;zy++) 
																for(int yc=zy+1;yc<=n;yc++)
																ans=ans*(i+j+k+kk+kkk+kkkk+kkkkk+sb+sbb+lc+lcc+lccc+db+nm+bx+zzs+lj+wtf+zy+yc)%Mod;
																
																
	cout<<ans;
	return 0;
} 
/*
998244353
�һ���ȫ������֪������˵ĸ��ࡣ���������� 
*/
