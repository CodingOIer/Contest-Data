#include<bits/stdc++.h>
using namespace std;
int n,k;
int t[100005],v[100005];
long long ans=0;
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",&t[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&v[i]);
	}
	sort(v+1,v+n+1);
	long long j=n;
	for(int i=1;i<=k;i++){
		ans+=v[j];
		j--;
	}
	cout<<ans;
	return 0;
} 
