#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
const int MX = 1e5 + 10;
struct sky {
	ll t, v, id;
} a[MX], b[MX];
bool id[MX];
bool cmp(sky &a, sky &b) {
	return a.t < b.t;
}
bool cmp2(sky &a, sky &b) {
	return a.v > b.v;
}
ll mv = 0;
int main() {
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout);
	int n = read(), k = read();
	FOR(i, 1, n) a[i].t = read(), b[i].t = a[i].t, b[i].id = a[i].id = i;
	FOR(i, 1, n) a[i].v = read(), b[i].v = a[i].v, mv = max(mv, a[i].v);
	sort(a + 1, a + n + 1, cmp);
	sort(b + 1, b + n + 1, cmp2);
	int la = 1, lb = 1;
	ll ans = 0, h = 0;
	FOR(i, 0, mv) {
		while (a[la].t <= i && la < n) id[a[la].id] = 1, la++;
		while (id[b[lb].id] && lb < n)  lb++;
		ans += b[lb].v;
		id[b[lb].id] = 1;
		h++;
		if (k == h) break;
	}
	cout << ans;
	return 0;
}
