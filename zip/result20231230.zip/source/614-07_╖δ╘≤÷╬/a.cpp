#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
int main() {
	return 0;
}
