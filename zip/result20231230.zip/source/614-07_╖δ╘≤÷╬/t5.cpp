#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
const int MX = 505;
const int mod = 1e9 + 7;
ll f[MX];
ll ksm(int x, int y) {
	ll base = x, sum = 1;
	while (y) {
		if (y & 1) sum = (sum * base) % mod;
		base = (base * base) % mod;
		y /= 2;
	}
	return sum;
}
int getl(string x, int st) {
	int t = 0;
	FOR(i, st, x.size() - 1) if (x[i] == '?') t++;
	else return t;
	return t;
}
int main() {
	int n = read();
	string s;
	cin >> s;
	FOR(i, 1, n) f[i] = (ksm(2, i) + ((i >= 3) * ksm(2, i / 3) * ksm(2, i / 3 - 1) * ksm(2, i % 3))) % mod;
	cout << f[n] << " ";
	cout << endl;
//	ll ans = 1;
//	FOR(i, 0, s.size() - 1) {
//		if (s[i] == '?') {
//			int l = getl(s, i);
//			ans *= f[l];
//			i += (l + 1);
//		} else {
//			ans *= gets(s, i);
//		}
//	}
//	cout << f[n] << " ";
	return 0;
}
