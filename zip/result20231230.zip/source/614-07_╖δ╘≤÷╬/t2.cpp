#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
const ll jie = 1e18;
int main() {
//	ll n = read(), k = read();
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	string s;
	cin >> s;
	ll k = read();
	if (s.size() <= 19) {
		ll ans = 0;
		ll n = 0;
		FOR(i, 0, s.size() - 1) n = (n << 1) + (n << 3) + s[i] - 48;
		while (n >= k) {
			ll ge = n / k;
			n = ge + (n - ge * k);
			ans += ge;
		}
		cout << ans + (n == k - 1);
	} else {

	}
	return 0;
}
//10**100000!? �����õ�������ͳ�!?
