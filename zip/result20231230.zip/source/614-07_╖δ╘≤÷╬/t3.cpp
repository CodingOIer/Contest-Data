#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
ll vis[1000000];
const int mod = 998244353;
ll ksm(ll x, ll y) {
	ll base = x, sum = 1;
	while (y) {
		if (y & 1) {
			sum = (sum * base) % mod;
			y--;
		}
		base = (base * base) % mod;
		y /= 2;
	}
	return sum;
}
int main() {
	freopen("t3.in", "r", stdin);
	freopen("t3.out", "w", stdout);
	ll n = read();
	ll mx = 0;
	FOR(i, 1, n) {
		ROF(j, mx, 1) vis[i + j] = (vis[i + j] + vis[j]) % (mod - 1);
		vis[i] = (vis[i] + 1) % (mod - 1);
		mx = i + mx;
	}
	ll ans = 1;
	FOR(i, 1, n * (n + 1) / 2)  ans = (ans * max(1ll, ksm(i, vis[i]))) % mod;
	cout << ans;
	return 0;
}
