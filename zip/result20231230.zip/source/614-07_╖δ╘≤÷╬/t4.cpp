#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
//
//
//
using namespace std;
inline ll read() {
	ll f = 0, sum = 0;
	char c = getchar();
	while (!isdigit(c)) f = (c == '-'), c = getchar();
	while (isdigit(c)) sum = (sum << 1) + (sum << 3) + c - 48, c = getchar();
	return f ? -sum : sum;
}
const int MX = 5e5 + 10;
struct sky {
	ll p, w;
} a[MX], b[MX];
bool cmp(sky &a, sky &b) {
	return a.p < b.p;
}
ll tmp[MX];
int main() {
	freopen("t4.in", "r", stdin);
	freopen("t4.out", "w", stdout);
	int n = read(), m = read(), k = read(), d = read();
	FOR(i, 1, m) {
		a[i].p = read(), a[i].w = read();
		sort(a + 1, a + i + 1, cmp);
		int top = 0;
		FOR(j, 1, i) {
			if (a[j].p == b[top].p) b[top].w += a[j].w;
			else b[++top].w = a[j].w, b[top].p = a[j].p;
		}
		FOR(j, 1, n) tmp[j] = k;
		bool flag = 0;
		FOR(j, 1, top) {
			FOR(k, b[j].p, b[j].p + d) {
				if (b[j].w > tmp[k])  b[j].w -= tmp[k], tmp[k] = 0;
				else {
					tmp[k] = tmp[k] - b[j].w, b[j].w = 0;
					break;
				}
			}
			if (b[j].w != 0) {
				cout << "NO" << endl;
				flag = 1;
				break;
			}
		}
		if (!flag) cout << "YES" << endl;
	}

	return 0;
}
//���㱩��������ʦ�Ļ���˵��������300��
