#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,k,sum,cnt;
ll ans;
struct need{
	int v,t;
}a[100005];
int cmp(need x,need y){
	if(x.v==y.v) return x.t>y.t;
	else return x.v>y.v;
}
int cmp2(need x,need y){
	return x.t<y.t; 
}
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i].t);
	for(int i=1;i<=n;i++) scanf("%d",&a[i].v);
	sort(a+1,a+n+1,cmp);
	sort(a+1,a+k+1,cmp2);
	for(int i=1;i<=k;i++)
	{
		if(a[i].t<cnt) sum++;
		else ans+=a[i].v,cnt++;
	}
	for(int i=k+1;i<=n;i++)
	{
		if(sum==0) break;
		if(a[i].t>=cnt) sum--,ans+=a[i].v,cnt++;
	}
	printf("%lld",ans); 
	return 0;
}
