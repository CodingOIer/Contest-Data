#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll ans,sum;
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>s;
	cout<<s.size()*s.size()+1;
	return 0;
}
