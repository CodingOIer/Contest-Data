#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k,ans,sum;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	while(n>=k)
	{
		sum=n/k;
		ans+=sum; n=n%k+sum;
	}
	if(n==k-1) ans++;
	printf("%lld",ans);
	return 0;
}
/*
ans         n         k 
ans=n/k   n=n%k+ans   k 
if(n<k-1) cout;
if(n==k-1) ans++,cout;
if(n>k) ����; 
*/
