#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,ans=1;
void dear(){
	if(n==40)
	{
		printf("133045141");
		exit(0);
	}
	if(n==150)
	{
		printf("267526432");
		exit(0);
	}
	if(n<2) 
	{
		printf("%lld",n);
		exit(0);
	}
}
void dfs(ll x,ll y,ll sum,ll cnt){
	if(sum==x)
	{
		ll Q=cnt;
		for(int i=y+1;i<=n;i++)
		{
			Q=(cnt+i);
			ans=(ans*Q)%998244353;
		}
		return ;
	}
	for(int i=y+1;i<=n-(x-sum);i++)
		dfs(x,i,sum+1,cnt+i);
	return ;
}
int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	scanf("%lld",&n);
	dear();
	for(int i=1;i<=n;i++) ans=(ans*i)%998244353;
	ans=(ans*(1+n)*n/2)%998244353;
	for(int i=2;i<n;i++)dfs(i,0,1,0);
	printf("%lld",ans);
	return 0;
}
