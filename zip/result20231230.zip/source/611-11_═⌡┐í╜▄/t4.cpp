#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,k,d,x,y,g[500005],a[500005];
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&d);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		if(y>0)
		{
			for(int i=x;i<=x+d;i++)
			{
				if(k-g[i]<y) y-=(k-g[i]),a[i]=g[i],g[i]=k;
				else
				{
					g[i]+=y;y=0;
					break;
				}
			}
			if(y>0)
			{
				for(int i=x;i<=x+d;i++) g[i]=a[i];
				printf("NO\n");
			}
			else printf("YES\n");
		}
		else 
		{
			y=abs(y);
			for(int i=x;i<=x+d;i++)
			{
				if(g[i]<y) y-=g[i],a[i]=g[i],g[i]=0;
				else
				{
					g[i]-=y;
					y=0;
					break;
				}
			}
			if(y>0)
			{
				for(int i=x;i<=x+d;i++) g[i]=a[i];
				printf("NO\n");
			}
			else printf("YES\n");
		}
	}
	return 0;
}
