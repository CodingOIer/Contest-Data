#include<bits/stdc++.h>
using namespace std;
long long read()
{
	long long tmp;
	cin>>tmp;
	return tmp;
}
bool cmp(long long a,long long b)
{
	return a>b;
}
long long n,k,ans,v[100005],t[100005];
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++)
		t[i]=read();
	for(int i=1;i<=n;i++)
		v[i]=read();
	sort(v+1,v+n+1,cmp);
	for(int i=1;i<=k;i++)
		ans+=v[i];
	cout<<ans;
}

