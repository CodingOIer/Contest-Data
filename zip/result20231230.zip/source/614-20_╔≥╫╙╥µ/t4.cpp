#include<bits/stdc++.h>
using namespace std;
long long read()
{
	long long tmp;
	cin>>tmp;
	return tmp;
}
long long n,m,k,d;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=m;i++)
	{
		long long x,y;
		cin>>x>>y;
		cout<<"YES\n";
	}
}
