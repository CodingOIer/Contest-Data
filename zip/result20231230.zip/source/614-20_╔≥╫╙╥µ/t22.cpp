#include<bits/stdc++.h>
using namespace std;
long long read()
{
	long long tmp;
	cin>>tmp;
	return tmp;
}
long long n,k,ans,l;
int main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	for(int i=1;i<=100;i++)
	{
		n=i,k=7;
		ans=n/(k-1);
		cout<<ans<<"\n";
	}
}
