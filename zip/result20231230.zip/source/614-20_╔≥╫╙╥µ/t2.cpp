#include<bits/stdc++.h>
using namespace std;
long long read()
{
	long long tmp;
	cin>>tmp;
	return tmp;
}
long long n,k,l;
string s;
string q(string a,long long b)
{
	long long data=0;
	bool t;
	string ans="";
	for(long long i=0;i<s.size();i++)
	{
		data*=10;
		data+=s[i]-'0';
		if(data>=k)
		{
			ans+=(data/k+'0');
			data%=k;
			t=1;
		}
		else if(t)
			ans+='0';	
	}
	return ans;
}
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s;
	k=read();
	k--;
	cout<<q(s,k);
}
