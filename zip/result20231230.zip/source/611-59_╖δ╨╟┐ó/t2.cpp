#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
char ch[N];
int a[N], ans[N], le;
int n, k;

void div(){
	int ret[N], st = 0;
	long long sum = 0;
	memset (ret, 0, sizeof ret);
	
	for (int i = n; i >= 1; --i){
		sum *= 10;
		sum += a[i];
		
		if (sum >= k){
			if (st == 0) st = i;
			ret[i] = sum / k;
			sum %= k;
		}
	}
	
	for (int i = 1; i <= st; ++i) {
		ans[i] += ret[i];
		ans[i+1] += ans[i] / 10;
		ans[i] %= 10;
	}
	
	for (; ans[le+1] != 0; ++le);
	
	int t = 1;
	while (sum) {
		ret[t++] += sum % 10;
		sum /= 10;
	}
	
	for (int i = 1; i <= st; ++i){
		ret[i+1] += ret[i] / 10;
		ret[i] %= 10;
	}
	if (ret[st+1]) st++;
	
	for (int i = n; i >= 1; --i) a[i] = ret[i];
	n = st;
} 

bool check() {
	int c[N], sum = 0;
	memset (c, 0, sizeof c);
	
	int kt = k;
	while (kt) {
		c[++sum] = kt % 10;
		kt /= 10;
	}
	
	if (sum < n) return true;
	else if (sum > n) return false;
	
	for (int i = n; i >= 1; --i) {
		if (a[i] > c[i]) return true;
		else if (a[i] < c[i]) return false;
	}
	return true;
}

bool isk(){
	a[1]++;
	for (int i = 1; i <= n; ++i) {
		a[i+1] = a[i] / 10;
		a[i] %= 10;
	}
	if (a[n+1]) n++;
	
	int c[N], sum = 0;
	memset (c, 0, sizeof c);
	
	int kt = k;
	while (kt) {
		c[++sum] = kt % 10;
		kt /= 10;
	}
	
	if (sum != n) return false;
	for (int i = n; i >= 1; --i) if (a[i] != c[i]) return false;
	return true;
}

int main(){
	freopen ("t2.in", "r", stdin);
	freopen ("t2.out", "w", stdout);
		
	scanf ("%s %d", ch, &k);
	n = strlen(ch);
	for (int i = 0; i < n; ++i) a[n - i] = ch[i] - '0';
	
	while (check()) {
		div();
	}
	
	if (isk()) {
		ans[1]++;
		if (le == 0) le = 1;
	}
	
	for (int i = le; i >= 1; --i) printf ("%d", ans[i]);
	if (le == 0) printf ("0");
	
	return 0;
}

