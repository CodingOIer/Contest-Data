#include <bits/stdc++.h>
using namespace std;

const int N = 5e5 + 5;
int n, m, k, d;
long long a[N], use[N];

int main(){
	freopen ("t4.in", "r", stdin);
	freopen ("t4.out", "w", stdout);

	scanf ("%d%d%d%d", &n, &m, &k, &d);
	while (m--){
		int x, y;
		scanf ("%d%d", &x, &y);
		
		a[x] += y;
		memset (use, 0, sizeof use);
		bool flag = true;
		for (int j = 1; j <= x - d; ++j){
			if (a[j] == 0) continue;
			y = a[j];
			
			for (int i = x; i <= x + d; ++i) {
				if (k - use[i] < y) {
					y -= k - use[i];
					use[i] = k;
				}
				else {
					y = 0;
					use[i] += y;
				}
			}
			if (y != 0) {
				printf ("NO\n");
				flag = false;
				break;
			}
		}
		if (flag) printf ("YES\n");
	}
	
	return 0;
}

