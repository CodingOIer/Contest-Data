#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
int n, k;
struct coin{
	int t;
	int w;
}a[N];
int mx[N];
long long ans;

bool cmp(coin x, coin y) {return x.t < y.t;}

int main(){
	freopen ("t1.in", "r", stdin);
	freopen ("t1.out", "w", stdout);

	scanf ("%d%d", &n, &k);
	for (int i = 1; i <= n; ++i) scanf ("%d", &a[i].t);
	for (int i = 1; i <= n; ++i) scanf ("%d", &a[i].w);
	
	sort (a + 1, a + n + 1, cmp);
	
	for (int i = n; i >= 1; --i) mx[i] = max(mx[i+1], a[i].w);
	
	for (int i = 1; i <= k; ++i) ans += mx[i];
	
	printf ("%lld", ans);
	
	
	return 0;
}

