#include <bits/stdc++.h>
using namespace std;

const int mod = 998244353;
const int M = 2e2 + 5;

int n;
unsigned long long inv[M];
vector <unsigned long long> a;

int main() {
	freopen ("t3.in", "r", stdin);
	freopen ("t3.out", "w", stdout);
	
	scanf ("%d", &n);
	
	if (n == 1) {
		printf ("1");
		exit(0);
	} 
	
	inv[0] = 1;
	for (int i = 1; i <= n; ++i) inv[i] = inv[i-1] * i % mod;
	
	for (int i = 2; i <= n; ++i) {
		int t = a.size();
		for (int j = 0; j < t; ++j) a.push_back(a[j] + i);
		for (int j = 1; j < i; ++j) a.push_back(j + i);
	}
	
	int t = a.size();
	unsigned long long ans = 1;	
	for (int i = 0; i < t; ++i) ans = ans * a[i] % mod;
	printf ("\n%llu", ans * inv[n] % mod);
	
	
	return 0;
}

