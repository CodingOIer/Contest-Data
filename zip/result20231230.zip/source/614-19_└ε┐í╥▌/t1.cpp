#include <iostream>
#include <algorithm>
#include <utility>
#include <queue>
#define int long long
#define t first
#define v second
using namespace std;
inline int read()
{
    int ans = 0, f = 0;
    char c = getchar();
    while (!isdigit(c))
        f |= (c == '-'), c = getchar();
    while (isdigit(c))
        ans = (ans << 3) + (ans << 1) + c - 48, c = getchar();
    return f ? -ans : ans;
}
void write(int x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(48 + x % 10);
}
const int N = 1e5 + 5;
int n, k;
pair<int, int> a[N];
priority_queue<int, vector<int>, greater<int>> q;
signed main()
{
    freopen("t1.in", "r", stdin);
    freopen("t1.out", "w", stdout);
    n = read(), k = read();
    for (int i = 1; i <= n; ++i)
        a[i].t = read();
    for (int i = 1; i <= n; ++i)
        a[i].v = read();
    sort(a + 1, a + n + 1);
    for (int i = 1; i <= n; ++i)
    {
        if (q.size() < k)
            q.push(a[i].v);
        else if (q.top() < a[i].v)
        {
            q.pop();
            q.push(a[i].v);
        }
    }
    int ans = 0;
    while (!q.empty())
    {
        ans += q.top();
        q.pop();
    }
    write(ans);
    return 0;
}