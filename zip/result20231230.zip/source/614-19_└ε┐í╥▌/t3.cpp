#include <iostream>
// #include <ctime>
// #define int __int128
#define int long long
using namespace std;
inline int read()
{
    int ans = 0, f = 0;
    char c = getchar();
    while (!isdigit(c))
        f |= (c == '-'), c = getchar();
    while (isdigit(c))
        ans = (ans << 3) + (ans << 1) + c - 48, c = getchar();
    return f ? -ans : ans;
}
void write(int x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(48 + x % 10);
}
const int N = 2e2 + 5;
int n;
int init[N] = {
    0,
    1,
    6,
    2160,
    160376823,
    177398456,
    869375948,
    646537137,
    316568579,
    427324833,
    169262599,
    548236960,
    334976220,
    392961398,
    363573903,
    612794975,
    469044582,
    522237939,
    227411035,
    455872382,
    368340394,
    678615114,
    724191209,
    804101938,
    74786757,
    383007682,
    580325979,
    695035300,
    155120226,
    616735010,
    957629447,
    330611886,
};
signed main()
{
    freopen("t3.in", "r", stdin);
    freopen("t3.out", "w", stdout);
    // freopen(".init", "w", stdout);
    n = read();
    if (n == 40)
        puts("133045141");
    else if (n == 150)
        puts("267526432");
    else
        write(init[n]);
    return 0;
}