#include <iostream>
#define int __int128
using namespace std;
inline int read()
{
    int ans = 0, f = 0;
    char c = getchar();
    while (!isdigit(c))
        f |= (c == '-'), c = getchar();
    while (isdigit(c))
        ans = (ans << 3) + (ans << 1) + c - 48, c = getchar();
    return f ? -ans : ans;
}
void write(int x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(48 + x % 10);
}
int n, k, ans;
signed main()
{
    freopen("t2.in", "r", stdin);
    freopen("t2.out", "w", stdout);
    n = read(), k = read();
    while (n / k)
    {
        ans += n / k;
        n = n % k + n / k;
    }
    if (n + (__int128)1 == k)
        ++ans;
    write(ans);
    return 0;
}