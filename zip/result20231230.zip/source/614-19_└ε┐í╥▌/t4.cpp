#include <iostream>
#include <utility>
#include <queue>
using namespace std;
inline int read()
{
    int ans = 0, f = 0;
    char c = getchar();
    while (!isdigit(c))
        f |= (c == '-'), c = getchar();
    while (isdigit(c))
        ans = (ans << 3) + (ans << 1) + c - 48, c = getchar();
    return f ? -ans : ans;
}
void write(int x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(48 + x % 10);
}
const int N = 2e3 + 5;
int n, m, k, d, used[N];
priority_queue<int> q[N], p[N];
inline int check(int x)
{
    int cnt = 0;
    for (int i = x; i <= x + d && i <= n; ++i)
        cnt += k - q[i].size();
    return cnt;
}
inline int forward(int l, int r)
{
    int _r = r;
    while (r >= l)
    {
        if (p[r].size() < k)
        {
            p[r].push(_r - r);
            return 1;
        }
        --r;
    }
    return 0;
}
inline void init()
{
    for (int i = 1; i <= n; ++i)
        p[i] = q[i];
}
inline void save()
{
    for (int i = 1; i <= n; ++i)
        q[i] = p[i];
}
signed main()
{
    freopen("t4.in", "r", stdin);
    freopen("t4.out", "w", stdout);
    n = read(), m = read(), k = read(), d = read();
    while (m--)
    {
        int x = read(), y = read();
        if (y < 0)
        {
            while (y < 0 && !q[x].empty())
                q[x].pop(), ++y;
            puts("YES");
        }
        else
        {
            if (check(x) >= y)
            {
                for (int i = x; i <= x + d && i <= n; ++i)
                    while (y && q[i].size() < k)
                        q[i].push(x + d - i), --y;
                puts("YES");
            }
            else
            {
                init();
                int need = y - check(x);
                for (int i = x; i <= x + d && i <= n && need; ++i)
                    while (need && !p[i].empty() && forward(i + 1, i + p[i].top()))
                        p[i].pop(), --need;
                if (!need)
                {
                    for (int i = x; i <= x + d && i <= n; ++i)
                        while (y && p[i].size() < k)
                            p[i].push(x + d - i), --y;
                    save();
                    puts("YES");
                }
                else
                    puts("NO");
            }
        }
    }
    return 0;
}