#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=2e3+5;
int n,m,k,d,cnt;
int a[Max][Max];
bool pd(int x,int y){
	bool f=0;
	int cnt=0;
	for(int di=0;di<=d;di++){
		for(int i=1;i<=n;i++){
			if(x+di>k||cnt>=abs(y)){
				f=1;
				break; 
			}
			if(y>0){
				if(!a[i][x+di]) a[i][x+di]=x,cnt++;
				else if(pd(a[i][x+di],1)) a[i][x+di]=x,cnt++;
			}
			else if(a[i][x+di]&&y<0) a[i][x+di]=0,cnt++;
		}
		if(f) break;
	}
	return cnt>=abs(y);
}
signed main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	n=read(),m=read(),k=read(),d=read();
	while(m--){
		int x=read(),y=read();
		bool f=0;
		if(y>0){
			if(x!=1) f=1;
			else{
				if(cnt+y<=n) cnt+=y;
				else f=1;
			}
		}
		else cnt+=y;
		if(!f) puts("YES");
		else puts("NO");
	}
	return 0;
}

