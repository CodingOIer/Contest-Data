#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10); 
}

const int Max=1e3+5;
int n,k,ans;
struct node{
	int t,v;
}a[Max];
bool cmp(node a,node b){
	return a.v>b.v;
}
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++) a[i].t=read();
	for(int i=1;i<=n;i++) a[i].v=read();
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=k;i++) ans+=a[i].v;
	write(ans);
	return 0;
}
