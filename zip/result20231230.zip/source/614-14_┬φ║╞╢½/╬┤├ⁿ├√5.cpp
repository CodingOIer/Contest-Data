#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=1e5+5,mod=998244353;
int n,top,ans=1;
int a[Max];
void dfs(int x){
	if(x>n){
		if(!top) return ;
		int sum=0;
		for(int i=1;i<=top;i++) sum+=a[i];
		ans=(ans*sum)%mod;
		return ;
	}
	dfs(x+1);
	a[++top]=x;
	dfs(x+1);
	top--;
}
signed main(){
	//freopen("t3.in","r",stdin);
	//freopen("t3.out","w",stdout);
	n=read();
	int ans=pow(2*n,n);
	ans%=mod;
	write(ans/2%mod);
	return 0;
}

