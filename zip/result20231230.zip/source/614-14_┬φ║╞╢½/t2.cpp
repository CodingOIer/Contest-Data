#include<bits/stdc++.h>
#define int __int128
using namespace std;
inline int read(){
	int t=0,f=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}

void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar('0'+x%10);
}

const int Max=1e5+5;
int n,k,ans;
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	n=read(),k=read();
	while(n>=k){//n �� ƿ�� 
		int cnt=n/k;
		ans+=cnt;
		n=n%k+cnt;
	}
	if((n+1)==k) ans++;
	write(ans);
	return 0;
}
