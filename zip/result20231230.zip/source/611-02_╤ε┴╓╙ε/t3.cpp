#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
long long ans=1;
int n;
void dfs(int step,int sum){
	if(step==n+1){
		if(sum==0)return;
		ans=ans*sum%mod;
		return;
	}
	dfs(step+1,sum);
	dfs(step+1,sum+step);
}
int main(){
	//1*2*3
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	dfs(1,0);
	cout<<ans<<endl;
}
//dp[2][2]=dp[1][1]*2^0+2^1;
//(s1+i)*(s2+i)=i^0s1*s2+i(s1+s2)+i^2
//s1*s2*s3+is3(s1+s2)+s3i^2+is1*s2+i^2(s1+s2)+i^3
//i^0s1*s2*s3+i(s3*s1+s1*s2+s3*s2)+i^2(s1+s2+s3)+i^3
