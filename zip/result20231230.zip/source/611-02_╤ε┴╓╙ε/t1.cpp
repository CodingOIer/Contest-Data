#include<bits/stdc++.h>
using namespace std;
long long n,k,a[100005],Xiao7_Mr_10_;
long long ans;
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>Xiao7_Mr_10_;
	for(int i=1;i<=n;i++)cin>>a[i];
	sort(a+1,a+n+1);
	for(int i=n-k+1;i<=n;i++)ans+=a[i];
	cout<<ans<<endl;
	return 0;
} 
