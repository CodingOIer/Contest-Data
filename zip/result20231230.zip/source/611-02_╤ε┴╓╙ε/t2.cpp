#include<bits/stdc++.h>
using namespace std;
string str;
int k;
int siz,siz2=10000;
long long ans[10004];
long long a[10005];
long long pow10[20];
void print(long long x){
	if(10>x){
		cout<<x;
		return;
	}
	print(x/10);
	cout<<x%10;
}
int main(){
	pow10[0]=1;
	for(int i=1;i<=18;i++)pow10[i]=pow10[i-1]*10;
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>str>>k;
	int cnt=0;
	for(int i=str.size()-1;i>=0;i--){
		a[siz+1]+=pow10[cnt]*(str[i]-'0');
		cnt++;
		if(cnt==10){
			siz++;
			cnt=0;
		}
	}
	if(a[siz+1]!=0)siz++;
	if(siz<=2&&a[1]+a[2]*pow10[10]<=pow10[18]){
		unsigned long long ans=0;
		long long n=a[1]+a[2]*pow10[10];
		while(n>=k){
			ans+=n/k;
			n=n/k+n%k;
		}
		if(n==k-1)ans++;
		cout<<ans<<endl;
		return 0;
	}
	//cout<<a[siz]<<endl;
	while(siz>1||a[1]>=k){
		for(int i=siz;i>=2;i--){
			ans[i]+=a[i]/k;
			a[i-1]+=a[i]%k*pow10[10];
			a[i]/=k;
		}
		ans[1]+=a[1]/k;
		//cout<<a[1]/k<<endl;
		a[1]=a[1]/k+a[1]%k;
		
		if(a[siz]==0)siz--;
		for(int i=1;i<=max(siz2,siz);i++){
			ans[i+1]+=ans[i]/pow10[9];
			ans[i]%=pow10[9];
		}
		while(ans[siz2]==0)siz2--;
	//	cout<<ans[1]<<endl;
//		for(int i=siz;i>=1;i--)cout<<a[i];
//		cout<<endl;
	}
	
	if(a[1]==k-1){
		ans[1]+=1;
		for(int i=1;i<=siz2;i++){
			ans[i+1]+=ans[i]/pow10[9];
			ans[i]%=pow10[9];
		}
		if(ans[siz2+1]!=0)siz2=siz2+1;
	}
	//cout<<
	while(ans[siz2]==0)siz2--;
	for(int i=siz2;i>=1;i--)cout<<ans[i];
} 
