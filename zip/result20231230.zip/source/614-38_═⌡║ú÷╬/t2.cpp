#include<bits/stdc++.h>
#define int long long
using namespace std;
int yu;
string chufa(string s,int p)
{
	string daa;
	for(int i=0;i<s.size();i++)
	{
		daa+=(yu*10+s[i]-'0')/p+'0';
		yu=(yu*10+s[i]-'0')%p;
	}
	return daa;
}
char p[1000001];
void jiafa(string &l,string s)
{
	int sum=0;
	for(int i=0;i<strlen(p);i++) p[i]=0;
	for(int i=l.size()-1,j=s.size()-1,op=max(i,j);i>-1||j>-1;i--,j--,op--)
	{
		if(i<=-1) if(s[j]+sum-'0'>=10) p[op]=(s[j]+sum-'0')%10,sum=1;else p[op]=s[j]+sum-'0',sum=0;
		if(j<=-1) if(l[i]+sum-'0'>=10) p[op]=(l[i]+sum-'0')%10,sum=1;else p[op]=l[i]+sum-'0',sum=0;
		if(i>-1 && j>-1)
		{
//			cout<<s[j]+l[i]+sum-'0'-'0'<<" "<<l[0]<<" "<<s[0]<<" ";
			if(s[j]+l[i]+sum-'0'-'0'>=10) p[op]=(s[j]-'0'+l[i]-'0'+sum)%10,sum=1;
			else p[op]=s[j]+l[i]+sum-'0'-'0',sum=0;
//			cout<<p[op]+'0'<<endl;
		}
		p[op]+='0';
	}
	string u;
	l=u;
	if(sum==1) l+='1';
	for(int i=0;i<strlen(p);i++) l+=p[i];
}
void jiafa1(string &n,int yu,string m)
{
	int sum=0,l=yu,ss=0;
	for(int i=0;i<strlen(p);i++) p[i]=0;
	while(l>0) ss++,l/=10;
	for(int i=m.size()-1,op=max(i,ss)-1;i>-1||yu>0;i--,yu/=10,op--)
	{
		int yuy=yu%10;
		if(i<=-1) if(yuy+sum>=10) p[op]=(yuy+sum)%10,sum=1;else p[op]=yuy+sum,sum=0;
		if(yu<=0) if(m[i]+sum-'0'>=10) p[op]=(m[i]+sum-'0')%10,sum=1;else p[op]=m[i]+sum-'0',sum=0;
		if(i>-1 && yu>0)
		{
			if(m[i]+yuy+sum-'0'>=10) p[op]=(yuy-'0'+m[i]+sum)%10,sum=1;
			else p[op]=m[i]+yuy+sum-'0',sum=0;
		}
		p[op]+='0';
	}
	string u;
	n=u;
	if(sum==1) n+='1';
	for(int i=0;i<strlen(p);i++) n+=p[i];	
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	string n,k;
	cin>>n>>k;
	if(n.size()<=18){
		int ans=0,l=0,r=0;
		for(int i=0;i<n.size();i++) l=l*10+n[i]-'0';
		for(int i=0;i<k.size();i++) r=r*10+k[i]-'0';
		while(l>0)
		{
			ans+=l/r;
			l=l%r+l/r;
			if(l<r)
			{
				if(r-l==1) ans++;
				break;
			}	
		}
		cout<<ans;
	}
	else{
		string ans; 
		int c=0,cnt=0;
		for(int i=0;i<k.size();i++) c=c*10+k[i]-'0';
		while(n.size()>0)
		{cnt++;
			yu=0;
			string da=chufa(n,c);
			string u;int f=0;
			for(int i=0;i<da.size();i++) if(f==1||da[i]-'0'>0)u+=da[i],f=1;
			da=u; 
			jiafa(ans,da);
			jiafa1(n,yu,da);
			int sums=0,add;
			for(int i=0;i<n.size();i++){if(n[i]-'0'==0) sums++;	else {add=n[i];break;}}
			if(n.size()-sums<=k.size())
			{
				int l=0;	for(int i=sums;i<n.size();i++) l=l*10+n[i]-'0';
				if(l<c)
				{
					string u;u+='1';
					if(l+1==c) jiafa(ans,u);
					break;
				}
			}
			string u1;
			for(int i=sums;i<n.size();i++) u1+=n[i];
			n=u1;
		}
		int f=0;
		for(int i=0;i<ans.size();i++)
		{
			if(ans[i]-'0'!=0 || f==1)
			cout<<ans[i],f=1;
		}
	}
	return 0;
}

