#include<bits/stdc++.h>
using namespace std;
char a[500001];
map<string,int>s;
int ans=0,mod=1000000007;
int pd(int n)
{
	string u;
	for(int i=1;i<=n;i++) u+=a[i];
	if(s[u]==0) s[u]=1;
	else ans--,s[u]++;
	if(s[u]==1) return 1;
	return 0;
}
void dfs(int p,int n)
{
	if(p>n||p==0) {
		pd(n),ans++,ans%=mod;return;
	}
	if(a[p]=='1' && a[p+1]=='1' && a[p+2]=='0'&&p+2<=n){
		a[p]='0',a[p+2]='1',ans++;ans%=mod;
		if(pd(n)==1)dfs(p+1,n),dfs(p-2,n);
		a[p]='1',a[p+2]='0';
	}
	if(a[p]=='1' && a[p-1]=='1' && a[p-2]=='0'&&p-2>0) 
	{
		a[p]='0',a[p-2]='1',ans++,ans%=mod;
		if(pd(n)==1)dfs(p-1,n),dfs(p-2,n),dfs(p-3,n);
		a[p]='1',a[p-2]='0';
	}
	dfs(p+1,n);
}
void gg(int p,int n)
{
	if(p>n)
	{
		if(pd(n)==1)ans++,dfs(1,n);
		else ans++;
		return;
	}
	if(a[p]=='?') a[p]='0',gg(p+1,n),a[p]='1',gg(p+1,n),a[p]='?';
	else gg(p+1,n); 
}
int main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	int n;
	cin>>n>>a+1;
	gg(1,n);
	cout<<ans;
	return 0;
}
/*
20
?110?110??001000?000
5 
?0110
*/ 
