#include<bits/stdc++.h>
using namespace std;
#define int long long
int ans[100001],a[100001],b[100001],sum[1000001];
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n,m,ans1=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
	int cnt=0;
	for(int i=1;i<=n;i++)
	{
		if(sum[a[i]]!=0) ans[sum[a[i]]]=max(ans[sum[a[i]]],b[i]);
		else sum[a[i]]=++cnt,ans[cnt]=b[i];
	}
	sort(ans+1,ans+1+cnt);
	for(int i=cnt;i>=1;i--)
	{
		if(m==0) break;
		ans1+=ans[i];m--;
	}
	cout<<ans1;
	return 0;
} 
