#include<bits/stdc++.h>
using namespace std;
int a[2001];
map<int,map<int,int> >s;
struct f{
	int l,r,s,x;
}w[2000001];
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	int n,m,k,d,cnt=0;
	cin>>n>>m>>k>>d;
	while(m--)
	{
		int x,y;
		cin>>x>>y;
		if(y<0)
		{
			a[x]-=y;
			if(cnt>0)
			{
				for(int i=1;i<=cnt;i++)
				{
					for(int j=x;j<=x+d;j++)
					{
						if(s[j][x]!=0)
						{
							if(s[j][x]>y)
							{
								s[j][x]-=y;
								s[j][w[i].s]+=y;
								swap(w[i],w[cnt]);
								cnt--;
								break;
							}
							else
							{
								y-=s[j][x];
								w[i].x-=s[j][x];
								s[j][x]=0;
							}
						}
					}
				}
				if(cnt==0) cout<<"YES"<<endl;
				else cout<<"NO"<<endl;
			}
			else cout<<"YES"<<endl;
		}
		else
		{
			for(int i=x;i<=x+d;i++)
			{
				int sum=0;
				for(int j=1;j<=n;j++)
				{
					sum+=s[i][j];
				}
				if(sum<k)
				{
					if(k-sum>y)
					{
						s[i][x]+=y;
						y=0;break;
					}
					else {
						s[i][x]+=k-sum;
						y-=(k-sum);
					}
				}
			}
			if(y==0 && cnt==0) cout<<"YES"<<endl;
			else if(y!=0)w[++cnt].l=x,w[cnt].r=x+d,w[cnt].s=x,w[cnt].x=y,cout<<"NO"<<endl;else cout<<"NO"<<endl;
		}
	}
	return 0;
}

