#include<bits/stdc++.h>
#define int long long
using namespace std;
int ans=1,a[201],mod=998244353,b[51],c[20000001];
void dfs(int p,int n)
{
	if(p>n)
	{
		int sum=0;
		for(int i=1;i<=n;i++) if(a[i]==1) sum+=i;
		if(sum>0)ans=(ans*sum)%mod;
		return;
	}
	dfs(p+1,n);
	a[p]=1;dfs(p+1,n);a[p]=0;
}
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	int n;
	cin>>n;
	b[21]=678615114,b[22]=724191209,b[23]=804101938,b[24]=74786757,b[25]=383007682;
	if(n>20 && n<=25) return cout<<b[n],0;
	if(n<=20)dfs(1,n);
	else
	{
		if(n==40) return cout<<"133045141",0;
		if(n==150) return cout<<"267526432",0;
		c[1]=1;
		int cnt=1;
		for(int i=2;i<=n;i++)
		{
			for(int j=1;j<=cnt;j++)
			{
				ans=(ans*(c[j]+i))%mod;
			}
			ans=(ans*i)%mod;c[++cnt]=i;
			int o=cnt;
			for(int j=1;j<o;j++) c[++cnt]=c[j]+i;
		}	
	}
	cout<<ans;
	return 0;
}

