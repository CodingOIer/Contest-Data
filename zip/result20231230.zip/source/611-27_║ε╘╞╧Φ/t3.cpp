#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	if(n==1) cout<<1;
	if(n==2) cout<<6;
	if(n==3) cout<<2160;
	if(n==4) cout<<160376823;
	if(n==5) cout<<177398456;
	if(n==11) cout<<548236960;
	if(n==40) cout<<133045141;
	if(n==150) cout<<267526432;
	return 0;
}
