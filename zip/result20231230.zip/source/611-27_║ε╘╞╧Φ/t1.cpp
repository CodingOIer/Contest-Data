#include<bits/stdc++.h>
using namespace std;
int n,k;
int t[100003],v[100003];
long long ans;
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&t[i]);
	for(int i=1;i<=n;i++) scanf("%d",&v[i]);
	sort(v+1,v+n+1);
	for(int i=1;i<=k;i++) ans+=v[n-i+1];cout<<ans;
	return 0;
}
