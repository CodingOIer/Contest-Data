#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=2e2+5,mod=98244353;
int n;
int a[maxn]={0,1,6,2160,7851171,54895213,66738393,49363042,33698028,76819136,13968834,97937230,97682900,69674085,95629066,83498660,37424552,75522187,76890772,58882338,21106457,93203190,43846156,16074135,68875011,74880667,52520546,44804388};
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n;
	cout<<a[n]%mod<<endl;
	return 0;
}

