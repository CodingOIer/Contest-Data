#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=4e3+5;
int n,m,k,d;
int a[maxn],sum[maxn];
signed main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n>>m>>k>>d;
	if(k==0){
		while(m--){
			int x,y;
			cin>>x>>y;
			cout<<"NO\n";	
		}
		return 0;
	}
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		if(y>0){
			int yy=y;
			for(int i=x;i<=x+d;i++) if(k-sum[i]>0) yy-=(k-sum[i]);
			if(yy<=0){
				cout<<"YES\n";
				for(int i=x;i<=x+d;i++){
					if(y==0) break;
					if(sum[i]<k && y>=k-sum[i]) y-=(k-sum[i]),sum[i]=k;
					else if(sum[i]<k && y<k-sum[i]) sum[i]+=y,y=0;
					
				}
			}
			else cout<<"NO\n";
		}
		if(y<0){
			cout<<"YES\n";
			y=-y;
			for(int i=x;i<=x+d;i++){
				if(y==0) break;
				if(sum[i]>y) sum[i]-=y,y=0;
				else if(sum[i]!=0) y-=sum[i],sum[i]=0;
			}
		}
//		for(int i=1;i<=n;i++) cout<<sum[i]<<" ";
//		cout<<endl;
	}
	return 0;
}
