#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	int a[10000]={1,2,3,4,5,6,7,8};
	resrev(a+1,a+9);
	cout<<a[1]<<endl;
	return 0;
}

