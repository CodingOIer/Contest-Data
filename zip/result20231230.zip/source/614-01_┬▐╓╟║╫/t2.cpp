#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5;
string N,ANS;
int n,k,ans;
int a[maxn],b[maxn],c[maxn];
string jia(string s,string t){
	memset(a,0,sizeof(a)),memset(b,0,sizeof(b)),memset(c,0,sizeof(c));
	for(int i=0;i<s.size();i++) a[i+1]=s[i]-'0';
	for(int i=0;i<t.size();i++) b[i+1]=t[i]-'0';
	int top1=s.size(),top2=t.size(),len=max(s.size(),t.size()),u=1;
	for(int i=1;i<=len;i++){
		int dq=max(top1,top2);
		c[dq]+=a[top1]+b[top2];
		if(max(top1,top2)==1 && c[dq]>=10) u--;
		if(c[dq]>=10) c[dq-1]++,c[dq]-=10;
		top1--,top2--;
		if(top1<=0) top1=0;
		if(top2<=0) top2=0;
	}
	string st;
	for(int i=u;i<=len;i++) st+=char(c[i]+'0');
	return st;
}
struct node{string val,yu;}o;
node chu(string s){
	memset(a,0,sizeof(a)),memset(b,0,sizeof(b)),memset(c,0,sizeof(c));
	for(int i=0;i<s.size();i++) a[i+1]=s[i]-'0';
	int len=s.size(),p=0;
	for(int i=1;i<=len;i++){
		p=p*10+a[i];
		c[i]=p/k;
		if(c[i]>=1) p=p%k;
	}
	string st;
	int flag=0;
	for(int i=1;i<=len;i++){
		if(c[i]==0 && flag==0) continue;
		else st+=char(c[i]+'0'),flag=1;
	}
	o.val=st;
	o.yu.clear();
	int cnt=0;
	while(p){
		b[++cnt]=p%10;
		p/=10;
	}
	for(int i=cnt;i>=1;i--) o.yu+=char(b[i]+'0');
	return o;
}
bool cheak(string s,string t){
	if(s.size()>t.size()) return false;
	if(s.size()<t.size()) return true;
	for(int i=0;i<s.size();i++){
		if(s[i]<t[i]) return true;
	}
	return false;
}
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>N>>k;
	if(N<="9223372036854775807"){
		for(int i=0;i<N.size();i++) n=n*10+N[i]-'0';
		while(true){
			if(n<k) break;
			ans+=n/k;
			n=n/k+n%k;
		}
		if(n==k-1) ans++;
		cout<<ans<<endl;
	}
	else{
		string K;
		int kk=k,cnt=0;
		while(kk){
			a[++cnt]=kk%10;
			kk/=10;
		}
		for(int i=cnt;i>=1;i--) K+=char(a[i]+'0');
		while(true){
			if(cheak(N,K)) break;
			node h=chu(N);
			ANS=jia(ANS,h.val);
			N=jia(h.val,h.yu);
		}
		if(jia(N,"1")==K) cout<<jia(ANS,"1")<<endl;
		else cout<<ANS<<endl;
	}
	return 0;
}

