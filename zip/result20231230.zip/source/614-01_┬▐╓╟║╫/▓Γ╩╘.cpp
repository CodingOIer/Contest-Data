#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5,mod=98244353;
int n,ans=1;
int a[maxn];
void dfs(int dq,int sum,int x){
	if(dq>n) return; 
	if(sum==x+1){
		int p=0;
		for(int i=1;i<=x;i++) p+=a[i],p%=mod;
//		for(int i=1;i<=x;i++) cout<<a[i]<<" ";
		ans*=p;
		ans%=mod;
//		cout<<"---"<<p<<" "<<ans<<endl;
		return;
	}
	dfs(dq+1,sum,x);
	a[sum]=dq;
	dfs(dq+1,sum+1,x);
}
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n;
	n++;
	for(int i=1;i<=n;i++) dfs(1,1,i);
	cout<<ans<<endl;
	return 0;
}

