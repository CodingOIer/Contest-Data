#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5;
string s,t;
int a[maxn],b[maxn],c[maxn];
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>s>>t;
	for(int i=0;i<s.size();i++) a[i+1]=s[i]-'0';
	for(int i=0;i<t.size();i++) b[i+1]=t[i]-'0';
	int top1=s.size(),top2=t.size(),len=max(s.size(),t.size());
	for(int i=1;i<=len;i++){
		int dq=max(top1,top2);
		c[dq]+=a[top1]+b[top2];
		if(c[dq]>=10) c[dq-1]++,c[dq]-=10;
		top1--,top2--;
		if(top1<=0) top1=0;
		if(top2<=0) top2=0;
	}
	string st;
	for(int i=1;i<=len;i++) st+=char(c[i]+'0');
	cout<<st<<endl;
	return 0;
}

