#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5;
int n,k;
struct node{int t,v;}a[maxn];
bool cmp(node x,node y){return x.v>y.v;}
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>a[i].t;
	for(int i=1;i<=n;i++) cin>>a[i].v;
	sort(a+1,a+1+n,cmp);
	int ans=0;
	for(int i=1;i<=k;i++) ans+=a[i].v;
	cout<<ans<<endl;
	return 0;
}
