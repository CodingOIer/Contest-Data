//�ܷ�С��300��ʱ�������������� 
#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
const int mod=998244353;
int n;
int dp[114514];
int ans=1;
int ksm(int x,int p)
{
	int res=1;
	while(p)
	{
		if(p&1)
			res=res*x%mod;
		x=x*x%mod;
		p>>=1;
	}
	return res;
}
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	n=read();
	dp[0]=1;
	int sum=(1+n)*n/2;
	for(int i=1;i<=n;i++)
		for(int j=sum;j>=i;j--)
			dp[j]=dp[j]+dp[j-i];
	for(int i=1;i<=sum;i++)
		ans=ans*ksm(i,dp[i])%mod;
	write(ans);
	return 0;
}
