//�ܷ�С��300��ʱ�������������� 
#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
struct node
{
	int t,v;
}a[114514];
bool cmp(node x,node y)
{
	return x.v>y.v;
}
int n,k;
map<int,int>vis;
int ans;
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++)
		a[i].t=read();
	for(int i=1;i<=n;i++)
		a[i].v=read();
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
		if(!vis[a[i].t]&&k)
			--k,ans+=a[i].v,vis[a[i].t]=1;
	write(ans);
	return 0;
}
