//�ܷ�С��300��ʱ�������������� 
#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int n,m,k,d;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	n=read(),m=read(),k=read(),d=read();
	while(m--)
		puts("NO");
	return 0;
}
