//�ܷ�С��300��ʱ�������������� 
#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
int n;
int ans;
string s;
int vis[1145];
void dfs2(int now)
{
	if(vis[now])
		return;
	++ans;
	vis[now]=1;
	for(int i=1;i<=n;i++)
		if(now&(1<<(i-1)))
		{
			if(i>2)
				if((now&(1<<(i-2)))&&!(now&(1<<(i-3))))
				{
					int sub=now;
					sub^=(1<<(i-1));
					sub|=(1<<(i-3));
					dfs2(sub);
				}
			if(i<n-1)
				if((now&(1<<(i)))&&!(now&(1<<(i+1))))
				{
					int sub=now;
					sub^=(1<<(i-1));
					sub|=(1<<(i+1));
					dfs2(sub);
				}
		}
}
void dfs1(int x)
{
	if(x>n)
	{
		int sub=0;
		for(int i=1;i<=n;i++)
			if(s[i]=='1')
				sub|=(1<<(i-1));
		memset(vis,0,sizeof vis);
		dfs2(sub);
		return;
	}
	if(s[x]=='?')
	{
		s[x]='1';
		dfs1(x+1);
		s[x]='0';
		dfs1(x+1);
	}
	else
		dfs1(x+1);
}
signed main()
{
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	n=read(),cin>>s;
	s=' '+s;
	dfs1(1);
	write(ans);
	return 0;
}
