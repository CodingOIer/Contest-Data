//�ܷ�С��300��ʱ�������������� 
#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int res=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){res=(res<<1)+(res<<3)+(c^48);c=getchar();}
	return res*f;
}
void write(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9)write(x/10);
	putchar(x%10+'0');
}
string n;
int k;
int num[114514];
int ans[114514];
int cnt;
void darling_02(string x,int y)
{
	int last=1;
	int len=x.size();
	x='0'+x;
	for(int i=1;i<=len;i++)
	{
		int num=0;
		while(num<y&&i<=len)
		{
			if(i>last)
				ans[++cnt]=0;
			num=num*10+x[i]-'0',++i;
		}
		int ys=num%y;
		ans[++cnt]=num/y;
		last=i;
		--i;
		while(ys&&i<len)
			x[i--]=ys%10+'0',ys/=10;
	}
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n,k=read();
	darling_02(n,k-1);
	int i=1;
	while(!ans[i]&&i<=cnt)
		++i;
	if(i>cnt)
		write(0);
	else
		for(;i<=cnt;i++)
			write(ans[i]);
	return 0;
}
