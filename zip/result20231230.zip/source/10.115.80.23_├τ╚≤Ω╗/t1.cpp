#include<bits/stdc++.h>
using namespace std;
int w[1000005];
int cmp(int p1,int p2){
	return p1>p2;
}
int main(){
	int n,k;
	long long ans=0;
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=0,t;i<n;i++)
		scanf("%d",&t);
	for(int i=0;i<n;i++)
		scanf("%d",&w[i]);
	sort(w,w+n,cmp);
	for(int i=0;i<k;i++)
		ans+=w[i];
	printf("%lld",ans);
	return 0;
}
