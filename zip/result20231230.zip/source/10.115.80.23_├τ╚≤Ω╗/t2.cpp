#include<bits/stdc++.h>
using namespace std;
long long n,k,ans=0;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	while(n>=k){
		ans+=n/k;
		n=n/k+n%k;
	}
	if(n==k-1)
		ans+=1;
	printf("%lld",ans);
	return 0;
}
