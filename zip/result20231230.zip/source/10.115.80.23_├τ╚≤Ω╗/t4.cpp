#include<bits/stdc++.h>
using namespace std;
long long wz[500005],n,m,k,d;
bool cl[500005];
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&d);
	for(long long i=0,x,y;i<m;i++){
		scanf("%d%d",&x,&y);
		wz[x-1]+=y;
		cl[i]=1;
		if(y>0){
			for(long long j=0,r=0,f=k*d;j<n-d;j++){
				r+=wz[j];
				f+=k;
				if(r>f){
					cl[i]=0;
					break;
				}
			}
			for(long long j=n-1,r=0,f=k*d;j>=d;j--){
				r+=wz[j];
				f+=k;
				if(r>f){
					cl[i]=0;
					break;
				}
			}
			if(cl[i]==0)
				wz[x-1]-=y;
		}
	}
	for(int i=0;i<m;i++){
		if(cl[i])
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}
