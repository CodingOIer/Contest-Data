#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e5 + 10;
int w[N], res;
const int Mod = 1e9 + 7;

//map<string, int> t;
//void dfs(int s) {
//	if(t[s]) return;
//	++res;
//	t[s] = 1;
//	for(int i = 1; i <= n; i++) {
//		if(s & (1 << (i - 1))) {
//			if(i >= 2 && s[i - 2] == '0') dfs(s ^ (1 << (i - 1)) ^ (1 << (i - 3)));
//			if(i <= s.size() - 3 && !(s & (1 << (i + ))))
//		}
//	}
//}
signed main() {
	freopen("t5.in", "r", stdin);
	freopen("t5.out", "w", stdout);
	int n;
	cin >> n;
	string s;
	cin >> s;
	s = ' ' + s;
	int cnt = 0;
	for(int i = 1; i <= n; i++) {
		if(s[i] == '?') w[i] = ++cnt;
	}
	cout << (1 << cnt); 
//	int ans = 0;
//	for(int i = 0; i < (1 << cnt); i++) {
//		string ss;
//		for(int j = 1; j <= n; j++) {
//			if(s[j] == '?') {
//				if(i & (1 << (w[j] - 1))) ss += '1';
//				else ss += '0';
//			}
//			else ss += s[j];
//		}
//		res = 0;
//		t.clear();
//		dfs(ss);
//		ans = (ans + res) % Mod;
//	}
} 
