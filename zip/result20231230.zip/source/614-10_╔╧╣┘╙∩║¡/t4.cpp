#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 5e5 + 10;
int a[N], pre[N]; 
signed main() {
	freopen("t4.in", "r", stdin);
	freopen("t4.out", "w", stdout);
	int n, m, k, d;
	scanf("%lld%lld%lld%lld", &n, &m, &k, &d);
	
	for(int i = 1; i <= n; i++) pre[i] = i;
	while(m--) {
		int x, y;
		scanf("%lld%lld", &x, &y);
		puts("YES"); 
//		if(y > 0) {
//			for(int i = pre[x]; i <= x + d; i++) {
//				if(a[i] < k) {
//					int p = min((k - a[i]), y);
//					a[i] += p;
//					y -= p;
//				}
//				if(y == 0) break;
//			}
//			if(y) puts("NO");
//			else puts("YES");
//		}
//		else {
//			int last;
//			for(int i = pre[x + 1]; i >= x; i--) {
//				if(a[i]) {
//					int p = min(a[i], y);
//					a[i] -= p;
//					y -= p;
//				}
//				if(y == 0) {
//					last = i;
//					break;
//				}
//			}
//			if(y) puts("NO");
//			else puts("YES");
//			for(int i = x + 1; i <= n; i++) {
//				pre[i] = min(last, i);
//				for(int j = pre[i]; j <= )
//			}
//			
//		}
	}
	
}
/*
*/
