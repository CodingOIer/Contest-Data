#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e6 + 10;
int pl[N], mi[N], ef[N], uf[N], tmp1[N], a[N], b[N], res[N]; 
int Plus(int a[], int b[], int n, int m) {
	int i = n, j = m, p = 0, cnt = 0;
	while(i >= 1 || j >= 1) {
		tmp1[++cnt] = (a[i] + b[j] + p) % 10;
		p = (a[i] + b[j] + p) / 10;
		--i, --j;
	}
	if(p) tmp1[++cnt] = p;
	int pos = cnt;
	while(!tmp1[pos]) --pos; 
	int len = 0;
	for(int i = pos; i >= 1; i--) pl[++len] = tmp1[i];
	return len;
}
int Minu(int a[], int b[], int n, int m) {
	int i = n, j = m, p = 0, cnt = 0;
	while(i >= 1 || j >= 1) {
		int ne = (b[j] - (a[i] - p) + 9) / 10;
		tmp1[++cnt] = (a[i] - p + ne * 10) - b[j];
		p = ne;
		--i, --j;
	}
	if(p) tmp1[++cnt] = p;
	int pos = cnt;
	while(!tmp1[pos]) --pos; 
	int len = 0;
	for(int i = pos; i >= 1; i--) mi[++len] = tmp1[i];
	return len;
}
int chef(int a[], int k, int n) {
	int cnt = 0, p = 0;
	for(int i = n; i >= 1; i--) {
		tmp1[++cnt] = (a[i] * k + p) % 10;
		p = (a[i] * k + p) / 10; 
	}
	if(p) tmp1[++cnt] = p;
	int pos = cnt;
	while(!tmp1[pos]) --pos; 
	int len = 0;
	for(int i = pos; i >= 1; i--) ef[++len] = tmp1[i];
	return len;
}
int chuf(int a[], int k, int n) {
	int i = 0, p = 0, cnt = 0;
	while(i <= n && p < k) p = p * 10 + a[++i];
	while(i <= n) {
		uf[++cnt] = p / k;
		p = p % k * 10 + a[i]; 
		++i;
	}
	return cnt;
}

bool check(int a[], int k, int n) {
	int tmp = k, cnt = 0;
	while(tmp) tmp1[++cnt] = tmp % 10, tmp /= 10;
	if(n > cnt) return true;
	if(n < cnt) return false;
	for(int i = 1; i <= cnt; i++) {
		if(a[i] > tmp1[cnt - i + 1]) return true;
		if(a[i] < tmp1[cnt - i + 1]) return false;
	}
	return true;
}
string s;
int k, len_res = 0, len_a = s.size();
void solve1() {
	int m = 0;
	for(int i = 0; i < s.size(); i++) m = m * 10 + s[i] - '0';
	int cnt = 0;
	while(m >= k) {
		cnt += m / k;
		m = m / k + m % k;
	}
	if(m == k - 1) ++cnt;
	cout << cnt;
}
signed main() {
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	cin >> s;
	cin >> k;
	for(int i = 0; i < s.size(); i++) a[i + 1] = s[i] - '0';
	if(len_a <= 19) {
		solve1();
		return 0;
	} 
	while(check(a, k, len_a)) {
		int len_uf = chuf(a, k, len_a);
		int len_pl = Plus(res, uf, len_res, len_uf);
		for(int i = 1; i <= len_pl; i++) res[i] = pl[i];
		len_res = len_pl;
		int len_ef = chef(uf, k, len_uf);
		int len_jf = Minu(a, ef, len_a, len_ef);
		len_pl = Plus(uf, mi, len_uf, len_jf);
		for(int i = 1; i <= len_pl; i++) a[i] = pl[i];
		len_a = len_pl;
	 	
	}
	int sum = 0;
	for(int i = 1; i <= len_a; i++) sum = sum * 10 + a[i];
	if(sum == k - 1) {
		b[1] = 1;
		len_res = Plus(res, b, len_res, 1);
		for(int i = 1; i <= len_res; i++) cout << pl[i];
	}
	else for(int i = 1; i <= len_res; i++) cout << res[i];
}
