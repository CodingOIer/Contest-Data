#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 1e5 + 10;
int a[N];
signed main() {
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout); 
	int n, k;
	scanf("%lld%lld", &n, &k);
	for(int i = 1; i <= n; i++) {
		int x;
		scanf("%lld", &x);
	}
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	sort(a + 1, a + n + 1);
	reverse(a + 1, a + n + 1);
	int ans = 0;
	for(int i = 1; i <= k; i++) ans += a[i];
	printf("%lld", ans);
} 
