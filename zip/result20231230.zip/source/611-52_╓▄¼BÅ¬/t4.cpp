#include<bits/stdc++.h>
#define int long long
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define INT LONG_LONG
#define debug1() cout<<"I AK IOI!"<<endl
#define debug2(x,y) cout<<"case "<<x<<": "<<y<<endl
using namespace std;
int n,m,k,d,x,y,a[500005];
signed main()
{
	fast_io;
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	while (m--)
	{
		cout<<"No\n";
	}
	return 0;
}

