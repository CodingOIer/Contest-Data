#include<bits/stdc++.h>
#define int long long
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define INT LONG_LONG
#define debug1() cout<<"I AK IOI!"<<endl
#define debug2(x,y) cout<<"case "<<x<<": "<<y<<endl
using namespace std;
int n,a[100000005],t,ans=1;
signed main()
{
	fast_io; 
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		a[++t]=i;
		ans=(ans*a[t])%998244353;
		int x=t-1;
		for (int j=1;j<=x;j++)
			a[++t]=a[j]+i,ans=(ans*a[t])%998244353;
	}
	cout<<ans;
	return 0;
}
/*
1
3
7
*/
