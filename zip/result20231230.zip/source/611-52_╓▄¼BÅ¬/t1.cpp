#include<bits/stdc++.h>
#define int long long
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define INT LONG_LONG
#define endl '\n'
#define debug1() cout<<"I AK IOI!"<<endl
#define debug2(x,y) cout<<"case "<<x<<": "<<y<<endl
using namespace std;
int n,k,a[100005],ans;
inline bool cmp(const int &x,const int &y)
{
	return x>y;
}
signed main()
{
	fast_io;
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout); 
	cin>>n>>k;
	for (int i=1;i<=n;i++)
		cin>>a[i];
	for (int i=1;i<=n;i++)
		cin>>a[i];
	sort(a+1,a+n+1,cmp);
	for (int i=1;i<=k;i++)
		ans+=a[i];
	cout<<ans;
	return 0;
}
