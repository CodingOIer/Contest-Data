#include<bits/stdc++.h>
#define int long long
#define fast_io ios::sync_with_stdio(0);ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define INT LONG_LONG
#define debug1() cout<<"I AK IOI!"<<endl
#define debug2(x,y) cout<<"case "<<x<<": "<<y<<endl
#define debug3(x,y,z) cout<<"case "<<x<<"&"<<y<<": "<<z
using namespace std;
string s,ans;
int a[200005],n,k;
signed main()
{
	fast_io; 
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s>>k;
	int n=s.size();
	for (int i=0;i<n;i++)
		a[n-i]=s[i]-'0';
	k--;
	int t=0,v=1;
	for (int i=n;i>=1;i--)
	{
		t=t*10+a[i];
		if (t>=k&&v)
		{
			ans+=(char)(t/k+'0');
			t%=k;
			v=0;
		}
		else if (!v)
			ans+=(char)(t/k+'0'),t%=k;
	}
	cout<<ans;
	return 0;
}

