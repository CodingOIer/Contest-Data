#include <bits/stdc++.h>
using namespace std;
long long n,k;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	cout<<n/(k-1)<<endl;
	return 0;
}
