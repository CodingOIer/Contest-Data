#include <bits/stdc++.h>
using namespace std;
long long n,k,t[100005],w[100005],ans=0,sum=0;
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k; 
	for(long long i=1;i<=n;i++)
	{
		cin>>t[i];
	}
	for(long long i=1;i<=n;i++)
	{
		cin>>w[i];
	}
	sort(w+1,w+1+n);
	for(long long i=n;i>=1;i--)
	{
		if(sum<=k-1)
		{
			sum++;
			ans+=w[i];
		}
	}
	cout<<ans<<endl;
	return 0;
} 
