#include <bits/stdc++.h>
using namespace std;
long long n,m,k,d,sum=0,f=1,x[500005],y[500005],ans[500005]={0}; 
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k>>d;
	if(k!=1)
	{
		return 0;
	}
	else
	{
		for(long long i=1;i<=m;i++)
		{
			f=1;
			sum=0;
			cin>>x[i]>>y[i];
			for(long long j=x[i];j<=x[i]+d;j++)
			{
				if(!ans[j]&&!sum)
				{
					ans[j]++;
					sum++;
				}
				if(sum>=y[i]&&f==1)
				{
					f=0;
				}
			}	
			if(f==1)
			{
				cout<<"NO"<<endl;
			}
			else
			{
				cout<<"YES"<<endl;
			}
		}	
	}
	return 0;
}
