#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
const int mod=1e9+7;
int qpow(int x,int y){
	int ans=1;
	while(y){
		if(y&1) ans=(ans*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return ans;
}
signed main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n;
	cout<<qpow(2,n);
	return 0;
}

