#include<bits/stdc++.h>
using namespace std;
int n,k;
long long ans;
struct node{
	int t,v;
}a[100005];
bool cmp(node x,node y){
	if(x.v==y.v)return x.t<y.t;
	else return x.v>y.v;
}
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>a[i].t;
	for(int i=1;i<=n;i++)cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	int cnt=0;
	for(int i=1;;i++){
		if(a[i].t<i)continue;
		ans+=a[i].v;
		cnt++;
		if(cnt>=k) break;
	}
	cout<<ans;
	return 0;
}
