#include<bits/stdc++.h>
using namespace std;
int a[100005],b[100005];
string s;
long long ans,n,k,len,top,f=0;
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s>>k;
	len=s.size();
	for(int i=0;i<len;i++)a[i+1]=int(s[i]-'0');
	if(len<=18){
		for(int i=1;i<=len;i++) n=(n*10)+a[i];
		while(true){
			if(n>=k){
				ans+=n/k;
				n=n%k+n/k;
			}
			else{
				if(n+1==k)ans++;
				break;
			}
		}
		cout<<ans;
		return 0;
	}k--;
	for(int i=1;i<=len;i++)
	{
		n=(n*10)+a[i];
		if(n>=k){
			b[++top]=n/k;
			n%=k;
		}
		else b[++top]=0;
	}
	for(int i=1;i<=top;i++){
		if(b[i]==0){
			if(f==0) continue;
			else cout<<b[i];
		}
		else{
			f=1;
			cout<<b[i];
		}
	}
	return 0;
}

