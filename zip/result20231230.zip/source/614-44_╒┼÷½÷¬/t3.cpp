#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,ans=1;
int calc(int s){
	int res=0;
	for(int i=1;i<=n;i++){
		if(s&(1<<(i-1))) res=res+i;
	}
	return res;
}
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;/*
	for(int i=1;i<=(1+n)*n/2;i++) ans=(ans*i)%mod;
	for(int i=3;i<=3+(n-3)*2;i++) ans=(ans*i)%mod;
	cout<<ans;*/
	for(int bit=1;bit<(1<<n);bit++){
		ans=(ans*calc(bit))%mod;
	}
	cout<<ans;
	return 0;
}/*
1
1 1 1
1 1 2 1 1 1
1 1 2 2 2 2 2 1 1 1
1 1 2 2 3 3 3 3 3 3 2 2 1 1 1
1 1 2 2 3 4 4 4 5 5 5 5 4 4 4 3 2 2 1 1 1
1 1 2 2 3 4 5 5 6 7 7 8 8 8 8 8 7 7 6 5 5 4 3 2 2 1 1 1
1 1 2 2 3 4 5 6 7 8 9 10 11 12 13 13 13 14 13 13 13 12 11 10 9 8 7 6 5 4 3 2 2 1 1 1
1 1 2 2 3 4 5 6 8 9 10 12 13 15 17 18 19 21 21 22 23 23 23 23 22 21 21 19 18 17 15 13 12 10 9 8 6 5 4 3 2 2 1 1 1
1 1 2 2 3 4 5 6 8 10 11 13 15 17 20 22 24 27 29 31 33 35 36 38 39 39 40 40 39 39 38 36 35 33 31 29 27 24 22 20 17 15 13 11 10 8 6 5 4 3 2 2 1 1 1
*/
