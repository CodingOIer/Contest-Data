#include <bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int val[N*4],tag[N*4];
int n,m,k,d,a[N];
int x,y;
void push_down(int p) {
	if(tag[p]==0) return;
	val[p*2]+=tag[p];
	val[p*2+1]+=tag[p];
	tag[p*2]+=tag[p];
	tag[p*2+1]+=tag[p];
	tag[p]=0;
}
void build(int l,int r,int p) {
	if(l==r){
		val[p]=a[l];
		return;
	}
	int mid=(l+r)/2;
	build(l,mid,p*2);
	build(mid+1,r,p*2+1);
	val[p]=min(val[p*2],val[p*2+1]);
}
void change(int l,int r,int s,int t,int p,int k) {
	if(l>=s&&r<=t) {
		val[p]+=k,tag[p]+=k;
		return;
	}
	int mid=(l+r)/2;
	push_down(p);
	if(s<=mid)	change(l,mid,s,t,p*2,k);
	if(t>mid)	change(mid+1,r,s,t,p*2+1,k);
	val[p]=min(val[p*2],val[p*2+1]);
	return;
}
int ask(int l,int r,int s,int t,int p) {
	if(l>=s&&r<=t)	return val[p];
	int mid=(l+r)/2,ans=INT_MAX;
	push_down(p);
	if(s<=mid)	ans=ask(l,mid,s,t,p*2);
	if(t>mid)	ans=min(ans,ask(mid+1,r,s,t,p*2+1));
	return ans;
}
signed main() {
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=n;i++)a[i]=k;
	build(1,n,1);
	for(int _=1;_<=m;_++){
		cin>>x>>y;
		if(y>d){
			cout<<"NO";
			puts("");
			continue;
		}
		change(1,n,x,x+d,1,-1);
		if(ask(1,n,x,x+d,1)<0){
			cout<<"NO";
			puts("");
		}
		else{
			cout<<"YES";
			puts("");
		}
	}
	return 0;
}
//�҇������� 
