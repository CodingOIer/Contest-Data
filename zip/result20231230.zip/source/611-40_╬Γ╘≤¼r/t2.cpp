#include<bits/stdc++.h>
using namespace std;

long long n,k,h;
/*
long long n[100001],k,h[100001],nl,hl,t;
string tn;

int cuot(){
	t=0;
	hl=-1;
	for(int i=nl-1;i>=0;i--){
		t=t*10+n[i];
		h[i]=t/k;
		if(h[i]!=0 && hl==-1){
			hl=i;
		} 
	}
	for(int i=hl;i>=0;i--){
		cout<<h[i];
	}
}
*/

int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	/*//���,�ҹ��� 
	cout<<"Inf"<<endl;
	for(long long i=2;i<=100;i++){
		for(long long j=1;j<=1000;j++){
			h=0;
			k=i;
			n=j;
			while(n>=k){
				h=h+n/k;
				n=n%k+n/k;
			}
			if(n==k-1){
				h++;
			}
			cout<<h<<' ';
		}
		cout<<endl;
	}
	*/
	/*
	cin>>tn>>k;
	k=k-1;
	nl=tn.size();
	for(int i=0;i<nl;i++){
		n[nl-i-1]=tn[i];
	}
	cuot();//��** ���˵ĸ߾� 
	*/
	cin>>n>>k;
	h=n/(k-1);
	cout<<h;
	return 0;
}
