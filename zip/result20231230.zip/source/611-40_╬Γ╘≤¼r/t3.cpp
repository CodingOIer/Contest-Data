#include<bits/stdc++.h>
using namespace std;

long long n,h=1;

int dfs(int x,int z,int y){
	if(x==0){
		h=h*z;
		h=h%998224353;
		return 0;
	}else if(y==n){
		return 0;
	}else{
		for(int i=y+1;i<=n-x+1;i++){
			dfs(x-1,z+i,i);
		}
	}
}

int main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		dfs(i,0,0);
	}
	cout<<h;
	return 0;
}
/*
1
=1

1*2|(1+2)
=1*2*3

1*2*3|(1+2)*(1+3)*(2+3)|(1+2+3)
=1*2*3*3*4*5*6

1*2*3*4|(1+2)*(1+3)*(1+4)*(2+3)*(2+4)*(3+4)|(1+2+3)*(1+2+4)*(1+3+4)*(2+3+4)|(1+2+3+4)
=1*2*3*4*3*4*5*5*6*7*6*7*8*9*10
*/
