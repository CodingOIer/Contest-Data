#include<bits/stdc++.h>
using namespace std;

long long x,p[1000001],t,l,pl;
string s; 

int bh(string y){
	t=1;
	for(int i=x-1;i>=0;i--){
		l=l+t*(y[i]-'0');
		t=t*2;
	}
	p[]
}

int hs(string y,long long i){
	if(i==x){
		bh(y);
	}else{
		if(s[i]=='?'){
			hs(y+"0",1);
			hs(y+"1",1); 
		}else if(s[i]=='1'){
			hs(y+"1",1);
		}else{
			hs(y+"0",1);
		}
	}
	return 0;
} 

int main(){
//	freopen("","r",stdin);
//	freopen("","w",stdout);
	cin>>x;
	cin>>s;
	if(s[0]=='?'){
		hs("0",1);
		hs("1",1); 
	}else if(s[0]=='1'){
		hs("1",1);
	}else{
		hs("0",1);
	}
	return 0;
}

