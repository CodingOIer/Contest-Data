#include<bits/stdc++.h>
using namespace std;
long long n,mod=998244353;
long long a[201];
long long b[10000000];
int main()
{
//	freopen("t3.in","r",stdin);
//	freopen("t3.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>n;
	b[0]=1;
	b[1]=1;
	for(int i=2;i<=n;i++)
	{
		long long num=b[0];
		b[0]=b[0]*2+1;
		b[num+1]=i;
		for(long long o=1;o<=num;o++){
			b[num+1+o]=b[o]+i;
		}
		long long jl=1;
		for(long long  o=1;o<=b[0];o++)
		{
			if(b[o]!=0)
				jl=(jl*b[o])%mod;
		}
		cout<<"a["<<i<<"]="<<jl<<";"<<endl;
		//for(long long o=1;o<=num;o++){
		//	cout<<b[o]<<" ";
		//}
	}
	return 0;
}

