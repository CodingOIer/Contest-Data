#include<bits/stdc++.h>
using namespace std;
long long n,mod=998244353;
long long a[201];
long long b[100000000];
long long c[100000000];
int main()
{
	//freopen("t3.in","r",stdin);
	//freopen("t3.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>n;
	b[0]=1;
	b[1]=1;
	c[1]=1;
	long long jl=1;
	for(int i=2;i<=n;i++)
	{
		for(int o=1;o<=b[0];o++)
		{
			c[o]=b[o];
		}
		for(int o=1;o<=b[0];o++)
		{
			long long k=c[o];
			b[o+i]+=k;
		}
		b[i]++;
		for(int o=1;o<=b[0];o++)
		{	
			for(int w=1;w<=c[o];w++){
				jl=(jl*(o+i))%mod;
			}
		}
		b[0]=b[0]+i;
		cout<<"a["<<i<<"]="<<jl<<";"<<endl;
	}
	return 0;
}
