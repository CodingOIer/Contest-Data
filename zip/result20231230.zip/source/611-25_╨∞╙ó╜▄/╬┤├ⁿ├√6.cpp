#include<bits/stdc++.h>
using namespace std;
long long n,mod=998244353;
long long a[201];
long long b[10000000];
long long jl=1;//[1000000];
int main()
{
//	freopen("t3.in","r",stdin);
//	freopen("t3.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>n;
	b[0]=1;
	b[1]=1;
	for(int i=2;i<=n;i++)
	{
		long long num=b[0];
		b[0]=b[0]+i;
		for(long long o=1;o<=num;o++){
			b[o+i]=b[o];
		}
		b[i]++;
	//	jl[i]=jl[i-1];
		jl=1;
		//for(long long o=1;o<=num;o++)
		//{
	//		for(int w=1;w<=b[o];w++){
		//		jl=(jl*o)%mod;
	//		}	
	//	}
	//	cout<<"a["<<i<<"]="<<jl<<";"<<endl;
		for(int o=1;o<=b[0];o++){
			if(b[o]==2){
				cout<<" ";
			}
			else
			cout<<"0";
		}
		cout<<endl;
	}
	return 0;
}

