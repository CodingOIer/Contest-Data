#include<bits/stdc++.h>
using namespace std;
long long n,m,a[100001],b[100001];
long long jl;
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0); 
	std::cin>>n>>m;
	for(long long i=1;i<=n;i++)
		std::cin>>a[i];
	for(long long i=1;i<=n;i++)
		std::cin>>b[i];
	sort(b+1,b+n+1);
	for(long long i=n;i>n-m;i--)
		jl=jl+b[i];
	std::cout<<jl;
	return 0;
} 
