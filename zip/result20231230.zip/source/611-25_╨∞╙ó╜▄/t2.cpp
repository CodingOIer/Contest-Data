#include<bits/stdc++.h>
using namespace std;
long long n,m;
long long h,k;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	std::cin.tie(0);
	std::cout.tie(0);
	std::cin>>n>>m;
	k=n;
	for(long long i=1;;i++){
		if(k>=m){
			long long w=k/m;
			h=h+w;
			k=k%m+w;
		}
		else
		if(k+1==m){
			h=h+1;
			k=0;
		}
		else{
			break;
		}
	}
	std::cout<<h;
	return 0;
}

