#include<bits/stdc++.h>
using namespace std;
int main()
{
	std::cin.tie(0);
	std::cout.tie(0);
	long long n,jl=1;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int k;
		cin>>k;
		for(int o=1;o<=k;o++){
			jl=(jl*i)%998244353;
		}
	}
	cout<<jl;
	return 0;
}
