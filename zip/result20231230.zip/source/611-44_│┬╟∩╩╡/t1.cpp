#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,k,ans;
int a[100001];
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	for(int i=n;i>n-k;i--)ans+=a[i];
	cout<<ans;
	return 0;
} 
