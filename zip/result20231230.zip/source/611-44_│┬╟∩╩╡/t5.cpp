#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,aa[1000];
signed main()
{
	freopen("t5.in","r",stdin);	
	freopen("t5.out","w",stdout);
	cout<<0;
	return 0;
}

