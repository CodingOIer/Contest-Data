#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,aa[1000];
signed main()
{
	freopen("t3.in","r",stdin);	
	freopen("t3.out","w",stdout);
	cin>>n;
	if(n==1)
	{
		cout<<1;
		return 0;
	}
	if(n==2)
	{
		cout<<6;
		return 0;
	}
	if(n==3)
	{
		cout<<2160;
		return 0;
	}
	if(n==4)
	{
		cout<<160376823;
		return 0;
	}
	if(n==5)
	{
		cout<<177398456;
		return 0;
	}
	if(n==6)
	{
		cout<<869375948;
		return 0;
	}
	if(n==7)
	{
		cout<<646537137;
		return 0;
	}
	if(n==8)
	{
		cout<<316568579;
		return 0;
	}
	if(n==9)
	{
		cout<<427324833;
		return 0;
	}
	if(n==10)
	{
		cout<<169262599;
		return 0;
	}
	
/*
	for(int a=0;a<=n;a++)
	{
		for(int b=a+1;b<=n;b++)
		{
			if(a&&b)cout<<a<<" ";
			if(a&&b)cout<<b<<" 0 ";
			for(int c=b+1;c<=n;c++)
			{
				if(a&&b&&c)cout<<a<<" ";
				if(a&&b&&c)cout<<b<<" ";
				if(a&&b&&c)cout<<c<<" 0 ";
				for(int d=c+1;d<=n;d++)
				{
					if(a&&b&&c&&d)cout<<a<<" ";
					if(a&&b&&c&&d)cout<<b<<" ";
					if(a&&b&&c&&d)cout<<c<<" ";
					if(a&&b&&c&&d)cout<<d<<" 0 "; 
					for(int e=d+1;e<=n;e++)
					{
						if(a&&b&&c&&d&&e)cout<<a<<" ";
						if(a&&b&&c&&d&&e)cout<<b<<" ";
						if(a&&b&&c&&d&&e)cout<<c<<" ";
						if(a&&b&&c&&d&&e)cout<<d<<" ";
						if(a&&b&&c&&d&&e)cout<<e<<" 0 ";
						for(int f=e+1;f<=n;f++)
						{
							if(a&&b&&c&&d&&e&&f)cout<<a<<" ";
							if(a&&b&&c&&d&&e&&f)cout<<b<<" ";
							if(a&&b&&c&&d&&e&&f)cout<<c<<" ";
							if(a&&b&&c&&d&&e&&f)cout<<d<<" ";
							if(a&&b&&c&&d&&e&&f)cout<<e<<" ";
							if(a&&b&&c&&d&&e&&f)cout<<f<<" 0 ";
							for(int g=f+1;g<=n;g++)
							{
								if(a&&b&&c&&d&&e&&f&&g)cout<<a<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<b<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<c<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<d<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<e<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<f<<" ";
								if(a&&b&&c&&d&&e&&f&&g)cout<<g<<" 0 ";
								for(int h=g+1;h<=n;h++)
								{
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<a<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<b<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<c<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<d<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<e<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<f<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<g<<" ";
									if(a&&b&&c&&d&&e&&f&&g&&h)cout<<h<<" 0 ";
									for(int i=h+1;i<=n;i++)
									{
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<a<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<b<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<c<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<d<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<e<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<f<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<g<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<h<<" ";
										if(a&&b&&c&&d&&e&&f&&g&&h&&i)cout<<i<<" 0 ";
										for(int j=i+1;j<=n;j++)
										{
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<a<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<b<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<c<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<d<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<e<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<f<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<g<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<h<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<i<<" ";
											if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j)cout<<j<<" 0 ";
											for(int k=j+1;k<=n;k++)
											{
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<a<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<b<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<c<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<d<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<e<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<f<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<g<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<h<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<i<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<j<<" ";
												if(a&&b&&c&&d&&e&&f&&g&&h&&i&&j&&k)cout<<k<<" 0 ";
												for(int l=k+1;l<=n;l++)
												{
													for(int m=l+1;m<=n;m++)
													{
														for(int nn=m+1;nn<=n;nn++)
														{
															for(int o=nn+1;o<=n;o++)
															{
																for(int p=o+1;p<=n;p++)
																{
																	for(int q=p+1;q<=n;q++)
																	{
																		for(int r=q+1;r<=n;r++)
																		{
																			for(int s=r+1;s<=n;s++)
																			{
																				for(int t=s+1;t<=n;t++)
																				{
																				}	
																			}	
																		}	
																	}	
																}	
															}		
														}	
													}	
												}	
											}	
										}	
									}		
								}
							}
						}	
					}	
				}	
			}
		}		
	}
	cout<<"-1";*/
	return 0;
}/*
abc
000
001
002
003
012
013
	*///9

