#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,aa[1000];
signed main()
{
	freopen("t4.in","r",stdin);	
	freopen("t4.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cout<<"YES"<<endl;
	return 0;
}

