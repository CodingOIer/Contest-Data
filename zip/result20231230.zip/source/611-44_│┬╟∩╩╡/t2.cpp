#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,k,fn,ans;
int s;
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	fn=n;
	while(1)
	{
		ans+=fn/k;
		fn/=k;
		fn+=n%k;
		n=fn;
		if(n<k)
		{
			if(n+1==k)
			{
				cout<<ans+1;
				return 0;
			}
			else
			{
				cout<<ans;
				return 0;
			}
		}
	}
	return 0;
} 
