#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read(){
	int x=0,y=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-'){y=-1;}c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
	return x*y;
}
inline void write(int s){
	if(s<0)	s=-s,putchar('-');
	if(s>9)	write(s/10);
	putchar(s%10+'0');
	return;
}
const int N=1e5+5,M=1e6+5;
struct node{
	int t,v;
}s[N];
int cmp(node x,node y){return x.v>y.v;}
bool p[N];
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n=read(),k=read();
	for(int i=1;i<=n;i++)s[i].t=read();
	for(int i=1;i<=n;i++)s[i].v=read();
	sort(s+1,s+n+1,cmp);
	int ans=0;
	for(int i=1,sum=0;i<=n&&sum<k;i++){
		if(!p[s[i].t])ans+=s[i].v,sum++,p[s[i].t]=1;
	}
	write(ans);
	return 0;
}
