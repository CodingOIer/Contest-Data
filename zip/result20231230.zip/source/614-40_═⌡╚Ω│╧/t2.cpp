#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ull unsigned long long
inline int read(){
	int x=0,y=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-'){y=-1;}c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
	return x*y;
}
inline void write(int s){
	if(s<0)	s=-s,putchar('-');
	if(s>9)	write(s/10);
	putchar(s%10+'0');
	return;
}
const int N=1e5+5;
int _n[N],cnt,ans[N],cnta,h[N],cnth;
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')_n[++cnt]=c-'0',c=getchar();
	int k=read();
	int n=0;
	if(cnt<=19){
		for(int i=1;i<=cnt;i++)n=n*10+_n[i];
		int Ans=0;
		while(n>=k){
			int sum=n/k;
			Ans+=sum;
			n%=k,n+=sum;
			if(n+1==k)Ans++;
		}
		write(Ans);
		return 0;
	}
	while(1){
		for(int i=1;i<=cnt;i++){
			n=n*10+_n[i];
			if(!n)++cnth;
			if(n>=k)h[++cnth]=n/k,n%=k;
		}
		for(int i=1;i<=cnt;i++){_n[i]=0;}cnt=0;
		for(int i=1;i<=cnth;i++)_n[i]=h[i];
		cnt=cnth;
		int q=cnt;
		while(n){
			_n[q]+=n%10;
			n/=10;
			if(_n[q]>9)_n[q-1]++,_n[q]%=10;
			q--;
		}
		if(!ans[1]){for(int i=1;i<=cnth;i++){ans[++cnta]=h[i];}}
		else{
			for(int i=cnta,j=cnth;i>0&&j>0;i--,j--){
				ans[i]+=h[j];
				if(ans[i]>9)ans[i-1]++,ans[i]%=10;
			}
		}
		for(int i=1;i<=cnth;i++){h[i]=0;}
		cnth=0;
		if(cnt<=10){
			int s=0;
			for(int i=cnt;i>=1;i--)s=s*10+_n[i];
			if(s<k){
				if(s+1==k)ans[cnta]++;
				break;
			}
		}
	}
	for(int i=1;i<=cnta;i++)write(ans[i]);
	return 0;
}
