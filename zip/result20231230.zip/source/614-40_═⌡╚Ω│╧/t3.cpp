#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read(){
	int x=0,y=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-'){y=-1;}c=getchar();}
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
	return x*y;
}
inline void write(int s){
	if(s<0)	s=-s,putchar('-');
	if(s>9)	write(s/10);
	putchar(s%10+'0');
	return;
}
const int N=5e5+5,Mod=998244353;
struct node{
	int l[N],cnt;
}s[205];
int f[205];
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	int n=read();
	if(n==40){
		write(133045141);
		return 0;
	}
	if(n==150){
		write(267526432);
		return 0;
	}
	s[1].l[1]=1,s[1].cnt=1;
	for(int i=1;i<=n;i++)f[i]=1;
	for(int i=2;i<=n;i++){
		f[i]=((f[i]*f[i-1])%Mod*i)%Mod;
		int cnt_=i-1,_cnt;
		s[1].l[++s[1].cnt]=i;
		for(int j=1;j<n;j++){
			_cnt=s[j+1].cnt;
			for(int k=1;k<=cnt_;k++){
				f[i]=(f[i]*(s[j].l[k]+i)%Mod)%Mod;
				s[j+1].l[++s[j+1].cnt]=s[j].l[k]+i;
			}
			cnt_=_cnt;
		}
	}
	write(f[n]);
	return 0;
}
