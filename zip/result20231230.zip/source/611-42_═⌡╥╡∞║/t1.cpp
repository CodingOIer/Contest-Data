#include<bits/stdc++.h>
#define int long long
using namespace std ;
int n , k , ans=0 ;
struct node{
	int a , t ;
}a[123456];
bool cmp(node a,node b){
	return a.a>b.a ;
}
signed main(){
	freopen("t1.in","r",stdin) ;
	freopen("t1.out","w",stdout) ;
	cin >> n >> k ;
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].t) ;
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].a) ;
	sort(a+1,a+1+n,cmp) ;
	for(int i=1;i<=k;i++)
		ans += a[i].a ;
	cout << ans ;
	return 0 ;
}
