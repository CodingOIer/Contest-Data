#include<bits/stdc++.h>
#define int long long
using namespace std ;
int n , k ;
signed main(){
	freopen("t2.in","r",stdin) ;
	freopen("t2.out","w",stdout) ;
	cin >> n >> k ;
	cout << n/(k-1) ;
	return 0 ;
}
