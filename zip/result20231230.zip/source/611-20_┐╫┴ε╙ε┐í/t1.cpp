#include<bits/stdc++.h>
using namespace std;
long long n,k,i,s;
struct d{
	int t,v;
}a[100001];
int cmp(d x,d y){
	if(x.v!=y.v)return x.v>y.v;
	else return x.t<y.t;
}
int main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(i=1;i<=n;i++)cin>>a[i].t;
	for(i=1;i<=n;i++)cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	for(i=1;i<=k;i++)s+=a[i].v;
	cout<<s;
	return 0;
}
