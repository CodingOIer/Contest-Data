#include<bits/stdc++.h>
using namespace std;
char n[100001];
long long k,s,i; 
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	k--;
	for(i=0;i<strlen(n);i++)
	{
		if((s*10+n[i]-'0')>k)
		{
			cout<<(s*10+n[i]-'0')/k;
			s=(s*10+n[i]-'0')%k;
		}
		else s=s*10+n[i]-'0';
	}
	return 0;
}
