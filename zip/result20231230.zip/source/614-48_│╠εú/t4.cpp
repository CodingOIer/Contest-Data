#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
}
ll n,m,k,d;
ll x,y;
ll a[10000000];
void ch(ll x,ll y){
	ll ans=0;
	for(int i=x;i<=x+d;i++){
		ans+=a[i];
	}
	if(ans>=y){
		cout<<"YES"<<endl;
		for(int i=x;i<=x+d;i++){
			if(y==0) break;
			if(a[i]-y>=0) a[i]-=y;
			else y-=a[i],a[i]=0;
		}
	}
	else cout<<"NO"<<endl;
	return ;
}
void gai(ll x,ll y){
   // sort(a+1+x,a+1+x+d);
    for(int i=x;i<=x+d;i++){
    if(a[i]+y<=k) a[i]+=y;
	else y-=a[i],a[i]=k;	
	}
	 cout<<"YES"<<endl;
	return ;
}
int main(){
    in(); 
   cin>>n>>m>>k>>d;
   for(int i=1;i<=n;i++) a[i]=k;
   for(int i=1;i<=m;i++){
   	ll x,y;
   	cin>>x>>y;
   	if(y>=0) ch(x,y);
   	else gai(x,y);
   }

}

