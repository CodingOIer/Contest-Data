#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
}
string s;
ll n,ans; 
ll mod=1e9+7;
int main(){
    in();
    cin>>n>>s;
    for(int i=0;i<n;i++){
    	if(s[i]=='?') ans+=3;
    	else ans++;
	}
    cout<<ans;
}


