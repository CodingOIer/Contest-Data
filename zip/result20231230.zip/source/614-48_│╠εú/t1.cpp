#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
}
ll ans;
struct kk{
	int t,v;
}a[100300];
ll n,k;
int cmp(kk x,kk y){
	return x.v>y.v;  
}
int main(){
    in(); 
    cin>>n>>k;
    for(int i=1;i<=n;i++) cin>>a[i].t;
	for(int i=1;i<=n;i++) cin>>a[i].v;
     sort(a+1,a+n+1,cmp);
     for(int i=1;i<=k;i++) ans+=a[i].v;
	 cout<<ans; 

}

