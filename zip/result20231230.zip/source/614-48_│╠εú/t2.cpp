#include<bits/stdc++.h>
#define ll long long
using namespace std;
void in(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
}
ll n,k;
ll sum,ans;
int main(){
    in();
cin>>n>>k;
cout<<n/(k-1);
}

