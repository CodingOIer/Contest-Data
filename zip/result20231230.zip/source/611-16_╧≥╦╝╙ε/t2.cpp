#include<bits/stdc++.h>
using namespace std;
long long y,x,n,k,f=0;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>k;
	while(n>=k){
		if(f==1)f=0,n--;
		if((n+1)%k==0)f=1,n++;
		x=n/k;
		n%=k;
		y+=x;
		n+=x;
	}
	if(n==k-1)y++;
	cout<<y;
	return 0;
}
