#include<bits/stdc++.h>
using namespace std;
long long n,k,ans;
struct v{int v,t;}a[1000000];
int cmp(v x,v y){
	if(x.v==y.v)return x.t<y.t;
	return x.v>y.v;
}
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>a[i].t;
	for(int i=1;i<=n;i++)cin>>a[i].v;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=k;i++)ans+=a[i].v;
	cout<<ans;
	return 0;
} 
