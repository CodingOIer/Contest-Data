#include<bits/stdc++.h>
using namespace std;
const int mod=1000000007;
long long n,ans,c[1000000];
char a[1000000];
void dfs2(int x){
	if(x==n+1){
		ans++;
		ans%=mod;
		return;
	}
	if(a[x]=='0')dfs2(x+1);
	else{
		if(a[x+2]=='0'&&a[x+1]=='1'&&c[x]!=-1){
			int v=c[x];
			a[x+2]='1';
			c[x+2]=1;
			a[x]='0';
			dfs2(x+1);
			a[x+2]='0';
			c[x+2]=v;
			a[x]='1';
		}
		if(a[x-2]=='0'&&a[x-1]=='1'&&c[x]!=1){
			int v=c[x];
			a[x-2]='1';
			c[x-2]=1;
			a[x]='0';
			dfs2(x-1);
			a[x-2]='0';
			c[x-2]=v;
			a[x]='1';
		}
		dfs2(x+1);
	}
	return;
}
void dfs1(int x){
	if(x==n+1){
		char b[100000];
		for(int i=1;i<=n;i++)b[i]=a[i];
		dfs2(1);
		for(int i=1;i<=n;i++)a[i]=b[i];
		return;
	}
	if(a[x]=='?'){
		a[x]='1';
		dfs1(x+1);
		a[x]='0';
		dfs1(x+1);
		a[x]='?';
	}
	else dfs1(x+1);
}
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	a[0]=a[n+1]=a[n+2]='9';
	dfs1(1);
	cout<<ans;
	return 0;
} 
