#include<bits/stdc++.h>
using namespace std;
long long n,m,k,d,x[1000000],y[1000000],zong[1000000],z,w,v,f;
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=m;i++)cin>>x[i]>>y[i];
	for(int i=1;i<=m;i++){
		zong[x[i]]+=y[i];
		w=0,f=0;
		for(int j=n;j>=1;j--){
			z=k*(d+1)-w; 
			if(z<zong[j]){f=1;break;}
			w+=zong[j]-k;
			if(w<0)w=0;
		}
		if(f==1)cout<<"NO"<<endl;
		else cout<<"YES"<<endl;
	}
	return 0;
} 
