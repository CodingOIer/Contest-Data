#include<bits/stdc++.h>
#define int long long
using namespace std;
string s;
int a[100010],k,now=1,ans[100010];
signed main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>s;
	scanf("%lld",&k);
	k--;
	for(int i=1;i<=s.size();i++) a[i]=s[i-1]-'0';
	while(1){
		int num=0,t=now-1,flg=0;
		while(num<k&&t<s.size()) num=num*10+a[++t];
		if(num<k) break;
		int n=num/k,u=n*k;
		ans[t]=n;
		while(u){
			a[t]-=u%10;
			if(a[t]<0) a[t]+=10,a[t-1]--;
			u/=10,t--;
		}
		while(!a[now]&&now<s.size()) now++;
	}
	int flg=0;
	for(int i=1;i<=s.size();i++){
		if(flg==0&&ans[i]) flg=1;
		if(flg) printf("%lld",ans[i]);
	}
	if(flg==0) printf("0"); 
	return 0;
}
