#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,ans=1;
signed main(){
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	scanf("%lld",&n);
	int mi=(1<<n)-1;
	for(int i=1;i<=mi;i++){
		int li=i,num=0,now=1;
		while(li){
			if(li&1) num+=now;
			now++,li>>=1;
		}
		ans=ans*num%mod;
	}
	printf("%lld",ans);
	return 0;
}
