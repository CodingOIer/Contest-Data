#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,t,v[100010],ans;
bool cmp(int p,int q){
	return p>q;
}
signed main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&t);
	for(int i=1;i<=n;i++) scanf("%lld",&v[i]);
	sort(v+1,v+n+1,cmp);
	for(int i=1;i<=k;i++) ans+=v[i];
	printf("%lld",ans);
	return 0;
}
