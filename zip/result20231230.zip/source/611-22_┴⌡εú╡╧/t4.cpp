#include<bits/stdc++.h>
using namespace std;
int n,m,k,d,a[500010],x,y;
int sqz(int a,int b){
	return a%b==0?a/b:a/b+1;
}
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&d);
	while(m--){
		scanf("%d%d",&x,&y);
		a[x]+=y;
		int now=0,sy,flg=1;
		for(int i=1;i<=n;i++){
			if(i>now) now=i,sy=k;
			if(a[i]<=sy) sy-=a[i];
			else now+=sqz(a[i]-sy,k),sy=sqz(a[i]-sy,k)*k-(a[i]-sy);
			if(now>i+d){
				flg=0;
				break;
			}
		}
		printf(flg?"YES\n":"NO\n");
	}
	return 0;
}
