#include <bits/stdc++.h>
using namespace std;
vector<int> a, c;
vector<int> chu(vector<int> a, int k)
{
	int t = 0;
	vector<int> o;
	for (int i = 0; i < a.size(); i++)
	{
		t = t * 10 + a[i];
		if (t >= k)
		{
			o.push_back(t / k);
			t %= k;
		}
		else
			o.push_back(0);
	}
	reverse(o.begin(), o.end());
	while (o.size() > 1 && o[o.size() - 1] == 0)
		o.pop_back();
	reverse(o.begin(), o.end());
	return o;
}
int main() {
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	string A;
	cin >> A;
	int k;
	cin >> k;
	for (int i = 0; i < A.size(); i++)
		a.push_back(A[i] - '0'); 
	k--;
	c = chu(a, k);
	for (int i = 0; i < c.size(); i++)
		cout << c[i];
	return 0;
}
