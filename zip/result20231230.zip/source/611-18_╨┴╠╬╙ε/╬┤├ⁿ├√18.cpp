#include <stdio.h>
long long a[210];
const int mod = 998244353;
long long ans = 1;
void dfs(int f, int m, int n, long long sum, int step)
{
	if (step == n + 1)
	{
		ans = ans * sum % mod;
		return;
	}
	for (int i = f + 1; i <= m; i++)
	{
		a[step] = i;
		dfs(i, m, n, (sum + i) % mod, step + 1);
	}
}
int main() {
//	freopen("2.txt", "w", stdout);
	for (int n = 35; n <= 35; n++)
	{
		for (int i = 1; i <= n; i++)
		dfs(0, n, i, 0, 1);
		printf("%lld,", ans);
		ans = 1;
	}
	
	return 0;
}
