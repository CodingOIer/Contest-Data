#include <bits/stdc++.h>
using namespace std;
int main() {
//	freopen("t2.in", "r", stdin);
	freopen("t2.in", "w", stdout);
	srand(time(0));
	int n = rand() % 1000000 + 1, k = rand() % n + 1;
	cout << n << ' ' << k << endl;
	return 0;
}
