#include <stdio.h>
#include <queue>
#include <string>
long long sum;
int main() {
	freopen("t2.in", "r", stdin);
	freopen("t2.out", "w", stdout);
	long long n, k;
	scanf("%lld%lld", &n, &k);
	if (n < 0) {
		std::queue<std::string> q;
		while (1)
			q.push({"I AK IOI!"});
	}
	while (n >= k)
		sum += n / k, n = n % k + n / k;
	if (n == k - 1)
		sum++;
	printf("%lld", sum);
	return 0;
}
