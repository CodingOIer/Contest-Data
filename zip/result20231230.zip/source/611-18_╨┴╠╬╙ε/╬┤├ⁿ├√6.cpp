#include <bits/stdc++.h>
using namespace std;
const int N = 1e9 + 7;
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int n;
	string a;
	cin >> n >> a;
	int k = 0;
	for (int i = 0; i < a.size(); i++)
	{
		if (a[i] == '?')
		{
			k++;
		}
	}
	if (k == a.size())
	{
		long long sum = 1;
		for (int i = 1; i <= k; i++)
			sum = (sum * 2) % N;
		sum += sum / k * (k - 1);
		cout << sum;
	}
	return 0;
}
