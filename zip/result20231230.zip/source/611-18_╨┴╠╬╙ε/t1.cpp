#include <stdio.h>
#include <algorithm>
long long sum;
int a[100010], t[100010];
int main() {
	freopen("t1.in", "r", stdin);
	freopen("t1.out", "w", stdout);
	int n, k;
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i++)
		scanf("%d", t + i);
	for (int i = 1; i <= n; i++)
		scanf("%d", a + i);
	std::sort(a + 1, a + 1 + n);
	int s = n - k;
	for (int i = n; i > s; i--)
		sum += a[i];
	printf("%lld", sum);
	return 0;
}
