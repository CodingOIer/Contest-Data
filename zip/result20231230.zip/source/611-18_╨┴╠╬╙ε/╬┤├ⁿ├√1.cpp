#include <bits/stdc++.h>
#include <windows.h> 
using namespace std;
int main() {
	for (int i = 1; i <= 1000; i++){
		system("δ����20.exe");
		system("t2.exe");
		system("δ����21.exe");
		if (system("fc t2.out t3.out"))
		{
			cout << "000";
			return 0;
		}
	}
	return 0;
}
