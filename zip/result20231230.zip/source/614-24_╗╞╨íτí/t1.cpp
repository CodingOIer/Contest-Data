#include<bits/stdc++.h>
using namespace std;
long long n,m,b[1000010],c[1000010],s=0;
struct py{
	long long sj,jz;
}a[100010];
int main()
{
	freopen("t1.in","r",stdin);freopen("t1.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].sj);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].jz); 
	for(int i=1;i<=n;i++) b[a[i].sj]=max(a[i].jz,b[a[i].sj]);
	for(int i=1;i<=n;i++) c[i]=b[i];
	sort(c+1,c+n+1);
	for(int i=n;i>=n-m+1;i--) s+=c[i];
	printf("%lld",s);
	return 0;
}
/*
*/
