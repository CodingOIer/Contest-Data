#include<bits/stdc++.h>
using namespace std;
int n,m,k,d,p,q;
int main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m>>k>>d;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&p,&q);
		if((p+q)%3!=0) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
