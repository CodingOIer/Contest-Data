#include<bits/stdc++.h>
using namespace std;
long long n,m,t=0/*pz*/,s=0/*zjs*/,q=0/*dhd*/;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin.tie(0);
	cout.tie(0);
	//cin>>a>>b;
	cin>>n>>m;
	t=n;
	while(1)
	{
		q=t/m;
		s+=q;
		t=t%m+q;
		if(t<m)	
		{
			if(t+1==m) 
				s++;
			break;
		}
	}
	cout<<s;
	return 0;
}
