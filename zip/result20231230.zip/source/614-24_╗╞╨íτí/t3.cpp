#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	long long n,s=1,f[210];
	cin>>n;
	f[1]=1;
	for(int i=2;i<=200;i++) f[i]=f[i-1]+i;
	if(n<=5)
	{
		if(n==1) cout<<1;
		if(n==2) cout<<6;
		if(n==3) cout<<2160;
		if(n==4) cout<<160376823;
		if(n==5) cout<<177398456;
		return 0;
	}
	for(long long i=1;i<=f[n];i++)
	{
		s=((s%998244353)*(i%998244353))%998244353;
		if(i==n) s=((s%998244353)*(i%998244353))%998244353;
	}
	printf("%lld\n",s);
	return 0;
}
