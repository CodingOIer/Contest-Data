#include<bits/stdc++.h>
#define int long long
using namespace std;
int k,ans,a[100005],b[100005],n;
signed main(){
    freopen("t2.in","r",stdin);
    freopen("t2.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	while(n>=k-1){
		if(n==k-1){
			ans++;
			break;
		}
		int x=n/k;
		ans+=x;
		n%=k;
		n+=x;
	}
	cout<<ans;
	return 0;
}
