#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,ans,t[100005],v[100005],dp[100005];
signed main(){
    freopen("t1.in","r",stdin);
    freopen("t1.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		cin>>t[i];
	for(int i=1;i<=n;i++)
		cin>>v[i];
	sort(v+1,v+n+1);
	for(int i=k;i>=1;i--)
		ans+=v[i];
	cout<<ans;
	return 0;
}
