#include<bits/stdc++.h >
using namespace std;
int n,m,k,d;
int main(){
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>d>>k;
	while(m--){
		cout<<"YES\n";
	}
	return 0;
}
