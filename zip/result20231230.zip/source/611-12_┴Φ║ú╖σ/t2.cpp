#include<bits/stdc++.h >
using namespace std;
long long ans,n,m;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin>>n>>m;
	while(n>=m){
		ans+=n/m;
		n=(n/m)+(n%m);
//		cout<<n<<"\n";
		
	}
	if(n==m-1){
		ans++;
	}
	cout<<ans;
	return 0;
}
