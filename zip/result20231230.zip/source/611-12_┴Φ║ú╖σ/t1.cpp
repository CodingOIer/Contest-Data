#include<bits/stdc++.h >
using namespace std;
struct nodee{
	long long t,v;
}a[114514];
long long n,k,v[114514],sum;
bool cmp(nodee x,nodee y){
	if(x.v==y.v)return x.t<y.t;
	return x.v>y.v;
}
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].t;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i].v;
	}sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n&&k;i++){
		if(!v[a[i].t]){
			v[a[i].t]=1;
			sum+=a[i].v;
			k--;
		}
	}
	cout<<sum; 
	return 0;
}
