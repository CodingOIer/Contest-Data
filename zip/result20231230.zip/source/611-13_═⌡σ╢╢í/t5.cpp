#include<bits/stdc++.h>
#define int long long
#define debug puts("Genshin Impact")
#define inf (int)1e18
#define endl '\n'
using namespace std;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cout << 1;
	return 0;
}
