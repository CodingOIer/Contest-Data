#include<bits/stdc++.h>
#define int long long
#define debug puts("Genshin Impact")
#define inf (int)1e18
#define endl '\n'
using namespace std;
string s;
int a[100010];
int k;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin >> s >> k;
	k--;
	int len=s.size();
	for ( int i = 1 ; i <= len ; i++ )
	{
		a[i]=s[i-1]-'0';
	}
	int t=0;
	int flag=0;
	for ( int i = 1 ; i <= len ; i++ )
	{
		t=t*10+a[i];
		if(t/k!=0||flag)
		{
			cout << t/k;
			flag=1;
		}
		t%=k;
	}
	return 0;
}
