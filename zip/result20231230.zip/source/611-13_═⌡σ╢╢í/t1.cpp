#include<bits/stdc++.h>
#define int long long
#define debug puts("Genshin Impact")
#define inf (int)1e18
#define endl '\n'
using namespace std;
struct abc{
	int a,t;
}a[100010];
int cmp1(abc p,abc q)
{
	return p.a>q.a;
}
int cmp2(abc p,abc q)
{
	return p.t<q.t;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	int n,k;
	cin >> n >> k;
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i].t;
	}
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i].a;
	}
	sort(a+1,a+1+n,cmp1);
	int l=1,r=k,t=1;
	int ans=0;
	while(k&&l<=n)
	{
		sort(a+l,a+r+1,cmp2);
		for ( int i = l ; i <= r ; i++ )
		{
			if(t<=a[i].t&&k)
			{
				k--;
				t++;
				ans+=a[i].a;
			}
		}
		l=r+1;
		r=l+k-1;
	}
	cout << ans;
	return 0;
}
