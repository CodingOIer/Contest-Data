#include<bits/stdc++.h>
#define int long long
#define debug puts("Genshin Impact")
#define inf (int)1e18
#define endl '\n'
using namespace std;
int a[500010];
int n,q,k,d;
struct abc{
	int l,r,cnt,tag;
}t[2000010];
void build(int x,int l,int r)
{
	t[x].l=l;
	t[x].r=r;
	t[x].tag=-1;
	if(l==r)
	{
		t[x].cnt=k;
		return;
	}
	int mid=(l+r)/2;
	build(x<<1,l,mid);
	build(x<<1|1,mid+1,r);
	t[x].cnt=t[x<<1].cnt+t[x<<1|1].cnt;
}
void pd(int x)
{
	if(t[x].l==t[x].r||t[x].tag==-1)
	{
		return;
	}
	t[x<<1].cnt=(t[x<<1].r-t[x<<1].l+1)*t[x].tag;
	t[x<<1].tag=t[x].tag;
	t[x<<1|1].cnt=(t[x<<1|1].r-t[x<<1|1].l+1)*t[x].tag;
	t[x<<1|1].tag=t[x].tag;
	t[x].tag=-1;
}
void upd(int x,int l,int r,int p)
{
	if(l>r)
	{
		return;
	}
	int lf=t[x].l;
	int rt=t[x].r;
	if(l<=lf&&rt<=r)
	{
		t[x].tag=p;
		t[x].cnt=(rt-lf+1)*p;
		return;
	}
	if(rt<l||r<lf)
	{
		return;
	}
	pd(x);
	upd(x<<1,l,r,p);
	upd(x<<1|1,l,r,p);
	t[x].cnt=t[x<<1].cnt+t[x<<1|1].cnt;
}
void upd2(int x,int p,int val)
{
	int lf=t[x].l;
	int rt=t[x].r;
	if(p<=lf&&rt<=p)
	{
		t[x].cnt+=val;
		return;
	}
	if(p<lf||rt<p)
	{
		return ; 
	}
	pd(x);
	upd2(x<<1,p,val);
	upd2(x<<1|1,p,val);
	t[x].cnt=t[x<<1].cnt+t[x<<1|1].cnt;
}
int calc(int x,int l,int r)
{
	int lf=t[x].l;
	int rt=t[x].r;
	if(l<=lf&&rt<=r)
	{
		return t[x].cnt;
	}
	if(rt<l||r<lf)
	{
		return 0;
	}
	pd(x);
	return calc(x<<1,l,r)+calc(x<<1|1,l,r);
}
void check()
{
	upd(1,1,n,k);
	for ( int i = 1 ; i <= n ; i++ )
	{
		int f=a[i];
		int l=i,r=i+d;
		while(l<r)
		{
			int mid=(l+r)/2;
			if(calc(1,i,mid)<f)
			{
				l=mid+1;
			}else{
				r=mid;
			}
		}
		if(calc(1,i,l)<f)
		{
			cout << "NO\n";
			return;
		}
		f-=calc(1,i,l-1);
		upd(1,i,l-1,0);
		upd2(1,l,-f);
	}
	cout << "YES\n";
}
int s[500010];
void check2()
{
	memset(s,0,sizeof(s));
	for ( int i = 1 ; i <= n ; i++ )
	{
		int f=a[i];
		for ( int j = i ; j <= i+d ; j++ )
		{
			f-=(k-s[j]);
			s[j]=k;
			if(f<0)
			{
				s[j]+=f;
				f=0;
				break;
			}
		}
		if(f>0)
		{
			cout << "NO\n";
			return;
		}
	}
	cout << "YES\n";
}
void baoli()
{
	while(q--)
	{
		int x,cnt;
		cin >> x >> cnt;
		a[x]+=cnt;
		check2();
	}
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin >> n >> q >> k >> d;
	if(d<400)
	{
		baoli();
		return 0;
	 } 
	build(1,1,n);
	while(q--)
	{
		int x,cnt;
		cin >> x >> cnt;
		a[x]+=cnt;
		check();
	}
	return 0;
}
