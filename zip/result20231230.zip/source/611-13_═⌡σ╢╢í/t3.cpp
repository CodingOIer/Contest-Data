#include<bits/stdc++.h>
#define int long long
#define debug puts("Genshin Impact")
#define inf (int)1e18
#define endl '\n'
using namespace std;
const int mod=998244353;
int a[300010];
int fp(int x,int p)
{
	int ans=1;
	while(p)
	{
		if(p&1)
		{
			ans=ans*x%mod;
		}
		x=x*x%mod;
		p>>=1;
	}
	return ans;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	int n;
	cin >> n;
	a[1]=1;
	for ( int T = 2 ; T <= n ; T++ )
	{
		for ( int i = (T-1)*T/2 ; i >= 1 ; i-- )
		{
			a[i+T]+=a[i];
			a[i+T]%=(mod-1);
		}
		a[T]++;
	}
	int ans=1;
	for ( int i = 1 ; i <= n*(n+1)/2 ; i++ )
	{
		ans=ans*fp(i,a[i])%mod;
	}
	cout << ans;
	return 0;
}
