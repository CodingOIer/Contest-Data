#include <bits/stdc++.h>
using namespace std;
const int N=1e6+5;
long long n,m,k,d,x,y,len;
struct Point{
	int l,r;
	long long val;
}b[N<<2];
void add(int l,int r,int x){
	b[++len]=(Point){l,r,x};
}
void insert(int x,int l,int r){
	for(int i = 1;i <= len;i++){
		int l1=b[i].l,r1=b[i].r;
		if(l>=l1&&r<=r1){
			if(b[i].val+x<=(r1-l1+1)*k){
				cout << "YES\n";
				b[i].val+=x;
				return;
			}
			else{
				cout << "NO\n";
				return;
			}
		}
		else if(l>=l1){
			if(b[i].val+x<=(r-l1+1)*k){ 
				cout << "YES\n";
				b[i].val+=x;
				b[i].l=l1;
				b[i].r=r;
				return;
			}
			else{
				cout << "NO\n";
				return;
			}
		}
		else if(r<=r1){
			if(b[i].val+x<=(r1-l+1)*k){
				cout << "YES\n";
				b[i].val+=x;
				b[i].l=l;
				b[i].r=r1;
				return;
			}
			else{
				cout << "NO\n";
				return;
			}
		}
	}
	cout << "YES\n";
	add(l,r,x);
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin >> n >> m >> k >> d;
	for(int i = 1;i <= m;i++){
		cin >> x >> y;
		int l=x,r=x+d;
		if(l<=0)l+=n,r+=n;
		insert(y,l,r);
	}
	return 0;
}
