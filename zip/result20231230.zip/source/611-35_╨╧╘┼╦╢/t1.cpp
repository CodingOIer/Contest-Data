#include <bits/stdc++.h>
using namespace std;
const int N=1e6+5; 
long long ans,n,k,t[N],a[N];
int main(){
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> k;
	for(int i = 1;i <= n;i++)cin >> t[i];
	for(int i = 1;i <= n;i++)cin >> a[i];
	sort(a+1,a+1+n);
	for(int i = n;i >= n-k+1;i--)ans+=a[i];
	cout << ans;
	return 0;
}
