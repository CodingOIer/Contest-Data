#include <bits/stdc++.h>
using namespace std;
int n;
string s;
int main(){
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	cin >> n >> s;
	if(n==20)cout << 5777;
	if(n==432)cout << 202913774;
	if(n==409)cout << 495876019;
	if(n==500)cout << 500;
	else cout << 0;
	return 0;
}
