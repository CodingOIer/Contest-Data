#include <bits/stdc++.h>
using namespace std;
long long sum,n,k;
//ʣ��ƿ��=����������+�һ�ʣ��ƿ����
//�������Ҫ�߾���/�;��Ȱ�
//�ҿ�����,��[����]��!
//ans=n/(k-1) 
struct Point{
	int n;
	char a[1000005];
}x,y; 
Point read(){
	Point temp;
	temp.n=0;
	char ch;
	int x=0,w=1;
	while(ch<'0'||ch>'9'){
		if(ch=='-')w=-1;
		ch=getchar();
	}
	if(w==-1)temp.a[++temp.n]='-';
	while(ch>='0'&&ch<='9'){
		temp.a[++temp.n]=ch;
		ch=getchar();
	}
	return temp;
}
//����д��߾���.....
Point cf(Point x,int y){
	Point ans;
 	ans.n=0;
 	long long jw=0;
 	for(int i = x.n;i >= 1;i--){
 		long long num=((x.a[i]-'0')*y)+jw;
		long long upget=num/10;
		num%=10;
		ans.a[++ans.n]=num+'0';
		jw=upget;
	}
	while(jw>0){
		ans.a[++ans.n]=(jw%10)+'0';
		jw/=10;
	}
	for(int i = 1;i <= ans.n/2;i++)swap(ans.a[i],ans.a[ans.n-i+1]);
	return ans;
}
bool cmp(Point x,Point y){
	if(x.n>y.n)return true;
	if(y.n>x.n)return false;
	if(x.n==y.n)
		for(int i = 1;i <= x.n;i++)
			if(x.a[i]<y.a[i])
				return false;
	return true;
}
Point jf(Point x,Point y){
	Point ans;
	ans.n=0;
	long long tw=0;
	for(int i = y.n;i >= 1;i--){
		long long jdz=tw+y.a[i]-'0';
		if(x.a[i]-'0'>=jdz)x.a[i]=x.a[i]-'0'-jdz+'0',tw=0;
		else{
			x.a[i]=x.a[i]-'0'+10-jdz+'0';
			tw=1;
		}
	}
	if(tw>0){
		x.a[y.n+1]=x.a[y.n+1]-'0'-tw+'0';
		if(x.a[y.n+1]-'0'==0&&y.n+1==x.n)x.n--;
	}
	return ans;
}
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	x=read();
	cin >>k;
	if(x.n<=18){
		for(int i = 1;i <= x.n;i++)n=(n<<3)+(n<<1)+x.a[i]-'0';
		cout << n/(k-1);
	}
	else{
		
	}
	return 0;
}
