#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main(){
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m;
	if(n%m==0){
		cout<<n/m;
		return 0;
	}
	if(m==2){
		cout<<n/m+1;
		return 0;
	}
	long long bot=n%m;
	long long dr=n/m;
	bot+=dr;
	while(bot>=m){
		int k=dr;
		dr+=(bot/m);
		bot%=m;
		bot+=(dr-k);
	}
	if(bot+1==m) cout<<dr+1;
	else cout<<dr;
	return 0;
}

