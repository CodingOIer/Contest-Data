#include <bits/stdc++.h>
using namespace std;
const int mod = 1e9 + 7;
int n,ans;
int a[509],qp[509];
char c;
void df() {
	ans++; 
	for(int i=1;i<=n;i++) {
		if(a[i]==1) {
			if(i-2 > 0)
			if(a[i-1]==1 && a[i-2]==0 && i-2 != qp[i]) {
				qp[i-2] = i;
				a[i-2] = 1;
				a[i] = 0;
				df();
				a[i] = 1;
				a[i-2] = 0;
				qp[i-2] = i-2;
			}
			if(i+2<=n)
			if(a[i+1]==1 && a[i+2]==0 && i+2 != qp[i]) {
				qp[i+2] = i;
				a[i+2] = 1;
				a[i] = 0;
				df();
				a[i] = 1;
				a[i+2] = 0;
				qp[i+2] = i+2;
			}
		}
	}
	return ;
}
void dfs(int x) {
	if(x > n) {
		for(int i=1;i<=n;i++) qp[i] = i;
		df();
		ans %= mod;
		return ;
	}
	if(a[x] == 2) {
		a[x] = 0;
		dfs(x+1);
		a[x] = 1;
		dfs(x+1);
		a[x] = 2;
	} else {
		dfs(x+1);
	}
	return ;
}
int main() {
	freopen("t5.in","r",stdin);
	freopen("t5.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++) {
		cin>>c;
		if(c=='1') a[i] = 1;
		else if(c=='0') a[i] = 0;
		else a[i] = 2;
	}
	dfs(1);
	cout<<ans;
	return 0;
} 

