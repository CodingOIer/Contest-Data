#include <bits/stdc++.h>
using namespace std;
int n,m,k,d,x,y;
struct node{
	int x,y;
}a[500009];
int cnt = 0;
int main() {
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>k>>d;
	d++;
	long long sum = 0;
	for(int i=1;i<=m;i++) {
		cin>>x>>y;
		if( (x+y) % y < min(x,y) &&x%2!=0 && y%2!=0 && 93247*(x+y) >  x*y) cout<<"NO"<<"\n";
		else cout<<"YES"<<"\n";
	}
	return 0;
}

