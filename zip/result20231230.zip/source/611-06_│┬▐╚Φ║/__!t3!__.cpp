#include <bits/stdc++.h>
using namespace std;
const long long mod = 998244353; 
int n,csp;
unsigned long long anss,ans=1;
struct node{
	int add[500];
	int sum,cnt;
}a[500];
int q[10009],p;
void dfs(int x) {
	for(int i=a[x].add[a[x].cnt]+1;i<=n;i++) {
		a[x].cnt++;
		a[x].add[a[x].cnt] = i;
		a[x].sum += i;
	//	ans *= a[x].sum;
		q[++p] = a[x].sum;
		//p[++p] = a[x].sum;
	//	cout<<a[x].sum<<" ";
	//	ans %= mod;
	//	anss++;
		dfs(x);
		a[x].sum -= i;
		a[x].cnt--;
	}
	return ;
}
int main() {
	//freopen("t3.in","r",stdin);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	for(n=2;n<=40;n++) {
	//	cout<<n;
	ans = 1;
	for(int i=1;i<=n;i++) a[i].add[1] = i , a[i].cnt = 1 , a[i].sum = i;/* ans *= a[i].sum , ans%=mod;*/
	for(int i=1;i<n;i++) dfs(i);
	sort(q+1,q+1+p);
	for(int i=1;i<=p;i++) cout<<q[i]<<" ";
//	cout<<ans%mod<<"\n\n";
cout<<"\n\n";
	}
	return 0;
}
