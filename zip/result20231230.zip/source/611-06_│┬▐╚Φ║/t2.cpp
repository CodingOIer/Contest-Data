#include <bits/stdc++.h>
using namespace std;
__int128 n,k,ans,anss;
__int128 read() {
	char c = getchar();
	__int128 x=0;
	while(c>='0' && c<='9') x = x*10 + c-'0',c = getchar();
	return x; 
}
void print(__int128 x) {
	while(x>0) {
		cout<<int(x%10);
		x/=10;
	}
	return;
}
int main() {
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	n = read();
	k = read();
	while(1) {
		anss = n/k;
		ans += anss;
		n %= k;
		if(anss + n >= k-1) {
			ans += (anss+n+1) % k;
		} else {
			break;
		}
	}
	print(ans);
	return 0;
}
