#include <bits/stdc++.h>
int main() {
	
	for(int i=1;i<=100000;i++) std::cout<<1;
	while(1);
}
