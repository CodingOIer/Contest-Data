#include <bits/stdc++.h>
using namespace std;
const long long mod = 998244353; 
int n,csp;
unsigned long long anss,ans=1;
struct node{
	int add[500];
	int sum,cnt;
}a[500];
int p[10000],pp;
void dfs(int x) {
	for(int i=a[x].add[a[x].cnt]+1;i<=n;i++) {
		a[x].cnt++;
		a[x].add[a[x].cnt] = i;
		a[x].sum += i;
		ans *= a[x].sum;
		p[++pp] = a[x].sum;
	//	cout<<a[x].sum<<" ";
		ans %= mod;
		anss++;
		dfs(x);
		a[x].sum -= i;
		a[x].cnt--;
	}
	return ;
}
int main() {
	//freopen("t3.in","r",stdin);
	/*ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);*/
	for(n=1;n<=200;n++) {
		ans = 1;
		for(int i=1;i<=n;i++) a[i].add[1] = i , a[i].cnt = 1 , a[i].sum = i , ans *= a[i].sum , ans%=mod;
		for(int i=1;i<n;i++) dfs(i);
		cout<<ans%mod<<",";
	}
	return 0;
}
