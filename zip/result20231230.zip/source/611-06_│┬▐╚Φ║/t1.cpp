#include <bits/stdc++.h>
using namespace std;
int n,k,cnt;
long long ans;
struct node{
	int t,v;
}a[100009];
bool tim[100009];
bool cmp(node a,node b) {
	return a.v != b.v ? a.v > b.v : a.t < b.t;
}
int main() {
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>a[i].t;
	for(int i=1;i<=n;i++) cin>>a[i].v;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++) {
		if(a[i].t>=i && cnt < k && !tim[a[i].t]) {
			ans += a[i].v;
			cnt++;
			tim[a[i].t] = 1;
		}
	}
	cout<<ans;
	return 0;
} 
