#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 998244353;
int n,ans[205],power[205];
signed main()
{
	freopen("t3.out","w",stdout);
	ans[1] = 1,power[0] = 1;
	cin >> n;
	for(int i = 1;i <= n; i++) power[i] = power[i - 1] * 2;
	for(int i = 1;i < power[n]; i++)
	{
		bitset<64> bb(i);
		cout << bb << "\n";
	}
	return 0;
}
