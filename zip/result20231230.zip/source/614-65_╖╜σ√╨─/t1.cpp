#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mx = 1e5 + 5;
int n,k,maxx[mx],ans;
struct b{int id,t,w,v,l;}g[mx];
bool cmp1(b x,b y){return x.w < y.w;}
bool cmp2(b x,b y){return x.t < y.t;}
int read()
{
	int ch = getchar(),f = 0,res = 0;
	while(!isdigit(ch)) f |= ch == '-',ch = getchar();
	while( isdigit(ch)) res = (res << 3) + (res << 1) + (ch ^ 48),ch = getchar();
	return f ? -res : res;
}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	n = read(),k = read();
	for(int i = 1;i <= n; i++) g[i].v = 1,g[i].id = i,g[i].t = read();
	for(int i = 1;i <= n; i++) g[i].w = read();
	sort(g + 1,g + n + 1,cmp1);
	for(int i = 1;i <= n; i++) g[i].l = i;
	sort(g + 1,g + n + 1,cmp2);
	for(int i = n;i >= 1; i--) maxx[i] = max(maxx[i + 1],g[i].l);
	for(int i = 1;i <= n; i++) if((g[i].l > maxx[i + 1] && k >= 1) || k > n - i) ans += g[i].w,k--;
	cout << ans;
	return 0;
}
