#include<bits/stdc++.h>
using namespace std;
const int mx = 1e5 + 5;
int k,n[mx],ln,lk,kk,ans[mx],tot,lst,nn;
string s;
int main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout);
	cin >> s >> k;
	k--;kk = k;while(kk) lk++,kk /= 10;
	ln = s.length();
	for(int i = 1;i <= ln; i++) n[i] = s[i - 1] - '0';
	for(int i = lk;i <= ln; i++)
	{
		nn = 0;
		if(i == lk) for(int j = 1;j <= i; j++) nn = nn * 10 + n[j];
		else nn = n[i];
		nn += lst,lst = 0;
		if(nn < k) lst = nn * 10,tot += (tot == 0 ? 0 : 1);
		else ans[++tot] = nn / k,lst = (nn % k) * 10;
	}
	for(int i = 1;i <= tot; i++) cout << ans[i];
	return 0;
}
