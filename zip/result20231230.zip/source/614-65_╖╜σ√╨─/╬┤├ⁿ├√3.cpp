#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int mod = 998244353;
int ans = 1,n;
void dfs(int x,int s)
{
	if(x > n)
	{
		ans = ans * max(1ll,s) % mod;
		return;
	}
	dfs(x + 1,s + x);
	dfs(x + 1,s);
}
signed main()
{
	for(int i = 1;i <= 50; i++)
	{
		n = i;
		dfs(1,0);
		cout << ans << ",\n";
		ans = 1;
	}
}
