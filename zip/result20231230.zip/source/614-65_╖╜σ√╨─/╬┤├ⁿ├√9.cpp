#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int mod = 998244353;
int ksm(int x,int k)
{
	int res = 1;
	while(k)
	{
		if(k & 1) res = res * x % mod;
		x = x * x % mod,k >>= 1;
	}
	return res;
}	
int n,sum[25000],s,ans = 1,tmp[25000];
signed main()
{
	freopen("t3.in","r",stdin);
	freopen("t3.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n; i++)
	{
		sum[i]++;
		for(int j = 1;j <= s; j++) sum[i + j] += tmp[j];
		for(int j = 1;j <= s + i; j++) tmp[j] = sum[j];
		s += i;
	}
	for(int i = 1;i <= s; i++) ans = (ans * ksm(i,sum[i])) % mod;
	cout << ans;
}
