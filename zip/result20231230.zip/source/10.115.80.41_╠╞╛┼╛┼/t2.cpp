#include <bits/stdc++.h>
#define int long long 
#define cin std::cin
#define cout std::cout
int n,k; 
int ans=-1;
void dfs(int x,int p,int cnt)
{
	if(!p)
	{
		cout<<cnt;
		if(x)return;
		else 
		{
			ans=std::max(ans,cnt);
			return;
		}
	}
	if(p>x)p-=x,x=0;
	if(p<x)
	{
		ans=std::max(ans,cnt);
		return;
	}
	if(p>=k)dfs(x,p/k,cnt+p/k);
	if(p<k)dfs(x+k-p,1,cnt+1);
}
signed main()
{
	freopen("t2.in","r",stdin);
	freopen("t2.out","w",stdout); 
	cin>>n>>k;
	dfs(0,n,0);
	cout<<ans;
	return 0;
}
