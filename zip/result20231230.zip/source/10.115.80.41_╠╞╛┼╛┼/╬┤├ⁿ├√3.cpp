#include <bits/stdc++.h>
#define int long long
#define cin std::cin
#define cout std::cout
int n;
int ans=1;
int mod=998244353;
void dfs(int p,int l,int cnt,int x)
{
	if(l==p)
	{
		ans*=cnt%mod;
		ans%=mod;
		return;
	}
	for(int i=x-1;i>=1;i--)
	{
		dfs(p,l+1,cnt+i,i);
	}
}
signed main()
{
	n=1;
	while(1)
	{
		if(n==41)break;

		ans*=n;
		ans%=mod;
		for(int j=1;j<=n;j++)
		{
			dfs(j,0,n,n);
		}
		
		cout<<','<<ans;
		n++;
	}
		


	return 0;
}
