#include <bits/stdc++.h>
#define int long long 
#define cin std::cin
#define cout std::cout
int n,m,k,d;
const int N=2003;
int a[N];
signed main()
{
	freopen("t4.in","r",stdin);
	freopen("t4.out","w",stdout);
	cin>>n>>m>>k>>d;
	if(k==1)
	{
	
		while(m--)
		{
			int x,y;
			cin>>x>>y;
			if(y<0)
			{
				for(int i=x;i<=x+d;i++)
				{
					if(y==0)break;
					if(a[i])a[i]=0;
				}
				continue;
				puts("YES");
			}
			for(int i=x;i<=x+d;i++)
			{
				if(!a[i])y--;
				if(a[i])
				{
					int f=0;
					for(int j=a[i]+d;j>=a[i];j--)
					{
						if(!a[j])
						{
							a[j]=a[i];
							a[i]=0;
							y--;
							f=1;
							break;
						}
					}
					if(!f)break;
				}
				if(!y)break;
			}
			if(!y)puts("YES");
			else puts("NO");
		}
	}
	return 0;
}
