#include <bits/stdc++.h> 
#define int long long 
#define cin std::cin
#define cout std::cout
int n,k;
struct jb
{
	int t,v;
};
jb a[1003];
int r;
int ans=-1145141919810;
int cmp(jb x,jb y)
{
	return x.t<y.t;
}
int vis[1003];
void dfs(int x,int p,int cnt)
{
	if(p==k)
	{
		ans=std::max(ans,cnt);
		return;
	}
	for(int i=x+1;i<=n;i++)
	{
		dfs(i,p+1,cnt+a[i].v);
	}
}
signed main()
{
	freopen("t1.in","r",stdin);
	freopen("t1.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>a[i].t;
	for(int i=1;i<=n;i++)cin>>a[i].v;
	std::sort(a+1,a+1+n,cmp);
	if(k==1)
	{
		int maxn=-1145141919810;
		for(int i=1;i<=n;i++)
		{
			maxn=std::max(maxn,a[i].v);
		}
		cout<<maxn;
		return 0; 
	}
	for(int i=1;i<=n;i++)
	{
		dfs(i,1,a[i].v);
	}
	cout<<ans;
	return 0;
}
/*
5 2
1 2 4 3 5
3 2 1 2 2
*/ 
