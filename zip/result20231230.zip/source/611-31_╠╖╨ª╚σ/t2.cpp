#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

ll n ;
ll k , ans = 0 , temp = 0 ;

int main ()
{
	 freopen ( "t2.in" , "r" , stdin ) ;
	 freopen ( "t2.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> n >> k ;
	while ( n >= k )
	{
		ans += n / k ;
		n = n % k + n / k - temp ;
//		cout << n << " " << ans << " " << 0 << endl ;
		if ( n < k && ( ( n + ( k - n % k ) ) % k + ( n + ( k - n % k ) ) / k ) - ( k - n % k ) >= 0 )
		{
			temp = k - n % k ;
			n += temp ;
		}
//		cout << n << " " << ans << " " << temp << endl << endl ;
	}
	cout << ans << endl ;
	return 0 ;
}
