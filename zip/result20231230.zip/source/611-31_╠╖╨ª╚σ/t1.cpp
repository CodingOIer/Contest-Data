#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

const ll N = 1e6 + 5 ;

ll n , k , ans ;

struct node
{
	ll t , v ;
	friend bool operator > ( node a , node b )
	{
		return a.v > b.v ;
	}
} c [N] ;

int main ()
{
	 freopen ( "t1.in" , "r" , stdin ) ;
	 freopen ( "t1.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> n >> k ;
	for ( ll i = 0 ; i < n ; i ++ )
	{
		cin >> c [i].t ;
	}
	for ( ll i = 0 ; i < n ; i ++ )
	{
		cin >> c [i].v ;
	}
	sort ( c , c + n , greater <node> () ) ;
	for ( ll i = 0 ; i < k ; i ++ )
	{
		ans += c [i].v ;
	}
	cout << ans << endl ;
	return 0 ;
}
