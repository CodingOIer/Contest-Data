#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

int main ()
{
	 freopen ( "t4.in" , "r" , stdin ) ;
	 freopen ( "t4.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	ll n , m ;
	cin >> n >> m ;
	while ( m -- )
	{
		cout << "YES" << endl ;
	}
	return 0 ;
}
