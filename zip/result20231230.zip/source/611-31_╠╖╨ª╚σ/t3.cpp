#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

const ll N = 205 , mod = 998244353 ;

ll n , ans = 1 ;

ll st [N] ;

bitset <N> choose ;

int main ()
{
	 freopen ( "t3.in" , "r" , stdin ) ;
	 freopen ( "t3.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> n ;
	iota ( st , st + n , 1 ) ;
	for ( ll i = 0 ; i < n ; i ++ )
	{
		choose [i] = 1 ;
	}
	unsigned long long temp ;
	for ( ; choose.any () ; temp = choose.to_ullong() , temp -- , choose = temp )
	{
		ll sum = 0 ;
		for ( ll j = 0 ; j < n ; j ++ )
		{
			if ( choose [j] & 1 )
			{
				sum += st [j] ;
			}
		}
		ans = ans * sum % mod ;
	}
	cout << ans % mod << endl ;
	return 0 ;
}
