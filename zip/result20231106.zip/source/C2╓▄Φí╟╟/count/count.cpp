#include<bits/stdc++.h>
using namespace std;
const int N=1e4+1,V=1e8+1;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int T,q[V];
long long ans[N],n;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	for(int i=2;i<N;++i)
	for(int j=1;j<=i;++j){
		ans[i]+=1ll*q[i*j]*(2-(i==j))*2+(2-(i==j))*(2-(i==j));
		q[i*j]+=2-(i==j);
	}
	ans[1]=1;
	for(int i=2;i<N;++i) ans[i]+=ans[i-1];
	read(T);
	while(T--){
		read(n);
		printf("%lld\n",ans[n]);
	}
	return 0;
}

