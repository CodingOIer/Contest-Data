#include<bits/stdc++.h>
using namespace std;
const int N=1005;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int n,l[N],r[N],c[N];
long long f[1<<20];
inline void sub1(){
	long long sum;
	for(int z=1;z<(1<<n);++z){
		for(int i=1;i<=n;++i){
			if((z>>(i-1))&1){
				sum=0;
				for(int j=l[i];j<=r[i];++j)
					if((z>>(j-1))&1) sum+=c[i];
				sum-=c[i];
				f[z]=max(f[z],f[z^(1<<(i-1))]+sum);
			}
		}
	}
	printf("%lld",f[(1<<n)-1]);
}
long long ans;
inline void sub2(){
	for(int i=1;i<=n;++i)
		for(int j=l[i];j<=r[i];++j){
			if(i==j) continue;
			if(r[j]<i||l[j]>i||c[i]>c[j]) ans+=c[i];
		}
	printf("%lld",ans);
}
int main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	read(n);
	for(int i=1;i<=n;++i) read(l[i]),read(r[i]),read(c[i]);
	if(n<=20) sub1();
	else sub2();
	return 0;
}

