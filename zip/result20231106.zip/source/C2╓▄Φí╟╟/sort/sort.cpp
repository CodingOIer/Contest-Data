#include<bits/stdc++.h>
#define mid ((l+r)>>1)
using namespace std;
const int N=7e5+5;
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int n,root[N],tot,a[N],id[N];
struct Tree{int ls,rs,cnt;}t[N*26];
int build(int l,int r){
	int p=++tot;
	if(l<r){
		t[p].ls=build(l,mid);
		t[p].rs=build(mid+1,r);
	}
	return p;
}
int insert(int pre,int l,int r,int x){
	int p=++tot;
	t[p]=t[pre],++t[p].cnt;
	if(l<r){
		if(x<=mid) t[p].ls=insert(t[pre].ls,l,mid,x);
		else t[p].rs=insert(t[pre].rs,mid+1,r,x);
	}
	return p;
}
int query(int x,int y,int l,int r,int k){
	if(l==r) return l;
	int c=t[t[y].ls].cnt-t[t[x].ls].cnt;
	if(c>=k) return query(t[x].ls,t[y].ls,l,mid,k);
	return query(t[x].rs,t[y].rs,mid+1,r,k-c);
}
long long ans;
void solve(int l,int r){
	if(l==r) return;
	ans+=r-l+1;
	int k=a[query(root[l-1],root[r],1,n,(r-l+1)/2+((r-l+1)&1))];
	if(l<=k-1) solve(l,k-1);
	if(k+1<=r) solve(k+1,r);
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	read(n);
	root[0]=build(1,n);
	for(int i=1;i<=n;++i){
		read(a[i]);
		id[a[i]]=i;
	}
	for(int i=1;i<=n;++i)
		root[i]=insert(root[i-1],1,n,id[i]);
	solve(1,n);
	printf("%lld",ans);
	return 0;
}

