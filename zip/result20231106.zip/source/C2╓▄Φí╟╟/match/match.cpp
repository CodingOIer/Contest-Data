#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5; 
template <typename T> inline void read(T &x) {
    x = 0; char ch = getchar(); int f = 1;
    while (!isdigit(ch) && ch ^ '-') ch = getchar();
    if (ch == '-') f = -1, ch = getchar();
    while (isdigit(ch)) x = (x<<1)+(x<<3)+(ch^48), ch = getchar(); x *= f;
}
int T,n,m,u,v,du[N],ans,pre[N];
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(T);
	while(T--){
		read(n),read(m);
		ans=0;
		while(m--){
			read(u),read(v);
			ans=max(ans,++du[u]);
			ans=max(ans,++du[v]);
			if(du[u]==2&&du[v]==2&&pre[u]==pre[v]) ans=max(ans,3);
			if(!pre[u]) pre[u]=v;
			if(!pre[v]) pre[v]=u;
		}
		printf("%d\n",ans);
		for(int i=1;i<=n;++i) pre[i]=du[i]=0;
	}
	return 0;
}

