#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=1004,MM=1e5+4;
ll f[NN][MM];
string p[MM],t;
int l[NN],r[NN],c[NN];
int main()
{
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	for(int i=1;i<=8;i++)
		t.push_back(i);
	int u=0;
	unordered_map<string,int>mp;
	do
	{
		p[++u]=t;
		mp[t]=u;
	}while(next_permutation(t.begin(),t.end()));
	int n;
	ll ans=0;
	scanf("%d",&n);
	bool flag=true;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&l[i],&r[i],&c[i]);
		if(l[i]!=r[i])
			flag=false;
	}
	if(flag)
	{
		printf("0");
		return 0;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=u;j++)
		{
			ll res=0;
			for(int k=0;k<7;k++)
			{
				if(p[j][k]<p[j][7]&&i-7+k>0&&r[i-7+k]>=i)
					res+=c[i-7+k];
				if(p[j][k]>p[j][7]&&l[i]<=i-7+k)
					res+=c[i];
			}
			t=p[j];
			int px[14];
			for(int k=0;k<7;k++)
			{
				if(p[j][0]<p[j][k+1])
					t[k]=p[j][k+1]-1;
				else
					t[k]=p[j][k+1];
				px[t[k]]=k;
			}
			for(int k=8;k;k--)
			{
				if(k<8)
					t[px[k]]++;
				t[7]=k;
				int id=mp[t];
				f[i+1][id]=max(f[i+1][id],f[i][j]+res);
			}
			if(i==n)
				ans=max(ans,f[i][j]+res);
		}
	printf("%lld",ans);
	return 0;
}
