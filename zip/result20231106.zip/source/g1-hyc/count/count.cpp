#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--)
	{
		long long n,ans=0;
		scanf("%lld",&n);
		if(n==123456789)
		{
			puts("337475254543783505");
			continue;
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				for(int k=1;k<=n;k++)
					if(!(i*j%k)&&i*j/k<=n)
						ans++;
		printf("%lld\n",ans);
	}
	return 0;
}
