#include<bits/stdc++.h>
using namespace std;
typedef long double ld;
const int NN=7e5+4;
int idx=0,root[NN];
struct segment_tree
{
	int lson,rson,sum;
}tr[NN*40];
int update(int u,int l,int r,int id)
{
	int point=++idx;
	tr[point]=tr[u];
	if(l==r)
	{
		tr[point].sum++;
		return point;
	}
	int mid=l+(r-l)/2;
	if(id<=mid)
		tr[point].lson=update(tr[u].lson,l,mid,id);
	else
		tr[point].rson=update(tr[u].rson,mid+1,r,id);
	tr[point].sum=tr[tr[point].lson].sum+tr[tr[point].rson].sum;
	return point;
}
int ask(int u,int v,int l,int r,int k)
{
	if(l==r)
		return l;
	int mid=l+(r-l)/2;
	if(tr[tr[v].lson].sum-tr[tr[u].lson].sum>=k)
		return ask(tr[u].lson,tr[v].lson,l,mid,k);
	else
		return ask(tr[u].rson,tr[v].rson,mid+1,r,k-tr[tr[v].lson].sum+tr[tr[u].lson].sum);
}
long long ans=0;
int n,a[NN],p[NN];
void solve(int l,int r)
{
	if(l>=r)
		return;
	ans+=r-l+1;
	int k=ask(root[l-1],root[r],1,n,(r-l)/2+1);
	solve(l,a[k]-1),solve(a[k]+1,r);
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		p[a[i]]=i;
	}
	for(int i=1;i<=n;i++)
		root[i]=update(root[i-1],1,n,p[i]);
	solve(1,n);
	printf("%lld",ans);
	return 0;
}
