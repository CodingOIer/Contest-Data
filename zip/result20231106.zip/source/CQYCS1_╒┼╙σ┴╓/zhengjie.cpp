#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =7e5+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,a[N],tot,root[N],p[N];
ll cnt;
struct seg{
    int siz,l,r;
}xd[N*50];
inline void build(int x,int l,int r){
    if(l==r)return;
    L=++tot,R=++tot,build(lc),build(rc);
}
inline int modify(int &X,int x,int l,int r,int p){
    xd[++X]=xd[x];
    xd[X].siz++;
    if(l==r)return X;
    int now=X;
    if(p<=mid)xd[now].l=modify(X,lc,p);
    else xd[now].r=modify(X,rc,p);
    return now;
}
inline int query(int X,int x,int l,int r,int k){
    if(l==r)return l;
    int lk=xd[L].siz-xd[xd[X].l].siz;
    if(lk>=k)return query(xd[X].l,lc,k);
    return query(xd[X].r,rc,k-lk);
}
inline void solve(int l,int r){
    if(r-l+1<=1)return;
    cnt+=r-l+1;
    int nowp=query(root[l-1],root[r],1,n,(r-l+2)/2);
    int k=a[nowp];
    solve(l,k-1),solve(k+1,r);
}
int main(){
	freopen("sort2.in","r",stdin);
    freopen("sort2.out","w",stdout);
    n=read();
    rep(i,1,n)a[i]=read(),p[a[i]]=i;
    tot=1,root[0]=1,build(1,1,n);
    rep(i,1,n)root[i]=modify(tot,root[i-1],1,n,p[i]);
    solve(1,n);
    pf(cnt);
	return 0;
}