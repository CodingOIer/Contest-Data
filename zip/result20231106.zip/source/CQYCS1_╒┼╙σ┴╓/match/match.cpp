#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R L|1
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e6+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int T,n,m,h[N],to[N<<1],nxt[N<<1],cnt,dg[N];
bool fl;
inline void add(int a,int b){
    to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,dg[a]++;
}
inline void clear(){
    rep(i,1,n)h[i]=dg[i]=0;
    cnt=fl=0;
}
inline void dfs(int x){
    int sa=0,sb=0;
    e(x)if(!sa)sa=y;
    else sb=y;
    e(sa)if(y==sb)return fl=1,void();
}
int main(){
	freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        for(int i=1,x,y;i<=m;i++)x=read(),y=read(),add(x,y),add(y,x);
        int mx=0;
        rep(i,1,n)mx=max(mx,dg[i]); 
        if(mx<=1||mx>=3){
            pf(mx),putchar('\n'),clear();
            continue;
        }
        rep(i,1,n)if(dg[i]==2){
            dfs(i);
            if(fl){
                mx++;
                break;
            }
        }
        pf(mx),putchar('\n'),clear();
    }
	return 0;
}