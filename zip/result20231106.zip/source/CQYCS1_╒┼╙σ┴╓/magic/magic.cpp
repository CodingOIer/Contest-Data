#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R L|1
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e3+5,M=1.2e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n;
struct node{
    int l,r,c;
}a[N];
ll dp[M];
int p[5];
ll f[105][105][2][2];//左端点为i,右端点为j,左端点是否靠后的先走，右端点是否靠后的先走，只考虑[i,j]内的贡献，能得到的最大贡献
int main(){
	freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    n=read();
    int mx=0;
    rep(i,1,n)a[i].l=read(),a[i].r=read(),a[i].c=read(),mx=max(mx,max({i-a[i].l,a[i].r-i}));
    if(n<=20){
        int S=(1<<n)-1;
        rep(i,0,S)dp[i]=-llf;
        dp[0]=0;
        rep(s,1,S){
            rep(i,1,n)if((s>>i-1)&1){
                ll ex=0;
                rep(j,a[i].l,a[i].r)if(!((s>>j-1)&1))ex+=a[i].c;
                dp[s]=max(dp[s],dp[s^(1<<i-1)]+ex);
            }
        }
        pf(dp[S]),putchar('\n');
    }
    if(mx==0)return cout <<0,0;
    if(mx<=2){
        rep(i,1,n)rep(j,1,n)rep(k,0,1)rep(l,0,1)f[i][j][k][l]=-llf;
        rep(i,1,n)rep(j,0,1)rep(k,0,1)f[i][i][j][k]=0;
        rep(i,1,n-1){
            f[i][i+1][0][0]=f[i][i+1][1][1]=0;
            if(a[i].r>=i+1)f[i][i+1][0][0]+=a[i].c;
            if(a[i+1].l<=i)f[i][i+1][1][1]+=a[i+1].c;
        }
        rep(i,1,n){
            rep(j,1,3)p[j]=i+j-1;
            do{
                ll ex=0;
                rep(id,1,4){
                    rep(nx,id+1,4){
                        int w=p[nx];
                        if(w<=a[p[id]].r&&w>=a[p[id]].l)ex+=a[p[id]].c;
                    }
                }
                int lf=-1,rf=-1;
                rep(id,1,3){
                    if(p[id]<=i+1){
                        if(lf==-1)lf=(p[id]==i+1);
                    }
                    if(p[id]>=i+1){
                        if(rf==-1)rf=(p[id]==i+2);
                    }
                }
/*
5
1 2 1
2 2 3
2 4 7
3 5 4
3 5 5
*/
                f[i][i+2][lf][rf]=max(f[i][i+2][lf][rf],f[i+2][i+2][0][0]+ex);
            }while(next_permutation(p+1,p+4));
            rep(j,i+3,n){
                rep(k,0,1){
                    int l=i+2;
                    rep(m,1,4)p[m]=i+m-1;
                    do{
                        ll ex=0;
                        rep(id,1,4){
                            rep(nx,id+1,4){
                                int w=p[nx];
                                if(w<=a[p[id]].r&&w>=a[p[id]].l){
                                    if(w<=i+1||p[id]<=i+1)
                                    ex+=a[p[id]].c;
                                }
                            }
                        }
                        int lf=-1,rf=-1;
                        rep(id,1,4){
                            if(p[id]<=i+1){
                                if(lf==-1){
                                    lf=(p[id]==i+1);
                                }
                            }else if(rf==-1){
                                rf=(p[id]==i+3);
                            }
                        }
                        f[i][j][lf][k]=max(f[i][j][lf][k],f[l][j][rf][k]+ex);
                    }while(next_permutation(p+1,p+5));
                    rep(m,1,4)p[m]=j-4+m;
                    do{
                        ll ex=0;
                        rep(id,1,4){
                            rep(nx,id+1,4){
                                int w=p[nx];
                                if(w<=a[p[id]].r&&w>=a[p[id]].l){
                                    if(w>j-2||p[id]>j-2)
                                    ex+=a[p[id]].c;
                                }
                            }
                        }
                        int lf=-1,rf=-1;
                        rep(id,1,4){
                            if(p[id]>j-2){
                                if(lf==-1){
                                    lf=(p[id]==j);
                                }
                            }else if(rf==-1){
                                rf=(p[id]==j-2);
                            }
                        }
                        f[i][j][k][lf]=max(f[i][j][k][lf],f[i][j-2][k][rf]+ex);
                    }while(next_permutation(p+1,p+5));
                }
            }
        }
        pf(max({f[1][n][1][1],f[1][n][1][0],f[1][n][0][1],f[1][n][0][0]})),putchar('\n');
    }
	return 0;
}