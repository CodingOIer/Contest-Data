#include <bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e3 + 10, M = 5100, G = 7;

struct node {
	int l, r, c;
} a[N];

int n, m, ans;
int f[M], g[M], p[8];
int h[M][8], to[M][8];

map<int, int> mp;

bool edmer;
signed main() {
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
	m = 1;
	for(int i = 1; i <= G; i++) m *= i;

	n = read();
	for(int i = 1; i <= n; i++) a[i] = { read(), read(), read() };

	for(int i = 1; i <= G; i++) p[i] = i;
	for(int i = 1; i <= m; i++, next_permutation(p + 1, p + G + 1)) {
		int ha = 0;
		for(int j = 1; j <= G; j++) h[i][j] = p[j], ha = ha * (G + 1) + p[j];
		mp[ha] = i;
	}

	for(int i = 1; i <= m; i++) {
		for(int x = 0; x <= G; x++) {
			int ha = (x == 0);
			for(int j = 1; j <= G; j++) {
				if(h[i][j] < G) ha = ha * (G + 1) + h[i][j] + 1;
				if(j == x) ha = ha * (G + 1) + 1;
			}
			to[i][x] = mp[ha];
		}
	}

	for(int i = 1; i <= n; i++) {
		int l = a[i].l, r = a[i].r, c = a[i].c;
		for(int j = 1; j <= m; j++) {
			for(int k = 0; k <= G; k++) {
				int val = f[j];
				for(int x = 1; x <= k; x++) {
					int y = i - h[j][x];
					if(y > 0 and a[y].r >= i) val += a[y].c;
				}
				for(int x = k + 1; x <= G; x++) {
					int y = i - h[j][x];
					if(y > 0 and y >= l) val += c;
				}
				Max(g[to[j][k]], val);
			}
		}
		for(int j = 1; j <= m; j++) f[j] = g[j], g[j] = 0;
	}

	for(int i = 1; i <= m; i++) Max(ans, f[i]);

	write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 