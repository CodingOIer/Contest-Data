#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 7e5 + 10;

struct tree {
    int ls, rs, x;
} t[N * 30];

int n, ans, cnt;
int a[N], p[N], rt[N];

int New(int lr) { t[++cnt] = t[lr]; return cnt; }

void modify(int l, int r, int x, int k, int &lr) {
    lr = New(lr), t[lr].x += k; if(l == r) return; int mid = (l + r) >> 1;
    mid >= x ? modify(l, mid, x, k, t[lr].ls) : modify(mid + 1, r, x, k, t[lr].rs);
}

int query(int l, int r, int k, int x, int y) {
    if(l == r) return l; int mid = (l + r) >> 1;
    if(t[t[y].ls].x - t[t[x].ls].x >= k) return query(l, mid, k, t[x].ls, t[y].ls);
    return query(mid + 1, r, k - t[t[y].ls].x + t[t[x].ls].x, t[x].rs, t[y].rs);
}

void solve(int l, int r) {
    if(l >= r) return;
    int mid = a[query(1, n, (r - l) / 2 + 1, rt[l - 1], rt[r])];
    ans += r - l + 1, solve(l, mid - 1), solve(mid + 1, r);
}

bool edmer;
signed main() {
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) a[i] = read(), p[a[i]] = i;

    for(int i = 1; i <= n; i++) modify(1, n, p[i], 1, rt[i] = rt[i - 1]);

    solve(1, n), write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 