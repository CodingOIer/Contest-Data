#include <bits/stdc++.h>
#define int __int128
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2.1e7;

int n, ans, cnt;
int pri[N / 10], sphi[N], smu[N];

bool vis[N];

map<int, int> sp, sm;

void init() {
    sphi[1] = 1, smu[1] = 1;
    for(int i = 2; i < N; i++) {
        if(!vis[i]) vis[i] = 1, pri[++cnt] = i, sphi[i] = i - 1, smu[i] = -1;
        for(int j = 1; j <= cnt and pri[j] * i < N; j++) {
            int to = i * pri[j]; vis[to] = 1;
            if(!(i % pri[j])) { sphi[to] = sphi[i] * pri[j], smu[to] = 0; break; }
            sphi[to] = sphi[i] * (pri[j] - 1), smu[to] = -smu[i];
        } 
        sphi[i] += sphi[i - 1];
        smu[i] += smu[i - 1];
    } 
}

int Sid(int x) { return x * (x + 1) / 2; }

int Sm(int x) {
    if(x < N) return smu[x];
    if(sm.count(x)) return sm[x];
    int res = 1;
    for(int l = 2, r; l <= x; l = r + 1)
        r = x / (x / l), res -= (r - l + 1) * Sm(x / l);
    return sm[x] = res;
}

int Sp(int x) {
    if(x < N) return sphi[x];
    if(sp.count(x)) return sp[x];
    int res = Sm(x);
    for(int l = 2, r; l <= x; l = r + 1)
        r = x / (x / l), res += (Sid(r) - Sid(l - 1)) * Sm(x / l);
    return sp[x] = res;
}

void solve() {
    n = read(), ans = 0;

    for(int l = 1, r; l <= n; l = r + 1)
        r = n / (n / l), ans += (Sp(r) - Sp(l - 1)) * (n / l) * (n / l);

    ans *= 2, ans -= n * n;
    
    write(ans), putchar('\n');
}

bool edmer;
signed main() {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    init();
    
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 