#include<bits/stdc++.h>
using namespace std;
const int Maxn=7e5+5;
int n,a[Maxn];
int ans;
void Sort(int len){
	if(len<=1)return;
	int mid=a[(len>>1)+(len&1)],cnt=0,cnt1=0;
	vector<int>b,c;
	ans+=len;
	for(int i=1;i<=len;i++)
		if(a[i]<mid)b.push_back(a[i]),++cnt;
		else if(a[i]>mid)c.push_back(a[i]),++cnt1;
	for(int i=0;i<cnt;i++)a[i+1]=b[i];
	Sort(cnt);
	for(int i=0;i<cnt1;i++)a[i+1]=c[i];
	Sort(cnt1);
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	Sort(n);printf("%d",ans);
	return 0;
}

