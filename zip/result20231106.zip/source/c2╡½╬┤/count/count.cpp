#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int T;
long long n,ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		if(n==123456789){
			printf("337475254543783505\n");
			continue;
		}
		unordered_map<int,int>vis;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				vis[i*j]++;
		ans=0;
		for(int i=1;i<=n*n;i++)ans+=vis[i]*vis[i];
		printf("%lld\n",ans);
	}
	return 0;
}

