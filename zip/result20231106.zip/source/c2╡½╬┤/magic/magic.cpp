#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn=1005;
int n;
struct node{int l,r,c;}a[Maxn];
int f[2][Maxn][130],g[2][Maxn][130];
int data[Maxn];
inline void sb(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)data[j]=0;
		int mx=0;
		for(int j=1;j<=n;j++){
			data[j]=mx;
			for(int k=0;k<(1ll<<7);k++)mx=max(mx,f[i&1^1][j][k]),f[i&1][j][k]=0;
		}
		for(int j=n;j;j--){
			data[j]=max(data[j],mx);
			for(int k=0;k<(1ll<<7);k++)mx=max(mx,f[i&1^1][j][k]);
		}
		for(int j=1;j<=n;j++){
			for(int s=0;s<(1ll<<7);s++){
				int sum=0,sum1=0;
				for(int k=max(1ll,j-7);k<j;k++){
					if((s&(1ll<<7-j+k))&&a[k].r>=j)sum+=a[k].c;
					if((!(s&(1ll<<7-j+k)))&&a[j].l>=k)sum1+=a[j].c;
				}
				if(!s)f[i&1][j][s]=data[j]+sum1;
				for(int k=max(1ll,j-7);k<j;k++){
					if(s&(1<<(7-j+k))){
						if(a[k].r>=j)sum-=a[k].c;
						for(int s1=0;s1<(1<<7);s1++){
							int cnt=0;
							for(int k1=max(1ll,j-7);k1<=k;k1++)
								if((s1&(1<<(6-k+k1)))!=(s&(1<<(7-j+k1))))cnt=1;
							if(cnt==1)continue;
							f[i&1][j][s]=max(f[i&1][j][s],g[i&1^1][k][s1]+sum+sum1);
						}
					}
				}
				g[i&1][j][s]=max(g[i&1^1][j][s],f[i&1][j][s]);
			}
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++)ans=max(ans,f[n&1][i][(1<<6)-1]);
	printf("%lld",ans);
}
int dp[Maxn],vis[Maxn];
inline void sub1(){
	for(int s=0;s<(1<<n);s++){
		for(int i=1;i<=n;i++)vis[i]=0;
		for(int i=1;i<=n;i++){
			if(s&(1<<i-1))vis[i]=1;
		}
		for(int i=1;i<=n;i++){
			if(s&(1<<i-1)){
				int sum=0;
				for(int j=a[i].l;j<=a[i].r;j++)sum+=(vis[j]^1)*a[i].c;
				dp[s]=max(dp[s],dp[s^(1<<i-1)]+sum);
			}
		}
	}
	printf("%lld",dp[(1<<n)-1]);
}
signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)scanf("%lld%lld%lld",&a[i].l,&a[i].r,&a[i].c);
	if(n<=21)sub1();
	else{
		int mx=0;
		for(int i=1;i<=n;i++)mx=max(mx,max(i-a[i].l,a[i].r-i));
		if(!mx)printf("0\n"),exit(0);
		mx=0;
		for(int i=1;i<=n;i++)mx=max(mx,a[i].c);
		if(mx==1){
			int ans=0;
			for(int i=1;i<=n;i++)ans+=(a[i].r-i);
			printf("%lld",ans);
		}
	}
	return 0;
}
/*
1 3 1
1 4 1
2 5 1
2 5 1
2 5 1
*/
