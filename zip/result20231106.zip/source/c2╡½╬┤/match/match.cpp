#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
const int Maxn=1e6+5;
int T,n,m;
int u[Maxn],v[Maxn];
int cnt[Maxn],sum[Maxn];
map<pair<int,int>,int>vis;
vector<int>s[Maxn];
inline void solve(){
	for(int i=1;i<=m;i++)vis[{u[i],v[i]}]=0;
	for(int i=1;i<=n;i++)cnt[i]=sum[i]=0,s[i].clear();
	n=read();m=read();
	for(int i=1;i<=m;i++){
		u[i]=read();v[i]=read();
		if(u[i]>v[i])swap(u[i],v[i]);
		if(!vis[{u[i],v[i]}]){
			s[u[i]].push_back(v[i]);
			s[v[i]].push_back(u[i]);
			cnt[u[i]]++;cnt[v[i]]++;
		}
		sum[u[i]]++;sum[v[i]]++;
		vis[{u[i],v[i]}]++;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		if(cnt[i]==2)ans=max(ans,sum[i]+max(vis[{s[i][0],s[i][1]}],vis[{s[i][1],s[i][0]}]));
		else ans=max(ans,sum[i]);
	}
	printf("%d\n",ans);
}
int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read();
	while(T--)solve();
	return 0;
}

