#include<bits/stdc++.h>
using namespace std;
int n;
int l[1011],r[1011],c[1011];
long long f[1011][1<<8];//1还没选中
int K;
inline void Clac(int p)
{
	for(int S = (1 << K) - 1;S >= 0;S--)
	{
		for(int k = 0;k < K;k++) if(S & (1 << k))
		{
			int T = (S ^ (1 << k)),u = p - k;
			long long nans = f[p][S];
			for(int i = 0;i < K;i++) if(T & (1 << i))
			{
				int v = p - i;
				if(l[u] <= v && v <= r[u])
					nans += c[u];
			}
			f[p][T] = max(f[p][T],nans);
		}
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	cin >> n;
	K = min(8,n);
	for(int i = 1;i <= n;i++)
		cin >> l[i] >> r[i] >> c[i];
	Clac(K);
	for(int i = K + 1;i <= n;i++)
	{
		for(int S = 0;S < (1 << K - 1) - 1;S++)
		{
			f[i][S << 1] = f[i][S << 1 | 1] = f[i - 1][S];
			for(int k = 1;k <= K - 1;k++) if(!(S & ((1 << k) - 1)))
			{
				if(l[i - k] <= i && i <= r[i - k]) f[i][S << 1] += c[i - k],f[i][S << 1 | 1] += c[i - k];
			}else{
				if(l[i] <= i - k && i - k <= r[i]) f[i][S << 1] += c[i];
			}
		}
		Clac(i);
	}
	cout << f[n][0];
	return 0;
}