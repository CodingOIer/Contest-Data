#include<bits/stdc++.h>
using namespace std;
vector<int> v[1000011];
bool b[1000011];
int cntv,cnte;
void DFS(int p)
{
	cnte += v[p].size(),cntv++;
	b[p] = 1;
	for(auto i:v[p]) if(!b[i])
		DFS(i);
}
int ans;
int T;
int n,m;
int x,y;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	cin >> T;
	while(T--)
	{
		cin >> n >> m;
		for(int i = 1;i <= n;i++) b[i] = 0,v[i].clear();
		ans = 0;
		for(int i = 1;i <= m;i++)
		{
			cin >> x >> y;
			v[x].push_back(y),v[y].push_back(x);
		}
		for(int i = 1;i <= n;i++) ans = max(ans,(int)v[i].size());
		if(ans < 3)
		{
			for(int i = 1;i <= n;i++) if(!b[i])
			{
				cnte = cntv = 0,DFS(i),cnte >>= 1;
				if(cntv == 3 && cnte == 3)
				{
					ans = 3;
					break;
				}
			}
		}
		cout << ans << "\n";
	}
	return 0;
}