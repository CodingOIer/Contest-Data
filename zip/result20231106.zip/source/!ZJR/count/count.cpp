#include<bits/stdc++.h>
using namespace std;
int T;
long long ask;
const int n = 1000000;
int s[n+11];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	for(int i = 1;i <= n;i++)
	{
		long long cnt = 0;
		int nw;
		int mx = 1;
		while(mx * mx <= i) mx++;
		for(int j = mx - 1;j;j--) if(i % j == 0)
		{
			nw = 1 + (j * j != i);
			s[i / j] += nw * nw + 2 * nw * cnt;
			cnt += nw;
		}
	}
	for(int i = 1;i <= n;i++) s[i] += s[i - 1];
	cin >> T;
	while(T--)
	{
		cin >> ask;
		cout << s[ask] << "\n";
	}
	return 0;
}