#include<bits/stdc++.h>
#define lowbit(x) ((x)&-(x))
using namespace std;
int n;
int a[700011],dui[700011];
int t[1400011];
inline void add(int p,int k)
{
	while(p <= 2 * n)
	{
		t[p] += k;
		p += lowbit(p);
	}
}
inline int find(int k)
{
	if(t[1] == k) return 1;
	int res = 1;
	while(t[res << 1] < k) res <<= 1;
	int sum = t[res];
	for(int ad = (res >> 1);ad;ad >>= 1) if(res + ad <= n && sum + t[res + ad] < k)
		sum += t[res += ad];
	return res + 1;
}
inline void Clear(int l,int r)
{
	for(int i = l;i <= r;i++) add(dui[i],-1);
}
inline void Add(int l,int r)
{
	for(int i = l;i <= r;i++) add(dui[i],1);
}
long long ans;
void Solve(int l,int r)
{
	if(l >= r) return Clear(l,r);
	int len = r - l + 1;
	ans += len;
	int mid = a[find(len + 1 >> 1)];
	Clear(mid,mid);
	int ll = l,lr = mid - 1,rl = mid + 1,rr = r;
	if(lr - ll < rr - rl) swap(ll,rl),swap(lr,rr);
	Clear(rl,rr);
	Solve(ll,lr);
	Add(rl,rr);
	Solve(rl,rr);
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++) cin >> a[i],dui[a[i]] = i;
	Add(1,n);
	Solve(1,n);
	cout << ans;
	return 0;
}