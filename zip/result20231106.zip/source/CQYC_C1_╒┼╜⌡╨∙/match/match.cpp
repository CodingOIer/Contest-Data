#include <bits/stdc++.h>
using namespace std;

int t, n, m, x, y, deg[1000001], tri = 0, step[1000001], q[1000001], front, rear;
vector<int> edges[1000001];
map<int, int> have[1000001];
int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &m);
		tri = 0;
		for (int i = 1; i <= n; ++i) deg[i] = 0, step[i] = 0, edges[i].clear(), have[i].clear();
		int tot = 1;
		while (m--) {
			scanf("%d%d", &x, &y);
			edges[x].push_back(y);
			edges[y].push_back(x);
			deg[x]++; deg[y]++;
			have[x][y] = have[y][x] = 1;
		}
		int ans = 0;
		for (int i = 1; i <= n; ++i) ans = max(ans, deg[i]);
		if (ans < 3) {
			for (int i = 1; i <= n && !tri; ++i) {
				for (auto j : edges[i]) {
					for (auto k : edges[j]) {
						if (have[i][k]) {
							tri = 1;
							break;
						}
					}
					if (tri) break;
				}
				if (tri) break;
			}
		}
		printf("%d\n", max(ans, tri * 3));
	}
}
/*
0(20%)
60(50%)
100(30%) 
���� 60 �� 
*/
