#include <bits/stdc++.h>
using namespace std;

int n, a[700001], b[700001], c[700001];
long long ans = 0, dp[7000001];

void ksort(int l, int r) {
	if (r - l + 1 <= 1 || l >= r) return;
	int pivot = a[(l + r) / 2];
	int al = 0, ag = 0;
	ans += r - l + 1;
	for (int i = 1; i <= n; ++i) {
		if (a[i] < pivot) b[++al] = a[i];
		if (a[i] > pivot) c[++ag] = a[i];
	}
	int tot = 0;
	for (int i = 1; i <= al; ++i) a[++tot] = b[i];
	a[++tot] = pivot;
	for (int i = 1; i <= ag; ++i) a[++tot] = c[i];
	ksort(l, al);
	ksort(al + 2, r);
}

int main() {
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
	scanf("%d", &n);
	bool position_same_value = 1;
	for (int i = 1; i <= n; ++i) a[i] = i, position_same_value &= (a[i] == i);
	if (position_same_value) {
		for (int i = 2; i <= n; ++i) {
			if (i & 1)
				dp[i] = dp[(i / 2)] + dp[(i / 2)] + i;
			else dp[i] = dp[(i / 2) - 1] + dp[(i / 2)] + i; 
		}
		printf("%lld\n", dp[n]);
	} else {
		ksort(1, n);
		printf("%lld\n", ans);
	}
}
/*
10(20%)
20(20%)
30(60%)
���� 24 �� 
*/
