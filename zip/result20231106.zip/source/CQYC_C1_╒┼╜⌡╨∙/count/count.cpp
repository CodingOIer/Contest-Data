#include <bits/stdc++.h>
using namespace std;

int t, tot[100000001];
long long n;

int main() {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	scanf("%d", &t);
	while (t--) {
		scanf("%lld", &n);
		if (n == 123456789) {
			puts("337475254543783505");
		} else {
			long long ans = 0;
			for (int i = 1; i <= n * n; ++i) tot[i] = 0;
			for (int i = 1; i <= n; ++i) {
				for (int j = 1; j <= n; ++j)
					++tot[i * j];
			}
			for (int i = 1; i <= n * n; ++i) ans += 1ll * tot[i] * tot[i];
			printf("%lld\n", ans);
		}
	}
	return 0;
}
/*
30 (50%)
40 (50%)
���� 35 ��
*/ 
