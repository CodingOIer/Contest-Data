#include<bits/stdc++.h>
using namespace std;
int temp[15];
long long maxx=0,n,l[1010],r[1010],c[1010],kk[1010],tf=0;
bool v[15],vv[15];
void dfs(int nw)
{
	if(nw==n+1)
	{
		long long ans=0;
		memset(vv,0,sizeof vv);
		for(int i=1;i<nw;i++)
		{
			vv[temp[i]]=1;
			for(int j=l[temp[i]];j<=r[temp[i]];j++) if(vv[j]==0) ans+=c[temp[i]];
		}
		if(maxx<ans)
		{
			maxx=ans;
			for(int i=1;i<nw;i++) kk[i]=temp[i];
		}
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		if(v[i]==false)
		{
			temp[nw]=i;v[i]=true;
			dfs(nw+1);v[i]=false;
		}
	}
}
int main()
{
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>l[i]>>r[i]>>c[i];
	tf=1;
	for(int i=1;i<=n;i++) if(l[i]!=r[i]) tf=0;
	if(tf==0) dfs(1);
	if(tf==1) cout<<0;
	else cout<<maxx;
	return 0;
}
//5
//1 2 1
//2 2 3
//2 4 7
//3 5 4
//3 5 5

