#include<bits/stdc++.h>
using namespace std;
int t,n,m,tf1=1,tf2=1,tf3=1,temp[5];
int a,b,sum[1001000];
map<int,bool> mp[1001000];
int read()
{
	int x=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while('0'<=c&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	return x*f;
}
void write(int x)
{
    if(x<0)
	{
       	putchar('-');
    	x = -x;
    }
    if(x>9) write(x/10);
    putchar(x%10+'0'),putchar('\n');
	return ;
}
int main()
{
 	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	t=read();
	while(t--)
	{
		n=read(),m=read();
		for(int i=1;i<=n;i++) mp[i].clear(),sum[i]=0;
		for(int i=1;i<=m;i++)
		{
			a=read(),b=read(),mp[a][b]=true,mp[b][a]=true,sum[a]++,sum[b]++;
			if(a!=i||b!=i+1) tf1=0;
			if(a!=i||b!=1) tf2=0;
			if(a!=i||b!=i%n+1) tf3=0;
		}
		if(tf1==1&&n-m==1) {write(min(m,2));continue;}
		if(tf2==1&&n-m==1) {write(m);continue;}
		if(tf3==1&&n==m)
		{
			if(m==3) write(m);
			else write(2);
			continue;
		}
		int ans=0,tf4=0;
		
		for(int i=1;i<=n;i++)
		{
			if(sum[i]!=2) ans=max(ans,sum[i]);
			else if(tf4==0)
			{
				int len=0;
				for(auto tt:mp[i]) if(tt.second) temp[++len]=tt.first;
				if(mp[temp[1]][temp[2]]==true) ans=max(ans,3),tf4=1;
				else ans=max(ans,2);
			}
		}
		write(ans);
	}
}
//1
//10 5
//3 7
//9 5
//6 1
//6 8
//1 7
