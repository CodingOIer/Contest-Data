#include<bits/stdc++.h>
using namespace std;
int t,f[10001000],sum[10001000];
int prime[10001000],cnt=0;
bool isprime[10001000];
long long n,er[66];
long long zong[10001000],ans=0;
void init()
{
	memset(isprime,1,sizeof isprime);
	isprime[1]=0;
	for(int i=1;i<=10000000;i++)
	{
		if(isprime[i]==1) prime[++cnt]=i,sum[i]=1;
		for(int j=1;j<=cnt&&i*prime[j]<=10000000;j++)
		{
			isprime[i*prime[j]]=0;
			sum[i*prime[j]]=sum[i]+1;
			if(i%prime[j]==0)break;
		}
	}
	er[0]=1;
	for(int i=1;i<=62;i++) er[i]=er[i-1]*2;
	return ;
}
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>t;
	init();
	while(t--)
	{
		cin>>n;
		if(n==123456789) {cout<<"337475254543783505";continue;}
		ans=0;
		for(long long i=1;i<=n;i++)
		{
			for(long long j=1;j<=n;j++)
			{
				for(long long k=1;k<=(i*j)/k;k++)
				{
					if((i*j)%k==0&&(i*j)/k<=n)
					{
						if(k!=(i*j)/k) ans++;
						ans++;
					}
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
//10
//1
//12
//123
//1234
//12345
//123456
//1234567
//12345678
//123456789
//1234567890
