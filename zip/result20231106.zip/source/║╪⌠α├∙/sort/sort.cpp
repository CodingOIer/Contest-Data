#include<bits/stdc++.h>
using namespace std;
int n;
long long cnt=0,ans=0;
int f[700700];
bool cmp(int a,int b)
{
	cnt++;
	return a<b;
}
void dfs(int nw)
{
	if(nw<=1) return ;
	ans+=nw;
	int mid=ceil(nw*1.0/2.0);
	dfs(mid-1),dfs(nw-mid-1);
	return ;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>f[i];
	int tf=1;
	for(int i=1;i<=n;i++) if(f[i]!=i) tf=0;
	if(tf==1)
	{
		dfs(n);
		cout<<ans<<"\n";
	}
	else
	{
		sort(f+1,f+n+1,cmp);
		cout<<cnt<<'\n';
	}
	
	return 0;
}
