#include<bits/stdc++.h>
#define int long long
using namespace std;
bool st;
int n,a[700005],id[700005],b[700005],T[20000005],ch[20000005][2],cnt,rt[700005],ans;
bool ed;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &k,int pt,int l,int r,int g){
    k=++cnt;
    T[k]=T[pt];ch[k][0]=ch[pt][0];ch[k][1]=ch[pt][1];
    if(l==r){
        T[k]++;
        return;
    }
    int mid=(l+r)>>1;
    if(g<=mid) add(ch[k][0],ch[pt][0],l,mid,g);
    else add(ch[k][1],ch[pt][1],mid+1,r,g);
    T[k]=T[ch[k][0]]+T[ch[k][1]];
}
inline int find(int k,int pt,int l,int r,int g){
    if(l==r) return l;
    int mid=(l+r)>>1;
    if(g<=(T[ch[k][0]]-T[ch[pt][0]])) return find(ch[k][0],ch[pt][0],l,mid,g);
    return find(ch[k][1],ch[pt][1],mid+1,r,g-(T[ch[k][0]]-T[ch[pt][0]]));
}
inline void solve(int l,int r){
    if(l>r) return;
    if(l!=r) ans+=(r-l+1);
    int d=find(rt[r],rt[l-1],1,n,ceil((double)(r-l+1)/2.0));
    solve(l,a[d]-1);solve(a[d]+1,r);
}
signed main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    // cerr<<(double)(&st-&ed)/1024.0/1024.0<<"MB\n";
    n=read();
    for(int i=1;i<=n;i++) a[i]=read(),id[a[i]]=i;
    for(int i=1;i<=n;i++) add(rt[i],rt[i-1],1,n,id[i]);
    ans=0;
    solve(1,n);
    cout<<ans;
    return 0;
}