#include<bits/stdc++.h>
#define int long long
using namespace std;
const int M=22000000;
int n,ans=0,b[1005],sum[1005],B,N;
vector<int> dp[1005];
double st;
bool v[1005];
struct ok{
    int l,r,c;
}a[1005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int js(){
    for(int i=1;i<=n;i++) sum[i]=0,v[i]=0;
    for(int i=1;i<=n;i++){
        v[b[i]]=1;
        for(int j=a[b[i]].l;j<=a[b[i]].r;j++) if(!v[j]) sum[j]+=a[b[i]].c;
    }
    int d=0;
    for(int i=1;i<=n;i++) d+=sum[i];
    return d;
}
signed main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    st=clock();
    n=read();
    for(int i=0;i<=(n+1);i++) dp[i].resize(M/n);
    for(int i=2,j=1;i<=(M/n);i<<=1,j++) N=i,B=j-1;
    for(int i=1;i<=n;i++) a[i].l=read(),a[i].r=read(),a[i].c=read();
    for(int i=0;i<=n;i++){
        int d=max((int)1,i-B);
        for(int j=0;j<N;j++){
            for(int g=0;(g<=B)&&((i-g)>0);g++){    
                if(!(j&(1<<g))){
                    int w=0;
                    // cout<<i<<" "<<j<<" "<<g<<" "<<max(d,a[i-g].l)<<" "<<a[i-g].r<<"\n";
                    for(int h=max(d,a[i-g].l);h<=a[i-g].r;h++){
                        if(h>i) w++;
                        else if((i-h)==g) continue;
                        else if(!(j&(1<<(i-h)))) w++;
                    }
                    // cout<<i<<" "<<j<<" "<<g<<" "<<w<<"\n";
                    dp[i][j+(1<<g)]=max(dp[i][j+(1<<g)],dp[i][j]+w*a[i-g].c);
                }
            }
        }
        for(int j=0;j<N;j++) dp[i+1][(j<<1)&(N-1)]=max(dp[i+1][(j<<1)&(N-1)],dp[i][j]);
    }
    for(int i=0;i<N;i++) ans=max(ans,dp[n][i]);
    for(int i=1;i<=n;i++) b[i]=i;
    ans=max(ans,js());
    while((((double)clock()-st)/(double)CLOCKS_PER_SEC)<=1.9){
        random_shuffle(b+1,b+1+n);
        ans=max(ans,js());
    }
    cout<<ans;
    return 0;
}