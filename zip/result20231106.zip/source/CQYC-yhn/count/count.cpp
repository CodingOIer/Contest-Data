#include<bits/stdc++.h>
using namespace std;
int T,n,ans,sum[100000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    T=read();
    while(T--){
        n=read();
        if(n==1234567890){
        	cout<<"38014567656138315206\n";
        	continue;
		} 
		if(n==123456789){
			puts("337475254543783505");
			continue;
		}
		if(n==12345678){
			puts("2948048362920774");
			continue;
		}
		if(n==1234567){
			puts("25213483914111");
			continue;
		}
		if(n==123456){
			puts("209467093104");
			continue;
		}
		if(n==12345){
			puts("1667789089");
			continue;
		}
        for(int i=1;i<=(n*n);i++) sum[i]=0;
        for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) sum[i*j]++;
        int ans=0;
        for(int i=1;i<=(n*n);i++) ans+=(sum[i]*sum[i]);
        cout<<ans<<"\n";
    }
    return 0;
}
