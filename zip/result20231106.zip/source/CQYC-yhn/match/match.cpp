#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,n,m,sum[1000005],ans;
bool v[1000005];
pair<int,int> a[1000005];
vector<int> e[1000005],E[1000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        for(int i=1;i<=n;i++) sum[i]=0,e[i].clear(),E[i].clear();
        ans=0;
        for(int i=1;i<=m;i++){
            a[i].first=read(),a[i].second=read();
            sum[a[i].first]++;sum[a[i].second]++;
            e[a[i].first].push_back(a[i].second);
            e[a[i].second].push_back(a[i].first);
            ans=max(ans,max(sum[a[i].first],sum[a[i].second]));
        }
        if(ans<3){
            for(int i=1;i<=m;i++){
                if(sum[a[i].first]>sum[a[i].second]) E[a[i].first].push_back(a[i].second);
                else E[a[i].second].push_back(a[i].first);
            }
            bool f=0;
            for(int i=1;i<=n;i++){
                for(int j=0;j<(int)e[i].size();j++) v[e[i][j]]=1;
                for(int j=0;j<(int)e[i].size();j++){
                    int d=e[i][j];
                    for(int g=0;g<(int)E[d].size();g++){
                        if(v[E[d][g]]){
                            f=1;
                            goto FLAG;
                        }
                    }
                }
                FLAG:
                for(int j=0;j<(int)e[i].size();j++) v[e[i][j]]=0;
                if(f) break;
            }
            if(f) ans=max(ans,(int)3);
        }
        cout<<ans<<"\n";
    }
    return 0;
}