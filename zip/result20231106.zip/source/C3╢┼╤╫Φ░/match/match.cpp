#include<bits/stdc++.h>
using namespace std;
int du[1000005],cnt=0,vis[1000005],flag=0;
vector<int> q[1000005];
void dfs(int x) {
	vis[x]=1;
	cnt++;
	flag+=q[x].size();
	for(int i=0;i<q[x].size();i++) {
		int to=q[x][i];
		if(vis[q[x][i]]) continue;	
		dfs(to);
	}
}
int main() {
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) {
		int n,m,maxn=0;
		scanf("%d %d",&n,&m);
		for(int i=1;i<=m;i++) {
			int x,y;
			scanf("%d %d",&x,&y);
			du[x]++; du[y]++;
			maxn=max(maxn,max(du[x],du[y]));
			q[x].push_back(y);
			q[y].push_back(x);
		} 
		if(maxn==2) {
			for(int i=1;i<=n;i++) {
				if(!vis[i]) {
					cnt=0;flag=0;
					dfs(i);
					if(cnt==3 && flag==6) {
						maxn=3;
						break;
					}
				}
			}
		} 
		printf("%d\n",maxn); 
		for(int i=1;i<=n;i++) du[i]=0;
		for(int i=1;i<=n;i++) vis[i]=0;
		for(int i=1;i<=n;i++) q[i].clear(); 
	}
	return 0;
} 
/*
3
4 1
2 3
1 0
5 4
3 2
5 3
5 1
4 5

*/
