#include<bits/stdc++.h>
#define int long long
using namespace std;
bool sss;
int prime[10005],w[10005],cnt;
bitset<10005> vis; 
int solve() {
	w[1]=1;
	for(int i=2;i<=1e4;i++) {
		if(!vis[i]) {
			prime[++cnt]=i;
			w[i]=i-1;
		}
		for(int j=1;j<=cnt && prime[j]*i<=1e4;j++) {
			vis[i*prime[j]]=1;
			w[i*prime[j]]=w[i]*w[prime[j]];
			if(i%prime[j]==0) {
				w[i*prime[j]]+=w[i];
				break;
			}
		}
	}
}
bool ttt;
signed main() {
	cerr<<(&sss-&ttt)/1024/1024<<"MiB"<<endl;
	solve();
	return 0;
} 
