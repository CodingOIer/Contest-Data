#include<bits/stdc++.h>
#define int long long
using namespace std;
int l[1005],r[1005],c[1005],f[(1<<20)];
signed main() {
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	int n,flag=0;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) {
		scanf("%lld %lld %lld",&l[i],&r[i],&c[i]);
		if(l[i]!=r[i] || r[i]!=i || l[i]!=i) flag=1; 
	}
	if(!flag) {
		printf("0");
		return 0;
	}
	if(n<=20) {
		for(int i=0;i<(1<<n);i++) {
			for(int j=1;j<=n;j++) {
				if(i&(1<<(j-1))) continue;
				int sum=f[i];
				for(int k=l[j];k<=r[j];k++) {
					if(((i&(1<<(k-1))))==0 && k!=j) sum+=c[j];
				}
				f[i|(1<<(j-1))]=max(f[i|(1<<(j-1))],sum);
			}
		}
		printf("%lld",f[(1<<n)-1]);
	} else {
		int ans=0;
		for(int i=1;i<=n;i++) {
			for(int j=l[i];j<=r[i];j++) {
				if(l[j]<=i && i<=r[j] && c[j]>c[i]) ans+=c[j];
			}
		}
		printf("%lld",ans);
	}

	
	return 0;
} 
/*
12
1 3 861
2 4 822
1 3 286
2 4 236
5 6 335
4 9 837
3 11 469
7 12 846
9 12 258
6 12 139
7 12 932
12 12 411

*/
