#include<bits/stdc++.h>
#define int long long
using namespace std;
int num=0;
struct node {
	int x,id;
}a[700005];
bool cmp1(node x,node y) {
	return x.id<y.id;
}
bool cmp2(node x,node y) {
	return x.x<y.x;
}
int al[700005],ar[700005],w=0;
void solve(int l,int r) {
	if(l>=r) return ;
	int mid=a[(l+r)/2].x;
	num+=(r-l+1);
	int cnt1=0,cnt2=0;
	for(int i=l;i<=r;i++) {
		if(a[i].x<mid) al[++cnt1]=a[i].x;
		if(a[i].x>mid) ar[++cnt2]=a[i].x;
	}
	for(int i=l;i<=l+cnt1-1;i++) a[i].x=al[i-l+1];
	for(int i=r-cnt2+1;i<=r;i++) a[i].x=ar[i-(r-cnt2+1)+1];
	solve(l,l+cnt1-1);
	solve(r-cnt2+1,r);
}
signed main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	int n;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i].x),a[i].id=i;	
	solve(1,n);
	printf("%lld",num);
	return 0;
} 
/*


*/
