#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int t;
	scanf("%lld",&t);
	while(t--) {
		int x;
		scanf("%lld",&x);
		int ans=0; 
		for(int i=1;i<=x*x;i++) {
			int sum=0;
			for(int j=1;j*j<=i;j++) {
				if(i%j==0) {
					if(i/j<=x) {
						if(i/j==j) sum++;
						else sum+=2;
					}
				}
			}
			ans+=sum*sum;
		}
		printf("%lld\n",ans);
	}
	return 0;
} 
/*
10
1
12
123
1234
12345
123456
1234567
12345678
123456789
1234567890

*/
