#include <bits/stdc++.h>
using namespace std;
int t, n, m, ans;
unordered_set<int> e[1200000];
void read(int &x)
{
    char c = getchar();
    while (isspace(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
int main()
{
    freopen("match.in", "r", stdin);
    freopen("match.out", "w", stdout);
    read(t);
    while (t--)
    {
        read(n);
        read(m);
        for (int i = 1, x, y; i <= m; i++)
            read(x), read(y), e[x].insert(y), e[y].insert(x);
        ans = 0;
        for (int i = 1; i <= n; i++)
            ans = max(ans, int(e[i].size()));
        for (int i = 1; i <= n; e[i++].clear())
            if (ans < 3)
                for (int j : e[i])
                    for (int k : e[j])
                        if (e[i].count(k))
                            ans = 3;
        printf("%d\n", ans);
    }
    return 0;
}