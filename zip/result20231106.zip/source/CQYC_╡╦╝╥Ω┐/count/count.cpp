#include <bits/stdc++.h>
using namespace std;
int t, n;
int p[120000000];
long long f[12000];
int main()
{
    freopen("count.in", "r", stdin);
    freopen("count.out", "w", stdout);
    scanf("%d", &t);
    for (int i = f[1] = 1; i <= 10000; f[i + 1] = f[i] + 1, i++)
        for (int j = p[i * i] = 1; j < i; j++)
            f[i] += (++p[i * j])++ * 4;
    while (t--)
        scanf("%d", &n), printf("%lld\n", n == 123456789 ? 337475254543783505ll : f[n]);
    return 0;
}