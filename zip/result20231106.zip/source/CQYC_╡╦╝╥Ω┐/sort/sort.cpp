#include <bits/stdc++.h>
using namespace std;
int n;
size_t sort(vector<int> &a)
{
    if (a.size() < 2)
        return 0;
    int x = a[(a.size() - 1) / 2];
    vector<int> l, r;
    for (int i : a)
        if (i != x)
            (i < x ? l : r).push_back(i);
    return a.size() + sort(l) + sort(r);
}
int main()
{
    freopen("sort.in", "r", stdin);
    freopen("sort.out", "w", stdout);
    scanf("%d", &n);
    vector<int> a;
    for (int i = 0, x; i < n; i++)
        scanf("%d", &x), a.push_back(x);
    printf("%zu\n", sort(a));
    return 0;
}