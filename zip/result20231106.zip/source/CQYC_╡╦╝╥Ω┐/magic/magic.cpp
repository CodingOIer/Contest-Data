#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
int n;
int l[6000], r[6000], c[6000];
long long ans;
string s{0, 1, 2, 3, 4, 5, 6};
string from[6000];
__gnu_pbds::gp_hash_table<int, long long> f[6000];
__gnu_pbds::gp_hash_table<string, int> to;
int main()
{
    freopen("magic.in", "r", stdin);
    freopen("magic.out", "w", stdout);
    for (int i = 0; i < 5040; i++)
        to[from[i] = s] = i, next_permutation(s.begin(), s.end());
    scanf("%d", &n);
    f[0][0] = 0;
    for (int i = 1; i <= n; i++)
    {
        scanf("%d%d%d", &l[i], &r[i], &c[i]);
        for (int j = 0; j < 8; j++)
            for (auto [x, y] : f[i - 1])
            {
                string s = from[x];
                for (char &c : s)
                    c += c >= j;
                for (int k = 1; k < 8 && k < i; k++)
                    y += (s[7 - k] < j && r[i - k] >= i) * c[i - k] + (s[7 - k] > j && l[i] <= i - k) * c[i];
                int t = s[0];
                s[0] = j;
                for (char &c : s)
                    c -= c >= t;
                rotate(s.begin(), s.begin() + 1, s.end());
                f[i][to[s]] = max(f[i][to[s]], y);
            }
    }
    for (auto i : f[n])
        ans = max(ans, i.second);
    printf("%lld\n", ans);
    return 0;
}