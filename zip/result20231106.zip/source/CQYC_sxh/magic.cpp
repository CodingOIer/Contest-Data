#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

inline void Max(i64 &x, int y) { (y > x) && (x = y); }

const int N = 1010, K = 3;

int n, o, l[N], r[N], c[N], p[N];
// i64 f[1 << 7], g[1 << 7], ans;
i64 ans;
signed main() {
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
    n = read(), o = (1 << K) - 1;
    For(i, 1, n) l[i] = read(), r[i] = read(), c[i] = read();
    For(i, 1, n) p[i] = i;
    do {
        i64 sum = 0;
        For(i, 1, n) {  
            int tot = 0;
            For(j, 1, i - 1) {
                if (p[j] >= l[p[i]] && p[j] <= r[p[i]]) ++tot;
                sum += (r[p[i]] - l[p[i]] + 1 - tot) * c[i];
            }
        }ans = max(ans, sum);
    }while (next_permutation(p + 1, p + n + 1));
    cout << ans;
    // For(i, 1, 2) {
    //     memcpy(g, f, sizeof g), memset(f, 0, sizeof f);
    //     For(j, 0, o) Max(f[j >> 1], g[j]);
    //     For(j, 1, o) For(k, 0, K - 1) if ((i - (K - 1 - k)) >= 1 && ((j >> k) & 1)) {
    //         cout << "Fuck:"<<bitset<3>(j)<<" "<<i <<" "<<k<<" "<<(i - (K - 1 - k)) <<'\n';
    //         int p = i - (K - 1 - k), L = max(0, k - (p - l[p])), R = max(K - 1, k + r[p] - p);
    //         int tot = 0; For(t, L, R) if (t != k) tot += (i >> t) & 1;
    //         cout << p<<" "<<k<<" "<<L<<" "<<R<<" "<<g[j ^ (1 << k)] <<" "<<tot<<'\n';
    //         Max(f[j], g[j ^ (1 << k)] + c[p] * (r[p] - l[p] + 1 - tot));
    //     }
    //     For(j, 0, o) if (f[j]){
    //         For(k, 0, K - 1) cout << (j >> k & 1);
    //         cout <<" " << f[j] <<"\n";
    //     }
    //     cout << '\n';
    // } 
    // For(i, 0, o) Max(ans, f[i]); cout << ans;
	return 0;
}