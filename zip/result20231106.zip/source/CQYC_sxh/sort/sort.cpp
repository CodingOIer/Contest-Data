#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 7e5 + 1000;

int n, a[N], p[N]; i64 ans;

#define ls(x) (t[x].ls)
#define rs(x) (t[x].rs)
#define mid ((l + r) >> 1)
struct node { int ls, rs, w; }t[N << 5];
int num, root[N];
int New(int x) { return t[++num] = t[x], num; }
void insert(int &x, int p, int l = 1, int r = n) {
    x = New(x), ++t[x].w; if (l == r) return;
    if (mid >= p) insert(ls(x), p, l, mid);
    else insert(rs(x), p, mid + 1, r);
}
int ask(int p, int q, int k, int l = 1, int r = n) {
    if (l == r) return l;;int val = t[ls(q)].w - t[ls(p)].w;
    if (val >= k) return ask(ls(p), ls(q), k, l, mid);
    return ask(rs(p), rs(q), k - val, mid + 1, r);
}
void solve(int l, int r) {
    if (l >= r) return;
    int k = a[ask(root[l - 1], root[r], (r - l + 2) / 2)];
    ans += r - l + 1, solve(l, k - 1), solve(k + 1, r);
}
signed main() {
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
    n = read(); For(i, 1, n) a[i] = read(), p[a[i]] = i;
    For(i, 1, n) insert(root[i] = root[i - 1], p[i]);
    solve(1, n), cout << ans;
	return 0;
}