#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=7e5+5;
int n,a[maxn],b[maxn],ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void f(int l,int r){
    if(r-l<=0)
        return;
    int x=a[l+(r-l)/2];
    int tot1=0,tot2=0;
    for(int i=l;i<=r;i++){
        ++ans;
        if(a[i]<x)
            b[l+(++tot1)-1]=a[i];
        if(a[i]>x)
            b[x+(++tot2)]=a[i];
    }
    b[x]=x;
    for(int i=l;i<=r;i++)
        a[i]=b[i];
    f(l,x-1);
    f(x+1,r);
}
void s(int l,int r){
    if(r-l<=0)
        return;
    int x=l+(r-l)/2;
    ans+=r-l+1;
    s(l,x-1);
    s(x+1,r);
}
signed main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int bj=0;
    n=read();
    for(int i=1;i<=n;i++){
        a[i]=read();
        if(a[i]!=i)
            bj=1;
    }
    if(!bj){
        s(1,n);
        printf("%lld\n",ans);
        return 0;
    }
    f(1,n);
    printf("%lld\n",ans);
    return 0;
}