#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,l[1005],r[1005],c[1005],v[1005],u[1005],ans;
priority_queue<pair<int,int> > q;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int y){
    if(x>n){
        ans=max(ans,y);
        return;
    }
    for(int i=1;i<=n;i++)
        if(!v[i]){
            v[i]=1,u[x]=i;
            int sum=0;
            for(int j=l[i];j<=r[i];j++)
                if(!v[j])
                    sum+=c[i];
            solve(x+1,y+sum);
            v[i]=0;
        }
}
signed main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    int bj=0;
    n=read();
    for(int i=1;i<=n;i++){
        l[i]=read(),r[i]=read(),c[i]=read();
        if(r[i]-l[i]>1)
            bj=1;
    }
    if(!bj){
        puts("0");
        return 0;
    }
    solve(1,0);
    printf("%lld\n",ans);
    return 0;
}