#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e8+5;
int t,n,ans,a[maxn],b[10005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    for(int i=1;i<=1e4;i++){
        for(int j=1;j<=i;j++){
            ans-=a[i*j]*a[i*j];
            a[i*j]++;
            if(i!=j)
                a[i*j]++;
            ans+=a[i*j]*a[i*j];
        }
        b[i]=ans;
    }
    t=read();
    while(t--){
        n=read();
        if(n==123456789){
            puts("337475254543783505");
            return 0;
        }
        printf("%lld\n",b[n]);
    }
    return 0;
}