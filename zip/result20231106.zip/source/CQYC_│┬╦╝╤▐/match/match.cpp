#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
int aa;
int t,n,m,u,v,ans;
vector<int> in[maxn];
map<pair<int,int>,int> ma;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int bb;
signed main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    t=read();
    while(t--){
        ans=0;
        ma.clear();
        n=read(),m=read();
        for(int i=1;i<=n;i++)
            in[i].clear();
        for(int i=1;i<=m;i++){
            u=read(),v=read();
            if(u>v)
                swap(u,v);
            ma[{u,v}]=1;
            in[u].push_back(v);
            in[v].push_back(u);
        }
        for(int i=1;i<=n;i++){
            int x=in[i].size();
            ans=max(ans,x);
            if(x==2&&ans==2){
                u=in[i][0],v=in[i][1];
                if(u>v)
                    swap(u,v);
                if(ma.count({u,v}))
                    ans++;
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}
