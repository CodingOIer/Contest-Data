#include<bits/stdc++.h>
// #define int long long
using namespace std;

const int MAXN=1e6+10;
int ju[MAXN];
vector<int> g[MAXN];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
signed main()
{
   freopen("match.in","r",stdin);
   freopen("match.out","w",stdout);
    int T=read();
    while(T--)
    {
        int n=read(),m=read();  
        for(int i=1;i<=n;i++)
        {
            ju[i]=0;
            g[i].clear();
        }
        for(int i=1;i<=m;i++)
        {
            int u=read(),v=read();
            ju[u]++;
            ju[v]++;
            g[u].push_back(v);
            g[v].push_back(u);
        }
        int ans=0;
        for(int i=1;i<=n;i++)
        {
            ans=max(ans,ju[i]);
        }
        if(ans<3)
        {
            for(int i=1;i<=n;i++)
            {
                if(ju[i]==2)
                {
                    for(int v:g[g[i][0]])
                    {
                        if(v==g[i][1])
                        {
                            ans=3;
                        }
                    }
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}
