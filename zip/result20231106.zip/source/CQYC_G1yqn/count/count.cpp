#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,T;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}

signed main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();
		if(n==20231118)
            puts("8162496362357382");
		if(n==123456789)
			puts("337475254543783505");
		else puts("0");
	}
	return 0;
}
