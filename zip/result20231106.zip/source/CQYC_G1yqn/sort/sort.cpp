#include<bits/stdc++.h>
#define int long long
using namespace std;

const int MAXN=7e5+10;
int n,a[MAXN],pos[MAXN];

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

struct node
{
    int vis[MAXN];
    inline int lowbit(int x)
	{
		return x&-x;
	}
    inline void clear(int x)
	{
		for(;x<=n;x+=lowbit(x))
			vis[x]=0;
	}
    inline void add(int x,int val)
	{
		for(;x<=n;x+=lowbit(x))
			vis[x]+=val;
	}
    inline int query(int x)
	{
		int sum=0;
		for(;x;x-=lowbit(x))
			sum+=vis[x];
		return sum;
	}
}sorrt;

inline int find(int v)
{
    int l=1,r=n;
    while(l<r)
	{
        int mid=l+r>>1;
        if(v<=sorrt.query(mid))
		{
			r=mid;
		}
        else
		{
			l=mid+1;
		}
    }
    return l;
}

inline int solve(int l,int r,bool flag)
{
    if(l>r)return 0;
    if(l==r)
	{
        if(!flag)
		{
			sorrt.add(pos[l],-1);
		}
        return 0;
    }
    if(flag)
	{
		for(int i=l;i<=r;i++)
		{
			sorrt.add(pos[i],1);
		}
	}
    int res=r-l+1;
    int midId=find((r-l)/2+1),mid=a[midId];
    sorrt.add(midId,-1);
    if(r-mid>mid-l)
	{
        for(int i=l;i<mid;i++)
		{
			sorrt.add(pos[i],-1);
		}
        res+=solve(mid+1,r,false);
        res+=solve(l,mid-1,true);
        for(int i=l;i<mid;i++)
		{
			sorrt.clear(pos[i]);
		}
    }
    else
	{
        for(int i=mid+1;i<=r;i++)
		{
			sorrt.add(pos[i],-1);
		}
        res+=solve(l,mid-1,false);
        res+=solve(mid+1,r,true);
        for(int i=mid+1;i<=r;i++)
			sorrt.clear(pos[i]);
    }
    return res;
}

signed main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
    {
    	a[i]=read();
    	pos[a[i]]=i;
	}
    printf("%lld\n",solve(1,n,true));
    return 0;
}
