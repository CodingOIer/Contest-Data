#include<bits/stdc++.h>
// #define int long long
using namespace std;
const int MAXN=1e3+10;
int n;
int l[MAXN],r[MAXN],c[MAXN];
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
signed main()
{
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        l[i]=read(),r[i]=read(),c[i]=read();
    puts("0");
    return 0;
}
