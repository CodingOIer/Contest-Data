#include<bits/stdc++.h>
// #define int long long
#define ll long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1010
#define M 5100
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(ll x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il bool check(int l,int r,int x){
    return l<=x&&r>=x;
}
il void Mx(ll &a,ll b){
    a=max(a,b);
}
int n,l[N],r[N],c[N],id,mp[1700000];
ll dp[N][M],ans;
vector<int> a[M],b;
bool vis[10];
il int Hash(vector<int> &V){
    int res=0;
    for(auto v:V) res=res*7+v;
    return res;
}
il void dfs(int x){
    if(x>6){
        a[++id]=b;mp[Hash(a[id])]=id;return;
    }
    for(int i=0;i<7;++i) if(!vis[i]){
        vis[i]=1;b.pk(i);dfs(x+1);vis[i]=0;b.pop_back();
    }
}
il int turn(vector<int> u,int v){
    int res=0;
    for(int i=0;i<7;++i){
        if(u[i]>=v) ++u[i];
        if(u[i]>u[0]) --u[i];
        if(i){
            // if(u[i]>6) cerr<<"ERROR";
            res=res*7+u[i];
        }
    }
    if(v>u[0]) --v;
    return mp[res*7+v];
}
bool pppp;
signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i){
        l[i]=read();r[i]=read();c[i]=read();
    }
    dfs(0);
    // cerr<<"error";
    // for(int i=1;i<=id;++i){
    //     for(int j=0;j<7;++j) cout<<a[i][j]<<" ";
    //     cout<<"\n";
    // }
    // turn(a[5040],7);return 0;
    for(int i=1;i<=n;++i){
        for(int j=1;j<=id;++j){
            ll res=0;
            if(i-7>0) for(int k=1;k<7;++k)
                if(a[j][k]>a[j][0]&&check(l[i-7],r[i-7],i+k-7)) res+=c[i-7];
            for(int k=0;k<8;++k){
                if(i-7>0&&k>a[j][0]&&check(l[i-7],r[i-7],i)) res+=c[i-7];
                for(int h=max(7-i,max(l[i]+7-i,0));h<=min(6,r[i]+7-i);++h)
                    if(k<=a[j][h]&&check(l[i],r[i],i+h-7)) res+=c[i];
                Mx(dp[i][turn(a[j],k)],dp[i-1][j]+res);
                if(i-7>0&&k>a[j][0]&&check(l[i-7],r[i-7],i)) res-=c[i-7];
                for(int h=max(7-i,max(l[i]+7-i,0));h<=min(6,r[i]+7-i);++h)
                    if(k<=a[j][h]&&check(l[i],r[i],i+h-7)) res-=c[i];
            }
        }
    }
    // cout<<turn(a[5040],0)<<" "<<turn(a[5040],1)<<" "<<turn(a[5039],0)<<" ";
    // cout<<turn(a[5038],3)<<" "<<turn(a[5025],0)<<"\n";
    // cout<<dp[0][5040]<<" "<<dp[1][5040]<<" "<<dp[2][5039]<<" "<<dp[3][5038];
    // cout<<" "<<dp[4][5025]<<" "<<dp[5][4984]<<"\n";
    for(int i=1;i<=id;++i){
        ll res=0;
        for(int j=0;j<7;++j) if(n+j-6>0){
            for(int k=j+1;k<7;++k){
                if(a[i][j]<a[i][k]&&check(l[n+j-6],r[n+j-6],n+k-6)){
                    // if(i==4984) cerr<<"ERROR";
                    res+=c[n+j-6];
                }
                // if(i==4984) cerr<<n+j-6<<" "<<n+k-6<<" "<<l[n+j-6]<<" "<<r[n+j-6]<<" "<<res<<"\n";
            }
        }
        // if(i==4984) cerr<<res<<" ";
        ans=max(ans,res+dp[n][i]);
    }
    // for(int i=0;i<7;++i) cerr<<a[4984][i]<<" ";
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}