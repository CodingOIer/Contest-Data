#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N<<1],to[N<<1],du[N],t;
map<int,bool> mp[N];
il void add(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;mp[u][v]=1;++du[u];
    nxt[++t]=head[v];head[v]=t;to[t]=u;mp[v][u]=1;++du[v];
}
int T,n,m,ans;
il void solve(){
    n=read();m=read();
    while(m--){
        int u=read(),v=read();
        add(u,v);
    }
    for(int i=1;i<=n;++i) ans=max(ans,du[i]);
    if(ans>3){
        write(ans);return;
    }
    for(int i=1;i<=n;++i) for(int j=head[i];j;j=nxt[j]){
        int v=to[j];
        if(pii(du[i],i)>pii(du[v],v)){
            for(int k=head[v];k;k=nxt[k]) if(mp[i].count(to[k])){
                write(3);return;
            }
        }
    }
    write(ans);
}
bool pppp;
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
    T=read();
    while(T--){
        solve();putchar('\n');ans=t=0;
        for(int i=1;i<=n;++i){
            head[i]=du[i]=0;mp[i].clear();
        }
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}