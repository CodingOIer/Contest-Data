#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 700010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,a[N],rt[N],ans,id[N];
struct SEG{
	#define ls (son[w][0])
	#define rs (son[w][1])
	#define ls_ (son[w_][0])
	#define rs_ (son[w_][1])
	int sum[N*50],id,son[N*50][2];
	il void push_up(int w){
		sum[w]=sum[ls]+sum[rs];
	}
	il void build(int &w,int l,int r){
		w=++id;
		if(l==r) return;
		int mid=(l+r)>>1;
		build(ls,l,mid);build(rs,mid+1,r);
	}
	il void update(int &w,int w_,int l,int r,int x,int k){
		w=++id;sum[w]=sum[w_];ls=ls_;rs=rs_;
		if(l==r){
			sum[w]+=k;return;
		}
		int mid=(l+r)>>1;
		if(x<=mid) update(ls,ls_,l,mid,x,k);
		else update(rs,rs_,mid+1,r,x,k);
		push_up(w);
	}
	il int query(int w,int w_,int l,int r,int k){
		if(!w||!w_) return 0;
		if(l==r) return l;
		int mid=(l+r)>>1;
		if(sum[ls]-sum[ls_]>=k) return query(ls,ls_,l,mid,k);
		return query(rs,rs_,mid+1,r,k-sum[ls]+sum[ls_]);
	}
} ST;
il void solve(int l,int r){
	if(r-l+1<=1) return;
	int cnt=ST.sum[rt[r]]-ST.sum[rt[l-1]];
	int tmp=ST.query(rt[r],rt[l-1],1,n,(cnt+1)/2);
	// cerr<<l<<" "<<r<<" "<<tmp<<"\n";
	ans+=cnt;
	solve(l,a[tmp]-1);solve(a[tmp]+1,r);
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
    n=read();
	for(int i=1;i<=n;++i){
		a[i]=read();id[a[i]]=i;
	}
	ST.build(rt[0],1,n);
	for(int i=1;i<=n;++i){
		ST.update(rt[i],rt[i-1],1,n,id[i],1);
	}
	solve(1,n);
	write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}