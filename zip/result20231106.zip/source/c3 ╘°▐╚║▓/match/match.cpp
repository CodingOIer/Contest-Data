#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
int n,m,ans;
vector<int>q[1000005];
vector<int>gg[1000005];
int in[10005];
priority_queue<pair<int,int> >qu;
void dfs(int x,int yuan,int k){
	if(k==3&&x==yuan) ans=max(ans,3);
	else if(k==3) ans=max(ans,2);
	if(k==3) return;
	if(x==yuan&&k!=0) return;
	for(int i=0;i<q[x].size();i++){
		if(i!=q[x][i]-1&&q[x][i]==q[x][i+1]) continue;
		dfs(q[x][i],yuan,k+1);
	}
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	int T=read();
	while(T--){
		ans=0;
		n=read(),m=read();
		if(m==0){
			cout<<0<<endl;
			continue;
		}
		memset(in,0,sizeof(in));
		bool flag1=1,flag2=1;
		for(int i=1;i<=n;i++) q[i].clear();
		for(int i=1;i<=m;i++){
			int u=read(),v=read();
			if(u==v) continue;
			q[u].push_back(v);
			q[v].push_back(u);
			if(v!=u%n+1) flag1=0;
			if(u!=1) flag2=0;
		}
		for(int i=1;i<=n;i++){
			sort(q[i].begin(),q[i].end());
			for(int j=0;j<q[i].size();j++){
				if(q[i][j]!=q[i][j+1]) in[i]++;
			}
		}
		if(flag2) ans=max(ans,m);
		
		for(int i=1;i<=n;i++){
			ans=max(ans,in[i]);
		}
		if(ans<3)
			for(int i=1;i<=n;i++){
				dfs(i,i,0);
			}
		cout<<ans<<endl;
	}
	return 0;
}
