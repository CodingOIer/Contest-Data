#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
int n,m,ans;
struct XXX{
	int l,r,c,id;
}z[10005];
int gg[1003];
bool vis[1003];
bool bk[12];
bool cmp(XXX a,XXX b){
	int gg1=a.r-a.l,gg2=b.r-b.l;
	if(b.id>=a.l&&b.id<=a.r) gg1++;
	if(a.id>=b.l&&a.id<=b.r) gg2++;
	return gg1*a.c>gg2*b.c;
}
void dfs(int x){
	if(x==n+1){
		memset(bk,0,sizeof(bk));
		int sum=0;
		for(int i=1;i<=n;i++){
			int k=gg[i];
			bk[k]=1;
			for(int j=z[k].l;j<=z[k].r;j++){
				if(!bk[j]) sum+=z[k].c;
			}
		}
		ans=max(ans,sum);
		return;
	}
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		vis[i]=1;
		gg[x]=i;
		dfs(x+1);
		vis[i]=0;
		gg[x]=0;
	}
}
signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		z[i].l=read(),z[i].r=read(),z[i].c=read();
		z[i].id=i;
	}
	if(n<=10){
		dfs(1);
		cout<<ans;
		return 0;
	}
	sort(z+1,z+n+1,cmp);
	for(int i=1;i<=n;i++){
		for(int j=i;j<n;j++){
			int gg1=z[j].r-z[j].l,gg2=z[j+1].r-z[j+1].l;
			if(z[j+1].id>=z[j].l&&z[j+1].id<=z[j].r) gg1++;
			if(z[j].id>=z[j+1].l&&z[j].id<=z[j+1].r) gg2++;
//			cout<<gg1<<" "<<gg2<<endl;
			if(gg1*z[j].c<gg2*z[j+1].c){
				XXX k=z[j];
				z[j]=z[j+1];
				z[j+1]=k;
			}
			else break;
		}
//		cout<<endl;
	}
	int sum=0;
	for(int i=1;i<=n;i++){
//		cout<<z[i].id<<" ";
		bk[z[i].id]=1;
		for(int j=z[i].l;j<=z[i].r;j++){
			if(!bk[j]) sum+=z[i].c;
		}
	}
	cout<<sum;
	return 0;
}
