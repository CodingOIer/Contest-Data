#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
int n,m,ans;
int dp[1000005];
signed main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int T=read();
	while(T--){
		n=read();
		int ans=0;
		if(n<=10000){
			for(int i=1;i<=n;i++){
				for(int t=1;t<=n;t++){
					//j<=n*t/i/(t/__gcd(i)
					ans+=min(n/(t/__gcd(i,t)),((n*t/i)/(t/__gcd(i,t))));
					
				}
			}
			printf("%lld\n",ans);
			continue;
		}
	}
	return 0;
}
