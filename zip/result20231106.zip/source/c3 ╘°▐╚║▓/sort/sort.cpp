#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*f;
}
int n,m,ans;
int a[1000005];
int g[1000005];
int jyh[1000005];
int al[1000005],ag[1000005];
void sort(int k[],int x){
	if(x==1||x==0) return;
	int gg=k[(x+1)/2];
	int totl=0,totg=0;
//	ans+=x;
	for(int i=1;i<=x;i++){
		if(k[i]<gg) al[++totl]=k[i];
		else if(k[i]>gg) ag[++totg]=k[i];
//		else if(k[i]==gg) cout<<k[i]<<" ";
	}
	ans+=x;
	if(totl)sort(al,totl);
	if(totg)sort(ag,totg);
}
signed main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read();
	bool flag=1;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		if(a[i]!=i) flag=0;
	}
	if(flag){
		for(int i=2;i<=n;i++){
			jyh[i]=i+jyh[(i-1)/2]+jyh[i/2];
		}
		cout<<jyh[n];
		return 0; 
	}
	sort(a,n);
	cout<<ans;
	return 0;
}
