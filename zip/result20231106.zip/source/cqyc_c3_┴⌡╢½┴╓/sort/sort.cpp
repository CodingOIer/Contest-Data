#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T u=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){u=u*10+(c^48);c=getchar();}
        return f?-u:u;
    }}in;int stk[39],tp;
    template<typename T>void out(T u,char c=0){
        if(u<0)putchar('-'),u=-u;
        do stk[tp++]=u%10;while(u/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 700005;
int a[N],p[N];
int n;

class persistent_segtree{
    private:
        struct{int l,r,w;} tr[N*60];
        int rt[N],idx;

        void pushup(int x){tr[x].w = tr[tr[x].l].w+tr[tr[x].r].w;}
    public:
        int& operator [] (int x){return rt[x];}
        void build(int &u,int l = 1,int r = n){
            u = ++idx;
            if(l==r)
                return;
            int mid = (l+r)>>1;
            build(tr[u].l,l,mid);
            build(tr[u].r,mid+1,r);
        }
        void insert(int &u,int v,int l,int r,int p){
            tr[u=++idx] = tr[v];
            if(l==r){
                tr[u].w++;
                return;
            }
            int mid = (l+r)>>1;
            if(p<=mid)
                insert(tr[u].l,tr[v].l,l,mid,p);
            else
                insert(tr[u].r,tr[v].r,mid+1,r,p);
            pushup(u);
        }
        int query(int u,int v,int l,int r,int p){
            if(l==r)
                return l;
            int mid = (l+r)>>1,w = tr[tr[v].l].w-tr[tr[u].l].w;
            if(p<=w)
                return query(tr[u].l,tr[v].l,l,mid,p);
            return query(tr[u].r,tr[v].r,mid+1,r,p-w);
        }
        int solve(int l,int r){
            if(l>=r)
                return 0;
            int w = tr[rt[r]].w-tr[rt[l-1]].w;
            int p = query(rt[l-1],rt[r],1,n,w/2+w%2);
            return w+solve(l,a[p]-1)+solve(a[p]+1,r);
        }
}tr;

signed main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    n = in;
    tr.build(tr[0]);
    for(int k=1;k<=n;k++)
        p[a[k]=in] = k;
    for(int k=1;k<=n;k++)
        tr.insert(tr[k],tr[k-1],1,n,p[k]);
    out(tr.solve(1,n));
    return 0;
}