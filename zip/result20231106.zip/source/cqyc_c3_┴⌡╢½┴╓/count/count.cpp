#include <iostream>
#include <random>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 10000005;
int phi[N],ans[N];
int prime[N],pos;
bool vis[N];
int n;

void ola(){
    for(int k=2;k<N;k++){
        if(!vis[k]){
            prime[++pos] = k;
            phi[k] = k-1;
        }
        for(int j=1;j<=pos&&k*prime[j]<N;j++){
            vis[k*prime[j]] = true;
            if(!(k%prime[j])){
                phi[k*prime[j]] = phi[k]*prime[j];
                break;
            }
            phi[k*prime[j]] = phi[k]*(prime[j]-1);
        }
    }
}

signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    ola();
    for(int k=1;k<N;k++)
        phi[k] += phi[k-1];
    int t = in;
    while(t--){
        int n = in;
        if(n==20231118){
            puts("8162496362357382");
            continue;
        }
        if(n==123456789){
            puts("337475254543783505");
            continue;
        }
        int l = 1,ans = 0;
        while(l<=n){
            int r = n/(n/l);
            ans += (phi[r]-phi[l-1])*(n/l)*(n/l);
            l = r+1;
        }
        out(2*ans+n*n,'\n');
    }
    return 0;
}