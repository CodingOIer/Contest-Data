#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 1000005;
vector<int> g[N];
int d[N];
int n,m;

int main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    int t = in;
    while(t--){
        int n = in,m = in;
        for(int k=1;k<=n;k++){
            d[k] = 0;
            g[k].clear();
        }
        for(int k=1;k<=m;k++){
            int a = in,b = in;
            d[a]++,d[b]++;
            g[a].push_back(b);
            g[b].push_back(a);
        }
        int ans = 0;
        for(int k=1;k<=n;k++)
            ans = max(ans,d[k]);
        if(ans<3)
            for(int k=1;k<=n;k++)
                if(d[k]==2)
                    for(int v:g[g[k][0]])
                        if(v==g[k][1])
                            ans = 3;
        out(ans,'\n');
    }
    return 0;
}