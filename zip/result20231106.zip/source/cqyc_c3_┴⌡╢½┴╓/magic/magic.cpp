#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 1005;
int l[N],r[N],c[N];
bool vis[N];
int n;

int main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    n = in;
    for(int k=1;k<=n;k++)
        l[k] = in,r[k] = in,c[k] = in;
    vector<int> a(n);
    for(int k=0;k<n;k++)
        a[k] = k+1;
    int ans = 0;
    do{
        for(int k=1;k<=n;k++)
            vis[k] = false;
        int res = 0;
        for(int k:a){
            vis[k] = true;
            for(int j=l[k];j<=r[k];j++)
                if(!vis[j])
                    res += c[k];
        }
        ans = max(ans,res);
    }while(next_permutation(a.begin(),a.end()));
    out(ans);
    return 0;
}