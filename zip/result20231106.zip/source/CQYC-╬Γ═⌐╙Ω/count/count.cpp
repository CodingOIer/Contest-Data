#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

bool sss;
const int Maxn=1e8+10,Mx=1000;
int T,N,f[Mx+10],g[Maxn];
bool ttt;

void Init(){
    For(i,1,Mx){
        f[i]=f[i-1];
        For(j,1,i){
            int s=i*j;
            f[i]-=g[s]*g[s];
            if(i^j) g[s]+=2;
            else ++g[s];
        }
        For(j,1,i) f[i]+=g[i*j]*g[i*j];
    }
}

signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    Init(); T=read(); 
    while(T--){
        N=read();
        if(N==123456789) puts("337475254543783505");
        else write(f[N]),pc('\n');
    }
    return 0;
}
/*
g++ count.cpp -o count -O2
./count
*/