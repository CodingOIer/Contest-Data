#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=7e5+10;
int N,x,Ans;
vector<int> A;

void Sort(vector<int> B){
    int l=B.size();
    if(l<=1) return;
    int mid=B[(l+1)/2-1]; vector<int> L,R;
    For(i,0,l-1){
        ++Ans;
        if(B[i]<mid) L.pb(B[i]);
        if(B[i]>mid) R.pb(B[i]);
    }
    Sort(L),Sort(R);
}

int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    N=read(); For(i,1,N) x=read(),A.pb(x);
    Sort(A); write(Ans);
    return 0;
}
/*
g++ sort.cpp -o sort -O2
./sort
*/