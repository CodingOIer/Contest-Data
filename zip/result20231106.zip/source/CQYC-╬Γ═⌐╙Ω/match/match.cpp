#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int T,N,M,in[Maxn],top,hed[Maxn],cnt;
bool flag,Vis[Maxn];
struct node{int nxt,to;}G[Maxn<<1];

void Clear(){ For(i,1,N) in[i]=0,Vis[i]=0,hed[i]=0; cnt=0; flag=0; }

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void DFS(int x,int p){
    ++top; Vis[x]=1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        if(Vis[y]){ if(top==3) return flag=1,void(); }
        else DFS(y,x); 
        if(flag) return;
    }
    --top;
}

void Solve(){
    N=read(),M=read();
    For(i,1,M){
        int u=read(),v=read();
        ++in[u],++in[v],Addedge(u,v),Addedge(v,u);
    }
    int Mx=0;
    For(i,1,N) Mx=max(Mx,in[i]);
    if(Mx>=3){
        write(Mx),pc('\n');
        Clear(); return;
    }
    top=0;
    For(i,1,N) if(!Vis[i]) DFS(i,0);
    if(flag) Mx=3;
    write(Mx),pc('\n');
    Clear();
}

int main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    T=read(); while(T--) Solve();
    return 0;
}
/*
g++ match.cpp -o match -O2
./match
*/