#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1010,Mxk=(1<<20)+10;
int N,L[Maxn],R[Maxn],C[Maxn],Ans,X[Maxn],f[Mxk];
bool flag;

int main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    N=read();
    For(i,1,N){
        L[i]=read(),R[i]=read(),C[i]=read();
        if(max(i-L[i],R[i]-i)>0) flag=1;
        if(N<=30) For(j,L[i],R[i]) X[i]|=(1<<(j-1));
    }
    if(!flag) pc('0'),exit(0);
    int M=(1<<N)-1;
    For(S,0,M) For(j,1,N) if(!(S&(1<<(j-1)))){
        int T=S^(1<<j-1),c=(R[j]-L[j]+1)-__builtin_popcount(X[j]&T);
        f[T]=max(f[T],f[S]+c*C[j]);
    }
    write(f[M]);
    return 0;
}
/*
g++ magic.cpp -o magic -O2
./magic
*/