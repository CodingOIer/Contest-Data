#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1010,Q=14,M=1<<(Q+1);
bool Begin;
int n,l[N],r[N],c[N];
ll dp[M],cpy[M];
bool End;
inline void Max(ll &x,ll y) {x=x>y?x:y;}
int main()
{
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    cerr<<(&Begin-&End)/1024/1024<<"MB\n";
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d%d",l+i,r+i,c+i);
    int P=M-1;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<=P;j++)
            cpy[j]=dp[j],dp[j]=0;
        for(int j=0,L,R,ned;j<=P;j++)
        {
            ned=P&(j<<1|1);
            Max(dp[j],cpy[ned]);
            for(int k=0,T;k<=Q;k++)
            {
                if((T=i-(Q-k))<1) continue;
                if(!(j>>k&1)&&l[T]>=max(1,i-Q)&&r[T]<=i)
                {
                    L=P>>(i-l[T]+1);
                    R=P>>(i-r[T]);
                    ned=j&(L^R);
                    Max(dp[1<<k|j],dp[j]+1ll*(r[T]-l[T]-__builtin_popcount(ned))*c[T]);
                }
            }
        }
    }
    printf("%lld\n",dp[P]);
    cerr<<"[Runtime]"<<1.0*clock()/1000/1000<<"s\n";
    fclose(stdin);fclose(stdout);
    return 0;
}
