#include<bits/stdc++.h>
#define vi vector<int>
using namespace std;
typedef long long ll;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=5e7+10;
int n;
bool subtask=1;
ll ans;
vi pri;
void build(int l,int r)
{
    if(r-l<=1) return;
    int mid=(l+r)>>1;
    ans+=(r-l+1);
    build(l,mid-1);
    build(mid+1,r);
}
void solve(vi a)
{
    int sz=a.size();
    if(sz<=1) return;
    vi l,r;int mid=a[(1+sz)/2-1];
    for(int i=0,x;i<sz;i++)
    {
        x=a[i];++ans;
        if(x<mid) l.push_back(x);
        if(x>mid) r.push_back(x);
    }
    solve(l);solve(r);
}
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    n=read();
    for(int i=1,x;i<=n;i++)
    {
        x=read(),pri.push_back(x);
        if(i!=x) subtask=0;
    }
    if(subtask) build(1,n);
    else solve(pri);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
