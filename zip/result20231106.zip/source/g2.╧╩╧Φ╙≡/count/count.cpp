#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 Int;
inline ll read()
{
    ll x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
int stk[40],tp;
inline void write(Int x)
{
    if(!x) return puts("0"),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
    putchar('\n');
}
const int N=1e6+10;
int T,cnt,mu[N],prime[N];
bool vis[N];
ll n;
Int ans;
void shai()
{
    mu[1]=1;
    for(int i=2;i<N;i++)
    {
        if(!vis[i]) prime[++cnt]=i,mu[i]=-1;
        for(int j=1,tmp;j<=cnt&&(tmp=i*prime[j])<N;j++)
        {
            vis[tmp]=1;
            if(!(i%prime[j])) break;
            mu[tmp]=-mu[i];
        }
    }
}
int main()
{
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    shai();
    T=read();
    while(T--)
    {
        n=read();ans=0;
        for(int x=1;x<=n;x++)
        {
            if(!mu[x]) continue;
            for(int i=1;i<=n/x;i++)
                ans+=mu[x]*(n/x/i)*(n/x/i)*(i-1);
        }
        ans*=2;
        ans+=(Int)n*n;
        write(ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
