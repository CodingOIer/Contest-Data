#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/hash_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
int stk[10],tp;
inline void write(int x)
{
    if(!x) return puts("0"),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
    putchar('\n');
}
const int N=1e6+10;
int T,n,m,ans,in[N],tx[N];
vector<int>E[N];
gp_hash_table<int,bool>edge[N];
inline void Max(int &x,int y) {x=x>y?x:y;}
bool cmp(int x,int y) {return in[x]==in[y]?x>y:in[x]>in[y];}
int main()
{
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    T=read();
    int x,y;
L:  while(T--)
    {
        ans=0;
        n=read(),m=read();
        for(int i=1;i<=n;i++)
            in[i]=0,E[i].clear(),edge[i].clear();
        for(int i=1;i<=m;i++)
        {
            x=read(),y=read();
            if(x==y||edge[x][y]) continue;
            edge[x][y]=edge[y][x]=1;
            ++in[x],++in[y];
            E[x].push_back(y);
            E[y].push_back(x);
        }
        for(int i=1;i<=n;i++) Max(ans,in[i]);
        if(ans>2) {write(ans);continue;}
        if(m==n-1) {write(ans);continue;}
        for(int i=1;i<=n;i++)
            sort(E[i].begin(),E[i].end(),cmp);
        for(int i=1;i<=n;i++)
            tx[i]=lower_bound(E[i].begin(),E[i].end(),i,cmp)-E[i].begin();
        for(int i=1;i<=n;i++)
        {
            if(tx[i]==in[i]) continue;
            for(int j=tx[i];j<in[i];j++)
            {
                y=E[i][j];
                if(tx[y]==in[y]) continue;
                for(int k=tx[y];k<in[y];k++)
                    if(edge[i][E[y][k]]) {puts("3");goto L;}
            }
        }
        write(ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
