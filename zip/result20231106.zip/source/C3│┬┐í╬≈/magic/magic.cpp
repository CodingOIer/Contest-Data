#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e3+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,ans;
int dp[1100000];
bool vis[N];
struct Node{
	int l,r,c,id;
}a[N];
bool cmp(Node a,Node b){return a.c>b.c;}

int Max(int a,int b){return a>b?a:b;}

int tr[N];
int lb(int x){return x&(-x);}
void add(int x,int k){for(;x<=n;x+=lb(x))tr[x]+=k;}
int sum(int x){int res=0;for(;x;x-=lb(x))res+=tr[x];return res;}

signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
		a[i].l=read(),a[i].r=read(),a[i].c=read(),a[i].id=i;
	if(n<=20){
		for(int i=1;i<(1<<n);i++){
			int x=i,id=0;
			while(x){
				id++;
				if(x&1) add(id,1);
				x>>=1;
			}
	
			x=i,id=0;
			while(x){
				id++;
				if(x&1){
					int ad=(a[id].r-a[id].l+1-(sum(a[id].r)-sum(a[id].l-1)))*a[id].c;
					dp[i]=Max(dp[i],dp[i-(1<<(id-1))]+ad);
				}
				x>>=1;
			}
	
			x=i,id=0;
			while(x){
				id++;
				if(x&1) add(id,-1);
				x>>=1;
			}		
		}
		printf("%lld",dp[(1<<n)-1]);		
	}
	else{
		sort(a+1,a+1+n,cmp);
		ans=0;
		for(int i=1;i<=n;i++){
			add(a[i].id,1);
			int ad=(a[i].r-a[i].l+1-(sum(a[i].r)-sum(a[i].l-1)))*a[i].c;
			ans=ans+ad;
		}
		printf("%lld",ans);
	}
	return 0;
}
