#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=7e5+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,a[N],b[N],ans;
void solve(int l,int r){
	if(l>=r) return;
	ans=ans+(r-l+1);

	int mid=l+(r-l+1)/2+((r-l+1)&1)-1;
	
	int r1=l-1,r2;
	
	for(int i=l;i<=r;i++) if(a[i]<a[mid]) b[++r1]=a[i];
		
	r2=r1;
	for(int i=l;i<=r;i++) if(a[i]>a[mid]) b[++r2]=a[i];
		
	for(int i=l;i<=r2;i++) a[i]=b[i];
	
	solve(l,r1);
	solve(r1+1,r2);
}
signed main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	solve(1,n);
	printf("%lld",ans);
	return 0;
}
