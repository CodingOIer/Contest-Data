#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
//bool SSS;
int T,n,ans,sum;
int cnt[100000001];
bitset<100000001> vis;
//bool TTT;
signed main(){	
//	cerr<<(&SSS-&TTT)/1024/1024<<"Mib\n";
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		if(n==123456789){
			printf("337475254543783505\n");
			continue;
		}
		ans=sum=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				int v=i*j;
				if(i^j) ans+=cnt[v],sum+=vis[v];
				else sum+=cnt[v],vis[v]=1; 
				cnt[v]++;
			}
		}
		printf("%d\n",ans*2+sum+n*n);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				int v=i*j;
				if(!vis[v]) continue;
				cnt[v]=0;
				vis[v]=0; 
			}
		}
	}
	return 0;
}
