#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e6+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int T,n,m,ans;
int u[N],v[N],in[N];
int head[N],to[N<<1],nxt[N<<1],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}
bool vis[N];
int Max(int a,int b){return a>b?a:b;}
void clean(){
	tot=0;
	for(int i=1;i<=n;i++) head[i]=in[i]=0;
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	T=read();
	while(T--){
		n=read(),m=read();
		for(int i=1;i<=m;i++){
			u[i]=read(),v[i]=read();
			in[u[i]]++,in[v[i]]++;
			add(u[i],v[i]);
			add(v[i],u[i]);
		}
		ans=0;
		for(int i=1;i<=m;i++){
			int U=u[i],V=v[i],res=0;
			if(Max(in[U],in[V])==2){
				for(int j=head[U];j;j=nxt[j])
					vis[to[j]]=1;
				for(int j=head[V];j;j=nxt[j])
					res|=vis[to[j]];
				for(int j=head[U];j;j=nxt[j])
					vis[to[j]]=0;					
			}
			ans=Max(ans,Max(in[U],in[V])+res);		
		}
		printf("%lld\n",ans);
		clean();
	}
	return 0;
}
