#include<bits/stdc++.h>
#define int long long 
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int p[10000005],tot;
int vis[10000005];
int phi[10000005];
unordered_map<int,__int128>ans_phi;
void Init(int n){
	phi[1]=1;
	for(int i=2;i<=n;i++){
		if(vis[i]==0){
			p[++tot]=i;
			vis[i]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=tot;j++){
			if(i*p[j]>n)break;
			vis[i*p[j]]=p[j];
			if(vis[i]==p[j]){
				phi[i*p[j]]=phi[i]*p[j];
				break;
			}
			phi[i*p[j]]=phi[i]*(p[j]-1);
		}
	}
	for(int i=2;i<=n;i++)phi[i]+=phi[i-1];
}
inline __int128 S_phi(int n){
	if(n<=1e7)return phi[n];
	if(ans_phi[n])return ans_phi[n];
	__int128 ans=n*(n+1)/2;
	for(int l=2,r;l<=n;l=r+1){
		r=n/(n/l);
		ans-=(__int128)(r-l+1)*S_phi(n/l);
	}
	return ans_phi[n]=ans;
}
__int128 sol(int x){
	__int128 ans=0;
	for(int l=2,r;l<=x;l=r+1){
		r=x/(x/l);
		ans+=(__int128)(S_phi(r)-S_phi(l-1))*(x/l)*(x/l);
	}
	return (__int128)(ans*2+(__int128)x*x);
}
signed main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	Init(1e7);
	int T;
	read(T);
	while(T--){
		int x;
		read(x);
		write(sol(x)),putch('\n');
	}
	flush();
	return 0;
}
