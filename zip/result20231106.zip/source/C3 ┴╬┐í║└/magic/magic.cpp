#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,ans;
int l[1005],r[1005],c[1005];
int f[(1<<22)+5];
int s[1005];
int tree[1005];
void add(int x){
	while(x<=n){tree[x]++;x+=x&(-x);}
}
int query(int y){
	int sum=0;
	while(y){sum+=tree[y];y-=y&(-y);}
	return sum;
}
int ask(int l,int r){
	return query(r)-query(l-1);
}
void check(){
	for(int i=1;i<=n;i++)tree[i]=0;
	int sum=0;
	for(int i=1;i<=n;i++){
		add(s[i]);
		sum+=(r[s[i]]-l[s[i]]+1-ask(l[s[i]],r[s[i]]))*c[s[i]];
	}
	ans=max(ans,sum);
}
void sol(){
	int x=rand()%n+1;
	int y=rand()%n+1;
	swap(x,y);
	check();
}
signed main(){
	srand(20081216);
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>l[i]>>r[i]>>c[i];
	if(n>20){
		for(int i=1;i<=n;i++)s[i]=i;
		for(int i=1;i<=10000;i++)sol();
		cout<<ans;
		return 0;
	}
	for(int i=1;i<(1<<n);i++){
		for(int j=1;j<=n;j++){
			if((i>>(j-1))&1){
				int sum=0;
				for(int k=l[j];k<=r[j];k++){
					if((i>>(k-1))&1)continue;
					sum+=c[j];
				}
				f[i]=max(f[i],f[i-(1<<(j-1))]+sum);
			}
		}
	}
	cout<<f[(1<<n)-1];
	return 0;
}
