#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n;
int a[700005],b[700005];
int root[700005],tot;
struct node{
	int s,l,r,ls,rs;
}tree[20000008];
void modify(int x,int y,int W){
	tree[y].s=tree[x].s+1;
//	cout<<tree[y].s<<" "<<tree[y].l<<" "<<tree[y].r<<"////"<<tree[x].s<<" "<<tree[x].l<<" "<<tree[x].r<<" "<<x<<endl;
	if(tree[y].l==tree[y].r)return;
	int mid=(tree[y].l+tree[y].r)/2;
	if(W<=mid){
//		if(tree[x].ls==0){
//			tree[x].ls=++tot;
//			tree[tot]=(node){0,tree[x].l,mid,0,0};
//		}
		tree[y].rs=tree[x].rs;
		tree[y].ls=++tot;
		tree[tot]=(node){0,tree[y].l,mid,0,0};
		modify(tree[x].ls,tree[y].ls,W);
	}else{
//		if(tree[x].rs==0){
//			tree[x].rs=++tot;
//			tree[tot]=(node){0,mid+1,tree[x].r,0,0};
//		}
		tree[y].ls=tree[x].ls;
		tree[y].rs=++tot;
		tree[tot]=(node){0,mid+1,tree[y].r,0,0};
		modify(tree[x].rs,tree[y].rs,W);
	}
}
int query(int x,int L,int R){
//	cout<<tree[x].l<<" "<<tree[x].r<<":"<<tree[x].s<<"{{{"<<x<<"///"<<tree[x].ls<<" "<<tree[x].rs<<endl;
	if(x==0)return 0;
	if(L<=tree[x].l&&tree[x].r<=R)return tree[x].s;
	int mid=(tree[x].l+tree[x].r)/2;
	if(R<=mid)return query(tree[x].ls,L,R);
	else if(L>mid)return query(tree[x].rs,L,R);
	else return query(tree[x].ls,L,R)+query(tree[x].rs,L,R);
}
int ask(int L,int R,int k){
	int l=1,r=n;
	while(l<r){
		int mid=(l+r)/2;
//		cout<<mid<<","<<L<<";;;"<<R<<":"<<query(root[mid],L,R)<<endl;
		if(query(root[mid],L,R)<k){
			l=mid+1;
		}else{
			r=mid;
		}
	}
	return a[l];
}
long long int sol(int l,int r){
//	cout<<l<<" "<<r<<'\n';
	if(l>=r)return 0ll;
//	cout<<l<<" "<<r<<"-"<<(r-l+2)/2<<"///"<<ask(l,r,(r-l+2)/2)<<'\n';
	return (long long int)sol(l,ask(l,r,(r-l+1+1)/2)-1)+sol(ask(l,r,(r-l+1+1)/2)+1,r)+r-l+1;
}
signed main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)read(a[i]);
//	for(int i=1;i<=n;i++){
//		b[a[i]]=i;
//	}
	root[0]=1;tot=1;
	tree[1]=(node){0,1,n,0,0};
	for(int i=1;i<=n;i++){
		root[i]=++tot;
		tree[root[i]]=node{0,1,n,0,0};
//		cout<<i<<":::"<<endl;
		modify(root[i-1],root[i],a[i]);
//		cout<<"----------------"<<endl;
	}
	write(sol(1,n));
//	cout<<ask(3,4,2)<<endl;
	flush();
	return 0;
}/*
5
4 3 5 1 2
*/
