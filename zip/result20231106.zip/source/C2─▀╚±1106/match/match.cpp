#include<bits/stdc++.h>
// #define int long long
#define rep(i,a,b) for(auto i(a);i<=(b);++i)
#define req(i,a,b) for(auto i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int T,n,m,deg[1000001],x,y,res,vis[1000001];
vector<int> g[1000001];
void dfs(int pos,int step)
{
	if(res==3) return;
	vis[pos]=step;
	for(int i:g[pos])
	{
		if(!vis[i]) dfs(i,step+1);
		else if(step+1-vis[i]==3) res=3;
		if(res==3) return;		
	}
}
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n,m);
		fill(deg+1,deg+n+1,0);
		rep(i,1,n) g[i].clear();
		rep(i,1,m) read(x),read(y),++deg[x],++deg[y],g[x].emplace_back(y),g[y].emplace_back(x);
		res=*max_element(deg+1,deg+n+1);
		if(res<3&&m>=3)
		{
			rep(i,1,n) vis[i]=0;
			rep(i,1,n) dfs(i,1);
		}
		writeln(res);
	}
	return 0;
}
