#include<bits/stdc++.h>
#define int long long
#define N 1000005
using namespace std;
int t,n,m;
int in[N];
int ans;
bool vis[N],k[N];
vector<int> to[N];
int read(){
	int f=1,x=0;char s=getchar();
	while(s<'0'| s>'9'){
		if(s=='-') f=-1;
		s=getchar();
	}
	while(s>='0' && s<='9'){x=x*10+s-'0';s=getchar();}
	return x*f;
}
void f(int x,int o,int fa){
	if(o==1){
		for(int i=0;i<to[x].size();i++){
			if(to[x][i]==fa){
				ans=3;
				break;
			}
		}
		return;
	}
	for(int i=0;i<to[x].size();i++){
		if(vis[to[x][i]]) continue;
		f(to[x][i],o-1,fa);
		if(ans==3) break;
	}
}
void dfs(int x){
	vis[x]=1;
	if(ans!=3) f(x,3,x);
	for(int i=0;i<to[x].size();i++){
		if(vis[to[x][i]]) continue;
		dfs(to[x][i]);
		if(ans==3) break;
	}
}
signed main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	t=read();
	while(t--){
		n=read();m=read();
		ans=0;
		for(int i=1,u,v;i<=m;i++){
			u=read();v=read();
			in[u]++;
			in[v]++;
			to[u].push_back(v);
			to[v].push_back(u);
		}
		for(int i=1;i<=n;i++){
			ans=max(ans,in[i]);
		}
		if(ans<3){
			for(int i=1;i<=n;i++){
				if(!vis[i]) dfs(i);
				if(ans==3) break;
			}
		}
		for(int i=1;i<=n;i++){
			in[i]=0;
			vis[i]=0;
			to[i].clear();
		}
		printf("%lld\n",ans);
	}
	return 0;
}


