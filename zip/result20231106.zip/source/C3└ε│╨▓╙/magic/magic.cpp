#include<bits/stdc++.h>
#define int long long
#define N 1005
using namespace std;
int n;
int l[N],r[N],c[N];
int ans;
int f[1048580];
bool vis[N];
void dfs(int x,int s){
	if(x>n){
		ans=max(ans,s);
		return;
	}
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		vis[i]=1;
		int k=0;
		for(int j=l[i];j<=r[i];j++){
			if(!vis[j]) k+=c[i];
		}
		dfs(x+1,s+k);
		vis[i]=0;
	}
}
signed main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld %lld %lld",&l[i],&r[i],&c[i]);
	if(n<=10){
		dfs(1,0);
		printf("%lld",ans);
		return 0;
	}
	if(n<=20){
		for(int i=1;i<(1<<n);i++){
			for(int j=1;j<=n;j++){
				int sum=0;
				if((1<<(j-1))&i){
					for(int k=l[j];k<=r[j];k++){
						if(!((1<<(k-1))&i)) sum+=c[j];
					}
					f[i]=max(f[i],f[i-(1<<(j-1))]+sum);
				}
			}
		}
		printf("%lld",f[(1<<n)-1]);
		return 0;
	}
	printf("0");
	return 0;
}


