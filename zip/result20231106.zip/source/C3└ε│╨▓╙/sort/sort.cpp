#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int b;
vector<int> a;
int ans;
void f(vector<int> p){
	int s=p.size(),o=p[(s+1)/2-1];
	if(s<=1) return;
	vector<int> x,y;
	for(int i=0;i<s;i++){
		ans++;
		if(p[i]<o) x.push_back(p[i]);
		if(p[i]>o) y.push_back(p[i]);
	}
	if(x.size()>1) f(x);
	if(y.size()>1) f(y);
}
signed main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&b);
		a.push_back(b);
	}
	f(a);
	printf("%lld",ans);
	return 0;
}


