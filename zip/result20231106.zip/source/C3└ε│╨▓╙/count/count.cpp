#include<bits/stdc++.h>
#define int long long
using namespace std;
int t;
int n;
int a[1000005];
signed main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		scanf("%lld",&n);
		int ans=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				a[i*j]++;
			}
		}
		for(int i=1;i<=n*n;i++) ans+=a[i]*a[i],a[i]=0;
		printf("%lld\n",ans);
	}
	return 0;
}

//20231118
//123456789
