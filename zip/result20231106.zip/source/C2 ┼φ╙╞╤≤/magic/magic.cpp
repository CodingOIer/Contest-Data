#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 1e3+5;
int n,l[N],r[N],p[N],cnt,op[N];
long long f[1<<20],c[N];
long long val[N],ans;
bool vis[N];
mt19937 rnd(114514);
signed main()
{
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	read(n);
	for(int i = 0;i<n;i++)
		read(l[i]),read(r[i]),read(c[i]),l[i]--,r[i]--,op[i] = i;
	if(n<=20)
	{
		for(int z = 1;z<(1<<n);z++)
		{
			cnt = 0;
			for(int i = 0;i<n;i++)
				if((z>>i)&1)
					p[++cnt] = i;
			for(int i = 1;i<=cnt;i++)
			{
				int zz = (z^(1<<p[i]));
				long long sum = 0;
				for(int j = l[p[i]];j<=r[p[i]];j++)
					if((j!=p[i])&&(((zz>>j)&1)!=1))
						sum+=c[p[i]];
				f[z] = max(f[z],f[zz]+sum); 
			}
		}
		write(f[((1<<n)-1)]);
	}
	else
	{
		do{
			shuffle(op,op+n,rnd);
			for(int i = 0;i<n;i++) vis[i] = val[i] = 0;
			for(int ii = 0,i = op[ii];ii<n;ii++,i = op[ii])
			{
				vis[i] = 1;
				for(int j = l[i];j<=r[i];j++)
					if(!vis[j]) val[j]+=c[i];
			}
			long long sum = 0;
			for(int i = 0;i<n;i++) sum+=val[i];
			ans = max(ans,sum); 
		}while(1.0*clock()/CLOCKS_PER_SEC<1.95);
		write(ans);
	}
	return 0;
}

