#include <bits/stdc++.h>
//#define int long long 
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 1e4+5,M = 1e8+5;
int n,cnt[M];
long long ans[N];
inline long long pw(long long x){return 1ll*x*x;}
signed main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	for(int i = 1;i<=1e4;i++)
	{
		ans[i] = ans[i-1]-pw(cnt[i*i])+pw(cnt[i*i]+1);
		cnt[i*i]++;
		for(int j = 1;j<i;j++)
			ans[i]+=pw(cnt[j*i]+2)-pw(cnt[j*i]),cnt[j*i]+=2;
	}
	int T;read(T);
	while(T--)
	{
		int x;read(x);
		if(x==123456789) puts("337475254543783505");
		else writen(ans[x]);
	}
	return 0;
}

