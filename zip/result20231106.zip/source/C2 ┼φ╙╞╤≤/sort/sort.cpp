#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
int n,ans;
vector<int> a;
void qsort(vector<int> &a)
{
	int len = a.size();
	if(len<=1) return;
	int mid = a[(len+1)/2-1];
	vector<int> l,r;
	ans+=len;
	for(int i = 0;i<len;i++)
	{
		if(a[i]<mid) l.push_back(a[i]);
		else if(a[i]>mid) r.push_back(a[i]);
	}
	a.clear();
	qsort(l),qsort(r);
	for(int i:l) a.push_back(i);
	a.push_back(mid);
	for(int i:r) a.push_back(i);
}
signed main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	read(n),a.resize(n);
	for(int i = 0;i<n;i++)
		read(a[i]);
	qsort(a);
	write(ans);	
	return 0;
}

