#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 1e6+5;
int n,m,du[N];
vector<int> g[N];
void solve()
{
	read(n),read(m);
	for(int i = 1,u,v;i<=m;i++)
		read(u),read(v),g[u].push_back(v),g[v].push_back(u),du[u]++,du[v]++;
	int ans = 0;
	for(int i = 1;i<=n;i++)
		ans = max(ans,du[i]);
	if(ans<3)
	{
		for(int i = 1;i<=n;i++)
		{
			if(du[i]<2) continue;
			int u = g[i][0],v = g[i][1];
			bool flag = 0;
			for(auto w:g[u])
				if(w==v)
				{
					flag = 1;
					break;
				}
			if(flag)
			{
				ans = 3;
				break;
			}
		}
	}
	writen(ans);
	for(int i = 1;i<=n;i++)
		du[i] = 0,g[i].clear();
}
int T;
signed main()
{
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	read(T);
	while(T--) solve();
	return 0;
}

