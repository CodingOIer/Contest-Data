#include <bits/stdc++.h>
using namespace std;

void Freopen(string Filename) {
	freopen((Filename + ".in").c_str(), "r", stdin);
	freopen((Filename + ".out").c_str(), "w", stdout);
}

int T;
pair<int, int> edge[500005];

bool check_edge(int u, int v, int uu, int vv) {return u == uu || u == vv || v == uu || v == vv;}

bool check(int* legal) {
	for (int i = 1; i <= legal[0]; i++)
		for (int j = 1; j <= legal[0]; j++)
			if (!check_edge(edge[legal[i]].first, edge[legal[i]].second, edge[legal[j]].first, edge[legal[j]].second)) return 0;
	return 1;
}

int main() {
	Freopen("match");
	scanf("%d", &T);
	while (T--) {
		int n, m;
		scanf("%d%d", &n, &m);
		bool islst = m == n - 1, isflr = m == n - 1, islop = m == n;
		for (int i = 1; i <= m; i++) {
			int u, v;
			scanf("%d%d", &u, &v);
			if (u != 1 || v != i) isflr = 0;
			if (u != i || v != i + 1) islst = 0;
			if (u != i || v != i % n + 1) islop = 0;
			edge[i] = make_pair(u, v);
		}
		if (m <= 1) {
			printf("%d\n", m);
			continue;
		}
		if (islst || isflr || islop) {
			printf("%d\n", isflr ? n : 2);
			continue;
		}
		else if (m <= 20) {
			int ans = 0;
			for (int i = 1; i < 1 << m; i++) {
				int legal[25];
				legal[0] = 0;
				for (int j = 1; j <= m; j++)
					if (i >> j - 1 & 1) legal[++legal[0]] = j;
				if (check(legal)) ans = max(ans, __builtin_popcount(i));
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
