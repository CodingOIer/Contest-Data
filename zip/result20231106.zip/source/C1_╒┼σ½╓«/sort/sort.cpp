#include <bits/stdc++.h>
using namespace std;

void Freopen(string Filename) {
	freopen((Filename + ".in").c_str(), "r", stdin);
	freopen((Filename + ".out").c_str(), "w", stdout);
}

int n, ans;
int a[1000005], q1[1000005], q2[1000005];

void quicksort(int l, int r) {
	if (l >= r) return;
	int t = a[l + r >> 1], i1 = 0, i2 = 0, ct = 0, p = l - 1;
	for (int i = l; i <= r; i++) {
		ans++;
		if (a[i] < t) q1[++i1] = a[i];
		else if (a[i] > t) q2[++i2] = a[i];
		else ct++;
	}
	for (int i = 1; i <= i1; i++) a[++p] = q1[i];
	while (ct--) a[++p] = t;
	for (int i = 1; i <= i2; i++) a[++p] = q2[i];
	quicksort(l, l + i1 - 1); quicksort(r - i2 + 1, r);
}

int main() {
	Freopen("sort");
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d", a + i);
	quicksort(1, n);
	printf("%d", ans);
	return 0;
}
