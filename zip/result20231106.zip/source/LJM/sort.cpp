#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n, ans;
int a[N], b[N], c[N];
void sort(int L, int R) {
	if(R - L + 1 <= 1) return;
	int mid = (L + R) / 2;
	int tot1 = 0, tot2 = 0;
	for(int i = L; i <= R; i++) {
		ans++;
		if(a[i] < a[mid]) b[++tot1] = a[i];
		if(a[i] > a[mid]) c[++tot2] = a[i]; 
	}
	int tot = L - 1;
	for(int i = 1; i <= tot1; i++) a[++tot] = b[i];
	a[++tot] = a[mid];
	for(int i = 1; i <= tot2; i++) a[++tot] = c[i];
	sort(L, L + tot1 - 1);
	sort(R - tot2 + 1, R);
}
signed main() {
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
    scanf("%lld", &n);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    sort(1, n);
    printf("%lld", ans);
	return 0;
}

