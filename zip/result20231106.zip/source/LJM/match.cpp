#include<bits/stdc++.h>
#define int long long
#define N 1000006
using namespace std;
int T, n, m, ans;
int d[N];
vector<int>p[N];
map<int, map<int, int> >f;
int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') f = -1;
		ch = getchar(); 
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
} 
void write(int x) {
	if(x < 0) putchar('-'), x = -x;
	if(x > 9) write(x / 10);
	putchar('0' + x % 10);
}
signed main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
    T = read();
    while(T--) {
    	n = read(), m = read();
    	for(int i = 1; i <= n; i++) {
    		d[i] = 0;
    		p[i].clear();
		}
    	for(int i = 1; i <= m; i++) {
    		int u, v;
    		u = read(), v = read();
    		d[u]++, d[v]++;
    		f[u][v] = f[v][u] = 1;
    		p[u].push_back(v);
    		p[v].push_back(u);
		}
		ans = 0;
		for(int i = 1; i <= n; i++) ans = max(ans, d[i]);
		if(ans < 3) {
			for(int i = 1; i <= n; i++) {
				for(int j = 0; j < p[i].size(); j++) {
					for(int k = j + 1; k < p[i].size(); k++) {
						int x = p[i][j], y = p[i][k];
						if(f[x][y]) {
						    write(3);
						    cout << "\n";
						    goto end;
						}
					}
				} 
			}
		}
		write(ans);
		cout << "\n";
		end:;
		for(int i = 1; i <= n; i++) {
			for(int j = 0; j < p[i].size(); j++) f[i][p[i][j]] = f[p[i][j]][i] = 0;
		}
	}
	return 0;
}

