#include<bits/stdc++.h>
#define int long long
#define N 1010
using namespace std;
int n, ans;
int f[100010]; 
int L[N], R[N], C[N];
int max(int a, int b) {
	return a > b ? a : b;
}
int min(int a, int b) {
	return a < b ? a : b;
}
signed main() {
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
    scanf("%lld", &n);
    cout << n;
    /*for(int i = 1; i <= n; i++) scanf("%lld %lld %lld", &L[i], &R[i], &C[i]);
    
    for(int j = 1; j < (1 << n); j++) f[j] = -1e18;
    for(int j = 0; j < (1 << n); j++) {
    	for(int i = 1; i <= n; i++) {
    		if((j & (1 << (i - 1))) != 0) continue;
    		int get = 0;
    		for(int x = L[i]; x <= R[i]; x++) {
    			if((j & (1 << (x - 1))) == 0) get++;
			}
    		f[j | (1 << (i - 1))] = max(f[j | (1 << (i - 1))], f[j] + get * C[i]);
		}
	}
	cout << f[(1 << n) - 1];
    /*for(int i = 1; i <= n; i++) {
    	for(int j = 0; j < (1 << (R[i] - L[i] + 1)); j++) {
    	    if((j & (1 << (i - L[i]))) == 0) continue;
    		for(int k = 0; k < (1 << (R[i - 1] - L[i - 1] + 1)); k++) {
    			int l = max(L[i], L[i - 1]), r = min(R[i], R[i - 1]);
    			bool flag = 1;
    			for(int x = l; x <= r; x++) {
    				if((((j >> (x - L[i] + 1 - 1)) & 1) != ((k >> (x - L[i - 1] + 1 - 1)) & 1))) {
    					flag = 0;
    					break;
					}
				}
				if(flag) {
					int get = 0;
					for(int x = 1; x <= (R[i] - L[i] + 1); x++) {
						if((j & (1 << (x - 1))) == 0) get++;
					}
					f[i][j] = max(f[i][j], f[i - 1][k] + get * C[i]);
				}
			}
		}
	}
	for(int j = 0; j < (1 << (R[n] - L[n] + 1)); j++) {
        ans = max(ans, f[n][j]);	
    }
    cout << ans;*/
	return 0;
}

