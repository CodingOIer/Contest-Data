#include<bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') f = -1;
		ch = getchar(); 
	}
	while(ch >= '0' && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
} 
void write(int x) {
	if(x < 0) putchar('-'), x = -x;
	if(x > 9) write(x / 10);
	putchar('0' + x % 10);
}
int T, n, ans;
int f[100006];
int vis[100000006];
signed main() {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	n = 10000;
	f[1] = 1;
	vis[1] = 1;
	for(int i = 2; i <= n; i++) {
	    f[i] = f[i - 1] + 1 + 4 * (i - 1);
	    int res = 0;
	    for(int c = 1; c < i; c++) {
	    	res += vis[i * c];
		}
		f[i] += res * 4;
		for(int j = 1; j < i; j++) vis[i * j] += 2;
		vis[i * i]++;
	}
    T = read();
    while(T--) {
    	n = read();
    	cout << f[n] << endl; 
	}
	return 0;
}
