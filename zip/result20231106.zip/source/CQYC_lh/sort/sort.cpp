#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
long long ot[40],otp;
void write(long long x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=7e5+2;
int n;
int ar[maxn],pos[maxn];
long long ans;
bool fl=0;
struct SEGTREE{
    int root[maxn],idx;
    struct node{
        int ls,rs;
        int num;
    }t[maxn*22];
    void pushup(int x){
        t[x].num=t[t[x].ls].num+t[t[x].rs].num;
        return ;
    }
    void build(int &x,int l,int r){
        x=++idx;
        if(l==r){t[x].num=t[x].ls=t[x].rs=0;return ;}
        int mid=(l+r)>>1;
        build(t[x].ls,l,mid);
        build(t[x].rs,mid+1,r);
        pushup(x);
        return ;
    }
    void modify(int &x,int pas,int l,int r,int p){
        x=++idx;
        t[x]=t[pas];
        if(l==r){t[x].num++;return ;}
        int mid=(l+r)>>1;
        if(p<=mid)modify(t[x].ls,t[pas].ls,l,mid,p);
        else modify(t[x].rs,t[pas].rs,mid+1,r,p);
        pushup(x);
        return ;
    }
    int query(int lx,int rx,int l,int r,int k){
        // if(fl)printf("query %d %d %d %d %d %d %d\n",lx,rx,l,r,k,t[lx].num,t[rx].num);
        if(l==r)return l;
        int mid=(l+r)>>1;
        if(t[t[rx].ls].num-t[t[lx].ls].num>=k)return query(t[lx].ls,t[rx].ls,l,mid,k);
        else return query(t[lx].rs,t[rx].rs,mid+1,r,k-(t[t[rx].ls].num-t[t[lx].ls].num));
    }
}segt;
void solve(int l,int r){
    int len=r-l+1;
    if(len<=1)return ;
    ans+=1ll*len;
    int pos=len/2+len%2;
    // if(l==1&&r==n)fl=1,printf("pos: %d %d\n",segt.query(segt.root[l-1],segt.root[r],1,n,pos),pos);
    // else fl=0;
    int mid=ar[segt.query(segt.root[l-1],segt.root[r],1,n,pos)];
    // if(r!=333)printf("solve %d %d %d\n",l,r,mid);
    // printf("solve %d %d %d\n",l,r,mid);
    solve(l,mid-1);
    solve(mid+1,r);
    return ;
}
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++){
        pos[ar[i]=read()]=i;
    }
    segt.build(segt.root[0],1,n);
    for(int i=1;i<=n;i++){
        segt.modify(segt.root[i],segt.root[i-1],1,n,pos[i]);
    }
    solve(1,n);
    write(ans);
    putchar('\n');
    return 0;
}