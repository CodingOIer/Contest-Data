#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
long long ot[40],otp;
void write(long long x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=1e3+2,maxs=6000;
int n;
int l[maxn],r[maxn],po[maxn];
long long c[maxn],va[maxn][8][2];
long long dp[maxn][maxs];
int cnt;
int p[maxs][8];
int no[maxn],vis[maxn];
vector<int>G[maxs];
namespace brute1{
    long long ans;
    void dev(int x){
        if(x==n+1){
            cnt++;
            for(int i=1;i<=n;i++)po[no[i]]=i;
            long long sum=0;
            for(int i=1;i<=n;i++){
                for(int j=l[i];j<=r[i];j++)if(po[j]>po[i])sum+=c[i];
            }
            ans=max(ans,sum);
            return ;
        }
        for(int i=1;i<=n;i++){
            if(vis[i])continue;
            vis[i]=1,no[x]=i;
            dev(x+1);
            vis[i]=0;
        }
        return ;
    }
    void solve(){
        ans=-1e18;
        dev(1);
        printf("%lld\n",ans);
    }
}
void dev(int x){
    if(x==8){
        cnt++;
        for(int i=1;i<=7;i++)p[cnt][i]=no[i];
        return ;
    }
    for(int i=1;i<=7;i++){
        if(vis[i])continue;
        vis[i]=1,no[x]=i;
        dev(x+1);
        vis[i]=0;
    }
    return ;
}
int main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++){
        l[i]=read(),r[i]=read(),c[i]=read();
        for(int j=l[i];j<i;j++)va[i][i-j][0]=c[i];
        for(int j=r[i];j>i;j--)va[j][j-i][1]=c[i];
    }
    if(n<=10){brute1::solve();return 0;}
    // dev(1);
    // for(int i=1;i<=cnt;i++){
    //     for(int j=1;j<=7;j++)po[p[i][j]]=j;
    //     for(int j=1;j<=7;j++){
    //         for(int k=1;k<=7;k++){
    //             if(p[i][j]-k>=1)dp[7][i]+=va[j][k][po[p[i][j]-k]>po[p[i][j]]];
    //         }
    //     }
    //     for(int j=1;j<=cnt;j++)if(check(i,j))G[j].push_back(i);
    // }
    // for(int i=8;i<=n;i++){
    //     for(int j=1;j<=cnt;j++){
    //         for(int k=0;k<G[j].size();k++){
    //             long long sum=0;
    //             for(int o=1;o<=7;o++){
    //                 sum=1;
    //             }
    //         }
    //     }
    // }
    return 0;
}