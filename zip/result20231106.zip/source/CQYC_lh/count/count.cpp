#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
long long ot[40],otp;
void write(long long x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
namespace brute{
    const int maxn=1e7+2;
    int cnt;
    long long pri[maxn],phi[maxn],sum[maxn],ans[maxn];
    bool vis[maxn];
    void Euler(){
        phi[1]=1;
        for(int i=2;i<maxn;i++){
            if(!vis[i])pri[++cnt]=i,phi[i]=i-1;
            for(int j=1;j<=cnt&&pri[j]*i<maxn;j++){
                vis[i*pri[j]]=1;
                if(i%pri[j]==0){
                    phi[i*pri[j]]=phi[i]*pri[j];
                    break;
                }
                else phi[i*pri[j]]=phi[i]*phi[pri[j]];
            }
        }
        return ;
    }
    void pre(){
        Euler();
        for(int i=1;i<maxn;i++)sum[i]=sum[i-1]+phi[i];
    }
    long long query(int n){
        long long ret=0;
        for(int l=1,r;l<=n;l=r+1){
            r=(n/(n/l));
            ret+=(sum[r]-sum[l-1])*1ll*(n/l)*(n/l);
        }
        // for(int i=1;i<=n;i++){
        //     for(int j=1;j<=n/i;j++)ret+=phi[j]*1ll*(n/j);
        // }
        return ret*2ll-1ll*n*n;
    }
    void solve(){
        pre();
        // for(int i=1;i<=100;i++)printf("phi[%d]=%lld\n",i,phi[i]);
        int n,T;
        T=read();
        while(T--){
            n=read();
            write(query(n));
            putchar('\n');
        }
        return ;
    }
}
int main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    brute::solve();
    return 0;
}