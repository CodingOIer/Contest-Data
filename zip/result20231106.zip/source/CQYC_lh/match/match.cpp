#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=1e6+2;
int T;
int n,m;
int fa[maxn];
int ans;
vector<int>G[maxn];
bool vis[maxn];
void add(int u,int v){
    G[u].push_back(v);
    // G[++cnt]=(node_edge){hed[u],v};
    // hed[u]=cnt;
    return ;
}
void init(){
    for(int i=1;i<=n;i++)G[i].clear();
    return ;
}
void dfs(int x){
    vis[x]=1;
    for(int i=0,v;i<G[x].size();i++){
        v=G[x][i],fa[v]=x;
        // printf("dfs %d %d\n",x,v);
        if(vis[v]){
            if(v==fa[fa[x]])ans=max(ans,3);
            continue;
        }
        dfs(v);
    }
    return ;
}
int main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    T=read();
    while(T--){
        // printf("solve again\n");
        n=read(),m=read();
        init();
        for(int i=1,u,v;i<=m;i++){
            u=read(),v=read();
            // printf("add %d %d\n",u,v);
            add(u,v);
            add(v,u);
        }
        ans=0;
        dfs(1);
        for(int i=1;i<=n;i++)ans=max(ans,(int)G[i].size());
        write(ans),putchar('\n');
    }
    return 0;
}