#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=1e6+7;

ll T,n,ans;
ll mu[Maxn];
bitset<Maxn>isp;
vector<ll>p;

inline void init(ll N){
	isp[0]=isp[1]=1;mu[1]=1;
	for(ll i=2;i<=N;i++){
		if(!isp[i]) p.emplace_back(i),mu[i]=-1;
		for(auto j:p){
			if(i*j>N) break;
			isp[i*j]=1;
			if(!(i%j)) break;
			mu[i*j]=-mu[i];
		}
	}
}

int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%lld",&T);
	init(Maxn-7);
	while(T--){
		scanf("%lld",&n);ans=0;
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=n/i;j++){
				ll res=mu[j],res1=0,x=n/j;
				for(ll d1=1;d1<=n/i/j;d1++){
					res1+=((n/j)/(d1))*(d1*2-1);
				}
				ans+=res*res1;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}



