#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e6+7;
int T,deg[Maxn];
vector<int>e[Maxn];

int main(){
	freopen("match.in","r",stdin);
	freopen("match.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		int n,m;
		scanf("%d%d",&n,&m);
		int ans=0;
		bool flg=0;
		memset(deg,0,sizeof deg);
		for(int i=1;i<=n;i++){
			deg[i]=0;
			e[i].resize(0);
		}
		for(int i=1,u,v;i<=m;i++){
			scanf("%d%d",&u,&v);
			deg[u]++,deg[v]++;
			e[u].emplace_back(v);
			e[v].emplace_back(u);
		}
		for(int i=1;i<=n;i++){
			ans=max(ans,deg[i]);
			if(deg[i]==2&&!flg){
				int u=e[i][0],v=e[i][1];
				for(auto j:e[u])
					if(j==v){
						ans=max(ans,3);
						break;
					}
				flg=1;
			}
		}
			
		printf("%d\n",ans);
	}
	return 0;
}

/*
3
4 1
2 3
1 0
5 4
3 2
5 3
5 1
4 5


*/

