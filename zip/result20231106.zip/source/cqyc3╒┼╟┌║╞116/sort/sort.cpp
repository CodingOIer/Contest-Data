#include <bits/stdc++.h>
#define ll long long
using namespace std;

ll cmpcnt=0;
vector<int> Sort(vector<int>&a,int len){
	if(a.size()<=1) return a;
	int pivot=a[(len-1)/2];
	vector<int>ag,au;
	cmpcnt+=len;
	for(auto val:a){
		if(val<pivot) ag.emplace_back(val);
		if(val>pivot) au.emplace_back(val);
	}
	Sort(ag,ag.size());
	Sort(au,au.size());
	vector<int>ans;
	for(auto v:ag) ans.emplace_back(v);
	ans.emplace_back(pivot);
	for(auto v:au) ans.emplace_back(v);
	return ans;
}

int n;
vector<int>A;

int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,x;i<=n;i++)
		scanf("%d",&x),
		A.emplace_back(x);
	Sort(A,A.size());
	printf("%lld",cmpcnt);
	
	return 0;
}

/*
5
4 3 5 1 2
*/

