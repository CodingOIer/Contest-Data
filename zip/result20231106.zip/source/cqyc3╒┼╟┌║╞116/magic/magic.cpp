#include <bits/stdc++.h>
#define ll long long
using namespace std;

const double d=0.975,eps=1e-9;
const int Maxn=1010;

struct node{
	int l,r,c;
}a[Maxn];
bool vis[Maxn];
int n,p[Maxn],ans,add[Maxn];

inline int solve(){
	for(int i=0;i<=n+1;i++) vis[i]=add[i]=0;
	for(int i=1;i<=n;i++){
		vis[p[i]]=1;
		for(int j=a[p[i]].l;j<=a[p[i]].r;j++){
			if(!vis[j]) add[j]+=a[p[i]].c;
		}
	}
	int res=0;
	for(int i=1;i<=n;i++) res+=add[i];
	return res;
}

inline void SA(){
	double T=1919.810;
	while(T>eps){
		int rnd1=rand()%n+1,rnd2=rand()%n+1;
		swap(p[rnd1],p[rnd2]);
		int res=solve();
		if(res>ans){
			ans=res;
			//cout<<"test\n";
			//cout<<res<<endl;
			//for(int i=1;i<=n;i++) cout<<p[i]<<" ";puts("");
		}
		else if(exp(res-ans)/T<=(double)rand()/RAND_MAX) swap(p[rnd1],p[rnd2]);
		T*=d;
	}
}

int main(){
	freopen("magic.in","r",stdin);
	freopen("magic.out","w",stdout);
	srand(19260817);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d%d",&a[i].l,&a[i].r,&a[i].c);
		p[i]=i;
	}
	while((double)clock()<=980) SA();
	printf("%d",ans);
	return 0;
}

/*
5
1 2 1
2 2 3
2 4 7
3 5 4
3 5 5

*/
