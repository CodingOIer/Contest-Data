#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1010;
int n;
struct node{
	int l, r, c, id, x;
}a[Maxn], b[Maxn]; 
int id[Maxn], vis[Maxn];
int ans;
bool cmp(node q, node p){
	return q.id < p.id;
}
void dfs(int x){
	if(x > n){
		int s = 0;
		memset(vis, 0, sizeof vis);
		for(int i = 1 ; i <= n ; i++){
			int x;	
			for(int j = 1 ; j <= n ; j++){
				if(id[j] == i){
					x = j;
					break;
				}
			}
			vis[x] = 1;
//			cout << x << " ";
			for(int j = a[x].l ; j <= a[x].r ; j++)
				if(!vis[j]) s += a[x].c;
		}
//		cout << s << endl;
		ans = max(ans, s);
		return ;
	}
	for(int i = 1 ; i <= n ; i++){
		if(!id[i]){
			id[i] = x;
			dfs(x + 1);
			id[i] = 0;
		}
	}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
	cin >> n;
	for(int i = 1 ; i <= n ; i++)
		cin >> a[i].l  >> a[i].r >> a[i].c;
	dfs(1);
	cout << ans << '\n';
	return 0;
}
/*
5
1 2 1
2 2 3
2 4 7
3 5 4
3 5 5
*/
