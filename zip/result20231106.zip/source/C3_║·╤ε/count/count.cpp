#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 10000000, maxn = 10000010;
int T, n;
int phi[maxn], prime[maxn], vis[maxn], cnt;
void Phi(){
	phi[1] = 1;
	for(int i = 2 ; i <= Maxn ; i++){
		if(!vis[i]){
			prime[++cnt] = i;
			phi[i] = i - 1;
		}
		for(int j = 1 ; j <= cnt && i * prime[j] <= Maxn ; j++){
			vis[i * prime[j]] = 1;
			if(i % prime[j] == 0){
				phi[i * prime[j]] = phi[i] * prime[j];
				break;
			}
			phi[i * prime[j]] = phi[i] * (prime[j] - 1);
		}
	}
	for(int i = 1 ; i <= Maxn ; i++) phi[i] += phi[i - 1];
}
map<int, int> _phi;
__int128 _Phi(__int128 n){
	if(n <= Maxn) return phi[n];
	if(_phi[n]) return _phi[n];
	__int128 sum = n * (n + 1) / 2;
	for(__int128 i = 2, j ; i <= n ; i = j + 1){
		j = n / (n / i);
		sum -= (__int128)(j - i + 1) * _Phi(n / i);
	}
	return sum;
}
//void write(__int128 x) {
//    if (x < 0) {
//        putchar('-');
//       	x = -x;
//    }
//    if (x > 9) write(x / 10);
//    putchar(x % 10 ^ 48);
//}
int solve(__int128 n){
	__int128 ans = 0;
	for(__int128 i = 1, j ; i <= n ; i = j + 1){
		j = n / (n / i);
		ans += (__int128)(_Phi(j) - _Phi(i - 1)) * (__int128)(n / i) * (n / i) * 2;
	}
//	write(ans);
//	cout << '\n';
	return ans;
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("cout.in", "r", stdin);
	freopen("cout.out", "w", stdout);
	cin >> T;
	Phi();
//	int aa = 12244;
//	write(aa);
//	cout << endl;
	while(T--){
		cin >> n;
		cout << solve(n) - n * n << '\n';
	}
	return 0;
}
/*
10
1
12
123
1234
12345
123456
1234567
12345678
123456789
1234567890


*/
