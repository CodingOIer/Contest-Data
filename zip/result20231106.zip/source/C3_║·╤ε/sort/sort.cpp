#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 700010;
int n, ans;
int b[Maxn];
int l[Maxn], r[Maxn];
void _Sort(int a[], int len){
	if(len <= 1) return ;
//	cout << len << endl;
//	for(int i = 1 ; i <= len ; i++) cout << a[i] << " ";
//	cout << endl;
	double ll = len;	 
	int mid = a[(int)ceil(ll / 2.0)];
//	ans += len;
//	memset(l, 0, sizeof l);
//	memset(r, 0, sizeof r);
	int ln = 0, rn = 0;
//	cout << mid << endl;
	for(int i = 1 ; i <= len ; i++){
		ans++; 
//		cout << a[i] << " ";
		if(a[i] < mid) l[++ln] = a[i];
		if(a[i] > mid) r[++rn] = a[i];
	}
//	cout << endl;
//	cout << ln << " " << rn << endl;
//	cout << endl;
	_Sort(l, ln);
	_Sort(r, rn);
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
	cin >> n;
	for(int i = 1 ; i <= n ; i++) cin >> b[i];
	_Sort(b, n);
	cout << ans << '\n';
	return 0;
}
/*
5
4 3 5 1 2
*/
