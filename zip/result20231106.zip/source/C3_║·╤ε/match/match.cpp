#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1000010;
int T;
int n, m, ans;
struct Tree{
	int to, nxt;
}tree[Maxn << 1];
int head[Maxn], tot;
void add(int x, int y){
	tree[++tot] = {y, head[x]};
	head[x] = tot;
}
int vis[Maxn], in[Maxn], dep[Maxn];
void Clean(){
	memset(tree, 0, sizeof tree);
	memset(head, 0, sizeof head);
	memset(vis, 0, sizeof vis);
	memset(dep, 0, sizeof dep);
	memset(in, 0, sizeof in);
	tot = ans = 0;
}
void dfs(int x, int s){
	dep[x] = s;
	vis[x] = 1;
	for(int i = head[x] ; i ; i = tree[i].nxt){
		int to = tree[i].to;
		if(vis[to]){
//			cout << dep[x] << " " << dep[to] << '\n';
			if(dep[x] - dep[to] == 2) ans = max(ans, 3ll);
			continue;
		}
		dfs(to, s + 1);
	}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	cin >> T;
	while(T--){
		Clean();
		cin >> n >> m;
		for(int i = 1 ; i <= m ; i++){
			int x, y;
			cin >> x >> y;
			add(x, y); add(y, x);
			in[x]++; in[y]++;
		}
		for(int i = 1 ; i <= n ; i++) ans = max(ans, in[i]);
		for(int i = 1 ; i <= n ; i++){
			if(!vis[i])
				dfs(1, 1);
		}
		cout << ans << '\n';
	}
	return 0;
}
/*
1
7 3
7 5
5 1
1 7
*/
