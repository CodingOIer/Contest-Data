#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e3+5 ;
int n,ans,res ;
int p[N],val[N],tr[N],vis[N] ;
struct Node{int l,r,w ;}a[N] ;
void Add(int x,int k)
{
    while(x <= n) tr[x] += k,x += -x&x ;
}
int Ask(int x)
{
    int res = 0 ;
    while(x) res += tr[x],x -= -x&x ;
    return res ;
}
void Check()
{
    int res = 0 ;
    FOR(i,1,n,1) tr[i] = 0,val[i] = 0 ;
    FOR(id,1,n,1)
    {
        int i = p[id] ;
        val[i] = Ask(i),Add(a[i].l,a[i].w),Add(a[i].r+1,-a[i].w) ;
    }
    FOR(i,1,n,1) res += val[i] ; ans = max(ans,res) ;
}
void Dfs(int x)
{
    if(x == n+1) {Check() ; return ;}
    FOR(i,1,n,1) if(!vis[i]) p[x] = i,vis[i] = 1,Dfs(x+1),vis[i] = 0 ;
}
void Solve1()
{
    Dfs(1),print(ans),enter ;
}
int cmp1(int x,int y)
{
    return a[x].w > a[y].w ;
}
int cmp2(int x,int y)
{
    return a[x].r-a[x].l > a[y].r-a[y].l ;
}
int cmp3(int x,int y)
{
    return (a[x].r-a[x].l+1)*a[x].w > (a[y].r-a[y].l+1)*a[y].w ;
}
mt19937 rd(time(0)) ;
void Tan()
{
    me(tr,0) ;
    FOR(i,1,n,1) Add(i,1),Add(i+1,-1) ;
    FOR(T,1,n,1)
    {
        int id = 0,mx = 0 ; //print(T),enter ;
        FOR(i,1,n,1) if(!vis[i])
        {
            int val = Ask(a[i].r)-Ask(a[i].l-1) ; val *= a[i].w ;
            if(val >= mx) mx = val,id = i ;
        }
        p[T] = id,vis[id] = 1,Add(id,-1),Add(id+1,1) ; 
    } //FOR(i,1,n,1) print(p[i]) ; enter ;
    Check() ;
}
void Solve2()
{
    FOR(i,1,n,1) p[i] = i ;
    sort(p+1,p+1+n,cmp1),Check() ;
    reverse(p+1,p+1+n),Check() ;
    sort(p+1,p+1+n,cmp2),Check() ;
    reverse(p+1,p+1+n),Check() ;
    sort(p+1,p+1+n,cmp3),Check() ;
    reverse(p+1,p+1+n),Check() ; Tan() ;
    while((double)clock()/CLOCKS_PER_SEC <= 1.9) shuffle(p+1,p+1+n,rd),Check() ;
    print(ans),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("magic.in","r",stdin) ;
	freopen("magic.out","w",stdout) ;
    read(n) ;
    FOR(i,1,n,1) read(a[i].l,a[i].r,a[i].w) ;
    if(n <= 10) Solve1() ;
    else Solve2() ;
    return 0 ;
}