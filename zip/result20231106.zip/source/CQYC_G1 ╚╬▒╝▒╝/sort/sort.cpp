#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 7e5+5 ;
int n,top ; long long ans ;
int rt[N],a[N],pos[N] ;
struct Node{int l,r,w ;}tr[N*60] ;
#define ls(x) tr[x].l
#define rs(x) tr[x].r
#define w(x) tr[x].w
#define mid (le+ri>>1)
inline void update(int x) {w(x) = w(ls(x))+w(rs(x)) ;}
void Build(int &x,int le = 1,int ri = n)
{
    x = ++top ; if(le == ri) return ; 
    Build(ls(x),le,mid),Build(rs(x),mid+1,ri);
}
void Insert(int &x,int y,int k,int le = 1,int ri = n)
{
    x = ++top,tr[x] = tr[y] ; if(le == ri) {w(x)++ ; return ;}
    (k <= mid) ? Insert(ls(x),ls(y),k,le,mid) : Insert(rs(x),rs(y),k,mid+1,ri) ; update(x) ;
}
int Query(int x,int y,int k,int le = 1,int ri = n)
{
    if(le == ri) return le ; int val = w(ls(y))-w(ls(x)) ;
    return (k <= val) ? Query(ls(x),ls(y),k,le,mid) : Query(rs(x),rs(y),k-val,mid+1,ri) ;
}
void Solve(int le,int ri)
{
    if(le >= ri) return ;
    int p = w(rt[ri])-w(rt[le-1]) ; ans += p,p = p/2+p%2 ;
    int pos = Query(rt[le-1],rt[ri],p) ; Solve(le,a[pos]-1),Solve(a[pos]+1,ri) ;
} 
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("sort.in","r",stdin) ;
	freopen("sort.out","w",stdout) ;
    read(n),Build(rt[0]) ;
    FOR(i,1,n,1) read(a[i]),pos[a[i]] = i ;
    FOR(i,1,n,1) Insert(rt[i],rt[i-1],pos[i]) ;
    Solve(1,n),print(ans),enter ;
    return 0 ;
}