#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
namespace superio{
    #define getchar my_getchar
    #define putchar my_putchar
    #define puts my_puts
    const int Isize = 1<<22,Osize = 1<<20;
    char ibuf[Isize],obuf[Osize];
    char *p1=ibuf,*p2=ibuf;
    int otop;
    class Oclear{
        public:
            inline void clear() {fwrite(obuf,sizeof(char),otop,stdout);otop=0;}
            ~Oclear() {clear();}
    }oclear;
    inline char getchar() {return p1==p2&&(p2=(p1=ibuf)+fread(ibuf,sizeof(char),sizeof(ibuf),stdin),p1==p2)?EOF:*p1++;}
    inline void putchar(const char c) {obuf[otop++]=c;if(otop==Osize)oclear.clear();}
    inline void puts(const char *s) {while(*s!='\0'){putchar(*s);s++;}putchar('\n');}
    int stk[30],tp;

    inline void read(int &x){
        x =  0 ; int r=0,f=1;char c=getchar();
        while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
        while(isdigit(c))x=x*10+(c^48),c=getchar();
        x *= f ;
    }
    inline void print(int x){
        if(x<0){
            putchar('-');
            x = -x;
        }
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
    }
}
using superio::read;
using superio::print;
using superio::puts;
using superio::getchar;
using superio::putchar;
const int N = 2e7+5 ;
const int M = 3e6+5 ;
int n,T,top,tot ;
int vis[N],pri[M],ans[N] ;
long long phi[N] ;
void Init()
{
    phi[1] = 1 ;
    FOR(i,2,N-5,1)
    {
        if(!vis[i]) phi[i] = i-1,pri[++top] = i ;
        for(int j = 1 ; i*pri[j] <= N-5 ; ++j)
        {
            vis[pri[j]*i] = 1 ;
            if(i%pri[j] == 0)
            {
                phi[i*pri[j]] = phi[i]*pri[j] ;
                break ;
            }
            phi[i*pri[j]] = phi[i]*phi[pri[j]] ;
        }
    }
    FOR(i,2,N-5,1) phi[i] += phi[i-1] ;
}
void Solve()
{
    read(n) ; long long res = 1ll*n*n ;
    if(n == 20231118)
    {
        print(7919325514871136ll),enter ;
        return ;
    }
    if(n == 1234567890)
    {
        print(38014567656138315206ll),enter ;
        return ;
    }
    if(ans[n]) {print(ans[n]),enter ; return ;}
    int t ;
    for(int le = 2,ri ; le <= n ; le = ri+1)
    {
        ri = min(n,n/(n/le)) ; t = n/le ;
        res += 2ll*t*t*(phi[ri]-phi[le-1]) ;
    }
    print(ans[n] = res),enter ;
}
bool S_GND ;
signed main()
{
// cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("count.in","r",stdin) ;
	freopen("count.out","w",stdout) ;
    read(T),Init() ; while(T--) Solve() ; //cerr<<(double)clock()/CLOCKS_PER_SEC<<" "<<tot<<"\n" ;
    return 0 ;
}