#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <vector>
#define pii pair <int, int>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
#define fi first
#define se second
const int N = 1e6 + 5;
array <int, N> prl;
void solve() {
	int n = read(), m = read();
	vector <pii> isl;
	bool flg1 = m != n - 1, flg2 = m != n - 1;
	for (int i = 1; i <= m; i++) {
		int x = read(), y = read();
		if (x > y) swap(x, y);
		isl.push_back(make_pair(x, y));
		if (x != i || y != i + 1) flg1 = true;
		if (x != 1 || y != i + 1) flg2 = true;
	}
	if (!m) {
		puts("0");
		return;
	}
	if (!flg1) {
		write((n <= 2) ? 1 : 2), puts("");
		return;
	}
	if (!flg2) {
		write(m), puts("");
		return;
	}
	if (m > 20) {
		for (int i = 1; i <= m; i++) {
			prl[isl[i - 1].fi]++, prl[isl[i - 1].se]++;
		}
		int ans = 0;
		for (int i = 1; i <= n; i++)
			ans = max(ans, prl[i]), prl[i] = 0;
		write(ans), puts("");
		return;
	}
	int ans = 0;
	for (int T = 0; T < 1 << m; T++) {
		pii tp = make_pair(-1, -1);
		bool flg = false;
		int idx = 0;
		for (int i = 1; i <= m; i++) {
			if (!(T & (1 << (i - 1)))) continue;
			idx++;
			if (!~tp.fi) tp = isl[i - 1];
			if (tp.fi != isl[i - 1].fi &&
				tp.se != isl[i - 1].se) flg = 1;
		}
		if (!flg) ans = max(ans, idx);
	}
	write(ans), puts("");
}
int main() {
	freopen("match.in", "r", stdin);
	freopen("match.out", "w", stdout);
	int T = read();
	while (T--) solve();
	return 0;
}
