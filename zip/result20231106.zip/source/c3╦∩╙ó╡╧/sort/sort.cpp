#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define ll long long
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(ll x) {
	if (x < 0ll) {
		x = -x;
		putchar('-');
	}
	if (x > 9ll) {
		write(x / 10ll);
	}
	putchar(x % 10ll + '0');
}
const int N = 7e5 + 5;
array <int, N> s, h;

namespace SGT {

array <int, N * 31> edge, lc, rc;
array <int, N> rot;
int cnt;
void modify(int &x, int l, int r, int y) {
	cnt++;
	edge[cnt] = edge[x] + 1;
	lc[cnt] = lc[x];
	rc[cnt] = rc[x];
	x = cnt;
	if (l == r) return;
	int mid = (l + r) >> 1;
	if (y <= mid) modify(lc[x], l, mid, y);
	else modify(rc[x], mid + 1, r, y);
}
int query(int x1, int x2, int l, int r, int k) {
	if (l == r) return l;
	int mid = (l + r) >> 1, len = edge[lc[x1]] - edge[lc[x2]];
	if (len >= k) return query(lc[x1], lc[x2], l, mid, k);
	else return query(rc[x1], rc[x2], mid + 1, r, k - len);
}

}

ll solve(int l, int r) {
	if (r - l <= 0) return 0;
	int k = SGT::query(SGT::rot[r], SGT::rot[l - 1], -1e9, 1e9, (r - l) / 2 + 1);
	ll ans = 0;
	k = h[k];
	/* write(l), putchar(32); */
	/* write(r), putchar(32); */
	/* write(k), puts(""); */
	/* exit(0); */
	/* system("pause"); */
	ans += r - l + 1;
	ans += solve(l, k - 1), ans += solve(k + 1, r);
	return ans;
}
int main() {
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
	int n = read();
	for (int i = 1; i <= n; i++) {
		int x = read();
		s[x] = i;
	}
	for (int i = 1; i <= n; i++) {
		h[s[i]] = i;
		SGT::rot[i] = SGT::rot[i - 1];
		SGT::modify(SGT::rot[i], -1e9, 1e9, s[i]);
		/* write(s[i]), putchar(32); */
	}
	/* puts(""); */
	/* write(SGT::query(SGT::rot[5], SGT::rot[0], -1e9, 1e9, 3)), puts(""); */
	/* return 0; */
	write(solve(1, n)), puts("");
	return 0;
}
