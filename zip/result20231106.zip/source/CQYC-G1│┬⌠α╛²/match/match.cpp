#include<bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=1e6+5;
int n,m,t,d[N],ans;
vector<int> g[N];
void add(int x,int y){d[x]++,g[x].push_back(y);}
void solve(){
    n=read(),m=read(),ans=0;
    memset(d,0,sizeof(d));
	for(int i=1;i<=n;i++) g[i].clear();
	for(int i=1;i<=m;i++){
        int x=read(),y=read();
        add(x,y),add(y,x);
	}
	for(int i=1;i<=n;i++) ans=max(ans,d[i]);
	if(ans<3){
		for(int i=1;i<=n;i++){
			if(d[i]==2){
                for(auto v:g[g[i][0]]){
					if(v==g[i][1]) ans=3;
                }
            }
        }
    }
    cout<<ans<<"\n";
}
int main(){
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    t=read();
	while(t--) solve();
	return 0;
}
