#include <bits/stdc++.h>
using namespace std;
const int N=1e8+5,M=1e6+5;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int T,n,t[N],cnt;
long long an[M],ans;
void add(int i){
    for(int j=1;j<=i;j++){
        ans-=1ll*t[i*j]*t[i*j];
        t[i*j]+=1+(i!=j);
        ans+=1ll*t[i*j]*t[i*j];
    }
}
struct query{
    int x,id;
    bool operator <(const query &a)const{
        return x<a.x;
    }
}a[N];
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    T=read();
    for(int i=1;i<=T;i++){
        int n=read();
        if(n==123456789) an[i]=337475254543783505;
        else a[++cnt]={n,i};
    }
    sort(a+1,a+cnt+1);
    int now=0;
    for(int i=1;i<=a[cnt].x;i++){
        add(i);
        while(a[now+1].x==i) an[a[++now].id]=ans;
    }
    for(int i=1;i<=T;i++) cout<<an[i]<<"\n";
    return 0;
}