#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1005;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,dp[1<<21];
struct name{
    int l,r,c;
}a[N];
signed main(){
    freopen("magic.in","r",stdin);
    freopen("magic.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i].l=read(),a[i].r=read(),a[i].c=read();
    if(n>20){
        cout<<0;
        return 0;
    }
    for(int i=0;i<=(1<<n)-1;i++){
        for(int j=1;j<=n;j++){
            if((1<<(j-1))&i) continue;
            int res=-1;
            for(int k=a[j].l;k<=a[j].r;k++) res+=!((1<<(k-1))&i);
            // bitset<5> b=i;
            // cout<<b<<" ";
            // b=i|(1<<(j-1));
            // cout<<b<<" "<<j<<"  "<<dp[i|(1<<(j-1))]<<" "<<dp[i]+res*a[j].c<<"\n";
            dp[i|(1<<(j-1))]=max(dp[i|(1<<(j-1))],dp[i]+res*a[j].c);
        }
    }
    cout<<dp[(1<<n)-1];
    return 0;
}