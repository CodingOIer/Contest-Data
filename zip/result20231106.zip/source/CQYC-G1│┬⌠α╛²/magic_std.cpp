#include <bits/stdc++.h>
using namespace std;
const int N=1005;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,dp[N][1<<5];
struct name{
    int l,r,c;
}a[N];
int main(){
    // freopen("magic.in","r",stdin);
    // freopen("magic.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i].l=read(),a[i].r=read(),a[i].c=read();
    for(int i=1;i<=n;i++){
        for(int j=0;j<(1<<5)-1;j++){
            for(int k=0;k<(1<<5)-1;k++){
                if(j|kk!=kk) continue;
            }
        }
    }
    return 0;
}