
    // freopen("magic.out","w",stdout);