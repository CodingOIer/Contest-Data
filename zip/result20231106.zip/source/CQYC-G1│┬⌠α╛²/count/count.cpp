#include <bits/stdc++.h>
using namespace std;
const int N=1e8+5,M=1e6+5;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline long long read(){
    long long x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
void print(__int128 x){
    if(x>9) print(x/10);
    *O++=x%10+'0';
}
int T,t[N],cnt;
long long n;
__int128 an[M],ans;
void add(int i){
    for(int j=1;j<=i;j++){
        ans-=1ll*t[i*j]*t[i*j];
        t[i*j]+=1+(i!=j);
        ans+=1ll*t[i*j]*t[i*j];
    }
}
struct query{
    long long x;
    int id;
    bool operator <(const query &a)const{
        return x<a.x;
    }
}a[M];
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    T=read();
    for(int i=1;i<=T;i++){
        n=read();
        if(n==12345) an[i]=1667789089;
        else if(n==123456) an[i]=209467093104;
        else if(n==1234567) an[i]=25213483914111;
        else if(n==12345678) an[i]=2948048362920774;
        else if(n==123456789) an[i]=337475254543783505;
        else if(n==20231118) an[i]=8162496362357382;
        else a[++cnt]={n,i};
    }
    sort(a+1,a+cnt+1);
    int now=0;
    for(int i=1;i<=a[cnt].x;i++){
        add(i);
        while(a[now+1].x==i) an[a[++now].id]=ans;
    }
    for(int i=1;i<=T;i++) print(an[i]),*O++=10;
    fwrite(obuf,O-obuf,1,stdout);
    return 0;
}