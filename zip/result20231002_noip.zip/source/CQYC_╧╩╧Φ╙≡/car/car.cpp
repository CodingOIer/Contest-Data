#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0;bool f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return f?-x:x;
}
const int N=2e5+10;
char pp[2];
struct ok{
	int x,y;
	void init()
	{
		x=read();
		scanf("%s",&pp);
		if(pp[1]=='M') y=0;
		else if(pp[1]=='N') y=1;
		else y=2;
	}
	bool operator <(const ok &A) const{return x==A.x?y<A.y:x<A.x;}
}a[N];
int m,t,n,q,ans[3],now[3];
int T[N][3];
int main()
{
	freopen("car.in","r",stdin);
	freopen("car.out","w",stdout);
	m=read(),t=read(),n=read(),q=read();
	for(int i=1;i<=n;i++) a[i].init();
	sort(a+1,a+n+1);a[n+1].x=t;
	for(int i=1;i<=n;i++) a[i].x=min(a[i].x,t);
	for(int i=n,x;i;i--)
	{
		for(int j=0;j<3;j++) now[j]=0;
		x=a[i].x;now[a[i].y]=m;
		for(int p,j=i+1;j<=n+1;j++)
		{
			p=a[j].x-x;
			if(p>m||!~T[j][0]) {T[i][0]=-1;break;}
			for(int h=0,k;h<3&&p;h++)
				k=min(now[h],p),p-=k,now[h]-=k,T[i][h]+=k;
			x=a[j].x;
			if(!a[j].y)
			{
				for(int k=0;k<3;k++) T[i][k]+=T[j][k];
				break;
			}
			if(a[j].y==1)
			{
				if(!now[0])
				{
					for(int k=0;k<3;k++) T[i][k]+=T[j][k];
					break;
				}
				now[1]=m-now[0],now[2]=0;
			}
			if(a[j].y==2)
			{
				if(!now[0]&&!now[1])
				{
					for(int k=0;k<3;k++) T[i][k]+=T[j][k];
					break;
				}
				now[2]=m-now[0]-now[1];
			}
			if(x==t) break;
		}
	}
	int x,l;
L:	while(q--)
	{
		x=read();
		for(int i=0;i<3;i++) ans[i]=now[i]=0;
		now[0]=m;
		l=lower_bound(a+1,a+(n+1)+1,(ok){x,0})-a;
		for(int p;l<=n+1;l++)
		{
			p=a[l].x-x;
			if(p>m||!~T[l][0]) {puts("-1");goto L;}
			for(int i=0,k;i<3&&p;i++)
				k=min(now[i],p),p-=k,now[i]-=k,ans[i]+=k;
			x=a[l].x;
			if(!a[l].y)
			{
				for(int k=0;k<3;k++) ans[k]+=T[l][k];
				break;
			}
			if(a[l].y==1)
			{
				if(!now[0])
				{
					for(int k=0;k<3;k++) ans[k]+=T[l][k];
					break;
				}
				now[1]=m-now[0],now[2]=0;
			}
			if(a[l].y==2)
			{
				if(!now[0]&&!now[1])
				{
					for(int k=0;k<3;k++) ans[k]+=T[l][k];
					break;
				}
				now[2]=m-now[0]-now[1];
			}
			if(x==t) break;
		}
		cout<<ans[2]<<" "<<ans[1]<<'\n';
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
