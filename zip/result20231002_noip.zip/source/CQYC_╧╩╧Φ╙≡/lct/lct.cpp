#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=N<<1;
int n,m,q,u[N],v[N],w[N],num[N];
int first[N],to[M],nxt[M],lth[M],cnt;
long long ans;
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
void dfs(int x,int fa)
{
	for(int i=first[x],v;i;i=nxt[i])
	{
		if((v=to[i])==fa) continue;
		for(int j=1;j<=m;j++)
			if(num[j]) num[__gcd(lth[i],j)]+=num[j];
		++num[lth[i]];
		dfs(v,x);
		ans+=num[1];
		--num[lth[i]];
		for(int j=m;j;j--)
			if(num[j]) num[__gcd(lth[i],j)]-=num[j];
	}
}
void solve()
{
	m=ans=cnt=0;
	for(int i=1;i<=n;i++) first[i]=0;
	for(int i=1;i<n;i++)
		inc(u[i],v[i],w[i]),inc(v[i],u[i],w[i]),m=max(m,w[i]);
	for(int i=1;i<=n;i++) dfs(i,0);
	printf("%lld\n",ans/2);
}
int main()
{
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<n;i++)
		scanf("%d%d%d",u+i,v+i,w+i);
	solve();
	int k,x,y,p;
	while(q--)
	{
		scanf("%d%d%d%d",&k,&x,&y,&p);
		u[k]=x,v[k]=y,w[k]=p;
		solve();
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
