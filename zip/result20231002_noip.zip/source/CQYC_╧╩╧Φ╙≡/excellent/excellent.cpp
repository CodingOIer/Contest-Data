#include<bits/stdc++.h>
using namespace std;
const int N=3010;
int T,n,ans[N];
bool vis[N][N];
char a[N];
long long res;
bitset<N>now,dif[N];
int main()
{
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%s",a+1);
		n=strlen(a+1);res=0;
		for(int i=1;i<=n;i++) dif[i]=0;
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++)
				if(a[i]!=a[j]&&a[i]!='?'&&a[j]!='?') dif[i][j-i]=1;
		for(int i=1;i<=n;i++)
		{
			now=0;ans[i]=0;
			for(int j=i;j+j-i+1<=n;j++)
			{
				now|=dif[j];
				if(!now[j-i+1]) vis[i][j+j-i+1]=1,++ans[i];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=i+2;j<=n;j+=2)
				if(vis[i][j-1]) res+=ans[j],vis[i][j-1]=0;
			for(int j=i;j<=n;j++) vis[i][j]=0;
		}
		printf("%lld\n",res);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
