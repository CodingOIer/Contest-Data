#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4;
vector<int>g[NN],t[NN*11];
int n,id[NN],in[NN],d[NN],fa[NN],siz[NN],bs[NN],dfn[NN],idfn[NN],tim,top[NN];
struct segment_tree
{
	int l,r;
}tr[NN<<2];
void dfs1(int u,int f)
{
	d[u]=d[f]+1;
	fa[u]=f;
	siz[u]=1;
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==f)
			continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[bs[u]])
			bs[u]=v;
	}
}
void dfs2(int u,int t)
{
	dfn[u]=++tim;
	idfn[tim]=u;
	top[u]=t;
	if(bs[u])
		dfs2(bs[u],t);
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa[u]||v==bs[u])
			continue;
		dfs2(v,v);
	}
}
void build(int u,int l,int r)
{
	tr[u]={l,r};
	if(l==r)
	{
		id[l]=u;
		return;
	}
	int mid=l+(r-l)/2;
	t[u].push_back(u<<1);
	t[(u<<1)+5*n].push_back(u+5*n);
	t[u].push_back(u<<1|1);
	t[(u<<1|1)+5*n].push_back(u+5*n);
	in[u<<1]++,in[u<<1|1]++,in[u+5*n]+=2;
	build(u<<1,l,mid);
	build(u<<1|1,mid+1,r);
}
void modify(int u,int l,int r,int x,int type)
{
	if(tr[u].l>=l&&tr[u].r<=r)
	{
		if(type==1)
		{
			t[x].push_back(u);
			in[u]++;
		}
		else
		{
			t[u+5*n].push_back(x);
			in[x]++;
		}
		return;
	}
	int mid=tr[u].l+(tr[u].r-tr[u].l)/2;
	if(l<=mid)
		modify(u<<1,l,r,x,type);
	if(r>mid)
		modify(u<<1|1,l,r,x,type);
}
void modify_path(int u,int v,int x,int type)
{
	int t=type==1?v:u;
	while(top[u]!=top[v])
	{
		if(d[top[u]]<d[top[v]])
			swap(u,v);
		int p=dfn[u];
		if(t==u)
			p--;
		modify(1,dfn[top[u]],p,x,type);
		u=fa[top[u]];
	}
	if(d[u]<d[v])
		swap(u,v);
	int l=dfn[v],r=dfn[u];
	if(t==v)
		l++;
	if(t==u)
		r--;
	modify(1,l,r,x,type);
}
int main()
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		tim=0;
		for(int i=1;i<=n;i++)
		{
			g[i].clear();
			bs[i]=0;
		}
		for(int i=1;i<=11*n;i++)
		{
			t[i].clear();
			in[i]=0;
		}
		for(int i=1;i<n;i++)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			g[u].push_back(v);
			g[v].push_back(u);
		}
		int m;
		scanf("%d",&m);
		dfs1(1,0);
		dfs2(1,1);
		build(1,1,n);
		for(int i=1;i<=m;i++)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			t[id[dfn[v]]].push_back(i+10*n);
			t[i+10*n].push_back(id[dfn[u]]+5*n);
			in[i+10*n]++,in[id[dfn[u]]+5*n]++;
			modify_path(u,v,i+10*n,1);
			modify_path(u,v,i+10*n,2);
		}
		queue<int>q;
		int cnt=0;
		for(int i=1;i<=11*n;i++)
			if(!in[i])
				q.push(i);
		while(q.size())
		{
			int u=q.front();
			q.pop();
			if(u>10*n&&u<=10*n+m)
				cnt++;
			for(int i=0;i<t[u].size();i++)
			{
				int v=t[u][i];
				in[v]--;
				if(!in[v])
					q.push(v);
			}
		}
		if(cnt==m)
			puts("Yes");
		else
			puts("No");
	}
	return 0;
}
