#include<bits/stdc++.h>
using namespace std;
const int NN=3004;
int f[NN],g[NN],maxx[NN][NN];
char s[NN];
int main()
{
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
    int t;
    scanf("%d",&t);
    while(t--)
	{
        memset(f,0,sizeof(f));
        memset(g,0,sizeof(g));
        memset(maxx,0,sizeof(maxx));
        scanf("%s",s+1);
        int n=strlen(s+1);
        for(int i=n;i>=1;i--)
        	for(int j=n;j>=1;j--)
        		if(s[i]==s[j]||s[i]=='?'||s[j]=='?')
        			maxx[i][j]=maxx[i+1][j+1]+1;
        for(int i=1;i<=n;i++)
            for(int len=1;len<=min(i,n-i);len++)
                if(maxx[i-len+1][i+1]>=len)
                    f[i-len+1]++,g[i+len]++;
		long long ans=0;
        for(int i=1;i<n;i++)
            ans+=1ll*g[i]*f[i+1];
        printf("%lld\n",ans);
    }
    return 0;
}
