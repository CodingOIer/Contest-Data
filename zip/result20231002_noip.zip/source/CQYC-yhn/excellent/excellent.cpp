#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,n,cnt,sum[3005][2];
char a[3005];
bool F1;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("excellent.in","r",stdin);
    freopen("excellent.out","w",stdout);
    T=read();
    while(T--){
        F1=1;
        scanf("%s",a+1);
        n=strlen(a+1);
        for(int i=1;i<=n;i++) sum[i][0]=sum[i][1]=0;
        for(int i=1;i<=n;i++) if(a[i]!='?') F1=0;
        int ans=0;
        if(F1){
            for(int i=1;i<=n;i++){
                for(int j=i;j<=n;j++){
                    int sz=(j-i+1);
                    if(sz&1) continue;
                    ans+=(sz/2-1);
                }
            }
            cout<<ans<<"\n";
            continue;
        }
        for(int i=1;i<=n;i++){
            for(int j=i;j<=n;j++){
                if((j-i)&1){
                    int d=(j-i+1)/2;
                    bool f=1;
                    for(int g=1;g<=d;g++){
                        if(a[i+g-1]!=a[i+d+g-1]&&a[i+g-1]!='?'&&a[i+d+g-1]!='?'){
                            f=0;
                            break;
                        }
                    }
                    if(f){
                        sum[i][0]++,sum[j][1]++;
                    }
                }
            }
        }
        for(int i=1;i<n;i++) ans+=(sum[i][1]*sum[i+1][0]);
        cout<<ans<<"\n";
    }
    return 0;
}