#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,ans,t1,t2,t3,t4,G[2005][2005];
struct ok{
    int x,y,z;
}a[100005];
struct node{
    int d,z;
};
vector<node> e[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int gcd(int x,int y){
    if(!y) return x;
    return gcd(y,x%y);
}
inline void dfs(int k,int f,int g){
    if(g==1) ans++;
    for(int i=0;i<(int)e[k].size();i++){
        if(e[k][i].d==f) continue;
        if(e[k][i].z<=2000&&g<=2000) dfs(e[k][i].d,k,G[e[k][i].z][g]);
        else dfs(e[k][i].d,k,gcd(e[k][i].z,g));
    }
}
inline void solve(){
    for(int i=1;i<=n;i++) e[i].clear();
    for(int i=1;i<n;i++){
        e[a[i].x].push_back((node){a[i].y,a[i].z});
        e[a[i].y].push_back((node){a[i].x,a[i].z});
    }
    ans=0;
    for(int i=1;i<=n;i++) dfs(i,0,0);
    cout<<ans/2<<"\n";
}
signed main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    for(int i=1;i<=2000;i++) for(int j=0;j<=2000;j++) G[i][j]=gcd(i,j);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        a[i].x=read(),a[i].y=read(),a[i].z=read();
    }
    solve();
    for(int i=1;i<=q;i++){
        t1=read(),t2=read(),t3=read(),t4=read();
        a[t1]=(ok){t2,t3,t4};
        solve();
    }
    return 0;
}
