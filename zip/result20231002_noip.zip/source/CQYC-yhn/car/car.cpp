#include<bits/stdc++.h>
#define int long long
using namespace std;
int m,t,n,q,c[200005],t1,a[200005],b[500005],cnt,M,id[500005];
string k[200005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    m=read(),t=read(),n=read(),q=read();
    b[++cnt]=t;
    for(int i=1;i<=n;i++){
        c[i]=read();
        cin>>k[i];b[++cnt]=c[i];
    }
    for(int i=1;i<=q;i++) a[i]=read(),b[++cnt]=a[i];
    sort(b+1,b+1+cnt);
    M=unique(b+1,b+1+cnt)-(b+1);
    for(int i=1;i<=n;i++){
        int d=lower_bound(b+1,b+1+M,c[i])-b;
        id[d]=i;
    }
    int O=lower_bound(b+1,b+1+M,t)-b;
    for(int i=1;i<=q;i++){
        int d=lower_bound(b+1,b+1+M,a[i])-b;
        int w1=m,w2=0,w3=0,z1=0,z2=0;
        bool flag=0;
        for(int j=d+1;j<=O;j++){
            int o=b[j]-b[j-1];
            int p=min(o,w1);
            w1-=p;o-=p;
            p=min(o,w2);
            w2-=p;o-=p;z1+=p;
            p=min(o,w3);
            w3-=p;o-=p;z2+=p;
            // cout<<b[j]<<" "<<w1<<" "<<w2<<" "<<w3<<" "<<o<<"\n";
            if(o>0){
                flag=1;
                break;
            }      
            if(id[j]>0){
                if(k[id[j]]=="SM") w1+=m;
                if(k[id[j]]=="SN") w2+=m;
                if(k[id[j]]=="SS") w3+=m;
                w1=min(w1,m);
                w2=min(w2,m-w1);
                w3=min(w3,m-w1-w2);
            }
        }
        if(flag) puts("-1");
        else cout<<z2<<" "<<z1<<"\n";
    }
    return 0;
}