#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,n,m,t1,t2,cnt,head[120005],nxt[240005],txt[240005],sum[120005];
struct ok{
    int l,r;
    bool operator < (const ok &A) const{
        return l<A.l;
    }
}a[240005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    T=read();
    while(T--){
        n=read();
        for(int i=1;i<n;i++){
            t1=read(),t2=read();
        }
        m=read();
        bool flag=0;
        for(int i=1;i<=m;i++){
            a[i].l=read(),a[i].r=read();
            sum[a[i].l]++;
            if(sum[a[i].l]>1) flag=1;
        }
        sort(a+1,a+1+m);
        for(int i=2;i<=m;i++) if(a[i].r<a[i-1].r) flag=1;
        for(int i=1;i<=m;i++) sum[a[i].l]--;
        if(flag) puts("No");
        else puts("Yes");
    }
    return 0;
}