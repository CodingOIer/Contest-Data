#include<bits/stdc++.h>
#define R register
#define LL long long
using std::vector;
using std::partition;
int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,m,q,mu[100010],pp[100010],id[100010],pcnt,ecnt;
bool np[100010];
struct edge
{
	int u,v,d,start,end;
}e[130010];
LL nowans;
struct union_find_set
{
	int fa[100010],size[100010],stu[130010],stv[130010],top;
	int find(int i){return fa[i]?find(fa[i]):i;}
	void build(){for(R int i=1;i<=n;++i)size[i]=1;}
	inline void connect(int u,int v)
	{
		u=find(u),v=find(v);
		size[u]<size[v]?u^=v^=u^=v:0;
		stu[++top]=u,
		stv[top]=v,
		fa[v]=u,
		nowans-=(((LL)size[u]*(size[u]-1))>>1)+(((LL)size[v]*(size[v]-1))>>1),
		size[u]+=size[v],
		nowans+=(((LL)size[u]*(size[u]-1))>>1);
	}
	inline void del()
	{
		fa[stv[top]]=0,
		nowans-=(((LL)size[stu[top]]*(size[stu[top]]-1))>>1);
		size[stu[top]]-=size[stv[top]],
		nowans+=(((LL)size[stu[top]]*(size[stu[top]]-1))>>1)+(((LL)size[stv[top]]*(size[stv[top]]-1))>>1),
		--top;
	}
	inline void clear(R int last=0){while(top>last)del();}
}ss;
vector<int> p[100010];
void pre_work()
{
	mu[1]=1;
	for(R int i=2;i<=m;++i)
	{
		!np[i]?pp[++pcnt]=i,mu[i]=-1,p[i].push_back(i),0:0;
		for(R int j=1;j<=pcnt&&i*pp[j]<=m;++j)
		{
			np[i*pp[j]]=1,p[i*pp[j]]=p[i];
			if(!(i%pp[j]))break;
			mu[i*pp[j]]=-mu[i];
			p[i*pp[j]].push_back(pp[j]);
		}
	}
}
vector<edge*>lst[100010];
LL ans[100010];
int select_ql,select_qr,muk;
struct select_join{inline bool operator () (R const edge *xx){return xx->start<=select_qr&&xx->end>=select_ql;}};
struct select_include{inline bool operator () (R const edge *xx){return xx->start<=select_ql&&xx->end>=select_qr;}};
void DC(vector<edge*>::iterator l,vector<edge*>::iterator r,int ll,int rr)
{
	if(l>=r){ans[ll]+=nowans*muk,ans[rr+1]-=nowans*muk;return;}
	int mm=(ll+rr)>>1,tmptop=ss.top;
	select_ql=ll,select_qr=mm;
	vector<edge*>::iterator nl=partition(l,r,select_include());
	for(R vector<edge*>::iterator i=l;i<nl;++i)
		ss.connect((*i)->u,(*i)->v);
	DC(nl,partition(nl,r,select_join()),ll,mm),
	ss.clear(tmptop);
	select_ql=mm+1,select_qr=rr;
	nl=partition(l,r,select_include());
	for(R vector<edge*>::iterator i=l;i<nl;++i)
		ss.connect((*i)->u,(*i)->v);
	DC(nl,partition(nl,r,select_join()),mm+1,rr),
	ss.clear(tmptop);
}
void work(int dd)
{
	select_ql=0,select_qr=q;
	vector<edge*>::iterator tmp=partition(lst[dd].begin(),lst[dd].end(),select_include());
	for(R vector<edge*>::iterator i=lst[dd].begin();i<tmp;++i)ss.connect((*i)->u,(*i)->v);
	muk=mu[dd];
	DC(tmp,lst[dd].end(),0,q);
	ss.clear();
}
signed main()
{
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	n=read(),q=read();
	for(R int i=1;i<n;++i)
	{
		e[i].u=read(),
		e[i].v=read(),
		e[i].d=read(),
		e[i].d>m?m=e[i].d:0,
		e[i].end=q;
		id[i]=i;
	}
	for(R int i=1,k,x,y,dd;i<=q;++i)
	{
		k=read(),x=read(),y=read(),dd=read(),
		e[id[k]].end=i-1,
		id[k]=n+i-1,
		e[n+i-1].start=i,
		e[n+i-1].u=x,
		e[n+i-1].v=y,
		e[n+i-1].d=dd,
		e[n+i-1].end=q,
		dd>m?m=dd:0;
	}
	pre_work();
	for(R int i=1;i<=n+q-1;++i)
	{
		R int len=p[e[i].d].size();
		for(R int s=1;s<(1<<len);++s)
		{
			R int dd=1;
			for(R int j=0;j<len;++j)s&(1<<j)?dd*=p[e[i].d][j]:0;
			lst[dd].push_back(e+i);
		}
	}
	ss.build();
	for(R int i=2;i<=m;++i){if(mu[i])work(i);}
	ans[0]+=(LL)n*(n-1)/2;
	for(R int i=1;i<=q;++i)ans[i]+=ans[i-1];
	for(R int i=0;i<=q;++i)printf("%lld\n",ans[i]);
	return 0;
}
