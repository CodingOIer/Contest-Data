#include<bits/stdc++.h>
#define base 131
#define N 3000
using namespace std;
int s[N+11][27];
char c[N+11];
unsigned long long mi[3011],H[3011];
inline unsigned long long ask(int l,int r)
{
	return H[r] - H[l - 1] * mi[r - l + 1];
}
int nxt[N+11];
int s1[27],s2[27];
inline bool Check(int l1,int r1,int l2,int r2)
{
	if(ask(l1,r1) == ask(l2,r2)) return 1;
	memcpy(s1,s[r1],sizeof(s1)),memcpy(s2,s[r2],sizeof(s2));
	for(int i = 0;i < 27;i++) s1[i] -= s[l1 - 1][i],s2[i] -= s[l2 - 1][i];
	for(int i = 0;i < 26;i++) if(s1[i] != s2[i])
	{
		if(s1[i] < s2[i])
			s1[26] -= s2[i] - s1[i];
		else
			s2[26] -= s1[i] - s2[i];
	}
	int m = r1 - l1;
	if(s1[26] == s2[26] && s1[26] >= 0)
	{
		int len = 0;
		while(len <= m)
		{
			do{
				if(c[l1 + len] == '?') len = nxt[l1 + len] - l1;
				if(c[l2 + len] == '?') len = nxt[l2 + len] - l2;
			}while((c[l1 + len] == '?' || c[l2 + len] == '?') && len <= m);
			if(len > m) break;
			int r = min({nxt[l1 + len] - 1 - l1,nxt[l2 + len] - 1 - l2,m});
			if(ask(l1 + len,l1 + r) != ask(l2 + len,l2 + r)) return 0;
			len = r + 1;
		}
		return 1;
	}else return 0;
}
int l[N+11],r[N+11];
long long ans;
int T,n;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
	mi[0] = 1;
	for(int i = 1;i <= N;i++) mi[i] = mi[i - 1] * base;
	cin >> T;
	while(T--)
	{
		cin >> (c + 1);
		n = strlen(c + 1);
		memset(s[0],0,sizeof(s[0]));
		for(int i = 1;i <= n;i++)
		{
			H[i] = H[i - 1] * base + c[i];
			l[i] = r[i] = 0;
			memcpy(s[i],s[i - 1],sizeof(s[i]));
			if(c[i] == '?') s[i][26]++;
			else s[i][c[i] - 'a']++;
		}
		nxt[n] = nxt[n + 1] = n + 1;
		for(int i = n - 1;i;i--)
			if((c[i] == '?') ^ (c[i + 1] == '?')) nxt[i] = i + 1;
			else nxt[i] = nxt[i + 1];
		ans = 0;
		for(int i = 2;i < n;i++)
		{
			for(int len = 1;i - 2 * len >= 0;len++)
			{
				if(Check(i - 2 * len + 1,i - len,i - len + 1,i))
				{
					l[i]++;
				}
			}
			for(int len = 1;i + len * 2 - 1 <= n;len++)
			{
				if(Check(i,i + len - 1,i + len,i + 2 * len - 1))
				{
					r[i]++;
				}
			}
		}
		for(int i = 2;i + 1 < n;i++)
		{
			ans += l[i] * r[i + 1];
		}
		cout << ans << "\n";
	}
	return 0;
}
