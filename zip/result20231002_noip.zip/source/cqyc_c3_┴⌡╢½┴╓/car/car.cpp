#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 200005;
pair<int,int> a[N];
int w[N][4];
int ans[4];
int n,m,t,q;

void car(int x,int p){
    if(a[x].first==t)
        return;
    if(a[x].second==1){
        p = m;
        for(int k:{1,2,3})
            if(a[w[x][k]].first-a[x].first<=m){
                car(w[x][k],m-(a[w[x][k]].first-a[x].first));
                return;
            }
        ans[0] = -1;
    }
    else if(a[x].second==2){
        if(a[w[x][1]].first-a[x].first<=p)
            car(w[x][1],p-(a[w[x][1]].first-a[x].first));
        else if(a[w[x][2]].first-a[x].first<=p)
            car(w[x][2],p-(a[w[x][2]].first-a[x].first));
        else if(a[w[x][2]].first-a[x].first>m&&a[w[x][1]].first-a[x].first>m){
            if(a[w[x][3]].first-a[x].first>m)
                ans[0] = -1;
            else{
                ans[2] += m-p;
                car(w[x][3],m-(a[w[x][3]].first-a[x].first));
            }
        }
        else if(w[x][2]<w[x][1]){
            ans[2] += a[w[x][2]].first-a[x].first-p;
            car(w[x][2],0);
        }
        else{
            ans[2] += a[w[x][1]].first-a[x].first-p;
            car(w[x][1],0);
        }
    }
    else if(a[x].second==3){
        if(a[x+1].first-a[x].first<=p)
            car(x+1,p-(a[x+1].first-a[x].first));
        else if(a[x+1].first-a[x].first<=m){
            ans[3] += a[x+1].first-a[x].first-p;
            car(x+1,0);
        }
        else
            ans[0] = -1;
    }
}

int main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    m = in,t = in,n = in,q = in;
    for(int k=1;k<=n;k++){
        a[k].first = in;
        char c = getchar();
        while(c!='S')
            c = getchar();
        c = getchar();
        a[k].second = (c=='M')+(c=='N')*2+(c=='S')*3;
    }
    sort(a+1,a+n+1);
    while(a[n].first>t)
        n--;
    if(a[n].first!=t)
        a[++n] = {t,1};
    w[n][0] = w[n][1] = w[n][2] = w[n][3] = n+1;
    a[n+1] = {2e9,0};
    for(int k=n-1;k;k--){
        for(int j=1;j<4;j++)
            w[k][j]=w[k+1][j];
        w[k][a[k+1].second] = k+1;
    }
    for(int k=1;k<=q;k++){
        int x = in;
        memset(ans,0,sizeof(ans));
        int p = lower_bound(a+1,a+n+1,make_pair(x,0))-a;
        if(a[p].first-x>m){
            puts("-1");
            continue;
        }
        car(p,m-(a[p].first-x));
        if(ans[0]==-1)
            puts("-1");
        else{
            out(ans[3],' ');
            out(ans[2],'\n');
        }
    }
    return 0;
}