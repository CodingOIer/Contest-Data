#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 3005;
int cl[N],cr[N];
string s;

namespace kmp{
    class kmp_pro{
        public:
            int kmp[N],len[N],val[N];
            string s;
            void init(){
                int n = s.size()-1;
                for(int k=2,j=0;k<=n;k++){
                    while(j&&(s[k]!=s[j+1]&&s[k]!='?'&&s[j+1]!='?'))
                        j = kmp[j];
                    if(s[k]==s[j+1]||s[k]=='?'||s[j+1]=='?')
                        j++;
                    kmp[k] = j;
                }
                for(int k=1;k<=n;k++){
                    len[k] = kmp[k];
                    val[kmp[k]] = k;
                    if(len[k]>k/2){
                        while(len[k]>k/2)
                            len[k] = len[len[k]];
                        len[k] = val[len[k]];
                        while(len[k]>k/2)
                            len[k] = kmp[len[k]];
                    }
                }
            }
    }p[N];

    signed main(){
        int n = s.size();
        for(int k=1;k<=n;k++)
            cl[k] = cr[k] = 0;
        for(int k=0;k<n;k++){
            p[k].s = " "+s.substr(k,s.size()-k);
            p[k].init();
            for(int j=1;j<=n-k;j++)
                if(j%2==0&&p[k].len[j]==j/2){
                    cl[k+1]++;
                    cr[j+k]++;
                }
        }
        int ans = 0;
        for(int k=1;k<n;k++)
            ans += cr[k]*cl[k+1];
        cout << ans << endl;
        return 0;
    }
}

namespace sub1{
    bool cmp(int l1,int l2,int l){
        for(int k=0;k<l;k++)
            if(s[l1+k]!=s[l2+k]&&s[l1+k]!='?'&&s[l2+k]!='?')
                return false;
        return true;
    }

    signed main(){
        int n = s.size();
        for(int k=1;k<=n;k++)
            cl[k] = cr[k] = 0;
        for(int k=0;k<n;k++)
            for(int j=k+1;j<n;j+=2)
                if(cmp(k,k+(j-k+1)/2,(j-k+1)/2)){
                    cl[k+1]++;
                    cr[j+1]++;
                }
        int ans = 0;
        for(int k=1;k<n;k++)
            ans += cr[k]*cl[k+1];
        cout << ans << endl;
        return 0;
    }
}

signed main(){
    freopen("cexcellent.in","r",stdin);
    freopen("cexcellent.out","w",stdout);
    int t;
    cin >> t;
    while(t--){
        cin >> s;
        bool f1 = true,f2 = true;
        for(auto c:s)
            if(c=='?')
                f1 = false;
            else
                f2 = false;
        if(s.size()<=200)
            sub1::main();
        else if(f1||f2)
            kmp::main();
        else
            sub1::main();
    }
    return 0;
}