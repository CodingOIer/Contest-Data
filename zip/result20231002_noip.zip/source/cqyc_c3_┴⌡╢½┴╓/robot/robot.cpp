#include <iostream>
#include <vector>
#include <random>
#include <queue>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],check;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++check]=x%10,x/=10;while(x);
        while(check)putchar(stk[check--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 12005;
int fa[N],dep[N],siz[N],son[N],top[N],t[N][2];
struct inquiry{int x,y,id;};
mt19937 myrand(713);
vector<inquiry> q;
vector<int> g[N];
int n,m;

void dfs1(int u){
    siz[u] = 1;
    son[u] = 0;
    for(auto v:g[u]){
        if(v==fa[u])
            continue;
        fa[v] = u;
        dep[v] = dep[u]+1;
        dfs1(v);
        siz[u] += siz[v];
        if(siz[v]>siz[son[u]])
            son[u] = v;
    }
}

void dfs2(int u,int check){
    top[u] = check;
    if(son[u])
        dfs2(son[u],check);
    for(auto v:g[u]){
        if(v==fa[u]||v==son[u])
            continue;
        dfs2(v,v);
    }
}

int lca(int x,int y){
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]])
            swap(x,y);
        x = fa[top[x]];
    }
    if(dep[x]<dep[y])
        swap(x,y);
    return y;
}


namespace check{
    vector<int> g[N];
    int d[N];
    void clear(){
        for(int k=1;k<=m;k++){
            g[k].clear();
            d[k] = 0;
        }
    }
    void add(int x,int y){;
        g[x].push_back(y);
        d[y]++;
    }
    bool check(){
        queue<int> q;
        for(int k=1;k<=m;k++)
            if(!d[k])
                q.push(k);
        int cnt = 0;
        while(!q.empty()){
            int u = q.front();
            cnt++;
            q.pop();
            for(auto v:g[u])
                if(!(--d[v]))
                    q.push(v);
        }
        return cnt==m;
    }
}

void dfs(int u,int x,int c){
    while(u!=fa[x]){
        if(t[u][0]&&t[u][0]!=c)
            check::add(t[u][0],c);
        if(t[u][1]&&t[u][1]!=c)
            check::add(c,t[u][1]);
        u = fa[u];
    }
}

int main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    int T = in;
    while(T--){
        n = in;
        check::clear();
        for(int k=1;k<=n;k++){
            g[k].clear();
            t[k][0] = t[k][1]=0;
        }
        for(int k=1;k<n;k++){
            int x = in,y = in;
            g[x].push_back(y);
            g[y].push_back(x);
        }
        dfs1(1);
        dfs2(1,1);
        m = in;
        q.resize(m);
        for(int k=0;k<m;k++)
            q[k].x = in,q[k].y = in,q[k].id = k+1,t[q[k].x][0] = k+1,t[q[k].y][1] = k+1;
        shuffle(q.begin(),q.end(),myrand);
        int cnt = 0;
        for(auto [x,y,id]:q){
            cnt++;
            if(cnt==500){
                if(!check::check())
                    break;
                cnt = 0;
            }
            int l = lca(x,y);
            dfs(x,l,id);
            dfs(y,l,id);
        }
        if(!check::check()){
            puts("No");
            continue;
        }
        puts("Yes");
    }
    return 0;
}