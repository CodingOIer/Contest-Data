#include <iostream>
#include <array>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 5005;
vector<pair<int,int>> g[N];
array<int,3> e[N];
int d[N];
int n,q;

void dfs(int u){
    for(auto [v,w]:g[u]){
        if(~d[v])
            continue;
        d[v] = __gcd(d[u],w);
        dfs(v);
    }
}

int solve(){
    int ans = 0;
    for(int k=1;k<=n;k++){
        memset(d,-1,sizeof(int)*(n+1));
        d[k] = 0;
        dfs(k);
        for(int j=1;j<=n;j++)
            if(d[j]==1)
                ans++;
    }
    return ans/2;
}

int main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    n = in,q = in;
    for(int k=1;k<n;k++){
        int a = in,b = in,c = in;
        e[k] = {a,b,c};
        g[a].emplace_back(b,c);
        g[b].emplace_back(a,c);
    }
    out(solve(),'\n');
    while(q--){
        int K = in,a = in,b = in,c = in;
        e[K] = {a,b,c};
        for(int k=1;k<=n;k++)
            g[k].clear();
        for(int k=1;k<n;k++){
            auto [a,b,c] = e[k];
            g[a].emplace_back(b,c);
            g[b].emplace_back(a,c);
        }
        out(solve(),'\n');
    }
    return 0;
}