#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int MAXN=2e5+5;
int T[MAXN],S[MAXN];
char k[MAXN];
int m,t,n,q;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}
void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
signed main()
{
	freopen("car.in","r",stdin);
	freopen("car.out","w",stdout);
	m=read(),t=read(),n=read(),q=read();
	for(int i=1;i<=n;i++)
		T[i]=read(),k[i]=read(); 
	for(int i=1;i<=q;i++)S[i]=read();
    return 0;
}
