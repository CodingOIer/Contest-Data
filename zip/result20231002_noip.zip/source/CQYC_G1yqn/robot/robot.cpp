#include<bits/stdc++.h>
using namespace std;

const int MAXN=1e5+5;
vector<int> G[MAXN];
int depth[MAXN],fa[MAXN];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}

void dfs(int u,int pre,int d)
{
    depth[u]=d;
    fa[u]=pre;
    for(int v:G[u])
        if(v!=pre) 
            dfs(v,u,d+1);
}

int LCA(int a,int b) 
{
    while(a!=b) 
	{
        if(depth[a]>depth[b]) 
            a=fa[a];
        else 
            b=fa[b];
    }
    return a;
}

bool check(int s1,int t1,int s2,int t2) 
{
    int lca1=LCA(s1,t1);
    int lca2=LCA(s2,t2);
    if(lca2==s2||lca2==t2||lca1==s2||lca1==t2) 
		return false;
    if(LCA(s1,s2)==s2&&LCA(t1,s2)==s2) 
		return true;
    if(LCA(s1,t2)==t2&&LCA(t1,t2)==t2)
		return true;
    if(LCA(s2,s1)==s1&&LCA(t2,s1)==s1)
		return true;
    if(LCA(s2,t1)==t1&&LCA(t2,t1)==t1) 
		return true;
    return false;
}

int main() 
{
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
    int T,n,m;
    T=read();
    while(T--) 
	{
        n=read();
        for(int i=1;i<=n;i++)
            G[i].clear();
        for(int i=1;i<n;i++)
        {
        	int u,v;
        	u=read(),v=read();
        	G[u].push_back(v);
        	G[v].push_back(u);
		}
		dfs(1,-1,1);
        m=read();
        vector<pair<int, int>> paths(m);
        for(int i=0;i<m;i++)
		{
			paths[i].first=read();
			paths[i].second=read();
		}
        bool ok=true;
        for(int i=0;i<m&&ok;i++)
        	for(int j=i+1;j<m&&ok;j++)
        		if(check(paths[i].first,paths[i].second,paths[j].first,paths[j].second))
        			ok=false;
        std::cout<<(ok?"Yes":"No")<<endl;
    }
    return 0;
}
