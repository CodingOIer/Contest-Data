#include<bits/stdc++.h>
// #define int long long
#define ll unsigned long long
using namespace std;

const int N=60005,B=131;
int T,n,m,f[N],g[N];
ll h[N],p[N];
//string s;
char s[N];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}

void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}

inline ll Hash(int l,int r){return h[r]-h[l-1]*p[r-l+1];}

inline int lcs(int x,int y,int len)
{
	int l=1,r=len,ret=0;
	while(l<=r)
    {
		int mid=(l+r)>>1;
		if(Hash(x-mid+1,x)==Hash(y-mid+1,y))
			ret=mid,l=mid+1;
		else r=mid-1;
	}
	return ret;
}

inline int lcp(int x,int y,int len)
{
	int l=1,r=len,ret=0;
	while(l<=r)
    {
		int mid=(l+r)>>1;
		if(Hash(x,x+mid-1)==Hash(y,y+mid-1))
			ret=mid,l=mid+1;
		else r=mid-1;
	}
	return ret;
}

inline void solve()
{
	memset(f,0,sizeof(f));
	memset(g,0,sizeof(g));
	memset(h,0,sizeof(h));
    // cin>>s+1;
    // n=s.size()+1;
    // cout<<n<<" "<<"qqqqqq";
	scanf("%s",s+1),
	n=strlen(s+1);
	for(int i=1;i<=n;i++) 
		h[i]=h[i-1]*B+s[i];
	for(int i=1;i<=n;i++)
    {
		for(int j=i,k=i*2;k<=n;j+=i,k+=i)
        {
			int ret1=lcs(j,k,i),ret2=lcp(j,k,i);
			int head=max(k-ret1+i,k),tail=min(k+ret2-1,k+i-1);
			if(head<=tail)
            {
				++f[head];
                --f[tail+1];
				++g[head-i*2+1];
                --g[tail-i*2+2];
			}
		}
	}
	for(int i=1;i<=n;i++)
		f[i]+=f[i-1],g[i]+=g[i-1];
	ll ans=0;
	for(int i=1;i<n;i++)
		ans+=1LL*f[i]*g[i+1];
	write(ans);
    putchar('\n');
}

int main()
{
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
	p[0]=1;
    T=read();
	for(int i=1;i<=30000;i++) 
		p[i]=p[i-1]*B;
	while(T--) 
        solve();
	return 0;
}
