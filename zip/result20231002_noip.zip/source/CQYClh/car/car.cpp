#include<bits/stdc++.h>
using namespace std;
bool memst;
const int maxn=2e5+2;
const int inf=1e9;
int m,t,n,Q;
struct node{
    int ty,p;
}all[maxn];
struct node_q{
    int id,p;
}q[maxn];
struct node_que{
    int a,b;
    node_que operator + (const node_que &A)const{
        return {a+A.a,b+A.b};
    }
}ans[maxn];
struct SEGTREE{
    int rt,idx;
    struct node{
        int l,r,ls,rs;
        node_que va;
        char tag;
    }t[maxn*160],emp;
    void init(){emp={0,0,0,0,{0,0},3},newid(rt,-inf,inf);}
    int newid(int &x,int l,int r){return (!x)?(x=++idx,t[x]=emp,t[x].l=l,t[x].r=r,t[x].va={r-l+1,0},x):x;}
    void pushup(int x){
        t[x].va=t[t[x].ls].va+t[t[x].rs].va;
        return ;
    }
    void update(int x,char v){
        if(v==3)return ;
        if(v==0)t[x].va.a=t[x].va.b=0;
        if(v==1)t[x].va.b+=t[x].va.a,t[x].va.a=0;
        t[x].tag=min(t[x].tag,v);
    }
    void pushdown(int x){
        update(t[x].ls,t[x].tag);
        update(t[x].rs,t[x].tag);
        t[x].tag=3;
        return ;
    }
    void modify(int x,int l,int r,char v){
        if(r>inf)r=inf;
        // if(x==1)printf("modify %d %d %d\n",l,r,v);
        if(t[x].l==l&t[x].r==r){
            update(x,v);
            return ;
        }
        int mid=(t[x].l+t[x].r)/2;
        newid(t[x].ls,t[x].l,mid),newid(t[x].rs,mid+1,t[x].r);
        pushdown(x);
        if(l>mid)modify(t[x].rs,l,r,v);
        else if(r<=mid)modify(t[x].ls,l,r,v);
        else {
            modify(t[x].ls,l,mid,v);modify(t[x].rs,mid+1,r,v);
        }
        pushup(x);
    }
    node_que query(int x,int l,int r){
        if(r>inf)r=inf;
        // if(x==1)printf("query %d %d\n",l,r);
        if(l>r)return {0,0};
        if(t[x].l==l&&t[x].r==r){
            return t[x].va;
        }
        int mid=(t[x].l+t[x].r)/2;
        newid(t[x].ls,t[x].l,mid),newid(t[x].rs,mid+1,t[x].r);
        pushdown(x);
        if(l>mid)return query(t[x].rs,l,r);
        else if(r<=mid)return query(t[x].ls,l,r);
        else {
            return query(t[x].ls,l,mid)+query(t[x].rs,mid+1,r);
        }
    }
}segt;
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
bool cmp(node a,node b){return a.p<b.p;}
bool cmp2(node_q a,node_q b){return a.p<b.p;}
bool memed;
int main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    // cerr<<"MEM:"<<((&memed-&memst)/1024/1024)<<'\n';
    m=read(),t=read(),n=read(),Q=read();
    int ti;
    string ki;
    // printf("chao\n");
    for(int i=1;i<=n;i++){
        ti=read(),cin>>ki;
        if(ki[1]=='M')all[i]={0,ti};
        if(ki[1]=='N')all[i]={1,ti};
        if(ki[1]=='S')all[i]={2,ti};
    }
    sort(all+1,all+n+1,cmp);
    // for(int i=1;i<=n;i++){
    //     printf("all[%d]=(%d %d)\n",i,all[i].ty,all[i].p);
    // }
    for(int i=1;i<=Q;i++){
        q[i].p=read();
        q[i].id=i,ans[i]={-1,-1};
    }
    // printf("boom\n");
    sort(q+1,q+Q+1,cmp2);
    segt.init();
    int tp=Q;
    while(n&&all[n].p>t)n--;
    all[n+1]={3,t};
    // printf("la %d\n",segt.query(1,1,t));
    bool f=1;
    for(int i=n;i;i--){
        while(q[tp].p>all[i].p&&tp){
            if(q[tp].p+m<all[i+1].p){f=0;break;}
            // printf("que %d\n",q[tp].id);
            ans[q[tp].id]=segt.query(1,q[tp].p+m+1,t);
            tp--;
        }
        if(all[i].p+m<all[i+1].p)break;
        segt.modify(1,all[i].p+1,all[i].p+m,all[i].ty);
    }
    while(tp&&f){
        if(q[tp].p+m<all[1].p)break;
        // printf("que %d\n",q[tp].id);
        ans[q[tp].id]=segt.query(1,q[tp].p+m+1,t);
        tp--;
    }
    for(int i=1;i<=Q;i++){
        if(ans[i].a==-1)printf("-1\n");
        else printf("%d %d\n",ans[i].a,ans[i].b);
    }
    return 0;
}