#include<bits/stdc++.h>
using namespace std;
const int maxn=12e4+2;
int n,m;
int cnt,idx;
int hed[maxn],dfn[maxn],siz[maxn];
struct SEGTREE{
    int rt,idx;
    struct node{
        int ls,rs,l,r;
        int sum;
    }t[maxn*20],emp;
    void init(){
        emp={0,0,0,0,0};
        return ;
    }
    int newid(){return t[++idx]=emp,idx;}
    void pushup(int x){
        t[x].sum=t[t[x].ls].sum+t[t[x].rs].sum;
        return ;
    }
    void modify(int &x,int p,int v){
        if(!x)x=newid();
        if(t[x].l==t[x].r){
            t[x].sum++;
            return ;
        }
        int mid=(t[x].l+t[x].r)>>1;
        if(p<=mid)modify(t[x].ls,p,v);
        else modify(t[x].rs,p,v);
        pushup(x);
    }
    int query(int x,int l,int r){
        if(!x)return 0;
        if(t[x].l==l&&t[x].r==r){
            return t[x].sum;
        }
        int mid=(t[x].l+t[x].r)>>1;
        if(l>mid)return query(t[x].rs,l,r);
        else if(r<=mid)return query(t[x].ls,l,r);
        else {
            return query(t[x].ls,l,mid)+query(t[x].rs,mid+1,r);
        }
    }
    int merge(int lx,int rx){
        if(!lx||!rx)return lx+rx;
        t[lx].ls=merge(t[lx].ls,t[rx].ls);
        t[lx].rs=merge(t[lx].rs,t[rx].rs);
        pushup(lx);
        return lx;
    }
}segt;
void dfs1(int x,int f){
    
}
int main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);

    //没写完
    printf("more time!\n");
    return 0;
}