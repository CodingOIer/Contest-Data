#include<bits/stdc++.h>
using namespace std;
const int maxn=3e3+2;
int T;
int n;
char s[maxn];
int sum[maxn];
long long le[maxn][2];
long long ans;
void solve(int ty){
    for(int len=1;len<=n;len++){
        for(int i=1;i<=n;i++){
            if(i+len<=n)sum[i]=(s[i]==s[i+len]||s[i]=='?'||s[i+len]=='?');
            else sum[i]=0;
            sum[i]+=sum[i-1];
            if(i>=len&&sum[i]-sum[i-len]==len&&i+len<=n)le[i+len][ty]++;
        }
    }
}
int main(){
    freopen("excellent.in","r",stdin);
    freopen("excellent.out","w",stdout);
    scanf("%d",&T);
    while(T--){
        scanf("%s",s+1);
        n=strlen(s+1);
        for(int i=1;i<=n;i++)le[i][0]=le[i][1]=0;
        solve(0);
        reverse(s+1,s+n+1);
        solve(1);
        ans=0;
        for(int i=1;i<=n;i++)ans+=le[i][0]*le[n-i][1];
        // for(int i=1;i<=n;i++)printf("L[%d]=%d\n",i,le[i][0]);
        printf("%lld\n",ans);
    }
    return 0;
}