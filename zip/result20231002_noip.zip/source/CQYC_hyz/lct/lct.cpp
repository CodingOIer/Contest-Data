#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

struct edge {
    int u, v, w;
} e[N];

int n, q, ans;
bool vis[N];

vector<edge> E[N];

void dfs(int x, int fa, int w) {
    if(w == 1) ans++; vis[x] = 1;
    for(edge l : E[x]) if(!vis[l.v]) dfs(l.v, x, w ? __gcd(w, l.w) : l.w);
    vis[x] = 0;
}

int work() {
    for(int i = 1; i <= n; i++) E[i].clear();
    for(int i = 1; i < n; i++) {
        E[e[i].u].push_back({ e[i].u, e[i].v, e[i].w });
        E[e[i].v].push_back({ e[i].v, e[i].u, e[i].w });
    }
    ans = 0;

    for(int i = 1; i <= n; i++) dfs(i, 0, 0);
    return ans >> 1;
}

bool edmer;
signed main() {
	freopen("lct.in", "r", stdin);
	freopen("lct.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), q = read();
    for(int i = 1; i < n; i++) e[i] = { read(), read(), read() };
    
    write(work()), putchar('\n');

    for(int i = 1; i <= q; i++) {
        int k = read(), x = read(), y = read(), v = read();
        e[k] = { x, y, v }, write(work()), putchar('\n');
    }

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 