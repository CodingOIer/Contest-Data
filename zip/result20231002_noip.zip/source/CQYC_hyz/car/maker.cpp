#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int M = 10;

int m, t, n, q;

string s[3] = { "SM", "SN", "SS" };

mt19937 g(time(0));

bool edmer;
signed main() {
	// freopen("car.in", "r", stdin);
	freopen("car.in", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    m = g() % M + 1, t = g() % M + 1, n = 2e5, q = 2e5;

    cout << m << ' ' << t << ' ' << n << ' ' << q << '\n';

    for(int i = 1; i <= n; i++) cout << g() % M + 1 << " " << s[g() % 3] << '\n';

    for(int i = 1; i <= q; i++) cout << g() % t << '\n';

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 