#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 2e5 + 10, inf = 1e9;

struct node {
    int p, ty;
    bool operator < (const node &b) const { return p < b.p; }
} a[N], op[N], ans[N];

int m, t, n, q;
int c[3];

vector<node> v;

string ch;

bool edmer;
signed main() {
	freopen("car.in", "r", stdin);
	freopen("car.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    m = read(), t = read(), n = read(), q = read();

    for(int i = 1; i <= n; i++) {
        a[i].p = read(), cin >> ch;
        if(ch[1] == 'N') a[i].ty = 1;
        if(ch[1] == 'S') a[i].ty = 2;
    }

    sort(a + 1, a + n + 1), a[0].p = -inf - 10;

    while(n and a[n].p > t) n--; a[n + 1].p = t;

    for(int i = 1; i <= q; i++) {
        int s = read(), pos = lower_bound(a + 1, a + n + 1, (node) { s, 0 }) - a;
        c[0] = c[1] = c[2] = 0; int f[3] = { m, 0, 0 }, now = 0;
        for(int j = pos; j <= n + 1; j++) {
            int d = a[j].p - s;
            if(f[0] + f[1] + f[2] < d) { now = -1; break; }
            while(d) {
                int val = min(f[now], d);
                d -= val, f[now] -= val, c[now] += val;
                if(d) for(int k = 2; k + 1; k--) if(f[k]) now = k;
            }
            d = m;
            for(int k = 2; k > a[j].ty; k--) {
                int val = min(d, f[k]);
                f[k] -= val, f[a[j].ty] += val, d -= f[k];
            }
            if(f[0] + f[1] + f[2] < m) f[a[j].ty] += m - f[0] - f[1] - f[2];
            s = a[j].p;
        }
        if(now < 0) puts("-1");
        else {
            write(c[2]), putchar(' ');
            write(c[1]), putchar('\n');
        }
    }

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 