#include<bits/stdc++.h>
using namespace std;
int T = 0;
signed main() {
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 maker.cpp -o maker");
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 bf.cpp -o bf");
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 car.cpp -o car");

	while(++T) {
		system("maker.exe");
		double st = clock();
		system("car.exe");
		double ed = clock();
		system("bf.exe");

		if(system("fc car.out car.ans")) {
			puts("Wrong Answer");
			return 0;
		} 
		else printf("Accepted, test #%d, time %0.lfms\n", T, ed - st);

	}
    return 0;
}