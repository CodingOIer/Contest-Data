#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1.2e5 + 10;

int T, n, m;
int p[N], q[N];

vector<int> e[N];

namespace sub1 {
    int fa[N], dep[N], id[N];
    bool vis[N];

    void dfs(int x) {
        dep[x] = dep[fa[x]] + 1;
        for(int v : e[x]) if(v ^ fa[x]) fa[v] = x, dfs(v);
    }

    bool query(int x, int y) {
        for(int i = 1; i <= m; i++) vis[i] = 0;
        int cnt = 0;
        while(x ^ y) {
            if(dep[x] < dep[y]) swap(x, y);
            if(id[x]) vis[id[x]] ? cnt++ : vis[id[x]] = 1;
            x = fa[x];
        }
        vis[id[x]] ? cnt++ : vis[id[x]] = 1;
        return cnt > 1;
    }

    void solve() {
        for(int i = 1; i <= n; i++) fa[i] = dep[i] = id[i] = 0;

        dfs(1);

        for(int i = 1; i <= m; i++) id[p[i]] = i, id[q[i]] = i;

        for(int i = 1; i <= m; i++) if(query(p[i], q[i])) return puts("No"), void();
        puts("Yes");
    }
}

void solve() {
    for(int i = 1; i <= n; i++) e[i].clear();

    n = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    m = read();
    for(int i = 1; i <= m; i++) p[i] = read(), q[i] = read();
    
    sub1 :: solve();
}

bool edmer;
signed main() {
	freopen("robot.in", "r", stdin);
	freopen("robot.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 