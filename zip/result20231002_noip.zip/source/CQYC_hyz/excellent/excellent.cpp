#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 3010;

int T, n, ans;
int f[N], g[N];

char s[N];

bool check(int x, int y) { return s[x] == s[y] or s[x] == '?' or s[y] == '?'; }

void solve() {
	for(int i = 1; i <= n + 1; i++) f[i] = g[i] = 0;

    scanf("%s", s + 1), n = strlen(s + 1), ans = 0;

	for(int len = 1; len <= n; len++) {
		int now = 0;
		for(int l = 1, r = len + 1; r <= n; l++, r++) {
			now = max(0ll, now - 1);
			while(r + now <= n and check(l + now, r + now)) now++;
			if(l + now >= r) f[l]++, g[r + len]++;
		}
	}

	for(int i = 1; i <= n; i++) ans += f[i] * g[i];

	write(ans), putchar('\n');
}

bool edmer;
signed main() {
	freopen("excellent.in", "r", stdin);
	freopen("excellent.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 