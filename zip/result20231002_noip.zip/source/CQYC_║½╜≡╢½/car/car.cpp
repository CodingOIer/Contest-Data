#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int m,T,n,Q,f1[N],f2[N];
bool f0[N];
vector<pii> V[3];
map<string,int> mp;
struct node{
    int a,col;
    il bool operator<(ct node &x)ct{
        return a<x.a;
    }
} A[N];
il int calc1(int k,int l,int r){
    int tmp=lower_bound(V[k].begin(),V[k].end(),pii(l,0))-V[k].begin();
    if(tmp==(int)V[k].size()||A[V[k][tmp].se].a<l||A[V[k][tmp].se].a>r) return n+1;
    return V[k][tmp].se;
}
il int calc2(int k,int l,int r){
    int tmp=lower_bound(V[k].begin(),V[k].end(),pii(r+1,0))-V[k].begin();
    if(V[k].empty()||!tmp||A[V[k][tmp-1].se].a<l||A[V[k][tmp-1].se].a>r) return n+1;
    return V[k][tmp-1].se;
}
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("car.in","r",stdin);
	freopen("car.out","w",stdout);
    m=read();T=read();n=read();Q=read();
    mp["SM"]=0;mp["SN"]=1;mp["SS"]=2;
    for(int i=1;i<=n;++i){
        A[i].a=read();string k;cin>>k;
        A[i].col=mp[k];
    }
    sort(A+1,A+1+n);
    for(int i=1;i<=n;++i){
        if(A[i].a>=T){
            n=i-1;break;
        }
    }
    for(int i=1;i<=n;++i){
        V[A[i].col].pk(pii(A[i].a,i));
    }
    A[n+1].a=T;f0[n+1]=1;
    // for(int i=2;i<=n;++i) if(A[i].a==A[i-1].a) cerr<<"ERROR";
    for(int i=n;i;--i){
        int tmp=A[i].col<0?calc2(0,A[i].a+1,A[i].a+m):calc1(0,A[i].a+1,A[i].a+m);
        if(A[tmp].a<=A[i].a+m){
            f0[i]=f0[tmp];f1[i]=f1[tmp];f2[i]=f2[tmp];
            if(A[i].col==0){
            }
            if(A[i].col==1){
                f1[i]+=A[tmp].a-A[i].a;
            }
            if(A[i].col==2){
                f2[i]+=A[tmp].a-A[i].a;
            }
        }
        else{
            tmp=A[i].col<1?calc2(1,A[i].a+1,A[i].a+m):calc1(1,A[i].a+1,A[i].a+m);
            if(A[tmp].a<=A[i].a+m){
                f0[i]=f0[tmp];f1[i]=f1[tmp];f2[i]=f2[tmp];
                if(A[i].col==0){
                    f1[i]-=A[i].a+m-A[tmp].a;
                }
                if(A[i].col==1){
                    f1[i]+=A[tmp].a-A[i].a;
                }
                if(A[i].col==2){
                    f2[i]+=A[tmp].a-A[i].a;
                }
            }
            else{
                tmp=A[i].col<2?calc2(2,A[i].a+1,A[i].a+m):calc1(2,A[i].a+1,A[i].a+m);
                if(A[tmp].a<=A[i].a+m){
                    f0[i]=f0[tmp];f1[i]=f1[tmp];f2[i]=f2[tmp];
                    if(A[i].col==0){
                        f2[i]-=A[i].a+m-A[tmp].a;
                    }
                    if(A[i].col==1){
                        f1[i]+=m;f2[i]-=A[i].a+m-A[tmp].a;
                    }
                    if(A[i].col==2){
                        f2[i]+=A[tmp].a-A[i].a;
                    }
                }
            }
        }
        // cerr<<i<<" "<<A[i].a<<" "<<A[i].col<<" "<<f0[i]<<" "<<f1[i]<<" "<<f2[i]<<"\n";
    }
    // Q=1;
    // cerr<<T<<" "<<m<<"\n";
    while(Q--){
        int S=read();
        if(S+m>=T){
            puts("0 0");continue;
        }
        int tmp=calc2(0,S+1,S+m);
        // cerr<<tmp;
        if(A[tmp].a<=S+m){
            if(!f0[tmp]) puts("-1");
            else{
                int res1=f1[tmp],res2=f2[tmp];
                write(res2);putchar(' ');write(res1);putchar('\n');
            }
        }
        else{
            tmp=calc2(1,S+1,S+m);
            if(A[tmp].a<=S+m){
                if(!f0[tmp]) puts("-1");
                else{
                    int res1=f1[tmp],res2=f2[tmp];
                    res1-=S+m-A[tmp].a;
                    write(res2);putchar(' ');write(res1);putchar('\n');
                }
            }
            else{
                tmp=calc2(2,S+1,S+m);
                if(A[tmp].a<=S+m){
                    if(!f0[tmp]) puts("-1");
                    else{
                        int res1=f1[tmp],res2=f2[tmp];
                        res2-=S+m-A[tmp].a;
                        write(res2);putchar(' ');write(res1);putchar('\n');
                    }
                }
                else puts("-1");
            }
        }
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}