#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 3010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,f[N][N],sum1[N],sum2[N],ans,n;
char S[N];
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
    T=read();
    while(T--){
        scanf(" %s",S+1);n=strlen(S+1);ans=0;
        for(int i=1;i<=n+1;++i) sum1[i]=sum2[i]=0;
        for(int i=1;i<=n+1;++i) for(int j=1;j<=n+1;++j) f[i][j]=0;
        for(int i=n;i;--i){
            // f[i][i]=1;
            for(int j=i+1;j<=n;++j){
                if(S[i]==S[j]||S[i]=='?'||S[j]=='?') f[i][j]=f[i+1][j+1]+1;
                if(f[i][j]>=j-i){
                    ++sum1[i];++sum2[j+j-i-1];
                }
                // cerr<<i<<" "<<j<<" "<<f[i][j]<<"\n";
            }
        }
        for(int i=1;i<=n;++i){
            ans+=sum2[i]*sum1[i+1];
            // cerr<<sum2[i]<<" "<<sum1[i+1]<<"\n";
        }
        write(ans);putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}