#include <bits/stdc++.h>
#define int long long
using namespace std;
int t,n,a[3005],b[3005],ans;
char s[3005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x){
    for(int i=1;i<=x/2;i++){
        int bj=0;
        for(int j=1;j<=i;j++)
            if(s[x-j+1]!=s[x-i-j+1]&&s[x-j+1]!='?'&&s[x-i-j+1]!='?'){
                bj=1;
                break;
            }
        if(!bj)
            a[x]++,b[x-2*i+1]++;
    }
}
signed main(){
    freopen("cexcellent.in","r",stdin);
    freopen("cexcellent.out","w",stdout);
    t=read();
    while(t--){
        ans=0;
        scanf("%s",s+1);
        n=strlen(s+1);
        int bj=0;
        for(int i=1;i<=n+1;i++){
            a[i]=b[i]=0;
            if(i<n&&s[i]!=s[i+1])
                bj=1;
        }
        if(!bj)
            for(int i=1;i<=n;i++)
                a[i]=i/2,b[i]=(n-i+1)/2;
        else
            for(int i=1;i<=n;i++)
                solve(i);
        for(int i=1;i<=n;i++)
            ans+=a[i]*b[i+1];
        printf("%lld\n",ans);
    }
    return 0;
}