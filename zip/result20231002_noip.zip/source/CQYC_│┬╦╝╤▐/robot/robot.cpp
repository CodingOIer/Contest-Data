#include <bits/stdc++.h>
using namespace std;
const int maxn=2e5;
int t,n,u,v,m,p[maxn],q[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    t=read();
    while(t--){
        n=read();
        for(int i=1;i<n;i++){
            u=read(),v=read();
        }
        for(int i=1;i<=m;i++)
            p[i]=read(),q[i]=read();
        puts("Yes");
    }
    return 0;
}