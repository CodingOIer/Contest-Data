#include <bits/stdc++.h>
using namespace std;
const int maxn=2e5+5;
int m,t,n,q,s,ti[maxn],b[maxn],cnt,ne[maxn],v[4],ss,sn;
map<int,int> k;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    m=read(),t=read(),n=read(),q=read();
    for(int i=1;i<=n;i++){
        ti[i]=read();
        string c;
        cin>>c;
        int b;
        if(c=="SM")
            b=3;
        if(c=="SN")
            b=2;
        if(c=="SS")
            b=1;
        k[ti[i]]=max(k[ti[i]],b);
    }
    sort(ti+1,ti+1+n);
    n=unique(ti+1,ti+1+n)-ti-1;
    for(int i=1;i<=n;i++)
        if(ti[i]>=t){
            n=i-1;
            break;
        }
    for(int i=n;i;i--){
        while(cnt&&k[b[cnt]]<k[ti[i]])
            --cnt;
        ne[i]=b[cnt];
        b[++cnt]=ti[i];
    }
    while(q--){
        v[0]=v[3]=m;
        v[1]=v[2]=0;
        ss=sn=0;
        s=read();
        int g=upper_bound(ti+1,ti+1+n,s)-ti;
        int bj=0;
        for(int i=g;i<=n;i++){
            int u=ti[i]-s;
            if(v[0]<u){
                bj=1;
                break;
            }
            v[0]-=u;
            if(v[3]<u){
                u-=v[3];
                v[3]=0;
                if(v[2]<u){
                    u-=v[2];
                    sn+=v[2];
                    v[2]=0;
                    v[1]-=u;
                    ss+=u;
                }
                else
                    v[2]-=u,sn+=u;
            }
            else
                v[3]-=u;
            s=ti[i];
            if(ne[i]){
                int u=ne[i]-s;
                if(v[0]<u)
                    if(u<=m-v[0])
                        v[k[s]]+=u,v[0]+=u;
                    else
                        v[k[s]]+=m-v[0],v[0]=m;
            }
            else
                v[k[s]]+=m-v[0],v[0]=m;
        }
        if(bj){
            puts("-1");
            continue;
        }
        int u=t-s;
        if(v[0]<u){
            puts("-1");
            continue;
        }
        v[0]-=u;
        if(v[3]<u){
            u-=v[3];
            v[3]=0;
            if(v[2]<u){
                u-=v[2];
                sn+=v[2];
                v[2]=0;
                ss+=u;
                v[1]-=u;
            }
            else
                v[2]-=u,sn+=u;
        }
        else
            v[3]-=u;
        printf("%d %d\n",ss,sn);
    }
    return 0;
}
