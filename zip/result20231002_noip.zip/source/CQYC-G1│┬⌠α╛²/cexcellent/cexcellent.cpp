#include <bits/stdc++.h>
using namespace std;
const int N=3e4+5;
int t,n;
long long ans;
string s;
int pd(int l1,int r1,int l2,int r2){
    for(int i=l1,j=l2;i<=r1;i++,j++){
        if(s[i]!=s[j]&&s[i]!='?'&&s[j]!='?') return 0;
    }
    return 1;
}
namespace n3{
    int f[N],g[N];
    int mian(){
        memset(f,0,sizeof(f));
        memset(g,0,sizeof(g));
        for(int i=1;i<=n;i++){
            for(int len=1;len<=min(i,n-i);len++){
                if(pd(i-len+1,i,i+1,i+len)){
                    f[i-len+1]++;
                    g[i+len]++;
                }
            }
        }
        for(int i=1;i<n;i++){
            ans+=1ll*g[i]*f[i+1];
        }
        cout<<ans<<"\n";
        return 0;
    }
}
namespace nw{
    const int p=19950721,mod=998244853,N=3e4+5;
    int po[N],pre[N],suf[N],f[N],g[N],ip[N];
    long long ans;
    #define pow Pow
    int pow(int x,int base){
        int ans=1;
        while(base){
            if(base&1) ans=1ll*ans*x%mod;
            x=1ll*x*x%mod;
            base>>=1;
        }
        return ans;
    }
    void intt(){
        po[0]=1;
        ip[0]=1;
        int pp=pow(p,mod-2);
        for(int i=1;i<N;i++) po[i]=1ll*po[i-1]*p%mod,ip[i]=1ll*ip[i-1]*pp%mod;
    }
    int ha(int l,int r){
        return 1ll*(suf[l]-suf[r+1]+mod)%mod*ip[n-r]%mod;
    }
    int mian(){
        ans=0;
        pre[0]=suf[n+1]=0;
        for(int i=1;i<=n;i++) pre[i]=(1ll*pre[i-1]*p%mod+s[i])%mod,f[i]=g[i]=0;
        for(int i=n;i;i--) suf[i]=(suf[i+1]+1ll*s[i]*po[n-i]%mod)%mod;
        for(int i=1;i<=n;i++){
            for(int len=1;len<=min(i,n-i);len++){
                if(ha(i-len+1,i)==ha(i+1,i+len)){
                    f[i-len+1]++;
                    g[i+len]++;
                }
            }
        }
        for(int i=1;i<n;i++){
            ans+=1ll*f[i+1]*g[i];
        }
        cout<<ans<<"\n";
        return 0;
    }
}
int main(){
    freopen("cexellent.in","r",stdin);
    freopen("cexellent.out","w",stdout);
    cin>>t;
    nw::intt();
    while(t--){
        cin>>s;
        n=s.size(),ans=0;
        s=' '+s;
        bool flag=1,ff=1;
        for(int i=1;i<=n;i++){
            if(s[i]=='?'){
                flag=0;
            }
            else ff=0;
        }
        if(flag) nw::mian();
        else if(ff){
            if(n<4) cout<<"0\n";
            else{
                n-=3;
                if(n%2==0) cout<<1ll*n*(n+2)*(n+4)/24<<"\n";
                else{
                    n=n/2+1;
                    cout<<1ll*n*(n+1)*(2*n+1)/6<<"\n";
                }
            }
        }
        else n3::mian();
    }
    return 0;
}