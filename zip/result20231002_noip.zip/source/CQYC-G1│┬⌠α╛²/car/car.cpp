#include <bits/stdc++.h>
using namespace std;
const int N=2e5+5,inf=2e9;
int m,t,n,q,ans[4];
struct point{
    int p,k;
}a[N];
bool operator <(point a,point b){
    return a.p<b.p;
}
int nx[N][4];
void go(int x,int now){
    if(a[x].p==t) return;
    if(a[x].k==1){
        now=m;
        for(int i=1;i<=3;i++){
            if(a[nx[x][i]].p-a[x].p<=m){
                go(nx[x][i],m-(a[nx[x][i]].p-a[x].p));
                return;
            }
        }
        ans[0]=-1;
        return;
    }
    if(a[x].k==2){
        if(a[nx[x][1]].p-a[x].p<=now){
            go(nx[x][1],now-(a[nx[x][1]].p-a[x].p));
            return;
        }
        if(a[nx[x][2]].p-a[x].p<=now){
            go(nx[x][2],now-(a[nx[x][2]].p-a[x].p));
            return;
        }
        if(a[nx[x][2]].p-a[x].p>m&&a[nx[x][1]].p-a[x].p>m){
            if(a[nx[x][3]].p-a[x].p>m){
                ans[0]=-1;
                return ;
            }
            ans[2]+=m-now;
            go(nx[x][3],m-(a[nx[x][3]].p-a[x].p));
            return ;
        }
        if(nx[x][2]<nx[x][1]){
            ans[2]+=a[nx[x][2]].p-a[x].p-now;
            go(nx[x][2],0);
            return;
        }
        ans[2]+=a[nx[x][1]].p-a[x].p-now;
        go(nx[x][1],0);
        return;
    }
    if(a[x].k==3){
        if(a[x+1].p-a[x].p<=now) go(x+1,now-(a[x+1].p-a[x].p));
        else if(a[x+1].p-a[x].p<=m) ans[3]+=a[x+1].p-a[x].p-now,go(x+1,0);
        else ans[0]=-1;
        return;
    }
}
int main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    std::ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>m>>t>>n>>q;
    for(int i=1;i<=n;i++){
        char c;
        cin>>a[i].p>>c>>c;
        a[i].k=(c=='M')+(c=='N')*2+(c=='S')*3;
    }
    sort(a+1,a+n+1);
    while(a[n].p>t) n--;
    if(a[n].p!=t) a[++n]={t,1};
    nx[n][0]=nx[n][1]=nx[n][2]=nx[n][3]=n+1;
    a[n+1]={inf,0};
    for(int i=n-1;i;i--){
        for(int j=1;j<4;j++) nx[i][j]=nx[i+1][j];
        nx[i][a[i+1].k]=i+1;
    }
    for(int kkk=1;kkk<=q;kkk++){
        int x;
        cin>>x;
        memset(ans,0,sizeof(ans));
        int now=lower_bound(a+1,a+n+1,point{x,0})-a;
        if(a[now].p-x>m){
            cout<<"-1\n";
            continue;
        }
        go(now,m-(a[now].p-x));
        if(ans[0]==-1) cout<<"-1\n";
        else cout<<ans[3]<<" "<<ans[2]<<"\n";
    }
    return 0;
}