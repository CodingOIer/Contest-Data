#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=1.2e5+5,K=20,Q=1e6,sz=400;
vector<int> g[N];
int T,n,m,fa[N][K+5],d[N],t[N][2];
struct query{
    int x,y,id;
}q[N];
void dfs(int x){
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        d[y]=d[x]+1;
        fa[y][0]=x;
        dfs(y);
    }
}
void intt(){
    for(int i=1;i<=K;i++){
        for(int j=1;j<=n;j++) fa[j][i]=fa[fa[j][i-1]][i-1];
    }
}
int lca(int x,int y){
    if(d[x]<d[y]) swap(x,y);
    for(int i=K;i>=0;i--)
        if(d[fa[x][i]]>=d[y]) x=fa[x][i];
    if(x==y) return x;
    for(int i=K;i>=0;i--)
        if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
namespace tp{
    vector<int> g[N];
    int d[N];
    queue<int> q;
    void clear(){
        for(int i=1;i<=m;i++) g[i].clear(),d[i]=0;
    }
    void add(int x,int y){
        // cout<<x<<" "<<y<<"\n";
        g[x].push_back(y);
        d[y]++;
    }
    bool tp(){
        int cnt=0;
        while(!q.empty()) q.pop();
        for(int i=1;i<=m;i++)
            if(d[i]==0) q.push(i);
        while(!q.empty()){
            int x=q.front();
            cnt++;
            q.pop();
            for(auto y:g[x]){
                d[y]--;
                if(d[y]==0) q.push(y);
            }
        }
        return cnt==m;
    }
}
void dfs1(int x,int l,int i){
    while(x!=fa[l][0]){
        if(t[x][0]&&t[x][0]!=i) tp::add(t[x][0],i);
        if(t[x][1]&&t[x][1]!=i) tp::add(i,t[x][1]);
        x=fa[x][0];
    }
}
int main(){
    freopen("robot.in","r",stdin);
    freopen("robot.out","w",stdout);
    mt19937 rnd(19920725);
    T=read();
    for(int kkk=1;kkk<=T;kkk++){
        bool flag=0;
        n=read();
        tp::clear();
        for(int i=1;i<=n;i++) g[i].clear(),t[i][0]=t[i][1]=0;
        for(int i=1;i<n;i++){
            int x=read(),y=read();
            g[x].push_back(y);
            g[y].push_back(x);
        }
        d[1]=1;
        dfs(1);
        intt();
        m=read();
        for(int i=1;i<=m;i++){
            q[i].x=read(),q[i].y=read(),q[i].id=i;
            t[q[i].x][0]=i,t[q[i].y][1]=i;
        }
        if(flag){
            cout<<"No\n";
            continue;
        }
        shuffle(q+1,q+m+1,rnd);
        for(int i=1;i<=m;i++){
            if(i%sz==0){
                flag=!tp::tp();
                if(flag) break;
            }
            int x=q[i].x,y=q[i].y;
            int l=lca(x,y);
            dfs1(x,l,q[i].id),dfs1(y,l,q[i].id);
        }
        flag=!tp::tp();
        if(flag){
            cout<<"No\n";
            continue;
        }
        cout<<"Yes\n";
    }
    return 0;
}