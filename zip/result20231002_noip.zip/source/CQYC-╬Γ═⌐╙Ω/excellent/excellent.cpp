//1s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=3010,base=13331,Mod=1919941207;
int T,N,f[Maxn],g[Maxn],Ans,A[Maxn],B[Maxn];
char S[Maxn];

void calc1(){ For(i,1,N) f[i]=i/2,g[i]=(N-i+1)/2; }

void calc2(){
    B[0]=1;
    For(i,1,N) 
        A[i]=A[i-1]*base%Mod+(S[i]-'a'+1),
        B[i]=B[i-1]*base%Mod;
    For(i,1,N){
        Rof(j,i,1){
            if((i-j+1)&1) continue;
            int md=(i+j)>>1,len=(i-j+1)>>1;
            int t1=(A[md]+Mod-A[md-len]*B[len]%Mod)%Mod;
            int t2=(A[i]+Mod-A[i-len]*B[len]%Mod)%Mod;
            if(t1==t2) ++f[i];
        }
        For(j,i+1,N){
            if((j-i+1)&1) continue;
            int md=(i+j)>>1,len=(j-i+1)>>1;
            int t1=(A[md]+Mod-A[md-len]*B[len]%Mod)%Mod;
            int t2=(A[j]+Mod-A[j-len]*B[len]%Mod)%Mod;
            if(t1==t2) ++g[i];
        }
    }
}

void calc3(){
    For(i,1,N){
        Rof(j,i,1){
            if((i-j+1)&1) continue;
            bool ccc=0; int md=(i+j)>>1;
            for(int l=md,r=i;r>md;--l,--r)
                if(S[l]!=S[r]&&S[l]!='?'&&S[r]!='?'){ccc=1; break;}
            if(!ccc) ++f[i];
        }
        For(j,i+1,N){
            if((j-i+1)&1) continue;
            bool ccc=0; int md=(i+j)>>1;
            for(int l=i,r=md+1;l<=md;++l,++r)
                if(S[l]!=S[r]&&S[l]!='?'&&S[r]!='?'){ccc=1; break;}
            if(!ccc) ++g[i];
        }
    }
}

void Solve(){
    scanf("%s",S+1); N=strlen(S+1),Ans=0;
    bool f1=1,f2=1;
    For(i,1,N) (S[i]!='?'?f1=0:f2=0);
    memset(f,0,sizeof f),memset(g,0,sizeof g);
    if(f1) calc1();
    else if(f2) calc2();
    else calc3();
    For(i,1,N-1) Ans+=f[i]*g[i+1];
    write(Ans),pc('\n');
}

signed main(){
    freopen("excellent.in","r",stdin);
    freopen("excellent.out","w",stdout);
    T=read(); while(T--) Solve();
    return 0;
}