//2s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,Q,x[Maxn],y[Maxn],v[Maxn],cnt,hed[Maxn],Ans;
struct node{int nxt,to,val;}G[Maxn<<1];
bool Vis[5010][5010];

void Addedge(int x,int y,int z){G[++cnt]=(node){hed[x],y,z};hed[x]=cnt;}

void DFS(int x,int p,int v){
    if(v==1) ++Ans;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p||Vis[x][y]) continue;
        DFS(y,x,(v==-1?G[i].val:__gcd(v,G[i].val)));
    }
}

int main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    N=read(),Q=read();
    For(i,1,N-1){
        x[i]=read(),y[i]=read(),v[i]=read();
        Addedge(x[i],y[i],v[i]),Addedge(y[i],x[i],v[i]);
    }
    For(i,1,N) DFS(i,0,-1);
    write(Ans>>1),pc('\n');
    while(Q--){
        int k=read(),tx=read(),ty=read(),tv=read();
        Vis[x[k]][y[k]]=Vis[y[k]][x[k]]=1;
        Addedge(tx,ty,tv),Addedge(ty,tx,tv);
        x[k]=tx,y[k]=ty,v[k]=tv;
        Ans=0;
        For(i,1,N) DFS(i,0,-1);
        write(Ans>>1),pc('\n');
    }
    return 0;
}