//1s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10,INF=1e9+10;
int M,T,N,Q,Nxt[Maxn][4];
string S;
struct node{
    int t,p;
    bool operator <(const node &c)const{return t^c.t?t<c.t:p<c.p;}
}A[Maxn];

void Solve(){
    int s=read(),sm=M,sn=0,ss=0,vn=0,vs=0;
    int L=upper_bound(A+1,A+N+1,(node){s,-1})-A-1;
    
    if((T-s)<=M) return printf("0 0\n"),void();

    int res=sm+sn+ss;
    //Go to the near sm
    int len=A[Nxt[L][0]].t-s;
    if(len<=res){
        int t=min(len,sm);
        sm-=t,len-=t;
        t=min(len,sn),sn-=t,vn+=t,len-=t;
        t=min(len,ss),ss-=t,vs+=t,len-=t;
        sm+=M-(sm+sn+ss);
        L=Nxt[L][0];
    }else{ //Go to the near sn
        len=A[Nxt[L][1]].t-s;
        if(len<=res){
            int t=min(len,sm);
            sm-=t,len-=t;
            t=min(len,sn),sn-=t,vn+=t,len-=t;
            t=min(len,ss),ss-=t,vs+=t,len-=t;
            sn+=M-(sm+sn+ss);
            L=Nxt[L][1];
        }else{ //Go to the near ss
            len=A[Nxt[L][2]].t-s;
            if(len<=res){
                int t=min(len,sm);
                sm-=t,len-=t;
                t=min(len,sn),sn-=t,vn+=t,len-=t;
                t=min(len,ss),ss-=t,vs+=t,len-=t;
                ss+=M-(sm+sn+ss);
                L=Nxt[L][2];
            }else return puts("-1"),void();
        }
    }

    for(int i=L;i<=N;){
        if((T-A[i].t)<=sm+ss+sn){
            int len=T-A[i].t;
            int t=min(len,sm);
            sm-=t,len-=t;
            t=min(len,sn),sn-=t,len-=t,vn+=t;
            t=min(len,ss),ss-=t,len-=t,vs+=t;
            break;
        }
        int res=sm+sn+ss;
        //Go to the near sm
        int len=A[Nxt[i][0]].t-A[i].t;
        if(len<=res){
            int t=min(len,sm);
            sm-=t,len-=t;
            t=min(len,sn),sn-=t,vn+=t,len-=t;
            t=min(len,ss),ss-=t,vs+=t,len-=t;
            sm+=M-(sm+sn+ss);
            i=Nxt[i][0];
        }else{ //Go to the near sn
            len=A[Nxt[i][1]].t-A[i].t;
            if(len<=res){
                int t=min(len,sm);
                sm-=t,len-=t;
                t=min(len,sn),sn-=t,vn+=t,len-=t;
                t=min(len,ss),ss-=t,vs+=t,len-=t;
                sn+=M-(sm+sn+ss);
                i=Nxt[i][1];
            }else{ //Go to the near ss
                len=A[Nxt[i][2]].t-A[i].t;
                if(len<=res){
                    int t=min(len,sm);
                    sm-=t,len-=t;
                    t=min(len,sn),sn-=t,vn+=t,len-=t;
                    t=min(len,ss),ss-=t,vs+=t,len-=t;
                    ss+=M-(sm+sn+ss);
                    i=Nxt[i][2];
                }else return puts("-1"),void();
            }
        }
    }
    write(vs),pc(' '),write(vn),pc('\n');
}

signed main(){
    freopen("car.in","r",stdin);
    freopen("car.out","w",stdout);
    M=read(),T=read(),N=read(),Q=read();
    For(i,1,N){
        A[i].t=read(),cin>>S;
        A[i].p=(S=="SM"?0:S=="SN"?1:2);
    }
    sort(A+1,A+N+1);
    Rof(i,N,1) if(A[i].t<=T){N=i;break;}
    A[0].t=INF;
    Rof(i,N-1,0){
        For(j,0,2) Nxt[i][j]=Nxt[i+1][j];
        Nxt[i][A[i+1].p]=i+1;
    }
    while(Q--) Solve();
    return 0;
}
/*
6 18 4 1
2 SN
6 SS
4 SN
12 SS
10
*/