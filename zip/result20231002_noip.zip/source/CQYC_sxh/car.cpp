#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


char qqq;

const int N = 4e5 + 1000;

int m, t, n, q, c[N], cnt;
pii p[N]; int col[N];


namespace part1{
    using arr = array<int, 7>;
    void operator +=(arr &a, int x) { For(i, x + 1, 3) a[x] += a[i], a[i] = 0; int sum = 0; For(i, 0, 3) sum += a[i]; a[x] += m - sum; }
    void operator *=(arr &a, int &x) { int k = 0; For(i, 0, 3) k = min(x, a[i]), a[i] -= k, a[max(1, i) + 3] += k, x -= k; } 
    void solve() { int s = read();
        arr f = {m, 0, 0, 0, 0, 0, 0}; int dis = 0;
        int p = lower_bound(c + 1, c + cnt + 1, s) - c;
        f *= (dis = c[p] - s); 
        if (dis) { puts("-1"); return; }
        For(i, p, cnt - 1) {
            For(j, 1, 3) if ((col[i] >> j) & 1) 
                { f += j; break; }
            f *= (dis = c[i + 1] - c[i]);
            if (dis) { puts("-1"); return; }
        } cout << f[6] << " " << f[5] << '\n';
    }
}

namespace part2{
    using arr = array<int, 4>; map<arr, pii> mp[N];
    pii operator +(pii x, pii y) { 
        if (min({x.first, x.second, y.first, y.second}) < 0) return {-1, -1};
        return {x.first + y.first, x.second + y.second}; 
    }
    pair<arr, pii> operator *(arr f, int x) { pii ans = {0, 0}; int k = 0;
        For(i, 0, 1) k = min(f[i], x), f[i] -= k, x -= k;
        k = min(f[2], x), f[2] -= k, x -= k, ans.first += k;
        k = min(f[3], x), f[3] -= k, x -= k, ans.second += k;
        if (x) ans = {-1, -1}; ; return {f, ans};
    }
    void operator +=(arr &f, int x) { 
        For(i, x + 1, 3) f[x] += f[i], f[i] = 0; 
        int sum = 0; For(i, 0, 3) sum += f[i]; f[x] += m - sum;
    }
    pii dfs(int x, arr f) {
        if (x == cnt) return {0, 0};
        For(i, 1, 3) if ((col[x] >> i) & 1) { f += i; break; }
        if (mp[x].count(f)) return mp[x][f];
        auto ver = f * (c[x + 1] - c[x]);
        return mp[x][f] = ver.second + dfs(x + 1, ver.first);
    }
    void solve() { int s = read(); arr f = {m, 0, 0, 0}; 
        int p = lower_bound(c + 1, c + cnt + 1, s) - c;
        auto ver = f * (c[p] - s); 
        pii ans = ver.second + dfs(p, ver.first);
        if (min(ans.first, ans.second) < 0) puts("-1");
        else cout << ans.second << " " << ans.first << '\n';
    }
}

char qqqq;

signed main() {
	freopen("car.in", "r", stdin);
	freopen("car.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    m = read(), t = read(), n = read(), q = read(), c[++cnt] = t;
    For(i, 1, n) {
        p[i].first = read(), c[++cnt] = p[i].first;
        char ch = getchar(); ch = getchar();
        if (p[i].first >= t) --cnt;
        if (ch == 'M') p[i].second = 1 << 1;
        if (ch == 'N') p[i].second = 1 << 2;
        if (ch == 'S') p[i].second = 1 << 3;
    } 
    sort(c + 1, c + cnt + 1), cnt = unique(c + 1, c + cnt + 1) - c - 1;
    For(i, 1, n) if (p[i].first < t) 
        col[lower_bound(c + 1, c + cnt + 1, p[i].first) - c] |= p[i].second;
    // if (n <= 5000 && q <= 5000) { while (q--) part1::solve(); return 0; }
    while (q--) part2::solve();
	return 0;
}