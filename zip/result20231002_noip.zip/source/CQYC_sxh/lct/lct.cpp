#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (!a || !b) return (a | b); if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 100;
int n, q;
struct node { int u, v, w; }e[N];
int head[N], nxt[N << 1], to[N << 1], w[N << 1], cnt;
int g[2010][2010];

void Add(int u, int v, int c) {
    to[++cnt] = v, w[cnt] = c, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, w[cnt] = c, nxt[cnt] = head[v], head[v] = cnt;
}

i64 ans;

void dfs(int u, int fa, int G) {
    if (G == 1) ++ans; 
    Eor(u) if (to[i] != fa) 
        dfs(to[i], u, gcd(G, w[i]));
}
void solve() {
    For(i, 1, n) head[i] = 0; cnt = 0;
    For(i, 1, n - 1) Add(e[i].u, e[i].v, e[i].w);
    For(i, 1, n) dfs(i, 0, 0); cout << ans << '\n';
}
signed main() {
	freopen("lct.in", "r", stdin);
	freopen("lct.out", "w", stdout);
    n = read(), q = read();
    For(i, 0, 2000) For(j, 0, 2000) g[i][j] = gcd(i, j);
    For(i, 1, n - 1) e[i] = {read(), read(), read()}; ; solve();
    while (q--) { int x = read(); e[x] = {read(), read(), read()}; solve(); }
	return 0;
}