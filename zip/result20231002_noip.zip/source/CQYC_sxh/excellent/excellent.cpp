#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


const int N = 3010;

int n; char s[N];
int f[N], g[N], lg[N];

bool eq(char x, char y) { return (x == '?') || (y == '?') || (x == y); }


namespace part1 {
	bool v[14][N][N];
	bool ok(int l1, int r1, int l2, int r2) { int l = lg[r1 - l1 + 1];
		return v[l][l1][l2] & v[l][r1 - (1 << l) + 1][r2 - (1 << l) + 1];
	}
	void solve() {
		scanf("%s", s + 1), n = strlen(s + 1); For(i, 1, n) f[i] = g[i] = 0;
		For(i, 1, n) For(j, i + 1, n) v[0][i][j] = eq(s[i], s[j]);
		For(i, 1, lg[n]) For(j, 1, n + 1 - (1 << i)) For(k, j + (1 << i), n + 1 - (1 << i)) 
			v[i][j][k] = v[i - 1][j][k] & v[i - 1][j + (1 << (i - 1))][k + (1 << (i - 1))];
		For(i, 1, n) for (int j = i + 1; j <= n; j += 2) 
			if (ok(i, (i + j) / 2, (i + j + 1) / 2, j)) ++g[i], ++f[j];
		i64 ans = 0; For(i, 1, n - 1) ans += 1ll * f[i] * g[i + 1] % mod; cout << ans << '\n';
	} 
}

int dp[N][N];
void solve() {
	scanf("%s", s + 1), n = strlen(s + 1); For(i, 1, n) f[i] = g[i] = 0;
	For(i, 1, n + 1) dp[i][n + 1] = dp[n + 1][i] = 0;
	Rof(i, n, 1) Rof(j, n, i) {
		if (!eq(s[i], s[j])) { dp[i][j] = 0; continue; }
		dp[i][j] = 1 + dp[i + 1][j + 1];
	}
	For(i, 1, n) for (int j = i + 1; j <= n; j += 2) 
		if (dp[i][(i + j + 1) / 2] >= (j - i + 1) / 2) ++g[i], ++f[j];
	i64 ans = 0; For(i, 1, n - 1) ans += 1ll * f[i] * g[i + 1] % mod; cout << ans << '\n';
}

signed main() {
	freopen("excellent.in", "r", stdin);
	freopen("excellent.out", "w", stdout);
    For(i, 2, 3000) lg[i] = lg[i >> 1] + 1;
    int T = read(); while (T--) solve();
	return 0;
}