#include <bits/stdc++.h>
using namespace std;
int t, n, ans;
int l[4000], r[4000];
char s[4000];
int main()
{
    freopen("excellent.in", "r", stdin);
    freopen("excellent.out", "w", stdout);
    scanf("%d", &t);
    while (t--)
    {
        scanf("%s", s);
        n = strlen(s);
        ans = 0;
        memset(l, 0, sizeof l);
        memset(r, 0, sizeof r);
        for (int i = 1; i < n; i++)
            for (int j = 0, x = 0; i + j < n; j++)
                if ((x = (s[j] == s[i + j] || s[j] == '?' || s[i + j] == '?') * (x + 1)) >= i)
                    l[j - i + 1]++, r[i + j + 1]++;
        for (int i = 1; i < n; i++)
            ans += l[i] * r[i];
        printf("%d\n", ans);
    }
    return 0;
}