#include <bits/stdc++.h>
using namespace std;
#define int long long
int m, t, n, q;
char c;
vector<pair<int, int>> d;
map<int, pair<int, int>> s[3];
map<int, pair<int, int>>::iterator p[3];
auto calc(int x, int k)
{
    pair res(LLONG_MAX / 2, LLONG_MAX / 2);
    if (t - x <= m && x <= t)
        res = {(k == 2) * (t - x), (k == 1) * (t - x)};
    for (int i = 0; i < 3; i++)
        if (p[i] = s[i].upper_bound(x); p[i] != s[i].end() && p[i]->first - x <= m)
            res = min(res, {p[i]->second.first + (k == 2) * (p[i]->first - x), p[i]->second.second + (k == 1) * (p[i]->first - x)});
    if (k == 1)
        if (p[2] != s[2].end() && p[2]->first - x <= m)
            if (!(p[1] != s[1].end() && p[1]->first - x <= m))
                if (!(p[0] != s[0].end() && p[0]->first - x <= m))
                    res = min(res, {p[2]->second.first - m + (p[2]->first - x), p[2]->second.second + m});
    if (k == 0)
        if (p[2] != s[2].end() && p[2]->first - x <= m)
            if (!(p[1] != s[1].end() && p[1]->first - x <= m))
                if (!(p[0] != s[0].end() && p[0]->first - x <= m))
                    res = min(res, {p[2]->second.first - m + (p[2]->first - x), p[2]->second.second});
    if (k == 0)
        if (p[1] != s[1].end() && p[1]->first - x <= m)
            if (!(p[0] != s[0].end() && p[0]->first - x <= m))
                res = min(res, {p[1]->second.first, p[1]->second.second - m + (p[1]->first - x)});
    return res;
}
signed main()
{
    freopen("car.in", "r", stdin);
    freopen("car.out", "w", stdout);
    scanf("%lld%lld%lld%lld", &m, &t, &n, &q);
    for (int i = 0, x; i < n; i++)
        scanf("%lld %*c%c", &x, &c), s[(c != 'M') + (c == 'S')][x], d.emplace_back(x, (c != 'M') + (c == 'S'));
    sort(d.begin(), d.end(), greater());
    for (auto [x, k] : d)
        s[k][x] = calc(x, k);
    for (int i = 0, x; i < q; i++)
    {
        scanf("%lld", &x);
        auto [a, b] = calc(x, 0);
        if (a > LLONG_MAX / 4)
            puts("-1");
        else
            printf("%lld %lld\n", a, b);
    }
    return 0;
}