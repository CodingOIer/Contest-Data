#include <bits/stdc++.h>
using namespace std;
int t, n, m;
int a[200000], b[200000], c[200000], d[200000];
int f[20][200000];
vector<int> e[200000], g[200000];
void dfs(int x)
{
    for (int y : e[x])
        if (y != f[0][x])
            f[0][y] = x, c[y] = c[x] + 1, dfs(y);
}
int lca(int x, int y)
{
    if (c[x] < c[y])
        swap(x, y);
    for (int i = 16; i >= 0; i--)
        if (c[x] - c[y] >= 1 << i)
            x = f[i][x];
    for (int i = 16; i >= 0; i--)
        if (f[i][x] != f[i][y])
            x = f[i][x], y = f[i][y];
    return x == y ? x : f[0][x];
}
void read(int &x)
{
    char c = getchar();
    while (!isdigit(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
int main()
{
    freopen("robot.in", "r", stdin);
    freopen("robot.out", "w", stdout);
    read(t);
    while (t--)
    {
        read(n);
        for (int i = 1; i <= n; i++)
            e[i].clear();
        for (int i = 1, x, y; i < n; i++)
            read(x), read(y), e[x].push_back(y), e[y].push_back(x);
        dfs(1);
        for (int i = 0; i < 16; i++)
            for (int j = 1; j <= n; j++)
                f[i + 1][j] = f[i][f[i][j]];
        read(m);
        for (int i = 1; i <= m; i++)
            read(a[i]), read(b[i]), g[i].clear(), d[i] = 0;
        for (int i = 1; i <= m; i++)
            for (int j = 1, x = lca(a[i], b[i]); j <= m; j++)
            {
                if (i != j && minmax(lca(a[i], a[j]), lca(b[i], a[j])) == minmax(a[j], x))
                    g[i].push_back(j), d[j]++;
                if (i != j && minmax(lca(a[i], b[j]), lca(b[i], b[j])) == minmax(b[j], x))
                    g[j].push_back(i), d[i]++;
            }
        queue<int> q;
        for (int i = 1; i <= m; i++)
            if (!d[i])
                q.push(i);
        while (q.size())
        {
            int x = q.front();
            q.pop();
            m--;
            for (int y : g[x])
                if (!--d[y])
                    q.push(y);
        }
        puts(m ? "No" : "Yes");
    }
    return 0;
}