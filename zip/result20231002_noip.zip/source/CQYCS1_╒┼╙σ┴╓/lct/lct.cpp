#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline ll read(){ll s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=4e7+5,inf=2147000000;
const ll mod=998244353;
const ui base=131;
using namespace std;
int n,m,h[N],to[N<<1],nxt[N<<1],cnt,w[N<<1],dep[N],f[N][20],g[N][20];
inline int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
inline void add(int a,int b,int c){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,w[cnt]=c;
}
struct edge{
	int x,y,w;
}e[N];
inline void dfs(int x,int fa){
	f[x][0]=fa,dep[x]=dep[fa]+1;
	rep(i,1,15)f[x][i]=f[f[x][i-1]][i-1],g[x][i]=gcd(g[x][i-1],g[f[x][i-1]][i-1]);
	e(x)if(y^fa)g[y][0]=w[i],dfs(y,x);
}
inline int lca(int x,int y){
	int ans;
	if(dep[x]<=dep[y])ans=g[x][0];
	else ans=g[y][0];
	if(ans==1)return 1;
	if(dep[x]<dep[y])swap(x,y);
	int del=dep[x]-dep[y],p=0;
	while(del){
		if(del&1)ans=gcd(ans,g[x][p]),x=f[x][p];
		if(ans==1)return 1;
		p++,del>>=1;
	}
	per(i,15,0)if(f[x][i]^f[y][i]){
		ans=gcd(gcd(g[x][i],g[y][i]),ans),x=f[x][i],y=f[y][i];
		if(ans==1)return 1;
	}
	if(x==y)return ans;
	return gcd(ans,gcd(g[x][0],g[y][0]));
}
inline void solve(){
	cnt=0;
	rep(i,1,n)h[i]=0;
	rep(i,1,n-1)add(e[i].x,e[i].y,e[i].w),add(e[i].y,e[i].x,e[i].w);
	dfs(1,0);
	ll ans=0;
	rep(i,1,n)rep(j,i+1,n)ans+=(lca(i,j)==1);
	pf(ans),putchar('\n');
}
int main(){
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	n=read(),m=read();
	rep(i,1,n-1)e[i].x=read(),e[i].y=read(),e[i].w=read();
	solve();
	for(int i=1,id,x,y,w;i<=m;i++)id=read(),x=read(),y=read(),w=read(),e[id]={x,y,w},solve();
	return 0;
}
