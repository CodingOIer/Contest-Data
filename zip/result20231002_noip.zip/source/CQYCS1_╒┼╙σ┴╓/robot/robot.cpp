#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1.2e5+5,M=1e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int T,n,m,h[N],to[N<<1],nxt[N<<1],cnt;
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt;
}
struct node{
	int x,y,len;
}q[N];
int f[N],dep[N],siz[N],son[N],dfn[N],Time,top[N];
inline void dfs(int x,int fa){
	f[x]=fa,dep[x]=dep[fa]+1,siz[x]=1;
	e(x)if(y^fa)dfs(y,x),siz[x]+=siz[y],son[x]=siz[y]>siz[son[x]]?y:son[x]; 
} 
inline void Dfs(int x,int low){
	top[x]=low,dfn[x]=++Time;
	if(son[x])Dfs(son[x],low);
	e(x)if(y^son[x]&&y^f[x])Dfs(y,y);
}
struct seg{
	int w;bool laz;
}xd[N<<2];
inline void rev(int x,int l,int r){
	xd[x].laz^=1,xd[x].w=r-l+1-xd[x].w;
}
inline void pushdown(int x,int l,int r){
	if(xd[x].laz)rev(lc),rev(rc),xd[x].laz=0;
}
inline void getup(int x){
	xd[x].w=xd[L].w+xd[R].w;
}
inline void build(int x,int l,int r){
	xd[x]={0,0};
	if(l==r)return;
	build(lc),build(rc);
}
inline void modify(int x,int l,int r,int Ll,int Rr){
	if(OK)return rev(x,l,r),void();
	pushdown(x,l,r);
	if(Ll<=mid&&Rr>=l)modify(lc,Ll,Rr);
	if(Ll<=r&&Rr>mid)modify(rc,Ll,Rr);
	getup(x);
}
inline int query(int x,int l,int r,int Ll,int Rr){
	if(OK)return xd[x].w;
	pushdown(x,l,r);
	if(Rr<=mid)return query(lc,Ll,Rr);
	if(Ll>mid)return query(rc,Ll,Rr);
	return query(lc,Ll,Rr)+query(rc,Ll,Rr);
}
inline void lca(int x,int y){
	while(top[x]^top[y]){
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		modify(Root,dfn[top[x]],dfn[x]),x=f[top[x]];
	}
	if(dep[x]>dep[y])swap(x,y);
	modify(Root,dfn[x],dfn[y]);
}
inline int got(int x,int y){
	int ans=0;
	while(top[x]^top[y]){
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		ans+=query(Root,dfn[top[x]],dfn[x]),x=f[top[x]];
	}
	if(dep[x]>dep[y])swap(x,y);
	return ans+query(Root,dfn[x],dfn[y]);
}
inline int dist(int x,int y){
	int prex=dep[x],prey=dep[y];
	while(top[x]^top[y])dep[top[x]]>dep[top[y]]?x=f[top[x]]:y=f[top[y]];
	int k=min(dep[x],dep[y]);
	return prex+prey-2*k+1;
}
int main(){
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout); 
	T=read();
	while(T--){
		n=read();
		rep(i,1,n)h[i]=son[i]=0;cnt=Time=0;
		for(int i=1,x,y;i^n;i++)x=read(),y=read(),add(x,y),add(y,x);
		dfs(1,0),Dfs(1,1);
		build(Root);
		m=read();
		rep(i,1,m)q[i].x=read(),q[i].y=read(),q[i].len=dist(q[i].x,q[i].y);
			bool fl=1;
			rep(i,1,m){
				rep(j,i+1,m){
					lca(q[i].x,q[i].y);
					int k=got(q[j].x,q[j].y);
					if(k==q[j].len||k==q[i].len){
						fl=0;
						break;
					}
					if(got(q[j].y,q[j].y)==1){
						lca(q[i].x,q[i].y);
						lca(q[i].y,q[i].y);
						if(got(q[j].x,q[j].y)==1){
							fl=0;
							break;
						}
						lca(q[i].y,q[i].y),lca(q[i].x,q[i].y);
					}
					if(got(q[j].x,q[j].x)==1){
						lca(q[i].x,q[i].y);
						lca(q[i].x,q[i].x);
						if(got(q[j].x,q[j].y)==1){
							fl=0;
							break;
						}
						lca(q[i].x,q[i].x),lca(q[i].x,q[i].y);
					}
				}
				if(!fl)break;
			}
			printf("%s\n",fl?"Yes":"No");
	}
	return 0;
}
