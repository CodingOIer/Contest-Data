#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline ll read(){ll s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =3e3+5,M=4e7+5,inf=2147000000;
const ll mod=998244353;
const ui base=131;
using namespace std;
int T,f[N],g[N],n;
ll ans;
ui H[N],p[N];
char c[N];
inline ui getHash(int l,int r){
	if(r>n)return 0;
	return H[r]-H[l-1]*p[r-l+1];
}
inline bool cmp(int l,int r,int Ll,int Rr){
	rep(i,1,r-l+1){
		if(c[l+i-1]!=c[Ll+i-1]){
			if(c[l+i-1]=='?'||c[Ll+i-1]=='?')continue;
			return 0;
		}
	}
	return 1;
}
bool sam[2005][1005];
int main(){
	freopen("excellent.in","r",stdin);
	freopen("excellent.out","w",stdout);
	p[0]=1;rep(i,1,3000)p[i]=p[i-1]*base;
	T=read();
	while(T--){
		scanf("%s",c+1);
		n=strlen(c+1);
		bool fl=0,flag=0;
		rep(i,1,n){
			if(c[i]=='?')fl=1;
			else flag=1;
		}
		if(!fl){
			rep(i,1,n)f[i]=g[i]=0;
			rep(i,1,n)H[i]=H[i-1]*base+c[i];
			ans=0;
			rep(len,1,n>>1)for(int i=len<<1;i<=n;i+=len){
				if(c[i]!=c[i-len])continue;
				int l=1,r=len,pos=0,Ll,Rr;
				while(l<=r)if(getHash(i-len-mid+1,i-len)==getHash(i-mid+1,i))pos=mid,l=mid+1;
				else r=mid-1;
				Ll=max(i,i-pos+len);
				l=1,r=len,pos=0;
				while(l<=r)if(getHash(i-len,i-len+mid-1)==getHash(i,i+mid-1))pos=mid,l=mid+1;
				else r=mid-1;
				Rr=min(i+len-1,i+pos-1);
				if(Ll<=Rr)g[Ll-(len<<1)+1]++,g[Rr-(len<<1)+2]--,f[Ll]++,f[Rr+1]--;	
			}
			rep(i,1,n)f[i]+=f[i-1],g[i]+=g[i-1];
			rep(i,1,n-1)ans+=f[i]*g[i+1];
			pf(ans),putchar('\n');
			continue;
		}
		if(!flag){
			ans=0;
			for(int i=4;i<=n;i+=2){
				int ct=n-i+1;
				ans+=1LL*ct*(i/2-1); 
			}
			pf(ans),putchar('\n');
			continue;
		}
		ans=0;
		rep(l,1,n-1){
			rep(len,1,n){
				if(l+len*2-1>n)break;
				sam[l][len]=cmp(l,l+len-1,l+len,l+len*2-1);
			}
		}
		rep(l,1,n-3){
			for(int r=l+3;r<=n;r+=2){
				int len=r-l+1;
				rep(lena,1,len/2-1){
					int lenb=len/2-lena;
					if(sam[l][lena]&&sam[r-lenb*2+1][lenb])ans++;
				}
			}
		}
		pf(ans),putchar('\n');
	}
	return 0;
}
