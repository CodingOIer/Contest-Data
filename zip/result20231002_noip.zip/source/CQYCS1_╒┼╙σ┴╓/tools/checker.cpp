#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1.2e5+5,M=1e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int T=1000,a[N],st[N],top;
int main(){
	freopen("robot3.ans","r",stdin); 
	rep(i,1,T){
		string s;
		cin >>s;
		a[i]=s=="Yes";
	}
	freopen("robot3.out","r",stdin);
	rep(i,1,T){
		string s;
		cin >>s;
		bool f=s=="Yes";
		if(f^a[i]){
			cerr<<"On test "<<i<<",the answer is "<<a[i]<<",but you put "<<f<<".\n";
			st[++top]=i;
		}
	}
	int l=1;
	freopen("robot3.in","r",stdin);
	T=read();
	rep(i,1,T){
		int n=read();
		if(l<=top&&st[l]==i){
			cerr<<"Case "<<i<<" is like:\n"<<n<<'\n'; 
			for(int j=1,x,y;j^n;j++)x=read(),y=read(),cerr<<x<<" "<<y<<'\n';
			int m=read();
			cerr<<m<<'\n';
			rep(j,1,m)cerr<<read()<<" ",cerr<<read()<<'\n';
			
		}
		else {
			rep(j,1,n-1)read(),read();
			int m=read();
			rep(j,1,m)read(),read();
		}
	}
	return 0;
}
