#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1.2e5+5,Mxk=300;
int T,N,M,Tp,A[Mxn],B[Mxn],Sk[Mxn],Dp[Mxn],F[Mxk][Mxk];
int Sz[Mxn],Fa[Mxn],Sn[Mxn],Top[Mxn];
int Ct,Nt[Mxn<<1],To[Mxn<<1],Hd[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Merge(int x,int y) {
	Nt[++Ct]=Hd[x],To[Ct]=y,Hd[x]=Ct;
	Nt[++Ct]=Hd[y],To[Ct]=x,Hd[y]=Ct;
}
void DFS(int x,int p) {
	Sk[++Tp]=x,Dp[x]=Dp[p]+1;
	Sz[x]=1,Fa[x]=p;
	For(i,1,Tp) F[x][Sk[i]]=1;
	for(int v,i=Hd[x];i;i=Nt[i]) {
		if((v=To[i])!=p) {
			DFS(v,x),Sz[x]+=Sz[v];
			if(Sz[v]>Sz[Sn[x]]) Sn[x]=v;
		}
	}
	--Tp;
}
void TOP(int x,int t) {
	Top[x]=t;
	if(Sn[x]) TOP(Sn[x],t);
	for(int v,i=Hd[x];i;i=Nt[i]) {
		if((v=To[i])!=Fa[x]&&v!=Sn[x]) {
			TOP(v,v);
		}
	}
}
bool cmp(int x,int y) {return Dp[x]<Dp[y];}
int GetLca(int a,int b) {
	while(Top[a]!=Top[b]) {
		if(Dp[Top[a]]>Dp[Top[b]]) a=Fa[Top[a]];
		else b=Fa[Top[b]];
	}
	return Dp[a]<Dp[b]?a:b;
}
bool On(int x,int l,int r) {
	if(Dp[l]>Dp[r]) swap(l,r);
	if(F[r][l]) {
		if(F[r][x]&&F[x][l]) return 1;
		else return 0;
	}
	else {
		int lca=GetLca(l,r);
		if(F[r][x]&&F[x][lca]) return 1;
		else if(F[l][x]&&F[x][lca]) return 1;
		else return 0;
	}
}
bool Check() {
	For(i,1,M) For(j,i+1,M) {
		if(On(B[i],A[j],B[j])&&On(B[j],A[i],B[i])) return 0;
		int x[5];
		x[1]=A[i],x[2]=B[i],x[3]=A[j],x[4]=B[j];
		sort(x+1,x+5,cmp);
		if(F[x[2]][x[1]]&&F[x[3]][x[1]]&&F[x[4]][x[1]]&&F[x[3]][x[2]]&&F[x[4]][x[2]]&&F[x[4]][x[3]]) {
			if(A[i]==x[1]&&B[i]==x[4]) return 0;
			if(A[j]==x[1]&&B[j]==x[4]) return 0;
			if(B[i]==x[1]&&A[i]==x[4]) return 0;
			if(B[j]==x[1]&&A[j]==x[4]) return 0;
		}
		else {
			if(F[A[i]][A[j]]&&F[B[i]][B[j]]) return 0;
			if(F[A[i]][B[j]]&&F[B[i]][A[j]]) return 0;
			if(F[A[j]][A[i]]&&F[B[j]][B[i]]) return 0;
			if(F[A[j]][B[i]]&&F[B[j]][A[i]]) return 0;
		}
//		int Mn=A[i],Mx=A[i];
//		bool FMn=1,FMx=1;
//		if(Dp[B[i]]<Dp[Mn]) Mn=B[i],FMn=1;
//		if(Dp[A[j]]<Dp[Mn]) Mn=A[j],FMn=0;
//		if(Dp[B[j]]<Dp[Mn]) Mn=B[j],FMn=0;
//		
//		if(Dp[B[i]]>Dp[Mx]) Mx=B[i],FMx=1;
//		if(Dp[A[j]]>Dp[Mx]) Mx=A[j],FMn=0;
//		if(Dp[B[j]]>Dp[Mx]) Mx=B[j],FMn=0;
	}
	return 1;
}
signed main() {
	freopen("robot.in","r",stdin);
	freopen("robot.out","w",stdout);
	T=_();
	while(T--) {
		N=_(),Ct=0;
		For(i,1,N) For(j,1,N) Hd[i]=F[i][j]=0;
		For(i,2,N) Merge(_(),_());
		DFS(1,0);
		TOP(1,1);
//		For(i,1,N) {
//			For(j,1,N) pt("%d ",F[i][j]); 
//			pc('\n');
//		}
//		pc('\n');
		M=_();
		For(i,1,M) 
			A[i]=_(),B[i]=_();
		pt(Check()?"Yes\n":"No\n");
	} 
	return 0;
}
