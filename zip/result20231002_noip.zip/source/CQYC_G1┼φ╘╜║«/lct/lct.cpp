#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e5+5;
int N,Q,Ans,X[Mxn],Y[Mxn],C[Mxn],Fa[Mxn],Up[Mxn],Dp[Mxn];
int Ct,Nt[Mxn<<1],To[Mxn<<1],Vl[Mxn<<1],Hd[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Merge(int x,int y,int v) {
	Nt[++Ct]=Hd[x],To[Ct]=y,Vl[Ct]=v,Hd[x]=Ct;
}
void DFS(int x) {
	for(int v,i=Hd[x];i;i=Nt[i]) {
		if((v=To[i])!=Fa[x]) {
			Fa[v]=x,Up[v]=Vl[i],Dp[v]=Dp[x]+1,DFS(v);
		}
	}
}
bool Check(int x,int y) {
	int G=0;
	if(Dp[x]<Dp[y]) swap(x,y);
	while(Dp[x]>Dp[y]) {
		G=G?__gcd(G,Up[x]):Up[x],x=Fa[x];
		if(G==1) return 1;
	}
	if(x!=y&&!G) G=__gcd(Up[x],Up[y]),x=Fa[x],y=Fa[y];
	if(G==1) return 1;
	while(x!=y) {
		G=__gcd(G,Up[x]),G=__gcd(G,Up[y]);
		if(G==1) return 1;
		x=Fa[x],y=Fa[y];
	}
	if(G==1) return 1;
	return 0;
}
void Solve() {
	For(i,2,N) Merge(X[i],Y[i],C[i]),Merge(Y[i],X[i],C[i]);
	Dp[1]=1,DFS(1);
	For(i,1,N) For(j,i+1,N) {
		Ans+=Check(i,j);
	}
}
signed main() {
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	N=_(),Q=_();
	For(i,2,N) {
		X[i]=_(),Y[i]=_(),C[i]=_();
//		int x=_(),y=_(),c=_();
//		F[x][y]=F[y][x]=c;
//		Merge(x,y,c),Merge(y,x,c);
	}
	Solve(),__(Ans),pc('\n');
	Q=_();
	while(Q--) {
		int k=_();
		X[k]=_(),Y[k]=_(),C[k]=_();
		Solve(),__(Ans),pc('\n');
	}
	return 0;
}
