/*
    Program: goto.cpp
    Author: 1l6suj7
    DateTime: 2023-10-30 08:07:11
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second

using namespace std;

const int N = 500010;

int n, K;
ll a[N], f[N], s[N], g[N];

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

signed main() {
    freopen("goto.in", "r", stdin);
    freopen("goto.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read(), K = read();
    lp(i, 1, n) a[i] = read(), s[i] = s[i - 1] + a[i];
    lp(i, 1, n) {
        if(i >= K) f[i] = max(f[i - 1], s[i] + g[i - K]);
        g[i] = max(g[i - 1], f[i] - s[i]);
    }
    printf("%lld", f[n]);
    return 0;
}
/*
f[i] = max { f[j] + s[i] - s[j] }
i - j >= K
*/