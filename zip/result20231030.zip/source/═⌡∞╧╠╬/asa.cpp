/*
    Program: asa.cpp
    Author: 1l6suj7
    DateTime: 2023-10-30 08:36:39
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second

using namespace std;

const ll N = 2000000;
const ll MOD = 998244353;
const ll rev2 = 499122177;

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

ll prm[N + 10], mu[N + 10], ms[N + 10], ms2[N + 10], cnt;
bool nprm[N + 10];

void init() {
    mu[1] = 1, nprm[1] = 1;
    lp(i, 2, N) {
        if(!nprm[i]) prm[++cnt] = i, mu[i] = -1;
        for(int j = 1; j <= cnt && i * prm[j] <= N; ++j) {
            nprm[i * prm[j]] = 1;
            if(i % prm[j] == 0) { mu[i * prm[j]] = 0; break; }
            mu[i * prm[j]] = -mu[i];
        }
    }
    lp(i, 1, N) ms[i] = ms[i - 1] + mu[i], ms2[i] = ms2[i - 1] + (mu[i] == 0);
}

ll calcf(ll n) {
    ll i = 1, res = 0;
    while(i <= n) {
        ll j = min(n, n / (n / i)), t = n / i;
        res = (res + t * t % MOD * (ms[j] - ms[i - 1])) % MOD;
        i = j + 1;
    }
    return (res % MOD + MOD) % MOD;
}

ll calcg(ll n) {
    ll i = 1, res = 0;
    while(i <= n) {
        ll j = min(n, n / (n / i)), t = calcf(n / i);
        res = (res + t * (ms2[j] - ms2[i - 1]) % MOD) % MOD;
        i = j + 1;
    }
    return res;
}

// ll calc(ll n) {
//     ll res = 0;
//     lp(i, 1, n) lp(j, 1, n) res += mu[__gcd(i, j)] == 0;
//     return res;
// }

ll T, n;

signed main() {
    freopen("asa.in", "r", stdin);
    freopen("asa.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    init();
    T = read();
    while(T--) {
        n = read();
        printf("%lld\n", calcg(n));
    }
    return 0;
}