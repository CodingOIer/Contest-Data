/*
    Program: yuukei.cpp
    Author: 1l6suj7
    DateTime: 2023-10-30 09:33:44
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second

using namespace std;

const int N = 210;
const ll MOD = 1e9 + 7;

struct edge { int v, nxt; } E[N << 1];
int en, hd[N];

void add(int u, int v) { E[++en] = {v, hd[u]}, hd[u] = en; }

int n, R, B, G, num[4], c[N], du[N];
string s;

namespace S1 {
    ll f[N][N], g[N][N];
    void dfs(int now, int fa) {
        for(int i = hd[now]; i; i = E[i].nxt) {
            int v = E[i].v;
            if(v == fa) continue;
            dfs(v, now);
        }
        g[now][0] = 1;
        if(c[now] != 1) return;
        int cnt = 1;
        mst(f, 0);
        f[0][0] = 1;
        for(int i = hd[now]; i; i = E[i].nxt) {
            int v = E[i].v;
            if(v == fa) continue;
            // co(now), cod(v);
            lp(j, 0, R) {
                lp(k, 0, j) {
                    f[cnt][j] = (f[cnt][j] + f[cnt - 1][j - k] * g[v][k]) % MOD;
                }
            }
            ++cnt;
        }
        lp(i, 1, R) g[now][i] = (g[now][i] + f[cnt - 1][i - 1]) % MOD;
        // co(now), co(cnt), cod(f[cnt - 1][1]);
    }

    void solve1() {
        dfs(1, 0);
        ll ans = 0;
        lp(i, 1, n) if(c[i] == 1) lp(j, 1, R) ans = (ans + g[i][j]) % MOD;
        printf("%lld\n", ans);
    }
}

namespace S2 {
    ll qpow(ll x, int k) {
        ll res = 1;
        while(k) {
            if(k & 1) res = res * x % MOD;
            x = x * x % MOD, k >>= 1;
        }
        return res;
    }

    ll fac[N], ifac[N];
    void init() {
        fac[0] = 1;
        lp(i, 1, n) fac[i] = fac[i - 1] * i % MOD;
        ifac[n] = qpow(fac[n], MOD - 2);
        dlp(i, n, 1) ifac[i - 1] = ifac[i] * i % MOD;
    }

    ll C(ll a, ll b) { return a >= b? fac[a] * ifac[a - b] * ifac[b] : 0; }

    void solve2(int rt) {
        init();
        ll t[] = {0, 0, 0, 0};
        lp(i, 1, n) ++t[c[i]];
        ll ans = 0;
        if(num[c[rt]] > 0) {
            ll res = 1;
            lp(i, 1, 3) if(i != c[rt]) {
                ll tmp = 0;
                lp(j, 0, num[i]) tmp = (tmp + C(t[i], j)) % MOD;
                res = res * tmp % MOD;
            }
            ll tmp = 0;
            lp(j, 0, num[c[rt]] - 1) tmp = (tmp + C(t[c[rt]] - 1, j)) % MOD;
            ans = res * tmp % MOD;

        }
        lp(i, 1, 3) if(num[i] > 0) ans += t[i];
        printf("%lld\n", ((ans - 1) % MOD + MOD) % MOD);
    }
}

namespace S3 {
    int fa[N];

    int fd(int x) { return x == fa[x]? x : (fa[x] = fd(fa[x])); }

    void solve3() {
        int len = 1 << n, ans = 0;
        lp(s, 0, len - 1) {
            int cnt[4] = {0, 0, 0, 0};
            lp(i, 0, n - 1) if((1 << i) & s) ++cnt[c[i + 1]];
            if(cnt[1] > num[1] || cnt[2] > num[2] || cnt[3] > num[3]) continue;
            lp(i, 1, n) fa[i] = i;
            int t = cnt[1] + cnt[2] + cnt[3];
            lp(i, 1, n) {
                if((1 << (i - 1)) & s) {
                    int x = fd(i);
                    for(int j = hd[i]; j; j = E[j].nxt) {
                        int v = E[j].v;
                        if((1 << (v - 1)) & s) {
                            int y = fd(v);
                            if(x != y) fa[y] = x, --t;
                        }
                    }
                }
            }
            if(t == 1) ++ans;
        }
        printf("%d", ans);
    }
}

signed main() {
    freopen("yuukei.in", "r", stdin);
    freopen("yuukei.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    cin >> n >> R >> B >> G >> s;
    num[1] = R, num[2] = G, num[3] = B;
    for(int i = 0; i < s.size(); ++i) {
        if(s[i] == 'r') c[i + 1] = 1;
        else if(s[i] == 'g') c[i + 1] = 2;
        else c[i + 1] = 3;
    }
    int u, v;
    lp(i, 1, n - 1) cin >> u >> v, add(u, v), add(v, u), ++du[u], ++du[v];
    if(B == 0 && G == 0) return S1::solve1(), 0;
    lp(i, 1, n) if(du[i] == n - 1) return S2::solve2(i), 0;
    S3::solve3();
    return 0;
}
/*
5
1 0 0
rbrrg
1 2
1 3
3 4
4 5
*/