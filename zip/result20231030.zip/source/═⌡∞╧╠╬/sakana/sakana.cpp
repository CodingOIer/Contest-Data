/*
    Program: sakana.cpp
    Author: 1l6suj7
    DateTime: 2023-10-30 10:54:51
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) (x << 1)
#define rc(x) ((x << 1) ^ 1)
#define co(x) cout << x << ' '
#define cod(x) cout << x << endl
#define pb(x) emplace_back(x)
#define mkp(x, y) makepair(x, y)
#define pii pair<int, int>
#define pll pair<ll, ll>,
#define fi first
#define se second

using namespace std;

const int N = 500010;

int n;
ll a[N], ans;
bool vis[N];

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

signed main() {
    freopen("sakana.in", "r", stdin);
    freopen("sakana.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read();
    ll mx = 0, mn = MAX8;
    lp(i, 1, n) a[i] = read(), mx = max(mx, a[i]), mn = min(mn, a[i]);
    lp(i, 1, n - 1) {
        if(i == 1) {
            if(abs(a[i] + a[i + 1] - mx) < max(abs(a[i] - mx), abs(a[i + 1] - mx))) vis[i] = vis[i + 1] = 1, ans = max(ans, abs(a[i] + a[i + 1] - mx));
            else ans = max(ans, abs(a[i] - mx));
            continue;
        }
        if(!vis[i] && abs(a[i] + a[i + 1] - mx) < max(abs(a[i] - mx), abs(a[i + 1] - mx))) vis[i] = vis[i + 1] = 1, ans = max(ans, abs(a[i] + a[i + 1] - mx));
        else if(!vis[i]) ans = max(ans, abs(a[i] - mx));
    }
    if(!vis[n]) ans = max(ans, abs(a[n] - mx));
    printf("%lld\n", ans);
    return 0;
}