#include<bits/stdc++.h>
#define meow(args...) fprintf(stderr, args)
typedef unsigned u32;
const u32 P=1e9+7;
int n, r, b, g, mx, head[201], to[400], next[400], size[201], vlist[201], tot, dfn[201], dfr[201];
u32 f[201][40460], ans;
char s[202];
bool vis[200];
void measure(int x) {
	vlist[++tot]=x;
	size[x]=1;
	for(int i=head[x]; i; i=next[i]) {
		if(!vis[i/2]) {
			vis[i/2]=true;
			measure(to[i]);
			size[x]+=size[to[i]];
			vis[i/2]=false;
		}
	}
}
void dfs(int x) {
	vlist[++tot]=x;
	dfn[x]=tot;
	for(int i=head[x]; i; i=next[i]) {
		if(!vis[i/2]) {
			vis[i/2]=true;
			dfs(to[i]);
			vis[i/2]=false;
		}
	}
	dfr[x]=tot;
}
void inc(u32 &a, u32 b) {
	a+=b;
	if(a>=P) a-=P;
}
void de(int x) {
	int c;
	tot=0;
	measure(x);
	for(int i=1; i<=tot; ++i) {
		bool ok;
		c=vlist[i];
		ok=size[c]*2>=tot;
		for(int j=head[c]; j && ok; j=next[j])
			ok &= size[to[j]]>size[c] || size[to[j]]*2<=tot;
		if(ok) break;
	}
	tot=0;
	dfs(c);
	memset(f[tot], 0, mx*sizeof(u32));
	f[tot][0]=1;
	for(int i=tot; i--; ) {
		int v=vlist[i+1];
		u32 *F=f[i], *G=f[i+1];
		memcpy(F, f[dfr[v]], mx*sizeof(u32));
		for(int j=0; j<mx; ++j) {
			if(s[v]=='r'&&j/(b+1)/(g+1)) inc(F[j], G[j-(g+1)*(b+1)]);
			if(s[v]=='g'&&j/(b+1)%(g+1)) inc(F[j], G[j-(b+1)]);
			if(s[v]=='b'&&j%(b+1)) inc(F[j], G[j-1]);
		}
	}
	for(int i=1; i<mx; ++i) inc(ans, f[0][i]);
	for(int i=head[c]; i; i=next[i]) {
		if(!vis[i/2]) {
			vis[i/2]=true;
			de(to[i]);
		}
	}
}
int main() {
	freopen("yuukei.in", "r", stdin);
	freopen("yuukei.out", "w", stdout);
	scanf("%d%d%d%d%s", &n, &r, &b, &g, s+1);
	mx=(r+1)*(g+1)*(b+1);
	for(int i=1, j=2; i<n; ++i) {
		int x, y;
		scanf("%d%d", &x, &y);
		to[j]=y;
		next[j]=head[x];
		head[x]=j++;
		to[j]=x;
		next[j]=head[y];
		head[y]=j++;
	}
	de(1);
	printf("%u\n", ans);
	return 0;
}
