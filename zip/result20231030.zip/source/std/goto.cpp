#include<bits/stdc++.h>
# define N 5000010
# define reg register
# define getc() (S==T && (T=(S=B)+fread(B,1,1<<15,stdin),S==T)?EOF:*S++)
char B[1<<15],*S=B,*T=B;
int In() {
	reg int x=0; reg char ch=getc(); reg bool f=0;
	for(;ch<'0' || ch>'9';ch=getc()) f=ch=='-';
	for(;ch>='0' && ch<='9';ch=getc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
long long f[N],fs[N];
long long max(long long x,long long y) {return x>y?x:y;}
int main() {
	freopen("goto.in", "r", stdin);
	freopen("goto.out", "w", stdout);
	int n=In(),k=In();
	long long sum=0;
	for(reg int i=1;i<k;i++) sum+=In(), fs[i]=max(fs[i-1],-sum);
	for(reg int i=k;i<=n;i++) {
		sum+=In();
		f[i]=max(fs[i-k]+sum,f[i-1]);
		fs[i]=max(fs[i-1],f[i]-sum);
	}
	printf("%lld",f[n]);
	return 0;
}
