#include<bits/stdc++.h>
#define re register
#define mp std::make_pair
#define X first
#define Y second
typedef std::pair<int,int> pii;
typedef long long ll;
typedef unsigned long long ull;
const int MAXN=1e6+10,mod=998244353;
int T,pr[MAXN],tot,mu[MAXN];
bool p[MAXN];
ll n,ans;
ll read()
{
	ll x=0,w=0;
	char ch=0;
	while(ch<'0'||ch>'9') w|=ch=='-',ch=getchar();
	while('0'<=ch&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return w?-x:x; 
}
void Euler()
{
	mu[1]=1;
	for(re int i=2;i<=1000000;i++) 
	{
		if(!p[i]) pr[++tot]=i,mu[i]=-1;
		for(re int j=1;j<=tot&&i*pr[j]<=1000000;j++)
		{
			p[i*pr[j]]=1;
			if(i%pr[j]==0) {mu[i*pr[j]]=0;break;}
			mu[i*pr[j]]=-mu[i];
		}
	}
}
int main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	//for(re int i=1;i<=10000000;i++) pd[i]=-1;
	Euler();
	T=read();
	while(T--)
	{
		n=read();
		ans=0;
		for(re int i=2;1ll*i*i<=n;i++) if(mu[i]) 
			ans=(ans-1ll*(mu[i]*(n/(1ll*i*i))%mod)*((n/(1ll*i*i))%mod))%mod;
		printf("%lld\n",(ans+mod)%mod);
	}
	return 0;
}
