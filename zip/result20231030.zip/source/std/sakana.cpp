#include<bits/stdc++.h>
#define reg register
#define maxn 500010
#define cmax(a,b) (a<(b)?a=(b),1:0)
#define getchar() (_S==_T&&(_T=(_S=_B)+fread(_B,1,1<<15,stdin),_S==_T)?EOF:*_S++)
char _B[1<<15],*_S=_B,*_T=_B;
int read() {
	reg int s=0,f=1; reg char ch;
	for(;(ch=getchar())<'0'||ch>'9';ch=='-'?f=-f:0);
	for(;ch>='0'&&ch<='9';s=s*10+ch-'0',ch=getchar());
	return s*f;
}
const int inf=2e9;
int n,N,mx,cnt1,cnt2,ans,a[maxn],b[maxn];
int max(reg int a,reg int b) {return a>b?a:b;}
int min(reg int a,reg int b) {return a<b?a:b;}
bool cmin(reg int&a,reg int b) {return a>b?a=b,1:0;}
struct P{
	int v,x;
	bool operator<(reg const P&a)const{return v<a.v;}
}p[maxn];
struct vec{int a[2];};
struct mat{int a[2][2];}m[1<<20];
vec operator*(reg vec a,reg mat b) {
	return (vec){max(min(a.a[0],b.a[0][0]),min(a.a[1],b.a[1][0])),
				 max(min(a.a[0],b.a[0][1]),min(a.a[1],b.a[1][1]))};
}
mat operator*(reg mat a,reg mat b) {
	return (mat){max(min(a.a[0][0],b.a[0][0]),min(a.a[0][1],b.a[1][0])),
				 max(min(a.a[0][0],b.a[0][1]),min(a.a[0][1],b.a[1][1])),
				 max(min(a.a[1][0],b.a[0][0]),min(a.a[1][1],b.a[1][0])),
				 max(min(a.a[1][0],b.a[0][1]),min(a.a[1][1],b.a[1][1]))};
}
int main() {
	freopen("sakana.in", "r", stdin);
	freopen("sakana.out", "w", stdout);
	n=read();
	for(N=1;N<=n;N<<=1);
	for(reg int i=1;i<=n;++i) a[i]=read(),cmax(mx,a[i]),m[i+N]=(mat){a[i],inf,0,0};
	for(reg int i=2;i<=n;++i) if(a[i]+a[i-1]>mx) p[++cnt1]={b[++cnt2]=a[i]+a[i-1],i}; else m[i+N].a[1][0]=a[i]+a[i-1];
	std::sort(p+1,p+cnt1+1),std::sort(b+1,b+cnt2+1),cnt2=std::unique(b+1,b+cnt2+1)-b-1,m[N]=(mat){inf,inf,inf,inf};
	for(reg int i=n+1;i<=N;++i) m[i+N]=(mat){inf,inf,inf,inf};
	for(reg int i=N-1;i;--i) m[i]=m[i<<1]*m[i<<1|1];
	ans=mx-((vec){inf,inf}*m[1]).a[0];
	for(reg int i=1,k=1;i<=cnt2;++i) {
		for(reg int x;p[k].v==b[i];++k)
			for(m[x=p[k].x+N].a[1][0]=b[i];x>>=1;m[x]=m[x<<1]*m[x<<1|1]);
		cmin(ans,b[i]-((vec){inf,inf}*m[1]).a[0]);
	}
	printf("%d",ans);
	return 0;
}
