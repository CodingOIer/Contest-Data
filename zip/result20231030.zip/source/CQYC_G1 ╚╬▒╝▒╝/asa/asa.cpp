#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e6+5 ;
const int MOD = 998244353 ;
int T,n,top ;
int pri[N],vis[N] ;
int check(int k,int val)
{
    FOR(i,2,100,1)
    {
        int res = 1 ;
        FOR(j,1,k,1) res *= i ;
        if(res > val) break ;
        if(val%res == 0) return 1 ;
    }
    return 0 ;
}
int Check(int a,int b)
{
    FOR(k,2,13,1) 
    {
        int op = 1 ;
        FOR(x,1,200,1) op &= check(k,a*x+b) ;
        if(op) return 1 ;
    }
    return 0 ;
}
vector<int>p[N] ;
void Solve()
{
    // read(n) ; int ans= 0 ;
    // FOR(i,1,n,1) FOR(j,1,n,1) if(Check(i,j)) ++ans ; //print(i,j),enter ;
    // print(ans),enter ;
    read(n) ; int ans = 0 ;
    FOR(i,1,n,1)
    {
        if(!p[i].size()) continue ; int si = p[i].size() ;
        FOR(S,1,(1<<si)-1,1)
        {
            int tot = 0,res = 1 ;
            FOR(j,0,si-1,1) if((S>>j)&1)
                ++tot,res *= p[i][j] ;
            ans += (tot&1)?n/res:MOD-n/res,ans %= MOD ;
        }
    }
    print(ans),enter ;
}
void Init()
{
    FOR(i,2,N-5,1)
    {
        if(vis[i]) continue ;
        pri[++top]  = i ;
        FOR(j,2*i,N-5,i) vis[j] = 1 ;
    }
    FOR(i,1,top,1)
    {
        int g = pri[i]*pri[i] ;
        FOR(j,g,N-5,g) p[j].pb(g) ;
    }
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("asa.in","r",stdin) ;
	freopen("asa.out","w",stdout) ;
    read(T),Init() ; while(T--) Solve() ; //cerr<<(double)clock()/CLOCKS_PER_SEC<<"\n" ;
    return 0 ;
}