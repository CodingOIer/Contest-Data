#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 205 ;
const int M = 65 ;
const int MOD = 998244353 ;
int n,ans ;
char col[N] ;
int fac[N],inv[N],lmt[N],tot[N],id[N] ;
int f[M][M][M][M],g[N][N][10][10],vis[N],sz[N],gs[N][5] ;
vector<int>e[N] ;
inline int C(int x,int y)
{
    if(x < y) return 0 ;
    return fac[x]*inv[y]%MOD*inv[x-y]%MOD ;
}
void Dfs(int x)
{
    vis[x] = sz[x] = 1,gs[x][id[col[x]]] = 1 ;
    if(col[x] == 'r') f[x][1][0][0] = 1 ;
    if(col[x] == 'b') f[x][0][1][0] = 1 ;
    if(col[x] == 'g') f[x][0][0][1] = 1 ;
    for(auto v:e[x]) if(!vis[v])
    {
        Dfs(v) ;
        ROF(i,min(lmt['r'],gs[x][1]),0,1) ROF(j,min(lmt['b'],gs[x][2]),0,1) ROF(k,min(lmt['g'],gs[x][3]),0,1) 
        ROF(ii,min(lmt['r']-i,gs[v][1]),0,1) ROF(jj,min(lmt['b']-j,gs[v][2]),0,1) ROF(kk,min(lmt['g']-k,gs[v][3]),0,1)
            (f[x][i+ii][j+jj][k+kk] += f[x][i][j][k]*f[v][ii][jj][kk]%MOD ) %= MOD ;
        FOR(i,1,3,1) gs[x][i] += gs[v][i] ; 
    }
    FOR(i,0,lmt['r'],1) FOR(j,0,lmt['b'],1) FOR(k,0,lmt['g'],1) ans += f[x][i][j][k],ans %= MOD ;
}
void Solve1()
{
    Dfs(1),print(ans),enter ; //print(f[4][1][0][1]),enter ;
}
void Solve2()
{
    fac[0] = inv[0] = inv[1] ;
    FOR(i,1,n,1) fac[i] = fac[i-1]*i%MOD ;
    FOR(i,2,n,1) inv[i] = (MOD-MOD/i)*inv[MOD%i]%MOD ;
    FOR(i,2,n,1) inv[i] = inv[i-1]*inv[i]%MOD ;
    FOR(i,2,n,1) tot[col[i]]++ ; lmt[col[1]]-- ;
    FOR(i,0,lmt['r'],1) FOR(j,0,lmt['b'],1) FOR(k,0,lmt['g'],1)
        ans += C(tot['r'],i)*C(tot['b'],j)%MOD*(tot['g'],k)%MOD,ans %= MOD ;
    lmt[col[1]]++ ;
    FOR(i,2,n,1) if(lmt[col[i]]) ++ans ; print(ans%MOD) ;
}
void DDfs(int x)
{
    vis[x] = sz[x] = 1,gs[x][id[col[x]]] = 1 ;
    if(col[x] == 'r') g[x][1][0][0] = 1 ;
    if(col[x] == 'b') g[x][0][1][0] = 1 ;
    if(col[x] == 'g') g[x][0][0][1] = 1 ;
    for(auto v:e[x]) if(!vis[v])
    {
        Dfs(v) ;
        ROF(i,min(lmt['r'],gs[x][1]),0,1) ROF(j,min(lmt['b'],gs[x][2]),0,1) ROF(k,min(lmt['g'],gs[x][3]),0,1) 
        ROF(ii,min(lmt['r']-i,gs[v][1]),0,1) ROF(jj,min(lmt['b']-j,gs[v][2]),0,1) ROF(kk,min(lmt['g']-k,gs[v][3]),0,1)
            (g[x][i+ii][j+jj][k+kk] += g[x][i][j][k]*g[v][ii][jj][kk]%MOD ) %= MOD ;
        FOR(i,1,3,1) gs[x][i] += gs[v][i] ; 
    }
    FOR(i,0,lmt['r'],1) FOR(j,0,lmt['b'],1) FOR(k,0,lmt['g'],1) ans += g[x][i][j][k],ans %= MOD ;
}
void Solve3()
{
    DDfs(1),print(ans),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("yuukei.in","r",stdin) ;
	freopen("yuukei.out","w",stdout) ;
    read(n),read(lmt['r'],lmt['b'],lmt['g']) ;
    id['r'] = 1,id['b'] = 2,id['g'] = 3 ;
    scanf("%s",col+1) ;
    FOR(i,2,n,1)
    {
        int u,v ; read(u,v) ;
        e[u].pb(v),e[v].pb(u) ;
    }
    if(n <= 55)  Solve1() ;
    else if(e[1].size() == n-1) Solve2() ;
    else Solve3() ;
    return 0 ;
}