#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
const int N = 5e5+5 ;
int n,ans=1e18 ;
int a[N],f[N][2] ;//0 没选，1 选了
vector<int>val ;
bool S_GND ;
void Solve(int lmt)
{
    FOR(i,2,n-1,1) if(a[i]+a[i-1] < lmt && a[i]+a[i+1] < lmt) return ;
    f[1][0] = a[1],f[1][1] = a[1] ;
    FOR(i,2,n,1)
    {
        f[i][0] = f[i][1] = 1e18 ;
        if(a[i] < lmt)
        {
            if(a[i]+a[i-1] >= lmt) f[i][1] = min(f[i][1],max(f[i-1][0],a[i]+a[i-1])) ;
            if(a[i-1] >= lmt) f[i][0] = min(f[i][0],max(f[i-1][0],a[i])) ; 
            if(a[i-2]+a[i-1] >= lmt) f[i][0] = min(f[i][0],max(f[i-1][1],a[i])) ;
        }
        else
        {
            f[i][1] = min(f[i][1],max(f[i-1][0],a[i-1]+a[i])) ;
            if(a[i-1]+a[i-2] >= lmt) f[i][0] = min(f[i][0],max(f[i-1][1],a[i])) ;
            if(a[i-1] >= lmt) f[i][0] = min(f[i][0],max(f[i-1][0],a[i])) ;
        }
    }
    if(a[n] >= lmt) ans = min(ans,f[n][0]-lmt) ;
    if(a[n]+a[n-1] >= lmt) ans = min(ans,f[n][1]-lmt) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("sakana.in","r",stdin) ;
	freopen("sakana.out","w",stdout) ;
    read(n) ;
    FOR(i,1,n,1) read(a[i]),val.pb(a[i]) ;
    FOR(i,1,n-1,1) val.pb(a[i]+a[i+1]) ;
    sort(val.begin(),val.end()),unique(val.begin(),val.end()) ;
    if(n <= 5000) for(auto wi:val) Solve(wi) ; 
    else
    {
        int le = 0,ri = val.size() ; --ri ;
        while(le <= ri)
        {
            int mid = le+ri>>1 ; int las = ans ; Solve(val[mid]) ;
            if(ans < las) le = mid+1 ;
            else ri = mid-1 ;
        }
        int jd = ans ; ans = 1e18,le = 0,ri = val.size() ; --ri ;
        while(le <= ri)
        {
            int mid = le+ri>>1 ; int las = ans ; Solve(val[mid]) ;
            if(ans < las) ri = mid-1 ;
            else le = mid+1 ;

        }
        ans = min(ans,jd) ;
    }
    print(ans),enter ;
    return 0 ;
}