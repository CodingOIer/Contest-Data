#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int T, n, ans;
bool f[5010][5010];
signed main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	cin >> T;
	while(T--) {
		cin >> n;
		ans = 0;
		for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++) f[i][j] = 0;
		for(int x = 2; x * x <= n; x++) {
			int num = x * x;
			for(int i = num; i <= n; i += num)
			for(int j = num; j <= n; j += num) {
				if(!f[i][j]) {
					ans++;
					f[i][j] = 1;
				}
			}
		}
		cout << ans << endl;
	}
	return 0;
}
/*
1
31
*/

