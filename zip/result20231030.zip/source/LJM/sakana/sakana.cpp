#include<bits/stdc++.h>
#define int long long
#define N 500005
using namespace std;
int n, maxn, hh;
int a[N], vis[N];
bool flag = 0;
bool check1(int x) {
	for(int i = 1; i <= n; i++) vis[i] = 0;

	for(int i = 1; i <= n; i++) {
		if(a[i] == maxn) {
			vis[i] = 2;
			break;
		}
	}
	
	for(int i = 1; i <= n; i++) {
		if(vis[i] == 2) continue;
		if(maxn - a[i] <= x) {
			vis[i] = 1;
			continue;
		}
		if(vis[i + 1] == 0 && maxn >= a[i] + a[i + 1] && maxn - (a[i] + a[i + 1]) <= x) {
			vis[i] = 2;
			vis[i + 1] = 2;
		}
		else if(vis[i - 1] == 1 && maxn >= a[i] + a[i - 1] && maxn - (a[i] + a[i - 1]) <= x) {
			vis[i] = 2;
			vis[i - 1] = 2;
		} else return 0;
	}
	return 1;
}
bool check2(int x) {
	for(int i = 1; i <= n; i++) vis[i] = 0;
    vis[hh] = 2;
    vis[hh + 1] = 2;
    maxn = a[hh] + a[hh + 1];
	for(int i = 1; i <= n; i++) {
		if(vis[i] == 2) continue;
		if(maxn - a[i] <= x) {
			vis[i] = 1;
			continue;
		}
		if(vis[i + 1] == 0 && maxn >= a[i] + a[i + 1] && maxn - (a[i] + a[i + 1]) <= x) {
			vis[i] = 2;
			vis[i + 1] = 2;
		}
		else if(vis[i - 1] == 1 && maxn >= a[i] + a[i - 1] && maxn - (a[i] + a[i - 1]) <= x) {
			vis[i] = 2;
			vis[i - 1] = 2;
		} else return 0;
	}
	return 1;
}
signed main() {
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	scanf("%lld", &n);
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]), maxn = max(maxn, a[i]);
	//cout << a[n] - a[1];
	int L = 0, R = 1e9, mid, ans = -1;
	while(L <= R) {
		mid = (L + R) / 2;
		if(check1(mid)) {
			ans = mid;
			R = mid - 1;
		} else L = mid + 1;
	}
    //cout << ans << endl;
	flag = 1;
	int MAX = maxn;
	for(int i = 1; i < n; i++) {
        if(a[i] + a[i + 1] < MAX) continue;
		int L = 0, R = 1e9, mid, now = 1e9;
		hh = i;
		while(L <= R) {
			mid = (L + R) / 2;
			if(check2(mid)) {
				now = mid;
				R = mid - 1;
			} else L = mid + 1;
		}
        //cout << now << endl;
		ans = min(ans, now);
	}
	printf("%lld", ans);
	return 0;
}
/*
3
10 6 6
*/
/*
5
1 3 1 2 5
*/


