#include<bits/stdc++.h>
#define int long long
#define N 210
#define mod 1000000007
using namespace std;
int n, r, b, g, ans;
int f[N][102][27][27];
int f2[110][110][110];
char a[N];
vector<int>p[N];
void dfs(int x, int fa) {
	if(a[x] == 'r') f[x][1][0][0] = 1;
	if(a[x] == 'b') f[x][0][1][0] = 1;
	if(a[x] == 'g') f[x][0][0][1] = 1;
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == fa) continue;
		dfs(y, x);
	}
	for(int h = 0; h < p[x].size(); h++) {
	int y = p[x][h];
	if(y == fa) continue;
	for(int i = r; i >= 0; i--)
    for(int j = b; j >= 0; j--)
    for(int k = g; k >= 0; k--)
    for(int R = 0; R <= i; R++)
    for(int B = 0; B <= j; B++)
    for(int G = 0; G <= k; G++) {
    	if(R == 0 && B == 0 && G == 0) continue;
    	if(f[x][i - R][j - B][k - G] == 0) continue;
    	if(f[y][R][B][G] == 0) continue;
    	f[x][i][j][k] += (f[x][i - R][j - B][k - G] * f[y][R][B][G]) % mod;
    	f[x][i][j][k] %= mod;
	}
	
	
	}
    
}
signed main(){
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
	scanf("%lld %lld %lld %lld", &n, &r, &b, &g);
	for(int i = 1; i <= n; i++) cin >> a[i];
	int num = 0;
	for(int i = 1; i <= n - 1; i++) {
		int u, v;
		scanf("%lld %lld", &u, &v);
		p[u].push_back(v);
		p[v].push_back(u); 
		if(u == 1 || v == 1) num++;
	}
	if(num == n - 1) {
		
		if(a[1] == 'r') f2[1][0][0] = 1;
		if(a[1] == 'b') f2[0][1][0] = 1;
		if(a[1] == 'g') f2[0][0][1] = 1;
		for(int i = 2; i <= n; i++) {
			for(int R = r; R >= 0; R--) {
				for(int B = b; B >= 0; B--) {
					for(int G = g; G >= 0; G--) {
						if(a[i] == 'r' && R >= 1) f2[R][B][G] += f2[R - 1][B][G];
						if(a[i] == 'b' && B >= 1) f2[R][B][G] += f2[R][B - 1][G];
						if(a[i] == 'g' && G >= 1) f2[R][B][G] += f2[R][B][G - 1];
                        f2[R][B][G] %= mod;						
					}
				}
			}
		}
		for(int j = 0; j <= r; j++)
	    for(int k = 0; k <= b; k++)
	    for(int l = 0; l <= g; l++) {
		    if(j == 0 && k == 0 && l == 0) continue;
		    ans = (ans + f2[j][k][l]) % mod;
	    }
	    for(int i = 2; i <= n; i++) {
	    	if(a[i] == 'r' && r >= 1) ans++;
	    	if(a[i] == 'b' && b >= 1) ans++;
	    	if(a[i] == 'g' && g >= 1) ans++;
	    	ans %= mod;
		}
	    printf("%lld", ans);
	    return 0;
	}
	dfs(1, 0);
	for(int i = 1; i <= n; i++)
	for(int j = 0; j <= r; j++)
	for(int k = 0; k <= b; k++)
	for(int l = 0; l <= g; l++) {
		if(j == 0 && k == 0 && l == 0) continue;
		ans = (ans + f[i][j][k][l]) % mod;
		//if(f[i][j][k][l] > 0)cout <<i << " " <<  j << " " << k << " " << l << " " << f[i][j][k][l] << endl;
		
	} 
	printf("%lld\n", ans);
	//cout << dfs(1, 0, 1, 0, 1);
	return 0;
}
/*
5 2 3 1
rbbrg
1 2
1 3
1 4
1 5
*/

/*
5 1 1 1
rbrrg
1 2
1 3
3 4
4 5
*/

