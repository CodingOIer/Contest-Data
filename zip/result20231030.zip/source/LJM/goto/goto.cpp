#include<bits/stdc++.h>
#define int long long
#define N 5000006
using namespace std;
int n, k;
int a[N], sum[N], f[N], g[N];
signed main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	scanf("%lld %lld", &n, &k);
	for(int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]);
		sum[i] = sum[i - 1] + a[i];	
	} 
	g[0] = -1e18;
	for(int i = 1; i <= n; i++) {
		f[i] = f[i - 1];
		g[i] = max(g[i - 1], f[i - 1] - sum[i - 1]);
		if(i - k + 1 >= 1) f[i] = max(f[i], sum[i] + g[i - k + 1]);
	}
	printf("%lld", f[n]);
	return 0;
}

