#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e6+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int T,ans[11]={0,0,0,0,1,1,1,1,4,5,5};
ll n;
inline int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
bool f[5005];
inline void prep(){
	rep(i,2,80){
		int k=i*i;
		if(k>5000)return;
		if(f[k])continue;
		for(int j=k;j<=5000;j+=k)f[j]=1;
	}
}
bool isp[N];
int p[N],pw[N],cnt;
inline void Prep(){
	rep(i,2,1000){
		if(!isp[i])p[++cnt]=i;
		for(int j=1;j<=cnt&&i*p[j]<=1000;j++){
			isp[i*p[j]]=1;
			if(i%p[j]==0)break;
		}
	}
	rep(i,1,cnt)pw[i]=1LL*p[i]*p[i];
	//rep(i,1,cnt)cout <<pw[i]<<endl;
}
inline int bitcount(ll x){
	int ans=0;
	while(x)ans++,x-=x&-x;
	return ans;
}
inline ll got(ll x){
	ll ans=0;
	int mx=sqrt(x);
	int ct=0;
	rep(i,1,cnt){
		if(pw[i]>mx)break;
		else ct++;
	}
	int nw=ct;
	rep(i,1,cnt){
		if(pw[i]>x/2)break;
		else nw++;
	}
	int S=(1<<ct)-1;
	rep(s,0,S){
		ll nk=1;
		rep(i,1,ct){
			if((s>>i-1)&1)nk*=pw[i];
			if(nk>x)break;
		}
		if(nk==1)continue;
		if(nk>x)continue;
		ll amt=x/nk;
		int k=bitcount(s);
		if(k&1)(ans+=amt*amt%mod)%=mod;
		else ans=((ans-amt*amt%mod)%mod+mod)%mod;
		rep(i,ct+1,nw){
			if(nk*pw[i]>x)break;
			ll now=nk*pw[i];
			amt=x/now;
			if(!(k&1))(ans+=amt*amt%mod)%=mod;
			else ans=((ans-amt*amt%mod)%mod+mod)%mod;
		}
	}
	rep(i,ct+1,nw){
		ll k=x/pw[i];
		(ans+=k*k%mod)%=mod;
	}
	rep(i,nw+1,cnt)if(pw[i]<=x)ans++,ans%=mod;
	else break;
	return ans;
}
int main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	T=read(),prep(),Prep();
	int t=T;
	while(T--){
		cin >>n;
		if(t==1&&n<=10){
			pf(ans[n]),putchar('\n');
			continue;
		}
		if(t==1&&n<=5000){
			int ans=0;
			rep(i,1,n)rep(j,i,n){
				int g=gcd(i,j);
				if(f[g])ans++,ans+=(i!=j);
			}
			pf(ans),putchar('\n');
			continue;
		}
		if(n<=1000000){
			pf(got(n)),putchar('\n');
			continue;
		}
	}
    return 0;
}
