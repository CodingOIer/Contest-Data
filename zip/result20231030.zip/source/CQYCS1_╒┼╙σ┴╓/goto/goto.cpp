#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =5e6+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int n,k,a[N];
ll dp[N],sum,mn;
int main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	n=read(),k=read();
	rep(i,1,n)a[i]=read(),sum+=a[i];
	rep(i,0,n+1)dp[i]=llf;
	dp[0]=0;
	mn=llf;
	rep(i,1,n+1){
		dp[i]=dp[i-1]+a[i];
		if(i-k-1>=0)mn=min(mn,dp[i-k-1]);
		dp[i]=min(dp[i],mn+a[i]);
	}
	pf(sum-dp[n+1]);
    return 0;
}
/*
6 2
1 -1 4 -5 1 4
*/
