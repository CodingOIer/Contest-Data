#include<bits/stdc++.h>
using namespace std;
const int mx = 10000000,mod = 998244353;
bool is[mx+11];
int f[mx+11],l[mx+11];
int T,n;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("asa.in","r",stdin);
    freopen("asa.out","w",stdout);
    for(int i = 2;i <= mx;i++)
        if(is[i])
            for(int a = i * 2;a <= mx;a += i) is[a] = 1;
        else
            for(long long a = (long long)i * i;a <= mx;a *= i) is[a] = 1;
    for(int i = 2;i <= mx;i++)
    {
        if(!l[i])
            for(int j = i * 2;j <= mx;j += i)
                if(!l[j])
                    l[j] = i;
    }
    for(int i = 2;i <= mx;i++)
    {
        if(!l[i])
            f[i] = i - 1;
        else
            if(i / l[i] % l[i])
                f[i] = f[i / l[i]] * (l[i] - 1);
            else
                f[i] = f[i / l[i]] * l[i];
    }
    for(int i = 1;i <= mx;i++) f[i] += f[i - 1];
    cin >> T;
    while(T--)
    {
        cin >> n;
        long long ans = 0;
        for(int gcd = 1;gcd <= n;gcd++) if(is[gcd])
        {
            ans++;
            int m = n / gcd;
            ans += f[m] * 2;
            ans %= mod;
        }
        cout << ans << "\n";
    }
    return 0;
}