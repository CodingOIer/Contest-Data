#include<bits/stdc++.h>
#include<bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;
int n;
int a[500011],lmn,rmx;
int f[500011];
gp_hash_table<int,int> h;
const int MX = 0.8 * CLOCKS_PER_SEC;
int ans = INT_MAX;
inline int Clac(int mx)
{
    if(h[mx]) return h[mx];
    f[0] = mx;
    f[1] = a[1];
    for(int i = 2;i <= n;i++)
    {
        f[i] = min(a[i],f[i - 1]);
        if(a[i] + a[i - 1] <= mx)
            f[i] = max(f[i],min(f[i - 2],a[i - 1] + a[i]));
    }
    ans = min(ans,mx - f[n]);
    h[mx] = mx - f[n];
    return mx - f[n];
}
inline void SA()
{
    int npl,nans,lans,lpl = ((unsigned int)rmx + lmn) / 2;
    lans = Clac(lpl);
    for(double T = (rmx - lmn) / 2.0;T > 1 && clock() < MX;T *= 0.97)
    {
        if(rand()&1)
            npl = lpl + rand() * T / RAND_MAX;
        else
            npl = lpl - rand() * T / RAND_MAX;
        if(npl < lmn || npl > rmx) continue;
        nans = Clac(npl);
        if(nans < lans || exp((lans - nans) / T) * RAND_MAX >= rand())
            lpl = npl,lans - nans;
    }
}
int main()
{
    srand(time(0));rand();
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    cin >> n;
    for(int i = 1;i <= n;i++) cin >> a[i];
    for(int i = 1;i <= n;i++) lmn = max(a[i],lmn);
    for(int i = 2;i <= n;i++) rmx = max(a[i] + a[i - 1],rmx);
    ans = lmn;
    Clac(lmn),Clac(rmx);
    if(n <= 5000)
        for(int i = 2;i <= n;i++) if(a[i] + a[i - 1] >= lmn) Clac(a[i] + a[i - 1]);
    long long l = lmn,r = rmx,lmid,rmid;
    while(l <= r)
    {
        lmid = (l + l + r) / 3,rmid = (l + r + r) / 3;
        if(Clac(lmid) <= Clac(rmid))
            r = rmid - 1;
        else
            l = lmid + 1;
    }
    while(clock() < MX) SA();
    cout << ans;
    cerr << "stdans: " << ans << "\n";
    return 0;
}