#include<bits/stdc++.h>
using namespace std;
struct ios{
    inline char gc(){
        static const int IN_LEN=1<<18|1;
        static char buf[IN_LEN],*s,*t;
        return (s==t)&&(t=(s=buf)+fread(buf,1,IN_LEN,stdin)),s==t?-1:*s++;
    }
    template <typename _Tp> inline ios & operator >> (_Tp&x){
        static char ch,sgn; ch = gc(), sgn = 0;
        for(;!isdigit(ch);ch=gc()){if(ch==-1)return *this;sgn|=ch=='-';}
        for(x=0;isdigit(ch);ch=gc())x=x*10+(ch^'0');
        sgn&&(x=-x); return *this;
    }
}io;
#define cin io
int n,k;
int a[5000011];
long long s[5000011];
long long f[5000011],pre[5000011];
int l[5000011];
int main()
{
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    cin >> n >> k;
    for(int i = 1;i <= n;i++) cin >> a[i];
    for(int i = 1;i <= n;i++) s[i] = s[i - 1] + a[i];
    pre[k] = max(0ll,f[k] = s[k]),l[k] = 1;
    for(int i = k + 1;i <= n;i++)
    {
        l[i] = l[i - 1];
        if(pre[i - k] >= s[i - k] - s[l[i] - 1] + pre[l[i] - 1]) l[i] = i - k + 1;
        f[i] = s[i] - s[l[i] - 1] + pre[l[i] - 1];
        pre[i] = max(pre[i - 1],f[i]);
    }
    printf("%lld",pre[n]);
    return 0;
}