#include <bits/stdc++.h>
using namespace std;

int n, a[500001], k;
long long f[500006];

int main() {
	freopen("goto.in", "r", stdin);
	freopen("goto.out", "w", stdout);
	scanf("%d%d", &n, &k);
	if (k > n) {
		return puts("0"), 0;
	}
	bool flag1 = 1;
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]), flag1 &= (a[i] <= 0);
	if (flag1) return puts("0"), 0;
	if (k == 1) {
		long long sum = 0;
		for (int i = 1; i <= n; ++i) sum += max(a[i], 0);
		return printf("%lld\n", sum), 0;
	}
	for (int i = 0; i <= n; ++i) f[i] = -1ll << 62;
	for (int i = n; i >= 0; --i) {
		for (int j = 0; j <= n; ++j) {
			if (i == n) {
				if (j >= k || j == 0) f[j] = 0;
				else f[j] = -1ll << 62;
				continue;
			}
			if (j >= k) {
				f[j] = max({f[0], f[j + 1] + a[i + 1]});
			} else if (j == 0) {
				f[j] = max({f[0], f[j + 1] + a[i + 1]});
			} else {
				f[j] = f[j + 1] + a[i + 1];
			}
		}
	}
	printf("%lld\n", f[0]);
}
/*
1 + 7 + 20 + 21 = 59
*/
