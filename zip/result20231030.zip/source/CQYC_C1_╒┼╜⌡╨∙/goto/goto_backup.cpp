#include <bits/stdc++.h>
using namespace std;

int n, a[100001], k;
long long sum[100001];
long long f[1003][1003];
bool vis[1003][1003];

long long dfs(int i, int len) {
	if (i == n) {
		if (len >= k || len == 0) return 0;
		else return -1ll << 62;
	}
	if (vis[i][len]) return f[i][len];
	if (len >= k) {
		f[i][len] = max({dfs(i + 1, 0),dfs(i + 1, len + 1) + a[i + 1]});
		vis[i][len] = 1;
		return f[i][len];
	}
	else if (len == 0) {
		f[i][len] = max({dfs(i + 1, 0), dfs(i + 1, len + 1) + a[i + 1]});
		vis[i][len] = 1;
		return f[i][len];
	}
	else {
		f[i][len] = max({dfs(i + 1, len + 1) + a[i + 1]});
		vis[i][len] = 1;
		return f[i][len];
	}
}

int main() {
	freopen("goto4.in", "r", stdin);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]); 
	printf("%lld\n", dfs(0, 0));
}
/*
182401312708
136382798845
*/
