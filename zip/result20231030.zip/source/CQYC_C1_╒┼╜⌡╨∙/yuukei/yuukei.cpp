#include <bits/stdc++.h>
using namespace std;

int n, r, g, b;
vector<int> edges[203]; 
char s[205];
long long ans = 0, fact[203];
const int p = 998244353;
int fa[205];

int get_fa(int i) {
	if (fa[i] == i) return fa[i];
	else return fa[i] = get_fa(fa[i]);
}
long long qpow(long long a, long long b) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % p;
		a = a * a % p;
		b >>= 1;
	}
	return res;
}
long long inv (long long a) {
	return qpow(a, p - 2);
}
long long C(long long a, long long b) {
	return fact[a] * inv(fact[a - b]) % p * inv(fact[b]) % p;
}
int main() {
	freopen("yuukei.in", "r", stdin);
	freopen("yuukei.out","w", stdout);
	scanf("%d%d%d%d", &n, &r, &g, &b);
	scanf("%s", s + 1);
	for (int i = 1; i < n; ++i) {
		int x, y;
		scanf("%d%d", &x, &y);
		edges[x].push_back(y);
		edges[y].push_back(x);
	}
	if (n <= 20) {
		for (int f = 1; f < (1 << n); ++f){
			int rt = 0, gt = 0, bt = 0;
			for (int i = 1; i <= n; ++i) {
				if ((f & (1 << (i - 1)))) {
					rt += (s[i] == 'r');
					gt += (s[i] == 'g');
					bt += (s[i] == 'b');
				}
			}
			if (rt > r || gt > g || bt > b) continue;
			for (int i = 1; i <= n; ++i) fa[i] = i;
			for (int i = 1; i <= n; ++i) {
				if ((f & (1 << (i - 1))))
					for (auto j : edges[i]) {
						if ((f & (1 << (j - 1)))) {
							fa[get_fa(i)] = get_fa(j);
						}
					}
			}
			int a  = -1;
			bool ok = 1;
			for (int i = 1; i <= n; ++i) {
				if ((f & (1 << (i - 1)))) {
					if (a == -1) a = get_fa(i);
					else if (a != get_fa(i)) ok = 0;
				}
			}
			ans += ok;
		}
		printf("%d\n", ans);
	} else if (edges[1].size() == n - 1) {
		ans = 0;
		fact[0] = 1;
		for (int i = 1; i <= 200; ++i) fact[i] = fact[i - 1] * i % p;
		for (int i = 2; i <= n; ++i) {
			if ((s[i]=='r' && r==0) || (s[i]=='b' && b==0) || (s[i]=='g' && g==0));
			else ++ans;
		}
		long long ans1 = 1;
		if ((s[1]=='r' && r==0) || (s[1]=='b' && b==0) || (s[1]=='g' && g==0));
		else {
			int rt = 0, bt = 0, gt = 0, rrt = 0, bbt = 0, ggt = 0;
			for (int i = 2; i <= n; ++i) {
            	rt += (s[i] == 'r');
        	    gt += (s[i] == 'g');
    	        bt += (s[i] == 'b');
            	rrt += (s[i] == 'r');
        	    ggt += (s[i] == 'g');
    	        bbt += (s[i] == 'b');
	        }
			rt = min(rt, r - (s[1] == 'r'));
			bt = min(bt, b - (s[1] == 'b'));
			gt = min(gt, g - (s[1] == 'g'));
			long long tmp = 0;
			for (int i = 0; i <= rt; ++i) {
				tmp += C(rrt, i);
				tmp %= p;
			}
			ans1 = ans1 * tmp % p;
			tmp = 0;
			for (int i = 0; i <= bt; ++i) {
				tmp += C(bbt, i);
				tmp %= p;
			}
			ans1 = ans1 * tmp % p;
			tmp = 0;
			for (int i = 0; i <= gt; ++i) {
				tmp += C(ggt, i);
				tmp %= p;
			}
			ans1 = ans1 * tmp % p;
		}
		printf("%lld\n", ans + ans1);
	}
}
/*
15 + 10 = 25
*/
