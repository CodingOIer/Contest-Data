#include <bits/stdc++.h>
using namespace std;

int t, n;
const int biao[12] = {0, 0, 0, 0, 1, 1, 1, 1, 1, 5, 5};

int main() {
	freopen("asa.in", "r", stdin);
	freopen("asa.out", "w", stdout);
	scanf("%d%d", &t, &n);
	printf("%d\n", biao[n]);
	return 0;
}
