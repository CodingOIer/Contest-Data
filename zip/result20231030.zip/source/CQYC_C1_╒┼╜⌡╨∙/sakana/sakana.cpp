#include <bits/stdc++.h>
using namespace std;
int n;
long long a[500001];
long long ans = 1ll << 60;

void dfs(int i, long long maxn, long long minn) {
	if (i == n + 1) {
		ans = min(ans, maxn - minn);
		return;
	}
	dfs(i + 1, max(maxn, a[i]), min(minn, a[i]));
	if (i != n) {
		dfs(i + 2, max(maxn, a[i] + a[i + 1]), min(minn, a[i] + a[i + 1]));
	}
	
}

int main() {
	freopen("sakana.in", "r", stdin);
	freopen("sakana.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%lld", &a[i]);
	}
	ans = 1ll << 60;
	dfs(1, -1ll << 60, 1ll << 60);
	printf("%lld\n", ans);
}
/*
10*/
