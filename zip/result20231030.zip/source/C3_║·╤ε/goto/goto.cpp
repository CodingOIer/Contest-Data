#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 5000010;
int n, K, len, tt, Max, ans;
int a[maxn], s[maxn], f[maxn];
int read(){
	int x = 0, w = 1; char ch = getchar();
	while(!isdigit(ch)) {if(ch == '-') w = -1; ch = getchar();}
	while(isdigit(ch)) {x = (x << 3) + (x << 1) + ch ^ 48; ch = getchar();}
	return x * w;
} 
signed main(){
	ios::sync_with_stdio(false);
	freopen("goto.in", "r", stdin);
	freopen("goto.out", "w", stdout);
	cin >> n >> K;
	for(int i = 1 ; i <= n ; i++){
		cin >> a[i];
		if(a[i] > 0 && K == 1) ans += a[i];
		if(a[i] > 0) tt = 1;
	}
	if(K == 1){
		cout << ans << '\n';
		return 0;
	}
	if(!tt){
		cout << 0 << '\n';
		return 0;
	}
	for(int i = 1 ; i <= n ; i++) s[i] = s[i - 1] + a[i];
	for(int i = 0 ; i <= n ; i++){
		Max = 0;
		for(int j = i + 1 ; j <= n ; j++){
			for(int k = i + 1 ; k <= j ; k++)
				if(j - k + 1 >= K) Max = max(Max, s[j] - s[k - 1]);
//			cout << Max << " ";
			f[j] = max(f[j], f[i] + Max);
		}
//		cout << '\n';
	}
//	for(int i = 1 ; i <= n ; i++) cout << f[i] << " ";
//	cout << endl;
	for(int i = 1 ; i <= n ; i++) ans = max(ans, f[i]);
	cout << ans << '\n';
	return 0;
}
/*
10 3
-5 10 5 -9 99 -10 5 -5 -5 10

110

6 2
1 -1 4 -5 1 4

6 2
1 �\1 4 �\5 1 4

6 2
1 �\1 4 �\5 1 4

*/
