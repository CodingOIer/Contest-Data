#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 998244353;
int T, n;
int vis[5010];
signed main(){
	ios::sync_with_stdio(false);
	freopen("asa.in", "r", stdin);
	freopen("asa.out", "w", stdout);
	cin >> T;
	while(T--){
		cin >> n;
		int ans = 0;
		for(int a = 1 ; a <= n ; a++){
			for(int b = a ; b <= n ; b++){
				int x = __gcd(a, b), s = 2, tt = 0;
				int y = x;
				if(vis[x] == 1){
					ans += 2;
					if(ans >= mod) ans -= mod;
					continue;
				}
				if(vis[x] == 2) continue;
				while(x > 1){
					int len = 0;
					while(x % s == 0){
						x /= s;
						len ++;
					}
					if(len >= 2){
						tt = 1;
						break;
					}
					s++;
				}
				if(tt){
					vis[y] = 1;
					if(a == b) ans++;
					else ans += 2;
					if(ans >= mod) ans -= mod;
//					cout << a << " " << b << '\n';
				}
				else vis[x] = 2;
			}
		}
		cout << ans << '\n';
	}
	return 0;
}
/*
6
31
233
314
1582
3141
4713
 */
