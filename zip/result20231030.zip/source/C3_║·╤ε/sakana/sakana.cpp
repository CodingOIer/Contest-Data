#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 500010;
int n, ans = 1e18;
int a[maxn], f[maxn][2], vis[maxn];
void dfs(int x){
	if(x > n){
		int Min = 1e18, Max = 0;
		for(int i = 1 ; i <= n ; i++){
			//	cout << vis[i] << " ";
			if(vis[i + 1]) continue;
			if(vis[i]){
				Min = min(Min, a[i] + a[i - 1]);
				Max = max(Max, a[i] + a[i - 1]);
			}
			else{
				Min = min(Min, a[i]);
				Max = max(Max, a[i]);
			}
		}
		//		cout << '\n';
		//		cout << Max <<" " <<Min <<'\n';
		ans = min(Max - Min, ans);
		return ;
	}
	dfs(x + 1);
	if(x + 1 <= n){
		vis[x + 1] = 1;
		dfs(x + 2);
		vis[x + 1] = 0;
	}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("sakana.in", "r", stdin);
	freopen("sakana.out", "w", stdout);
	cin >> n;
	for(int i = 1 ; i <= n ; i++) cin >> a[i];
	if(n <= 10){
		dfs(1);
		cout << ans << '\n';
		return 0;
	}
	for(int i = 1 ; i <= n ; i++) f[i][1] = 1e18;
	f[1][0] = a[1]; f[1][1] = a[1];
	f[2][0] = a[1] + a[2]; f[2][1] = a[1] + a[2];
	for(int i = 3 ; i <= n ; i++){
		f[i][0] = max(f[i][0], min(f[i - 1][0], a[i]));
		f[i][1] = min(f[i][1], max(f[i - 1][1], a[i]));
		f[i + 1][0] = max(f[i + 1][0], min(f[i - 1][0], a[i] + a[i + 1]));
		f[i + 1][1] = min(f[i + 1][1], max(f[i - 1][1], a[i] + a[i + 1]));
	}
//	for(int i = 1 ; i <= n ; i++) cout << f[i][0] << " " << f[i][1] << '\n';
	cout << f[n][1] - f[n][0] << '\n';
	return 0;	
}
/*
  5
  1 3 1 2 5

4
0 0 99 66
4
*/
