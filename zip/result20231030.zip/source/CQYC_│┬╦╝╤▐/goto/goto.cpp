#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=5e6+5;
int n,k,a[maxn],b[maxn],f[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    n=read(),k=read();
    int bj=0,res=0;
    for(int i=1;i<=n;i++){
        a[i]=read();
        b[i]=b[i-1]+a[i];
        if(a[i]>0)
            bj=1,res+=a[i];
    }
    if(!bj){
        puts("0");
        return 0;
    }
    if(k==1){
        printf("%lld\n",res);
        return 0;
    }
    for(int i=k;i<=n;i++){
        f[i]=f[i-1];
        for(int j=i-k;j>=0;j--)
            f[i]=max(f[i],f[j]+b[i]-b[j]);
    }
    printf("%lld\n",f[n]);
    return 0;
}