#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,r,b,g,va[205][3],u,v,f[65][65][65][65],k[205][105],p[65][65][65],ans;
char s[205];
vector<int> to[205];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int& a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
void dfs(int u,int fa){
    for(auto v:to[u])
        if(v!=fa)
            dfs(v,u);
    f[u][va[u][0]][va[u][1]][va[u][2]]=1;
    for(auto v:to[u])
        if(v!=fa){
            for(int i=0;i<=r;i++)
                for(int j=0;j<=b;j++)
                    for(int l=0;l<=g;l++)
                        p[i][j][l]=f[u][i][j][l];
            for(int i=r;i>=va[u][0];i--)
                for(int j=b;j>=va[u][1];j--)
                    for(int l=g;l>=va[u][2];l--)
                        if(f[u][i][j][l]){
                            for(int x=0;x+i<=r;x++)
                                for(int y=0;y+j<=b;y++)
                                    for(int z=0;z+l<=g;z++)
                                        add(p[x+i][y+j][z+l],f[v][x][y][z]);
                        }
            for(int i=0;i<=r;i++)
                for(int j=0;j<=b;j++)
                    for(int l=0;l<=g;l++)
                        f[u][i][j][l]=p[i][j][l];
        }
}
void dfs2(int u,int fa){
    for(auto v:to[u])
        if(v!=fa)
            dfs2(v,u);
    if(va[u][0]){
        k[u][1]=1;
        for(auto v:to[u])
            if(v!=fa&&va[v][0]){
                for(int i=r;i>=1;i--)
                    if(k[u][i])
                        for(int x=0;x+i<=r;x++)
                            add(k[u][x+i],k[v][x]);
            }
    }
}
signed main(){
    freopen("yuukei.in","r",stdin);
    freopen("yuukei.out","w",stdout);
    n=read(),r=read(),b=read(),g=read();
    scanf("%s",s+1);
    for(int i=1;i<=n;i++){
        if(s[i]=='r')
            va[i][0]=1;
        if(s[i]=='b')
            va[i][1]=1;
        if(s[i]=='g')
            va[i][2]=1;
    }
    for(int i=1;i<n;i++){
        u=read(),v=read();
        to[u].push_back(v);
        to[v].push_back(u);
    }
    if(!b&&!g){
        dfs2(1,0);
        for(int i=1;i<=n;i++)
            for(int j=1;j<=r;j++)
                add(ans,k[i][j]);
        printf("%lld\n",ans);
        return 0;
    }
    if(n<=60){
        dfs(1,0);
        for(int i=1;i<=n;i++)
            for(int x=0;x<=r;x++)
                for(int y=0;y<=b;y++)
                    for(int z=0;z<=g;z++)
                        add(ans,f[i][x][y][z]);
        printf("%lld\n",ans);
        return 0;
    }
    return 0;
}