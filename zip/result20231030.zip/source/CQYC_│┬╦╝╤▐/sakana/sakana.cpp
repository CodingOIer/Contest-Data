#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=5e5+5;
int n,a[maxn],ans=1e18;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int mi,int ma){
    if(x>n){
        ans=min(ans,ma-mi);
        return;
    }
    solve(x+1,min(mi,a[x]),max(ma,a[x]));
    if(x<n)
        solve(x+2,min(mi,a[x]+a[x+1]),max(ma,a[x]+a[x+1]));
}
signed main(){
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    if(n<=10){
        solve(1,1e18,0);
        printf("%lld\n",ans);
        return 0;
    }
    return 0;
}
