#include<bits/stdc++.h>
using namespace std;
int n,f[500500],maxx=0;
bool dp[500500][2];
int d[3][40020];
bool cheak(int zhi)
{
	memset(dp,0,sizeof dp);
	dp[1][0]=dp[2][1]=true;
	if(abs(f[2]-f[1])<=zhi) dp[2][0]=true;
	for(int i=3;i<=n;i++)
	{
 		if(dp[i-1][0]==true&&abs(f[i]-f[i-1])<=zhi||
		dp[i-1][1]==true&&abs(f[i]-(f[i-1]+f[i-2]))<=zhi) dp[i][0]=true;
		if(dp[i-2][0]==true&&abs(f[i]+f[i-1]-f[i-2])<=zhi||
		dp[i-2][1]==true&&abs(f[i]+f[i-1]-f[i-2]-f[i-3])<=zhi) dp[i][1]=true;
	}
	if(dp[n][0]==false&&dp[n][1]==false) return false;
	return true;
}
int md(int x){return x%3;}
int main()
{
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&f[i]),maxx=max(maxx,f[i]+f[i-1]);
	bool tf=1;
	for(int i=1;i<=n;i++) if(f[i]>20000) {tf=0;break;}
	if(tf==0)
	{
		int l=0,r=1e9+7;
		while(l<r)
		{
			long long mid=(l+r)>>1;
			if(cheak(mid)) r=mid;
			else l=mid+1;
		}
		printf("%lld",l);
		return 0;
	}
	else
	{
		for(int i=f[1];i<=maxx;i++) d[1][i]=f[1];
		for(int i=f[2];i<=maxx;i++) d[2][i]=min(f[1],f[2]);
		for(int i=f[1]+f[2];i<=maxx;i++) d[2][i]=f[1]+f[2];
		for(int i=3;i<=n;i++)
		{
			for(int j=1;j<=maxx;j++) d[md(i)][j]=-1e9;
			for(int j=f[i];j<=maxx;j++) d[md(i)][j]=max(d[md(i)][j],min(d[md(i-1)][j],f[i]));
			for(int j=f[i]+f[i-1];j<=maxx;j++) d[md(i)][j]=max(d[md(i)][j],min(d[md(i-2)][j],f[i]+f[i-1]));
		}
		int ans=2e9;
		for(int i=1;i<=maxx;i++) ans=min(ans,(i-d[md(n)][i]));
		printf("%lld",ans);
	}
	return 0;
}
