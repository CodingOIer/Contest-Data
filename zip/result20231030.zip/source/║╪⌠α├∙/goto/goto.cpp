#include<bits/stdc++.h>
using namespace std;
bool tf=0;
long long n,k,f[5005000],dp[5005000],sum[5005000],ans=0;
deque<int> q;
int main()
{
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&f[i]);
	for(int i=1;i<=n;i++) if(f[i]>0) {tf=1;break;}
	if(tf==0) {cout<<0;return 0;}
	if(k==1)
	{
		long long ans=0;
		for(int i=1;i<=n;i++) ans+=max(0ll,f[i]);
		cout<<ans;
		return 0;
	}
	else
	{
		for(int i=1;i<=n;i++) sum[i]=sum[i-1]+f[i];
		for(int i=0;i<=n;i++)
		{
			while(!q.empty()) q.pop_back();
			for(int j=i+k,l=i;j<=n;j++,l++)
			{
				while(!q.empty()&&sum[q.back()]>=sum[l]) q.pop_back();
				q.push_back(l);
				dp[j]=max(dp[j],dp[i]+(sum[j]-sum[q.front()]));
			}
		}
		for(int i=1;i<=n;i++) ans=max(ans,dp[i]);
		printf("%lld",ans);
	}
	return 0;
}
