#include<bits/stdc++.h>
using namespace std;
int prime[16]={2,3,5,7,11,13,17,19,23,29,31,37,41,43};
long long sh[60060],lasr=1,x,mod=998244353,len=0,t,ans=0;
void init()
{
	for(int i=0;i<(1<<14);i++)
	{
		long long ii=i,temp=1;
		for(int j=0;j<13;j++) if((ii&(1<<j))) temp*=prime[j];
		sh[++len]=temp;
	}
	sort(sh+1,sh+len+1);
}
int main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	//ios::sync_with_stdio(false);
	//cin.tie(0),cout.tie(0);
	cin>>t;
	init();
	long long last=1;
	while(t--)
	{
		cin>>x;
		for(int i=last;i<=x;i++)
		{
			for(int j=1;j<=i;j++)
			{
				int a=i,b=j,tf=1;
				for(int k=1;k<=len;k++) if(a+b<sh[k]&&(sh[k]-b)%a==0) {tf=0;break;}
				ans+=tf,ans%=mod;
				if(i==j) break;
				a=j,b=i,tf=1;
				for(int k=1;k<=len;k++) if(a+b<sh[k]&&(sh[k]-b)%a==0) {tf=0;break;}
				ans+=tf,ans%=mod;
			}
		}
		cout<<ans<<"\n";
		last=x+1;
	}
}
