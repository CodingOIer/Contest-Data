#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,tot,ans=1e9;
int a[500005];
int s[500005];
int f[500005];
int check(int x){
	f[0]=1e9;
	f[1]=a[1];
	for(int i=2;i<=n;i++){
		f[i]=min(f[i-1],a[i]);
		if(a[i]+a[i-1]<=x)f[i]=max(f[i],min(f[i-2],a[i-1]+a[i]));
	}
	return f[n];
}
void Init(int x){
	int last=-1e9;
	for(int i=1;i<=n;i++){
		if(s[i]<x)continue;
		if(s[i]!=last){
			s[++tot]=s[i];
			last=s[i];
		}
	}
}
int nxt(int x,int s){
	int l=x+1,r=tot;
	while(l<r){
		int mid=(l+r)/2;
		if(check(mid)!=s){
			r=mid;
		}else{
			l=mid+1;
		}
	}
	return l;
}
signed main(){
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	read(n);
	int maxn=0;
	for(int i=1;i<=n;i++)read(a[i]),maxn=max(maxn,a[i]);
	s[1]=maxn;
	for(int i=2;i<=n;i++)s[i]=a[i]+a[i-1];
	sort(s+1,s+n+1);
	Init(maxn);
	for(int i=1;i<=tot;){
		int res=check(s[i]);
		ans=min(s[i]-res,ans);
		i=nxt(i,res);
	}
	write(ans);
	flush();
	return 0;
}
