#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
const int mod=1e9+7;
int n,r,g,b,ans;
int a[205];
vector<int>to[205];
map<int,map<int,map<int,map<int,int>>>>f;
inline int Mod(int x){if(x>=mod)x-=mod;return x;}
int tmp[105][105][105];
void dfs(int x,int fa){
	if(a[x]==1)f[x][1][0][0]=1;
	else if(a[x]==2)f[x][0][1][0]=1;
	else if(a[x]==3)f[x][0][0][1]=1;
	for(auto y:to[x]){
		if(y==fa)continue;
		dfs(y,x);
		for(int i=0;i<=r;i++)
			for(int j=0;j<=g;j++)
				for(int k=0;k<=b;k++){
					tmp[i][j][k]=f[x][i][j][k];
					f[x][i][j][k]=0;
				}
		for(int i=0;i<=r;i++)
			for(int j=0;j<=g;j++)
				for(int k=0;k<=b;k++)
					for(int s1=0;s1<=i;s1++)
						for(int s2=0;s2<=j;s2++)
							for(int s3=0;s3<=k;s3++)
							f[x][i][j][k]=Mod(1ll*f[x][i][j][k]+1ll*f[y][s1][s2][s3]*tmp[i-s1][j-s2][k-s3]%mod);
	}
	for(int i=0;i<=r;i++)
			for(int j=0;j<=g;j++)
				for(int k=0;k<=b;k++)
					ans=(ans+f[x][i][j][k]);
	f[x][0][0][0]=1;
}
signed main(){
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
	read(n,r,b,g);
	for(int i=1;i<=n;i++){
		char ch=getch();
		if(ch=='r')a[i]=1;
		else if(ch=='g')a[i]=2;
		else a[i]=3;
	}
	for(int i=1;i<n;i++){
		int u,v;
		read(u,v);
		to[u].push_back(v);
		to[v].push_back(u);
	}
	dfs(1,0);
	write(ans);
	flush();
	return 0;
}
