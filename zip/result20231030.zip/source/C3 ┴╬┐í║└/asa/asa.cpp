#include<bits/stdc++.h>
using namespace std;//8:4
int a[15]={0,0,0,0,1,1,1,1,4,5,5};
signed main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		int x;
		cin>>x;
		cout<<a[x]<<endl;
	}
	return 0;
} 
