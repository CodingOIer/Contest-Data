#include<bits/stdc++.h>
using namespace std;
#define int long long
#define inf 1e18
int n;
int a[500010];
int mx,mn=inf;
void work(int l,int r)
{
	if(l>r)
	{
		return;
	}
	if(l==r)
	{
		mx=max(mx,a[l]);
		mn=min(mn,a[l]);
		return;
	}
	if(l+1==r)
	{
		if(a[l]+a[r]<=mx)
		{
			mn=min(mn,a[l]+a[r]);
			return;
		}
		if(a[l]>=mn&&a[r]>=mn)
		{
			return;
		}
		int vb=a[l]+a[r]-mx;
		int vf=max(mn-a[l],mn-a[r]);
		if(vb<=vf)
		{
			mx=a[l]+a[r];
			return;
//			mx=max(a[l]+a[r],mx)
		}else{
			mn=min(a[l],a[r]);
			return;
		}
	}
	int flag=-1,x=inf;
	for ( int i = l ; i+1 <= r ; i++ )
	{
		if(a[i]+a[i+1]<x)
		{
			flag=i;
			x=a[i]+a[i+1];
		}
	}
	mx=max(x,mx);
	mn=min(x,mn);
	work(l,flag-1);
	work(flag+2,r);
}
signed main()
{
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	cin >> n;
	for ( int i = 1 ; i <= n ; i++ )
	{
		cin >> a[i];
	}
	work(1,n);
	cout <<mx-mn;
	return 0;
}//�ٵ�̰�ģ�0 
