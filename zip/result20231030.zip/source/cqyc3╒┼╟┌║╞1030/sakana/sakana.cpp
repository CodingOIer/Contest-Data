#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=5e5+7,inf=1e12;

ll n,f[Maxn][2],a[Maxn];

int main(){
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++) scanf("%lld",&a[i]);
	//for(ll i=1;i<=n;i++) f[i][0]=f[i][1]=inf;
	
	for(ll i=1;i<=n;i++){
		f[i][0]=max(f[i-1][0],abs(a[i]-a[i-1]));
		
		if(i>=2){
			f[i][0]=min(f[i][0],max(f[i-1][1],abs(a[i]-(a[i-1]+a[i-2]))));
			f[i][1]=max(f[i-2][0],abs(a[i]+a[i-1]-a[i-2]));
			if(i>=3){
				f[i][1]=min(f[i][1],max(f[i-2][1],abs(a[i]+a[i-1]-a[i-2]-a[i-3])));
			}
		}
	}
	printf("%lld",min(f[n][0],f[n][1]));
	return 0;
}
/*
5
1 3 1 2 5

6
1 4 3 6 2 9

6
1 6 2 5 3 4
*/
