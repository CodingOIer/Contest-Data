#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Mod=998244353,Maxn=4e6+7;

ll T,n,ans; 
ll mu[Maxn],f[Maxn];
bitset<Maxn>isp;
vector<ll>p;

inline ll up(ll x){
	return (x%Mod+Mod)%Mod;
}

inline void Sieve(int N){
	isp[0]=isp[1]=1;mu[1]=1;
	for(ll i=2;i<=N;i++){
		if(!isp[i]) p.push_back(i),mu[i]=-1;
		for(auto j:p){
			if(i*j>N) break;
			isp[i*j]=1;	
			if(!(i%j)) break;
			mu[i*j]=-mu[i];
		}
	}
	for(ll i=2;i<=N;i++) f[i]=-mu[i];
	for(ll i=1;i<=N;i++) f[i]=up(f[i]+f[i-1]);
}

inline ll smu(ll l,ll r){
	ll ql=l,qr=r;
	l=ceil(sqrtl(l*1.)),r=(ll)sqrtl(r*1.);
	while(l*l<ql) l++;
	while((r+1)*(r+1)<qr) r++;
	while((l-1)*(l-1)>ql) l--; 
	while(r*r>qr) r--;
	if(l==0) return f[r];
	return f[r]-f[l-1];
}

int main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	scanf("%lld",&T);
	Sieve(Maxn-7);
	while(T--){
		scanf("%lld",&n);
		ans=0;
		for(ll l=1,r;l<=n;l=r+1){
			r=n/(n/l);
			ll res=(__int128)(n/l)*(n/l)%Mod;
			ans=up(ans+(__int128)res*smu(l,r)%Mod);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
/*
5
1
3
5
7
9

11
31
233
314
1582
3141
4713
914159
31415926
3141592653
314159265358
1000000000000
*/


