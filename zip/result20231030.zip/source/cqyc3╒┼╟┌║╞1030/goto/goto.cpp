#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=5e6+7,inf=1e12;

ll n,k,a[Maxn],ans=-inf,sum[Maxn];

int main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	bool Tid1;
	scanf("%lld%lld",&n,&k);
	for(ll i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		if(a[i]>0) Tid1=1;
	}
	if(!Tid1){
		printf("0");
		return 0;
	}
	if(k==1){
		ll cnt=0;
		for(ll i=1;i<=n;i++) if(a[i]>=0) cnt++,ans+=a[i];
		printf("%lld",ans);
		return 0;
	}
	
	for(ll i=0;i<(1<<n);i++){
		ll cnt=0,sum=0;
		bool flg=0;
		for(ll j=0;j<=n;j++){
			if(i>>j&1){
				sum+=a[j+1];
				cnt++;
			}
			else{
				if(cnt<k) flg=1;
				cnt=0;
			}
		}
		if(!flg){
			ans=max(ans,sum);
		}
	}
	printf("%lld",ans);
	return 0;
}
/*
6 2
1 -1 4 -5 1 4
*/


