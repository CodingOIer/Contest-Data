#include <iostream>
#include <vector>
#include <set>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 500005;
int a[N],b[N];
int n;

set<pair<int,int>> s;

int f[N];
int solve(int v){
    for(int k=1;k<=n;k++)
        f[k] = 1e18;
    f[0] = 0;
    for(int k=1;k<=n;k++){
        if(a[k]>=v)
            f[k] = min(f[k],max(f[k-1],a[k]));
        if(k>1&&a[k]+a[k-1]>=v)
            f[k] = min(f[k],max(f[k-2],a[k-1]+a[k]));
    }
    return f[n];
}

signed main(){
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n = in;
    vector<int> q;
    for(int k=1;k<=n;k++){
        q.push_back(a[k] = in);
        s.insert({a[k],k});
    }
    for(int k=1;k<n;k++)
        q.push_back(a[k]+a[k+1]);
    sort(q.begin(),q.end());
    int ans = 1e18;
    for(int v:q){
        int w = solve(v);
        if(~w)
            ans = min(ans,w-v);
        else
            break;
    }
    out(ans);
    return 0;
}