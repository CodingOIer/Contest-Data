#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 5000005;
int s[N],f[N];
int n,K;

signed main(){
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    n = in,K = in;
    int w = -1e18;
    for(int k=1;k<=n;k++){
        int x = in;
        s[k] = s[k-1]+x;
        if(k>=K)
            w = max(w,f[k-K]-s[k-K]);
        f[k] = max(f[k-1],s[k]+w);
    }
    out(f[n]);
    return 0;
}