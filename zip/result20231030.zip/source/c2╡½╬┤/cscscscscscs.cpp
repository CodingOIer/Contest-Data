#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline int ksm(int x,int k){
	int res=1;
	for(;k;k>>=1){if(k&1)res=res*x;x*=x;if(res>1e9)return res;}
	//cout<<res<<endl;
	return res;
}
signed main(){
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	for(int a=1;a<=11;a++)
		for(int b=1;b<=11;b++){
			int ok=0;
			for(int k=2;k<=1000;k++){
				int ok1=1;
				for(int x=1;x<=1000;x++){
					int res=1;
					for(int z=2;z<=1000;z++){
						int kk=ksm(z,k);
						if(kk>=a*x+b||kk<0||kk==0)break;
						if((a*x+b)%kk)res=0;
					}
					if(res)ok1=0;
				}
				if(ok1)ok=1;
			}
			if(!ok)printf("%d %d\n",a,b);
		}
	return 0;
}

