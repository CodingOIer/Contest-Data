#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=1e6+5;
int n,a[Maxn],v[Maxn];
int f[2][Maxn][2],g[Maxn][2];
map<int,int>vis;
int cnt[p];
struct Tree{int ls,rs,data;}t[Maxn<<1][3];
signed main(){
//	freopen("sakana.in","r",stdin);
//	freopen("sakana.out","w",stdout);
	n=read();int cnt=n;
	for(int i=1;i<=n;i++)v[i]=a[i]=read();
	for(int i=1;i<n;i++)v[++cnt]=a[i]+a[i+1];
	sort(v+1,v+1+cnt);
	int m=unique(v+1,v+1+cnt)-v-1;
	for(int i=1;i<=m;i++)vis[v[i]]=i;
	for(int i=0;i<=1;i++)
		for(int j=0;j<=m;j++)f[i][j][0]=f[i][j][1]=2e18+7;
	f[1][vis[a[1]]][0]=a[1];
	for(int j=0;j<=m;j++)g[j][0]=g[j][1]=2e18+7;
	g[vis[a[1]+a[2]]][0]=0;
	for(int i=2;i<=n;i++){
		for(int k=1;k<=m;k++){
			int j=v[k];
			if(a[i]<j)f[i&1][vis[a[i]]][0]=min(f[i&1][vis[a[i]]][0],min(f[i&1^1][k][0],f[i&1^1][k][1]));
			else f[i&1][k][0]=max(min(f[i&1^1][k][0],f[i&1^1][k][1]),a[i]);
		}
		for(int k=1;k<=m;k++){
			int j=v[k];
			if(a[i]+a[i-1]<j)f[i&1][vis[a[i]+a[i-1]]][1]=min(f[i&1][vis[a[i]+a[i-1]]][1],min(g[k][1],g[k][0]));
			else f[i&1][k][1]=max(min(g[k][1],g[k][0]),a[i]+a[i-1]);
		}
		for(int k=1;k<=m;k++)g[k][0]=f[i&1^1][k][0],g[k][1]=f[i&1^1][k][1],f[i&1^1][k][0]=f[i&1^1][k][1]=2e18+7;
	}
	int ans=2e18+7;
	for(int i=1;i<=m;i++)ans=min(ans,min(f[n&1][i][0],f[n&1][i][1])-v[i]);
	write(ans);flush();
	return 0;
}

