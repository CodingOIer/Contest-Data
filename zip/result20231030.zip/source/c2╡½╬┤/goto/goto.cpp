#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
  	while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=5e6+5;
int n,a[Maxn],k;
int f[Maxn],sum[Maxn],g[Maxn];
inline void solve21(){
	memset(f,-0x7f,sizeof f);
	for(int i=k;i<=n;i++){
		for(int j=0;j<=i-k;j++)
			f[i]=max(f[i],g[j]+sum[i]-sum[j]);
		g[i]=max(f[i],g[i-1]);
	}
	//for(int i=1;i<=n;i++)write(f[i]),pc('\n');
	//for(int i=1;i<=n;i++)printf("g[%d]=%d\n",i,g[i]);
	write(g[n]);
	flush();
	exit(0);
}
int gg[Maxn];
inline void solve100(){
	g[k]=f[k]=sum[k];g[k]=max(g[k],0ll);
	gg[1]=g[1]-a[1];
	for(int i=2;i<=k;i++)gg[i]=max(gg[i-1],g[i]-sum[i]);
	for(int i=k+1;i<=n;i++){
		f[i]=max(0ll,gg[i-k])+sum[i];
		g[i]=max(g[i-1],f[i]);
		gg[i]=max(gg[i-1],g[i]-sum[i]);
	}
	//for(int i=1;i<=n;i++)write(f[i]),pc('\n');
	//for(int i=1;i<=n;i++)printf("g[%d]=%d\n",i,g[i]);
	write(g[n]);flush();
	exit(0);
}
signed main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	n=read();k=read();
	int op=1;
	for(int i=1;i<=n;i++){
		a[i]=read();
		sum[i]=sum[i-1]+a[i];
		if(a[i]>0)op=0;
	}
	if(op){
		int ans=-1e18;
		for(int i=k;i<=n;i++)ans=max(ans,sum[i]-sum[i-k]);
		write(ans);flush();return 0;
	}
	if(k==1){
		int ans=0;
		for(int i=1;i<=n;i++)ans+=(a[i]>0)*a[i];
		write(ans);flush();return 0;
	}
	if(n<=5000)solve21();
	solve100();
	return 0;
}

