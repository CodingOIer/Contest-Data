#include<bits/stdc++.h>
#define re register
#define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int T,n;
int sqnb[1000001];
namespace WrongAnswer
{
	int prime[1000001],cnt,ans;
	bitset<1000001> isprime,vis;
	inline void sieve(int n)
	{
		isprime.set(1);
		rep(i,2,n)
		{
			if(!isprime.test(i)&&!vis.test(i)) vis.set(i),prime[++cnt]=i;
			for(re int j=i+i;j<=n;j+=i) if(!vis.test(j)) vis.set(j),isprime.set(j,0);
		}
	}
	inline int main()
	{
		rep(i,1,1000000) sqnb[i]=i*i;
		sieve(1e6);
		isprime.reset();
		rep(i,1,cnt) isprime.set(prime[i]);
		read(T);
		while(T--)
		{
			read(n);
			ans=0;
			int lim=sqrt(n),cur;
			rep(d,2,lim)
			{
				if(!isprime.test(d)) continue;
				cur=n/sqnb[d];
				(ans+=cur*cur)%=998244353;
			}
			// int cnt=0;
			// rep(i,2,lim) rep(j,i+1,lim) if(sqnb[i]*sqnb[j]<=n) ++cnt;
			writeln(ans);
			// 有一种情况能卡掉，可能 n=36 就 G 了
		}
		return 0;
	}
}
namespace BruteForce
{
	inline int main()
	{
		rep(i,1,5000) sqnb[i]=i*i;
		read(T);
		while(T--)
		{
			read(n);
			int ans=0,lim=sqrt(n);
			rep(i,1,n) rep(j,1,n)
			{
				rep(d,2,sqrt(n)) if(!(i%sqnb[d])&&!(j%sqnb[d])){++ans;break;}
			}
			writeln(ans);
		}
	
		return 0;
	}
}
signed main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	BruteForce::main();
	return 0; 
}
