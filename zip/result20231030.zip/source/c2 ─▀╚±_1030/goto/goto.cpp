#include<bits/stdc++.h>
#define re register
#define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,k,a[100001],res;
namespace NonPositive
{
	inline void Solve()
	{
		puts("0");
	}
}
namespace K1
{
	inline void Solve()
	{
		sort(a+1,a+n+1,greater<int>());
		int ans=0;
		rep(i,1,n) if(a[i]<0) break; else ans+=a[i];
		write(ans);
	}
}
namespace BruteForce
{
	int dp[100001],sum[100001];
	inline void Solve()
	{
		partial_sum(a+1,a+n+1,sum+1);
		rep(i,k,n)
		{
			dp[i]=max(dp[i],dp[i-1]);
			rep(j,1,i-k+1) dp[i]=max(dp[i],sum[i]-sum[j-1]+dp[j]);
		}
	//	rep(i,1,n) cout<<"dp["<<i<<"]="<<dp[i]<<endl;
		write(dp[n]);
	}
}
signed main()
{
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	read(n,k);
	rep(i,1,n) read(a[i]),res+=a[i]<=0;
	if(res==n) NonPositive::Solve();
	else if(k==1) K1::Solve();
	else if(n<=50000) BruteForce::Solve();
	return 0; 
}
