#include<bits/stdc++.h>
using namespace std;
const int P=998244353;
typedef long long ll;
const int NN=1e6+4;
int mu[NN],prime[NN],phi[NN],s[NN];
bool vis[NN];
int main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	int cnt=0;
	vis[1]=true,mu[1]=phi[1]=1;
	for(int i=2;i<NN;i++)
	{
		if(!vis[i])
		{
			prime[++cnt]=i;
			phi[i]=i-1;
			mu[i]=1;
		}
		for(int j=1;1ll*i*prime[j]<NN&&j<=cnt;j++)
		{
			if(!(i%prime[j]))
			{
				phi[i*prime[j]]=phi[i]*prime[j];
				mu[i*prime[j]]=0;
				vis[i*prime[j]]=true;
				break;
			}
			phi[i*prime[j]]=phi[i]*(prime[j]-1);
			mu[i*prime[j]]=mu[i]*-1;
			vis[i*prime[j]]=true;
		}
	}
	for(int i=1;i<NN;i++)
		s[i]=(s[i-1]+phi[i])%P;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		ll n;
		int ans=0;
		scanf("%lld",&n);
		for(int i=1;i<=n;i++)
			if(!mu[i])
				ans=(ans+s[n/i]*2%P-1)%P;
		printf("%d\n",ans);
	}
	return 0;
}
