#include<bits/stdc++.h>
using namespace std;
const int NN=5e5+4;
int n,a[NN],f[NN];
int solve(int v)
{
	for(int i=1;i<=n;i++)
		f[i]=2e9+100;
	f[0]=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]>=v)
			f[i]=min(f[i],max(f[i-1],a[i]));
		if(i>1&&a[i]+a[i-1]>=v)
			f[i]=min(f[i],max(f[i-2],a[i-1]+a[i]));
	}
	return f[n];
}
int main()
{
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	scanf("%d",&n);
	vector<int>g;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		g.push_back(a[i]);
	}
	for(int i=1;i<n;i++)
		g.push_back(a[i]+a[i+1]);
	sort(g.begin(),g.end());
	int ans=2e9+100;
	for(int i=0;i<g.size();i++)
	{
		int v=g[i],w=solve(v);
		if(w<2e9+50)
			ans=min(ans,w-v);
		else
			break;
	}
	printf("%d",ans);
	return 0;
}
