#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=5e6+4;
ll s[NN],f[NN];
int main()
{
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	ll res=-1e18;
	for(int i=1;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		s[i]=s[i-1]+x;
		if(i>=k)
			res=max(res,f[i-k]-s[i-k]);
		f[i]=max(f[i-1],res+s[i]);
	}
	printf("%lld",f[n]);
	return 0;
}
