#include <bits/stdc++.h>
#define int long long
#define lowbit(x) (x&(-x))
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 5e6+5;
int n,k,a[N],s[N],dp[N];
bool flag = 1;
int mx,_mx;
signed main()
{
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	read(n),read(k);
	for(int i = 1;i<=n;i++)
		read(a[i]),flag&=(a[i]<=0),s[i] = s[i-1]+a[i];
	if(flag) return puts("0"),0;
	if(k==1)
	{
		int ans = 0;
		for(int i = 1;i<=n;i++)
			ans+=max(0ll,a[i]);
		write(ans);
	}
	else if(n<=1e3)
	{
		for(int i = k;i<=n;i++)
		{
			for(int j = 1;j<i;j++)
				dp[i] = max(dp[i],dp[j]);
			for(int j = k;j<=i;j++)
				dp[i] = max(dp[i],dp[i-j]+s[i]-s[i-j]);
		}
		write(dp[n]);
	}
	else
	{
		for(int i = k;i<=n;i++)
		{
			_mx = max(_mx,dp[i-k]+s[i-k]);
			dp[i] = max(mx,_mx+s[i]);
			mx = max(mx,dp[i]);
		}
		write(dp[n]);
	}
	return 0;
}

