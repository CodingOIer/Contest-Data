#include <bits/stdc++.h>
using namespace std;
const int N = 25;
int n,r[3],ton[3],a[N],ans;
string s;
bool vis[N][N];
int p[N],cnt;
bool ok()
{
	if(cnt==1) return 1;
	for(int i = 1;i<=cnt;i++)
	{
		bool flag = 0;
		for(int j = 1;j<=cnt;j++)
			if(vis[p[i]][p[j]])
			{
				flag = 1;
				break;
			}
		if(!flag) return 0;
	}
	return 1;
}
signed main()
{
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>r[0]>>r[1]>>r[2];
	cin>>s;
	for(int i = 0;i<n;i++)
	{
		if(s[i]=='r') a[i] = 0;
		if(s[i]=='b') a[i] = 1;
		if(s[i]=='g') a[i] = 2;
	}
	for(int i = 1,u,v;i<n;i++)
		cin>>u>>v,u--,v--,vis[u][v] = vis[v][u] = 1;
	for(int i = 1;i<(1<<n);i++)
	{
		cnt = 0,ton[1] = ton[2] = ton[0] = 0;
		for(int j = 0;j<n;j++)
			if((i&(1<<j)))
				p[++cnt] = j;
		if(!ok()) continue;
		for(int j = 1;j<=cnt;j++)
			ton[a[p[j]]]++;
		if(ton[0]>r[0]||ton[1]>r[1]||ton[2]>r[2]) continue;
		ans++;
	}
	cout<<ans;
	return 0;
}

