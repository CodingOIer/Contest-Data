#include <bits/stdc++.h>
#define int long long
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 5e5+5;
int n,a[N],fz[N][2],cnt,ans = 2e18;
void get()
{
	int mn = 2e18,mx = 0;
	for(int i = 1;i<=cnt;i++)
		mn = min(mn,a[fz[i][0]]+a[fz[i][1]]),mx = max(mx,a[fz[i][0]]+a[fz[i][1]]);
	ans = min(ans,mx-mn);
}
void dfs(int x)
{
	if(x>n) return get();
	if(cnt&&!fz[cnt][1]) fz[cnt][1] = x,dfs(x+1),fz[cnt][1] = 0;
	fz[++cnt][0] = x,dfs(x+1),fz[cnt--][0] = 0;
}
signed main()
{
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	read(n);
	for(int i = 1;i<=n;i++)
		read(a[i]);
	dfs(1);
	write(ans);
	return 0;
}

