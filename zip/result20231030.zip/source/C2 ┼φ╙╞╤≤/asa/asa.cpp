#include <bits/stdc++.h>
#define int long long
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 5e3+5;
int n,ans[N];
bool vis[N],v[N];
signed main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	for(int i = 2;i<N;i++)
		for(int j = i*i;j<N;j*=i)
			v[j] = 1;
	for(int i = 1;i<N;i++)
		if(v[i]&&!vis[i])
			for(int j = i;j<N;j+=i)
				vis[j] = 1;
	vis[1] = 0;
	for(int i = 1;i<N;i++)
	{
		ans[i] = ans[i-1]+vis[i];
		for(int j = 1;j<i;j++)
			if(vis[__gcd(i,j)])
				ans[i]+=2;
	}
	int T;
	read(T);
	while(T--) writen(ans[read<int>()]);
	return 0;
}

