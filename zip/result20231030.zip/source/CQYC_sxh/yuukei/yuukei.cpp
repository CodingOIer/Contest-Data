#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 1e9 + 7;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

char qqq;
const int N = 210;

int n, lim[3], c[N], ans; char s[N];
int head[N], nxt[N << 1], to[N << 1], cnt;

void Add(int u, int v) {
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt;   
}

int siz[N], maxp[N], root; bool vis[N];
void get_root(int u, int fa, int total) {
    siz[u] = 1, maxp[u] = 0;
    Eor(u) if (to[i] != fa && !vis[to[i]]) {
        get_root(to[i], u, total);
        siz[u] += siz[to[i]];
        maxp[u] = max(maxp[u], siz[to[i]]);
    }
    maxp[u] = max(maxp[u], total - siz[u]);
    if (maxp[u] < maxp[root]) root = u;
}

int sz[N][3], dfn[N], num;
vector<vector<vector<int>>> f[N];

void pre(int u, int fa) {
    siz[u] = 1;
    Eor(u) if (to[i] != fa && !vis[to[i]]) {
        pre(to[i], u), siz[u] += siz[to[i]];
    } dfn[++num] = u;
}
void New(int k, int x, int y, int z) {
    f[k].resize(x + 1);For(i, 0, x) f[k][i].resize(y + 1);
    For(i, 0, x) For(j, 0, y) f[k][i][j].resize(z + 1);
    For(i, 0, x) For(j, 0, y) For(l, 0, z) f[k][i][j][l] = 0;
}
void calc(int u) {
    num = 0, pre(u, 0);
    New(0, 1, 1, 1), f[0][0][0][0] = 1;
    For(x, 1, num) { int u = dfn[x];
        For(i, 0, 2) sz[x][i] = max(sz[x - 1][i], sz[x - siz[u]][i]);
        ++sz[x][c[u]]; For(i, 0, 2) sz[x][i] = min(sz[x][i], lim[i]);
        New(x, sz[x][0] + 3, sz[x][1] + 3, sz[x][2] + 3);

        For(i, 0, sz[x - 1][0]) For(j, 0, sz[x - 1][1]) For(k, 0, sz[x - 1][1])
            add(f[x][i + (c[u] == 0)][j + (c[u] == 1)][k + (c[u] == 2)], f[x - 1][i][j][k]);
        For(i, 0, sz[x - siz[u]][0]) For(j, 0, sz[x - siz[u]][1]) For(k, 0, sz[x - siz[u]][1])
            add(f[x][i + (c[u] == 0)][j + (c[u] == 1)][k + (c[u] == 2)], f[x - 1][i][j][k]);
    }
    For(i, 0, sz[num][0]) For(j, 0, sz[num][1]) For(k, 0, sz[num][2]) add(ans, f[num][i][j][k]);
}

void solve(int u) {
    vis[u] = 1, calc(u); Eor(u) if (!vis[to[i]]) 
    root = 0, get_root(to[i], 0, siz[to[i]]), solve(root);
}

char qqqq;
signed main() {
	freopen("yuukei.in", "r", stdin);
	freopen("yuukei.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    n = read(); For(i, 0, 2) lim[i] = read();
    scanf("%s", s + 1); For(i, 1, n) {
        if (s[i] == 'r') c[i] = 0;
        if (s[i] == 'b') c[i] = 1;
        if (s[i] == 'g') c[i] = 2;
    } For(i, 1, n - 1) Add(read(), read());
    maxp[0] = n, root = 0, get_root(1, 1, n), solve(root);
    cout << ans << '\n';  
	return 0;
}
