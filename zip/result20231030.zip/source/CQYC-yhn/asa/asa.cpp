#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int T,n,a[1000005],prime[1000005],cnt,ans=0,phi[1000005];
bitset<1000005> v;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("asa.in","r",stdin);
    freopen("asa.out","w",stdout);
    for(int i=2;i<=1000000;i++){
        if(!v[i]) prime[++cnt]=i,phi[i]=1;
        for(int j=1;(j<=cnt)&&((prime[j]*i)<=1000000);j++){
            v[prime[j]*i]=1;
            phi[prime[j]*i]=-phi[i];
            if((i%prime[j])==0){
                phi[prime[j]*i]=0;
                break;
            }
        }
    }
    for(int i=1;i<=1000000;i++) a[i]=i*i;
    T=read();
    while(T--){
        n=read();
        int ans=0;
        for(int i=1;(i<=1000000)&&(a[i]<=n);i++){
            int t=n/a[i];
            t%=M;
            t=(t*t)%M;
            t=t*phi[i];
            t=((t%M)+M)%M;
            ans=(ans+t)%M;
        }
        cout<<ans<<"\n";
    }
    return 0;
}