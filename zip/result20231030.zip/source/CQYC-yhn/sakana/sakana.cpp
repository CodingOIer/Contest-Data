#include<bits/stdc++.h>
using namespace std;
int n,a[500005];
map<int,int> dp[2][2];
map<int,int>::iterator it;
//第 i 条鱼，i-1 是否已成组，最小值的最大值的最小值
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i]=read();
    dp[1][0][2000000001]=0;
    dp[1][1][a[1]]=a[1];
    for(int i=1;i<=n;i++){
        int t=i&1;
        dp[t^1][0].clear();
        dp[t^1][1].clear();
        for(int j=0;j<=1;j++){
            for(it=dp[t][j].begin();it!=dp[t][j].end();it++){
                pair<int,int> o=*it;
                int d=a[i+1]+a[i];
                if(!j){
                    if(dp[t^1][1][min(o.first,d)]) dp[t^1][1][min(o.first,d)]=min(dp[t^1][1][min(o.first,d)],max(o.second,d));
                    else dp[t^1][1][min(o.first,d)]=max(o.second,d);
                }
                else{
                    if(dp[t^1][0][o.first]) dp[t^1][0][o.first]=min(dp[t^1][0][o.first],o.second);
                    else dp[t^1][0][o.first]=o.second;
                    if(dp[t^1][1][min(o.first,a[i+1])]) dp[t^1][1][min(o.first,a[i+1])]=min(dp[t^1][1][min(o.first,a[i+1])],max(dp[t][j][o.first],a[i+1]));
                    else dp[t^1][1][min(o.first,a[i+1])]=max(dp[t][j][o.first],a[i+1]);
                }
            }
        }
    }
    int ans=2000000001;
    for(it=dp[n&1][1].begin();it!=dp[n&1][1].end();it++){
        pair<int,int> o=*it;
        ans=min(ans,o.second-o.first);
    }
    cout<<ans;
    return 0;
}