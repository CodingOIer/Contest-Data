#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,a[5000005],sum[5000005],dp[5000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    n=read(),k=read();
    for(int i=1;i<=n;i++) a[i]=read(),sum[i]=sum[i-1]+a[i];
    int mx=0,mx2=-1e18;;
    for(int i=1;i<=n;i++){
        int in=1e18;
        if((i-k)>=0) mx2=max(mx2,dp[i-k]-sum[i-k]);
        dp[i]=mx2+sum[i];
        mx=max(mx,dp[i]);
        dp[i]=mx;
    }
    cout<<dp[n];
    return 0;
}