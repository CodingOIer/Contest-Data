#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,w1,w2,w3,t1,t2,cnt,head[205],nxt[405],txt[405],dp[205][300005],sz[205][3],F[300005];
char a[205];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int js(int x,int y,int z){
    return z+y*(w3+1)+x*(w3+1)*(w2+1);
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void dfs(int k,int f){
    for(int i=head[k];i;i=nxt[i]){
        int v=txt[i];
        if(v==f) continue;
        dfs(v,k);
        int s1=min(sz[k][0],w1),s2=min(sz[k][1],w2),s3=min(sz[k][2],w3);
        int s4=min(sz[v][0],w1),s5=min(sz[v][1],w2),s6=min(sz[v][2],w3);
        int s7=min(sz[k][0]+sz[v][0],w1),s8=min(sz[k][1]+sz[v][1],w2),s9=min(sz[k][2]+sz[v][2],w3);
        for(int d1=0;d1<=s7;d1++) for(int d2=0;d2<=s8;d2++) for(int d3=0;d3<=s9;d3++) F[js(d1,d2,d3)]=0;
        for(int d1=0;d1<=s1;d1++){
            for(int d2=0;d2<=s2;d2++){
                for(int d3=0;d3<=s3;d3++){
                    for(int d4=0;d4<=min(w1-d1,s4);d4++){
                        for(int d5=0;d5<=min(w2-d2,s5);d5++){
                            for(int d6=0;d6<=min(w3-d3,s6);d6++){
                                add(F[js(d1+d4,d2+d5,d3+d6)],dp[k][js(d1,d2,d3)]*dp[v][js(d4,d5,d6)]%M);
                            }
                        }
                    }
                }
            }
        }
        for(int d1=0;d1<=s7;d1++) for(int d2=0;d2<=s8;d2++) for(int d3=0;d3<=s9;d3++) add(dp[k][js(d1,d2,d3)],F[js(d1,d2,d3)]);
        for(int j=0;j<3;j++) sz[k][j]+=sz[v][j];
    }
}
signed main(){
    freopen("yuukei.in","r",stdin);
    freopen("yuukei.out","w",stdout);
    n=read(),w1=read(),w2=read(),w3=read();
    scanf("%s",a+1);
    for(int i=1;i<=n;i++){
        if(a[i]=='r') sz[i][0]++,dp[i][js(1,0,0)]=1;
        if(a[i]=='b') sz[i][1]++,dp[i][js(0,1,0)]=1;
        if(a[i]=='g') sz[i][2]++,dp[i][js(0,0,1)]=1;
    }
    for(int i=1;i<n;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    int ans=0;
    dfs(1,0);
    for(int h=1;h<=n;h++) for(int i=0;i<=w1;i++) for(int j=0;j<=w2;j++) for(int g=0;g<=w3;g++) add(ans,dp[h][js(i,j,g)]);
    cout<<ans;
    return 0;
}