#include<bits/stdc++.h>
using namespace std;
const int mod=998244353,N=5000;
int T,g[N+1][N+1],ans[N+1];
bool is[N+1];
long long n;
int main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	for(int i=1;i<=N;++i) g[i][0]=g[0][i]=i;
	for(int i=2;i<=N;++i)
		for(int j=2;j*j<=i;++j)
			if(i%(j*j)==0){
				is[i]=1;
				break;
			}
	for(int i=1;i<=N;++i){
		for(int j=1;j<i;++j){
			g[i][j]=g[j][i%j];
			ans[max(i,j)]+=is[g[i][j]]*2;
		}
		ans[i]+=is[i];
	}
	for(int i=1;i<=N;++i) ans[i]=(ans[i-1]+ans[i])%mod;
	scanf("%d",&T);
	while(T--){
		scanf("%lld",&n);
		printf("%d\n",ans[n]);
	}
	return 0;
}

