#include<bits/stdc++.h>
using namespace std;
const int N=205,mod=1e9+7;
inline void read(int &x){
	x=0;int f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	x*=f;
}
int head[N],to[N<<1],nxt[N<<1],tot;
inline void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
int n,k[3],S,f[61][31][31][31],col[N],sz[N];
bool sub=1;
char s[N];
int C[N][N],ans,cnt[3];
inline void addv(int &x,int y){x+=y;if(x>=mod)x-=mod;}
void dp(int p,int fa){
	if(col[p]==0) f[p][1][0][0]=1;
	if(col[p]==1) f[p][0][1][0]=1;
	if(col[p]==2) f[p][0][0][1]=1;
	sz[p]=1;
	for(int o=head[p],v;o;o=nxt[o]){
		v=to[o];
		if(v==fa) continue;
		dp(v,p);
		sz[p]+=sz[v];
		for(int a=min(k[0],sz[p]);~a;--a)
		for(int b=min(k[1],sz[p]-a);~b;--b)
		for(int c=min(k[2],sz[p]-a-b);~c;--c)
		for(int x=0;x<=a;++x)
		for(int y=0;y<=b;++y)
		for(int z=0;z<=c;++z)
			addv(f[p][a][b][c],1ll*f[p][a-x][b-y][c-z]*f[v][x][y][z]%mod);
	}
	for(int a=0;a<=k[0];++a)
	for(int b=0;b<=k[1];++b)
	for(int c=0;c<=k[2];++c)
		addv(ans,f[p][a][b][c]);
}
int g[N][N];
inline void dp2(int p,int fa){
	if(col[p]==0) g[p][1]=1;
	for(int o=head[p];o;o=nxt[o]){
		if(to[o]==fa) continue;
		dp2(to[o],p);
		for(int i=k[0];i;--i)
		for(int j=1;j<i;++j)
			addv(g[p][i],1ll*g[p][i-j]*g[to[o]][j]%mod);
	}
	for(int i=1;i<=k[0];++i) addv(ans,g[p][i]);	
}
int main(){
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
	read(n);
	read(k[0]),read(k[1]),read(k[2]);
	scanf("%s",s+1);
	for(int i=1;i<=n;++i){
		if(s[i]=='r') col[i]=0;
		if(s[i]=='b') col[i]=1;
		if(s[i]=='g') col[i]=2;
	}
	for(int i=1,u,v;i<n;++i){
		read(u),read(v);
		sub&=(u==1||v==1);
		add(u,v);
		add(v,u);
	}
	if(sub){
		C[0][0]=1;
		for(int i=1;i<=n;++i) ++cnt[col[i]];
		for(int i=1;i<=n;++i){
			C[i][0]=1;
			for(int j=1;j<=i;++j)
				C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
		}
		if(k[col[1]]){
			--k[col[1]],--cnt[col[1]];
			for(int a=0;a<=min(k[0],cnt[0]);++a)
			for(int b=0;b<=min(k[1],cnt[1]);++b)
			for(int c=0;c<=min(k[2],cnt[2]);++c)
				ans=(ans+1ll*C[cnt[0]][a]*C[cnt[1]][b]%mod*C[cnt[2]][c]%mod)%mod;
			++k[col[1]];
		}
		for(int c=0;c<3;++c)
			if(k[c]) ans=(ans+cnt[c])%mod;
		printf("%d",ans);
		return 0;
	}
	if(k[1]==0&&k[2]==0) dp2(1,0);
	else dp(1,0);
	printf("%d",ans);
	return 0;
}

