#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
	x=0;int f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}
int n,k,x,i=1;
long long sum,g[5000001],mxf,mxg;
void print(long long x){
	if(x>9) print(x/10);
	putchar(48+x%10);
}
int main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	read(n),read(k);
	for(;i<=n;++i){
		read(x);
		sum+=x;
		g[i]=mxf-sum;
		if(i>=k){
			mxg=max(mxg,g[i-k]);
			mxf=max(mxf,mxg+sum);
		}	
	}
	print(mxf);
	return 0;
}
