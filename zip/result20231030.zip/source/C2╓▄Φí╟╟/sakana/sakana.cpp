#include<bits/stdc++.h>
using namespace std;
const int N=5005,INF=2e9;
inline void read(int &x){
	x=0;int f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	x*=f;
}
int n,a[N],f[N],ans=INF;
bool flag;
int main(){
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
	read(n);
	for(int i=1;i<=n;++i) read(a[i]);
	f[0]=f[n+1]=INF;
	f[1]=a[1],f[n]=a[n];
	for(int i=1;i<=n;++i){
		if(i>1&&a[i]<a[1]) continue;
		if(i<n&&a[i]<a[n]) continue;
		flag=1;
		for(int j=2;j<i&&flag;++j){
			f[j]=0;
			if(a[j]<=a[i]) f[j]=max(f[j],min(f[j-1],a[j]));
			if(a[j]+a[j-1]<=a[i]) f[j]=max(f[j],min(f[j-2],a[j]+a[j-1]));
			flag&=(f[j]!=0);
		}
		for(int j=n-1;j>i&&flag;--j){
			f[j]=0;
			if(a[j]<=a[i]) f[j]=max(f[j],min(f[j+1],a[j]));
			if(a[j]+a[j+1]<=a[i]) f[j]=max(f[j],min(f[j+2],a[j]+a[j+1]));
			flag&=(f[j]!=0);
		}
		if(flag) ans=min(ans,a[i]-min(f[i-1],f[i+1]));
	}
	for(int i=1;i<n;++i){
		if(i>1&&a[i]+a[i+1]<a[1]) continue;
		if(i<n-1&&a[i]+a[i+1]<a[n]) continue;
		flag=1;
		for(int j=2;j<i&&flag;++j){
			f[j]=0;
			if(a[j]<=a[i]+a[i+1]) f[j]=max(f[j],min(f[j-1],a[j]));
			if(a[j]+a[j-1]<=a[i]+a[i+1]) f[j]=max(f[j],min(f[j-2],a[j]+a[j-1]));
			flag&=(f[j]!=0);
		}
		for(int j=n-1;j-1>i&&flag;--j){
			f[j]=0;
			if(a[j]<=a[i]+a[i+1]) f[j]=max(f[j],min(f[j+1],a[j]));
			if(a[j]+a[j+1]<=a[i]+a[i+1]) f[j]=max(f[j],min(f[j+2],a[j]+a[j+1]));
			flag&=(f[j]!=0);
		}
		if(flag) ans=min(ans,a[i]+a[i+1]-min(f[i-1],f[i+2]));
	}
	printf("%d",ans);
	return 0;
}
