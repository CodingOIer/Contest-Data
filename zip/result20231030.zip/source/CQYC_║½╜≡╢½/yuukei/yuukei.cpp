#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 210
#define M 100010
#define mod 1000000007
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
int head[N],nxt[N<<1],to[N<<1],t;
il void add(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;
    nxt[++t]=head[v];head[v]=t;to[t]=u;
}
int n,dp[N][M],R,G,B,b[4000010],tot,nfd[N],id,ans,sz[N],mx[N],rt,sum;
bool vis[N];
il int Hash(int i,int j,int k){
    return i*40000+j*200+k;
}
il void dfs(int x,int fa){
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa&&!vis[to[i]]) dfs(to[i],x);
    nfd[++id]=x;
}
char S[N];
il void getrt(int x,int fa){
    sz[x]=1;mx[x]=0;
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa&&!vis[to[i]]){
        getrt(to[i],x);sz[x]+=sz[to[i]];mx[x]=max(mx[x],sz[to[i]]);
    }
    mx[x]=max(mx[x],sum-sz[x]);
    if(mx[rt]>mx[x]) rt=x;
}
il void calc(int x){
    id=0;dfs(x,0);
    // cerr<<x<<" "<<id<<"\n";
    // cerr<<x<<" "<<sz[x]<<"\n";
    for(int i=1;i<=id;++i){
        for(int j=1;j<=tot;++j) dp[i][j]=0;
        int g=nfd[i];
        if(i-1>0) for(int j=0;j<=R;++j) for(int k=0;k<=G;++k) for(int h=0;h<=B;++h){
            int tmp=dp[i-1][b[Hash(j,k,h)]];
            if(S[g]=='r') ++j;
            if(S[g]=='g') ++k;
            if(S[g]=='b') ++h;
            if(j<=R&&k<=G&&h<=B) Add(dp[i][b[Hash(j,k,h)]],tmp);
            if(S[g]=='r') --j;
            if(S[g]=='g') --k;
            if(S[g]=='b') --h;
        }
        // if(g==3) cerr<<S[g]<<" ";
        if(S[g]=='r'&&R>0){
            Add(dp[i][b[Hash(1,0,0)]],1);
            // if(g==3) cerr<<b[Hash(1,0,0)]<<" ";
        }
        if(S[g]=='g'&&G>0) Add(dp[i][b[Hash(0,1,0)]],1);
        if(S[g]=='b'&&B>0) Add(dp[i][b[Hash(0,0,1)]],1);
        if(i-sz[g]>0) for(int j=0;j<=R;++j) for(int k=0;k<=G;++k) for(int h=0;h<=B;++h){
            Add(dp[i][b[Hash(j,k,h)]],dp[i-sz[g]][b[Hash(j,k,h)]]);
        }
    }
    // cerr<<nfd[id]<<" ";
    int res=0;
    for(int j=1;j<=tot;++j){
        Add(ans,dp[id][j]);
        res+=dp[id][j];
    }
    // cout<<x<<" "<<res<<"\n";
}
il void solve(int x){
    // cerr<<x<<" ";
    vis[x]=1;getrt(x,0);calc(x);
    for(int i=head[x];i;i=nxt[i]) if(!vis[to[i]]){
        sum=sz[to[i]];rt=0;
        getrt(to[i],0);
        solve(rt);
    }
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
    sum=n=read();R=read();B=read();G=read();scanf(" %s",S+1);
    for(int i=1;i<n;++i) add(read(),read());
    for(int i=0;i<=R;++i) for(int j=0;j<=G;++j) for(int k=0;k<=B;++k) b[Hash(i,j,k)]=++tot;
    // cerr<<tot<<" ";
    mx[0]=inf;
    getrt(1,0);solve(rt);
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}