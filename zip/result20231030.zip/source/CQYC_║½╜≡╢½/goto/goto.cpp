#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,dp[N],sum[N],K,pre[N];
bool pppp;
signed main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
    n=read();K=read();
    for(int i=1;i<=n;++i) sum[i]=sum[i-1]+read();
    dp[0]=0;pre[0]=0;
    for(int i=1;i<=n;++i){
        if(i-K>=0) dp[i]=pre[i-K]+sum[i];
        dp[i]=max(dp[i],dp[i-1]);
        pre[i]=max(pre[i-1],dp[i]-sum[i]);
    }
    write(dp[n]);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}