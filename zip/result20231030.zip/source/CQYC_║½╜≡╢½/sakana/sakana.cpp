#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 500010
#define inf (int)(1000000000)
using namespace std;
bool ppp;
int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,a[N],dp[N],ans;
vector<int> V;
bool pppp;
signed main(){
	freopen("sakana.in","r",stdin);
	freopen("sakana.out","w",stdout);
    n=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
		V.pk(a[i]);
		if(i!=1) V.pk(a[i]+a[i-1]);
	}
	sort(V.begin(),V.end());
	V.resize(unique(V.begin(),V.end())-V.begin());
	ans=inf;
	int tot=0;
	for(auto v:V){
		dp[0]=0;++tot;
		for(int i=1;i<=n;++i){
			dp[i]=inf;
			if(a[i]>=v) dp[i]=min(dp[i],max(dp[i-1],a[i]));
			if(i!=1&&a[i]+a[i-1]>=v) dp[i]=min(dp[i],max(dp[i-2],a[i]+a[i-1]));
		}
		ans=min(ans,dp[n]-v);
		if(tot*n>250000000) break;
	}
	write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}