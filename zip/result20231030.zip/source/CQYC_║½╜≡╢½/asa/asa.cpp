#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define mod 998244353
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int T,n;
// il void init(){
//     for(int i=2;i<=n;++i) for(int j=i*i,k=2;j<=n;j=j*i,++k) for(int h=1;h*j<=1e6;++h) f[h*j]|=1<<k;
// }
// il bool check(int a,int b){
//     for(int k=2;k<=20;++k){
//         int flag=1;
//         for(int x=1;a*x+b<=1e6&&x<=100;++x){
//             // cerr<<a*x+b<<" "<<k<<"\n";
//             if(f[a*x+b]&(1<<k)) continue;
//             flag=0;break;
//         }
//         if(flag) return 1;
//     }
//     return 0;
// }
vector<int> V;
il void init(){
    for(int i=2;i<=1e6;++i) for(int j=i*i;j<=1e12;j*=i) V.pk(j);
    sort(V.begin(),V.end());
    V.resize(unique(V.begin(),V.end())-V.begin());
}
map<int,int> f;
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
    init();
    T=read();
    while(T--){
        n=read();int ans=0;
        for(auto v:V){
            if(v>n) break;
            Add(f[v],1);
            int tmp=n/v;
            Add(ans,f[v]*tmp*tmp%mod);
            for(int i=2;i*v<=n;){
                int tmp=lower_bound(V.begin(),V.end(),v*i)-V.begin();
                if(tmp==(int)V.size()) break;
                if(V[tmp]==v*i) Del(f[i*v],f[v]);
                i=max(i+1,V[tmp]/v);
            }
        }
        f.clear();
        write(ans);putchar('\n');
    }
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}