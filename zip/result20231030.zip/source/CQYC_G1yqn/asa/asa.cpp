#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int MOD=998244353;
const int MAXN=5010;
int sa[MAXN],pre[MAXN],phi[MAXN],s[MAXN];
bool vis[MAXN];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(long long x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}

signed main()
{
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
	int cnt=0;
	vis[1]=true;
	sa[1]=phi[1]=1;
	for(int i=2;i<MAXN;i++)
	{
		if(!vis[i])
		{
			pre[++cnt]=i;
			phi[i]=i-1;
			sa[i]=1;
		}
		for(int j=1;1ll*i*pre[j]<MAXN&&j<=cnt;j++)
		{
			if(!(i%pre[j]))
			{
				phi[i*pre[j]]=phi[i]*pre[j];
				sa[i*pre[j]]=0;
				vis[i*pre[j]]=true;
				break;
			}
			phi[i*pre[j]]=phi[i]*(pre[j]-1);
			sa[i*pre[j]]=sa[i]*-1;
			vis[i*pre[j]]=true;
		}
	}
	for(int i=1;i<MAXN;i++)
	{
		s[i]=(s[i-1]+phi[i])%MOD;
	}
	int T=read();
	while(T--)
	{
		long long n;
		int ans=0;
		n=read();
		for(int i=1;i<=n;i++)
		{
			if(!sa[i])
			{
				ans=(ans+s[n/i]*2%MOD-1)%MOD;
			}		
		}
		write(ans);
		putchar('\n');
	}
	return 0;
}
