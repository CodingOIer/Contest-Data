#include<bits/stdc++.h>
#define int long long
// #define int __int128
using namespace std;

const int MAXN=5e5+10;
int n;
int a[MAXN],b[MAXN];
int Fly[MAXN];
set<pair<int,int>> Fish;
vector<int> q;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(long long x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}

int Free(int v)
{
    for(int k=1;k<=n;k++)
    {
        Fly[k]=1e18;
    }
    Fly[0]=0;
    for(int k=1;k<=n;k++)
    {
        if(k>1&&a[k]+a[k-1]>=v)
        {
            Fly[k]=min(Fly[k],max(Fly[k-2],a[k-1]+a[k]));
        }
        if(a[k]>=v)
        {
            Fly[k]=min(Fly[k],max(Fly[k-1],a[k]));
        }
    }
    return Fly[n];
}

signed main()
{
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
    {
        a[i]=read();
        q.push_back(a[i]);
        Fish.insert({a[i],i});
    }
    for(int i=1;i<=n;i++)
    {
        q.push_back(a[i]+a[i+1]);
    }
    sort(q.begin(),q.end());
    int ans=1e18;
    for(int v:q)
    {
        int w=Free(v);
        if(~w)
        {
            ans=min(w-v,ans);
        }
        else
        {
            break;
        }
    }
    write(ans);
    putchar('\n');
    return 0;
}
