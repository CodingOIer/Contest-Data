#include<bits/stdc++.h>
// #define int long long
using namespace std;

const int MAXN=5e6+10;
long long s[MAXN],f[MAXN];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(long long x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}

signed main()
{
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	int n=read(),k=read();
	long long cnt=-1e18;
	for(int i=1;i<=n;i++)
	{
		int a=read();
		s[i]=s[i-1]+a;
		if(i>=k)
        {
            cnt=max(f[i-k]-s[i-k],cnt);
        }
		f[i]=max(f[i-1],cnt+s[i]);
	}
	// printf("%lld",f[n]);
    write(f[n]);
    putchar('\n');
	return 0;
}
