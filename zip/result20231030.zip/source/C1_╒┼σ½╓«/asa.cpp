#include <bits/stdc++.h>
#define Mem(Arr, Val) memset(Arr, Val, sizeof(Arr))
#define Rep(i, Begin, End) for (auto i(Begin), _end(End); i != _end; i++)
#define Req(i, Begin, End) for (auto i(Begin), _end(End); i != _end; i--)
#define add_rep(i, Begin, End, Add) for (auto i(Begin), _end(End), _add(Add); i < _end; i += _add)
#define add_req(i, Begin, End, Add) for (auto i(Begin), _end(End), _add(Add); i > _end; i -= _add)
#define mul_rep(i, Begin, End, Mul) for (auto i(Begin), _end(End), _mul(Mul); i < _end; i *= _mul)
#define mul_req(i, Begin, End, Mul) for (auto i(Begin), _end(End), _mul(Mul); i > _end; i /= _mul)
using namespace std;

void Freopen(string _Filename) {
	freopen((_Filename + ".in").c_str(), "r", stdin);
	freopen((_Filename + ".out").c_str(), "w", stdout);
}

template<typename _Tp> void read(_Tp& _x) {
	static char _ch, _f;
	_f = 1;
    while (!isdigit(_ch = fgetc(stdin)))
		if (_ch == 45) _f = -1;
    _x = _ch ^ 48;
    while (isdigit(_ch = fgetc(stdin))) _x = (_x << 3) + (_x << 1) + (_ch ^ 48);
	_x *= _f;
}

template<typename _Tp> void write(_Tp _x, char _end = 10) {
	if (!_x) {printf("0%c", _end); return;}
	if (_x < 0) putchar(45), _x = -_x;
	static char _len;
	static char _ch[55];
	_len = 0;
	mul_req(_num, _x, (_Tp)0, (_Tp)10) _ch[++_len] = _num % 10 ^ 48;
	Req(i, _len, '\0') fputc(_ch[i], stdout);
	fputc(_end, stdout);
}

int T;
long long phi[1000005];

int main() {
	Freopen("asa");
	Rep(i, 2, 1000001) phi[i] = i;
	Rep(i, 2, 1000001)
		if (phi[i] == i)
			add_rep(j, i, 1000001, i)
				phi[j] = phi[i] / i * (i - 1);
	Rep(i, 2, 1000001) phi[i] += phi[i - 1];
	read(T);
	while (T--) {
		static int n;
		static long long ans;
		read(n); ans = 0;
		for (int i = 2; i * i <= n; i++) ans += (phi[n / (i * i)] << 1) + 1;
		for (int i = 2; i * i * i <= n; i++) ans += (phi[n / (i * i * i)] << 1) + 1;
		write(ans);
	}
	return 0;
}
