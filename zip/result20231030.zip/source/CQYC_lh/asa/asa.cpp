#include<bits/stdc++.h>
using namespace std;
const int maxn=1e7+2;
int cnt;
int pri[maxn];
int mob[maxn];
bool vis[maxn];
void Euler(){
    mob[1]=1;
    for(int i=2;i<=1e7;i++){
        if(!vis[i])pri[++cnt]=i,mob[i]=-1;
        for(int j=1;j<=cnt&&pri[j]*i<=1e7;j++){
            vis[pri[j]*i]=1;
            if(i%pri[j]==0)mob[i*pri[j]]=0;
            else mob[i*pri[j]]=mob[i]*mob[pri[j]];
        }
    }
    return ;
}
int gcd(int a,int b){
    if(!b)return a;
    return gcd(b,a%b);
}
bool check(int a,int b){
    if(mob[gcd(a,b)]==0)return 1;
    return 0;
}
int solve(long long n){
    int ans=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(check(i,j))ans++;
        }
    }
    return ans;
}
int main(){
    freopen("asa.in","r",stdin);
    freopen("asa.out","w",stdout);
    int T;
    Euler();
    scanf("%d",&T);
    while(T--){
        long long n;
        scanf("%lld",&n);
        printf("%d\n",solve(n));
    }
    // for(int i=1;i<=10;i++)printf("%d\n",solve(i));
    return 0;
}