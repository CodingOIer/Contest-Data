#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e2+7,maxk=63;
const int mod=1e9+7;
int n,lim[3];
int cnt,idx;
char s[maxn];
int hed[maxn],co[maxn],siz[maxn],nsz[maxn],maxson[maxn],dfn[maxn],idfn[maxn];
// int o[maxk][maxk][maxk][maxk];
vector<vector<vector<int>>>o[maxn];
int ans;
bool vis[maxn];
int sum1,sum2,sum3;
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
struct node_edge{
    int nxt,to;
}G[maxn*2];
void add(int u,int v){
    G[++cnt]=(node_edge){hed[u],v};
    hed[u]=cnt;
    return ;
}
int find_root(int x,int fa,int rt,int all){
    siz[x]=1,maxson[x]=0;
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==fa||vis[v])continue;
        rt=find_root(v,x,rt,all);
        siz[x]+=siz[v];
        maxson[x]=max(maxson[x],siz[v]);
    }
    maxson[x]=max(maxson[x],all-siz[x]);
    if(!rt||maxson[x]<maxson[rt])rt=x;
    return rt;
}
void dfs(int x,int fa){
    dfn[x]=++idx;
    idfn[idx]=x,nsz[x]=1;
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==fa||vis[v])continue;
        dfs(v,x);
        nsz[x]+=nsz[v];
    }
    return ;
}
void DP(){
    for(int i=0;i<=idx+1;i++){
        for(int j=0;j<=min(idx,lim[0])+1;j++){
            for(int k=0;k<=min(idx,lim[1])+1;k++){
                for(int p=0;p<=min(idx,lim[2])+1;p++)o[i][j][k][p]=0;
            }
        }
    }
    // for(int i=0;i<=idx+1;i++){
    //     h[i]=0;
    //     for(int j=0;j<=idx+1;j++){
    //         for(int ty=0;ty<3;ty++)f[i][j][ty]=0;
    //         for(int k=0;k<=idx+1;k++){
    //             for(int ty=0;ty<3;ty++)g[i][j][k][ty]=0;
    //         }
    //     }
    // }
    // h[1]=1;
    // for(int ty=0;ty<3;ty++)f[1][0][ty]=1,g[1][0][0][ty]=1;
    // for(int i=1;i<=idx;i++){
    //     upd(h[i+1],h[i]);
    //     upd(h[i+nsz[idfn[i]]],h[i]);
    //     for(int ty=0;ty<3;ty++){
    //         for(int j=0;j<=min(i,lim[ty]);j++){
    //             upd(f[i+1][j+(ty==co[idfn[i]])][ty],f[i][j][ty]);
    //             upd(f[i+nsz[idfn[i]]][j][ty],f[i][j][ty]);
    //             for(int k=0;k<=min(i,lim[(ty+1)%3]);k++){
    //                 upd(g[i+1][j+(ty==co[idfn[i]])][k+((ty+1)%3==co[idfn[i]])][ty],g[i][j][k][ty]);
    //                 upd(g[i+nsz[idfn[i]]][j][k][ty],g[i][j][k][ty]);
    //             }
    //         }
    //     }
    // }
    o[1][0][0][0]=1;
    for(int i=1;i<=idx;i++){
        for(int j=0;j<=min(idx,lim[0]);j++){
            for(int k=0;k<=min(idx,lim[1]);k++){
                for(int p=0;p<=min(idx,lim[2]);p++){
                    // printf("idfn[%d]=%d %d %d %d\n",i,idfn[i],(co[idfn[i]]==0),(co[idfn[i]]==1),(co[idfn[i]]==2));
                    upd(o[i+1][j+(co[idfn[i]]==0)][k+(co[idfn[i]]==1)][p+(co[idfn[i]]==2)],o[i][j][k][p]);
                    upd(o[i+nsz[idfn[i]]][j][k][p],o[i][j][k][p]);
                }
            }
        }
    }
    return ;
}
void calc(int x){
    idx=0;
    dfs(x,0);
    DP();
    // upd(ans,h[idx+1]);
    // upd(sum1,h[idx+1]);
    // for(int ty=0;ty<3;ty++){
    //     for(int j=0;j<=lim[ty];j++){
    //         upd(ans,mod-f[idx+1][j][ty]);
    //         upd(sum2,f[idx+1][j][ty]);
    //         for(int k=0;k<=lim[(ty+1)%3];k++){
    //             upd(ans,g[idx+1][j][k][ty]);
    //             upd(sum3,g[idx+1][j][k][ty]);
    //         }
    //     }
    // }
    for(int i=0;i<=min(idx,lim[0]);i++){
        for(int j=0;j<=min(idx,lim[1]);j++){
            for(int k=0;k<=min(idx,lim[2]);k++){
                upd(ans,o[idx+1][i][j][k]);
                // if(o[idx+1][i][j][k])printf("o[%d][%d][%d]= %d\n",i,j,k,o[idx+1][i][j][k]);
            }
        }
    }
    upd(ans,mod-1);
    // if(x==3)printf("%d %d %d\n",sum1,sum2,sum3);
    return ;
}
void solve(int x,int all){
    // printf("solve %d %d\n",x);
    calc(x);
    vis[x]=1;
    for(int i=hed[x],v,nall,nrt;i;i=G[i].nxt){
        v=G[i].to;
        if(vis[v])continue;
        nall=((siz[x]>=siz[v])?siz[v]:(all-siz[x]));
        nrt=find_root(v,x,0,nall);
        solve(nrt,nall);
    }
    return ;
}
int main(){
    freopen("yuukei.in","r",stdin);
    freopen("yuukei.out","w",stdout);
    n=read();
    for(int i=0;i<3;i++)lim[i]=read();
    scanf("%s",s+1);
    for(int i=1;i<=n;i++)co[i]=((s[i]=='r')?0:((s[i]=='b')?1:2));
    // printf("co:\n");
    // for(int i=1;i<=n;i++)printf("%d",co[i]);
    // printf("\n");
    // printf("%d %d %d\n",lim[0],lim[1],lim[2]);
    for(int i=0;i<=n+2;i++){
        o[i].resize(lim[0]+2);
        for(int j=0;j<lim[0]+2;j++){
            o[i][j].resize(lim[1]+2);
            for(int k=0;k<lim[1]+2;k++){
                o[i][j][k].resize(lim[2]+2);
            }
        }
    }
    // printf("boom\n");
    for(int i=1,u,v;i<n;i++){
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    int rt=find_root(1,0,0,n);
    solve(rt,n);
    printf("%d\n",ans);
    // printf("%d %d %d\n",sum1,sum2,sum3);
    return 0;
}