#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=5e6+2;
int n,K;
long long ar[maxn];
long long sum[maxn],mx1[maxn],mx2[maxn];
int main(){
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    n=read(),K=read();
    for(int i=1;i<=n;i++)ar[i]=read(),sum[i]=sum[i-1]+ar[i];
    for(int i=1;i<=n;i++){
        if(i-K>=0)mx1[i]=sum[i]+mx2[i-K];
        mx1[i]=max(mx1[i],mx1[i-1]);
        mx2[i]=mx1[i]-sum[i];
        mx2[i]=max(mx2[i],mx2[i-1]);
    }
    printf("%lld\n",mx1[n]);
    return 0;
}