#include<bits/stdc++.h>
using namespace std;
const int N=210,mod=1e9+7;
int n,R,B,G,ans,num[3],c[N][N];
char a[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
void pre()
{
    for(int i=0;i<N;i++)
    {
        c[i][0]=1;
        for(int j=1;j<N;j++) c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
    }
}
int main()
{
    freopen("yuukei.in","r",stdin);
    freopen("yuukei.out","w",stdout);
    pre();
    scanf("%d%d%d%d%s",&n,&R,&B,&G,a+1);
    for(int i=1;i<=n;i++)
        if(a[i]=='r') ++num[0];
        else if(a[i]=='b') ++num[1];
        else ++num[2];
    if(a[1]=='r')
        for(int i=0;i<min(R,num[0]);i++)
            for(int j=0;j<=min(B,num[1]);j++)
                for(int k=0;k<=min(G,num[2]);k++)
                    upd(ans,1ll*c[num[0]-1][i]*c[num[1]][j]%mod*c[num[2]][k]%mod);
    else if(a[1]=='b')
        for(int i=0;i<=min(R,num[0]);i++)
            for(int j=0;j<min(B,num[1]);j++)
                for(int k=0;k<=min(G,num[2]);k++)
                    upd(ans,1ll*c[num[0]][i]*c[num[1]-1][j]%mod*c[num[2]][k]%mod);
    else
        for(int i=0;i<=min(R,num[0]);i++)
            for(int j=0;j<=min(B,num[1]);j++)
                for(int k=0;k<min(G,num[2]);k++)
                    upd(ans,1ll*c[num[0]][i]*c[num[1]][j]%mod*c[num[2]-1][k]%mod);
    if(R) upd(ans,num[0]-(a[1]=='r'));
    if(B) upd(ans,num[1]-(a[1]=='b'));
    if(G) upd(ans,num[2]-(a[1]=='g'));
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
