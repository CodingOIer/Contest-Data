#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline int read()
{
    int x=0;bool f=0;
    char ch=getchar();
    while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return f?-x:x;
}
const int N=5e6+10;
int n,k;
ll Mx,dp[N],tot[N];
inline void Max(ll &x,ll y) {x=x>y?x:y;}
int main()
{
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    n=read(),k=read();
    for(int i=1,x;i<=n;i++)
    {
        x=read();
        dp[i]=dp[i-1];
        Mx+=x;tot[i]=tot[i-1]+x;
        if(i>=k) Max(Mx,dp[i-k]+tot[i]-tot[i-k]),Max(dp[i],Mx);
    }
    printf("%lld\n",dp[n]);
    fclose(stdin);fclose(stdout);
    return 0;
}
