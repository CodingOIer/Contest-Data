#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=5e5+10;
struct ok{
    int x,id1,id2;
    bool operator <(const ok &A) const{return x<A.x;}
}b[N];
int n,T,ans=INT_MAX,cnt,a[N];
int num[N];
inline void Min(int &x,int y) {x=x>y?y:x;}
int main()
{
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n=cnt=read();
    for(int i=1;i<=n;i++)
        a[i]=read(),b[i]=(ok){a[i],i,0};
    for(int i=1;i<n;i++)
        b[++cnt]=(ok){a[i]+a[i+1],i,i+1};
    sort(b+1,b+cnt+1);
    for(int i=cnt,Mx=cnt;i;i--)
    {
        T+=!num[b[i].id1]++;
        if(b[i].id2) T+=!num[b[i].id2]++;
        while(num[b[Mx].id1]>1&&num[b[Mx].id2]>1)
            --num[b[Mx].id1],--num[b[Mx].id2],--Mx;
        if(T==n) Min(ans,b[Mx].x-b[i].x);
    }
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
