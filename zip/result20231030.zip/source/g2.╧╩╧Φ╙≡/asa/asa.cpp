#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e6+10,mod=998244353;
int T,ans,cnt,sum[N];
bool vis[N];
ll n,a[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int main()
{
    freopen("asa.in","r",stdin);
    freopen("asa.out","w",stdout);
    for(int i=2;i<N;i++)
    {
        ll x=i;
        while(1)
        {
            x*=i;
            if(x>1e12) break;
            a[++cnt]=x;
        }
    }
    sort(a+1,a+cnt+1);
    cnt=unique(a+1,a+cnt+1)-a-1;
    for(int i=1;i<=cnt;i++)
        if(a[i]<N) vis[a[i]]=1;
    scanf("%d",&T);
    while(T--)
    {
        ans=0;
        scanf("%lld",&n);
        for(int i=n;i;i--)
        {
            if(!vis[i]) continue;
            sum[i]=1ll*(n/i)*(n/i)%mod;
            for(int j=i+i;j<=n;j+=i) upd(sum[i],mod-sum[j]);
            upd(ans,sum[i]);
        }
        for(int i=1;i<=n;i++) sum[i]=0;
        printf("%d\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
