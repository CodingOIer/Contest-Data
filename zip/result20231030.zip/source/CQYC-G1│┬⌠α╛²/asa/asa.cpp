#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e6+5,mod=998244353;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int t,n,ans,pr[N],cnt,vst[N],mu[N];
void sieve(int n){
    mu[1]=1;
    for(int i=2;i<=n;i++){
        if(!vst[i]) pr[++cnt]=i,mu[i]=-1;
        for(int j=1;j<=cnt&&i*pr[j]<=n;j++){
            vst[i*pr[j]]=1;
            if(i%pr[j]==0){
                mu[i*pr[j]]=0;
                break;
            }
            mu[i*pr[j]]=-mu[i];
        }
    }
}
int solve(){
    ans=0;
    n=read();
    for(int x=2;x*x<=n;x++){
        if(!mu[x]) continue;
        // cout<<x<<" "<<ph(x)<<" "<<x*x<<" "<<n/(x*x)<<" "<<(n/(x*x))*(n/(x*x))<<"\n";
        __int128 xx=-1;
        ans=(ans+xx*mu[x]*(n/(x*x))*(n/(x*x))%mod+mod)%mod;
    }
    return ans;
    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<=n;j++){
    //         for(int k=2;k*k<=min(i,j);k++){
    //             if(i%(k*k)==0&&j%(k*k)==0){
    //                 cout<<i<<" "<<j<<"\n";
    //                 ans++;
    //                 break;
    //             }
    //         }
    //     }
    // }
    // cout<<ans<<" ";
}
signed main(){
	freopen("asa.in","r",stdin);
	freopen("asa.out","w",stdout);
    sieve(1e6);
    t=read();
    while(t--) cout<<solve()<<"\n";
    return 0;
}