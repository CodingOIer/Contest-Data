#include<bits/stdc++.h>
#define int long long
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
	while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
	return x*f;
}
const int N=5e6+4,inf=1e18;
int n,k,a[N],s[N],f[N],ans=-inf;
signed main(){
	freopen("goto.in","r",stdin);
	freopen("goto.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++){
		s[i]=s[i-1]+a[i];
		if(i>=k) ans=max(ans,f[i-k]-s[i-k]);
		f[i]=max(f[i-1],ans+s[i]);
	}
	cout<<f[n]<<"\n";
	return 0;
}
