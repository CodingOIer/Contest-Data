#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=5e5+5,inf=1e9;
int n,a[N],dp[N],ans=inf,maxx,cnt,x[N],op[N];
pair<int,pair<int,int> > solve(int l){
    memset(dp,0,sizeof(dp));
    memset(x,0,sizeof(x));
    memset(op,0,sizeof(op));
    dp[0]=inf;
    for(int i=0;i<n;i++){
        if(dp[i+1]<min(dp[i],a[i+1])){
            if(dp[i]<a[i+1]) x[i+1]=x[i],op[i+1]=op[i];
            else x[i+1]=i+1,op[i+1]=0;
        }
        dp[i+1]=max(dp[i+1],min(dp[i],a[i+1]));
        if(i+2<=n&&a[i+1]+a[i+2]<=l){
            if(dp[i+1]<min(dp[i],(a[i+1]+a[i+2]))){
                if(dp[i]<(a[i+1]+a[i+2])) x[i+2]=x[i],op[i+2]=op[i];
                else x[i+2]=i+1,op[i+2]=1;
            }
            dp[i+2]=max(dp[i+2],min(dp[i],(a[i+1]+a[i+2])));
        }
    }
    return {dp[n],{x[n],op[n]}};
}
struct name{
    int x,id;
}b[N];
int t[N];
namespace bl{
    #include <bits/stdc++.h>
    using namespace std;
    char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
    #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
    inline int read(){
        int x=0,f=1;char ch=getchar();
        while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
        while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
        return x*f;
    }
    const int N=5e5+5,inf=1e9;
    int dp[N],ans,maxx;
    int solve(int l){
        memset(dp,0,sizeof(dp));
        dp[0]=inf;
        for(int i=0;i<n;i++){
            dp[i+1]=max(dp[i+1],min(dp[i],a[i+1]));
            if(i+2<=n&&a[i+1]+a[i+2]<=l) dp[i+2]=max(dp[i+2],min(dp[i],(a[i+1]+a[i+2])));
        }
        return l-dp[n];
    }
    int main(){
        for(int i=1;i<=n;i++) maxx=max(maxx,a[i]);
        ans=solve(maxx);
        for(int i=1;i<n;i++){
            if(a[i]+a[i+1]>maxx) ans=min(ans,solve(a[i]+a[i+1]));
        }
        cout<<ans;
        return 0;
    }
}
int main(){
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i]=read(),maxx=max(maxx,a[i]);
    if(n*maxx<=1e7){
        bl::main();
        return 0;
    }
    b[++cnt]={maxx,0};
    for(int i=1;i<n;i++){
       if(a[i]+a[i+1]>maxx) b[++cnt]={a[i]+a[i+1],i};
    }
    sort(b+1,b+cnt+1,[](name a,name b){return a.x<b.x;});
    for(int i=1;i<=cnt;i++){
        t[b[i].id]=i;
    }
    for(int i=1;i<=cnt;i++){
        pair<int,pair<int,int> > x=solve(b[i].x);
        ans=min(ans,b[i].x-x.first);
        int pos=t[x.second.first],pos1=t[x.second.first-1],pos2=t[x.second.first+1];
        // cout<<i<<" "<<b[i].x<<" "<<b[i].id<<" "<<x.first<<" "<<x.second.first<<" "<<x.second.second<<" "<<pos<<" "<<pos1<<"\n";
        // Sleep(1000);
        if(pos==1){
            if(x.second.second==1) break;
            else continue;
        }
        else if(x.second.second==1){
            if(b[max(pos1,pos2)].x<=b[i].x) break;
            else if(b[min(pos1,pos2)].x<=b[i].x) i=max(pos1,pos2)-1;
            else i=min(pos1,pos2)-1;
        }
        else{
            if(min(pos,pos1)<=i){
                if(max(pos,pos1)<=i) break;
                else i=max(pos,pos1)-1;
            }
            else i=min(pos,pos1)-1;
        }
    }
    cout<<ans;
    return 0;
}