#include<bits/stdc++.h>
using namespace std;
signed main(){
	freopen("yuukei.in","r",stdin);
	freopen("yuukei.out","w",stdout);
    
	return 0;
}
