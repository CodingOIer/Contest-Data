#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=5e5+10,INF=1e18;
int N,A[Maxn],Ans=INF;
bool Vis[Maxn];

void DFS(int x,int Mn,int Mx){
    if(x>N) return Ans=min(Ans,Mx-Mn),void();
    if(Vis[x]) DFS(x+1,Mn,Mx);
    else{
        Vis[x+1]=1; DFS(x+1,min(Mn,A[x]+A[x+1]),max(Mx,A[x]+A[x+1]));
        Vis[x+1]=0; DFS(x+1,min(Mn,A[x]),max(Mx,A[x]));
    }
}

signed main(){
    freopen("sakana.in","r",stdin);
    freopen("sakana.out","w",stdout);
    N=read(); For(i,1,N) A[i]=read();
    DFS(1,INF,0); write(Ans);
    return 0;
}
/*
g++ sakana.cpp -o sakana -O2
./sakana
*/