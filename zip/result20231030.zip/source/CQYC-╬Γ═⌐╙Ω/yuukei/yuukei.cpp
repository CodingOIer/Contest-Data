#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=210,P=1e9+7;
int N,tr,tb,tg,hed[Maxn],cnt,Ans,r,b,g;
int fac[Maxn],inv[Maxn];
char S[Maxn];
struct node{int nxt,to;}G[Maxn<<1];
bool Vis[Maxn],Get[Maxn],flag;

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void DFS1(int x){
    if(S[x]=='r') ++r;
    if(S[x]=='b') ++b;
    if(S[x]=='g') ++g;
    if(r>tr||b>tb||g>tg) return;
    Get[x]=1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if(Get[y=G[i].to]||!Vis[y]) continue;
        DFS1(y);
    }
}

bool check(){
    bool f=0;
    For(i,1,N) Get[i]=0;
    For(i,1,N) if(Vis[i]&&!Get[i]){
        if(f) return 0;
        f=1,r=0,b=0,g=0,DFS1(i);
        if(r>tr||b>tb||g>tg) return 0;
    }
    if(!f) return 0;
    return 1;
}

void DFS(int x){
    if(x>N){
        if(check()) ++Ans;
        return;
    }
    Vis[x]=1; DFS(x+1); Vis[x]=0; DFS(x+1);
}

void Solve0(){ DFS(1),write(Ans); }

int Power(int x,int d,int r=1){
    while(d){if(d&1) (r*=x)%=P; (x*=x)%=P,d>>=1;}
    return r;
}

int C(int n,int m){
    if(n<0||m<0||n<m) return 0;
    return fac[n]*inv[m]%P*inv[n-m]%P;
}

void Solve1(){
    fac[0]=1; For(i,1,N) fac[i]=fac[i-1]*i%P;
    inv[N]=Power(fac[N],P-2);
    Rof(i,N-1,0) inv[i]=inv[i+1]*(i+1)%P;
    int nr=0,nb=0,ng=0;
    For(i,2,N){
        if(S[i]=='r') ++nr,Ans+=(nr>0);
        if(S[i]=='b') ++nb,Ans+=(nb>0);
        if(S[i]=='g') ++ng,Ans+=(ng>0);
    }
    if(S[1]=='r') --tr;
    if(S[1]=='b') --tb;
    if(S[1]=='g') --tg;
    if(tr<0||tb<0||tg<0) write(Ans),exit(0);
    For(i,0,min(tr,nr)) For(j,0,min(tb,nb)) For(k,0,min(tg,ng))
        (Ans+=C(nr,i)*C(nb,j)%P*C(ng,k)%P)%=P;
    write(Ans);
}

signed main(){
    freopen("yuukei.in","r",stdin);
    freopen("yuukei.out","w",stdout);
    N=read(),tr=read(),tb=read(),tg=read(); scanf("%s",S+1);
    For(i,1,N-1){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
        if(u!=1&&v!=1) flag=1;
    }
    if(!flag) Solve1(),exit(0);
    Solve0();
    return 0;
}
/*
g++ yuukei.cpp -o yuukei -O2
./yuukei
*/