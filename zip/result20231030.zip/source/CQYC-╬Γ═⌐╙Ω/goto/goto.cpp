#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=5e6+10,INF=1e18;
int N,K,A[Maxn],R[Maxn],Ans,f[Maxn],g[Maxn],Sum[Maxn],stk[Maxn];
vector<int> V[Maxn];
bool Vis[Maxn];

void DFS(int x){
    if(x>N){
        int ret=0;
        for(int i=1;i<=N;++i)if(Vis[i]){
            int j=i; ret+=A[i];
            while(j<N&&Vis[j+1]) ret+=A[++j];
            if(j-i+1<K) return;
            i=j;
        }
        Ans=max(Ans,ret);
        return;
    }
    Vis[x]=1; DFS(x+1); Vis[x]=0; DFS(x+1);
}

signed main(){
    freopen("goto.in","r",stdin);
    freopen("goto.out","w",stdout);
    N=read(),K=read(); For(i,1,N) A[i]=read();
    if(N<=1000){
        For(i,1,N) Sum[i]=Sum[i-1]+A[i];
        For(i,1,N){
            Rof(j,i-K+1,1) f[i]=max(f[i],g[j-1]+Sum[i]-Sum[j-1]);
            g[i]=max(g[i-1],f[i]);
        }
        write(g[N]),exit(0);
    }

    int r=0;
    For(i,1,N) Sum[i]=Sum[i-1]+A[i];
    For(i,1,N){
        if(i>=K){
            int t=g[i-K]-Sum[i-K];
            while(r&&t>stk[r]) --r;
            stk[++r]=t;
        }
        f[i]=stk[1]+Sum[i],g[i]=max(g[i-1],f[i]);
    }
    write(g[N]),exit(0);

    return 0;
}
/*
g++ goto.cpp -o goto -O2 -Wall
./goto
*/