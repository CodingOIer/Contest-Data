#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 210, M = 110;

struct node {
    int a, b, c, x;
    node operator + (const node &p) const {
        return { a + p.a, b + p.b, c + p.c, 1ll * x * p.x % mod };
    }
};

int n, ans;
int lim[3], a[N], g[N][N][N];

char s[N];

vector<int> e[N];

vector<node> f[N];

void dfs(int x, int fa) {
    if(a[x] == 0) f[x].push_back({ 1, 0, 0, 1 });
    if(a[x] == 1) f[x].push_back({ 0, 1, 0, 1 });
    if(a[x] == 2) f[x].push_back({ 0, 0, 1, 1 });

    for(int v : e[x]) if(v ^ fa) {
        dfs(v, x);
        for(node l : f[x]) {
            inc(g[l.a][l.b][l.c], l.x);
            for(node r : f[v]) {
                r = l + r;
                if(r.a > lim[0] or r.b > lim[1] or r.c > lim[2]) continue;
                inc(g[r.a][r.b][r.c], r.x);
            }
        }
        f[v].clear(), f[x].clear();
        for(int i = 0; i <= lim[0]; i++)
            for(int j = 0; j <= lim[1]; j++)
                for(int k = 0; k <= lim[2]; k++) if(g[i][j][k])
                    f[x].push_back({ i, j, k, g[i][j][k] }), g[i][j][k] = 0;
    }
    for(node l : f[x]) inc(ans, l.x);
}

bool edmer;
signed main() {
	freopen("yuukei.in", "r", stdin);
	freopen("yuukei.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), lim[0] = read(), lim[2] = read(), lim[1] = read();

    scanf("%s", s + 1);

    for(int i = 1; i <= n; i++) {
        if(s[i] == 'g') a[i] = 1;
        if(s[i] == 'b') a[i] = 2;
    }

    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    dfs(1, 0);

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 