#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 5e5 + 10, inf = 1e9;

int n, cnt, ans = inf;
int a[N], b[N], f[N];

int work(int x) {
    f[0] = x;
    for(int i = 1; i <= n; i++) {
        f[i] = min(f[i - 1], a[i]);
        if(i - 1 and a[i] + a[i - 1] <= x) Max(f[i], min(f[i - 2], a[i] + a[i - 1]));
    }
    return x - f[n];
}

bool edmer;
signed main() {
	freopen("sakana.in", "r", stdin);
	freopen("sakana.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(); int mx = 0;
    for(int i = 1; i <= n; i++) Max(mx, a[i] = read());

    for(int i = 2; i <= n; i++) b[++cnt] = a[i] + a[i - 1];
    b[++cnt] = mx, sort(b + 1, b + cnt + 1), cnt = unique(b + 1, b + cnt + 1) - b - 1;

    for(int i = 1; i <= cnt; i++) if(b[i] >= mx) Min(ans, work(b[i]));

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 