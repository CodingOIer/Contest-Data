#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 5e5 + 10, inf = 2e9;

struct node {
    int x, w;
    bool operator < (const node &p) const { return w < p.w; }
};

int n, cnt, ans = inf;
int a[N], b[N], f[N], g[N];

set<node> s;

bool vis[N];

void work(int id) {
    if(vis[id]) return;
    int x = b[id]; f[0] = x;
    for(int i = 1; i <= n; i++) {
        f[i] = min(f[i - 1], a[i]);
        if(i - 1 and a[i] + a[i - 1] <= x) Max(f[i], min(f[i - 2], a[i] + a[i - 1]));
    }
    vis[id] = 1, g[id] = f[n], s.insert({ id, f[n] });
}

bool edmer;
signed main() {
	freopen("sakana.in", "r", stdin);
	freopen("sakana.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(); int mx = 0;
    for(int i = 1; i <= n; i++) Max(mx, a[i] = read());

    for(int i = 2; i <= n; i++) b[++cnt] = a[i] + a[i - 1];
    b[++cnt] = mx, sort(b + 1, b + cnt + 1), cnt = unique(b + 1, b + cnt + 1) - b - 1;
    
    s.insert({ cnt + 1, inf });

    int now = 1;
    while(b[now] < mx) now++;

    while(now <= cnt) {
        work(now); 
        int l = now + 1, r = s.upper_bound({ now, g[now] }) -> x - 1, res = now;
        while(l <= r) {
            int mid = (l + r) >> 1; work(mid);
            if(g[mid] == g[now]) res = mid, l = mid + 1;
            else r = mid - 1;
        }
        Min(ans, b[now] - g[now]), now = res + 1;
    }

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 