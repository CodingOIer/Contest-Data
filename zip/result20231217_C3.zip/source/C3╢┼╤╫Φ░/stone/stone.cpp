/*
Dr.Stone
石神千空祝我这道题不挂。
*/
#include<bits/stdc++.h>
using namespace std;
int n,vis[200005],ma[200005],f[200005];
void dfs(int x) {
    if(x==n+1) {
        printf("YES\n");
        for(int i=1;i<=n;i++) {
            printf("%d %d\n",i,f[i]);
        }
        exit(0);
    }
    for(int i=1;i<=n;i++) {
        int to=abs(i-x);
        if(!vis[i]) {
            if(!ma[to]) {
                ma[to]++;
                vis[i]++;
                f[x]=i;
                dfs(x+1);
                ma[to]--;
                vis[i]--;
            }
        }
    }
}
int main() {
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    scanf("%d",&n);
    if(n%4!=0 && (n-1)%4!=0) {
        printf("NO");
        return 0;
    }
    dfs(1);
    printf("NO");
    return 0;
}
/*
1 2
2 9
3 1
4 8
5 
6 7
7 
8 
9 


*/