#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int a[200005];
int check(int x,int l,int r) {
    int cnt=0,sum=0;
    for(int i=l;i<=r;i++) {
        if(a[i]<x) cnt+=(sum>0),sum=0;
        else sum++;
    }
    if(sum) cnt++;
    return cnt;
}
int main() {
    freopen("spring.in","r",stdin);
    freopen("spring.out","w",stdout);
    scanf("%d %d %d",&n,&m,&k);
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    while(m--) {
        int L,R,flag=1;
        scanf("%d %d",&L,&R);
        for(int i=n;i>=1;i--) {
            if(check(i,L,R)>=k) {
                printf("%d\n",i);
                flag=0;
                break;
            }
        }
        if(flag) {
            printf("-1\n");
        }
    }
    return 0;
}
/*
1 2
2 9
3 1
4 8
5 
6 7
7 
8 
9 


*/