#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int ksm(int x,int y) {
    int ans=1;
    while(y) {
        if(y&1) ans=(ans*x)%mod;
        x=(x*x)%mod;
        y>>=1;
    }
    return ans;

}
signed main() {
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    int n,k,v;
    scanf("%lld %lld %lld",&n,&k,&v);
    for(int i=1;i<=k;i++) {
        int x;
        scanf("%lld",&x);
    }
    cout<<(k)*ksm(v,n)%mod;
    return 0;
}