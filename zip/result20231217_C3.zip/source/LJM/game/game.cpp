#include<bits/stdc++.h>
#define int long long
#define mod 998244353
#define N 1000006
using namespace std;
int read() {
	int x = 0, f = 1; char ch = getchar();
	while(ch < '0' || ch > '9') { if(ch == '-') f = -1; ch = getchar(); }
	while(ch >= '0' && ch <= '9') { x = x * 10 + ch - '0'; ch = getchar(); }
	return x * f;
}
void write(int x) {
	if(x < 0) putchar('-'), x = -x;
	if(x > 9) write(x / 10);
	putchar('0' + x % 10);
}
int Pow(int a, int n) {
	if(n == 0) return 1;
	if(n == 1) return a;
	int x = Pow(a, n / 2);
	if(n % 2 == 0) return x * x % mod;
	else return x * x % mod * a % mod;
}
int n, k, v;
int len[7];
map<int, map<int, int>>p[7];
int f[N], lst[N], sum[N];
int Get(int L, int R) {
	if(L == 0) return sum[R];
	return (sum[R] - sum[L - 1] + mod) % mod;
}
void Sub2() {
    lst[0] = 1;
	for(int i = 1; i <= k; i++)	{
		sum[0] = lst[0];
		for(int j = 1; j <= n * k; j++) sum[j] = (sum[j - 1] + lst[j]) % mod;
		for(int j = 0; j <= n * k; j++) f[j] = 0;
		for(int M = 1; M <= n * k; M++) { //f[m] += lst[M - x] + ... + lst[M-1] 
		    int x = min(n, M);
		    f[M] += Get(M - x, M - 1);
		    f[M] %= mod; 
			/*for(int j = 1; j <= min(n, M); j++) {
				f[M] += lst[M - j];
				f[M] %= mod;
			}*/
		}
		for(int j = 0; j <= n * k; j++) lst[j] = f[j];
	}
	int res = 0;
	for(int i = 1; i <= n * k; i++) {
		res = (res + f[i] * Pow(v, i) % mod) % mod;
	}
	write(res);
	exit(0);
}
int A[100], B[100];
vector<int>G[100];
void dfs2(int x) {
	if(x == k + 1) {
		int dif = 0, Get = 0;
		for(int i = 1; i <= k; i++) {
			if(A[i] != B[i]) dif++, Get = i;
			if(dif > 1) return;
		}
		if(dif == 0) return;
		if(p[dif][A[Get] + 1][B[Get] + 1]) {
			//cout
			int aa = 0, bb = 0;
			for(int i = 1; i <= k; i++) {
				aa = aa * n + A[i];
				bb = bb * n + B[i];
			}
			G[aa].push_back(bb);
			G[bb].push_back(aa);
			
			//cout << aa << " -> " << bb << endl;
		}
		return;
	}
	for(int i = 0; i < n; i++) {
		B[x] = i;
		dfs2(x + 1);
	}
}
int Minn = 1e18, Maxx = 0;
void dfs1(int x) {
	if(x == k + 1) {
		dfs2(1);
		int z = 0;
		for(int i = 1; i <= k; i++) {
			z = z * n + A[i];
		}
		Minn = min(Minn, z);
		Maxx = max(Maxx, z); 
		//cout << z << endl;
		return;
	}
	for(int i = 0; i < n; i++) {
		A[x] = i;
		dfs1(x + 1);
	}
}
int uu[100];
int b[100];
__int128 ans;
void dfs3(int x) {
	if(x > Maxx) {
		for(int i = Minn; i <= Maxx; i++) {
			if(!uu[i]) continue;
			for(auto y : G[i]) {
				if(uu[y]) return;
			}
		}
	    __int128 NN = 0;
		for(int i = Minn; i <= Maxx; i++) {
			if(!uu[i]) continue;
			int hh = i, len = 0;
			while(hh) {
				b[++len] = hh % n;
				hh /= n;
			}
			int sum = 0;
			for(int i = len; i >= 1; i--) sum += (b[i] + 1);
			//cout << "e" << len << endl;
			NN += Pow(v, sum);
		}
		ans = max(ans, NN);
		return;
	}
	uu[x] = 0;
	dfs3(x + 1);
	uu[x] = 1;
	dfs3(x + 1);
}
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n = read(), k = read(), v = read();
	bool flag = 1;
	for(int i = 1; i <= k; i++) {
		len[i] = read();
		if(len[i]) flag = 0;
		for(int j = 1, u, v; j <= len[i]; j++) {
			u = read(), v = read();
			p[i][u][v] = p[i][v][u] = 1;
		}
	}
	if(flag) Sub2();
	dfs1(1);
	//cout << Minn << " " << Maxx << endl;
	dfs3(0);
	write(ans % mod);
	return 0;
}
/*
2 3 2
0
0
0
*/















