#include<bits/stdc++.h>
#define N 1000005
using namespace std;
int n, m, k;
int a[N];
vector<int>p[N];
struct node{
	int ls, rs, v;
}t[N * 23];
int rt[N], cnt;
void pushup(int u) {
	t[u].v = t[t[u].ls].v + t[t[u].rs].v;
}
void update(int lsto, int &o, int L, int R, int x, int y) {
	o = ++cnt;
	t[o] = t[lsto];
	if(L == R) {
		t[o].v += y;
		return;
	}
	int mid = (L + R) / 2;
	if(x <= mid) update(t[lsto].ls, t[o].ls, L, mid, x, y);
	else update(t[lsto].rs, t[o].rs, mid + 1, R, x, y);
	pushup(o); 
}
int query(int lsto, int o, int L, int R, int l, int r) {
	if(r < L || R < l) return 0;
	if(l <= L && R <= r) return t[o].v - t[lsto].v;
	int mid = (L + R) / 2;
	return query(t[lsto].ls, t[o].ls, L, mid, l, r) + query(t[lsto].rs, t[o].rs, mid + 1, R, l, r);
}
void Sub1() {
	while(m--) {
		int l, r;
		scanf("%d %d", &l, &r);
		for(int h = n; h >= 1; h--) {
			int d = 0;
			for(int i = l; i <= r; i++) {
				if(i == l && a[i] >= h) {
					d++;
				}
				else if(a[i] >= h && a[i - 1] < h) d++;
			}
			if(d >= k) {
				printf("%d\n", h);
				goto end;
			}
		}
		printf("-1\n");
		end:;
	}
}
void Sub2() {
	for(int i = 1; i <= n; i++) {
		if(i % 2 == 0) rt[i] = rt[i - 1];
		else update(rt[i - 1], rt[i], 1, n, a[i], 1);
	}
	//cout << query(rt[0], rt[5], 1, 5, 3, 5);
	for(int i = 1; i <= m; i++) {
		int l, r;
		scanf("%d %d", &l, &r);
		int L = 2, R = n, Get = -1, mid;
		while(L <= R) {
			mid = (L + R) / 2;
			if(query(rt[l - 1], rt[r], 1, n, mid, n) >= k) {
				Get = mid;
				L = mid + 1;
			}
			else R = mid - 1;
		}
		if(Get == -1) {
			if(1 >= k) Get = 1;
		}
		printf("%d\n", Get);
	}
}
signed main() {
	
	freopen("spring.in", "r", stdin);
	freopen("spring.out", "w", stdout);
	scanf("%d %d %d", &n, &m, &k);
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	if(n <= 500 && m <= 500) Sub1();
	else 
	Sub2();
	return 0;
}
/*
5 1 2
3 1 2 1 1
1 5
*/
