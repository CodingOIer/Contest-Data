#include<bits/stdc++.h>
#define N 500005
using namespace std;
int n; 
int now[N], vis[N], use[N];
void dfs(int x) {
	if(x > n) {
		cout << "YES" << endl; 
		for(int i = 1; i <= n; i++) cout << i << " " << now[i] << endl;
		cout << endl;
		exit(0);
	}
	for(int i = 1; i <= n; i++) {
		if(vis[i]) continue;
		if(use[abs(i - x)]) continue;
		use[abs(i - x)] = 1;
		now[x] = i;
		vis[i] = 1;
		dfs(x + 1);
		use[abs(i - x)] = 0;
		vis[i] = 0;
	}
}
signed main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d", &n);
	if(n >= 14) {
		cout << "NO";
		return 0;
	}
	dfs(1);
	cout << "NO";
	return 0;
}
//2 3 6 7 10 11 14 15
