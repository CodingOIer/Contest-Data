#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=5e4+5;
inline int read(){
	int q=0,w=1;char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-') w=-1;ch=getchar();} 	
	while(ch>='0'&&ch<='9') q=q*10+ch-'0',ch=getchar();
	return q*w;
}
int n,m,k,h[N];
vector<int> p[N];
bool vis[N];
signed main(){
	freopen("spring.in","r",stdin);
	freopen("spring.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++){
		h[i]=read();
		p[h[i]].push_back(i);
	}
	for(int i=1;i<=m;i++){
		int l=read(),r=read(),ans=-1,res=1;
		for(int j=l;j<=r;j++) vis[j]=1;
		vis[l-1]=vis[r+1]=0;
		for(int j=1;j<=n;j++){
			if(res>=k) ans=j;
			for(int x=0;x<p[j].size();x++){
				int w=p[j][x];
				if(w>=l&&w<=r){
					if(!vis[w-1]&&!vis[w+1]) res--;
					if(vis[w-1]&&vis[w+1]) res++;
					vis[w]=0;					
				}
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
