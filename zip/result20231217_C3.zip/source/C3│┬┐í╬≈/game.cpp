#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5,mod=998244353;
inline int read(){
	int q=0,w=1;char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-') w=-1;ch=getchar();} 	
	while(ch>='0'&&ch<='9') q=q*10+ch-'0',ch=getchar();
	return q*w;
}
int n,k,v;
bool vis[N];

int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=(res*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return res;
}

int head[N],nxt[N<<1],to[N<<1],ans,tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}


signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),k=read(),v=read();
	if(k==1){
		int m=read();
		for(int i=1;i<=m;i++){
			int u=read(),v=read();
			add(u,v);
			add(v,u);
		}
		for(int i=n;i>=1;i--){
			if(vis[i]) continue;
			vis[i]=1;
			ans=(ans+ksm(v,i)%mod)%mod;
			
			int u=i;
			for(int j=head[u];j;j=nxt[j]){
				int v=to[j];
				vis[v]=1;
			}
		}
		printf("%lld",ans);
	}
	else{
		for(int i=1;i<=k;i++){
			int m=read();
		}
		
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				for(int l=1;l<=n;l++)
					for(int p=1;p<=n;p++)
						for(int o=1;o<=n;o++)
							ans=(ans+ksm(v,i+j+l+p+o))%mod;
					
		printf("%lld",ans);
	}
	return 0;
}
