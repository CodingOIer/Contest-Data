#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=20;
inline int read(){
	int q=0,w=1;char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-') w=-1;ch=getchar();} 	
	while(ch>='0'&&ch<='9') q=q*10+ch-'0',ch=getchar();
	return q*w;
}
int n;

int ans1[N][2]={1,1};
int ans2[N][2];
int ans3[N][2];
int ans4[N][2]={1,2,2,4,3,3,4,1};
int ans5[N][2]={1,3,2,5,3,2,4,4,5,1};
int ans6[N][2];
int ans7[N][2];
int ans8[N][2]={1,4,2,8,3,7,4,5,5,3,6,6,7,2,8,1};
int ans9[N][2]={1,4,2,9,3,8,4,5,5,7,6,6,7,3,8,2,9,1};
int ans10[N][2];
int ans11[N][2];
int ans12[N][2]={1,5,2,12,3,11,4,10,5,7,6,9,7,6,8,8,9,4,10,3,11,2,12,1};
int ans13[N][2]={1,5,2,13,3,12,4,11,5,10,6,7,7,9,8,8,9,6,10,4,11,3,12,2,13,1};
int ans14[N][2];
int ans15[N][2];

signed main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read();
	if(n==1){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans1[i][0],ans1[i][1]);
	}
	else if(n==2){
		printf("NO");
	}
	else if(n==3){
		printf("NO");
	}
	else if(n==4){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans4[i][0],ans4[i][1]);		
	}
	else if(n==5){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans5[i][0],ans5[i][1]);		
	}
	else if(n==6){
		printf("NO");
	}
	else if(n==7){
		printf("NO");
	}
	else if(n==8){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans8[i][0],ans8[i][1]);		
	}
	else if(n==9){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans9[i][0],ans9[i][1]);		
	}
	else if(n==10){
		printf("NO");
	}
	else if(n==11){
		printf("NO");
	}
	else if(n==12){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans12[i][0],ans12[i][1]);		
	}
	else if(n==13){
		printf("YES\n");
		for(int i=0;i<n;i++) printf("%lld %lld\n",ans13[i][0],ans13[i][1]);	
	}
	else if(n==14){
		printf("NO");
	}
	else if(n==15){
		printf("NO");
	}
	
	return 0;
}
