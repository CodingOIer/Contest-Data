#include <bits/stdc++.h>
using namespace std;

int n;
bool id[26], col[26], gd[26][26];

void dfs(int i) {
	if (i == n + 1) {
		puts("YES");
		for (int j = 1; j <= n; ++j) {
			for (int k = 1; k <= n; ++k) {
				if (gd[j][k]) printf("%d %d\n", j, k);
			}
		}exit(0);
	}
	for (int j = 1; j <= n; ++j) {
		if (!id[abs(i - j)] && !col[j]) {
			id[abs(i - j)] = col[j] = 1;
			gd[i][j] = 1;
			dfs(i + 1);
			id[abs(i - j)] = col[j] = 0;
			gd[i][j] = 0;
		}
	}
}

int main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	scanf("%d", &n);
	if (n <= 15) {
		if (n == 14 || n == 15) return puts("NO"), 0;
		else dfs(1);
		puts("NO");
	} else {
		if (n % 4 == 2 || n % 4 == 3) return puts("NO"), 0;
		else dfs(1);
		puts("NO");
	}
}
/*

*/
