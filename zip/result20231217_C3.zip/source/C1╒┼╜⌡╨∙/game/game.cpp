#include <bits/stdc++.h>
main() {
	freopen("spring.out", "w", stdout);
	return puts("0"), 0;
}

