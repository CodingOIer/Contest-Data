#include <bits/stdc++.h>
using namespace std;

int n, m, k, a[1000006], x[1000006], y[1000006];

int check(int l, int r, int h) {
	int tot = 0;
	for (int i = l; i <= r; ++i) {
		if ((a[i] >= h) && (!(a[i - 1] >= h) || i == l)) {
			if (++tot >= k) return k;
		}
	}
	return tot;
}
;
int main() {
	freopen("spring.in", "r", stdin);
	freopen("spring.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d", &x[i], &y[i]);
		int l = 0, r = n + 1;
		for (int h = n; h >= 1; --h) {
			if (check(x[i], y[i], h) >= k) {
				printf("%d\n", h);
				break;
			} else if (h == 1) printf("-1\n");
		}
	}
	return 0;
}
/*
10pts
*/
