#include<bits/stdc++.h>
using namespace std;
int n;
bool vis[105][105],h[105],w[105];
bool z;
void dfs(int x){
	if(z) return;
	if(x==-1){
		z=1;
		printf("YES\n");
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(vis[i][j]) printf("%d %d\n",i,j);
			}
		}
		return;
	}
	for(int i=1;i<=n;i++){
		if(h[i]) continue;
		if(i-x>0){
			if(!w[i-x]){
				vis[i][i-x]=1;
				h[i]=1;w[i-x]=1;
				dfs(x-1);
				h[i]=0;w[i-x]=0;
				vis[i][i-x]=0;
			}
		}
		if(x!=0&&i+x<=n){
			if(!w[i+x]){
				vis[i][i+x]=1;
				h[i]=1;w[i+x]=1;
				dfs(x-1);
				h[i]=0;w[i+x]=0;
				vis[i][i+x]=0;
			}
		}
	}
}
int main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	scanf("%d",&n);
	if(n<=15){
		vis[n][1]=1;
		h[n]=1;w[1]=1;
		dfs(n-2);
		if(!z) printf("NO");
		return 0;
	}
	if((n/2)&1){
		printf("NO");
		return 0;
	}
	vis[n][1]=1;
	h[n]=1;w[1]=1;
	vis[1][n-1]=1;
	h[1]=1;w[n-1]=1;
	dfs(n-3);
	return 0;
} 
