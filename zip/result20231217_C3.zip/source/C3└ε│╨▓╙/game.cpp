#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n,k,v;
int m[10];
int fac[N],inv[N];
int ans;
bool z;
const int mod=998244353;
vector<int> g[10][N];
int Pow(int x,int y){
	x%=mod;
	int z=1;
	while(y){
		if(y&1) z=z*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return z;
}
int C(int n,int m){
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld %lld",&n,&k,&v);
	for(int i=1;i<=k;i++){
		scanf("%lld",&m[i]);
		for(int j=1,u,v;j<=m[i];j++){
			scanf("%lld %lld",&u,&v);
			g[i][u].push_back(v);
			g[i][v].push_back(u);
		}
		if(m[i]) z=1;
	}
	if(!z){
		fac[0]=inv[0]=1;
		for(int i=1;i<=k;i++) fac[i]=fac[i-1]*Pow(v,i)%mod;
		inv[k]=Pow(fac[k],mod-2);
		for(int i=k-1;i>=1;i--) inv[i]=inv[i+1]*Pow(v,i+1)%mod;
		int w=Pow(v,(1+n)*n/2);
		for(int i=1;i<=k;i++){
			ans+=C(k,i)*Pow(n-1,k-i)%mod*w%mod*i%mod;
			ans%=mod;
		}
		printf("%lld",ans*v%mod);
		return 0;
	}
	return 0;
} 
