#include<bits/stdc++.h>
#define N 1000005
using namespace std;
int n,m,k;
int h[N];
int main(){
	freopen("spring.in","r",stdin);
	freopen("spring.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=1;i<=n;i++) scanf("%d",&h[i]);
	while(m--){
		int L,R;
		scanf("%d %d",&L,&R);
		int ans=-1;
		for(int i=n;i>=1;i--){
			int res=0;
			bool o=0;
			for(int j=L;j<=R;j++){
				if(h[j]>=i&&!o) res++,o=1;
				if(h[j]<i) o=0;
				if(res>=k) break;
			}
			if(res>=k){
				ans=i;
				break;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
} 
