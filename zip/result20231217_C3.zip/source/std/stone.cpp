#include<bits/stdc++.h>
using namespace std;
//dengyaotriangle!

vector<int> solve0(int k){
    int n=4*k;
    vector<int> p(n+1);
    for(int i=1;i<=k;i++)p[i]=n-i+1;
    for(int i=k+1;i<=2*k-1;i++)p[i]=n-i;
    p[2*k]=1;
    for(int i=2*k+1;i<=3*k-1;i++)p[i]=n-i+1;
    p[3*k]=n-k;
    for(int i=3*k+1;i<=4*k;i++)p[i]=n-i+2;
    return p;
}
vector<int> solve1(int k){
    int n=4*k+1;
    vector<int> p(n+1);
    for(int i=1;i<=k;i++)p[i]=n-i+1;
    p[k+1]=k+2;
    for(int i=k+2;i<=2*k;i++)p[i]=n-i+2;
    p[2*k+1]=1;
    for(int i=2*k+2;i<=3*k+1;i++)p[i]=n-i+3;
    for(int i=3*k+2;i<=4*k+1;i++)p[i]=n-i+2;
    return p;
}
int main(){
#ifndef dengyaotriangle
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
#endif
    ios::sync_with_stdio(0);cin.tie(0);
    int n;
    cin>>n;
    if(n%4>1){
        puts("NO");
        return 0;
    }
    puts("YES");
    auto p=(n%4?solve1(n/4):solve0(n/4));
    for(int i=1;i<=n;i++)
        printf("%d %d\n",i,p[i]);
    return 0;
}