#include <cstdio>
#include <cctype>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#define LOG(...) fprintf(stderr, __VA_ARGS__)
using namespace std;
typedef long long i64;
inline int rd(int f = 1, int x = 0, char ch = ' ')
{
    while(!isdigit(ch = getchar())) if(ch == '-') f = -1;
    while(isdigit(ch)) x = x*10+ch-'0', ch = getchar();
    return f*x;
}
const int N = 1e5+5, P = 998244353, K = 5;
int n, k, V, a[N]; void fix(int &x) { x<P?0:x-=P; }
struct G
{
    int sg[N], s[N], t; vector<int> e[N]; void add(int x, int y) { if(x > y) swap(x, y); e[x].push_back(y); }
    int SG(int x)
    {
        if(~sg[x]) return sg[x]; sg[x] = 0; map<int, bool> h;
        for(int y:e[x]) h[SG(y)] = 1; while(h.count(sg[x])) ++sg[x]; return sg[x];
    }
    void sol()
    {
        memset(sg+1, -1, sizeof(int)*n);
        for(int i = 1; i <= n; ++i) sg[i] = SG(i);
        for(int i = 1, v = 1; i <= n; ++i) v = (i64)v*V%P, t = max(sg[i], t), fix(s[sg[i]]+=v);
    }
}g[K];
int main()
{
    freopen("game.in", "r", stdin), freopen("game.out", "w", stdout);
    n = rd(), k = rd(), V = rd(); 
    for(int i = 0; i < k; g[i].sol(), ++i) for(int m = rd(), x, y; m--; ) x = rd(), y = rd(), g[i].add(x, y);
    a[0] = 1; for(int i = 0, v = 0; i < k; ++i) 
    {
        static int b[N]; for(int w = v; ~w; --w) for(int j = 0; j <= g[i].t; ++j) 
            fix(b[w^j] += (i64)a[w]*g[i].s[j]%P), v = max(v, w^j);
        for(int i = 0; i <= v; ++i) a[i] = b[i], b[i] = 0;
    }
    printf("%d\n", a[0]);
    return 0;
}