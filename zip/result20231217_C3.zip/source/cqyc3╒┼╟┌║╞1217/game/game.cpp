#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Mod=998244353;
ll n,k,v;
inline ll ksm(ll a,ll b,ll mod){
	ll z=1;
	while(b){
		if(b&1) z=z*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return z;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>k>>v;
	
	
	cout<<4;
	return 0;
}



