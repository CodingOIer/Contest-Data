#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e6+7,inf=1e9;
int n,Q,k;
int a[Maxn],maxx;


int main(){
	freopen("spring.in","r",stdin);
	freopen("spring.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),maxx=max(maxx,a[i]);
	while(Q--){
		int l,r,ans=-1;
		scanf("%d%d",&l,&r);
		
		
		for(int h=1;h<=maxx;h++){
			int cnt=0;
			for(int j=l;j<=r;j++){
				if(a[j]>=h&&(a[j-1]<h||j==l)) cnt++; 
			}
			if(cnt>=k){
				ans=max(ans,h);
			}
			else if(cnt<ans) break;
			if(!cnt) break;
			
		}
		printf("%d\n",ans);
	}
	return 0;
}

/*
10 10 3
8 10 7 9 5 2 6 1 4 5
3 4
6 6
3 4
1 9
1 8
2 9
5 7
5 10
4 7
6 10
*/

