#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=5e5+7;
int n,cnt;
pair<int,int>a[Maxn];
bool vis[Maxn],g[Maxn];
void DFS(int p){
	if(p>n){
//		if(a[1].first!=12) return ;
		printf("YES\n");
		for(int i=1;i<=n;i++) printf("%d %d\n",a[i].first,a[i].second);
		exit(0);
		return ;
	}
	
	for(int i=n;i;i--){
		
		if(vis[abs(p-i)]) continue;
		if(g[i]) continue;
		a[++cnt]=make_pair(i,p);
		g[i]=1;
		vis[abs(p-i)]=1;
		DFS(p+1);
		vis[abs(p-i)]=0;
		g[i]=0;
		--cnt;
	}

}

int main(){
	 freopen("stone.in","r",stdin);
	 freopen("stone.out","w",stdout);
	scanf("%d",&n);
	
	if(n&1){
		if(n%4!=1){
			printf("NO");
			return 0;
		}
	}
	if((n/2)&1){
		printf("NO");
		return 0;
	}
	else{
//		for(ll i=1;i<=n/2-4;i++){
//			printf("%d %d\n",n-i+1,i);
//			vis[n-i+1]=1;
//			g[abs(n-i+1-i)]=1;
//		}
	}
	
	DFS(1);
	printf("NO");
	return 0;
}



