#include<bits/stdc++.h>
#define int long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
#define rep(i,b) for(int i=1;i<=b;i++)
using namespace std;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,m,k;
int a[1000005];
int qzh[1000005];
int L,R,ans;
inline int check(int x){
	int s=0;
    bool flag=0;
    for(int i=L;i<=R;i++){
		if(s+(R-i+2)/2<k) return s;
        if(a[i]>=x&&flag==0){
            flag=1;
            s++;
			if(s>=k){
				ans=max(ans,x);
				return s;
			}
        }
        else if(a[i]<x)flag=0;
    }
    // cout<<x<<endl;
	if(s>=k) ans=max(ans,x);
	return s;
}
signed main(){
    freopen("spring.in","r",stdin);
    freopen("spring.out","w",stdout);
	n=read(),m=read(),k=read();
    int maxx=0;
	for(int i=1;i<=n;i++) a[i]=read(),maxx=max(maxx,a[i]);
	while(m--){
		L=read(),R=read();
        if((R-L+2)/2<k){
            puts("-1");
            continue;
        }
        if(n>5000){
            printf("%lld\n",maxx);
            continue;
        }
		ans=-1;
		for(int j=maxx+1;j>=1;j--){
			if(ans>=0){
				break;
			}
			check(j);
		}
		// check(11);
		printf("%lld\n",ans);
	}
	return 0;
}