#include<bits/stdc++.h>
#define int long long
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>=b;i--)
#define rep(i,b) for(int i=1;i<=b;i++)
using namespace std;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,ans=0;
int ggb[16];
bool jl[16],vis[16];
void dfs(int x){
	if(x==n+1){
        cout<<"YES"<<endl;
        for(int i=1;i<=n;i++){
            cout<<i<<" "<<ggb[i]<<" "<<abs(i-ggb[i])<<endl;
        }
		// return;
		exit(0);
	}
	for(int i=1;i<=n;i++){
		if(vis[i]||jl[abs(x-i)+1]) continue;
		vis[i]=1;jl[abs(x-i)+1]=1;
        ggb[x]=i;
		dfs(x+1);
		ggb[x]=0;
		vis[i]=0;jl[abs(x-i)+1]=0;
	}
}
int gg[300005];
signed main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n=read();
	if(n%4>1){
		cout<<"NO";
		return 0;
	} 
	if(n<=15){
		if(n<14)dfs(1);
		cout<<"NO";
		return 0;
	}
	if(n%2==0){
		
		memset(gg,-1,sizeof(gg));
		for(int i=1;i<=n;i++){
			if(gg[i]>=0) continue;
			int grap;
			if(i<=n/2) grap=(i-1)/2;
			else grap=(n-i)/2;
			if(grap==n/4-1){
				gg[i]=3;
				gg[i+1]=0;
				gg[i+2]=2;
				gg[i+3]=1;
				// cout<<i;
			}
			else{
				int zu;
				if(i<=n/2) zu=(n/2-i)/2;
				else zu=(i-n/2-1)/2;
				gg[i]=(zu)*4+3;
				gg[i+1]=(zu)*4+1;
				gg[n-i+1]=(zu)*4;
				gg[n-i]=(zu)*4+2;
			}
		}
		cout<<"YES"<<endl;
		for(int i=1;i<=n;i++){
			int grap;
			if(i<=n/2) grap=(i-1)/2;
			else grap=(n-i)/2;
			if((i<=n/2&&grap!=n/4-1)||((i==n/2-1||i==n/2)&grap==n/4-1)) printf("%lld %lld\n",i,i+gg[i]);
			else printf("%lld %lld\n",i,i-gg[i]);
			// cout<<gg[i]<<endl;
		}
	}
	return 0;
}