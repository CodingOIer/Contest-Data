#include <bits/stdc++.h>

#define rep(i, a, b) for(auto i = (a); i <= (b); i++)
#define _rep(i, a, b) for(auto i = (a); i >= (b); i--)

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;

template <typename _Tp>
void read(_Tp& first) {
	_Tp x = 0, f = 1; char c = getchar();
	while (!isdigit(c)) {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	first = x * f;
}

template <typename _Tp>
void print(_Tp x) {
	if (x < 0) x = (~x + 1), putchar('-');
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

int n;

int main() {
#ifndef LOCAL
#ifndef ONLINE_JUDGE
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
#endif
#endif
	read(n);
	if ((n / 2) & 1) return puts("NO"), 0;
	else puts("YES");
	if (n == 1) return puts("1 1"), 0;
	else if (n == 4) return puts("1 4\n2 2\n3 1\n4 3"), 0;
	else if (n == 5) return puts("1 5\n2 2\n3 4\n4 1\n5 3"), 0;
	else if (n == 8) return puts("1 8\n2 7\n3 3\n4 6\n5 4\n6 2\n7 1\n8 5"), 0;
	else if (n == 9) return puts("1 9\n2 8\n3 7\n4 4\n5 3\n6 5\n7 2\n8 1\n9 6"), 0;
	//else if (n == 13) puts("1 13\n2 12\n3 11\n4 10\n5 8\n6 6\n7 5\n8 7\n9 4\n10 3\n12 2\n13 1");
	int now = n - 2;
	int X1 = 1, X2 = n - 1, Y1 = n, Y2 = 1;
	print(X1), putchar(32), print(Y1), putchar(10);
	print(X2), putchar(32), print(Y2), putchar(10);
	while (now) {
		if (now == n - Y2 + 2 || now == n - Y1 + 2) {
			print(n), putchar(32), print(n - now + 1), putchar(10);
			int cx = X1, cy = Y2;
			if (n & 1) {
				printf("%d %d\n%d %d\n%d %d\n%d %d\n",1 + cx, 4 + cy, 2 + cx, 2 + cy, 3 + cx, 1 + cy, 4 + cx, 3 + cy);
			}
			else {
				printf("%d %d\n%d %d\n%d %d\n%d %d\n",1 + cx, 3 + cy, 2 + cx, 1 + cy, 3 + cx, 4 + cy, 4 + cx, 2 + cy);
			}
			break;
		}
		if ((now & 1) == (n & 1)) {
			X1++, Y1--;
			print(X1), putchar(32), print(Y1), putchar(10);
		}
		else {
			X2--, Y2++;
			print(X2), putchar(32), print(Y2), putchar(10);
		}
		now--;
	}
	return 0;
}
