#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 305,mod = 1000000007;
int fac[N],inv[N];
int f[2][N][N];
int n, m;

int ksm(int a,int b){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

int A(int a,int b){return fac[a]*inv[a-b]%mod;}

signed main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    inv[0] = fac[0] = 1;
    for(int k=1;k<N;k++)
        fac[k] = fac[k-1]*k%mod;
    inv[N-1] = ksm(fac[N-1],mod-2);
    for(int k=N-2;k;k--)
        inv[k] = inv[k+1]*(k+1)%mod;
    
    n = in,m = in;
    f[0][0][0] = 1;
    int o = 0;
    for(int k=1;k<=n;k++){
        for(int j=0;j<=min(n,m);j++){
            f[o^1][j][0] = 0;
            for(int i=1;i<=n;i++)
                f[o^1][j][i] = f[o][j][i-1];
        }
        o ^= 1;
        for(int j=min(n,m)-1;~j;j--){
            int s = 0;
            for(int i=n;i;i--){
                s = (s+f[o][j][i])%mod;
                f[o][j+1][i-1] = (f[o][j+1][i-1]+s)%mod;
            }
        }
    }
    int ans = 0;
    for(int k=1;k<=min(n,m);k++)
        ans = (ans+f[o][k][0]*A(m,k))%mod;
    out(ans);
    return 0;
}