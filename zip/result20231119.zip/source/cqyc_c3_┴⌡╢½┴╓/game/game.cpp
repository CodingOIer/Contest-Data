#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    puts("AFO");
    return 0;
}