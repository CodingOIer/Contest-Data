#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 300005,mod = 1000000007;
int l[N],r[N];
int n,m;

namespace A{
    int main(){
        int ans = 0;
        for(int k=1,j=1;k<=n;k++){
            j = max(j,r[k]);
            if(k>=j)
                ans++;
        }
        out(ans);
        return 0;
    }
}

namespace B{
    int stk[N],tp;
    int main(){
        r[0] = n + 1;
        stk[++tp] = 0;
        int ans = 0;
        for(int k=1;k<=n;k++){
            while(tp&&r[stk[tp]]<=r[k])
                tp--;
            stk[++tp] = k;
            int L = 1,R = tp,res;
            while(L<=R){
                int mid = (L+R)>>1;
                if(r[stk[mid]]<=k){
                    res = mid;
                    R = mid-1;
                }
                else
                    L = mid+1;
            }
            ans = (ans+k-stk[res-1])%mod;
        }
        out(ans);
        return 0;
    }
}

namespace nn{
    int main(){
        int ans = 0;
        for(int L=1;L<=n;L++){
            int j = 0;
            for (int R=L;R<=n;R++){
                if(l[R]<L)
                    break;
                j = max(j,r[R]);
                if(j<=R)
                    ans = (ans+1)%mod;
            }
        }
        out(ans);
        return 0;
    }
}

signed main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n = in,m = in;
    for(int k=1;k<=n;k++)
        l[k] = r[k] = k;
    int f1 = 1,f2 = 1;
    for(int k=1;k<=m;k++){
        int a = in,b = in;
        f1 &= (a>b)&(a==k+1);
        f2 &= a<b;
        l[a] = min(l[a],b);
        r[a] = max(r[a],b);
    }
    if(f1&&n-1==m)
        return A::main();
    if(f2)
        return B::main();
    return nn::main();
}