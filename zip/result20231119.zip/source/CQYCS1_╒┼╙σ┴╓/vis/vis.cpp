#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =3e5+5,M=6e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m,h[N],to[M],nxt[M],cnt;
inline void add(int a,int b){
    to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt;
}
int dfn[N],low[N],Time,bel[N],tot,s[N],tp,le[N],re[N];
bool ins[N];
inline void tarjan(int x){
    dfn[x]=low[x]=++Time,ins[x]=1,s[++tp]=x;
    e(x)if(!dfn[y])tarjan(y),low[x]=min(low[x],low[y]);
    else if(ins[y])low[x]=min(low[x],dfn[y]);
    if(dfn[x]==low[x]){
        tot++;
        le[tot]=n+1,re[tot]=0;
        for(int y=s[tp--];;y=s[tp--]){
            bel[y]=tot,ins[y]=0;
            le[tot]=min(le[tot],y),re[tot]=max(re[tot],y);
            if(y==x)break;
        }
    }
}
vector<int>p[N];
int rd[N];
inline void bfs(){
    queue<int>q;
    rep(i,1,n)if(!rd[i])q.push(i);
    while(!q.empty()){
        int x=q.front();
        q.pop();
        E(x){
            rd[y]--;
            re[y]=max(re[y],re[x]),le[y]=min(le[y],le[x]);
            if(rd[y]==0)q.push(y);
        }
    }
}
ll ans;
int li[N],ri[N];
struct seg{
    int w;
    bool laz;
}xd[N<<2];
inline void getup(int x){
    xd[x].w=xd[L].w+xd[R].w;
}
inline void inst(int x,int l,int r){
    xd[x].laz=1,xd[x].w=r-l+1;
}
inline void pushdown(int x,int l,int r){
    if(xd[x].laz)inst(lc),inst(rc),xd[x].laz=0;
}
inline void modify(int x,int l,int r,int Ll,int Rr){
    if(Ll>Rr)return;
    if(OK)return inst(x,l,r),void();
    pushdown(x,l,r);
    if(Ll<=mid&&Rr>=l)modify(lc,Ll,Rr);
    if(Ll<=r&&Rr>mid)modify(rc,Ll,Rr);
    getup(x);
}
inline int query(int x,int l,int r,int Ll,int Rr){
    if(OK)return xd[x].w;
    pushdown(x,l,r);
    if(Rr<=mid)return query(lc,Ll,Rr);
    if(Ll>mid)return query(rc,Ll,Rr);
    return query(lc,Ll,Rr)+query(rc,Ll,Rr);
}
int t[N];
inline void ad(int x,int k){
    while(x<=n)t[x]=min(t[x],k),x+=x&-x;
}
inline int que(int x){
    int ans=n+1;
    while(x)ans=min(ans,t[x]),x-=x&-x;
    return ans;
}
int main(){
	freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    for(int i=1,x,y;i<=m;i++){
        x=read(),y=read();
        if(x^y)add(x,y);
    }
    rep(i,1,n)if(!dfn[i])tarjan(i);
    rep(x,1,n)e(x){
        if(bel[x]^bel[y]){
            rd[bel[x]]++,p[bel[y]].pb(bel[x]);
        }
    }
    bfs();
    rep(i,1,n)li[i]=le[bel[i]],ri[i]=re[bel[i]],t[i]=n+1;
    int Rr=n;
    per(i,n,1){
        modify(Root,i,ri[i]-1);
        ad(li[i],i);
        Rr=que(i-1);
        if(Rr>i)ans+=Rr-i-query(Root,i,Rr-1);
    }
    cout <<ans%mod;
    return 0;
}