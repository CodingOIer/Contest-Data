#include<bits/stdc++.h>
#define ll long long
#define L t[x].l
#define R t[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=6e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,k,a[N],b[N];
ll dp[1005][1005],ans=llf;
ll F[1005][1005];
/*
8 4
3 8 7 9 9 4 6 8
2 5 9 4 3 8 9 1
*/
int main(){
	freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),k=read();
    rep(i,1,n)a[i]=read();
    rep(i,1,n)b[i]=read();
    if(k>n){
        cout <<0;
        return 0;
    }
    rep(i,0,n)rep(j,0,n)F[i][j]=llf;
    rep(t,1,k){
        rep(i,1,n)rep(j,i,n)F[i][j]=dp[i-1][j-1]+a[i]+b[j];
        rep(i,1,n)rep(j,i,n)F[i][j]=min({F[i-1][j],F[i][j-1],F[i-1][j-1],F[i][j]});
        rep(i,0,n)rep(j,i,n)dp[i][j]=F[i][j],F[i][j]=llf;
    }
    rep(i,1,n)rep(j,i,n)ans=min(ans,dp[i][j]);
    cout <<ans;
    return 0;
}