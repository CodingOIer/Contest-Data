#include<bits/stdc++.h>
#define ll long long
#define L t[x].l
#define R t[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e6+5,M=6e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m;
inline void Add(int &a,int b){
    ((a+=b)>=mod) and (a-=mod);
}
inline int mul(int a,int b){
    return 1LL*a*b%mod;
}
inline void Mul(int &a,int b){
    a=mul(a,b);
}
inline int red(int a,int b){
    ((a+=mod-b)>=mod) and (a-=mod);
    return a;
}
inline int qp(int a,int b){
    if(!b)return 1;
    int c=qp(a,b>>1);
    Mul(c,c);
    if(b&1)Mul(c,a);
    return c;
}
int ml[N],inv[N];
inline void prep(){
    ml[0]=1;
    rep(i,1,m)ml[i]=mul(ml[i-1],i);
    inv[m]=qp(ml[m],mod-2);
    per(i,m-1,0)inv[i]=mul(inv[i+1],i+1);
}
inline int C(int x,int y){
    if(x<0||y<0||x<y)return 0;
    return mul(mul(ml[x],inv[y]),inv[x-y]);
}
inline int A(int x,int y){
    return mul(C(x,y),ml[y]);
}
int dp[305][305][305],ans;//i prefix,j choosen,k max
int main(){
	freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    n=read(),m=read(),prep();
    dp[1][1][1]=1;
    rep(i,2,n){
        rep(mx,1,min(m,i)){
            rep(j,1,mx){
                if(j>1)Add(dp[i][j][mx],red(dp[i-1][j-1][mx-1],dp[i-1][j-2][mx-1]));
                Add(dp[i][j][mx],red(dp[i-1][mx][mx],dp[i-1][j-1][mx]));
            }
        }
        rep(mx,1,min(m,i))rep(j,1,mx)Add(dp[i][j][mx],dp[i][j-1][mx]);
    }
    rep(mx,1,min(m,n))Add(ans,mul(dp[n][mx][mx],A(m,mx)));
    pf(ans);
    return 0;
}