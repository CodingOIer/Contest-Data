#include <bits/stdc++.h>
#define int long long
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int N = 3e2+5,M = 1e2+5;
int n,K,a[N],b[N],f[N][N][M],mn1[N][N][M],mn2[N][N][M];
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(K);
	for(int i = 1;i<=n;i++)
		read(a[i]);
	for(int i = 1;i<=n;i++)
		read(b[i]);
	memset(f,63,sizeof f);
	memset(mn1,63,sizeof mn1);
	memset(mn2,63,sizeof mn2);
	f[0][0][0] = 0,mn1[0][0][0] = mn2[0][0][0] = 0;
	for(int i = 0;i<=n;i++)
		for(int j = 0;j<=n;j++)
			for(int k = 0;k<=2*K;k++)
			{
				if(k%2==1){if(i&&k) f[i][j][k] = mn1[i-1][j][k-1]+a[i];}
				else{if(j&&k&&j>=i) f[i][j][k] = mn2[i][j-1][k-1]+b[j];}
				if(i>0) mn1[i][j][k] = min(mn1[i-1][j][k],f[i][j][k]);
				else mn1[i][j][k] = f[i][j][k];
				if(j>0) mn2[i][j][k] = min(mn2[i][j-1][k],f[i][j][k]);
				else mn2[i][j][k] = f[i][j][k];
			}
	int ans = 2e18;
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=n;j++)
			ans = min(ans,f[i][j][2*K]);
	write(ans);
	return 0;
}

