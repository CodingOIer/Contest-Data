#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int mod = 1e9+7;
int n,m,ans[5][5] = {{1,2,3,4,5},{1,4,9,16,25},{1,8,27,64,125},{1,14,75,244,605},{1,22,183,844,2725}};
signed main()
{
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	read(n),read(m);
	if(n<=5&&m<=5) write(ans[n-1][m-1]);
	else puts("114514");
	return 0;
}
 
