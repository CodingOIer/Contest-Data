#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int N = 3e5+5,inf = 2e9,mod = 1e9+7;
int n,m,mn[N],mx[N],ans;
void add(int &x,int y){x+=y;if(x>=mod)x-=mod;}
inline void sub1()
{
	for(int i = 1;i<=n;i++)
	{
		int minn = inf,maxn = -inf;
		for(int j = i;j<=n;j++)
		{
			minn = min(minn,mn[j]),maxn = max(maxn,mx[j]);
			if(minn<i) break;
			if(maxn<=j) add(ans,1);
		}
	}
	write(ans);
}
int st[N][20];
inline int querymn(int l,int r)
{
	int lg = log2(r-l+1);
	return min(st[l][lg],st[r-(1<<lg)+1][lg]);
}
inline void sub2()
{
	for(int j = 0;j<=19;j++)
		for(int i = 1;i+(1<<j)-1<=n;i++)
			st[i][j] = inf;
	for(int i = 1;i<=n;i++) st[i][0] = mn[i];
	for(int j = 1;j<=17;j++)
		for(int i = 1;i+(1<<j)-1<=n;i++)
			st[i][j] = min(st[i][j-1],st[i+(1<<(j-1))][j-1]);
	for(int i = 1;i<=n;i++)
	{
		int l = 1,r = n-i+1,res = 0;
		while(l<=r)
		{
			int mid = (l+r)/2;
			if(querymn(i,i+mid-1)>=i) l = mid+1,res = mid;
			else r = mid-1;
		}
		add(ans,res);
	}
	write(ans);
}
inline int querymx(int l,int r)
{
	int lg = log2(r-l+1);
	return max(st[l][lg],st[r-(1<<lg)+1][lg]);
}
inline void sub3()
{
	for(int i = 1;i<=n;i++) st[i][0] = mx[i];
	for(int j = 1;j<=19;j++)
		for(int i = 1;i+(1<<j)-1<=n;i++)
			st[i][j] = max(st[i][j-1],st[i+(1<<(j-1))][j-1]);
	for(int i = 1;i<=n;i++)
	{
		int l = 1,r = i,res = 0;
		while(l<=r)
		{
			int mid = (l+r)/2;
			if(querymx(i-mid+1,i)<=i) l = mid+1,res = mid;
			else r = mid-1;
		}
		add(ans,res);
	}
}
signed main()
{
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	read(n),read(m);
	for(int i = 1;i<=n;i++)
		mn[i] = inf,mx[i] = -inf;
	for(int i = 1,u,v;i<=m;i++)
		read(u),read(v),mn[u] = min(mn[u],v),mx[u] = max(mx[u],v);
	if(n<=2e3) sub1();
	else if(m==n-1) sub2();
	else sub3();
	return 0;
}

