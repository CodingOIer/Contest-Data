#include<bits/stdc++.h>
using namespace std;
const int N=3e5+5,mod=1e9+7;
inline void read(int &x){
	x=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int head[N],to[N<<1],nxt[N<<1],tot;
inline void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
int n,m,u[N<<1],v[N<<1];
int dfn[N],low[N],idx,fa[N];
stack<int> stk;
bool instk[N],vis[N];
int f[N],g[N],rt[N];
void dfs(int p){
	dfn[p]=low[p]=++idx;
	stk.push(p);
	instk[p]=1;
	for(int o=head[p],v;o;o=nxt[o]){
		v=to[o];
		if(!dfn[v]){
			dfs(v);
			low[p]=min(low[p],low[v]);
		}else if(instk[v]) low[p]=min(low[p],low[v]);
	}
	if(dfn[p]==low[p]){
		int t=0;
		f[p]=g[p]=p;
		while(t^p){
			t=stk.top(),stk.pop();
			instk[t]=0;
			fa[t]=p;
			f[p]=min(f[p],t);
			g[p]=max(g[p],t);
		}
	}
}
void F(int p){
	if(vis[p]) return;
	vis[p]=1;
	for(int o=head[p];o;o=nxt[o]){
		F(to[o]);
		f[p]=min(f[p],f[to[o]]);
		g[p]=max(g[p],g[to[o]]);
	}
}
vector<int> Q[N];
int t[N],ans;
inline void addv(int x,int v){for(x=n-x+1;x<=n;x+=x&-x) t[x]+=v;}
inline void query(int x){for(x=n-x+1;x;x-=x&-x) ans=(ans+t[x])%mod;}
int main(){
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;++i){
		read(u[i]),read(v[i]);
		add(u[i],v[i]);
	}
	for(int i=1;i<=n;++i)
		if(!dfn[i]) dfs(i);
	for(int i=1;i<=n;++i) head[i]=0;
	tot=0;
	for(int i=1;i<=m;++i)
		if(fa[u[i]]!=fa[v[i]])
			add(fa[u[i]],fa[v[i]]);
	while(!stk.empty()) stk.pop();
	for(int i=1;i<=n;++i) F(fa[i]); 
	for(int i=1;i<=n;++i){
		while(!stk.empty()&&f[fa[stk.top()]]>f[fa[i]])  rt[stk.top()]=i,stk.pop();
		stk.push(i);
	}
	for(int i=1;i<=n;++i){
		if(f[fa[i]]!=i) continue;
		Q[i].push_back(i);
		if(rt[i]) Q[rt[i]].push_back(-i);
	}
	while(!stk.empty()) stk.pop();
	for(int i=1,t;i<=n;++i){
		for(int jj=0,j;jj<(int)Q[i].size();++jj){
			j=Q[i][jj];
			if(j<0) addv(-j,-1);
			else addv(j,1);
		}
		while(!stk.empty()&&g[fa[stk.top()]]<=g[fa[i]]) stk.pop();
		t=(stk.empty()?1:stk.top()+1);
		stk.push(i);
		if(g[fa[i]]!=i) continue;
		query(t);
	}
	printf("%d",ans);
	return 0;
}

