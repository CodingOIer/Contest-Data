#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m,a[114],l[114],r[114],id[114],ans,fac[114];
bool vis[10000005];
void dfs(int x){
	if(x==m+1){
		for(int i=1;i<=n;++i) a[i]=0;
		for(int i=1;i<=m;id[i++]=0)
			for(int j=l[i];j<=r[i];++j) a[j]=i;
		int idx=0;
		for(int i=1;i<=n;++i) if(!a[i]) return;
		for(int i=1;i<=n;++i)
			if(!id[a[i]]) id[a[i]]=++idx;
		int z=0,w=1;
		for(int i=1;i<=n;++i){
			a[i]=id[a[i]];
			z+=w*a[i];
			w*=(m+1);
		}
		if(!vis[z]) ans=(ans+fac[m-idx+1]),vis[z]=1;
		return;
	}
	for(l[x]=1;l[x]<=n;++l[x])
	for(r[x]=l[x];r[x]<=n;++r[x])
		dfs(x+1);
}
int main(){
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	scanf("%d%d",&n,&m);
	fac[m+1]=1;
	for(int i=m;i;--i) fac[i]=1ll*fac[i+1]*i%mod; 
	dfs(1);
	printf("%d",ans);
	return 0;
}

