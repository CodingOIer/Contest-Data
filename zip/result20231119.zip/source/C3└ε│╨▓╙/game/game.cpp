#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k;
int a[100005],b[100005];
map<int,map<int,map<int,int> > > p;
int dfs(int aa,int bb,int k1,int k2){
	if(k-k1>n-aa||k-k2>n-bb) return 1e18;
	if(k1==k2&&k1==k) return 0;
	if(p[aa][bb][k1+k2]>0) return p[aa][bb][k1+k2];
	int res=1e18;
	if(k1==k2) for(int i=aa+1;i<=n;i++) res=min(res,dfs(i,max(i-1,bb),k1+1,k2)+a[i]);
	else for(int i=bb+1;i<=n;i++) res=min(res,dfs(aa,i,k1,k2+1)+b[i]);
	return p[aa][bb][k1+k2]=res;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	printf("%lld",dfs(0,0,0,0));
	return 0;
}
