#include<bits/stdc++.h>
#define int long long
#define N 300005
using namespace std;
int n,m;
int tot,head[N],nxt[N<<1],to[N<<1];
int mx[N],mn[N];
int cx[N][23],cn[N][23],Log2[N];
int ans;
bool vis[N];
const int mod=1000000007;
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
void dfs(int x){
	vis[x]=1;
	for(int i=head[x];i;i=nxt[i]){
		if(!vis[to[i]]) dfs(to[i]);
		mx[x]=max(mx[x],mx[to[i]]);
		mn[x]=min(mn[x],mn[to[i]]);
	}
}
int maxx(int l,int r){
	int t=Log2[r-l+1];
	return max(cx[l][t],cx[r-(1<<t)+1][t]);
}
int minn(int l,int r){
	int t=Log2[r-l+1];
	return min(cn[l][t],cn[r-(1<<t)+1][t]);
}
signed main(){
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1,u,v;i<=m;i++){
		scanf("%lld %lld",&u,&v);
		if(u!=v) add(u,v);
	}
	for(int i=1;i<=n;i++) mx[i]=mn[i]=i;
	if(n<=500&&m<=5000){
		for(int i=1;i<=n;i++){
			dfs(i);
			for(int j=1;j<=n;j++) vis[j]=0;
		}
	}
	else{
		for(int i=1;i<=n;i++){
			if(!vis[i]) dfs(i);	
		}
		for(int j=1;j<=n;j++) vis[j]=0;
		for(int i=1;i<=n;i++){
			if(!vis[i]) dfs(i);	
		}
	}
	for(int i=2;i<=n;i++) Log2[i]=Log2[i/2]+1;
	for(int i=1;i<=n;i++) cx[i][0]=mx[i];
	for(int i=1;i<=20;i++){
		for(int j=1;j+(1<<i)-1<=n;j++){
			cx[j][i]=max(cx[j][i-1],cx[j+(1<<(i-1))][i-1]);
		}
	}
	for(int i=1;i<=n;i++) cn[i][0]=mn[i];
	for(int i=1;i<=20;i++){
		for(int j=1;j+(1<<i)-1<=n;j++){
			cn[j][i]=min(cn[j][i-1],cn[j+(1<<(i-1))][i-1]);
		}
	}
	for(int i=1;i<=n;i++){
		int l=i,r=i;
		while(r<=n&&minn(l,r)>=l){
			while(r<=n&&r<maxx(l,r)&&minn(l,r)>=l) r=maxx(l,r);
			if(r<=n&&minn(l,r)>=l){
				ans++;
				if(ans>=mod) ans-=mod;
			}
			r++;
		}
	}
	printf("%lld",ans%mod);
	return 0;
}
