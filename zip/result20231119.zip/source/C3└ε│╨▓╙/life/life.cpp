#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
int a[1000005];
int fac[1000005],inv[1000005];
int ans;
int p[75][75][75];
bool vis[75][75][75];
const int mod=1000000007;
inline int r(int x,int y){
	x%=mod;
	int z=1;
	while(y){
		if(y&1) z=z*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return z;
}
inline int c(int n,int m){
	return fac[n]*inv[m]%mod*inv[n-m]%mod;
}
inline void dfs(int x,int s,int l){
	if(s==n){
		ans+=c(m,x-1)*fac[x-1]%mod;
		ans%=mod;
		return;
	}
	if(x>m) return;
	for(int i=1;i<=n;i++){
		if(a[i]!=0) continue;
		bool z=0;
		for(int j=i;j<=n;j++){
			if(a[j]==0){
				a[j]=x;
				s++;
				if(i>l||j>l) dfs(x+1,s,i);
			}
			else if(a[j]==x-1) z=1;
		}
		for(int j=i;j<=n;j++){
			if(a[j]==x){
				a[j]=0;
				s--;
			}
		}
	}
}
signed main(){
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	fac[0]=inv[0]=1;
	for(int i=1;i<=m;i++) fac[i]=fac[i-1]*i%mod;
	inv[m]=r(fac[m],mod-2);
	for(int i=m-1;i>=1;i--) inv[i]=inv[i+1]*(i+1)%mod;
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
