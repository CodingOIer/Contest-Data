#include <bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
inline int Mod(int x){if(x>=mod)x-=mod;return x;}
int n,m,ans;
int f[2][305][305];
int main() {
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	cin>>n>>m;
	f[0][0][1]=1;
	int res=1;
	for(int i=1;i<=min(n,m);i++){
		memset(f[i&1],0,sizeof f[i&1]);
		res=1ll*res*(m-i+1)%mod;
		for(int j=i-1;j<n;j++){
			for(int k=1;k<=j+1;k++){
				for(int l=1;l+j<=n;l++){
					for(int w=1;w<=k;w++){
						f[i&1][j+l][k-w+l]=Mod(f[i&1][j+l][k-w+l]+1ll*f[(i-1)&1][j][k]*(m-i+1)%mod);	
					}
				}
			}
		}
//		cout<<i<<'\n';
		int sum=0;
		for(int j=1;j<=n+1;j++)sum=Mod(sum+f[i&1][n][j]);
		ans=Mod(ans+sum%mod);
	} 
	cout<<ans;
	return 0;
}
