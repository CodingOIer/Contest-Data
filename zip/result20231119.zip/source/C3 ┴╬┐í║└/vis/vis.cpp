#include <bits/stdc++.h>
#define mid ((l+r)>>1)
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
const int mod=1e9+7;
inline int Mod(int x){if(x>=mod)x-=mod;return x;} 
int n,m,ans;
struct node{
	int minn,maxn;
}a[300005];
int tree[300005];
inline int lowbit(int x){return x&(-x);}
void add(int x,int y){
	while(x<=n){
		tree[x]+=y;
		x+=lowbit(x);
	}
	return;
}
int ask(int x){
	int sum=0;
	while(x){
		sum+=tree[x];
		x-=lowbit(x);	
	}
	return sum;
}
void sol(int l,int r){
	if(l>=r){
		if(l<=a[l].minn&&a[l].maxn<=r)ans=Mod(ans+1);
		return;
	}
	sol(l,mid),sol(mid+1,r);
	int Min=a[mid+1].minn,Max=a[mid+1].maxn;
	int Maxn=a[mid].maxn,Minn=a[mid].minn;
	int now=mid+1;
	for(int i=mid+1;i<=r;i++){
		while(now>l&&max(a[now-1].maxn,Maxn)<=i){
			now--;
			Maxn=max(Maxn,a[now].maxn);
			Minn=min(Minn,a[now].minn);
			if(Minn>=now)add(now,1);
		}
		Max=max(Max,a[i].maxn);
		Min=min(Min,a[i].minn);
		if(Max<=i){
			ans=Mod(ans+ask(Min));
		}
	}
	Minn=a[mid].minn;
	for(int i=mid;i>=now;i--){
		Minn=min(Minn,a[i].minn);
		if(Minn>=i)add(i,-1);
	}
}
int main() {
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	read(n,m);
	for(int i=1;i<=n;i++)a[i].minn=a[i].maxn=i;
	for(int i=1;i<=m;i++){
		int u,v;
		read(u,v);
		a[u].minn=min(a[u].minn,v);
		a[u].maxn=max(a[u].maxn,v);	
	}
	sol(1,n);
	write(ans);
	flush();
	return 0;
}
