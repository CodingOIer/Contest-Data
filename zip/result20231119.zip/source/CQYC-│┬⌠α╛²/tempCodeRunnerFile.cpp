
    //     for(int j=0;j<=m;j++){
    //         for(int k=0;k<=m;k++){
    //             if(dp[i][j][k]) cout<<i<<" "<<j<<" "<<k<<"  "<<dp[i][j][k]<<"\n";
    //         }
    //     }
    // }