#include <bits/stdc++.h>
using namespace std;
const int N=3e5+5,K=20;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,m,low[N],dfn[N],col[N],stk[N],top,num[N],cnt,cnt_col,d[N],ans;
vector<int> g[N];
struct sccc{
    int l=N,r=0;
    vector<int> g,num;
}a[N];
struct name{
    int l,r;
}b[N];
void tarjan(int x){
    low[x]=dfn[x]=++cnt;
    stk[++top]=x;
    for(auto y:g[x]){
        if(!dfn[y]){
            tarjan(y);
            low[x]=min(low[x],low[y]);
        }
        else if(!col[y]) low[x]=min(low[x],dfn[y]);
    }
    if(low[x]==dfn[x]){
        cnt_col++;
        do{
            if(stk[top]==0) return;
            a[cnt_col].num.push_back(stk[top]);
            col[stk[top]]=cnt_col;
        }while(stk[top--]!=x);
    }
}
void dfs(int x){
    for(auto i:a[x].g){
        a[i].r=max(a[x].r,a[i].r);
        a[i].l=min(a[x].l,a[i].l);
        dfs(i);
    }
}
int l[N],r[N];
struct stbiao{
    int t[N][K+1],t1[N][K+1];
    void init(){
        for(int i=1;i<=K;i++){
            for(int j=1;j<=n;j++){
                t[j][i]=max(t[j][i-1],t[j+(1<<(i-1))][i-1]);
                t1[j][i]=min(t1[j][i-1],t1[j+(1<<(i-1))][i-1]);
            }
        }
    }
    int query1(int l,int r){
        int len=log2(r-l+1);
        return max(t[l][len],t[r-(1<<len)+1][len]);
    }
    int query2(int l,int r){
        int len=log2(r-l+1);
        return min(t1[l][len],t1[r-(1<<len)+1][len]);
    }
}st;
int findr(int x){
    int l=x,r=n,mid,ans=x-1;
    while(l<=r){
        mid=(l+r)>>1;
        if(st.query2(x,mid)<x) r=mid-1;
        else l=mid+1,ans=mid;
    }
    return ans;
}
int findl(int x){
    int l=1,r=x,mid,ans=x+1;
    while(l<=r){
        mid=(l+r)>>1;
        if(st.query1(mid,x)>x) l=mid+1;
        else r=mid-1,ans=mid;
    }
    return ans;
}
namespace zxs{
    const int N=2e5+5;
    int cnt,rt[N];
    struct tree{
        int ls,rs,sum;
    }t[N*30];
    void push_up(int x){
        t[x].sum=t[t[x].ls].sum+t[t[x].rs].sum;
    }
    int clone(int x){
        t[++cnt]=t[x];
        return cnt;
    }
    void build(int &x,int st,int ed){
        if(!x) x=++cnt;
        if(st==ed) return ;
        int mid=(st+ed)>>1;
        build(t[x].ls,st,mid);
        build(t[x].rs,mid+1,ed);
    }
    int update(int x,int st,int ed,int k){
        x=clone(x);
        int mid=(st+ed)>>1;
        if(st==ed){
            t[x].sum++;
            return x;
        }
        if(k<=mid) t[x].ls=update(t[x].ls,st,mid,k);
        else t[x].rs=update(t[x].rs,mid+1,ed,k);
        push_up(x);
        return x;
    }
    int query(int x,int y,int st,int ed,int l,int r){
        if(l<=st&&ed<=r) return t[x].sum-t[y].sum;
        int mid=(st+ed)>>1;
        int ans=0;
        if(l<=mid) ans+=query(t[x].ls,t[y].ls,st,mid,l,r);
        if(r>mid) ans+=query(t[x].rs,t[y].rs,mid+1,ed,l,r);
        return ans;
    }
    void init(){
        build(rt[0],1,n);
    }
}
int main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        g[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i]) tarjan(i);
    for(int i=1;i<=n;i++){
        a[col[i]].l=min(a[col[i]].l,i);
        a[col[i]].r=max(a[col[i]].r,i);
        for(auto j:g[i])
            if(col[i]!=col[j]) a[col[j]].g.push_back(col[i]),d[col[i]]++;
    }
    for(int i=1;i<=cnt_col;i++)
        if(d[i]==0) dfs(i);
    for(int i=1;i<=n;i++) b[i]={a[col[i]].l,a[col[i]].r},r[i]=n+1,l[i]=0;
    // for(int i=1;i<=n;i++) cout<<i<<" "<<b[i].l<<" "<<b[i].r<<"!\n";
    for(int i=1;i<=n;i++) st.t[i][0]=b[i].r,st.t1[i][0]=b[i].l;
    st.init();
    for(int i=1;i<=n;i++){
        l[i]=findl(i);
        r[i]=findr(i);
        // cout<<i<<" "<<l[i]<<" "<<r[i]<<"\n";
    }
    zxs::init();
    for(int i=1;i<=n;i++) zxs::rt[i]=zxs::update(zxs::rt[i-1],1,n,l[i]);
    for(int i=1;i<=n;i++){
        ans+=zxs::query(zxs::rt[r[i]],zxs::rt[i-1],1,n,1,i);
    }
    cout<<ans;
    return 0;
}