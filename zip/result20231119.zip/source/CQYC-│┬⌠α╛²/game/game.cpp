#include <bits/stdc++.h>
#include <bits/extc++.h>
using namespace __gnu_pbds;
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,dp=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') dp=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*dp;
}
#define int long long
const int N=1e5+5;
int n,k,bj=1,ans;
int a[N],b[N];
namespace subA{
    int mian(){
        for(int i=1;i<=n;i++) a[i]+=b[i];
        sort(a+1,a+n+1);
        for(int i=1;i<=k;i++) ans+=a[i];
        cout<<ans<<"\n";
        return 0;
    }
}
namespace n3m{
    int dp[305][305][305],ans=1e18;
    int mian(){
        memset(dp,0x3f,sizeof(dp));
        dp[0][0][0]=0;
        for(int i=1;i<=n;i++){
                for(int j=i;j<=n;j++){
                        for(int kk=1;kk<=k;kk++){
                                for(int i1=0;i1<i;i1++)
                                        for(int j1=i1;j1<j;j1++) dp[i][j][kk]=min(dp[i][j][kk],dp[i1][j1][kk-1]+a[i]+b[j]);
                            if(kk==k) ans=min(ans,dp[i][j][kk]);
                        }
                }
        }
        cout<<ans<<"\n";
        return 0;
    }
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),k=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++){
        b[i]=read();
        if(b[i]>b[i-1]) bj=0;
    }
    if(bj) return subA::mian();
    else return n3m::mian();
    return 0;
} 