#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
#define int long long
const int mod=1e9+7,N=1e6+5;
// 这就是希望。
// 即便需要取模，也是光明。
int n,m,dp[75][75][75][2],ans,jc[N],ijc[N];
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=ans*x%mod;
        x=x*x%mod;
        base>>=1;
    }
    return ans;
}
// dp[i][j][k] 表示走到i,有j个没动,k个在栈里,是否决定单走
void add(int &x,int y){x=(x+y)%mod;}
signed main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    n=read(),m=read();
    jc[0]=1;
    for(int i=1;i<=m;i++) jc[i]=jc[i-1]*i%mod;
    ijc[m]=pow(jc[m],mod-2);
    for(int i=m-1;i>=0;i--) ijc[i]=ijc[i+1]*(i+1)%mod;
    dp[1][m-1][1][0]=1;
    dp[1][m-1][0][1]=1;
    for(int i=1;i<n;i++){
        for(int j=0;j<=m;j++){
            for(int k=0;k<=m;k++){
                int now0=dp[i][j][k][0],now1=dp[i][j][k][1];
                add(dp[i+1][j][k][1],now1);// 单走的继续单走
                if(k) add(dp[i+1][j][k-1][0],now1);// 单走的结束，开始回收栈
                add(dp[i+1][j][k][0],now0);// 继续走
                if(j) add(dp[i+1][j-1][k+1][0],(now0+now1)%mod);// 来一个新的左括号
                if(j) add(dp[i+1][j-1][k][1],(now0+now1)%mod);// 来一个新的单走
            }
        }
    }
    // for(int i=1;i<=n;i++){
    //     for(int j=0;j<=m;j++){
    //         for(int k=0;k<=m;k++){
    //             for(int l=0;l<2;l++)
    //                 if(dp[i][j][k][l]) cout<<i<<" "<<j<<" "<<k<<" "<<l<<"  "<<dp[i][j][k][l]<<"\n";
    //         }
    //     }
    // }
    for(int j=0;j<=m;j++)
            for(int l=0;l<2;l++)
                add(ans,dp[n][j][0][l]*jc[m]%mod*ijc[j]%mod);
    cout<<ans<<"\n";
    return 0;
}