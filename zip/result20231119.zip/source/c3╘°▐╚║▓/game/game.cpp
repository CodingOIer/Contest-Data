#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
const int Mod=1e9+7;
int n,K;
int a[100005],b[100005];
int dp[10005][1005];
int st[200005][19];
int lg[200005];
int f[10005][1005],ans=1e16;
int jyh[301][301][101];
void dfs(int x,int y,int g,int val){
	if(val>=ans) return; 
	if(jyh[x][y][g]<=val) return;
	jyh[x][y][g]=val;
	if(g==K){
		ans=min(ans,val);
		return;
	}
	for(int i=x+1;i<=n;i++){
		for(int j=max(i,y+1);j<=n;j++){
			dfs(i,j,g+1,val+a[i]+b[j]);
		}
	}
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),K=read();
	a[0]=1e16;
	for(int i=1;i<=n;i++) a[i]=read(); 
	for(int i=1;i<=n;i++) b[i]=read();
	if(n<=300&&K<=100){
		memset(jyh,0x3f,sizeof(jyh));
		dfs(0,0,0,0);
		cout<<ans;
		return 0;
	}
	/*
	lg[0]=-1;
	for(int i=2;i<=n*2;i++) lg[i]=lg[i/2]+1;
	for(int i=0;i<=n;i++) st[i][0]=a[i];
	for(int k=1;k<=18;k++){
		for(int i=0;i<=n;i++){
			st[i][k]=min(st[i][k-1],st[i+(1<<(k-1))][k-1]);
		}
	}
	memset(dp,0x3f,sizeof(dp));
	dp[0][0]=0;
	memset(f,0x3f,sizeof(f));
	for(int i=1;i<=n;i++){
		sort(a+1,a+i+1);
		for(int j=1;j<=i;j++){
			f[i][j]=a[j];
//			cout<<f[i][j]<<" ";
		} 
//		cout<<endl;
	}
	for(int i=1;i<=n;i++){
		for(int k=1;k<=min(K,i);k++){
			dp[i][k]=dp[i-1][k];
			for(int j=0;j<i;j++){
				int kk=lg[i-j];
				int gg=min(f[j][k],min(st[j+1][kk],st[i-(1<<kk)+1][kk]));
				if(gg==0) gg=a[i];
				dp[i][k]=min(dp[i][k],dp[j][k-1]+gg+b[i]);
			}
		}
	} 
//	for(int i=1;i<=K;i++) cout<<dp[0][i]<<" "; 
	int ans=1e16;
	cout<<dp[n][K];*/
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	ans=0;
	for(int i=1;i<=K;i++){
		ans+=a[i];
		ans+=b[i];
	}
	int sum=1e16;
	if(K<n){
//		if(K<n-1){
//			sum=min(sum,ans-a[K]+a[K+2]);
//			sum=min(sum,ans-b[K]+b[K+2]);
//		}
		ans-=a[K];
		ans+=a[K+1];
		ans-=b[K];
		ans+=b[K+1];
	}
	cout<<ans;
	return 0;
}
