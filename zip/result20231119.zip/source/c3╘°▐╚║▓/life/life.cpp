#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
const int Mod=1e9+7;
int n,m;
int a[1000005];
int l[11],r[11];
int ans;
void dfs(int x){
	for(int i=1;i<m;i++){
		for(int j=i+1;j<=m;j++){
			if(l[j]>r[i]||r[j]<l[i]||(l[i]<=l[j]&&r[j]<=r[i])||(l[j]<=l[i]&&r[i]<=r[j])) continue;
			return;
		}
	}
	if(x==n+1){
	//		cout<<endl;
	//		for(int i=1;i<=m;i++){
	//			cout<<l[i]<<" "<<r[i]<<" ";
	//		}
//		cout<<1;
		ans++;
		return;
	}
	for(int i=1;i<=m;i++){
		if(x>3&&a[x-3]==a[x-1]&&a[x-2]==i&&a[x-1]!=i) continue;
		int gg=l[i],gg2=r[i];
		l[i]=min(l[i],x);
		r[i]=max(r[i],x);
		bool bk=1;
//		for(int j=1;j<=m;j++){
//			if(l[j]==l[0]||r[j]==0) continue;
//			if(l[j]>=r[i]||r[j]<=l[i]||(l[i]<=l[j]&&r[j]<=r[i])||(l[j]<=l[i]&&r[i]<=r[j])) continue;
//			bk=0;
//			break;
//		}
		if(!bk) continue;
		a[x]=i;
		dfs(x+1);
		l[i]=gg,r[i]=gg2;
		a[x]=0;
	}
	
}
signed main(){
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	n=read(),m=read();
	if(n<=10){
		memset(l,0x3f,sizeof(l));
		memset(r,0,sizeof(r));
		dfs(1);
		cout <<ans<<endl;
		return 0;
	}
	return 0;
}
