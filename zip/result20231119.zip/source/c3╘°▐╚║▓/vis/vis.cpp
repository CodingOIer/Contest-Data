#include<bits/stdc++.h>
#define LL long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
const LL Mod=1e9+7;
int n,m;
LL ans;
vector<int>q[200005],ll,rr;
int l[200005],r[200005];
int minst[200005][19],maxst[200005][19];
int lg[200005];
int qzh[200005];
signed main(){
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		if(u==v) continue;
		q[u].push_back(v);
//		q[v].push_back(u);
	}
	for(int i=1;i<=n;i++){
		q[i].push_back(i);
		sort(q[i].begin(),q[i].end());
	}
	memset(l,0x3f,sizeof(l));
	for(int i=1;i<=n;i++){
		int L=q[i][0],R=i;
		l[i]=L;
		if(i>1&&q[i][0]==q[i-1][0]) l[i]=min(l[i],l[i-1]);
		else 
		for(int j=L;j<=R;j++)
			if(l[j]<l[i])
				l[i]=min(l[i],l[j]);
		
	}
	for(int i=n;i>=1;i--){
		int L=i,R=q[i][q[i].size()-1];
		r[i]=R;
		int maxx=0,pp=0;
		if(i+1<=n&&R==q[i+1][(i+1<=n?q[i+1].size()-1:0ll)]) r[i]=max(r[i],r[i+1]);
		else 
		for(int j=L;j<=R;j++)
			if(r[j]>maxx)
				r[i]=max(r[i],r[j]);
	}
	for(int i=1;i<=n;i++){
		if(l[i]==i) ll.push_back(i);
		if(r[i]==i) rr.push_back(i);
//		cout<<i<<":"<<l[i]<<" "<<r[i]<<endl;
	}
	for(int i=1;i<=n;i++){
		qzh[i]=qzh[i-1];
		if(r[i]==i) qzh[i]++;
	}
	lg[0]=-1;
	for(int i=1;i<=n;i++) lg[i]=lg[i/2]+1;
	for(int i=1;i<=n;i++) minst[i][0]=l[i];
	for(int i=1;i<=n;i++) maxst[i][0]=r[i];
	for(int k=1;k<=18;k++){
		for(int i=1;i<=n;i++){
			minst[i][k]=min(minst[i][k-1],minst[i+(1<<(k-1))][k-1]);
			maxst[i][k]=max(maxst[i][k-1],maxst[i+(1<<(k-1))][k-1]);
		}
	}
	int radh=0;
	for(int i=0;i<ll.size();i++){
		int L=ll[i];
		/*if(r[L]==L){
			ans+=qzh[n]-qzh[L-1];
			ans%=Mod;
			continue;
		}*/
		for(int j=radh;j<rr.size();j++){
			int R=rr[j];
			if(L>R){
				radh=j;
				continue;
			}
			int k=lg[R-L+1];
//			cout<<endl<<minst[R-(1<<k)+1][k]<<" "<<R-(1<<k)+1<<" "<<k<<" ";
//			cout<<L<<" "<<R<<" "<<min(minst[L][k],minst[R-(1<<k)+1][k])<<" "<<max(maxst[L][k],maxst[R-(1<<k)+1][k]);
			if(L!=R&&min(minst[L][k],minst[R-(1<<k)+1][k])<L) continue;
			if(L!=R&&max(maxst[L][k],maxst[R-(1<<k)+1][k])>R) continue;
//			cout<<"Yes"<<endl;
			ans++;
			ans%=Mod;
		}
	}
	cout<<ans;
	return 0;
}
