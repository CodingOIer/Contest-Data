#include <bits/stdc++.h>
using namespace std;

int n, m, u, v;
vector<int> edges[200001];
int d[200001], yd[200001], ans;

int main() {
	freopen("vis.in", "r", stdin);
	freopen("vis.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d", &u, &v);
		edges[u].push_back(v);
		++d[u];
		++yd[u];
	}
	for (int i = 1; i <= n; ++i) {
		for (int j = i; j <= n; ++j) {
			bool ok = 1;
			for (int k = i; k <= j && ok; ++k)
				for (auto l : edges[k]) {
					if (l < i || l > j) {
						ok = 0;
						break;
					}
				}
			ans += ok; 
		}
		
	}
	return printf("%d\n", ans), 0;
}
/*
35pts
*/
