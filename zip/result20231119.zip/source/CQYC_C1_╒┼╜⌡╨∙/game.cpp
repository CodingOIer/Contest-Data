#include <bits/stdc++.h>
using namespace std;

int n, k, a[100001], b[100001];
int f[301][301][101][2];
#define inf 2139062143

inline void cmin(int &a, int b) {
	if (b < a) a = b;
}
inline int dfs(int i, int j, int l, bool who) {
	if (l == k) return 0;
	if (f[i][j][l][who] != inf) return f[i][j][l][who];
	register int ans = 1000000000, al, bl;
	if (who == 0) {
		for (al = i + 1; al <= n; ++al) {
			cmin(ans, dfs(al, j, l, who ^ 1) + a[al]);
		}
	} else {
		for (bl = max(j + 1, i); bl <= n; ++bl) {
			cmin(ans, dfs(i, bl, l + 1, who ^ 1) + b[bl]);
		}
	}
	return f[i][j][l][who] = ans;
}

void mains() {

	scanf("%d%d", &n, &k);
//	n = 300, k  
	for (int i = 1; i <= n; ++i) {
//		a[i] = i;
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= n; ++i) {
//		b[i] = i;
		scanf("%d", &b[i]);
	}
	memset(f, 127, sizeof(f));
	printf("%d\n", dfs(0, 0, 0, 0));
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	mains();
	return 0;
}
/*
25pts
*/
