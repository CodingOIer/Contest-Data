#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define pii pair <int, int>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
    int p = 0, flg = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-') flg = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        p = p * 10 + c - '0';
        c = getchar();
    }
    return p * flg;
}
void write(int x) {
    if (x < 0) {
        x = -x;
        putchar('-');
    }
    if (x > 9) {
        write(x / 10);
    }
    putchar(x % 10 + '0');
}
#define fi first
#define se second
const int N = 7;
array <pii, N> isl;
array <int, N> s;
int ans = 0;
void dfs(int step, int n, int m) {
    if (step == n) {
        isl.fill(make_pair(0, 0));
        for (int i = 1; i <= n; i++)
            if (!isl[s[i]].fi) isl[s[i]].fi = i;
        for (int i = n; i; i--)
            if (!isl[s[i]].se) isl[s[i]].se = i;
        sort(isl.begin() + 1, isl.begin() + 1 + m);
        bool flg = 0;
        for (int i = 2; i <= m; i++) {
            if (isl[i - 1].se > isl[i].fi && isl[i - 1].se < isl[i].se) flg = 1;
        }
        ans += !flg;
        return;
    }
    for (int i = 1; i <= m; i++) {
        s[step + 1] = i;
        dfs(step + 1, n, m);
    }
}
int main() {
    freopen("life.in", "r", stdin);
    freopen("life.out", "w", stdout);
    int n = read(), m = read();
    dfs(0, n, m);
    write(ans), puts("");
    return 0;
}

/*







*/