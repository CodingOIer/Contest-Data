#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define int long long
#define pii pair <int, int>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
    int p = 0, flg = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-') flg = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        p = p * 10 + c - '0';
        c = getchar();
    }
    return p * flg;
}
void write(int x) {
    if (x < 0) {
        x = -x;
        putchar('-');
    }
    if (x > 9) {
        write(x / 10);
    }
    putchar(x % 10 + '0');
}
#define fi first
#define se second
const int N = 3e5 + 5;
array <pii, N> s;
namespace Subtask1 {

void main(int n, int m) {
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        int tp1 = s[i].fi, tp2 = s[i].se;
        for (int j = i; j <= m; j++) {
            tp1 = min(tp1, s[j].fi); tp2 = max(tp2, s[j].se);
            if (tp1 == i && tp2 == j) ans++;
        }
    }
    write(ans), puts("");
}

}
namespace Subtask2 {

void main(int n, int m) {
    write(n - 1), puts("");
}

}
namespace Subtask3 {

const int mod = 1e9 + 7;
void Mod(int &x) {
    if (x >= mod) x -= mod;
    if (x < 0) x += mod;
}
void main(int n, int m) {
    int ans = 0, tp = 0;
    for (int i = 1; i <= n; i++) {
        // write(s[i].fi), putchar(32);
        // write(s[i].se), puts("[]");
        tp = max(tp, s[i].se);
        if (tp == i) ans += i, Mod(ans);
    }
    write(ans), puts("");
}

}
signed main() {
    freopen("vis.in", "r", stdin);
    freopen("vis.out", "w", stdout);
    int n = read(), m = read();
    for (int i = 1; i <= n; i++)
        s[i] = make_pair(i, i);
    bool flg1 = true, flg2 = true;
    for (int i = 1; i <= m; i++) {
        int x = read(), y = read();
        s[x].fi = min(s[x].fi, y), s[x].se = max(s[x].se, y);
        if (x > y) flg2 = false; if (x < y) flg1 = false;
    }
    if (n <= 2000) Subtask1::main(n, m), exit(0);
    if (m == n - 1 && flg1) Subtask2::main(n, m), exit(0);
    if (flg2) Subtask3::main(n, m), exit(0);
}