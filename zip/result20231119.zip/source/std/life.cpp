#include<functional>
#include<algorithm>
#include<iterator>
#include<cstring>
#include<cstdio>
using namespace std;
int cn[1111111],cm[1111111];
int r[1111111],rf[1111111];
const int Ha=1000000007;
int main()
{
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout); 
	int n,m;
	scanf("%d%d",&n,&m);
	r[1]=1;
	for(int i=2;i<=m;++i)
		r[i]=1ll*(Ha-Ha/i)*r[Ha%i]%Ha;
	rf[0]=1;
	for(int i=1;i<=m;++i)
		rf[i]=1ll*rf[i-1]*r[i]%Ha;
	cn[0]=cm[0]=1;
	for(int i=1;i<=m;++i)
	{
		cn[i]=1ll*cn[i-1]*(n-i+1)%Ha;
		cm[i]=1ll*cm[i-1]*(m-i+1)%Ha;
	}
	for(int i=0;i<=m;++i)
	{
		cn[i]=1ll*cn[i]*rf[i]%Ha;
		cm[i]=1ll*cm[i]*rf[i]%Ha;
	}
	int qwq=1,res=0;
	for(int i=1;i<=m;++i)
	{
		res=(res+1ll*qwq*cn[i-1]%Ha*cm[i])%Ha;
		qwq=1ll*qwq*(n-i)%Ha;
	}
	printf("%d\n",res);
	return 0;
}
