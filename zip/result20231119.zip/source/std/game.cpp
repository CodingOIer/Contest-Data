#include<cstdio>
#include<queue>
#define N 100005
using namespace std;
namespace runzhe2000
{
	typedef double db; 
	int n, k, a[N], b[N]; db B;
	int check(db lim)
	{
		priority_queue<db, vector<db>, greater<db> > q_up, q_dn; int f = 0; B = 0;
		for(int i = 1; i <= n; i++)
		{
			db val = a[i]-lim+b[i]; int pos = val < 0 ? 1 : 0;
			if(!q_up.empty() && q_up.top() + b[i] < 0) (q_up.top() + b[i] < val) ? pos = 2, val = q_up.top() + b[i] : 0;
			if(!q_dn.empty() && q_dn.top() + b[i] < 0) (q_dn.top() + b[i] < val) ? pos = 3, val = q_dn.top() + b[i] : 0;
			
			if(pos == 1) q_dn.push(-b[i]);
			else if(pos == 2) q_up.pop(), q_up.push(a[i]-lim), q_dn.push(-b[i]);
			else if(pos == 3) q_dn.pop(), q_up.push(a[i]-lim), q_dn.push(-b[i]);
			else q_up.push(a[i]-lim);
			
			if(pos) B += val, pos <= 2 ? f++ : 0;
		}
		return f;
	}
	void main()
	{
		scanf("%d%d",&n,&k);
		for(int i = 1; i <= n; i++) scanf("%d",&a[i]);
		for(int i = 1; i <= n; i++) scanf("%d",&b[i]);
		db l = 0, r = 2e9;
		for(; r - l > 1e-5;)
		{
			db mid = (l+r)/2;
			check(mid) <= k ? l = mid : r = mid;
		}
		printf("%.0lf\n",B+l*k);
	}
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	runzhe2000::main();
}
