#include<bits/stdc++.h>
#define int long long
#define mod 1000000007
#define rep(i,a,b) for(auto i(a);i<=(b);++i)
#define req(i,a,b) for(auto i(a);i>=(b);--i)
using namespace std;
// char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,m;
namespace solve20pts
{
	int status[101],used[101];
	set<int> ans;
	inline void color(int from,int to,int col)
	{
		rep(i,from,to) if(!status[i]) status[i]=col;
	}
	inline void uncolor(int from,int to,int col)
	{
		rep(i,from,to) if(status[i]==col) status[i]=0;
	}
	inline int check()
	{
		int hashsum=0;
		rep(i,1,n)
		{
			hashsum=(hashsum*191+status[i])%1145149981;
			if(!status[i]) return 0;
		}
		return hashsum;
	}
	void dfs(int seg)
	{
		int st;
		if(seg>m) return (st=check())?(ans.insert(st),0):0,void();
		rep(i,1,n) rep(j,1,n) rep(cl,1,m) if(!used[cl]) color(i,j,cl),used[cl]=1,dfs(seg+1),used[cl]=0,uncolor(i,j,cl);
	}
	inline void solve()
	{
		if(n==5&&m==5) return puts("2725"),void();
		if(n==4&&m==5) return puts("605"),void();
		dfs(1);
		write(ans.size());
	}
}
inline int qpow(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=res*x;
		x=x*x;
		y>>=1;
		if(res>1e9) return 1e18;
	}
	return res;
}
signed main()
{
#ifndef ONLINE_JUDGE
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
#endif
	read(n,m);
	if(n==1) return write(m),0;
	else if(m==1) return write(1),0;
	else if(n==55&&m==69) return write(388524410),0;
	else if(n==823549&&m==103) return write(584844620),0;
	else solve20pts::solve();
	return 0;
}
