#include<bits/stdc++.h>
// #define int long long
#define rep(i,a,b) for(auto i(a);i<=(b);++i)
#define req(i,a,b) for(auto i(a);i>=(b);--i)
using namespace std;
// char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,m,x,y,ans;
vector<int> g[300001];
namespace solve40pts
{
	inline void solve()
	{
		rep(i,1,n) 
		{
			rep(j,i,n)
			{
				int ok=1;
				rep(u,i,j)
				{
					for(auto v:g[u]) if(v<i||v>j) {ok=0;break;}
					if(!ok) break;
				}
				ans+=ok;
			}
			if(ans>=1000000007) ans-=1000000007;
		}
		write(ans);
	}
}
namespace special_constraint_a
{
	int dep[300001];
	vector<int> rev_g[300001];
	inline bool check()
	{
		rep(i,1,n) if(g[i].size()&&g[i][0]>=i) return 0;
		return m==n-1;
	}
	inline void solve()
	{
		cerr<<"Special Constraint A";
		rep(i,1,n) for(auto j:g[i]) rev_g[j].emplace_back(i);
		rep(i,1,n) ans+=!rev_g[i].size();
		write(ans);
	}
}
signed main()
{
#ifndef ONLINE_JUDGE
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
#endif
	read(n,m);
	rep(i,1,m) read(x,y),g[x].emplace_back(y);
	if(special_constraint_a::check()) special_constraint_a::solve();
	else solve40pts::solve();
	return 0;
}
