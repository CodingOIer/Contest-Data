#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,pstk[40];
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<typename T=long long>inline T read(){
	T x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
template<typename T>inline void write(T x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(x<0)x=-x,pc('-');
	if(plen>=1000000)flush();
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc('0'+pstk[len--]);
}
const int Maxn=3e5+5,Mod=1e9+7;
int n,m;
int head[Maxn],to[Maxn<<1],nxt[Maxn<<1],cnt1;
int f[Maxn],g[Maxn];
int dfn[Maxn],cnt,low[Maxn];
stack<int>stk;
int vis[Maxn];
int a[Maxn];
void tarjan(int u){
	vis[u]=1;stk.push(u);dfn[u]=low[u]=++cnt;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(!dfn[y]){
			tarjan(y);
			low[u]=min(low[u],low[y]);
		}
		if(vis[y])low[u]=min(low[u],low[y]);
	}
	if(low[u]==dfn[u]){
		a[u]=u;vis[u]=0;
		while(stk.top()!=u){
			a[stk.top()]=u;
			vis[stk.top()]=0;
			stk.pop();
		}
		stk.pop();
	}
}
struct edge{int u,v;}e[Maxn<<1];
int du[Maxn];
int st[Maxn][20];
inline int st_query(int l,int r){
	if(l==r)return st[l][0];
	int t=log2(r-l+1);
	return min(st[l][t],st[r-(1<<t)+1][t]);
}
inline int st_query1(int l,int r){
	if(l==r)return st[l][0];
	int t=log2(r-l+1);
	return max(st[l][t],st[r-(1<<t)+1][t]);
}
int s[Maxn],b[Maxn];
struct Tree{int ls,rs,data;}t[Maxn*30];
int root[Maxn],cnt2;
int build(int l,int r){
	int x=++cnt2;
	if(l==r)return x;
	int mid=l+r>>1;
	t[x].ls=build(l,mid);
	t[x].rs=build(mid+1,r);
	return x;
}
void change(int&x,int y,int l,int r,int d){
	x=++cnt2;t[x]=t[y];
	t[x].data++;
	if(l==r)return;
	int mid=l+r>>1;
	if(mid>=d)change(t[x].ls,t[y].ls,l,mid,d);
	else change(t[x].rs,t[y].rs,mid+1,r,d);
}
int query(int x,int y,int l,int r,int d){
	if(r<=d)return t[x].data-t[y].data;
	int mid=l+r>>1;
	int res=query(t[x].ls,t[y].ls,l,mid,d);
	if(mid<d)res+=query(t[x].rs,t[y].rs,mid+1,r,d);
	return res;
}
inline void solve(){
	for(int i=1;i<=n;i++)
		if(!dfn[i])tarjan(i);
	for(int i=1;i<=n;i++)f[i]=g[i]=i;
	for(int u=1;u<=n;u++){
		for(int i=head[u];i;i=nxt[i]){
			int y=to[i];
			if(y!=a[u])e[++cnt1]={a[u],y},du[a[u]]++;
			f[a[u]]=min(f[a[u]],y);
			g[a[u]]=max(g[a[u]],y);
		}
	}
	memset(head,0,sizeof head);
	for(int i=1;i<=cnt1;i++){
		to[i]=e[i].v;
		nxt[i]=head[e[i].u];
		head[e[i].u]=i;
	}
	queue<int>h;
	for(int i=1;i<=n;i++)
		if(!du[i])h.push(i);
	while(h.size()){
		int u=h.front();
		h.pop();
		for(int i=head[u];i;i=nxt[i]){
			int y=to[i];
			f[y]=min(f[y],f[u]);
			g[y]=max(g[y],g[u]);
			du[y]--;
			if(!du[y])h.push(y);
		}
	}
	int ans=0;
	memset(st,0x7f,sizeof st);
	for(int i=1;i<=n;i++)st[i][0]=f[a[i]];
	for(int j=1;j<20;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			st[i][j]=min(st[i][j-1],st[i+(1<<(j-1))][j-1]);
	for(int i=1;i<=n;i++){
		int l=i,r=n,mid,res=0;
		while(l<=r){
			mid=l+r>>1;
			if(st_query(i,mid)>=i)res=mid,l=mid+1;
			else r=mid-1;
		}
		s[i]=res;
	}
	memset(st,-0x7f,sizeof st);
	for(int i=1;i<=n;i++)st[i][0]=g[a[i]];
	for(int j=1;j<20;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			st[i][j]=max(st[i][j-1],st[i+(1<<(j-1))][j-1]);
	for(int i=1;i<=n;i++){
		int l=1,r=i,mid,res=0;
		while(l<=r){
			mid=l+r>>1;
			if(st_query1(mid,i)<=i)res=mid,r=mid-1;
			else l=mid+1;
		}
		b[i]=res;
	}
	root[0]=build(1,n);
	for(int i=1;i<=n;i++)
		if(b[i])change(root[i],root[i-1],1,n,b[i]);
		else root[i]=root[i-1];
	for(int i=1;i<=n;i++)
		if(s[i])ans=(ans+query(root[s[i]],root[i-1],1,n,i))%Mod;
	write(ans);flush();
}
signed main(){
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		to[i]=v;nxt[i]=head[u];
		head[u]=i;
	}
	solve();
	return 0;
}

