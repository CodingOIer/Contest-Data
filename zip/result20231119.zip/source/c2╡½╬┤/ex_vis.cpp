#include<bits/stdc++.h>
using namespace std;
int plen,pstk[40];
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<typename T=long long>inline T read(){
	T x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
template<typename T>inline void write(T x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(x<0)x=-x,pc('-');
	if(plen>=1000000)flush();
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc('0'+pstk[len--]);
}
const int Maxn=3e5+5;
int n,m;
int head[Maxn],to[Maxn<<1],nxt[Maxn<<1];
bool e[2005][2005];
int f[Maxn],g[Maxn];
inline void solve_sub1(){
	queue<int>h;
	for(int k=1;k<=n;k++){
		g[k]=f[k]=k;e[k][k]=1;
		h.push(k);
		while(h.size()){
			int u=h.front();
			h.pop();
			for(int i=head[u];i;i=nxt[i])
				if(!e[k][to[i]])f[k]=min(f[k],to[i]),g[k]=max(g[k],to[i]),e[k][to[i]]=1,h.push(to[i]);
		}
	}
//	for(int i=1;i<=n;i++)
//			printf("f[%d]=%d\n",i,f[i]);
	int ans=0;
	for(int l=1;l<=n;l++)
		for(int r=l;r<=n;r++){
			int ok=1;
			for(int i=l;i<=r;i++)
				if(f[i]<l||g[i]>r){
					ok=0;break;
				}
			if(ok)ans++;//,printf("%d %d\n",l,r);
		}
	write(ans);flush();
	exit(0);
}
int main(){
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		to[i]=v;nxt[i]=head[u];
		head[u]=i;
	}
	if(n<=500)solve_sub1();
	return 0;
}
