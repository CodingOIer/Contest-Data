#include<bits/stdc++.h>
#define int long long
using namespace std;
int plen,pstk[40];
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<typename T=int>inline T read(){
	T x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
template<typename T>inline void write(T x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(x<0)x=-x,pc('-');
	if(plen>=1000000)flush();
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc('0'+pstk[len--]);
}
const int Maxn=5005;
int n,K;
int a[100005],b[100005];
int f[Maxn][Maxn],g[Maxn][Maxn];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();K=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=n;i++)b[i]=read();
	for(int i=1;i<=K;i++){
		for(int j=i;j<=n+1;j++)
			for(int k=j;k<=n+1;k++)
				f[j][k]=g[j-1][k-1]+a[j]+b[k],g[j-1][k-1]=1e18;
		g[n][n]=g[n-1][n]=g[n][n-1]=1e18;
		for(int i=1;i<=n;i++)g[i][i-1]=1e18;
		for(int j=i;j<n;j++)
			for(int k=j;k<n;k++)
				g[j][k]=min(min(g[j][k-1],g[j-1][k]),min(g[j-1][k-1],f[j][k]));
	}
	int ans=1e18;
	for(int i=K;i<=n;i++)
		for(int j=i;j<=n;j++)
			ans=min(ans,f[i][j]);
	write(ans);flush();
	return 0;
}

