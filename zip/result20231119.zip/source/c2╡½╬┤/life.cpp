#include<bits/stdc++.h>
using namespace std;
int plen,pstk[40];
char out[1<<20];
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<typename T=long long>inline T read(){
	T x=0;bool f=0;char ch=getchar();
	while(ch<'0'||ch>'9')f^=(ch=='-'),ch=getchar();
	while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
template<typename T>inline void write(T x){
	if(!x){pc('0');if(plen>=1000000)flush();return;}
	if(x<0)x=-x,pc('-');
	if(plen>=1000000)flush();
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc('0'+pstk[len--]);
}
int n,m;
int aaa[11][11];
int main(){
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	n=read();m=read();
	aaa[1][1]=1;
	aaa[1][2]=1;
	aaa[1][3]=1;
	aaa[1][4]=1;
	aaa[1][5]=1;
	aaa[2][1]=1;
	aaa[2][2]=4;
	aaa[2][3]=9;
	aaa[2][4]=16;
	aaa[2][5]=25;
	aaa[3][1]=1;
	aaa[3][2]=8;
	aaa[3][3]=27;
	aaa[3][4]=64;
	aaa[3][5]=125;
	aaa[4][1]=1;
	aaa[4][2]=14;
	aaa[4][3]=75;
	aaa[4][4]=244;
	aaa[4][5]=605;
	aaa[5][1]=1;
	aaa[5][2]=24;
	aaa[5][3]=195;
	aaa[5][4]=880;
	aaa[5][5]=2805;
	write(aaa[n][m]);flush();
	return 0;
}

