#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,k,a[305],b[305],ans=1e16;
int f[205][305][305][2];
void dfs(int pos,int Alst,int Blst,int sum,int who){
	
	if(sum>f[pos][Alst][Blst][who]) return;
	f[pos][Alst][Blst][who]=sum;
	
	if(pos==(k<<1|1)){
		ans=min(ans,sum);
		return;
	}		
	
	if(who){
		for(int i=Alst+1;i<=n-(2*k-pos)/2;i++)
			dfs(pos+1,i,Blst,sum+a[i],who^1);
	}
	else{
		for(int i=max(Alst,Blst+1);i<=n-(2*k-pos)/2;i++)
			dfs(pos+1,Alst,i,sum+b[i],who^1);
	}
	
}
signed main(){	
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),k=read();	
	
	for(int i=1;i<=(k<<1|1);i++)
		for(int j=0;j<=n;j++)
			for(int l=0;l<=n;l++)
				f[i][j][l][0]=f[i][j][l][1]=1e16;
				
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	
	dfs(1,0,0,0,1);
	printf("%lld",ans);
	return 0;
}
