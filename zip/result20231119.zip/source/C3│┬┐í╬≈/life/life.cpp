#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=15,mod=1e9+7; 
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,m,ans;
int s[N],tp;
void dfs(int pos){
	if(pos==n+1){
		bool win=1;
		
		for(int l1=1;l1<n&&win;l1++)
			for(int r1=l1+2;r1<n&&win;r1++)
				for(int l2=l1+1;l2<r1&&win;l2++)
					for(int r2=r1+1;r2<=n&&win;r2++)
						if(s[l1]==s[r1]&&s[l2]==s[r2]&&s[l1]!=s[l2]) win=0;
		
		if(win) ans++;		
		return;
	}
	for(int i=1;i<=m;i++)
		s[++tp]=i,dfs(pos+1),tp--;
	return;
}
signed main(){	
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	n=read(),m=read();
	dfs(1);
	printf("%lld",ans%mod);
	return 0;
}
