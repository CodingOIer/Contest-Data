#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5,mod=1e9+7;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,m,ans;
int maxn[N],minn[N];
signed main(){	
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) minn[i]=n+1;
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		maxn[u]=max(maxn[u],v);
		minn[u]=min(minn[u],v);
	}
	for(int l=1;l<=n;l++){
		int mn=n+1,mx=0;
		for(int r=l;r<=n;r++){
			mn=min(mn,minn[r]);
			mx=max(mx,maxn[r]);
			if(mn<l) break;
			if(mx>r) continue;
			ans++;
		}
	}
	printf("%lld",ans);
	return 0;
}
