#include<bits/stdc++.h>
// #define int long long
// #define uint unsigned long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define mod 1000000007
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
	a=a+b>=mod?a+b-mod:a+b;
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=1ll*res*a%mod;
        a=1ll*a*a%mod;b>>=1;
    }
    return res;
}
int n,m,ans,fac[N],inv[N],f[610][310][310][2];
il void init(){
    fac[0]=1;
    for(int i=1;i<N;++i) fac[i]=1ll*fac[i-1]*i%mod;
    inv[N-1]=Pow(fac[N-1],mod-2);
    for(int i=N-1;i;--i) inv[i-1]=1ll*inv[i]*i%mod;
}
il int C(int a,int b){
    if(a<0||b<0||a<b) return 0;
    return 1ll*fac[a]*inv[b]%mod*inv[a-b]%mod;
}
il void solve(){
    ans=0;
    int mn=min(n,m<<1);
    f[0][0][0][0]=1;
    for(int i=0;i<=mn;++i) for(int j=0;j<=min(m,i);++j) for(int k=0;k<=j;++k) for(int o=0;o<2;++o) if(f[i][j][k][o]){
        if(k&&!o){
            Add(f[i+1][j][k-1][0],f[i][j][k][o]);
            Add(f[i+1][j][k][1],f[i][j][k][o]);
        }
        for(int h=i+1;h<=mn&&j+h-i<=m;++h) Add(f[h][j+h-i][k+h-i-1][0],f[i][j][k][o]);
    }
    for(int i=1;i<=mn;++i) for(int j=1;j<=min(m,i);++j)
        Add(ans,1ll*C(n-1,i-1)*C(m,j)%mod*fac[j]%mod*f[i][j][0][0]%mod);
    write(ans);
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
    init();
    // n=10;m=20;solve();
    // for(n=1;n<=10;++n) for(m=1;m<=10;++m) solve();
    n=read();m=read();
    solve();
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}