#include<bits/stdc++.h>
#define int long long
#define uint unsigned long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 300010
#define mod 1000000007
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
	a=a+b>=mod?a+b-mod:a+b;
}
int n,m,mn[N],mx[N],nxt[N],ans;
stack<int> S;
struct BIT{
    int sum[N];
    il int lowbit(int x){
        return x&-x;
    }
    il void add(int x,int k){
        for(;x<=n;x+=lowbit(x)) sum[x]+=k;
    }
    il int query(int x){
        int res=0;
        for(;x;x-=lowbit(x)) res+=sum[x];
        return res;
    }
} BT;
il void solve(int l,int r){
	if(l>r) return;
	int mid=(l+r)>>1;
    vector<int> V;
	for(int i=mid,MN=inf,MX=0,MX_=0,now=mid;i>=l;--i){
		MN=min(MN,mn[i]);MX=max(MX,mx[i]);
        while(now<=r&&mn[now]>=i){
            MX_=max(MX_,mx[now]);
            if(MX_==now){
                BT.add(now,1);V.pk(now);
            }
            ++now;
        }
		if(MN==i){
			int L=MX,R=nxt[i]-1;
            // cerr<<i<<" "<<L<<" "<<R<<"\n";
			Add(ans,BT.query(R)-BT.query(L-1));
		}
	}
    for(auto x:V) BT.add(x,-1);
    V.clear();
	solve(l,mid-1);solve(mid+1,r);
}
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i) mn[i]=mx[i]=i;
	while(m--){
		int u=read(),v=read();
		mn[u]=min(mn[u],v);mx[u]=max(mx[u],v);
	}
    // for(int i=1;i<=n;++i) cerr<<mn[i]<<" ";
	for(int i=n;i;--i){
		while(!S.empty()&&mn[S.top()]>=mn[i]) S.pop();
		if(!S.empty()) nxt[i]=S.top();
		else nxt[i]=n+1;
        S.push(i);
        // cerr<<nxt[i]<<" ";
	}
	solve(1,n);
	write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}