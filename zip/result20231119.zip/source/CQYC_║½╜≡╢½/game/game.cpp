#include<bits/stdc++.h>
#define int long long
// #define uint unsigned long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 3010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Mn(int &a,int b){
    a=min(a,b);
}
int n,K,dp[2][N][N],MN[N][N],a[N],b[N],ans=inf;
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    n=read();K=read();
    if(K<<1>n*2-1){
        write(inf);return 0;
    }
    for(int i=1;i<=n;++i) a[i]=read();
    for(int i=1;i<=n;++i) b[i]=read();
    memset(dp,0x3f,sizeof(dp));
    dp[0][0][0]=0;
    int l=0;
    for(int k=1;k<=K<<1;++k,l^=1){
        if(l){
            for(int i=0;i<=n;++i){
                for(int j=0;j<=n;++j){
                    MN[i][j]=dp[l][i][j];
                    if(i) Mn(MN[i][j],MN[i-1][j]);
                }
            }
        }
        else{
            for(int i=0;i<=n;++i){
                for(int j=0;j<=n;++j){
                    MN[i][j]=dp[l][i][j];
                    if(j) Mn(MN[i][j],MN[i][j-1]);
                }
            }
        }
        for(int i=0;i<=n;++i){
            for(int j=0;j<=n;++j){
                dp[l^1][i][j]=inf;
                if(!l){
                    if(!i) continue;
                    dp[l^1][i][j]=MN[i-1][j]+a[i];
                }
                else{
                    if(j<i||!j) continue;
                    dp[l^1][i][j]=MN[i][j-1]+b[j];
                }
                // if(dp[l^1][i][j]<inf) cout<<k<<" "<<i<<" "<<j<<" "<<dp[l^1][i][j]<<"\n";
            }
        }
    }
    for(int i=0;i<=n;++i) for(int j=0;j<=n;++j){
        // if(dp[l][i][j]==0) cerr<<l<<" "<<i<<" "<<j<<"\n";
        Mn(ans,dp[l][i][j]);
    }
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}