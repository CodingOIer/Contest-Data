#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int a[15];
int n,m,ans=0;
void dfs(int x) {
	if(x==n+1) {
		int last[15],sum[15][15];
		memset(last,0,sizeof last);
		memset(sum,0,sizeof sum);
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				sum[i][j]=sum[i-1][j]+(j==a[i]);
			}
			if(last[a[i]]) {
				for(int j=1;j<=m;j++) {
					if(a[i]==j) continue;
					if(sum[i][j]!=sum[last[a[i]]][j] && sum[last[a[i]]][j]>0) {
						return ;
					}
				}
			}
			last[a[i]]=i;
		}
		ans++;
		return ;
	}
	for(int i=1;i<=m;i++) {
		a[x]=i;
		dfs(x+1);
	}
}
signed main() {
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	dfs(1);
	printf("%lld\n",ans);
	return 0;
}
/*
10 20
7 5
9 9
3 5
4 5
8 9
4 5
2 1
8 9
1 4
10 9
4 5
3 5
6 6
1 3
2 3
9 8
7 5
4 5
4 5
9 9

*/
