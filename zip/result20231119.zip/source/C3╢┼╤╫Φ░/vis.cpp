#include<bits/stdc++.h>
using namespace std;
int head[600005],to[600005],nxt[600005],tot;
int vis[600005];
int n,m;
struct node {
	int l,r;
}a[600005];
void add(int x,int y) {
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
void dfs(int x) {
	vis[x]=1;
	a[x].l=x;
	a[x].r=x;
	for(int i=head[x];i;i=nxt[i]) {
		if(vis[to[i]]) {
			a[x].l=min(a[x].l,a[to[i]].l);
			a[x].r=max(a[x].r,a[to[i]].r);
			continue;
		}
		dfs(to[i]);
		a[x].l=min(a[x].l,a[to[i]].l);
		a[x].r=max(a[x].r,a[to[i]].r);
	}
} 
struct tree {
	#define ls (x<<1)
	#define rs ((x<<1)|1)
	#define mid ((l+r)>>1)
	int Max[1000005],Min[1000005];
	void build(int x,int l,int r) {
		if(l==r) {
			Max[x]=l;
			Min[x]=l;
			return ;
		}
		build(ls,l,mid);
		build(rs,mid+1,r);
		Max[x]=max(Max[ls],Max[rs]);
		Min[x]=min(Min[ls],Min[rs]);
	}
	void modifyMax(int x,int l,int r,int L,int R,int k) {
		if(L<=l && r<=R) {
			Max[x]=k;
			return ;
		}
		if(L<=mid) modifyMax(ls,l,mid,L,R,k);
		if(mid<R) modifyMax(rs,mid+1,r,L,R,k);
		Max[x]=max(Max[ls],Max[rs]);
		Min[x]=min(Min[ls],Min[rs]);
	}
	void modifyMin(int x,int l,int r,int L,int R,int k) {
		if(L<=l && r<=R) {
			Min[x]=k;
			return ;
		}
		if(L<=mid) modifyMin(ls,l,mid,L,R,k);
		if(mid<R) modifyMin(rs,mid+1,r,L,R,k);
		Min[x]=min(Min[ls],Min[rs]);
		Max[x]=max(Max[ls],Max[rs]);
	}
	int queryMax(int x,int l,int r,int L,int R) {
		int res=0;
		if(L<=l && r<=R) return Max[x];
		if(L<=mid) res=max(res,queryMax(ls,l,mid,L,R));
		if(mid<R) res=max(res,queryMax(rs,mid+1,r,L,R));
		Max[x]=max(Max[ls],Max[rs]);
		return res;
	}
	int queryMin(int x,int l,int r,int L,int R) {
		int res=1e9;
		if(L<=l && r<=R) return Min[x];
		if(L<=mid) res=min(res,queryMin(ls,l,mid,L,R));
		if(mid<R) res=min(res,queryMin(rs,mid+1,r,L,R));
		Min[x]=min(Min[ls],Min[rs]);
		return res;
	}
}T;
struct bitree {
	int sum[600005];
	int lowbit(int x) {
		return x&(-x);
	}
	void add(int x,int y) {
		for(int i=x;i<=n;i+=lowbit(i)) sum[i]+=y;
	}
	int query(int x) {
		int res=0;
		for(int i=x;i>=1;i-=lowbit(i)) res+=(sum[i]>0);
		return res;
	}
}Tr;
bool cmp(node x,node y) {
	if(x.l==y.l) return x.r<y.r;
	return x.l>y.l;
}
vector<int> q[600005];
int p[600005];
int f[(1<<20)];
int main() {
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++) {
		int x,y;
		scanf("%d %d",&x,&y);
		add(x,y);
	}
	for(int i=1;i<=n;i++) if(!vis[i]) dfs(i);
	T.build(1,1,n);
	for(int i=1;i<=n;i++) {
		int t;
		t=T.queryMin(1,1,n,a[i].l,i);
		a[i].l=t;
		T.modifyMin(1,1,n,i,i,a[i].l);
	}
	for(int i=n;i>=1;i--) {
		int t;
		t=T.queryMax(1,1,n,i,a[i].r);
		a[i].r=t;
		T.modifyMax(1,1,n,i,i,a[i].r);
	}
	int ans=0;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++) {
		q[a[i].l].push_back(a[i].r);
		p[i]=n+1;
	}
	if(n<=20) {
		f[0]=1;
		for(int i=0;i<(1<<n);i++) {
			for(int j=1;j<=n;j++) {
				int w=i;
				for(int k=a[j].l;k<=a[j].r;k++) {
					w|=(1<<(k-1));
				}
				f[w]|=f[i]; 
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++) {
			int sum=0;
			for(int j=i;j<=n;j++) {
				sum+=(1<<(j-1));
				if(f[sum]) {
					ans++;
				}
			} 
		} 
		printf("%d\n",ans);
		return 0;
	}
	memset(vis,0,sizeof vis);
	for(int i=n;i>=1;i--) {
		int len=q[i].size();
		for(int j=0;j<q[i].size();j++) {
			p[q[i][j]]=i;
			for(int k=q[i][j];k<=n;k++) {
				if(!vis[k] && q[i][j]+1>=p[k]) {
					p[k]=i;
					vis[k]++;
					ans++;
				}
			}			 
		}
		for(int k=1;k<=n;k++) vis[k]=0;
	}
	printf("%d\n",ans);
	return 0;
}
/*
10 20
7 5
9 9
3 5
4 5
8 9
4 5
2 1
8 9
1 4
10 9
4 5
3 5
6 6
1 3
2 3
9 8
7 5
4 5
4 5
9 9
*/
