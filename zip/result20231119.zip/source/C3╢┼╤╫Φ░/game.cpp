#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int a[200005],b[200005],n,m,minn=1e9;

void dfs(int x,int s1,int s2,int sum) {
	if(x==2*m+1) {
		minn=min(minn,sum);
		return ;
	}
	if(x%2==1) {
		for(int i=s1;i<=n;i++) {
			dfs(x+1,i+1,s2,sum+a[i]);
		}
	} else {
		for(int i=max(s1-1,s2);i<=n;i++) {
			dfs(x+1,s1,i+1,sum+b[i]);
		}
	}
}
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=n;i++) {
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=n;i++) {
		scanf("%lld",&b[i]);
	}
	dfs(1,1,1,0);
	printf("%lld\n",minn);
	return 0;
}
/*
10 20
7 5
9 9
3 5
4 5
8 9
4 5
2 1
8 9
1 4
10 9
4 5
3 5
6 6
1 3
2 3
9 8
7 5
4 5
4 5
9 9

*/
