#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,K,a[100005],b[100005],dp[205][305][305],mn[205][305][305],ans=1e18;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),K=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++) b[i]=read();
    memset(dp,0x3f,sizeof(dp));
    memset(mn,0x3f,sizeof(mn));
    dp[0][0][0]=0;
    for(int i=0;i<=(K<<1);i++){
        if(i&1){
            for(int j=0;j<=n;j++){
                for(int g=0;g<=n;g++){
                    if(j) mn[i][j][g]=min(mn[i][j][g],mn[i][j-1][g]);
                    dp[i][j][g]=min(dp[i][j][g],mn[i][j][g])+a[j];
                }
            }
        }
        else{
            for(int j=0;j<=n;j++){
                for(int g=0;g<=n;g++){
                    if(g) mn[i][j][g]=min(mn[i][j][g],mn[i][j][g-1]);
                    dp[i][j][g]=min(dp[i][j][g],mn[i][j][g])+b[g];
                }
            }
        }
        for(int j=0;j<=n;j++){
            for(int g=0;g<=n;g++){
                if(i&1){
                    mn[i+1][j][max(j,g+1)]=min(mn[i+1][j][max(j,g+1)],dp[i][j][g]);
                }
                else{
                    mn[i+1][j+1][g]=min(mn[i+1][j+1][g],dp[i][j][g]);
                }
            }
        }
    }
    for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) ans=min(ans,dp[K<<1][i][j]);
    cout<<ans;
    return 0;
}