#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,m,t1,t2,cnt,head[600005],nxt[600005],txt[600005],ans,mn[600005],v[600005];
queue<int> q;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
    }  
    for(int i=1;i<=n;i++) mn[i]=i;
    for(int i=1;i<=n;i++){
        int d=i,sz=0;
        while(d<=n){
            // cerr<<i<<" "<<d<<" "<<v[d]<<"\n";
            q.push(d);
            v[d]=i;
            // cerr<<n<<" "<<d<<" "<<v[d]<<" "<<i<<"\n";
            while(v[d]==i) d++;
            
            while(!q.empty()){
                int t=q.front();q.pop();sz++;
                for(int j=head[t];j;j=nxt[j]){
                    if(v[txt[j]]!=i){
                        if(mn[txt[j]]<i){
                            mn[i]=mn[txt[j]];
                            goto FLAG;
                        }
                        v[txt[j]]=i;
                        while(v[d]==i) d++;
                        q.push(txt[j]);
                    }
                }
            }
            if(d==(i+sz)) ans++;
        }
        FLAG:
        while(!q.empty()) q.pop();
        ans=ans;    
    }
    cout<<ans;
    return 0;
}