#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,m,dp[2][305][305],ans=0,s[2][305][305],S[1000005],inv[1000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
signed main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    S[0]=inv[0]=1;
    for(int i=1;i<=1000000;i++) S[i]=(S[i-1]*i)%M;
    inv[1000000]=ksm(S[1000000],M-2);
    for(int i=999999;i>=0;i--) inv[i]=(inv[i+1]*(i+1))%M;
    n=read(),m=read();
    memset(dp,0,sizeof(dp));
    dp[1][1][1]=m;
    for(int i=1;i<=n;i++){
        int t=i&1;
        for(int j=1;j<=min(i+1,m);j++) for(int g=1;g<=min(i+1,m);g++) dp[t^1][j][g]=s[t^1][j][g]=0;
        for(int j=1;j<=min(i,m);j++){
            for(int g=min(i,m)-1;g>=1;g--) add(s[t][g][j],s[t][g+1][j]);
        }
        for(int j=1;j<=min(i,m);j++){
            for(int g=1;g<=min(i,m);g++){
                add(dp[t][j][g],s[t][j][g]);
                add(dp[t^1][j][g],dp[t][j][g]);
                add(dp[t^1][j+1][g+1],dp[t][j][g]*(m-g)%M);
                add(s[t^1][j-1][g],dp[t][j][g]);
            }
        }
    }
    ans=0;
    for(int i=1;i<=min(n,m);i++) for(int j=1;j<=min(n,m);j++) add(ans,dp[n&1][i][j]);
    cout<<ans<<" ";
    return 0;
}