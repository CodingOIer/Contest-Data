#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,M,L[Maxn],R[Maxn],A[Maxn],Col[Maxn],Ans;
bool Vis[Maxn];
map<int,int> Map;

void DFS(int x){
    if(x>M){
        int ret=0;
        For(i,1,N) Col[i]=0;
        For(i,1,M){
            int c=A[i];
            For(j,L[c],R[c]) if(!Col[j]) Col[j]=c;
        }
        For(i,1,N) if(!Col[i]) return;
        For(i,1,N) ret=ret*(M+1)+Col[i];
        if(!Map[ret]) Map[ret]=1,++Ans;
        return;
    }
    For(i,1,M) if(!Vis[i]){
        Vis[i]=1,A[x]=i;
        For(l,1,N) For(r,l,N) L[i]=l,R[i]=r,DFS(x+1);
        Vis[i]=0;
    }
}

int main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    N=read(),M=read(); DFS(1); write(Ans);
    return 0;
}
/*
g++ life.cpp -o life -O2
./life
*/