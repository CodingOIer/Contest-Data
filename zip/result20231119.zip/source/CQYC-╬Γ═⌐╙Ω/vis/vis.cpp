#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=3e5+10,P=1e9+7;
int N,M,u,v,Mx[Maxn],Mn[Maxn],Ans;
int T0[27][Maxn],T1[27][Maxn];
vector<int> G[Maxn];
bool Vis[Maxn],flag;

void DFS(int x,int t){
    Mx[t]=max(Mx[t],x),Mn[t]=min(Mn[t],x);
    Vis[x]=1;
    for(int y:G[x]) if(!Vis[y]) DFS(y,t);
}

void Build(){
    For(i,1,N) T0[0][i]=Mn[i],T1[0][i]=Mx[i];
    For(i,1,20){
        For(j,1,N-(1<<i)+1){
            T0[i][j]=min(T0[i-1][j],T0[i-1][j+(1<<(i-1))]);
            T1[i][j]=max(T1[i-1][j],T1[i-1][j+(1<<(i-1))]);
        }
    }
}

int QMn(int l,int r){
    int len=r-l+1,lg=log2(len);
    return min(T0[lg][l],T0[lg][r-(1<<lg)+1]);
}

int QMx(int l,int r){
    int len=r-l+1,lg=log2(len);
    return max(T1[lg][l],T1[lg][r-(1<<lg)+1]);
}

void Get(int l,int r){
    if(l>r) return;
    if(QMn(l,r)<l) return;
    if(QMx(l,r)>r) Get(l,QMx(l,r));
    else ++Ans,Get(l,Mx[r+1]);
}

void Solve1(){
    memset(Mn,0x3f,sizeof Mn);
    For(i,1,N){
        For(j,1,N) Vis[j]=0;
        DFS(i,i);
    }
    Build();
    For(i,1,N)  Get(i,Mx[i]);
    write(Ans);
}

signed main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    N=read(),M=read();
    For(i,1,M){
        u=read(),v=read(),G[u].pb(v);
        if(u<=v) flag=1;
    }
    if(!flag&&M==N-1) write(N),exit(0);
    if(N<=2000) Solve1(),exit(0);
    return 0;
}
/*
g++ vis.cpp -o vis -O2
./vis
*/