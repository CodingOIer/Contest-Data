#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,INF=1e18;
int N,K,A[Maxn],B[Maxn],f[110][310][310],Ans=INF;

void Min(int &x,int y){if(y<x) x=y;}

void Solve1(){
    For(i,0,K*2) For(j,0,N) For(k,0,N) f[i][j][k]=INF;
    f[0][0][0]=0;
    For(i,0,K*2-1){
        For(j,0,N) For(k,0,N) if(f[i][j][k]<INF){
            if(i&1) For(t,max(k+1,j),N) Min(f[i+1][j][t],f[i][j][k]+B[t]);
            else For(t,j+1,N) Min(f[i+1][t][k],f[i][j][k]+A[t]);
        }
    }
    For(i,1,N) For(j,1,N) Min(Ans,f[K*2][i][j]);
    write(Ans);
}

signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    N=read(),K=read();
    For(i,1,N) A[i]=read(); For(i,1,N) B[i]=read();
    Solve1();
    return 0;
}
/*
g++ game.cpp -o game -O2
./game
*/