#include <bits/stdc++.h>
#define int long long
#define N 300005
using namespace std;
int n, m, ans;
bool vis[N];
vector<int>p[N];
int l, r;
int sum = 0;
bool h[N];
void dfs(int x) {
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(!vis[y]) {
			vis[y] = 1;
			if(y < l || y > r) {
				h[y] = 1;
				sum++;
			}
			dfs(y);
		}
	}
}
signed main() {
	freopen("vis.in", "r", stdin);
	freopen("vis.out", "w", stdout);
	scanf("%lld %lld", &n, &m);
	for(int i = 1, u, v; i <= m; i++) {
		scanf("%lld %lld", &u, &v);
		p[u].push_back(v);
	}
	int g = n;
	if(n > 2000) g = 1;
	for(l = 1; l <= g; l++) {
		for(int i = 1; i <= n; i++) vis[i] = h[i] = 0;
		sum = 0;
		for(r = l; r <= n; r++) {
			vis[r] = 1;
			dfs(r);
			if(h[r]) {
				h[r] = 0;
				sum--;
			}
			if(sum == 0) ans++;
		}
	}
	cout << ans;
	return 0;
}






