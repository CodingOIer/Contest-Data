#include <bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n, k;
int a[N], b[N];
int f[310][310][110][2];
int dfs(int A, int B, int dep, int opt) {
	if(f[A][B][dep][opt] != 0) return f[A][B][dep][opt];
	if(dep == 2 * k + 1) return 0;
	int ans = 1e18;
	if(opt == 1) { 
		for(int i = A + 1; i <= n; i++) ans = min(ans, dfs(i, B, dep + 1, 0) + a[i]);
		return f[A][B][dep][opt] = ans;
	}
	else {
		for(int i = max(A, B + 1); i <= n; i++) ans = min(ans, dfs(A, i, dep + 1, 1) + b[i]);
		return f[A][B][dep][opt] = ans;
	}
}
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%lld %lld", &n, &k);
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1; i <= n; i++) scanf("%lld", &b[i]);
	if(n <= 100) printf("%lld", dfs(0, 0, 1, 1));
	else {
		sort(a + 1, a + n + 1);
	    sort(b + 1, b + n + 1);
	    int ans = 0;
	    for(int i = 1; i <= k; i++) ans += a[i] + b[i];
	    cout << ans;
	}
	return 0;
}


