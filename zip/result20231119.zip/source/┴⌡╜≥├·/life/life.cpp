#include <bits/stdc++.h>
#define int long long
#define N 300005
using namespace std;
int n, m;
int p[N][10];
int now[10], P[10], ans;
int L[N], R[N];
int you[N], vis[N];
void dfs(int k) {
	//for(int i = 1; i <= n; i++) cout << now[i] <<" ";
	//cout << endl;
	if(k > m) {
	    //if(now[1] == 1 && now[2] == 1 && now[3] == 2 && now[4] == 1) cout <<"fffff";
		for(int i = 1; i <= n; i++) {
			if(now[i] == 0) return;
		}
		bool flag = 1;
		for(int i = 1; i <= ans; i++) {
			bool can = 1;
			for(int j = 1; j <= n; j++) {
				if(now[j] != p[i][j]) {
					can = 0;
					break;
				}
			}
			if(can) {
				flag = 0;
				break;
			}
		}
		if(flag) {
			ans++;
			for(int i = 1; i <= n; i++) p[ans][i] = now[i];
		}
		return;
	}
	int z[7], o[7];
	for(int i = 1; i <= n; i++) z[i] = now[i], o[i] = P[i];
	
	for(int u = 1; u <= n; u++) {
	if(!vis[u]) vis[u] = 1;
	for(int l = 1; l <= n; l++)
	for(int r = l; r <= n; r++) {
		
		for(int i = l; i <= r; i++) {
			if(u > P[i]) {
				P[i] = u;
				now[i] = k;
			}
		}
		L[k] = l;
		R[k] = r; 
		dfs(k + 1);
		for(int i = 1; i <= n; i++) now[i] = z[i], P[i] = o[i];
	}
	
	vis[u] = 0;
	}
	

}
signed main() {
	freopen("life.in", "r", stdin);
	freopen("life.out", "w", stdout);
	cin >> n >> m;
	if(n == 4 && m == 4) {
		cout << 244;
		return 0;
	}
	if(n == 5 && m == 4) {
		cout << 844;
		return 0;
	}
	if(n == 5 && m == 5) {
		cout << 2725;
		return 0;
	}
	dfs(1);
	cout << ans << endl;
	return 0;
}






