#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 1e9 + 7;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

char qqq;

const int N = 3e5 + 1000;

int n, m, L[N], R[N];
int lg[N], f[18][N], g[18][N];
pii a[N], b[N], c[N]; int cnt1, cnt2;
i64 ans;

int t[N];
void Add(int x, int y) { for (; x <= n; x += x & -x) t[x] += y; }
int ask(int x, int y = 0) { for (; x; x -= x & -x) y += t[x]; return y; } 

char qqqq;
signed main() {
	freopen("vis.in", "r", stdin);
	freopen("vis.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    n = read(), m = read();
    For(i, 1, n) L[i] = R[i] = i;
    For(i, 1, m) {
        int u = read(), v = read();
        Min(L[u], v), Max(R[u], v);
    }
    For(i, 2, n) lg[i] = lg[i >> 1] + 1;

    For(i, 1, n) f[0][i] = L[i], g[0][i] = R[i];
    
    For(i, 1, lg[n]) For(j, 1, n + 1 - (1 << i)) {
        f[i][j] = min(f[i - 1][j], f[i - 1][j + (1 << (i - 1))]);
        g[i][j] = max(g[i - 1][j], g[i - 1][j + (1 << (i - 1))]);
    }

    For(i, 1, n) { 
        int p = i; Rof(k, lg[n - i + 1], 0) 
        if (p + (1 << k) - 1 <= n && f[k][p] >= i) p += 1 << k; 
        if (p > i) a[++cnt1] = pii(i, p - 1);
    }
    
    For(i, 1, n) { 
        int p = i;  Rof(k, lg[i], 0) 
        if (p - (1 << k) + 1 >= 1 && g[k][p - (1 << k) + 1] <= i) p -= 1 << k;
        if (p < i) b[++cnt2] = pii(p + 1, i);
    }For(i, 1, cnt2) c[i] = b[i];
    sort(a + 1, a + cnt1 + 1), sort(b + 1, b + cnt2 + 1);

    for (int i = 1, j = 0, k = 0; i <= cnt1; ++i) {
        while (j < cnt2 && b[j + 1].first <= a[i].first) Add(b[++j].second, 1);
        while (k < cnt2 && c[k + 1].second < a[i].first) Add(c[++k].second, -1);
        ans += ask(a[i].second);
    }  
    cout << ans % mod;
	return 0;
}
