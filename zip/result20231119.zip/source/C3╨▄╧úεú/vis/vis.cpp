#include <bits/stdc++.h>

#define rep(i, a, b) for (int i(a); i <= (b); i++)
#define _rep(i, a, b) for (int i(a); i >= (b); i--)

typedef long long ll;

using namespace std;

#define int ll

function <int (void)> read = []() {
    int w = 0, f = 1;
    char ch = getchar();
    while (!isdigit(ch)) {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (isdigit(ch)) {
        w = (w << 3) + (w << 1) + (ch ^ 48);
        ch = getchar();
    }
    return w * f;
};

function <void (int)> print = [](int x) {
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) print(x / 10);
    putchar(x % 10 + 48);
};

const int MAXN = 2005, MOD = 1e9 + 7;
int n, m;
vector <int> G[MAXN];
set <int> arrv[MAXN];
int lim[2][MAXN];

bitset <MAXN> vis;

signed main() {
#ifndef LOCAL
    freopen("vis.in", "r", stdin);
    freopen("vis.out", "w", stdout);
#endif
    n = read(), m = read();
    memset(lim[0], 0x3f, sizeof lim[0]);
    rep (i, 1, m) {
		int u = read(), v = read();
		G[u].emplace_back(v);
    }
    function <void (int)> dfs = [&](int u) {
        if (vis[u]) return;
        vis[u] = 1;
        for (auto v : G[u]) {
            dfs(v);
        }
    };
    rep (i, 1, n) {
        vis.reset();
        dfs(i);
        rep (j, 1, n) {
            if (vis[j]) lim[0][i] = min(lim[0][i], j), lim[1][i] = max(lim[1][i], j);
        }
    }
    int ans = 0;
	rep (i, 1, n) {
        int l = 0x3f3f3f3f3f3f3f3f, r = 0;
		rep (j, i, n) {
            l = min(l, lim[0][j]), r = max(r, lim[1][j]);
            if (l >= i && r <= j) ans++;
            if (ans >= MOD) ans -= MOD;
		}
	}
    print(ans);
    return 0;
}