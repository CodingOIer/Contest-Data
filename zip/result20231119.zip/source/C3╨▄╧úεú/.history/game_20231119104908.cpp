#include <bits/stdc++.h>

#define rep(i, a, b) for (int i(a); i <= (b); i++)
#define _rep(i, a, b) for (int i(a); i >= (b); i--)

typedef long long ll;

using namespace std;

#define int ll

int read() {
    int w = 0, f = 1;
    char ch = getchar();
    while (!isdigit(ch)) {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (isdigit(ch)) {
        w = (w << 3) + (w << 1) + (ch ^ 48);
        ch = getchar();
    }
    return w * f;
}

void print(int x) {
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) print(x / 10);
    putchar(x % 10 + 48);
}

const int MAXN = 1e5 + 5, MOD = 1e9 + 7;
int n, k;
int a[MAXN], b[MAXN];

mt19937 rnd(time(0));

int r

signed main() {
#ifndef LOCAL
    freopen("life.in", "r", stdin);
    freopen("life.out", "w", stdout);
#endif
    n = read(), k = read();
    rep (i, 1, n) a[i] = read();
    rep (i, 1, n) b[i] = read();

    return 0;
}