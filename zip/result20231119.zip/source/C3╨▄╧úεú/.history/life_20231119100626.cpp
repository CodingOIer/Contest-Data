#include <bits/stdc++.h>

#define rep(i, a, b) for (int i(a); i <= (b); i++)
#define _rep(i, a, b) for (int i(a); i >= (b); i--)

typedef long long ll;

using namespace std;

#define int ll

int read() {
    int w = 0, f = 1;
    char ch = getchar();
    while (!isdigit(ch)) {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (isdigit(ch)) {
        w = (w << 3) + (w << 1) + (ch ^ 48);
        ch = getchar();
    }
    return w * f;
}

void print(int x) {
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) print(x / 10);
    putchar(x % 10 + 48);
}

const int MAXN = 105, MOD = 1e9 + 7;
int n, m;
pair <int, int> arr[MAXN];
int stat[MAXN];
set <string> s;

void dfs(int step) {
    if (step > m) {
        memset(stat, 0x3f, sizeof stat);
        rep (i, 1, m) {
            rep (j, arr[i].first, arr[i].second) {
                stat[j] = i;
            }
        }
        rep (i, 1, n) {
            if (stat[i] == 0x3f3f3f3f3f3f3f3f) return;
        }
        stringstream ss;
        rep (i, 1, n) ss << stat[i];
        s.insert(ss.str());
        return;
    }
    rep (i, 1, n) {
        rep (j, i, n) {
            arr[step] = make_pair(i, j);
            dfs(step + 1);
        }
    }
}

signed main() {
#ifndef LOCAL
    freopen("life.in", "r", stdin);
    freopen("life.out", "w", stdout);
#endif
    n = read(), m = read();
    dfs(1);
    print(s.size()), putchar(10);
    for (auto str : s) cout << str << endl;
    return 0;
}