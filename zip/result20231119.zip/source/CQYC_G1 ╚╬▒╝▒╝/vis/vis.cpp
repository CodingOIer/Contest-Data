#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 3e5+5 ;
const int MOD = 1e9+7 ;
int n,top,m,idx,cnt,mx,mex,top1,mi,id[N] ;
int you[N],st1[N],er[N],sc[N],UU[N<<1],VV[N<<1] ;
int st[N],in[N],low[N],dfn[N],of[N],vis[N],us[N] ;
random_device r ;
mt19937 rd(r()) ;
long long ans ;
vector<int>e[N],g[N],jd[N] ;
vector<int>qd[N] ; set<int>s ;
void Solve(int x,int fa)
{
	in[x] = 1,st[++top] = x,dfn[x] = low[x] = ++idx ;
	for(auto v:e[x])
		if(!dfn[v]) Solve(v,x),low[x] = min(low[x],low[v]) ;
		else if(in[v]) low[x] = min(low[x],dfn[v]) ;
	if(dfn[x] == low[x])
	{
		++cnt,qd[cnt].pb(x),in[x] = 0 ;
		while(st[top] != x && top) in[st[top]] = 0,qd[cnt].pb(st[top]),--top ;
		--top ;
	}
}
void Insert(int x)
{
    st1[++top1] = x,vis[x] = 1 ; for(auto pos:qd[x]) us[pos] = 1,mx  = max(mx,pos) ;
    for(auto v:g[x]) if(!vis[v]) Insert(v) ;
}
void Erase(int x)
{
    sc[x] = 1 ; for(auto v:qd[x]) er[v] = 1 ;
    for(auto v:jd[x]) if(!sc[v]) Erase(v) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("vis.in","r",stdin) ;
	freopen("vis.out","w",stdout) ;
    read(n,m) ; int tot = 0 ;
    FOR(i,1,m,1) read(UU[i],VV[i]),tot += UU[i]<VV[i] ;
    if(2*tot > m) FOR(i,1,m,1) UU[i] = n-UU[i]+1,VV[i] = n-VV[i]+1 ;
    FOR(i,1,m,1) e[UU[i]].pb(VV[i]) ;
    // FOR(i,1,m,1)
    // {
    //     int u,v ; read(u,v) ; u = n-u+1,v = n-v+1 ;
    //     e[u].pb(v) ;
    // }
    FOR(i,1,n,1) if(!dfn[i]) Solve(i,0) ;
    FOR(i,1,cnt,1) for(auto pos:qd[i]) of[pos] = i ;
    FOR(i,1,cnt,1)
    {
        for(auto poin:qd[i])
        {
            for(auto v:e[poin]) if(of[v] != of[poin])
                g[i].pb(of[v]),jd[of[v]].pb(i) ;
        }
    }
    mi = n ;
    // FOR(i,1,n,1) id[i] = i ;// shuffle(id+1,id+1+n,rd) ;
    FOR(i,1,n,1)
    {
        // int i  = id[kp] ;
        if(sc[of[i]]) continue ;
        mx = 0,mex = i,top1 = 0 ;
        for(int j = i ; j <= n ; j = mex)
        {
            if(us[j]) continue ; if(er[j]) break ;
            Insert(of[j]) ; while(us[mex]) ++mex ;
            if(mex == mx+1) ++ans ;
        }
        FOR(j,1,top1,1)
        {
            int x = st1[j] ; vis[x] = 0 ;
            for(auto pos:qd[x]) us[pos] = 0 ;
        }
        Erase(of[i]) ; //print(i),enter ; // cerr<<"!\n" ;
    }
    print(ans),enter ;
    // cerr<<(double)clock()/CLOCKS_PER_SEC<<"\n" ;
    return 0 ;
}