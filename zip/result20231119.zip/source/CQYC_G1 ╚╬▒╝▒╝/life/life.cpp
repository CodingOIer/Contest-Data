#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 75 ;
const int M = 1e6+5 ;
const int MOD = 1e9+7 ;
int n,m,ans ;
int f[2][N][N],fac[M],inv[M],sum[N] ;
void Init()
{
    fac[0] = inv[0] = inv[1] = 1 ;
    FOR(i,1,m,1) fac[i] = fac[i-1]*i%MOD ;
    FOR(i,2,m,1) inv[i] = (MOD-MOD/i)*inv[MOD%i]%MOD ;
    FOR(i,2,m,1) inv[i] = inv[i]*inv[i-1]%MOD ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("life.in","r",stdin) ;
	freopen("life.out","w",stdout) ;
    read(n,m),Init(),f[0][0][0] = 1 ;
    FOR(i,1,n,1)
    {
        int pos = i&1 ;
        FOR(j,0,min(n,m),1) f[pos][j][0] = 0 ;
        FOR(j,0,min(n,m),1) FOR(l,1,n,1) f[pos][j][l] = f[!pos][j][l-1] ;
        ROF(j,min(n,m)-1,0,1) 
        {
            me(sum,0) ;
            FOR(l,1,n,1) sum[l-1] = f[pos][j][l] ;  
            ROF(l,n-1,0,1) (sum[l] += sum[l+1]) %= MOD ;
            FOR(l,0,n,1) (f[pos][j+1][l] += sum[l]) %= MOD ;
        }
    }
    FOR(i,1,min(n,m),1) (ans += f[n&1][i][0]*fac[m]%MOD*inv[m-i]%MOD) %= MOD ; print(ans),enter ;
    return 0 ;
}