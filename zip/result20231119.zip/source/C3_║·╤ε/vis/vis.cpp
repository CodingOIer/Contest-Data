#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 510;
const int mod = 1e9 + 7;
int n, m, ops, ans;
vector<int> Edge[Maxn];
int vis[Maxn];
void dfs(int x, int l, int r){
    if(ops == 1) return ;
    vis[x] = 1;
    for(auto to : Edge[x]){
        if(to < l || to > r){
            ops = 1;
            return ;
        }
        if(!vis[to]) dfs(to, l, r);
    }
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("vis.in", "r", stdin);
    freopen("vis.out", "w", stdout);
    cin >> n >> m;
    for(int i = 1 ; i <= m ; i++){
        int x, y;
        cin >> x >> y;
        Edge[x].push_back(y);
    }
    for(int i = 1 ; i <= n ; i++){
        for(int j = i ; j <= n ; j++){
            ops = 0;
            for(int x = 1 ; x <= n ; x++) vis[x] = 1;
            for(int x = i ; x <= j ; x++){
                if(vis[x]) continue;
                dfs(x, i, j);
                if(ops) break;
            }
            if(!ops) ans++;
            if(ans >= mod) ans -= mod;
        }
    }
    cout << ans << '\n';
    return 0;
}