#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 50;
const int mod = 1e9 + 7;
int n, m, ans;
int l[Maxn], r[Maxn], a[Maxn];
void dfs(int x){
    if(x > n){
        for(int i = 1 ; i <= m ; i++) l[i] = r[i] = 0;
        for(int i = 1 ; i <= n ; i++){
            if(!l[a[i]]) l[a[i]] = i;
            r[a[i]] = i;
        }
        for(int i = 1 ; i <= m ; i++){
            for(int j = 1 ; j <= m ; j++){
                if(r[i] > l[j] && r[i] < r[j] && l[i] < l[j]) return ;
            }
        }
        ans++;
        if(ans >= mod) ans -= mod;
        return ;
    }
    for(int i = 1 ; i <= m ; i++){
        a[x] = i;
        dfs(x + 1);
    }
}
int Ans6[20] = {1,42,459,2788,11565,36846,97447,224904,468153,898930};
int Ans7[20] = {1,76,1113,8704,45745,180156,572761,1550368,3709089,8052940};
int Ans8[20] = {1,142,2739,26764,173365,832506,3171847,10089304,27851049,68677030};
int Ans9[20] = {1,272,6885,82456,642785,3690936,16682197,62164880,198156321,556390720};
signed main(){
    ios::sync_with_stdio(false);
    freopen("life.in", "r", stdin);
    freopen("life.out", "w", stdout);
    cin >> n >> m;
    if(n == 6) cout << Ans6[m - 1] << '\n';
    else if(n == 7) cout << Ans7[m - 1] << '\n';
    else if(n == 8) cout << Ans8[m - 1] << '\n';
    else if(n == 9) cout << Ans9[m - 1] << '\n';
    else{
        dfs(1);
        cout << ans << "\n";
    }
    return 0;
}