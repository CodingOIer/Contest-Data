#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 310;
const int inf = 1e18;
int n, k, ans = 1e18;
int a[Maxn], b[Maxn];
int s[Maxn];
void dfs(int x){
    if(x > 2 * k){
        int sum = 0;
        for(int i = 1 ; i <= 2 * k ; i++){
            if(i & 1) sum += a[s[i]];
            else sum += b[s[i]];
        }
        ans = min(ans, sum);
        return ;
    }
    if(x == 1){
        for(int i = 1 ; i <= n ; i++){
            s[x] = i;
            dfs(x + 1);
        }
    }
    else if(x == 2){
        for(int i = s[x - 1] ; i <= n ; i++){
            s[x] = i;
            dfs(x + 1);
        }
    }
    else if(x & 1){
        for(int i = s[x - 2] + 1 ; i <= n ; i++){
            s[x] = i;
            dfs(x + 1);
        }
    }
    else if(x % 2 == 0){
        int st;
        if(s[x - 1] > s[x - 2]) st = s[x - 1];
        else st = s[x - 2] + 1;
        for(int i = st ; i <= n ; i++){
            s[x] = i;
            dfs(x + 1);
        }
    }
}
int f[Maxn][Maxn][Maxn], g[Maxn][Maxn][Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    cin >> n >> k;
    for(int i = 1 ; i <= n ; i++) cin >> a[i];
    for(int i = 1 ; i <= n ; i++) cin >> b[i];
    if(k > n){
        cout << ans << '\n';
        return 0;
    }
    dfs(1);
    cout << ans << '\n';

    return 0;
}