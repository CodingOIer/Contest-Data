#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

int n, m, ans;

namespace sub1 {
    const int N = 310;
    
    int f[N][N], g[N][N];

    void main() {
        f[0][0] = 1;

        for(int i = 1; i <= n; i++) {
            for(int j = 0; j <= i; j++)
                for(int k = j; k + 1; k--) g[j][k] = f[j][k];

            for(int j = i; j + 1; j--)
                for(int k = j; k + 1; k--) {
                    if(k) inc(f[j][k - 1], f[j][k]); else f[j][k] = 0;
                    inc(f[j + 1][k + 1], 1ll * g[j][k] * (m - j) % mod);
                }
        }

        for(int i = 0; i <= min(n, m); i++)
            for(int j = 0; j <= i; j++) inc(ans, f[i][j]);
        
        write(ans);
    }
}

bool edmer;
signed main() {
	freopen("life.in", "r", stdin);
	freopen("life.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();

    sub1 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 