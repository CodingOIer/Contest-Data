#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e6 + 10;

struct node {
    int l, r;
    node operator + (const node &p) const { return { min(l, p.l), max(r, p.r) }; }
} a[N];

int n, m, cnt, top, ans;
int dfn[N], low[N], stk[N], col[N], d[N];

vector<int> e[N], E[N];

bool vis[N];

namespace Tarjan {
    void tarjan(int x) {
        dfn[x] = low[x] = ++cnt, stk[++top] = x, vis[x] = 1;
        for(int v : e[x]) {
            if(!dfn[v]) tarjan(v), Min(low[x], low[v]);
            else if(vis[v]) Min(low[x], dfn[v]);
        }
        if(dfn[x] == low[x]) {
            while(stk[top + 1] ^ x) {
                int p = stk[top--]; 
                a[x] = a[x] + a[p], vis[p] = 0, col[p] = x;
            }
        }
    }

    void work(int tot) {
        for(int i = 1; i <= tot; i++) {
            dfn[i] = low[i] = stk[i] = 0;
            if(!a[i].l) a[i] = (i <= n ? (node) { i, i } : (node) { n, 1 });
        }
        for(int i = 1; i <= tot; i++) if(!dfn[i]) tarjan(i);
    }
}

namespace Topu {
    void work(int tot) {
        queue<int> q;

        for(int i = 1; i <= tot; e[i++].clear()) for(int v : e[i])
            if(col[v] ^ col[i]) E[col[i]].push_back(col[v]), d[col[v]]++;

        for(int i = 1; i <= tot; i++) if(!d[i]) q.push(i);

        while(!q.empty()) {
            int x = q.front(); q.pop();
            for(int v : E[x]) {
                a[v] = a[v] + a[x];
                if(!(--d[v])) q.push(v);
            }
        }

        for(int i = 1; i <= tot; i++) a[i] = a[col[i]];
    }
}

namespace Sol {

    int t[N], top[2], stk[2][N], f[N], g[N];

    void mdi(int x, int k) { while(x <= n) t[x] += k, x += x & -x; }
    int ask(int x) { int res = 0; while(x) res += t[x], x -= x & -x; return res; }

    void work() {
        stk[1][0] = n + 1;
        for(int i = n; i; i--) {
            if(a[i].r == i) mdi(i, 1), vis[i] = 1; 
            while(top[0] and f[stk[0][top[0]]] < a[i].r) {
                int x = stk[0][top[0]--];
                if(vis[x]) mdi(x, -1);
            }
            stk[0][++top[0]] = i, f[i] = a[i].r;
            
            while(top[1] and g[stk[1][top[1]]] >= a[i].l) top[1]--;
            stk[1][++top[1]] = i, g[i] = a[i].l;

            while(top[1] and g[stk[1][top[1]]] >= i) top[1]--;

            inc(ans, ask(stk[1][top[1]] - 1));
        }
    }
}

bool edmer;
signed main() {
	freopen("vis.in", "r", stdin);
	freopen("vis.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    for(int i = 1; i <= m; i++) {
        int u = read(), v = read();
        e[v].push_back(u);
    }

    Tarjan :: work(n), Topu :: work(n), Sol :: work();

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 