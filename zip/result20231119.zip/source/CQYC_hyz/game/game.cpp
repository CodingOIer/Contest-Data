#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 3e5 + 10, M = 1e6 + 10, inf = 1e18;

int n, m, cnt, s, t, ans;
int a[N], b[N], cur[N], hed[N], nex[M], to[M], w[M], c[M], d[N];

bool vis[N];

void add(int u, int v, int x, int y) {
    nex[++cnt] = hed[u], hed[u] = cnt, to[cnt] = v, w[cnt] = x, c[cnt] = y;
    nex[++cnt] = hed[v], hed[v] = cnt, to[cnt] = u, w[cnt] = 0, c[cnt] = -y;
}

bool spfa() {
    for(int i = s; i <= t; i++) d[i] = inf, cur[i] = hed[i];
    queue<int> q; d[s] = 0, q.push(s), vis[s] = 1;

    while(!q.empty()) {
        int x = q.front(); q.pop(), vis[x] = 0;
        
        for(int i = hed[x]; i; i = nex[i]) {
            if(w[i] and d[to[i]] > d[x] + c[i]) {
                d[to[i]] = d[x] + c[i];
                if(!vis[to[i]]) vis[to[i]] = 1, q.push(to[i]);
            }
        }
    }

    return d[t] != inf;
}

int dinic(int x, int flow, int C) {
    if(x == t) return ans += C * flow, flow;
    int rest = flow; vis[x] = 1;

    for(int i = cur[x]; i and rest; cur[x] = i, i = nex[i])
        if(!vis[to[i]] and w[i] and d[to[i]] == d[x] + c[i]) {
            int p = dinic(to[i], min(rest, w[i]), C + c[i]);
            w[i] -= p, w[i ^ 1] += p, rest -= p;
        }

    vis[x] = 0;    
    return flow - rest;
}

bool edmer;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), s = 0, t = 2 * n + 2, cnt = 1;

    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= n; i++) b[i] = read();
    
    for(int i = 1; i < n; i++) add(n + i, n + i + 1, n, 0);
    for(int i = 1; i <= n; i++) add(s, i, 1, a[i]), add(i, i + n, 1, 0), add(i + n, t - 1, 1, b[i]);
    
    add(t - 1, t, m, 0);

    while(spfa()) m -= dinic(s, m, 0);

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 