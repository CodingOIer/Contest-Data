#include <bits/stdc++.h>
#define ll long long
#define lll __int128 
#define lowbit(x) (x&-x)
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) x=-x,putchar('-');
		if(x>9) write(x/10);
		putchar(x%10+'0');
	}
}
using namespace IO;

const int Maxn=30;
int n,m;
set<int>tse[Maxn];
vector<int>e[Maxn],ne[Maxn],fn[Maxn];
int deg[Maxn];
bitset<Maxn>b[Maxn];

map<ll,ll>gg;

int dfn[Maxn],low[Maxn],cnt;
int stk[Maxn],top,col[Maxn],Cl;

int sum[Maxn][Maxn];

void Tarjan(int u){
	dfn[u]=low[u]=++cnt;
	stk[++top]=u;
	for(auto v:e[u]){
		if(!dfn[v]){
			Tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(!col[v]) low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u]){
		int tp=stk[top];
		Cl++;
		do{
			tp=stk[top--];
			col[tp]=Cl;
			b[Cl][tp]=1;
		}while(tp!=u);
	}
}

inline void toposort(){
	queue<int>q;
	for(int i=1;i<=n;i++) if(!deg[i]) q.push(i);
	
	while(!q.empty()){
		int u=q.front();
		q.pop();
		for(auto v:fn[u]){
			deg[v]--;
			b[v]|=b[u];
			if(!deg[v]) q.push(v);
		}
	}
}

ll ans=0;

int main(){
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout); 
	
	
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		if(u==v) continue;
		tse[u].insert(v);
	}
	
	for(int i=1;i<=n;i++){
		for(auto j:tse[i])
			e[i].emplace_back(j);
		tse[i].clear();
	}
		
	
	for(int i=1;i<=n;i++){
		if(!dfn[i]){
			Tarjan(i);
		}
	}
//	for(int i=1;i<=n;i++){
//		cout<<i<<' '<<col[i]<<endl;
//	}
//	printf("%d",Cl);
	for(int i=1;i<=n;i++)
		for(auto j:e[i]){
			if(col[i]==col[j]) continue;
			tse[col[i]].insert(col[j]);
		}
	for(int i=1;i<=Cl;i++)
		for(auto j:tse[i])
			ne[i].emplace_back(j),
			fn[j].emplace_back(i),
			deg[i]++;
	toposort();
	
//	cout<<"lll "<<Cl<<endl;\\\\
printf("1")
	for(int i=1;i<=Cl;i++){
		for(int j=i;j<=Cl;j++){
			
			
//			bool pp=0;
//			for(int u=i;u<=j;u++)
//				for(int v=i;v<=j;v++){
//					if(u==v) continue;
//					bitset<Maxn>gg=b[u]|b[v];
//					
//					if(gg==b[u]) pp=1;
//				}
//			if(pp) continue;
			
			bitset<Maxn>s;

			for(int k=i;k<=j;k++) s|=b[k];
			ll pp=0;
			for(ll k=1;k<=n;k++) if(s[k]) pp+=(1ll<<k)		;
			
			if(gg[pp]) continue;
			gg[pp]=1;
			
			
			
			
			bool flg1=0,flg2=0,ok=1;
			int ct=0;
			for(int k=1;k<=n;k++){
				ct+=s[k];
				if(flg1&&flg2&&s[k]) ok=0; 
				if(s[k]) flg1=1;
				else if(flg1) flg2=1;
			}
			if(ok){
				if(ct!=n) ans++;cout<<"test "<<s<<endl;
				
			}
		}
	}
	
	printf("%lld",ans+1);
	
	return 0;
} 

/*
5 5
1 2
1 2
2 3
2 3
2 2

5 5
1 3
3 4
5 4
1 5
2 1

10 20
7 5
9 9
3 5
4 5
8 9
4 5
2 1
8 9
1 4
10 9
4 5
3 5
6 6
1 3
2 3
9 8
7 5
4 5
4 5
9 9

*/
