#include <bits/stdc++.h>
#define ll long long
#define lll __int128
#define lowbit(x) (x&-x)
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) x=-x,putchar('-');
		if(x>9) write(x/10);
		putchar(x%10+'0');
	}
}
using namespace IO;

const ll Mod=1e9+7;
int n,m;
ll ans;
int col[20],s[20];
bool d[20];

map<ll,ll>sr;

void DFS(int p){

	if(p>m){
		bool flg=1;
		for(int i=1;i<=n;i++) if(col[i]==0) flg=0;
		ll pp=0;
		for(int i=1;i<=n;i++) pp=pp*10+col[i];
		
		if(sr.count(pp)) flg=0;
		sr[pp]=1;
		 
//		if(flg){
//			cout<<"fck\n";
//			for(int i=1;i<=n;i++) cout<<col[i]<<" ";
//			cout<<"\n";
//		}
		ans+=flg;
		return ;
	}
	
	for(ll l=1;l<=m;l++){
		if(d[l]) continue;
		d[l]=1;
		for(ll i=1;i<=n;i++){
			for(ll j=i;j<=n;j++){
					
			
			for(ll k=i;k<=j;k++) s[k]=col[k];
			for(ll k=i;k<=j;k++) col[k]=l;
	//	cout<<i<<" "<<j<<' '<<l<<" "<<p<<endl;  
			DFS(p+1);
			for(ll k=i;k<=j;k++) col[k]=s[k];
		}
		}
		
	d[l]=0;	
	}
	
//	DFS(p+1);
}

int main(){
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout); 
	
	
	scanf("%d%d",&n,&m);
	DFS(1);
	
	printf("%lld",ans%Mod);
	return 0;
}

