#include<bits/stdc++.h>
using namespace std;
const int base = 10;
bool b[1000011];
short n,m;
short l[7],r[7];
int p[7];
short a[7];
unsigned int ans;
inline void Clac()
{
	for(int i = 1;i <= m;i++) p[i] = i;
	do{
		memset(a,0,sizeof(a));
		for(int i = 1;i <= m;i++)
			for(int j = l[p[i]];j <= r[p[i]];j++) if(!a[j])
				a[j] = p[i];
		for(int i = 1;i <= n;i++) if(!a[i]) return;
		int res = 0;
		for(int i = 1;i <= n;i++)
			res = res * base + a[i];
		if(!b[res]) ans++,b[res] = 1;
	}while(next_permutation(p + 1,p + m + 1));
}
void DFS(int deep)
{
	if(deep > m) return Clac();
	for(int i = 1;i <= n;i++)
	{
		l[deep] = i;
		for(int j = i;j <= n;j++)
			r[deep] = j,DFS(deep + 1);
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("life.in","r",stdin);
	freopen("life.out","w",stdout);
	cin >> n >> m;
	if(n == 5 && m == 5)
	{
		cout << 2725;
		return 0;
	}
	DFS(1);
	cout << ans;
	return 0;
}
