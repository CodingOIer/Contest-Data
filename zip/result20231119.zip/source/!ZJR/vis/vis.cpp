#include<bits/stdc++.h>
#define lowbit(x) (x&-x)
using namespace std;
const int mod = 1000000007;
int n,m;
vector<int> v[300011];
int l[25][300011],r[25][300011],lg[300011];
inline int askr(int ll,int rr)
{
	return max(r[lg[rr - ll + 1]][ll],r[lg[rr - ll + 1]][rr + 1 - (1 << lg[rr - ll + 1])]);
}
inline int askl(int ll,int rr)
{
	return min(l[lg[rr - ll + 1]][ll],l[lg[rr - ll + 1]][rr + 1 - (1 << lg[rr - ll + 1])]);
}
bool inst[300011];
int st[300011],top,dfn[300011],low[300011];
int idx;
void Tarjan(int p)
{
	dfn[p] = low[p] = ++idx;
	l[0][p] = r[0][p] = p;
	inst[p] = 1;
	st[++top] = p;
	for(auto i:v[p])
	{
		if(!dfn[i])
		{
			Tarjan(i);
			low[p] = min(low[p],low[i]);
		}else if(inst[i])
			low[p] = min(low[p],dfn[i]);
		l[0][p] = min(l[0][p],l[0][i]),r[0][p] = max(r[0][p],r[0][i]);
	}
	if(dfn[p] == low[p])
	{
		for(int i = top;st[i] != p;i--)
			l[0][p] = min(l[0][p],l[0][st[i]]),r[0][p] = max(r[0][p],r[0][st[i]]);
		while(st[top] != p) l[0][st[top]] = l[0][p],r[0][st[top]] = r[0][p],inst[st[top--]] = 0;
		top--;
		inst[p] = 0;
	}
}
vector<int> a[300011];
int b[300011];
void add(int p,int val)
{
	while(p)
	{
		b[p] += val;
		p -= lowbit(p);
	}
}
int ask(int p)
{
	int res = 0;
	while(p <= n)
	{
		res += b[p];
		p += lowbit(p);
	}
	return res;
}
long long ans;
int main()
{
	for(int i = 2;i <= 300000;i++)
		lg[i] = lg[i >> 1] + 1;
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= m;i++)
	{
		int x,y;
		cin >> x >> y;
		v[x].push_back(y);
	}
	for(int i = 1;i <= n;i++)
		if(!dfn[i])
			Tarjan(i);
	for(int k = 1;k <= lg[n];k++)
		for(int i = 1;(i + (1 << k)) - 1 <= n;i++)
			l[k][i] = min(l[k - 1][i],l[k - 1][i + (1 << k - 1)]),r[k][i] = max(r[k - 1][i],r[k - 1][i + (1 << k - 1)]);
	for(int i = 1;i <= n;i++)
	{
		int ll = i,rr = n,mid,res = i - 1;
		while(ll <= rr)
		{
			mid = ll + rr >> 1;
			if(askl(i,mid) >= i) res = mid,ll = mid + 1;
			else rr = mid - 1;
		}
		add(i,1),a[res + 1].push_back(i);
		for(auto x:a[i]) add(x,-1);
		ll = 1,rr = i,mid,res = i + 1;
		while(ll <= rr)
		{
			mid = ll + rr >> 1;
			if(askr(mid,i) <= i) res = mid,rr = mid - 1;
			else ll = mid + 1;
		}
		ans += ask(res);
	}
	cout << ans % mod;
	return 0;
}
