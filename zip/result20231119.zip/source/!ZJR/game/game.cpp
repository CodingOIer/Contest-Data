#include<bits/stdc++.h>
using namespace std;
int a[100011],b[100011];
long long f[111][311][311],s[111][311][311];
long long mx = 1000000000000000000;
int n,k;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	memset(s,0x3f,sizeof(s));
	memset(f,0x3f,sizeof(f));
	memset(f[0],0,sizeof(f[0]));
	cin >> n >> k;
	if(k > n)
	{
		cout << mx;
		return 0;
	}
	for(int i = 1;i <= n;i++)
		cin >> a[i];
	for(int i = 1;i <= n;i++)
		cin >> b[i];
	for(int i = 1;i <= k + 1;i++)
	{
		for(int x = 0;x <= n;x++)
		{
			for(int y = x;y <= n;y++)
			{
				s[i - 1][x][y] = f[i - 1][x][y];
				if(x) s[i - 1][x][y] = min(s[i - 1][x][y],s[i - 1][x - 1][y]);
				if(y) s[i - 1][x][y] = min(s[i - 1][x][y],s[i - 1][x][y - 1]);
			}
		}
		for(int x = i;x <= n;x++)
			for(int y = x;y <= n;y++)
				f[i][x][y] = s[i - 1][x - 1][y - 1] + a[x] + b[y];
	}
	cout << min(s[k][n][n],mx);
	return 0;
}
