#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(x==0){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int mod=1e9+7;
const int tmaxn=1e6+2;
int n,m;
int fac[tmaxn],inv_fac[tmaxn];
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
void pre(){
    fac[0]=1;for(int i=1;i<tmaxn;i++)fac[i]=1ll*fac[i-1]*i%mod;
    inv_fac[tmaxn-1]=f_pow(fac[tmaxn-1],mod-2);
    for(int i=tmaxn-1;i;i--)inv_fac[i-1]=1ll*inv_fac[i]*i%mod;
    return ;
}
int calc_C(int a,int b){
    if(a<b||a<0||b<0)return 0;
    return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
}
namespace brute1{
    const int maxn=3e2+2;
    int g[maxn][maxn][2],f[maxn][maxn][maxn];
    int ans;
    void solve(){
        pre();
        // g[0][0][0]=1;
        // for(int i=1;i<=n;i++){
        //     for(int j=0;j<=m;j++){
        //         upd(g[i][j][0],g[i-1][j][0]);
        //         upd(g[i][j][0],g[i-1][j][1]);
        //         for(int p=1;p<i;p++){
        //             for(int q=1;q<=j;q++){
        //                 upd(g[i][j][1],1ll*g[i-p][j-q][0]*((g[p][q-1][0]+g[p][q-1][1])%mod)%mod);
        //             }
        //         }
        //         // printf("g[%d][%d][%d]=%d\n",i,j,0,g[i][j][0]);
        //         // printf("g[%d][%d][%d]=%d\n",i,j,1,g[i][j][1]);
        //     }
        // }
        // for(int i=1;i<=m;i++)upd(ans,1ll*((g[n][i-1][0]+g[n][i-1][1])%mod)*C[m][i]%mod*fac[i]%mod);
        f[0][0][0]=1;
        int nm=min(m,n);
        for(int i=1;i<=n;i++){
            for(int j=1;j<=nm;j++){
                for(int k=0;k<=j;k++){
                    if(k){
                        upd(f[i][j][k],f[i-1][j][k]);
                        upd(f[i][j][k-1],f[i-1][j][k]);
                        upd(f[i][j][k],1ll*f[i-1][j-1][k-1]*(m-j+1)%mod);
                    }
                    upd(f[i][j][k],1ll*f[i-1][j-1][k]*(m-j+1)%mod);
                }
                // for(int k=0;k<=j;k++)printf("f[%d][%d][%d]=%d\n",i,j,k,f[i][j][k]);
            }
        }
        // for(int i=1;i<=nm;i++)upd(ans,1ll*fac[i]*f[n][i][0]%mod*calc_C(m,i)%mod);
        for(int i=1;i<=nm;i++)upd(ans,f[n][i][0]);
        write(ans);
        putchar('\n');
        return ;
    }
}
namespace tadashi{
    int ans;
    void solve(){
    }
}
int main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    n=read(),m=read();
    if(n<=300)brute1::solve();
    return 0;
}