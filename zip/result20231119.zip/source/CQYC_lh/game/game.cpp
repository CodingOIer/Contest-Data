#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(long long x){
    if(x==0){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=1e5+2,inf32=1e9;
const long long inf=1e18;
int n,K;
int va[2][maxn];
struct DINIC{
	int S,T;
    int cnt;
	int max_flow;
    long long min_cost;
	int hed[maxn*2+2],now[maxn*2+2];
    long long d[maxn*2+2];
    bool vis[maxn*2+2];
    queue<int>q;
    struct node_edge{
        int nxt,to,val;
        long long cot;
    }G[maxn*4*2];
    void add(int u,int v,int w,long long co){
        G[++cnt]=(node_edge){hed[u],v,w,co};
        hed[u]=cnt;
        return ;
    }
    void add_flow(int u,int v,long long w,long long co){
        add(u,v,w,co);
        add(v,u,0,-co);
    }
    bool SPFA(){
        memset(vis,0,sizeof(vis));
        memset(d,0x3f,sizeof(d));
        q.push(S),vis[S]=1,d[S]=0;
        int x;
        while(!q.empty()){
            x=q.front();
            q.pop();
            now[x]=hed[x];
            vis[x]=0;
            // printf("d[%d]=%lld\n",x,d[x]);
            for(int i=hed[x],v;i;i=G[i].nxt){
                v=G[i].to;
                if(!G[i].val)continue;
                if(d[v]>d[x]+G[i].cot){
                    d[v]=d[x]+G[i].cot;
                    if(!vis[v])q.push(v),vis[v]=1;
                }
            }
        }
        memset(vis,0,sizeof(vis));
        return d[T]!=d[0];
    }
    int dfs_flow(int x,int get){
        // printf("dfs %d %d %d\n",x,get,T);
        if(x==T)return get;
        int rest=get,give;
        vis[x]=1;
        for(int i=now[x],v;i&&rest;i=G[i].nxt){
            now[x]=i;
            v=G[i].to;
            if(!G[i].val||vis[v]||d[v]!=d[x]+G[i].cot)continue;
            give=dfs_flow(v,min(rest,G[i].val));
			if(!give)d[v]=d[0];
            G[i].val-=give;
            G[i^1].val+=give;
            rest-=give;
        }
        vis[x]=0;
        return get-rest;
    }
    void dinic(){
        int new_flow;
        max_flow=0,min_cost=0;
        while(SPFA()){
            // printf("a\n");
            while(new_flow=dfs_flow(S,inf32))max_flow+=new_flow,min_cost+=1ll*new_flow*d[T];
        }
        return ;
    }
}G;
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),K=read();
    for(int i=1;i<=n;i++)va[0][i]=read();
    for(int i=1;i<=n;i++)va[1][i]=read();
    G.cnt=1;
    G.S=2*n+1,G.T=2*n+3;
    for(int i=1;i<=n;i++){
        G.add_flow(G.S,i,1,va[0][i]);
        G.add_flow(i+n,G.T-1,1,va[1][i]);
        G.add_flow(i,i+n,1,0);
        if(i)G.add_flow(i-1,i,inf32,0);
    }
    G.add_flow(G.T-1,G.T,K,0);
    G.dinic();
    // G.SPFA();
    if(G.max_flow!=K)printf("%lld\n",(long long)1e18);
    else printf("%lld\n",G.min_cost);
    return 0;
}