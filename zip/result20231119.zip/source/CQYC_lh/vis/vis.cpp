#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(x==0){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=3e5+2;
const int inf=1e9;
const int mod=1e9+7;
int n,m;
int L[maxn],R[maxn];
int ans;
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
struct SEGTREE{
    #define ls(x) (x<<1)
    #define rs(x) (x<<1|1)
    struct node{
        int l,r,mx;
    }t[maxn<<2];
    void pushup(int x){
        t[x].mx=max(t[ls(x)].mx,t[rs(x)].mx);
        return ;
    }
    void build(int x,int l,int r){
        t[x].l=l,t[x].r=r;
        if(l==r){
            t[x].mx=-inf;
            return ;
        }
        int mid=(t[x].l+t[x].r)>>1;
        build(ls(x),l,mid);
        build(rs(x),mid+1,r);
        pushup(x);
        return ;
    }
    void modify(int x,int p,int v){
        if(t[x].l==t[x].r){
            t[x].mx=v;
            return ;
        }
        int mid=(t[x].l+t[x].r)>>1;
        if(p<=mid)modify(ls(x),p,v);
        else modify(rs(x),p,v);
        pushup(x);
    }
    int get_pos(int x,int p){
        if(t[x].l==t[x].r){
            if(t[x].mx>p)return t[x].l;
            else return 0;
        }
        if(t[rs(x)].mx>p)return get_pos(rs(x),p);
        else return get_pos(ls(x),p);
    }
}segt;
struct BIT{
    int t[maxn];
    int lowbit(int x){return x&-x;}
    void modify(int x,int v){
        if(!x)return ;
        for(int i=x;i<=n;i+=lowbit(i))upd(t[i],v);
    }
    int query(int x){
        if(!x)return 0;
        int ret=0;for(int i=x;i;i-=lowbit(i))upd(ret,t[i]);return ret;
    }
}bit;
struct node_sec{
    int l,r;
    bool operator < (const node_sec &A)const{
        return (l!=A.l)?(l<A.l):(r<A.r);
    }
    bool operator == (const node_sec &A)const{
        return (l==A.l)&&(r==A.r);
    }
};
int top,sta[maxn];
int main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)L[i]=R[i]=i;
    for(int i=1,u,v;i<=m;i++){
        u=read(),v=read();
        L[u]=min(L[u],v);
        R[u]=max(R[u],v);
    }
    segt.build(1,1,n);
    for(int i=1,pos;i<=n;i++){
        while(top&&sta[top]>L[i])bit.modify(top--,mod-1);
        if(L[i]==i)bit.modify(i,1),sta[++top]=i;
        if(R[i]==i){
            pos=segt.get_pos(1,R[i]);
            upd(ans,(mod+bit.query(i)-bit.query(pos))%mod);
        }
        segt.modify(1,i,R[i]);
    }
    write(ans);
    putchar('\n');
    return 0;
}