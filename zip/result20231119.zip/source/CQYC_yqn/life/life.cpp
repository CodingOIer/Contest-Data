#include<bits/stdc++.h>
//#define int long long
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
	return x*f;
}
const int mod=1e9+7;
int dp[75][75][75][2];
int n,m,ans;
void add(int &x,int y){x=(x+y)%mod;}
signed main()
{
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    n=read(),m=read();
    dp[1][m-1][1][0]=m;
    dp[1][m-1][1][1]=1;
    for(int i=1;i<n;i++)
	{
        for(int j=0;j<=m;j++)
		{
            for(int k=0;k<=m;k++)
			{
                int now0=dp[i][j][k][0];
				int now1=dp[i][j][k][1];
                add(dp[i+1][j][k][1],now1);
                if(k)
                	add(dp[i+1][j][k-1][0],now1);
                add(dp[i+1][j][k][0],now0);
                add(dp[i+1][j-1][k+1][0],(now0+now1)*j%mod);
                add(dp[i+1][j-1][k][1],(now0+now1)*j%mod);
            }
        }
    }
//    for(int i=1;i<=n;i++){
//        for(int j=0;j<=m;j++){
//            for(int k=0;k<=m;k++){
//                for(int l=0;l<2;l++)
//                    if(dp[i][j][k][l]) cout<<i<<" "<<j<<" "<<k<<" "<<l<<"  "<<dp[i][j][k][l]<<"\n";
//            }
//        }
//    }
    for(int j=0;j<=m;j++)
	{
        for(int l=0;l<2;l++)
            add(ans,dp[n][j][0][l]);
    }
    printf("%d\n",ans);
    return 0;
}
