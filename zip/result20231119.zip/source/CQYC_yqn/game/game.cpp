#include<bits/stdc++.h>
using namespace std;
const int N=305;
int n,K,a[N],b[N];
long long f[N][N][205],ans=1e18;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),K=read();
	K<<=1;
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=n;++i) b[i]=read();
	memset(f,0x3f,sizeof(f));
	f[0][0][0]=0;
	for(int i=0;i<=n;++i)
	for(int j=0;j<=n;++j)
	for(int k=0;k<K;++k)
	{
		if(!(k&1))
		{
			for(int l=i+1;l<=n;++l) f[l][j][k+1]=min(f[l][j][k+1],f[i][j][k]+a[l]);
		}else
		{
			for(int l=max(j+1,i);l<=n;++l) f[i][l][k+1]=min(f[i][l][k+1],f[i][j][k]+b[l]);
		}
	}
	for(int i=1;i<=n;++i)
	for(int j=1;j<=n;++j)
		ans=min(ans,f[i][j][K]);
	printf("%lld",ans);
	return 0;
}
