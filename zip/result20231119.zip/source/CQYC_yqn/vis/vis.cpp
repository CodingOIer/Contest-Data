#include<bits/stdc++.h>
using namespace std;
const int MAXN=3e5+4,P=1e9+7;
vector<int>g[MAXN];
bool vis[MAXN];
bool dfs(int u,int l,int r)
{
	if(vis[u])
		return true;
	if(u<l||u>r)
		return false;
	vis[u]=true;
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(!dfs(v,l,r))
			return false;
	}
	return true;
}
int main()
{
	freopen("vis.in","r",stdin);
	freopen("vis.ans","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
	}
	int ans=0;
	for(int l=1;l<=n;l++)
		for(int r=l;r<=n;r++)
		{
			bool flag=true;
			for(int i=1;i<=n;i++)
				vis[i]=false;
			for(int k=l;k<=r;k++)
				if(!dfs(k,l,r))
				{
					flag=false;
					break;
				}
			ans=(ans+flag)%P;
		}
	printf("%d",ans);
	return 0;
}
