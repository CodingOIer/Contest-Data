#include<bits/stdc++.h>
using namespace std;
const int NN=3e5+4,P=1e9+7;
struct segment_tree1
{
	struct segment_tree
	{
		int l,r,maxx;
	}tr[NN<<2];
	void pushdown(int u)
	{
		tr[u<<1].maxx=max(tr[u<<1].maxx,tr[u].maxx);
		tr[u<<1|1].maxx=max(tr[u<<1|1].maxx,tr[u].maxx);
	}
	void build(int u,int l,int r)
	{
		tr[u]={l,r,0};
		if(l==r)
		{
			tr[u].maxx=1;
			return;
		}
		int mid=l+(r-l)/2;
		build(u<<1,l,mid);
		build(u<<1|1,mid+1,r);
	}
	void modify(int u,int l,int r,int v)
	{
		if(tr[u].l>=l&&tr[u].r<=r)
		{
			tr[u].maxx=max(tr[u].maxx,v);
			return;
		}
		pushdown(u);
		int mid=tr[u].l+(tr[u].r-tr[u].l)/2;
		if(l<=mid)
			modify(u<<1,l,r,v);
		if(r>mid)
			modify(u<<1|1,l,r,v);
	}
	int query(int u,int p)
	{
		if(tr[u].l==tr[u].r)
			return tr[u].maxx;
		pushdown(u);
		int mid=tr[u].l+(tr[u].r-tr[u].l)/2;
		if(p<=mid)
			return query(u<<1,p);
		return query(u<<1|1,p);
	}
}A;
struct segment_tree2
{
	struct segment_tree
	{
		int l,r,v;
		bool flag;
	}tr[NN<<2];
	void pushup(int u)
	{
		tr[u].v=tr[u<<1].v+tr[u<<1|1].v;
	}
	void pushdown(int u)
	{
		if(!tr[u].flag)
			return;
		tr[u<<1].flag=tr[u<<1|1].flag=true;
		tr[u<<1].v=tr[u<<1|1].v=0;
	}
	void build(int u,int l,int r)
	{
		tr[u]={l,r,0,false};
		if(l==r)
		{
			tr[u].v=1;
			return;
		}
		int mid=l+(r-l)/2;
		build(u<<1,l,mid);
		build(u<<1|1,mid+1,r);
		pushup(u);
	}
	void modify(int u,int l,int r)
	{
		if(tr[u].l>=l&&tr[u].r<=r)
		{
			tr[u].flag=true;
			tr[u].v=0;
			return;
		}
		pushdown(u);
		int mid=tr[u].l+(tr[u].r-tr[u].l)/2;
		if(l<=mid)
			modify(u<<1,l,r);
		if(r>mid)
			modify(u<<1|1,l,r);
		pushup(u);
	}
	int query(int u,int l,int r)
	{
		if(tr[u].l>=l&&tr[u].r<=r)
			return tr[u].v;
		pushdown(u);
		int mid=tr[u].l+(tr[u].r-tr[u].l)/2,res=0;
		if(l<=mid)
			res+=query(u<<1,l,r);
		if(r>mid)
			res+=query(u<<1|1,l,r);
		return res;
	}
}B;
vector<int>g1[NN],g2[NN],p[NN];
int dfn[NN],low[NN],tim,scc[NN],scn,tmi[NN],tmx[NN];
stack<int>stk;
void tarjan(int u)
{
	dfn[u]=low[u]=++tim;
	stk.push(u);
	for(int i=0;i<g1[u].size();i++)
	{
		int v=g1[u][i];
		if(!dfn[v])
		{
			tarjan(v);
			low[u]=min(low[u],low[v]);
		}
		else if(!scc[v])
			low[u]=min(low[u],dfn[v]);
	}
	if(low[u]==dfn[u])
	{
		int x;
		scn++;
		do
		{
			x=stk.top();
			stk.pop();
			scc[x]=scn;
			p[scn].push_back(x);
		}while(x!=u);
	}
}
bool vis[NN];
int minn[NN],maxx[NN];
void dfs(int u)
{
	if(vis[u])
		return;
	vis[u]=true;
	tmi[u]=1e9;
	for(int i=0;i<p[u].size();i++)
	{
		int x=p[u][i];
		tmi[u]=min(tmi[u],x);
		tmx[u]=max(tmx[u],x);
	}
	for(int i=0;i<g2[u].size();i++)
	{
		int v=g2[u][i];
		dfs(v);
		tmi[u]=min(tmi[u],tmi[v]);
		tmx[u]=max(tmx[u],tmx[v]);
	}
	for(int i=0;i<p[u].size();i++)
	{
		maxx[p[u][i]]=tmx[u];
		minn[p[u][i]]=tmi[u];
	}
}
int main()
{
	freopen("vis.in","r",stdin);
	freopen("vis.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		g1[u].push_back(v);
	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])
			tarjan(i);
	for(int i=1;i<=n;i++)
		for(int j=0;j<g1[i].size();j++)
		{
			int v=g1[i][j];
			if(scc[i]!=scc[v])
				g2[scc[i]].push_back(scc[v]);
		}
	for(int i=1;i<=n;i++)
		if(!vis[i])
			dfs(i);
	int ans=0,p=1;
	while(p<=n&&maxx[p]!=p)
		p++;
	A.build(1,1,n);
	B.build(1,1,n);
	for(int i=1;i<=n;i++)
		if(maxx[i]>i)
			A.modify(1,i,maxx[i]-1,i+1);
	for(int i=1;i<=n;i++)
	{
		if(minn[i]<i)
			B.modify(1,minn[i]+1,i);
		int t=A.query(1,i);
		if(t<=i)
			ans=(ans+B.query(1,t,i))%P;
	}
	printf("%d",ans);
	return 0;
}
