#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=1e5+4;
int a[NN],b[NN];
ll f[304][304][104];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,K;
	scanf("%d%d",&n,&K);
	if(K>n)
	{
		printf("1000000000000000000");
		return 0;
	}
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	bool flag=true;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i]);
		if(b[i]<b[i-1])
			flag=false;
	}
	if(flag)
	{
		for(int i=1;i<=n;i++)
			a[i]+=b[i];
		sort(a+1,a+1+n);
		ll res=0;
		for(int i=1;i<=K;i++)
			res+=a[i];
		printf("%lld",res);
		return 0;
	}
	memset(f,0x3f,sizeof(f));
	f[0][0][0]=0;
	ll ans=1e18;
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
			for(int k=1;k<=K;k++)
			{
				for(int i1=0;i1<i;i1++)
					for(int j1=i1;j1<j;j1++)
						f[i][j][k]=min(f[i][j][k],f[i1][j1][k-1]+a[i]+b[j]);
				if(k==K)
					ans=min(ans,f[i][j][k]);
			}
	printf("%lld",ans);
	return 0;
}
