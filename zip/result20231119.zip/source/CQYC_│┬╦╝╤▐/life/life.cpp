#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7,maxn=1e6+5,base=131;
int n,m,l[maxn],r[maxn],vis[maxn],a[maxn],b[maxn],ans;
map<int,int> ma;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int check(){
    for(int i=1;i<=n;i++)
        a[i]=0;
    for(int i=1;i<=m;i++)
        for(int j=l[b[i]];j<=r[b[i]];j++)
            a[j]=b[i];
    int res=0;
    for(int i=1;i<=n;i++){
        if(!a[i])
            return 0;
        res=(res*base+a[i])%mod;
    }
    if(!ma[res]){
        ma[res]=1;
        return 1;
    }
    return 0;
}
void solve2(int x){
    if(x>m){
        if(check())
            ++ans;
        return;
    }
    for(int i=1;i<=m;i++)
        if(!vis[i]){
            vis[i]=1,b[x]=i;
            solve2(x+1);
            vis[i]=0;
        }
}
void solve(int x){
    if(x>m){
        solve2(1);
        return;
    }
    for(int i=1;i<=n;i++)
        for(int j=i;j<=n;j++){
            l[x]=i,r[x]=j;
            solve(x+1);
        }
}
signed main(){
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    n=read(),m=read();
    solve(1);
    printf("%lld\n",ans);
    return 0;
}
