#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5;
int n,k,a[maxn],b[maxn],ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int la,int lb,int va){
    if(k-x+1>n-la||k-x+1>n-lb)
        return;
    if(x>k){
        ans=min(ans,va);
        return;
    }
    for(int i=la+1;i+(k-x)<=n;i++)
        for(int j=max(i,lb+1);j+(k-x)<=n;j++)
            solve(x+1,i,j,va+a[i]+b[j]);
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),k=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    for(int i=1;i<=n;i++)
        b[i]=read();
    if(n==k){
        for(int i=1;i<=n;i++)
            ans+=a[i]+b[i];
        printf("%lld\n",ans);
        return 0;
    }
    ans=1e18;
    solve(1,0,0,0);
    printf("%lld\n",ans);
    return 0;
}
