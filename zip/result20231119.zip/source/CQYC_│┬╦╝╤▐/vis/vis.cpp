#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7,maxn=3e5+5;
int n,m,u,v,ans,cnt,vis[maxn],tot,t[maxn];
vector<int> to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int x){
    for(int i=x;i<=n;i+=(i&(-i)))
        t[i]++;
}
int query(int x){
    int res=0;
    for(int i=x;i;i-=(i&(-i)))
        res+=t[i];
    return res;
}
int dfs(int u,int l){
    if(u<l)
        return 1;
    if(vis[u]==l)
        return 0;
    add(u);
    vis[u]=l;
    for(auto v:to[u])
        if(vis[u]!=l){
            if(dfs(v,l))
                return 1;
        }
    return 0;
}
signed main(){
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        u=read(),v=read();
        to[u].push_back(v);
    }
    for(int i=1;i<=n;i++){
        memset(t,0,sizeof(t));
        for(int j=i;j<=n;j++){
            if(dfs(j,i))
                break;
            if(query(n)==j-i+1&&query(j)-query(i-1)==j-i+1)
                ++ans;
        }
    }
    printf("%lld\n",ans);
    return 0;
}
