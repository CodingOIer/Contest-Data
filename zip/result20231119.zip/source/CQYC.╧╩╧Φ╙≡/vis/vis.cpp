#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
typedef long long ll;
const int N=3e5+10,M=6e5+10,K=N<<2,mod=1e9+7;
int n,m;
int Mn[K],tag[K],num[K];
int first[N],to[M],nxt[M],cnt;
ll ans;
vector<int>ned[N];
multiset<int>s;
multiset<int>::iterator it;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void build(int id,int l,int r)
{
    num[id]=r-l+1;
    if(l==r) return;
    int mid=(l+r)>>1;
    build(lt,l,mid);
    build(rt,mid+1,r);
}
inline void upd(int id,int x) {Mn[id]+=x,tag[id]+=x;}
void push_up(int id)
{
    Mn[id]=min(Mn[lt],Mn[rt]);
    num[id]=0;
    if(Mn[id]==Mn[lt]) num[id]+=num[lt];
    if(Mn[id]==Mn[rt]) num[id]+=num[rt];
}
void push_down(int id)
{
    if(!tag[id]) return;
    upd(lt,tag[id]),upd(rt,tag[id]);
    tag[id]=0;
}
void add(int id,int l,int r,int L,int R)
{
    if(l>R||r<L) return;
    if(L<=l&&r<=R) return upd(id,1);
    push_down(id);
    int mid=(l+r)>>1;
    add(lt,l,mid,L,R);
    add(rt,mid+1,r,L,R);
    push_up(id);
}
int query(int id,int l,int r,int L,int R)
{
    if(l>R||r<L) return 0;
    if(L<=l&&r<=R) return Mn[id]?0:num[id];
    push_down(id);
    int mid=(l+r)>>1;
    return query(lt,l,mid,L,R)+query(rt,mid+1,r,L,R);
}
int main()
{
    freopen("vis.in","r",stdin);
    freopen("vis.out","w",stdout);
    n=read(),m=read();
    int u,v;
    while(m--)
        u=read(),v=read(),inc(u,v);
    build(1,1,n);
    for(int R,i=1;i<=n;i++)
    {
        for(int j=first[i];j;j=nxt[j])
            if((v=to[j])<=i) add(1,1,n,v+1,i);
            else ned[v].push_back(i),s.insert(i);
        for(int x:ned[i])
            it=s.find(x),s.erase(it);
        if(s.empty()) R=0;
        else it=s.end(),--it,R=*it;
        ans+=query(1,1,n,R+1,i);
    }
    cout<<ans%mod<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
