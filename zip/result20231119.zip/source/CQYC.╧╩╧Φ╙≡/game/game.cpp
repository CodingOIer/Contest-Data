#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10,M=5010,K=1010;
bool Begin;
struct ok{
    int a,b;
    bool operator <(const ok &A) const{return a==A.a?b<A.b:a<A.a;}
}A[N];
int n,k,a[N],b[N];
bool subtask=1;
ll Mn[M][K];
bool End;
inline void Min(ll &x,ll y) {x=x>y?y:x;}
int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cerr<<(&Begin-&End)/1024/1024<<"MB\n";
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++) scanf("%d",a+i);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",b+i);
        if(b[i-1]>b[i]) subtask=0;
    }
    if(subtask)
    {
        ll ans=0;
        for(int i=1;i<=n;i++)
            A[i]=(ok){a[i],b[i]};
        sort(A+1,A+n+1);
        for(int i=1;i<=k;i++)
            ans+=A[i].a,ans+=A[i].b;
        printf("%lld\n",ans);
        return 0;
    }
    if(n>5e3)
    {
        ll ans=0;
        for(int i=1;i<=n;i++)
            a[i]=min(a[i],b[i]);
        sort(a+1,a+n+1);
        for(int i=1;i<=2*k;i++) ans+=a[i];
        printf("%lld\n",ans);
        return 0;
    }
    memset(Mn,0x3f,sizeof(Mn));
    for(int i=0;i<=n;i++) Mn[i][0]=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=n;j>=i;j--)
            for(int p=1;p<=k;p++)
                Min(Mn[j][p],Mn[j-1][p-1]+a[i]+b[j]);
        for(int j=1;j<=n;j++)
            for(int p=0;p<=k;p++)
                Min(Mn[j][p],Mn[j-1][p]);
    }
    printf("%lld\n",Mn[n][k]);
    fclose(stdin);fclose(stdout);
    return 0;
}
