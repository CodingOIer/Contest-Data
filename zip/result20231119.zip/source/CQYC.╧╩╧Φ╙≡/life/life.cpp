#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10,M=310,mod=1e9+7;
int n,m,ans,dp[M][M][M];
int fac[N],inv[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
inline int add(int x,int y) {upd(x,y);return x;}
int ksm(int x,int y)
{
    int res=1;
    for(;y;y>>=1)
    {
        if(y&1) res=1ll*res*x%mod;
        x=1ll*x*x%mod;
    }
    return res;
}
void pre()
{
    fac[0]=1;
    for(int i=1;i<N;i++) fac[i]=1ll*i*fac[i-1]%mod;
    inv[N-1]=ksm(fac[N-1],mod-2);
    for(int i=N-1;i;i--) inv[i-1]=1ll*i*inv[i]%mod;
}
int A(int x,int y) {return 1ll*fac[x]*inv[x-y]%mod;}
int C(int x,int y) {return 1ll*fac[x]*inv[y]%mod*inv[x-y]%mod;}
int Cat(int x) {return add(C(x+x,x),mod-C(x+x,x+1));}
int main()
{
    freopen("life.in","r",stdin);
    freopen("life.out","w",stdout);
    pre();
    cin>>n>>m;
    dp[0][0][0]=1;
    for(int i=1,T;i<=n;i++)
    {
        T=min(i,m);
        for(int j=0;j<=T;j++)
            for(int k=j;k<=T;k++)
            {
                if(k) upd(dp[i][j][k],dp[i-1][j][k-1]);//One point
                if(j&&k) upd(dp[i][j][k],dp[i-1][j-1][k-1]);//left here
                upd(dp[i][j][k],dp[i-1][j+1][k]);//right here
                if(j) upd(dp[i][j][k],dp[i-1][j][k]);//None
            }
    }
    for(int i=1;i<=min(n,m);i++)
        upd(ans,1ll*dp[n][0][i]*A(m,i)%mod);
    cout<<ans<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
