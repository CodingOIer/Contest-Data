#include<bits/stdc++.h>
using namespace std;
long long read(){
    long long x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
__int128 ot[40],otp;
void write(__int128 x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=121;
int n,m,K;
long long ar[maxn];
__int128 calc(int x,long long S){
    __int128 ret=0,pas=0;
    long long no;
    for(int i=1;i<=n;i++){
        pas+=(__int128)(ar[i]&(1ll<<x));
        no=((ar[i]>>x)&1ll);
        if(S&(1ll<<i-1))no^=1ll;
        ret+=(__int128)(no<<x);
    }
    return max(ret,pas);
}
int main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    n=read(),m=read(),K=read();
    for(int i=1;i<=n;i++){
        ar[i]=read();
    }
    __int128 ans=0;
    for(int i=0;i<m;i++){
        long long S=0;
        for(int j=1;j<=n;j++){
            if(!(ar[j]&(1ll<<i)))S|=(1ll<<j-1);
        }
        __int128 sum=0;
        for(int j=0;j<m;j++)sum+=calc(j,S);
        ans=max(ans,sum);
    }
    write(ans);
    return 0;
}