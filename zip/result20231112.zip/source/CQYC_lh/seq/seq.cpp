#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int mod=1e9+7,maxn=43,maxs=5460+2;
int n,m;
int va[maxn][maxn];
int dp[maxn][maxn*maxn][maxn];
int inv[maxn];
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int calc_C(int a,int b){
    int mul1=1,mul2=1;
    for(int i=1;i<=b;i++)mul1=1ll*mul1*(a-i+1)%mod,mul2=1ll*mul2*i%mod;
    return 1ll*mul1*f_pow(mul2,mod-2)%mod;
}
namespace prime{
    int calc(int x){
        if(n<x)return 0;
        if((n-x)%(m-1)>0)return 0;
        x=(n-x)/(m-1);
        return calc_C(x+m-2,m-2);
    }
    void solve(){
        dp[0][0][1]=1;
        for(int i=1;i<=m;i++){
            for(int j=0;j<=i*(m-2);j++){
                for(int k=0;k<m;k++){
                    for(int w=0;w<=min(m-2,j);w++){
                        upd(dp[i][j][k*va[i][w]%m],dp[i-1][j-w][k]);
                        // if(dp[i-1][j-w][k])printf("upd(%d %d %d) to (%d %d %d)\n",i-1,j-w,k,i,j,k*va[i][w]%m);
                    }
                }
                // for(int k=0;k<m;k++)printf("dp[%d][%d][%d]=%d\n",i,j,k,dp[i][j][k]);
            }
        }
        int ans=0;
        ans=(calc_C(n+m-1,m-1)-calc_C(n+m-2,m-2)+mod)%mod;
        printf("%d\n",ans);
        for(int x=1;x<m;x++){
            ans=0;
            for(int i=0;i<=m*(m-2);i++){
                upd(ans,1ll*dp[m][i][x]*calc(i)%mod);
            }
            printf("%d\n",ans);
        }
    }
}
int main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        va[i][0]=1;
        for(int j=1;j<=m+1;j++)va[i][j]=va[i][j-1]*i%m;
    }
    prime::solve();
    return 0;
}