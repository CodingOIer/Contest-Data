#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+2;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int n;
int ar[maxn];
bool solve(int whi){
    if(whi==0)return 0;
    if(whi==1)return 1;
    if(ar[whi-1]!=ar[whi])return 1;
    return solve(whi-2);
}
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)ar[i]=read();
    sort(ar+1,ar+n+1);
    puts((solve(n))?"Alice":"Bob");
    return 0;
}