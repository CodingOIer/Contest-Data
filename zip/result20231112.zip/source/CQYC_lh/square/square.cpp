#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int solve(long long x){
    long long l=1,r=x,mid,pos=-1;
    while(l<=r){
        mid=(l+r)/2;
        if(mid*mid<=x)pos=mid,l=mid+1;
        else r=mid-1;
    }
    return ((pos*pos==x)?1:2);
}
int main(){
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    int T;
    int l,r;
    T=read();
    while(T--){
        l=read(),r=read();
        if(l==r)printf("%d\n",solve(l));
        else {
            if(r-l>1)printf("1\n");
            else printf("%d\n",solve(1ll*l*r));
        }
    }
    return 0;
}