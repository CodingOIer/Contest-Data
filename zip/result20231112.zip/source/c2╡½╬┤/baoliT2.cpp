#include<bits/stdc++.h>
using namespace std;
const int Maxn=700;
int T;
int f[Maxn*Maxn];
int main(){
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	memset(f,0x7f,sizeof f);
	f[0]=0;
	for(int i=1;i<Maxn*Maxn;i++)
		for(int j=1;j*j<=i;j++)
			f[i]=min(f[i],f[i-j*j]+1);
	for(int l=1;l<=9;l++)
		for(int r=l;r<=9;r++){
			int a=1;
			for(int i=l;i<=r;i++)a*=i;
			printf("%d %d=%d %d\n",l,r,f[a],f[(r*l)-(l-1)%2+r%2-(r-l+1)%2]);
		}
	return 0;
}

