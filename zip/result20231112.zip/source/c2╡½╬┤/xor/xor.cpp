#include<bits/stdc++.h>
#define int __int128
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
    while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
const int Maxn=128;
int n,m,k,a[Maxn];
int f[Maxn][Maxn],cnt[Maxn];
int data[Maxn];
inline void solve_sub1(){
	data[0]=1;
	for(int i=1;i<=m;i++)data[i]=data[i-1]*(int)2ll;
	for(int i=1;i<=n;i++)
		for(int j=0;j<m;j++)
			if(a[i]&data[j])f[i][j]=1;
	for(int j=0;j<m;j++)
		for(int i=1;i<=n;i++)
			cnt[j]+=f[i][j];
	int s=m-1,ans=0;
	while(s&&cnt[s]==n)ans+=data[s]*n,s--;
	ans+=data[s]*n;
	int len=n;
	for(int i=1;i<=n;i++)
		if(f[i][s]){
			len--;
			for(int j=0;j<s;j++)ans+=data[j]*f[i][j];
			for(int j=0;j<=m;j++)f[i][j]=0;
		}
	memset(cnt,0,sizeof cnt);
	for(int j=0;j<m;j++)
		for(int i=1;i<=n;i++)
			cnt[j]+=f[i][j];
	for(int i=0;i<s;i++)ans+=data[i]*max(len-cnt[i],cnt[i]);
	write(ans);flush();
	exit(0);
}
signed main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=n;i++)a[i]=read();
	if(k==1)solve_sub1();
	return 0;
}

