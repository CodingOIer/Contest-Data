#include<bits/stdc++.h>
using namespace std;
int plen,pstk[1<<20];
char out[1<<20];
inline void flush(){fwrite(out,1,plen,stdout);plen=0;}
inline void pc(char x){out[plen++]=x;}
inline int read(){
	int x=0,f=0;char ch=getchar();
	while(ch<'0'||ch>'9'){f=(ch=='-'?-1:f);ch=getchar();}
	while('0'<=ch&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return f?-x:x;
}
inline void write(int x){
	if(plen>=1e6)flush();
	if(x<0)pc('-'),x=-x;
	int len=0;
	for(;x;x/=10)pstk[++len]=x%10;
	while(len)pc(pstk[len--]+'0');
}
int main(){
	int n=read();
	write(n);flush();
	return 0;
}

