#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
int tid,T,l,r;
void solve()
{
	read(l),read(r);
	if(l==r&&(int)sqrt(l)*(int)sqrt(l)==l) puts("1");
	else puts("2");
}
signed main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	read(tid),read(T);
	while(T--) solve();
	return 0;
}

