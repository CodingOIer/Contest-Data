#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
//Alice����Bobȡ���ֵ->Aliceȡ�δ� 
//1.û�δ�->BobӮ
//2.�δ�Ϊ����->AliceӮ
//3.�δ�Ϊż��->Aliceȡ�δδ�
//�Դ�����
const int N = 1e5+5;
int n,a[N],cnt,las;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n);
	for(int i = 1;i<=n;i++)
		read(a[i]);
	sort(a+1,a+n+1);
	las = n;
	while(las>0)
	{
		for(int i = las;~i;i--)
			if(a[i]==a[las])
				cnt++;
			else
			{
				las = i;
				break;
			}
		if(cnt%2==1) return puts("Alice"),0;
	}
	puts("Bob");
	return 0;
}

