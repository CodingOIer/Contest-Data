#include <bits/stdc++.h>
#define int long long
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int N = 100;
int n,m,k,a[N],ans;
signed main()
{
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	read(n),read(m),read(k);
	for(int i = 1;i<=n;i++) read(a[i]),ans+=a[i];
	for(int i = (1ll<<m)-1;i;i--)
	{
		if((double)clock()/CLOCKS_PER_SEC>0.95) break;
		int now = 0;
		for(int j = 1;j<=n;j++)
			now+=max(a[j],(a[j]^i));
		ans = max(ans,now);
	}
	write(ans);
	return 0;
}

