#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 21], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 2e5 + 5;
array <int, N> s;
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n = read();
	for (int i = 1; i <= n; i++)
		s[i] = read();
	sort(s.begin() + 1, s.begin() + 1 + n, greater <int>());
	int now = 0;
	bool flg = false;
	/* write(s[2]), puts("@"); */
	for (int i = 1; i <= n + 1; i++) {
		if (s[i] != s[i - 1]) {
			if (now & 1) {
				flg = 1;
				break;
			}
			now = 1;
			continue;
		}
		else now++;
	}
	if (flg) puts("Alice");
	else puts("Bob");
	return 0;
}
