#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,m,ans[50];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    n=read(),m=read();
    if(m==2){
        printf("%lld\n%lld\n",n,1ll);
        return 0;
    }
    if(m==3){
        printf("%lld\n%lld\n%lld\n",3+(n-2)*3+(n-2)*(n-3)/2,n/2+1,(n+1)/2);
        return 0;
    }
    return 0;
}