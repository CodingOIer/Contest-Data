#include <bits/stdc++.h>
#define int long long
using namespace std;
int t,id,l,r;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("B.in","r",stdin);
    freopen("B.out","w",stdout);
    id=read(),t=read();
    while(t--){
        l=read(),r=read();
        if(l==r)
            puts("1");
        else
            puts("2");
    }
    return 0;
}