#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int n,a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("A.in","r",stdin);
    freopen("A.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    sort(a+1,a+1+n);
    for(int i=n;i>0;i--){
        int x=i,tot=0;
        while(a[x]==a[i]&&x>0)
            ++tot,--x;
        if(tot%2){
            puts("Alice");
            return 0;
        }
        i=x+1;
    }
    puts("Bob");
    return 0;
}
