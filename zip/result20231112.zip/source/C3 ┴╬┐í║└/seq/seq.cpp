#include<bits/stdc++.h>
using namespace std;
//#define int long long
const int mod=1e9+7;
inline int Mod(int x){if(x>=mod)x-=mod;return x;}
int n,m;
struct node{
	int a[40][40][40];
	void Init(){
		memset(a,0,sizeof a);
	}
}f;
int sum[40];
node w(node A,node B){
	node C;C.Init();
	for(int r=0;r<m;r++){
		for(int s=0;s<m;s++){
			for(int l=r-1;l>=0;l--){
				B.a[l][r][s]=Mod(B.a[l][r][s]+B.a[l+1][r][s]);
			}
		}
	}
	for(int l=0;l<m;l++){
		for(int mid=l;mid<m;mid++){
			for(int s_1=0;s_1<m;s_1++){
				if(A.a[l][mid][s_1]==0)continue;
				for(int r=mid;r<m;r++){
					for(int s_2=0;s_2<m;s_2++){
						if(B.a[mid][r][s_2]==0)continue;
						int s=s_1*s_2%m;
						C.a[l][r][s]=Mod(C.a[l][r][s]+(1ll*A.a[l][mid][s_1]*B.a[mid][r][s_2]%mod));
					}
				}
			}
		}
	}
	return C;
}
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	cin>>n>>m;
	f.Init();
	for(int i=0;i<m;i++)f.a[i][i][i]=1;
	node ans;ans.Init();
	ans.a[0][0][1]=1;
	while(n){
		if(n&1)ans=w(ans,f);
		f=w(f,f);
		n>>=1;
	}
	for(int l=0;l<m;l++){
		for(int r=l;r<m;r++){
			for(int s=0;s<m;s++){
				sum[s]=Mod(sum[s]+ans.a[l][r][s]);
			}
		}
	}
	for(int i=0;i<m;i++)cout<<sum[i]<<'\n';
	return 0;
}


