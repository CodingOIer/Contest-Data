#include<bits/stdc++.h>
using namespace std;
bool check_4(int l,int r){
	if(r-l+1>=32)return 0;
	int sum=1;
	for(int i=l;i<=r;i++)sum=sum*i%32;
}
signed main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	srand(114514);
	int ops,T;
	cin>>ops>>T;
	while(T--){
		int l,r;
		cin>>l>>r;
		if(ops==1){
			if(l==r&&int(sqrt(l))*int(sqrt(l))==l)cout<<"1\n";
			else cout<<"2\n";
		}else{
			if(rand()%19<=8)cout<<"4\n";
			else cout<<"3\n";
		}
	}
	return 0;
}


