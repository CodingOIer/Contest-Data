#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=50,Mod=1e9+7;
int N,M,tot[Maxn],A[50];

int Power(int x,int d,int r=1){
    while(d){if(d&1) (r*=x)%=M; (x*=x)%=M,d>>=1;}
    return r;
}

void DFS(int x,int r,int v){
    if(x>M) return (++tot[v])%=Mod,void();
    if(x==M) A[x]=r,DFS(x+1,0,v*Power(x,r)%M);
    else For(i,0,r) A[x]=i,DFS(x+1,r-i,v*Power(x,i)%M);
}

signed main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    N=read(),M=read();
    if(M==2) write(M),printf("\n1"),exit(0);
    if(M==3) write((N+1)*N/2),pc('\n'),write(N/2+1),pc('\n'),write((N+1)/2),exit(0);
    DFS(1,N,1);
    For(i,0,M-1) write(tot[i]),pc('\n');
    return 0;
}
/*
g++ seq.cpp -o seq -O2
./seq
*/