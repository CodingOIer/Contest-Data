#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,A[Maxn];
map<int,int> V;

signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    N=read(); For(i,1,N) A[i]=read(),++V[A[i]];
    sort(A+1,A+N+1); N=unique(A+1,A+N+1)-A-1;
    Rof(i,N,1) if(V[A[i]]&1) printf("Alice"),exit(0);
    printf("Bob");
    return 0;
}
/*
g++ game.cpp -o game -O2
./game
*/