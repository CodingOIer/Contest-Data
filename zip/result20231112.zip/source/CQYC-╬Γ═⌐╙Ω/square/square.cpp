#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

int id,T;

signed main(){
    srand(time(0));
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    id=read(); T=read();
    while(T--){
        int l=read(),r=read();
        if(id==2){
            write((rand()&1)?3:4),pc('\n');
            continue;
        }
        if(l==r){
            int t=sqrt(l);
            if(t*t==l) puts("1");
            else puts("2");
        }else puts("2");
    }
    return 0;
}
/*
g++ square.cpp -o square -O2
./square
*/