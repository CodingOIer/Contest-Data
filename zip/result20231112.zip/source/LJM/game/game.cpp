#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n;
int a[N];
map<int, int>f;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
    scanf("%lld", &n);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    sort(a + 1, a + n + 1);
    for(int i = 1; i <= n; i++) f[a[i]]++;
    for(int i = 1; i <= n; i++) {
    	if(i == 1 || a[i] != a[i - 1]) {
    		if(f[a[i]] % 2 != 0) {
    			cout << "Alice";
    			return 0;
			}
		}
	}
	cout << "Bob";
	return 0;
}

