#include<bits/stdc++.h>
#define int long long
#define mod 1000000007
using namespace std;
int n, m;
int Pow(int a, int n) {
	if(n == 0) return 1;
	if(n == 1) return a % mod;
	int x = Pow(a, n / 2);
	if(n % 2 == 0) return x * x % mod;
	else return x * x % mod * a % mod;
}
int inv(int x) {
	return Pow(x, mod - 2);
}
signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
    cin >> n >> m;
    if(m == 2) {
    	cout << n % mod << endl << 1;
    	return 0;
	}
	if(m == 3) {
		cout << (n * n - (1 + n) * n / 2 + n) % mod << endl;
		cout << (n / 2 + 1) % mod << endl;
		cout << (n + 1 - (n / 2 + 1)) % mod << endl;
		return 0;
	}
	if(m == 4) {
		int s0 = 0, s1 = 0, s2 = 0, s3 = 0;
		s0 = ((n - 1) * n % mod * (2 * n - 1) % mod * inv(12) % mod + 3 * n * (n - 1) % mod * inv(4) % mod + n) % mod;
		s0 = (s0 + (n * (n - 2 + 1) - (1 + n) * n / 2 + n) % mod) % mod;
		s1 = n / 2 + 1;
		s3 = (n + 1) - (n / 2 + 1);
		s2 = n;
		cout << s0 << endl << s1 << endl << s2 << endl << s3 << endl;
	}
	return 0;
}

