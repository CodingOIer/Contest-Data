#include<bits/stdc++.h>
#define int long long
using namespace std;
int n, m, k;
int a[1000], ans;
signed main() {
	freopen("xor.in", "r", stdin);
	freopen("xor.out", "w", stdout);
    cin >> n >> m >> k;
    for(int i = 1; i <= n; i++) cin >> a[i];
    int z = 1;
    if(m <= 20) for(int i = 1; i <= m; i++) z *= 2;
    else z = 1000000;
    z--;
    for(int x = 0; x <= z; x++) {
    	int now = 0;
    	for(int i = 1; i <= n; i++) {
    		now += max(a[i] ^ x, a[i]);
		}
		ans = max(ans, now);
	}
	cout << ans;
	return 0;
}

