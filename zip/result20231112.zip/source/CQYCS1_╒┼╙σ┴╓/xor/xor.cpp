#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline ll read(){ll s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e2+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353;
using namespace std;
ll a[N],sum;
ll ans,n,m,k;
vector<int>p[140];
inline void solve(int x){
    int siz=p[x].size();
    if(!siz)return;
    ll del=1LL*(1LL<<x)*siz;
    rep(i,0,x-1){
        int cnt=0;
        E(x)cnt+=((a[y]>>i)&1);
        del+=1LL*(1LL<<i)*(max(cnt,siz-cnt)-cnt);
    }
    ans=max(ans,sum+del);
}
int main(){
	freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    n=read(),m=read(),k=read();
    rep(i,1,n)a[i]=read(),sum+=a[i];
    ans=sum;
    rep(i,1,n){
        rep(j,0,m-1)if(!((a[i]>>j)&1))p[j].pb(i);
    }
    rep(i,0,m-1)solve(i);
    cout <<ans;
    return 0;
}