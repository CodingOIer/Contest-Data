#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =5e5+5,M=5e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m;
inline ll qp(ll a,ll b){
    if(!b)return 1;
    ll c=qp(a,b>>1);
    c=c*c%mod;
    if(b&1)c=c*a%mod;
    return c;
}
ll inv[N];
inline void prep(){
    rep(i,1,50)inv[i]=qp(i,mod-2);
}
inline ll c(int x,int y){
    if(x<y)return 0;
    ll ans=1;
    rep(i,x-y+1,x)ans=ans*i%mod;
    rep(i,1,y)ans=ans*inv[i]%mod;
    return ans;
}
int main(){
	freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    n=read(),m=read();
    if(m==2){
        printf("%d\n%d",n,1);
        return 0;
    }
    prep();
    if(m==3){
        ll ans0=0,ans1=0,ans2=0;
        ans1=(n+2)/2,ans2=n+1-ans1;
        ans0=(c(n+2,2)-n-1+mod)%mod;
        printf("%lld\n%lld\n%lld",ans0,ans1,ans2);
        return 0;
    }
    if(m==4){
        ll ans0=0,ans1=0,ans2=0,ans3=0;
        //只考虑1，2,3
        //第一种，2没选
        //模数的循环为，1 3 1 3
        //          ，0 1 2 3 
        ans1=(n+2)/2,ans3=n+1-ans1;
        //第二种，2选了一个
        //模数的循环为，2 2 2 2
        ans2=n;
        //剩下的模数全都是0
        ans0=c(n+3,3);
        ll s=(ans1+ans2+ans3)%mod;
        ans0=(ans0-s+mod)%mod;
        printf("%lld\n%lld\n%lld\n%lld",ans0,ans1,ans2,ans3);
        return 0;
    }
    return 0;
}