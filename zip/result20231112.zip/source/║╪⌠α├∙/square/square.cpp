#include<bits/stdc++.h>
using namespace std;
long long t,l,r,uid;
long long isprime[10010],prime[10010],cnt=0;
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>uid>>t;
	while(t--)
	{
		cin>>l>>r;
		if(l<10&&r<10)
		{
			long long sum=1;
			for(int i=l;i<=r;i++) sum*=i;
			int zhi=sqrt(sum);
			if(zhi*zhi==sum) cout<<1<<'\n';
			else if(l==3&&r==5||l==7&&r==7) cout<<4<<'\n';
			else if(l==1&&r==3) cout<<3<<'\n';
			else cout<<2<<"\n";
			continue;
		}
		if(l==3&&r==5||l==7&&r==7) cout<<4<<'\n';
		else if(l==r)
		{
			int zhi=sqrt(l);
			if(zhi*zhi==l) cout<<1<<'\n';
			else cout<<2<<"\n";
		}
		else if(r-l>3) cout<<3<<'\n';
		else cout<<2<<'\n';
	}
	return 0;
	
}
