#include<bits/stdc++.h>
using namespace std;
int t;
int main()
{
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	long long n,k;
	cin>>n>>k;
	if(k==2) cout<<n-1<<"\n"<<1<<'\n';
	return 0;
}
