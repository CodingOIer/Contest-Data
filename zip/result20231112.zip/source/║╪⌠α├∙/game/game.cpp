#include<bits/stdc++.h>
using namespace std;
int n,f[100100];
map<int,int> mp;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>f[i],mp[f[i]]++;
	for(auto to:mp)
	{
		int sh=to.second;
		if(sh%2==1){cout<<"Alice";return 0;}
	}
	cout<<"Bob";
	return 0;
}
