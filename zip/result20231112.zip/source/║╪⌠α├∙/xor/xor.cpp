#include<bits/stdc++.h>
using namespace std;
__int128 f[130],ans=0,state[130],dp[130][10];
__int128 er[130];
__int128 n,m,up;
inline __int128 read()
{
	__int128 x=0,f=1;char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while('0'<=c&&c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x*f;
}
inline void write(__int128 x)
{
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10+'0');
}
__int128 count(__int128 x)
{
	__int128 sum=0;
	while(x)
	{
		if(x%2) sum++;
		x/=2;
	}
	return sum;
}
__int128 calc(__int128 l,__int128 r)
{
 	__int128 zh=state[l],ans=0;
	__int128 b=count(zh);
	//cout<<"!!!!!!!!!!!!!!\n"<<l<<" "<<r<<" "<<b<<" ";write(zh);cout<<"\n";
	for(__int128 i=l;i<=r;i++)
	{
		//write(zh),cout<<' ',write(state[i]),cout<<"\n";
		__int128 have=count((zh&state[i])),y=count(state[i]);
		ans+=(b-2*(b-have))*er[m-i];
	}
	//write(ans);
	//cout<<'\n';
	return ans;
}
int main()
{
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	n=read(),m=read(),up=read();
	for(__int128 i=1;i<=n;i++) f[i]=read(),ans+=f[i];
	__int128 nw=1;
	er[0]=1;
	for(__int128 i=1;i<=m;i++) er[i]=er[i-1]*2;
 	for(__int128 j=0;j<m;j++)
	{
		__int128 wei=0,is=1;
		for(__int128 i=1;i<=n;i++)
		{
			if(!(f[i]&nw)) wei+=is;
			is*=2;
		}
		state[j+1]=wei;
		nw*=2;
 	}
	memset(dp,-0x3f,sizeof dp);
	dp[0][0]=0;
 	reverse(state+1,state+m+1);
	for(__int128 i=1;i<=m;i++)
		for(__int128 j=i-1;j>=0;j--)
			for(__int128 k=1;k<=min(i,up);k++) dp[i][k]=max(dp[i][k],dp[j][k-1]+calc(j+1,i));
	__int128 maxx=0;
	for(__int128 i=1;i<=m;i++)
		for(__int128 k=0;k<=min(i,up);k++) maxx=max(maxx,dp[i][k]);
	write(maxx+ans);
	return 0;
}
