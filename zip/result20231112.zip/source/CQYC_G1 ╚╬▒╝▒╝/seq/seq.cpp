#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 45 ;
const int MOD = 1e9+7 ;
int m,n ;
int a[N] ;
int dis[N],val[N] ;
struct Edge
{
	int v,w ;
	bool operator < (const Edge &A) const
	{
		return w > A.w ;
	}
};
vector<Edge>e[N] ;
inline void Solve()
{
	me(dis,0x3f),dis[1] = 1 ;
	priority_queue<Edge>q ; q.push({1,1}) ;
	while(!q.empty())
	{
		Edge x = q.top() ; q.pop() ;
		if(x.w != dis[x.v]) continue ;
		for(auto v:e[x.v]) 
		{
			if(dis[v.v] <= dis[x.v]+v.w) continue ;
			dis[v.v] = dis[x.v]+v.w,q.push({v.v,dis[v.v]}) ;
		}
	}
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("seq.in","r",stdin) ;
	freopen("seq.out","w",stdout) ;
    read(m,n) ;
    if(n == 2)
    {
        print(m,min(1,m)),enter ;
    }
    else
    {
        FOR(i,0,n,1)
        {
            FOR(j,1,n,1)
            {
                e[i].pb({i*j%m,1}) ;
            }
        }
        FOR(i,1,n-1,1)
        {
            val[i] = 1 ; int x = i ;
            while(x != 1 && x) x = x*i%n,++val[i] ;
        }
        Solve() ;
        FOR(i,0,m-1,1) print(n/dis[i]),enter ;
    }
    return 0 ;
}