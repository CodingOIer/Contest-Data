#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 205 ;
int n,m,k,ans ;
int vis[N],a[N],d[N][2],mi[N] ;
int calc()
{
    int res = 0 ;
    FOR(i,0,m,1) res += max(d[i][0],d[i][1])*(1<<i) ;
    FOR(i,1,n,1) if(!vis[i]) res += a[i] ; return res ; 
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("xor.in","r",stdin) ;
	freopen("xor.out","w",stdout) ;
    read(n,m,k) ;
    FOR(i,1,n,1) read(a[i]),ans += a[i] ; //print(ans),enter ;
    if(k == 1)
    {
        FOR(i,1,n,1) FOR(j,0,m,1) d[j][(a[i]>>j)&1]++,vis[i] = 1 ;
        ans = max(calc(),ans) ;
        FOR(i,1,n,1)
        {
            FOR(j,1,n,1) 
            {
                vis[j] = 0 ;
                FOR(j,0,m,1) d[j][(a[i]>>j)&1]-- ;
                if(calc() > ans) ans = calc() ;
                else
                {
                    vis[j] = 1 ;
                    FOR(j,0,m,1) d[j][(a[i]>>j)&1]++ ;
                }
            }
        }
        print(ans),enter ;
    }
    return 0 ;
}