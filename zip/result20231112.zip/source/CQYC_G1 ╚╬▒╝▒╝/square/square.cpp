#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e5+5 ;
int T,L,R,ty,top ;
int pri[N],vis[N] ;
map<int,int>mp ;
void Solve()
{
    int rp = sqrt(R) ;
    read(L,R) ;
    // BigInt res = 1 ;
    if(ty == 1)
    {
        if(rp*rp == R) print(1),enter ;
        else print(2),enter ;
    }
    else
    {
        int res = 1,tot = 0 ;
        FOR(i,L,R,1)
        {
            int x = i ;
            while(x%2 == 0) x /= 2,++tot ;
            res = res*x%8 ;
        }
        if(tot&1) res = res*2%8 ;
        if(res == 7)
        {
            print(4),enter ;
            return ;
        }
        mp.clear() ;
        FOR(i,L,R,1)
        {
            int x = i ;
            for(int j = 1 ; pri[j]*pri[j] <= i ; ++j)
            {
                if(x%pri[j]) continue ;
                while(x%pri[j] == 0) x /= pri[j],mp[pri[j]]++ ;
            }
            if(x != 1) mp[x]++ ;
        }
        int chk1 = 1,chk2 = 1 ;
        for(auto [key,val]:mp)
        {
            chk1 &= val%2 == 0 ;
            if(key%4 == 3) chk2 &= val%2 == 0 ;
        }
        if(chk1) print(1) ;
        else if(chk2) print(2) ;
        else print(3) ; enter ;
    }
}
void Init()
{
    FOR(i,2,N-5,1)
    {
        if(!vis[i]) pri[++top] = i ;
        for(int j = 1 ; i*pri[j] <= N-5 ; ++j)
        {
            vis[i*pri[j]] = 1 ;
            if(i%pri[j] == 0) break ;
        }
    }
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("square.in","r",stdin) ;
	freopen("square.out","w",stdout) ;
    // FOR(i,1,7,1)
    // {
    //     print(4*i%8),enter ;
    // }
    read(ty,T),Init() ; while(T--) Solve() ;
    // FOR(i,201,400,1)
    // {
    //     int x = i ;
    //     while(x%4 == 0) x /= 4 ;
    //     print(x%8) ; if(i%8 == 0) enter ;
    // }
    // enter ;
    return 0 ;
}