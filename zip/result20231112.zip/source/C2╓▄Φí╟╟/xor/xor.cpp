#include<bits/stdc++.h>
using namespace std;
const int N=125;
int n,m,k;
long long a[N],ans,sum,x,y;
int b[N],cnt;
int main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;++i) scanf("%lld",&a[i]);
	if(k==1&&n<=55){
		for(int i=0;i<m;++i){
			cnt=0;
			for(int j=1;j<=n;++j)
				if((a[j]>>i)&1) b[++cnt]=j;
			sum=0;
			for(int l=0;l<m;++l){
				x=y=0;
				for(int j=1;j<=cnt;++j)
					if((a[b[j]]>>l)&1) x+=1ll<<l;
					else y+=1ll<<l;
				sum+=max(x,y);
			}
			ans=max(ans,sum);
		}
		printf("%lld\n",ans);
		return 0;
	}else{
		for(long long v=0;v<(1ll<<m);++v){
			sum=0;
			for(int i=1;i<=n;++i)
				sum+=max(a[i]^v,a[i]);
			ans=max(ans,sum);
		}
		cout << ans << '\n';
		puts("bu hui,bai le.chu ti ren wo xie xie ni");
	}
	return 0;
}

