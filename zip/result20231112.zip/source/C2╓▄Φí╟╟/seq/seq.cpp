#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m,f[2][4000001][40],mu_leaf;
inline void add(int &x,int y){x+=y;if(x>=mod)x-=mod;}
int main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==2){
		printf("%d\n1\n",n);
		return 0;
	}
	f[0][0][1]=1;
	for(int i=1;i<=m;++i){
		for(int j=0;j<=n;++j){
			for(int l=0;l<m;++l) f[i&1][j][l]=0;
			for(int l=0;l<m;++l){
				mu_leaf=1;
				for(int k=0;k<=j;++k){
					add(f[i&1][j][l*mu_leaf%m],f[!(i&1)][j-k][l]);
					mu_leaf=mu_leaf*i%m;
				}
			}
		}
	}
	for(int i=0;i<m;++i) printf("%d\n",f[m&1][n][i]);
	return 0;
}

