#include<bits/stdc++.h>
using namespace std;
long long id,T,l,r,k;
int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%lld%lld",&id,&T);
	while(T--){
		scanf("%lld%lld",&l,&r);
		if(l==r){
			k=sqrt(l);
			printf("%d\n",2-(k*k==l));
		}else puts("2");
	}
	return 0;
}

