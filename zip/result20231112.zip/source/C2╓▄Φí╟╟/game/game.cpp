#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,a[N];
bool cnt;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i){
		cnt^=1;
		if(a[i]!=a[i+1]&&cnt){
			puts("Alice");
			return 0;
		}
	}
	puts("Bob");
	return 0;
}

