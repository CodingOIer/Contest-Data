#include<bits/stdc++.h>
#define int __int128
#define rep(i,a,b) for(auto i(a);i<=(b);++i)
#define req(i,a,b) for(auto i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,m,k,a[121],ans,val,res,b[121],opt;
mt19937 rnd(998244353);
signed main()
{
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	read(n,m,k);
	rep(i,1,n) read(a[i]);
	int lim=(__int128)1<<m;
	rep(i,1,n) ans+=a[i];
	memcpy(b,a,sizeof b);
	while(clock()<0.95*CLOCKS_PER_SEC)
	{
		val=rnd()%lim,res=0;
		rep(i,1,n) {if((a[i]^val)>a[i]) a[i]^=val; res+=a[i];}
		ans=max(ans,res);
		++opt;
		if(opt==k) memcpy(a,b,sizeof a),opt=0;
	}
	writeln(ans);
	return 0;
}
