#include<bits/stdc++.h>
#define int long long
#define rep(i,a,b) for(auto i(a);i<=(b);++i)
#define req(i,a,b) for(auto i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	TP x=0;
	int f=0;
	char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
	(x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,a[100001];
unordered_map<int,int> mp;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n);
	rep(i,1,n) read(a[i]),++mp[a[i]];
	for(const auto& i:mp) if(i.second&1) return puts("Alice"),0;
	puts("Bob");
	return 0;
}
