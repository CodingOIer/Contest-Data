#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    int n,m;
    cin >> n >> m;
    cout << n << endl << 1 << endl;
    return 0;
}