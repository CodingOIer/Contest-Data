#include <iostream>
#include <cstring>
#include <algorithm>
#include <unordered_set>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 100005;
int a[N];
int n;

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n = in;
    unordered_set<int> s;
    for(int i=1;i<=n;i++){
        int x = in;
        if(!s.count(x))
            s.insert(x);
        else
            s.erase(x);
    }
    puts(s.empty()?"Bob":"Alice");
    return 0;
}