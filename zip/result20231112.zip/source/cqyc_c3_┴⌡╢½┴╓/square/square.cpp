#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 31625;

int w[8];
void count(int n,int v){
    for(int k=0;k<8;k++)
        w[k] += n/8*v;
    for(int k=n/8*8+1;k<=n;k++)
        w[k%8] += v;
}

int ksm(int a,int b,int mod){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

int main(){
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    int id = in,t = in;
    while(t--){
        int l = in,r = in;
        if(l==r){
            int d = sqrtl(l);
            if(d*d==l){
                puts("1");
                continue;
            }
        }
        if(id==1){
            puts("2");
            continue;
        }
        auto check4 = [&]{
            memset(w,0,sizeof(w));
            count(r,1);
            count(l-1,-1);
            int sum = 1;
            for(int k:{3,5,7})
                sum = sum*ksm(k,w[k],8)%8;
            if(w[2]&1)
                sum = sum*2%8;
            return sum==7;
        };
        if(check4()){
            puts("4");
            continue;
        }
        if(id==2){
            puts("3");
            continue;
        }
        if(id==3){
            puts("2");
            continue;
        }
        auto check2 = [&]{
            int s = 1;
            for(int k=l;k<=r;k++){
                s *= k;
                if(s>1e9)
                    return false;
            }
            for(int k=1;k*k<=s;k++){
                int d = sqrtl(s-k*k);
                if(d*d+k*k==s)
                    return true;
            }
            return false;
        };
        if(check2())
            puts("2");
        else
            puts("3");
    }
    return 0;
}