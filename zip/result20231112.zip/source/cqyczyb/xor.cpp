#include <bits/stdc++.h>
#define int unsigned long long 
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='0'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=125;
int n,m,k,a[N],p[N];
int ans[2],t[N][2],sum[2];
//void sub1() {
//	for(int i=0;i<=m;++i) p[i]=1ll<<i;
//	for(int i=1;i<=n;++i) {
//		int id=0;
//		if(p[m-1]&a[i]) id=1;
//		++t[m-1][id],sum[id]+=a[i];
//		for(int j=0;j<m-1;++j) if(a[i]&p[j]) ++t[j][id];
//	}
//	for(int i=0;i<m-1;++i)
//	for(int j=0;j<2;++j)
//		ans[j]+=max(t[i][j],t[m-1][j]-t[i][j])*p[i];
//	ans[0]+=t[m-1][0]*p[m-1];
//	ans[1]+=t[m-1][1]*p[m-1];
//	cout<<max(ans[0]+sum[1],ans[1]+sum[0]);
//	exit(0);
//}
int res,tt[2];
void genshin() {
	for(int i=0;i<=m;++i) p[i]=1ll<<i;
	for(int _=1;_<=k;++_) {
		bool flag=1;
		for(int i=1;i<n;++i) if(a[i]!=a[i+1]) flag=0;
		if(flag) {
			for(int i=1;i<=n;++i) a[i]=p[m]-1;
			break;
		}
		for(int i=m-1;i>=0;--i) {
			tt[0]=tt[1]=0;
			for(int j=1;j<=n;++j) ++tt[(a[j]&p[i])>>i];
			if(!tt[0]||!tt[1]) continue;
			tt[0]=tt[1]=sum[0]=sum[1]=ans[0]=ans[1]=0;
			memset(t,0,sizeof t);
			for(int j=1;j<=n;++j) {
				int id=0;
				if(p[i]&a[j]) id=1;
				++t[i][id],sum[id]+=a[j];
				for(int k=0;k<i;++k) if(a[j]&p[k]) ++t[k][id];
			}
			for(int j=0;j<i;++j)
			for(int k=0;k<2;++k) {
				ans[k]+=max(t[j][k],t[i][k]-t[j][k])*p[j];
				tt[k]|=t[j][k]>t[i][k]-t[j][k]?0:p[j];
			}
			int id=0;
			tt[0]|=p[i];
			ans[0]+=t[i][0]*p[i]+sum[1];
			ans[1]+=t[i][1]*p[i]+sum[0];
//			cerr<<i<<" "<<ans[0]<<" "<<tt[0]<<" "<<ans[1]<<" "<<tt[1]<<endl;
			if(ans[0]<ans[1]) id=1;
			for(int j=1;j<=n;++j) {
				if(((a[j]&p[i])>>i)==id) a[j]^=tt[id];
				for(int k=m-1;k>i;--k) a[j]|=p[k];
//				cerr<<a[j]<<" ";
			}
//			cerr<<endl;
			break;
		}
	}
	for(int i=1;i<=n;++i) res+=a[i];
	cout<<res;
	exit(0);
}
signed main() {
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;++i) a[i]=read();
//	if(k==1&&n<=55&&m<=55) sub1();
//	else 
	genshin();
	return 0;
}
/*
4 4 2
0 4 2 12

55
*/
