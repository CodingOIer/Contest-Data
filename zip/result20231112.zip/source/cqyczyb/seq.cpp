#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='0'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=45,mod=1e9+7;
int n,m;
void norun2round() {
	cout<<n<<'\n'<<1;
	exit(0);
}
signed main() {
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	n=read(),m=read();
	if(m==2) norun2round();
	return 0;
}
/*
114514 2


*/

