#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='0'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,a[N];
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	sort(a+1,a+1+n);
	reverse(a+1,a+1+n);
	for(int i=2;i<=n+1;++i) {
		if(a[i]!=a[i-1]&&!(i&1)) {
			puts("Alice");
			return 0;
		}
	}
	puts("Bob");
	return 0;
}
/*
3
1 2 3

Alice

2
1 1

Bob
*/

