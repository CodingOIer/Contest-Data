#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='0'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int sq(int x) {
	return x*x;
}
signed main() {
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	read();
	int _=read();
	while(_--) {
		int l=read(),r=read();
		if(l==r&&sq(sqrt(l))==l) puts("1");
		else puts("2");
	}
	return 0;
}
/*
*/

