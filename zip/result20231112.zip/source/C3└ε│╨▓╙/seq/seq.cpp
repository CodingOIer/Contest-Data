#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
const int mod=1000000007;
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	if(m==2){
		printf("%lld\n%lld",n%mod,1);
		return 0;
	}
	if(m==3){
		printf("%lld\n",((1+n)*n/2)%mod);
		printf("%lld\n",(n/2+1)%mod);
		printf("%lld\n",((n+1)/2)%mod);
		return 0;
	}
	return 0;
}


