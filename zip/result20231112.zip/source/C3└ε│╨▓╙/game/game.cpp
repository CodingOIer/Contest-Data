#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int a[100005];
int mx,s;
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	sort(a+1,a+n+1);
	mx=a[n];
	for(int i=n;i>=1;i--){
		if(mx==a[i]) s++;
		else{
			if(s&1){
				printf("Alice");
				return 0;
			}
			else mx=a[i],s=1;
		}
	}
	printf("Bob");
	return 0;
}


