#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int id,l,r;
int fac[1000005];
signed main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%lld %lld",&id,&T);
	while(T--){
		scanf("%lld %lld",&l,&r);
		if(id==1){
			if(l==r){
				int o=sqrt(l);
				if(o*o==l) printf("1\n");
				else printf("2\n");
			}
			else printf("2\n");
			continue;
		}
	}
	return 0;
}


