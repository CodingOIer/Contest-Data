#include<bits/stdc++.h>
using namespace std;
int f[200005];
void check(int x) {
	int minn=1e9;
	
	for(int i=(int)sqrt(x);i>=1;i--) {
		
		minn=min(minn,f[x-i*i]+1);
	}
	f[x]=minn;
}
int main() {
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		check(i);
	}	
	for(int i=1;i<=n;i++) {
		printf("%d:%d\n",i,f[i]);
	}
	return 0;
} 
