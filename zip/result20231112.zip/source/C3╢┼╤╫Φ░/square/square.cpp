#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int T,id;
	scanf("%d %d",&id,&T);
	while(T--) {
		int l,r;
		scanf("%d %d",&l,&r);
		if(l==r && (int)sqrt(l)*(int)sqrt(l)==l) printf("1");
		else printf("2");
	}
	return 0;
} 
