#include<bits/stdc++.h>
using namespace std;
int a[100005];
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,len=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	for(int i=n;i>=1;i--) {
		len++;
		if(a[i]!=a[i-1]) {
			if(len%2==1) {
				printf("Alice");
				return 0;
			}
			len=0;
		}
	}
	printf("Bob");
	return 0;
} 
