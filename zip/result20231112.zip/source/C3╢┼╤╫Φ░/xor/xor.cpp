#include<bits/stdc++.h>
#define int long long
using namespace std;
int pw[61],f[61];
signed main() {
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	pw[0]=1;
	for(int i=1;i<=60;i++) pw[i]=pw[i-1]*2;
	int n,m,k;
	scanf("%lld %lld %lld",&n,&m,&k);
	for(int i=1;i<=n;i++) {
		int x,len=0;
		scanf("%lld",&x);
		while(x) {
			f[len]+=(x&1);
			x>>=1;
			len++;
		}
	}
	int ans=0;
	for(int i=0;i<=m;i++) {
		ans+=pw[i]*max(f[i],n-f[i]);
	}
	printf("%lld",ans);
	return 0;
}
