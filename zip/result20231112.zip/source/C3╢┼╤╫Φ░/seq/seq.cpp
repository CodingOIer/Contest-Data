#include<bits/stdc++.h>
#define int long long
using namespace std;
int f[45][10005][45];
const int mod=1e9+7;
int n,m;
int ksm(int x,int y) {
	int ans=1;
	while(y) {
		if(y&1) ans=(ans*x)%m;
		x=(x*x)%m;
		y>>=1;
	}
	return ans;
} 
signed main() {
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout); 
	scanf("%lld %lld",&n,&m);
	if(m==2) printf("%lld\n%lld\n",n,1);	
	else {
		f[0][0][1]=1;
		for(int i=1;i<=m;i++) {
			for(int j=0;j<=n;j++) {
				for(int k=0;k<=n;k++) {
					if(k+j>n) break;
					for(int w=0;w<m;w++) {
						f[i][k+j][(ksm(i,k)*w)%m]=(f[i][k+j][(ksm(i,k)*w)%m]+f[i-1][j][w])%mod;	
					}
				}
			}
		}
		for(int i=0;i<m;i++) {
			printf("%lld\n",f[m][n][i]);
		}
	}
	return 0;
}
