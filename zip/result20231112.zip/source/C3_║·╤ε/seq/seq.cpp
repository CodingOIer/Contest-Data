#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9 + 7;
int n, m;
int f[21][100010][21];
int ksm(int x, int y){
    int s = 1;
    while(y){
        if(y & 1) s = s * x % m;
        x = x * x % m;
        y >>= 1;
    }
    return s;
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("seq.in", "r", stdin);
    freopen("seq.out", "w", stdout);
    cin >> n >> m;
    if(m == 2){
        cout << n - 1 << '\n' << 1 << '\n';
        return 0;
    }
    f[0][0][1] = 1;
    for(int i = 1 ; i <= m ; i++){
        for(int j = 0 ; j <= n ; j++){
            for(int k = 0 ; k < m ; k++){
                for(int x = 0 ; x + j <= n ; x++){
                    // cout << j + x << " " << k * ksm(i, x) % mod << endl;
                    f[i][j + x][k * ksm(i, x) % m] = (f[i][j + x][k * ksm(i, x) % m] + f[i - 1][j][k]) % mod;
                }
            }
        }
    }
    for(int i = 0 ; i < m ; i++) cout << f[m][n][i] << '\n';
    return 0;
}