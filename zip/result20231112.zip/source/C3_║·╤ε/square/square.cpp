#include<bits/stdc++.h>
#define int long long
using namespace std;
int T, l, r, id;
signed main(){
    ios::sync_with_stdio(false);
    freopen("square.in", "r", stdin);
    freopen("square.out", "w", stdout);
    cin >> id;
    cin >> T;
    while(T--){
        cin >> l >> r;
        if(l == r){
            if(l = (int)sqrt(l) * (int)sqrt(l)) cout << 1 << '\n';
            else cout << 2 << '\n';
        }
        else cout << 2 << '\n';
    }
    return 0;
}