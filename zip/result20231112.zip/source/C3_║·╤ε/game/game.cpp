#include<bits/stdc++.h>
#define int long long
using namespace std;
int n, s, ans;
int a[100010];
signed main(){
    ios::sync_with_stdio(false);
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    cin >> n;
    for(int i = 1 ; i <= n ; i++) cin >> a[i];
    sort(a + 1, a + n + 1);
    for(int i = n ; i >= 1 ; i--){
        s++;
        if(a[i] != a[i - 1]){
            if(s % 2 == 1) ans = 1;
            s = 0;
        }
    }
    if(ans) cout << "Alice" << '\n';
    else cout << "Bob" << '\n';
    return 0;
}