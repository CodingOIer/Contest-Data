#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int T,res;
const int N=1e5+5;
int pre[N],cnt;
void xxs(int n){
    for(int i=2;i<=n;i++){
        bool ch=1;
        for(int j=1;j<=cnt&&pre[j]*pre[j]<=i;j++){
            if(i%pre[j]==0){
                ch=0;
                break;
            }
        }
        if(ch) pre[++cnt]=i;
    }
}
map<int,int> t;
int k[8];
void solve(int n,int v){
    for(int i=0;i<8;i++) k[i]+=n/8*v;
    for(int i=n/8*8+1;i<=n;i++) k[i%8]+=v;
}
#define pow Pow
int pow(int x,int base,int mod){
    int ans=1;
    while(base){
        if(base&1) ans=1ll*ans*x%mod;
        x=1ll*x*x%mod;
        base>>=1;
    }
    return ans;
}
int main(){
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    read();
    T=read();
    xxs(1.5e4);
    while(T--){
        int l=read(),r=read();
        if(l==r&&(int)sqrt(l)*(int)sqrt(l)==l){
            cout<<"1\n";
            continue;
        }
        if(r-l<=6){
            int res=0;
            t.clear();
            for(int i=l;i<=r;i++){
                int x=i;
                for(int j=1;j<=cnt&&pre[j]*pre[j]<=i;j++){
                    while(x%pre[j]==0){
                        if(pre[j]%4==3){
                            t[j]++;
                            if(t[j]&1) res++;
                            else res--;
                        }
                        x/=pre[j];
                    }
                }
                if(x%4==3){
                    t[x]++;
                    if(t[x]&1) res++;
                    else res--;
                }
            }
            if(!res){
                cout<<"2\n";
                continue;
            }
        }
        memset(k,0,sizeof(k));
        solve(r,1),solve(l-1,-1);
        int res=pow(1,k[1],8)*pow(3,k[3],8)*pow(5,k[5],8)*pow(7,k[7],8)%8;
        if(k[2]&1) res=res*2%8;
        if(res!=7){
            cout<<"3\n";
            continue;
        }
        cout<<"4\n";
    }
    return 0;
}