#include <bits/stdc++.h>
using namespace std;
#define int __int128
#define i1 __int128
#define ii (i1)1
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline i1 read(){
    i1 x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
void print(i1 x){
    if(x>9) print(x/10);
    *O++=x%10+'0';
    //*O++=10;//换行
    //fwrite(obuf,O-obuf,1,stdout);//输出
}
int n,m,k,t[125];
i1 a[125],b[125],ans;
#define maxx(a,b) (a>b?a:b)
void dfs(vector<int> g,int now){
    if(g.size()==k){
        memcpy(a,b,sizeof(b));
        for(auto i:g){
            vector<int> v,kk;
            memset(t,0,sizeof(t));
            for(int j=1;j<=n;j++){
                if(!(a[j]&(ii<<i))){
                    v.push_back(j);
                    for(int k=0;k<m;k++)
                        if(a[j]&(ii<<k)) t[k]++;
                }
            }
            for(int j=0;j<m;j++)
                if(t[j]<=v.size()/2) kk.push_back(j);
            for(auto j:v)
                for(auto k:kk) a[j]^=ii<<k;
        }
        int res=0;
        for(int i=1;i<=n;i++){
            res+=a[i];
        }
        ans=maxx(ans,res);
        return;
    }
    for(int i=now;i<m;i++){
        g.push_back(i);
        dfs(g,i+1);
        g.pop_back();
    }
}
signed main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++) a[i]=read();
    memcpy(b,a,sizeof(a));
    vector<int> g;
    dfs(g,0);
    print(ans);
    fwrite(obuf,O-obuf,1,stdout);//输出
    return 0;
}