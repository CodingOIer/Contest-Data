#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
#define int long long
const int mod=1e9+7;
int n,m;
signed main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    n=read(),m=read();
    if(m==2){
        cout<<n<<"\n"<<1<<"\n";
        return 0;
    }
    if(m==3){
        cout<<(n+1)*n/2%mod<<"\n"<<n/2+1<<"\n"<<(n-1)/2+1<<"\n";
        return 0;
    }
    if(m==4){
        cout<<(int)((__int128)n*((n-1)*(n-1)+8*(n-1)+6)/6)%mod<<"\n"<<n/2+1<<"\n"<<n<<"\n"<<(n-1)/2+1<<"\n";
        return 0;
    }
    return 0;
}
