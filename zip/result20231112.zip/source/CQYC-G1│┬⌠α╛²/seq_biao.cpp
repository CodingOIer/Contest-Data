#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int mod=1e9+7;
int n,m,dp[100005][40][40];
int main(){
    n=read(),m=read();
    dp[0][1][0]=1;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            for(int ii=0;ii<m;ii++){
                for(int k=ii;k<m;k++){
                    dp[i+1][j*k%m][k]=(dp[i+1][j*k%m][k]+dp[i][j][ii])%mod;
                }
            }
        }
    }
        for(int i=0;i<m;i++){
            int ans=0;
            for(int j=0;j<m;j++) ans=(ans+dp[n][i][j])%mod;
            cout<<ans<<" ";
        }
    return 0;
}