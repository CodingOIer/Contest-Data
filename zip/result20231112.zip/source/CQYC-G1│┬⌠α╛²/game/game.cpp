#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,a[N],sum[N],b[N],m;
map<int,int> t;
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    sort(a+1,a+n+1,[](int a,int b){return a>b;});
    memcpy(b,a,sizeof(a));
    m=unique(b+1,b+n+1)-b-1;
    sort(b+1,b+m+1);
    for(int i=1;i<=m;i++) t[b[i]]=i;
    for(int i=1;i<=n;i++) a[i]=t[a[i]];
    for(int i=1;i<=n;i++) sum[a[i]]++;
    for(int i=m;i;i--) sum[i]+=sum[i+1];
    for(int i=m;i;i--) 
        if(sum[i]&1){
            cout<<"Alice";
            return 0;
        }
    cout<<"Bob";
    return 0;
}