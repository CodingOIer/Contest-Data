#include<bits/stdc++.h>
using namespace std;
const int P=1e9+7;
int main()
{
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(m==2) 
		printf("%d\n1\n",n);
	else
		printf("%lld\n%d\n%d\n",1ll*(n+1)*n/2%P,n/2+1,(n-1)/2+1);
	return 0;
}
