#include<bits/stdc++.h>
using namespace std;
const int NN=1e4+4;
int prime[NN],t[NN],num[8];
bool vis[NN];
void calc(int n,int v)
{
    for(int i=0;i<8;i++)
		num[i]+=n/8*v;
    for(int i=n/8*8+1;i<=n;i++)
		num[i%8]+=v;
}
int qmi(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1)
			res=1ll*res*a%8;
		a=1ll*a*a%8;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int cnt=0;
    for(int i=2;i<NN;i++)
		if(!vis[i])
		{
			prime[++cnt]=i;
			for(long long j=1ll*i*i;j<NN;j+=i)
				vis[j]=false;
		}
    int T;
	scanf("%d",&T);
    while(T--)
	{
    	int l,r;
    	scanf("%d%d",&l,&r);
        if(l==r)
		{
			int L=0,R=l;
			while(L<R)
			{
				int mid=L+(R-L+1)/2;
				if(1ll*mid*mid<=l)
					L=mid;
				else
					R=mid-1;
			}
			if(1ll*L*L==l)
			{
				puts("1");
            	continue;
			}
        }
        if(r-l<10)
		{
            int res=0;
            memset(t,0,sizeof(t));
            for(int i=l;i<=r;i++)
			{
                int x=i;
                for(int j=1;j<=cnt&&1ll*prime[j]*prime[j]<=i;j++)
				{
                    while(x%prime[j]==0)
					{
                        if(prime[j]%4==3)
						{
                            t[j]++;
                            if(t[j]&1)
								res++;
                            else
								res--;
                        }
                        x/=prime[j];
                    }
                }
                if(x%4==3)
					res++;
            }
            if(!res)
			{
				puts("2"); 
                continue;
            }
        }
        memset(num,0,sizeof(num));
        calc(r,1),calc(l-1,-1);
        int res=1ll*qmi(1,num[1])*qmi(3,num[3])%8*qmi(5,num[5])%8*qmi(7,num[7])%8;
        if(num[2]&1)
			res=2ll*res%8;
        if(res!=7)
		{
        	puts("3");
            continue;
        }
        puts("4");
    }
    return 0;
}
