#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4;
int a[NN];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	set<int>st;
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		if(!st.count(x))
			st.insert(x);
		else
			st.erase(x);
	}
	if(st.size())
		printf("Alice");
	else
		printf("Bob");
	return 0;
}
