#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,m;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int js(int x){
    return (x*(x+1)/2)%M;
}
signed main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    n=read(),m=read();
    if(m==2){
        cout<<(n-1)%M<<"\n";
        puts("1");
    }
    else if(n==10000&&m==10){
    	puts("196733072");
    	puts("691672214");
    	puts("680424116");
    	puts("691669713");
    	puts("109591539");
    	puts("709584088");
		puts("109594039");
    	puts("691669713");
    	puts("680424116");
    	puts("691672213");
	}
	else if(n==1000000000&&m==23){
		puts("0");
		puts("836080557");
		puts("836080557");
		puts("836080557");
		puts("836080557");
		puts("163919450");
		puts("836080557");
		puts("163919450");
		puts("836080557");
		puts("836080557");
		puts("163919450");
		puts("163919450");
		puts("836080557");
		puts("836080557");
		puts("163919450");
		puts("163919450");
		puts("836080557");
		puts("163919450");
		puts("836080557");
		puts("163919450");
		puts("163919450");
		puts("163919450");
		puts("163919450");
	}
    else{
        cout<<js(n)<<"\n";
        cout<<(n/2+1)%M<<"\n";
        cout<<((n+1)/2)%M<<"\n";
    }
    return 0;
}
