#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[100005],b[100005],c[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i]=b[i]=read();
    sort(a+1,a+1+n);
    m=unique(a+1,a+1+n)-(a+1);
    for(int i=1;i<=n;i++){
        int d=lower_bound(a+1,a+1+m,b[i])-a;
        c[d]++;
    }
    for(int i=m;i>=1;i--){
        if(c[i]&1){
            cout<<"Alice";
            return 0;
        }
    }
    cout<<"Bob";
    return 0;
}