#include<bits/stdc++.h>
#define int long long
using namespace std;
int tid,T,l,r;
mt19937 rd(time(0));
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    tid=read();
    T=read();
    while(T--){
        l=read(),r=read();
        if(l==1&&r==3) puts("3");
		else if(l==4&&r==4) puts("1");
		else if(l==4&&r==5) puts("2");
		else if(l==3&&r==5) puts("4");
        else if(tid==1){
            int d=sqrtl(l);
            if(l==r&&(d*d)==l) puts("1");
            else puts("2");
        }
        else if(tid==2){
            int d=rd()&1;
            if(d) puts("3");
            else puts("4");
        }
        else if(tid==3){
            int d=rd()&1;
            if(d) puts("2");
            else puts("4");
        }
        else{
            int d=sqrtl(l),D=rd()%3;
            if(l==r&&(d*d)==l) puts("1");
            else if(D==0) puts("2");
            else if(D==1) puts("3");
            else puts("4");
        }
    }
    return 0;
}
