#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,K,a[1005],b[1005],c[1005],ans=0;
bool v[1005]; 
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void js(int x){
    int w=(int)1<<x;
    for(int i=1;i<=n;i++){
    	if((a[i]&((int)1<<x))==0) v[i]=1;
    	else v[i]=0;
	}
    for(int i=0;i<m;i++){
    	if(i==x) continue; 
        int d1=0,d2=0;
        for(int j=1;j<=n;j++){
            if(v[j]){
                if(a[j]&((int)1<<i)) d1++;
                else d2++;
            }
        }
        if(d2>=d1) w+=((int)1<<i);
    }
    for(int i=1;i<=n;i++) if(v[i]) a[i]^=w;
}
inline void dfs(int k){
    if(k==(K+1)){
        for(int i=1;i<=n;i++) a[i]=b[i];
        for(int i=1;i<=K;i++){
            js(c[i]);
        }
        int t=0;
        for(int i=1;i<=n;i++) t+=a[i];
        ans=max(ans,t);
        return;
    }
    for(int i=0;i<m;i++){
        c[k]=i;
        dfs(k+1);
    }
}
signed main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    n=read(),m=read(),K=read();
    for(int i=1;i<=n;i++) a[i]=b[i]=read();
    dfs(1);
    cout<<ans;
    return 0;
}
