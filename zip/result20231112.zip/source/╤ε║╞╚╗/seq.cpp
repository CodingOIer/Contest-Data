#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
long long n,m,ans0,ans1,ans2;
int main()
{
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(m==2) printf("%lld\n1",n);
	else 
	{
		ans0=n*(n+1)>>1ll;
		ans1=(n>>1ll)+1;
		ans2=n+1-ans1;
		ans0%=mod,ans1%=mod,ans2%=mod;
		printf("%lld\n%lld\n%lld",ans0,ans1,ans2);
	}
	return 0;
}

