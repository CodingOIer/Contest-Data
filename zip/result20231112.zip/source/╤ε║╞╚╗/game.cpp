#include<bits/stdc++.h>
using namespace std;
int n,ans,now;
int a[100005];
inline int read()
{
	int x(0);char ch(getchar());
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=a[i-1]) {ans|=now;now=1;}
		else now^=1;
	}
	ans|=now;
	ans?puts("Alice"):puts("Bob");
	return 0;
}

