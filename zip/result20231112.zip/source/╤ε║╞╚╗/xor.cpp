#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int cnt[2][2],d[125][125];
long long a[125],num[2],ans,now;
inline long long read()
{
	long long x(0);char ch(getchar());
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	{
		now=a[i]=read();ans+=a[i];
		for(int j=0;j<m;j++)
		{
			d[i][j]=now&1;
			now>>=1;
		}
	}
	for(int i=0;i<m;i++)
	{
		cnt[0][0]=cnt[0][1]=cnt[1][0]=cnt[1][1]=0;
		for(int j=1;j<=n;j++) cnt[d[j][m-1]][d[j][i]]++;
		if(cnt[0][0]>cnt[0][1]) num[0]+=1ll*(cnt[0][0]-cnt[0][1])*(1ll<<i);
		if(cnt[1][0]>cnt[1][1]) num[1]+=1ll*(cnt[1][0]-cnt[1][1])*(1ll<<i);
	}
	ans+=max(num[0],num[1]);
	printf("%lld",ans);
	return 0;
}

