#include<bits/stdc++.h>
using namespace std;
int typ,t,l,r,sq;
long long ans,sum4,sum2;
int main()
{
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	scanf("%d%d",&typ,&t);
	if(typ<=1)
	{
		while(t--)
		{
			scanf("%d%d",&l,&r);
			if(l==r)
			{
				sq=sqrt(l);
				if(sq*sq==l) ans=1;
				else ans=2;
			} 
			else ans=2;
			printf("%lld\n",ans);
		}
	}
	else 
	{
		while(t--)
		{
			scanf("%d%d",&l,&r);sum4=sum2=1;
			for(long long i=l;i<=r;i++)
			{
				sum4*=i,sum2*=i;
				while(sum4%4==0) sum4/=4;sum4%=8;
				while(sum2%2==0) sum2/=2;sum2%=4;
			}
			if(l==r)
			{
				sq=sqrt(l);
				if(sq*sq==l) ans=1;
				else 
				{
					if(sum2%4==1) ans=2;
					else if(sum4%8==7) ans=4;
					else ans=3;
				}
			} 
			else 
			{
				if(sum2%4==1) ans=2;
				else if(sum4%8==7) ans=4;
				else ans=3;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}

