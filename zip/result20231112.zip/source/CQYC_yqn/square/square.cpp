#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
    return x*f;
}
int T,res,cnt;
const int MAXN=1e4+5;
int pre[MAXN],t[MAXN];
void solve(int n)
{
    for(int i=2;i<=n;i++)
    {
        bool ch=1;
        for(int j=1;j<=cnt&&pre[j]*pre[j]<=i;j++)
        {
            if(i%pre[j]==0)
            {
                ch=0;
                break;
            }
        }
        if(ch) 
            pre[++cnt]=i;
    }
}
namespace sub4
{
    void add(int x)
    {
        int y=x;
        for(int i=1;i<=cnt&&pre[i]*pre[i]<=y;i++)
        {
            while(x%pre[i]==0)
            {
                if(++t[i]%2) 
                    res++;
                else 
                    res--;
                x/=pre[i];
            }
        }
        if(x>1) 
            res++;
    }
    int mian(int l,int r)
    {
        res=0;
        memset(t,0,sizeof(t));
        for(int i=l;i<=r;i++) 
            add(i);
        if(res==0)
        {
            puts("1");
            return 0;
        }
        res=0;
        memset(t,0,sizeof(t));
        for(int i=l;i<=r;i++)
        {
            int x=i;
            for(int j=1;j<=cnt&&pre[j]*pre[j]<=i;j++)
            {
                if(pre[j]%4==3)
                {
                    while(x%pre[j]==0)
                    {
                        if(++t[j]%2) 
                            res++;
                        else 
                            res--;
                        x/=pre[j];
                    }
                }
            }
            if(x%4==3) 
                res++;
        }
        if(res==0)
        {
            puts("2");
            return 0;
        }
        int cnt1=0,cnt2=1;
        for(int i=l;i<=r;i++)
        {
            int x=i;
            while(x&1^1)
            {
                cnt1^=1;
                x>>=1;
            }
            cnt2=cnt2*x%8;
        }
        if((cnt1?2:1)*cnt2%8!=7)
            puts("3");
        else
            puts("4");
        return 0;
    }
}
// void solve2(int a,int b)
// {
//     int sum=1;
//     for(int i=a;i<=b;i++)sum*=i;
//     for(int i=1;i*i<=sum;i++)
//     {
//         if(i*i==sum)
//         {
//             puts("1");
//             return;
//         }
//     }
// }
int main()
{
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    T=read();
    solve(15000);
    while(T--)
    {
        int l=read(),r=read();
        // solve2(l,r);
        if(r-l<=20) 
            sub4::mian(l,r);
    }
    return 0;
}