#include<bits/stdc++.h>
// #define int long long
using namespace std;
// bool ki;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
    return x*f;
}
set<int>st;
// bool ku;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    // cerr<<(&ki-&ku)/1024/1024<<"MB\n";
	int n=read();
	for(int i=1;i<=n;i++)
	{
		int a=read();
		if(!st.count(a))
			st.insert(a);
		else
			st.erase(a);
	}
	if(st.size())
        puts("Alice");
	else
        puts("Bob");
	return 0;
}