#include<bits/stdc++.h>
// #define int long long
using namespace std;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}
    return x*f;
}
signed main()
{
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    int n=read(),m=read();
    printf("%d\n",n);
    puts("1");
    return 0;
}