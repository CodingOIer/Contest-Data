#include<bits/stdc++.h>
using namespace std;
#define int __int128
#define ii (__int128)1
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}

void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int n,m,k;
int t[125];
__int128 a[125],b[125],ans;
#define maxx(a,b) (a>b?a:b)
void dfs(vector<int> g,int now)
{
    if(g.size()==k){
        memcpy(a,b,sizeof(b));
        for(auto i:g)
        {
            vector<int> v,kk;
            memset(t,0,sizeof(t));
            for(int j=1;j<=n;j++)
            {
                if(!(a[j]&(ii<<i)))
                {
                    v.push_back(j);
                    for(int k=0;k<m;k++)
                        if(a[j]&(ii<<k)) t[k]++;
                }
            }
            for(int j=0;j<m;j++)
                if(t[j]<=v.size()/2) 
                    kk.push_back(j);
            for(auto j:v)
                for(auto k:kk) 
                    a[j]^=ii<<k;
        }
        int res=0;
        for(int i=1;i<=n;i++)
            res+=a[i];
        ans=maxx(ans,res);
        return;
    }
    for(int i=now;i<m;i++)
    {
        g.push_back(i);
        dfs(g,i+1);
        g.pop_back();
    }
}
signed main()
{
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    n=read(),m=read(),k=read();
    for(int i=1;i<=n;i++) 
        a[i]=read();
    if(k==1||k==2)
    {
        memcpy(b,a,sizeof(a));
        vector<int> g;
        dfs(g,0);
        write(ans);
    }
    else
    {
        puts("0");
    }
    return 0;
}