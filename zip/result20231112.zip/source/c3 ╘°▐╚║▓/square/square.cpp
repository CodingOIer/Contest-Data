#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,k;
int s[1900005];
bool isp[10000005];
int tot,prime[10000005];
void xxs(){
	isp[2]=0;isp[1]=1;
	for(int i=2;i<=10000000;i++){
		if(!isp[i]){
			prime[++tot]=i;
		}
		for(int j=1;j<=tot&&i*prime[j]<=10000000;j++){
			isp[i*prime[j]]=1;
			if(i%prime[j]==0) break;
		}
	}
}
signed main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	int id=read();
	int T=read();
	xxs();
	while(T--){
		int l=read(),r=read();
		if(id==1){
			if(l!=r){
				cout<<2<<endl;
				continue;
			}
			if(1ll*sqrt(l)*sqrt(l)!=l){
				cout<<2<<endl;
			}
			else cout<<1<<endl;
			continue;
		}
		if(id==4){
			int ss=1;
			for(int i=l;i<=r;i++){
				int gg=i;
				for(int j=2;j<=sqrt(i);j++){
					while(gg%j==0){
						s[j]++;
						gg/=j;
					}
				}
				if(gg>1){
					ss*=gg;
				}
			}
			for(int i=1;i<=sqrt(r)+1;i++){
				if(s[i]%2==1){
					ss*=i;
				}
			}
			int p=0;
			while(ss){
				p++;
				ss-=(int)sqrt(ss)*(int)sqrt(ss);
			}
			printf("%lld\n",p);
			continue;
		}
		int ss=1;
		for(int i=1;i<=tot;i++){
			int s=0;
			for(int j=prime[i];j<=r;j*=prime[i]){
				s+=(r/j-(l-1)/j);
			}
			if(prime[i]>r) break;
			if(s%2==1){
				ss*=prime[i];
			}
		}
		int p=0;
		while(ss){
			p++;
			ss-=(int)sqrt(ss)*(int)sqrt(ss);
		}
		printf("%lld\n",p);
		
		
	}
	return 0;
}
