#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
const int Mod=1e9+7;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,k;
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	n=read();k=read();
	if(k==2){
		cout<<n<<endl;
		cout<<1;
		return 0;
	}
	if(k==3){
		cout<<(n*(n+1)/2)%Mod<<endl;
		cout<<(n+2)/2<<endl;
		cout<<(n+1)/2<<endl;
		return 0;
	}
	return 0;
}
