#include<bits/stdc++.h>
#define int __int128
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
void write(int x){
	if(x<10){
		putchar(x%10+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
}
//--------------------------------------------------------------------
int n,m,k;
int a[1005][1005],tot;
bool vis[100005];
int ans;
signed main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	n=read();m=read(),k=read();
	for(int i=1;i<=n;i++){
		int gg=read();
		tot=0;
		ans+=gg;
		while(gg){
			if(gg&1) a[i][tot]=1;
			tot++;
			gg>>=1;
		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<a[i][j]<<" ";
//		}
//		cout<<endl;
//	}
//	cout<<endl;
	for(int t=1;t<=k;t++){
		int mx=0,p=0;
		for(int k=m-1;k>=0;k--){
			int sum=0;
			for(int i=1;i<=n;i++){
				vis[i]=0;
				if(!a[i][k]) vis[i]=1,sum+=(1ull<<k);
			}
//		cout<<ans<<endl;
			for(int i=k-1;i>=0;i--){
				int res=0;
				for(int j=1;j<=n;j++)
					if(vis[j]){
						if(a[j][i]==0)res++;
						else res--;
					}
				if(res>0){
					sum+=1ull*res*(1ull<<i);
				}
//			cout<<sum<<" "<<i<<endl;
			}
			if(sum>mx){
				mx=sum;
				p=k;
			}
		}
		for(int i=1;i<=n;i++){
			vis[i]=0;
			if(!a[i][p]) vis[i]=1,ans+=1ull*(1ll<<p);
			a[i][p]=1;
		}
//		cout<<ans<<endl;
		for(int i=p-1;i>=0;i--){
			int sum=0;
			for(int j=1;j<=n;j++)
				if(vis[j]){
					if(a[j][i]==0)sum++;
					else sum--;
				}
			if(sum>0){
				for(int j=1;j<=n;j++){
					if(vis[j]){
						a[j][i]=1-a[j][i];
					}
				}
				ans+=1ull*sum*(1ll<<i);
			}
//			cout<<sum<<" "<<i<<endl;
		}
//		for(int i=0;i<=n;i++){
//			for(int j=0;j<=n;j++){
//				cout<<a[i][j]<<" ";
//			}
//			cout<<endl;
//		}
//		cout<<endl;
	}
	write(ans);
	return 0;
}
