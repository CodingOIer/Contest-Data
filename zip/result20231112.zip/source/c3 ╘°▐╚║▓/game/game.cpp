#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define re register
#define mp make_pair
#define pb push_back
#define lowbit(x) x&(-x)
#define FOR(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define ROF(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
using namespace std;
inline int read(){
	int p=0, q=1;
	char ch=getchar();
	while (!isdigit(ch)) q=(ch=='-')?-1:1,ch=getchar();
	while (isdigit(ch)) p=(p<<3)+(p<<1)+(ch^48),ch=getchar();
	return p*q;
}
//--------------------------------------------------------------------
int n,k;
int a[100005];
int gg[100005],tot,id[100005];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++){
		if(a[i]!=a[i-1]){
			id[++tot]=a[i];
			gg[tot]=1;
		}
		else {
			gg[tot]++;
		}
	}
//	for(int i=1;i<=tot;i++){
//		cout<<id[i]<<" "<<gg[i]<<endl;
//	}
	for(int i=tot;i>=1;i--){
		if(gg[tot]%2==0) continue;
		else{
			cout<<"Alice"<<endl;
			return 0;
		}
	}
	cout<<"Bob"<<endl;
	return 0;
}
