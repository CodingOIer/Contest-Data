#include<bits/stdc++.h>
#define int long long
#define i128 __int128
#define il inline
#define ct const
#define dl long double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 130
#define eps 1e-8
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
il i128 read128(){
	i128 x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(i128 x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il i128 max(i128 u,i128 v){
    return u<v?v:u;
}
int n,m,K;
i128 b[N],ans,c[10],d[N];
mt19937 rnd(time(0));
il i128 solve(){
    for(int i=1;i<=n;++i) d[i]=0;
    for(int i=0;i<(1<<K);++i){
        i128 tmp=0;
        for(int j=0;j<K;++j) if((1<<j)&i) tmp=tmp^c[j];
        for(int j=1;j<=n;++j) d[j]=max(d[j],tmp^b[j]);
    }
    i128 res=0;
    for(int i=1;i<=n;++i) res+=d[i];
    return res;
}
il void SA(){
    #define down 0.996
    dl t=3000;
    while(t>eps){
        int u=rnd()%K,v=rnd()%m;
        c[u]=c[u]^((i128)1<<v);
        i128 nowans=solve();
        if(exp((dl)(nowans-ans)/t)*RAND_MAX<rand()) c[u]=c[u]^((i128)1<<v);
        ans=max(ans,nowans);
        t*=down;
    }
}
il void solve2(){
    for(int i=0;i<K;++i) for(int j=0;j<m;++j) c[i]+=(i128)1<<(rnd()%2);
    ans=max(ans,solve());
    while((dl)clock()/CLOCKS_PER_SEC<0.8) SA();
    write(ans);
}
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
    n=read();m=read();K=read();
    for(int i=1;i<=n;++i){
        b[i]=read128();
    }
    solve2();
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}