#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 2000010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,a[N],ans,b[N],zhi[N],t,flag;
bool vis[N];
// int f[N];
il void dfs(int dep,int x,int y){
    // if(flag) cerr<<dep<<" "<<x<<" "<<y<<"\n";
    if(ans<=dep) return;
    // if(x<=1e6&&f[x]&&f[x]+dep<=ans) return;
    if(!x){
        ans=dep;
        for(int i=0;i<dep;++i) b[i]=a[i];
        return;
    }
    for(int i=y;i;--i) if(i*i<=x){
        a[dep]=i;dfs(dep+1,x-i*i,i);
    }
}
il void solve(int l,int r,int now){
    ans=inf;
    dfs(0,now,(int)sqrtl(now));
    write(ans);putchar('\n');
    // if(ans>4) cerr<<"ERROR";
    if(ans==2){
        for(int i=0;i<ans;++i){
            write(b[i]);putchar(' ');
        }
        putchar('\n');
    }
        putchar('\n');
}
il void init(){
    for(int i=2;i<=2e6;++i){
        if(!vis[i]){
            zhi[++t]=i;
            for(int j=2;j*i<=2e6;++j) vis[j*i]=1;
        }
    }
}
il void solve2(int l,int r){
    // cerr<<l<<" "<<r<<"\n";
    int now=1;
    // cerr<<"ERROR";
    for(int i=l;i<=r;++i){
        int x=i;
        for(int j=1;j<=t&&zhi[j]<=x;++j){
            while(!(x%zhi[j])){
                vis[j]^=1;x/=zhi[j];
            }
        }
    }
    for(int i=1;i<=t&&zhi[i]<=r;++i)
        if(vis[i]){
            now*=zhi[i];vis[i]=0;
        }
    // if(l==11&&r==19) flag=1;
    // cerr<<now<<" "<<l<<" "<<r<<"\n";
    // cout<<now<<" "<<l<<" "<<r<<"\n";
    solve(l,r,now);
    // cout<<"\n";
    // for(int i=0,x=now;i<ans;++i){
    //     if((b[i]+1)*(b[i]+1)<=x) cerr<<l<<" "<<r<<"\n";
    //     x-=b[i]*b[i];
    // }
}
il void solve1(int l,int r){
    if(l==r&&(int)sqrt(l)*(int)sqrt(l)==l) puts("1");
    else puts("2");
}
int tid;
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
    // for(int l=1;l<=20;++l){
    //     for(int r=l;r<=20;++r){
    //         int res=1;
    //         for(int i=l;i<=r;++i) res=res*i;
    //         if((int)sqrtl(res)*(int)sqrtl(res)==res) cout<<l<<" "<<r<<"\n";
    //     }
    // }
    init();
    for(int i=2;i<=1e6;++i) vis[i]=0;
    tid=read();T=read();
    while(T--){
        int l=read(),r=read();
        if(tid==1) solve1(l,r);
        else solve2(l,r);
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}