#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl long double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define M 45
#define inf (int)(1000000000000000000)
#define mod 1000000007
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
	a=a+b>=mod?a+b-mod:a+b;
}
il int calc(int l,int r){
	return (l+r)*(r-l+1)/2%mod;
}
il int Pow(int a,int b){
	int res=1;
	while(b){
		if(b&1) res=res*a%mod;
		a=a*a%mod;b>>=1;
	}
	return res;
}
il int C(int a,int b){
	if(a<0||b<0||a<b) return 0;
	int res=1;
	for(int i=1;i<=b;++i) res=(a-i+1)%mod*Pow(i,mod-2)%mod*res%mod;
	return res;
}
int n,m,f[2][M][M*M],l;
il void solve1(){
    write(n);putchar('\n');write(1);
}
il void solve2(){
	write(calc(1,n));putchar('\n');write((n+1)/2);putchar('\n');write(n+1-(n+1)/2);
}
il void solve3(){
	memset(f,0,sizeof f);
	f[0][1][0]=1;l=0;
	for(int i=1;i<m;++i,l^=1){
		for(int j=1;j<m;++j){
			for(int k=0;k<=(i-1)*(m-2);++k) if(f[l][j][k]){
				// cerr<<i-1<<" "<<j<<" "<<k<<" "<<f[l][j][k]<<"\n";
				for(int h=0,now=1;h<m-1&&k+h<=n;++h,now=now*i%m){
					Add(f[l^1][j*now%m][k+h],f[l][j][k]);
				}
			}
		}
		memset(f[l],0,sizeof(f[l]));
	}
	// cerr<<C(n+m-1,m-1)<<" "<<C(n+m-2,m-2)<<"\n";
	write((C(n+m-1,m-1)-C(n+m-2,m-2)+mod)%mod);putchar('\n');
	// cerr<<f[l][2][3]<<"\n";
	for(int i=1;i<m;++i){
		int ans=0;
		for(int j=0;j<=(m-1)*(m-2);++j) if(!((n-j)%(m-1))){
			Add(ans,f[l][i][j]*C((n-j)/(m-1)+m-2,m-2)%mod);
			// cerr<<i<<" "<<j<<" "<<f[l][i][j]<<" "<<C((n-j)/(m-1)+m-2,m-2)<<"\n";
		}
		write(ans);putchar('\n');
	}
}
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
    n=read();m=read();
	solve3();
    // if(m==2) solve1();
	// else if(m==3) solve2();
	// else solve3();
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}