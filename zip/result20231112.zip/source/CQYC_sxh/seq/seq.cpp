#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 1e9 + 7;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 42;

int n, m, lc, ma, ans[N];
pii a[N][N]; int len[N], vis[N];
int f[1500][N][N], g[1500][N][N];

void init() {
    lc = 1; For(i, 1, m) { len[i] = 0;
        int d = 1, flag = 0, cnt = 0;
        For(j, 0, m) vis[j] = -1;
        a[i][0] = pii(1, 0), vis[1] = 0;

        For(j, 1, m) { d = d * i % m; 
            if (vis[d] != -1) {
                For(k, vis[d], len[i]) a[i][k].second = 1;
                lc = lc * (j - vis[d]) / gcd(lc, j - vis[d]); break;
            } 
            a[i][++len[i]] = pii(d, 0), vis[d] = j;
        }
    }
    For(i, 1, m) {
        int cnt = 0; For(j, 0, len[i]) cnt += a[i][j].second;
        while (cnt < lc) {
            ++len[i], ++cnt;
            a[i][len[i]] = {a[i][len[i] - 1].first * i % m, 1};
        }
    }
}
int iv[N];
int calc(int n, int m) {
    if (n < 0 || m < 0) return 0;
    if (m == 0) return n == 0;
    --m, n += m; int ans = 1; For(i, 1, m) 
    ans = ans * (n - i + 1ll) % mod * iv[i] % mod;
    return ans;
}
signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
    For(i, 0, 40) iv[i] = inv(i);
    n = read(), m = read(), init(), f[0][0][1] = 1;
    For(i, 1, m) { int cma = ma;
        For(j, 0, ma) For(k, 0, i - 1) For(l, 0, m - 1) 
            g[j][k][l] = f[j][k][l], f[j][k][l] = 0;
        For(j, 0, ma) For(k, 0, i - 1) For(l, 1, m - 1) 
        if (g[j][k][l]) For(t, 0, len[i]) {
            if (a[i][t].first == 0) break; ; cma = max(cma, j + t);
            add(f[j + t][k + a[i][t].second][l * a[i][t].first % m], g[j][k][l]);
        } 
        ma = min(cma, n);
    }
    For(i, 0, ma) if ((n - i) % lc == 0) For(j, 0, m) For(k, 1, m - 1) if (f[i][j][k]) {
        add(ans[k], 1ll * f[i][j][k] * calc((n - i) / lc, j) % mod);
    }
    ans[0] = calc(n, m);For(i, 1, m - 1) add(ans[0], mod - ans[i]);
    For(i, 0, m - 1) cout << ans[i] <<"\n";
	return 0;
}
