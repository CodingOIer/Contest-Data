#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,m;
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	n=read(),m=read();
	if(m==2){
		printf("%lld\n1\n",n);
		return 0;
	}
	if(m==3){
		printf("%lld\n%lld\n%lld\n",(n*(n+1)/2)%mod,n/2+1,(n+1)/2);
		return 0;
	}
	return 0;
}
