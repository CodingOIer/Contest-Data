#include<bits/stdc++.h>
#define int __int128
#define ll long long
using namespace std;
const int N=125;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-48;ch=getchar();}
	return x*f;
}
inline void write(int x){
	if(x>9) write(x/10);
	putchar(x-(x/10*10)+'0');
}
int n,m,k,ans,maxn;
int a[N];
signed main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	n=read(),m=read(),k=read();
	for(ll i=1;i<=n;i++) a[i]=read();
	while(k--){
		sort(a+1,a+1+n);
		maxn=0;
		for(ll i=1;i<=n;i++){
			int res=0;
			for(ll j=0;j<m;j++){
				int cnt0=0,cnt1=0;
				for(int l=1;l<=i;l++){
					if(a[l]&(1<<j)) cnt1++;
					else cnt0++;
				}
				if(cnt0>cnt1) res=res+(cnt0-cnt1)*(1<<j);
			}
			maxn=max(maxn,res);
		}		
		for(ll i=1;i<=n;i++){
			int res=0;
			for(ll j=0;j<m;j++){
				int cnt0=0,cnt1=0;
				for(int l=1;l<=i;l++){
					if(a[l]&(1<<j)) cnt1++;
					else cnt0++;
				}
				if(cnt0>cnt1) res=res+(cnt0-cnt1)*(1<<j);
			}
			if(res==maxn){
				for(ll j=0;j<m;j++){
					int cnt0=0,cnt1=0;
					for(int l=1;l<=i;l++){
						if(a[l]&(1<<j)) cnt1++;
						else cnt0++;
					}
					if(cnt0>cnt1){
						for(ll l=1;l<=i;l++){
							if(a[l]&(1<<j)) a[l]-=(1<<j);
							else a[l]+=(1<<j);
						}						
					}
				}			
				break;
			}
		}
	}
	for(ll i=1;i<=n;i++) ans=ans+a[i];
	write(ans);
	return 0;
}
