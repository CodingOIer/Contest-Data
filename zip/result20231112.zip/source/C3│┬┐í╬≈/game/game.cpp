#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') {x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,x,a[N];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	sort(a+1,a+1+n);
	for(int i=1;i<=n+1;i++){
		if(a[i]!=a[i-1]){
			if(x&1){
				printf("Alice");
				return 0;
			}
			else x=1;
		}
		else x^=1;
	}
	printf("Bob");
	return 0;
}
