#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e5+7;

int n,a[Maxn],ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	
	for(int i=1;i<=n;i++){
		if(a[i]==2) ans^=2;
		else ans^=1;
	}
	
	if(ans) printf("Alice");
	else printf("Bob");
	
	return 0;
}



