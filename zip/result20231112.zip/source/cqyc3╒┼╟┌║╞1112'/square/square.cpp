#include <bits/stdc++.h>
#define ll long long
using namespace std;

inline bool ck1(ll x){
	ll sq=sqrt(x);
	if(sq*sq==x)
		return 1;
	for(ll j=1;j*j<x;j++){
		ll y=x-j*j;
		ll l=sqrt(y);
		if(l*l==y){
			return 1;
		}
	}
	return 0;
}

bool check(ll l,ll r){
	if(r-l<=3){
		bool flg=1;
		for(int i=l;i<=r;i++) flg&=ck1(i);
		return flg;
	}
	return check(l+1,r)|check(l,r-1);
}


ll Tid,T;
ll l,r;



int main(){
	freopen("square.in","r",stdin);
	freopen("square.out","w",stdout);
	
	scanf("%lld%lld",&Tid,&T);
	while(T--){
		scanf("%lld%lld",&l,&r);
		ll sq=sqrt(l);
		if(l==r&&sq*sq==l){
			printf("1\n");
			continue;
		}
		else if(r-l<=5){
			if(check(l,r)) printf("2\n");
			else{
				if(l==r||(l==3&&r==5)) printf("4\n");
				else printf("3\n"); 
			}
		}
		else{
			printf("4\n");
		}
	}
	/*
	for(ll i=1;i<=10000;i++){
		ll x=i;
		ll pp=sqrt(i);
		if(pp*pp==i) continue;
		bool flg=1;
		for(ll j=1;j*j<x;j++){
			ll y=x-j*j;
			ll l=sqrt(y);
			if(l*l==y){
				flg=0;
				break;
			}
		}
		if(!flg) cout<<i<<"\n";
	}
	
	
	for(ll i=1;i<=1000;i++){
		for(ll j=i;j<=i+10;j++){
			ll l=1;
			for(ll k=i;k<=j;k++){
				l*=k;
				if(l>=1e9) break;
			}
			if(l>=1e9) continue;
			//cout<<i<<" "<<j<<" "<<l<<endl;
			ll x=l;
			ll pp=sqrt(l);
			if(pp*pp==l){
				gp[i]=1;
				continue;
			}
			ll flg=0;
			for(ll jp=1;jp*jp<x;jp++){
				ll y=x-jp*jp;
				ll lp=sqrt(y);
				if(lp*lp==y){
					flg=lp;
					break;
				}
			}
			if(flg&&j-i==0) gp[i]=1;
			if(i%3==0) gp[i]=1;
		//	if(flg&&j-i==1) cout<<i<<" "<<j<<" "<<l<<" "<<gp[i]<<" "<<gp[j]<<"\n";
		}
	}
 
	for(ll i=1;i<=1000;i++){
		for(ll j=i;j<=i+10;j++){
			ll l=1;
			for(ll k=i;k<=j;k++){
				l*=k;
				if(l>=1e14) break;
			}
			if(l>=1e14) continue;
			//cout<<i<<" "<<j<<" "<<l<<endl;
			ll x=l;
			ll pp=sqrt(l);
			if(pp*pp==l) continue;
			ll flg=0;
			for(ll jp=1;jp*jp<x;jp++){
				ll y=x-jp*jp;
				ll lp=sqrt(y);
				if(lp*lp==y){
					flg=lp;
					break;
				}
			}
		//	if(flg&&j-i==0) gp[i]=1;
			if(flg&&j-i<=6&&j-i>=6) cout<<i<<" "<<j<<" "<<l<<" "<<gp[i]<<" "<<gp[i+1]<<" "<<gp[i+2]<<" "<<gp[i+3]<<" "<<gp[i+4]
			<<" "<<flg<<"\n";
			//int xxx=gp[i]+gp[i+2]+gp[i+3]+gp[i+1]+gp[i+4];
			//if(xxx==5 && j-i==4 && !flg) cout << "fuck "<< i<<" "<<j <<" "<<l<<endl;
			//if(j-i==2 && !flg && (gp[i]&&gp[i+1])) cout<<"fuck "<<i<<" "<<j<<endl;
		}
	}
	
	
	for(ll i=1;i<=1000;i++){
		for(ll j=i;j<=i+15;j++){
			ll l=1;
			for(ll k=i;k<=j;k++){
				l*=k;
				if(l>=1e9) break;
			}
			if(l>=1e9) continue;
			bool flg=0;
			for(ll k=1;k*k<=l;k++){
				if(ck1(l-k*k)){
					flg=1;
					break;
				}
			}
			if(!flg){
				cout<<i<<" "<<j<<endl;
				//cout<<i<<" "<<j<<" "<<(j/3)-((i-1)/3)<<" "<<"\n";
				//for(ll k=i;k<=j;k++) cout<<gp[k]<<" ";
				//cout<<endl;
			}
		}
	}*/
	return 0;
}

/*
1 4
1 3
4 4
4 5
3 5
*/

