#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0), cin.tie(0);
	int n;
	cin >> n;
	map<int, int> freq;
	while (n--) {
		int x;
		cin >> x;
		freq[x]++;
	}
	bool good = 0;
	for (auto p : freq) {
		good |= p.second % 2 == 1;
	}
	cout << (good ? "Alice" : "Bob") << "\n";
	return 0;
}
