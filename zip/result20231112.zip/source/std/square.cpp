#include<bits/stdc++.h>
#define rep(i, n) for(int i = 0; i < n; ++i)
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef array<int, 3> ai3;
const ll inf = 0x3f3f3f3f3f3f3f3fll;
const int Mod = 1e9 + 7;
const int inv2 = (Mod+1) / 2;
inline int sign(int a){ return (a&1) ? (Mod-1) : 1; }
inline void uadd(int &a, int b){ a += b-Mod; a += (a>>31) & Mod; }
inline void usub(int &a, int b){ a -= b, a += (a>>31) & Mod; }
inline void umul(int &a, int b){ a = (int)(1ll * a * b % Mod); }
inline int add(int a, int b){ a += b-Mod; a += (a>>31) & Mod; return a; }
inline int sub(int a, int b){ a -= b, a += (a>>31) & Mod; return a; }
inline int mul(int a, int b){ a = (int)(1ll * a * b % Mod); return a; }
int qpow(int b, int p){ int ret = 1; while(p){ if(p&1) umul(ret, b); umul(b, b), p >>= 1; } return ret; }
const int fN = 111;
int fact[fN], invfact[fN], pw2[fN], invpw2[fN];
void initfact(int n){
	pw2[0] = 1; for(int i = 1; i <= n; ++i) pw2[i] = mul(pw2[i-1], 2);
	invpw2[0] = 1; for(int i = 1; i <= n; ++i) invpw2[i] = mul(invpw2[i-1], (Mod+1) / 2);
	fact[0] = 1; for(int i = 1; i <= n; ++i) fact[i] = mul(fact[i-1], i);
	invfact[n] = qpow(fact[n], Mod-2); for(int i = n; i > 0; --i) invfact[i-1] = mul(invfact[i], i);
}
int binom(int n, int m){ return (m < 0 || m > n) ? 0 : mul(fact[n], mul(invfact[m], invfact[n-m])); }
const double pi = acos(-1);
inline void chmax(int &a, int b){ (b>a) ? (a=b) : 0; }
inline void chmin(int &a, int b){ (b<a) ? (a=b) : 0; }

vi get_fac(int x){
	vi ret;
	for(int i = 2; i*i <= x; ++i) while(x % i == 0) ret.push_back(i), x /= i;
	if(x > 1) ret.push_back(x);
	return ret;
}

inline bool issq(int x){
	int y = (int)sqrtl(x);
	return x == y * y;
}

void solve(){
	int l, r;
	cin >> l >> r;
	if(l == r && issq(l)){
		cout << "1\n";
		return;
	}

	bool ok = 1;
	map<int, int> freq;
	for(int i = r; i >= l && ok; i--){
		vi fac = get_fac(i);
		rep(j, (int)fac.size()) ++freq[fac[j]];
		for(const auto &x : freq){
			int p = x.first, e = x.second;
			if(p >= i && p % 4 == 3 && e % 2){
				ok = 0;
			}
		}
	}
	for(const auto &x : freq){
		int p, e;
		tie(p, e) = x;
		if(p % 4 == 3 && e % 2){
			ok = 0;
		}
	}
	if(ok) return cout << "2\n", void();

	int x = 1;
	for(int i = 1; i <= 7; i += 2){
		auto num = [&](int n){
			int s = 0;
			while(n){
				if(n >= i) s += (n - i) / 8 + 1;
				n /= 2;
			}
			return s;
		};
		if((num(r) - num(l - 1)) % 2){
			x = x * i % 8;
		}
	}

	auto num2 = [&](int n){
		int s = 0;
		while(n /= 2) s += n;
		return s;
	};

	if((num2(r) - num2(l - 1)) % 2 == 0 && x == 7){
		cout << "4\n";
	} else{
		cout << "3\n";
	}
}

int main(){
	freopen("square.in","r",stdin) ;
	freopen("square.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);

	int sub_id,T;
	cin >> sub_id >> T;
	while(T--) solve();

	return 0;
}
