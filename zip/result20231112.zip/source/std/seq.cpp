#include <bits/stdc++.h>
using namespace std;

const int P = 1e9 + 7;

int qp(int x, int y) {
	int z = 1;
	for (; y; y >>= 1, x = 1LL * x * x % P) {
		if (y & 1) z = 1LL * z * x % P;
	}
	return z;
}

void red(int &x) {
	x += x >> 31 & P;
}

int main() {
	freopen("seq.in","r",stdin) ;
	freopen("seq.out","w",stdout);
//	ios::sync_with_stdio(0), cin.tie(0);
	int n, m;
	cin >> n >> m;
	int phi = 0;
	for (int i = 1; i <= m; i++) {
		if (__gcd(i, m) == 1) phi++;
	}
	int cur = 0;
	vector<vector<vector<int>>> f(cur + 1, vector<vector<int>>(m, vector<int>(m + 1)));
	f[0][1][0] = 1;
	for (int x = 0; x < m; x++) {
		vector<int> V;
		int p = 0;
		for (int y = 1; ; y = y * x % m) {
			if (count(V.begin(), V.end(), y)) {
				p = find(V.begin(), V.end(), y) - V.begin();
				while (V.size() < p + phi) V.push_back(y), y = y * x % m;
				break;
			}
			V.push_back(y);
		}
		decltype(f) g(cur + V.size(), vector<vector<int>>(m, vector<int>(m + 1)));
		for (int i = 0; i <= cur; i++) {
			for (int j = 0; j < m; j++) {
				for (int k = 0; k <= x; k++) if (f[i][j][k]) {
					for (int v = 0; v < V.size(); v++) {
						red(g[i + v][j * V[v] % m][k + (v >= p)] += f[i][j][k] - P);
					}
				}
			}
		}
		f = g;
		cur += V.size() - 1;
	}
	auto binom = [&](int x, int y) {
		if (y < 0) return x < 0 ? 1 : 0;
		int ans = 1;
		for (int i = 1; i <= y; i++) ans = 1LL * ans * qp(i, P - 2) % P;
		while (y--) ans = 1LL * ans * x-- % P;
		return ans;
	};
	for (int x = 0; x < m; x++) {
		int ans = 0;
		for (int i = 0; i <= cur; i++) {
			for (int j = 0; j <= m; j++) if (f[i][x][j]) {
				if (n < i || (n - i) % phi) continue;
				ans = (ans + 1LL * f[i][x][j] * binom((n - i) / phi + j - 1, j - 1)) % P;
			}
		}
		cout << ans << "\n";
	}
	return 0;
}
