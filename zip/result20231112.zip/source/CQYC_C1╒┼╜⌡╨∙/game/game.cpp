#include <bits/stdc++.h>
using namespace std;

int n, a[100003];

bool solve(int n) { 
	if (n == 0) {
		return 0;
	}
	int maxntot = 0;
	for (int i = n; i >= 1; --i) {
		maxntot += (a[i] == a[n]);
		if (a[i] != a[n]) break;
	}
	if (maxntot & 1) return 1;
	else return solve(n - maxntot);
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
	}
	sort(a + 1, a + n + 1);
	if (solve(n)) puts("Alice");
	else puts("Bob");
	return 0;
}
