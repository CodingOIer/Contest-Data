#include <bits/stdc++.h>
using namespace std;

int n, m;

int main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if (m == 2) {
		printf("%d\n1\n", n);
		return 0;
	} else if (m == 3) {
		printf("%d\n%d\n%d\n", 1ll * n * (n - 1) / 2 % 1000000007);
		return 0;
	}
}
/* 
*/
