#include <bits/stdc++.h>
using namespace std;

int id, t, l, r;
#define issq(x) (int(sqrt(x)) * int(sqrt(x)) == x)

int main() {
	freopen("square.in", "r", stdin);
	freopen("square.out", "w", stdout);
	scanf("%d%d", &id, &t);
	if (id == 1) {
		while (t--) {
			scanf("%d%d", &l, &r);
			if (l == r && issq(l)) puts("1");
			else puts("2");
		}
	} else if (id == 2) {
		while (t--) {
			scanf("%d%d", &l, &r);
			if (l == r && !issq(l)) puts("4");
			else puts("3");
		}
	} else if (id == 3) {
		while (t--) {
			scanf("%d%d", &l, &r);
			if (l == r && !issq(l)) puts("4");
			else puts("2");
		}
	}
	return 0;
}

