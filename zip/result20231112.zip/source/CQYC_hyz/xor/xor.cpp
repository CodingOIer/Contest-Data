#include <bits/stdc++.h>
#define int __int128
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 130, M = 1 << 6;

int n, m, k, sum, ans;
int a[N];

namespace sub1 {
    int c[N];

    void main() {
        for(int i = 0, v = 1; i < m; i++, v <<= 1) {
            int res = sum;
            for(int j = 0; j < m; j++) c[j] = 0;
            for(int j = 0; j < n; j++) if(!(a[j] & v)) {
                res += v;
                for(int l = 0; l < m; l++)
                    if(l ^ i) (a[j] >> l & 1) ? c[l]-- : c[l]++;
            }
            for(int j = 0, p = 1; j < m; j++, p <<= 1)
                if(c[j] > 0) res += c[j] * p;
            Max(ans, res);
        }
        write(ans);
    }
}

namespace sub2 {
    int f[N], g[M][N], c[N];

    bool vis[N];

    void calc() {
        int res = sum;
        for(int i = 0; i < n; i++) {
            int p = 0;
            for(int j = 1; j <= k; j++) if(!(a[i] >> f[j] & 1)) 
                    p ^= (1 << (j - 1)), res += (int) 1ll << f[j];
            for(int j = 0; j < m; j++) if(!vis[j])
                (a[i] >> j & 1) ? g[p][j]-- : g[p][j]++;
        }
        for(int x = 0, v = 1; x < m; x++, v <<= 1) {
            c[x] = 0;
            for(int i = 0; i < (1 << k); i++) {
                int tot = 0;
                for(int j = 0; j < (1 << k); j++) {
                    int y = __builtin_popcount(i & j);
                    if(y & 1) tot += g[j][x] * v;
                }
                Max(c[x], tot);
            }
            for(int i = 0; i < (1 << k); i++) g[i][x] = 0;
            res += c[x];
        }
        Max(ans, res);
    }

    void dfs(int x, int st) {
        if(x == k + 1) return calc();
        for(int i = st; i + k - x < m; i++) 
            f[x] = i, vis[i] = 1, dfs(x + 1, i + 1), vis[i] = 0;
    }

    void main() {
        dfs(1, 0), write(ans);
    }
}

bool edmer;
signed main() {
	freopen("xor.in", "r", stdin);
	freopen("xor.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), k = read();
    for(int i = 0; i < n; i++) a[i] = read(), sum += a[i];

    ans = sum;

    if(k == 1) sub1 :: main();
    else sub2 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 