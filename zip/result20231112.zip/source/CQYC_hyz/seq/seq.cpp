#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 41, M = N * N;

int n, m;

int C(int x, int y) {
    int res = 1, iv = 1;
    for(int i = 0; i < y; i++) mul(res, x - i), mul(iv, i + 1);
    return res * q_pow(iv, mod - 2) % mod;
}

namespace sub1 {
    int f[M][N];

    bool check() {
        for(int i = 2; i < m; i++) if(!(m % i)) return 0;
        return 1;
    }

    void main() {
        f[0][1] = 1;
        for(int i = 2; i < m; i++) {
            for(int j = min(i * m, n); j + 1; j--) 
                for(int k = 1; k < m; k++) {
                    int val = f[j][k], v = 1; f[j][k] = 0;
                    for(int l = 0; l < m - 1; l++) 
                        inc(f[j + l][k * v % m], val), v = v * i % m;
                }
        }

        write((C(n + m - 1, m - 1) - C(n + m - 2, m - 2) + mod) % mod), putchar('\n');

        for(int i = 1; i < m; i++) {
            int res = 0; 
            for(int j = 0; j <= min(n, m * m); j++) 
                inc(res, C((n - j) / (m - 1) + m - 2, m - 2) * f[j][i] % mod);
            write(res), putchar('\n');
        }
    }
}

bool edmer;
signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();

    // if(sub1 :: check()) 
    sub1 :: main();
    
    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 