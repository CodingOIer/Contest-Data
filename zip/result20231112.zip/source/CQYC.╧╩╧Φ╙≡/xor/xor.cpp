#include<bits/stdc++.h>
using namespace std;
typedef __int128 Int;
inline Int read()
{
    Int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
int stk[125],tp;
inline void write(Int x)
{
    if(!x) return puts("0"),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
    putchar('\n');
}
const int N=125;
int n,m,k;
Int ans,a[N];
int main()
{
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++) ans+=a[i];
    write(ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
