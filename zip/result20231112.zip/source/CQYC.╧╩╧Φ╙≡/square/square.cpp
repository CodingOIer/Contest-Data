#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int id,T,l,r,dp[N];
bool check(int x)
{
    int k=__builtin_sqrt(x);
    return k*k==x;
}
int main()
{
    freopen("square.in","r",stdin);
    freopen("square.out","w",stdout);
    scanf("%d%d",&id,&T);
    while(T--)
    {
        scanf("%d%d",&l,&r);
        if(l==r&&check(l)) puts("1");
        else if(id==1) puts("2");
        else puts("3");
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
