#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,cnt,a[N],b[N],num[N];
int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",a+i),b[i]=a[i];
    sort(b+1,b+n+1);
    cnt=unique(b+1,b+n+1)-b-1;
    for(int i=1;i<=n;i++)
        ++num[lower_bound(b+1,b+cnt+1,a[i])-b];
    for(int i=cnt;i;i--)
        if(num[i]&1) return puts("Alice"),0;
    puts("Bob");
    fclose(stdin);fclose(stdout);
    return 0;
}
