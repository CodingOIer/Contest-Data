#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n,m,inv2,inv6;
int ksm(int x,int y)
{
    int res=1;
    for(;y;y>>=1)
    {
        if(y&1) res=1ll*res*x%mod;
        x=1ll*x*x%mod;
    }
    return res;
}
int S1(int x) {return 1ll*x*(x+1)/2%mod;}
int S2(int x) {return 1ll*x*(x+1)%mod*(2*x+1)%mod*inv6%mod;}
int main()
{
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    inv2=(mod+1)/2;
    inv6=ksm(6,mod-2);
    cin>>n>>m;
    if(m==2)
        printf("%d\n1\n",n);
    if(m==3)
        printf("%d\n%d\n%d\n",S1(n),n/2+1,(n+1)/2);
    if(m==4)
        printf("%d\n%d\n%d\n%d\n",((S2(n-1)+3ll*S1(n-1)%mod+2ll*n%mod)*inv2%mod+S1(n-1))%mod,n/2+1,(n-1)/2+1,(n+1)/2);
    fclose(stdin);fclose(stdout);
    return 0;
}
