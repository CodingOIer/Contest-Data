#include <bits/stdc++.h>
using namespace std;
int n, m;
int main()
{
    freopen("seq.in", "r", stdin);
    freopen("seq.out", "w", stdout);
    scanf("%d%d", &n, &m);
    printf("%d\n", n);
    printf("%d\n", 1);
    return 0;
}