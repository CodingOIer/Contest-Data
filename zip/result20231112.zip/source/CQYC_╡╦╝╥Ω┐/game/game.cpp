#include <bits/stdc++.h>
using namespace std;
int n;
int a[200000];
int main()
{
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    sort(a, a + n);
    for (int i = 0; i < n; i += 2)
        if (a[i] != a[i + 1])
        {
            puts("Alice");
            return 0;
        }
    puts("Bob");
    return 0;
}