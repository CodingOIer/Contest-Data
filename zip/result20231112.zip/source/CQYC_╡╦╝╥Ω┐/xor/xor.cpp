#include <bits/stdc++.h>
using namespace std;
int n, m, k;
bool f[200];
__int128_t ans;
__int128_t a[200];
void read(__int128_t &x)
{
    char c = getchar();
    while (isspace(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
bool parity(__int128_t x) { return x ? !parity(x - (x & -x)) : false; }
void dfs(int x, int y)
{
    if (x == m)
    {
        if (y < k)
            return;
        __int128_t sum = 0, d = 0, p = 0;
        for (int i = m - 1; i >= 0; i--)
            if (f[i])
                sum += __int128_t(n) << i, d |= __int128_t(1) << i, p++;
            else
            {
                __int128_t t = 0;

                for (int j = 0; j < 1 << p; j++)
                {
                    __int128_t g = 0, b = 0, e = d;
                    for (int k = 0; k < p; k++, e -= e & -e)
                        if (j >> k & 1)
                            b |= e & -e;
                    for (int k = 0; k < n; k++)
                        g += (a[k] >> i & 1) ^ parity(~a[k] & b);
                    t = max(t, g);
                }
                sum += t << i;
            }
        ans = max(ans, sum);
        return;
    }
    dfs(x + 1, y);
    if (y < k)
        f[x] = true, dfs(x + 1, y + 1), f[x] = false;
}
int main()
{
    freopen("xor.in", "r", stdin);
    freopen("xor.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 0; i < n; i++)
        read(a[i]);
    dfs(0, 0);
    if (ans < SIZE_MAX)
        printf("%zu\n", size_t(ans));
    else
        printf("%zu%019zu\n", size_t(ans / 10000000000000000000ull), size_t(ans % 10000000000000000000ull));
    return 0;
}