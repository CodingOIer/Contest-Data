#include <bits/stdc++.h>
using namespace std;
int t, l, r;
int main()
{
    freopen("square.in", "r", stdin);
    freopen("square.out", "w", stdout);
    scanf("%*d%d", &t);
    while (t--)
    {
        scanf("%d%d", &l, &r);
        if (l == r && !fmod(sqrt(l), 1))
        {
            puts("1");
            continue;
        }
        puts("2");
    }
    return 0;
}