#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cout << "Alice";
    return 0;
}