#include<bits/stdc++.h>
using namespace std;
int n,m;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    cin >> n >> m;
    if(m == 2)
    {
        cout << n << " " << 1;
        return 0;
    }
    return 0;
}