#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int n,m,u,v,q,vis[maxn],vis2[maxn],ans,cnt;
vector<int> to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int dfs(int u,int x){
    if(vis[u])
        return 0;
    if(x==u){
        vis2[x]=1;
        return 1;
    }
    int bj=0;
    vis[u]=1;
    for(auto v:to[u])
        if(dfs(v,x))
            vis2[u]=1,bj=1;
    vis[u]=0;
    return bj;
}
void dfs2(int u){
    if(vis2[u])
        return;
    ++cnt;
    vis2[u]=1;
    for(auto v:to[u])
        dfs2(v);
}
signed main(){
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        u=read(),v=read();
        to[u].push_back(v);
        to[v].push_back(u);
    }
    q=read();
    while(q--){
        memset(vis,0,sizeof(vis));
        memset(vis2,0,sizeof(vis2));
        u=read(),v=read();
        dfs(u,v);
        ans=0,cnt=0;
        for(int i=1;i<=n;i++)
            if(!vis2[i]){
                cnt=0;
                dfs2(i);
                ans^=cnt;
            }
        printf("%lld\n",ans);
    }
    return 0;
}
