#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353,maxn=1e5+5;
int n,k,m,l[maxn],r[maxn],s[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int power(int a,int b){
    int res=1;
    while(b){
        if(b&1)
            res=res*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return res;
}
signed main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
    n=read(),k=read(),m=read();
    for(int i=1;i<=m;i++)
        l[i]=read(),r[i]=read(),s[i]=read();
    if(k==0){
        puts("1");
        return 0;
    }
    if(m==0){
        printf("%lld\n",power(power(2,k),n));
        return 0;
    }
    return 0;
}