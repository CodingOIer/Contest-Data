#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int n,k,p[maxn],q[maxn],a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
    n=read(),k=read();
    for(int i=1;i<=n;i++)
        p[i]=read();
    for(int i=1;i<=n;i++)
        q[i]=read();
    for(int i=2;i<=k;i++){
        for(int j=1;j<=n;j++)
            a[p[j]]=q[j];
        for(int j=1;j<=n;j++)
            p[j]=q[j],q[j]=a[j];
    }
    for(int i=1;i<=n;i++)
        printf("%lld ",a[i]);
    return 0;
}