#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,k,r,f[2][10000005],sum,op,ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int power(int a,int b){
    int res=1;
    while(b){
        if(b&1)
            res=res*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return res;
}
signed main(){
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
    n=read(),k=read(),r=read();
    f[op][0]=1;
    for(int i=1;i<=n;i++){
        for(int j=0;j<=n*k;j++)
            f[op^1][j]=0;
        for(int j=n*k;j>=0;j--)
            if(f[op][j])
                for(int l=1;l<=k;l++)
                    f[op^1][l+j]=(f[op^1][l+j]+f[op][j])%mod;
        op^=1;
    }
    for(int i=1;i<=n*k;i++)
        sum=(sum+f[op][i]*f[op][i]%mod)%mod;
    int res=1,num=(power(k,n)*power(k,n)%mod+mod-sum)%mod*power(2,mod-2)%mod*power(power(k,n)*power(k,n)%mod,mod-2)%mod;
    for(int i=1;i<=r;i++){
        ans=(ans+res*num%mod)%mod;
        res=res*(1+mod-num*2%mod)%mod;
    }
    printf("%lld\n",ans);
    return 0;
}