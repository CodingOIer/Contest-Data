#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define mod 998244353
// #define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
int n,K,m,f[N],g[N];
il int find(int x){
    return f[x]==x?x:f[x]=find(f[x]);
}
vector<int> V[N];
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
    n=read();K=read();m=read();
    for(int i=0;i<=n;++i){
        f[i]=i;V[i].pk(i);g[i]=0;
    }
    while(m--){
        int u=read()-1,v=read(),s=read();
        if(V[find(u)].size()>V[find(v)].size()) swap(u,v);
        int fu=find(u),fv=find(v);
        if(fu!=fv){
            int tmp=g[u]^g[v]^s;
            for(auto x:V[fu]){
                g[x]^=tmp;V[fv].pk(x);
            }
            f[fu]=fv;
            V[fu].clear();
        }
        else if(g[u]!=(g[v]^s)){
            putchar('0');return 0;
        }
    }
    // for(int i=0;i<=n;++i) if(Pow(Pow(2,K),i)==210309119) cerr<<i<<" ";
    int tot=0;
    for(int i=0;i<=n;++i) if(f[i]==i) ++tot;
    // cerr<<tot<<" ";
    write(Pow(Pow(2,K),tot-1));
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}