#include<bits/stdc++.h>
#define ll long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 60000010
#define mod 998244353
// #define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=1ll*res*a%mod;
        a=1ll*a*a%mod;b>>=1;
    }
    return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int n,K,R,ans;
int inv[N];
// int fac[N],inv[N];
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
    n=read();K=read();R=read();
	inv[0]=1;
	for(int i=1;i<N;++i) inv[i]=1ll*inv[i-1]*i%mod;
	inv[N-1]=Pow(inv[N-1],mod-2);
	for(int i=N-1;i;--i) inv[i-1]=1ll*inv[i]*i%mod;
	for(int i=1,j=1;i<N;j=1ll*j*i%mod,++i) inv[i]=1ll*inv[i]*j%mod;
	ll res=1;
	for(int i=1;i<=n*2-1;++i) res=res*(K*n+n-i)%mod*inv[i]%mod;
    for(int i=0;i<=n<<1;++i){
		if(K*(n-i)<n) break;
		if(i&1) Del(ans,res);
		else Add(ans,res);
		res=res*inv[i+1]%mod*(n*2-i)%mod;
		for(int j=K*(n-i-1)-n+1;j<=K*(n-i)-n;++j) res=res*j%mod;
		for(int j=K*(n-i-1)+n;j<=K*(n-i)+n-1;++j) res=res*inv[j]%mod;
	}
    ans=1ll*ans*Pow(Pow(Pow(K,mod-2),2),n)%mod;
    write((1ll-Pow(ans,R)+mod)*Pow(2,mod-2)%mod);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}