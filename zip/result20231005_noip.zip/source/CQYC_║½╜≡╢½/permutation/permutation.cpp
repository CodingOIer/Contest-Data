#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,K;
struct node{
    int a[5010];
    il node operator+(ct node &x)ct{
        node b;
        for(int i=1;i<=n;++i) b.a[a[i]]=x.a[i];
        return b;
    }
} f[5010];
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
    n=read();K=read();
    for(int i=1;i<=n;++i) f[0].a[i]=read();
    for(int i=1;i<=n;++i) f[1].a[i]=read();
	// K=100;
    for(int i=2;i<=K;++i) f[i]=f[i-2]+f[i-1];
	// for(int i=1;i<<1<=K;++i){
	// 	cout<<i-1<<" "<<i<<" "<<i*2<<"\n";
	// 	for(int j=1;j<=n;++j) cout<<f[i-1].a[j]<<" ";
	// 	cout<<"\n";
	// 	for(int j=1;j<=n;++j) cout<<f[i].a[j]<<" ";
	// 	cout<<"\n";
	// 	for(int j=1;j<=n;++j) cout<<f[i<<1].a[j]<<" ";
	// 	cout<<"\n";
	// }
    for(int i=1;i<=n;++i){
        write(f[K].a[i]);putchar(' ');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}