#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define M 300010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[M<<1],to[M<<1],t;
il void add(int u,int v){
	nxt[++t]=head[u];head[u]=t;to[t]=v;
	nxt[++t]=head[v];head[v]=t;to[t]=u;
}
vector<int> e[N<<1];
il void Add(int u,int v){
	// cerr<<u<<" "<<v<<"\n";
	e[u].pk(v);
}
int n,m,Q,dfn[N],low[N],id,f[N<<1][20],tot,sz[N<<1],g[N<<1][20],dep[N<<1],G[N<<1],pre[N<<1],suf[N<<1];
stack<int> S;
il void tarjan(int x,int fa){
	dfn[x]=low[x]=++id;S.push(x);
	for(int i=head[x];i;i=nxt[i])
		if(!dfn[to[i]]){
			tarjan(to[i],x);
			low[x]=min(low[x],low[to[i]]);
			if(low[to[i]]>=dfn[x]){
				Add(x,++tot);
				while(!S.empty()){
					int v=S.top();S.pop();
					Add(tot,v);
					if(v==to[i]) break;
				}
			}
		}
		else if(to[i]!=fa) low[x]=min(low[x],dfn[to[i]]);
}
il void dfs1(int x,int fa){
	f[x][0]=fa;dep[x]=dep[fa]+1;
	for(auto v:e[x]) if(v!=fa){
		dfs1(v,x);sz[x]+=sz[v];
	}
	if(x<=n){
		++sz[x];
		for(auto v:e[x]) G[x]^=sz[v];
	}
	else for(auto v:e[x]) G[x]^=G[v];
	// cerr<<x<<" "<<G[x]<<"\n";
}
il void dfs2(int x){
	// cerr<<x<<" "<<g[x][0]<<"\n";
	for(int i=1;i<20;++i){
		f[x][i]=f[f[x][i-1]][i-1];
		g[x][i]=g[x][i-1]^g[f[x][i-1]][i-1];
	}
	if(x<=n){
		int lst=0;
		for(auto v:e[x]){
			pre[v]^=lst;lst^=sz[v];
		}
		lst=0;reverse(e[x].begin(),e[x].end());
		for(auto v:e[x]){
			suf[v]^=lst;lst^=sz[v];
		}
	}
	else{
		int lst=0;
		for(auto v:e[x]){
			pre[v]^=lst;lst^=G[v];
		}
		lst=0;reverse(e[x].begin(),e[x].end());
		for(auto v:e[x]){
			suf[v]^=lst;lst^=G[v];
		}
	}
	for(auto v:e[x]){
		g[v][0]=pre[v]^suf[v];dfs2(v);
	}
}
il int LCA(int u,int v){
	// if(dep[u]<dep[v]) swap(u,v);
	for(int i=19;i>=0;--i) if(dep[f[u][i]]>=dep[v]) u=f[u][i];
	if(u==v) return u;
	for(int i=19;i>=0;--i) if(f[u][i]!=f[v][i]){
		u=f[u][i];v=f[v][i];
	}
	return f[u][0];
}
il int jumpg(int u,int len){
	if(len<1) return 0;
	int res=0;
	for(int i=19;i>=0;--i) if((1<<i)&len){
		res^=g[u][i];u=f[u][i];
	}
	return res;
}
il int jumpf(int u,int len){
	for(int i=19;i>=0;--i) if((1<<i)&len) u=f[u][i];
	return u;
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	tot=n=read();m=read();
	while(m--) add(read(),read());
	tarjan(1,0);dfs1(1,0);dfs2(1);
	Q=read();
	while(Q--){
		int u=read(),v=read();
		if(dep[u]<dep[v]) swap(u,v);
		int lca=LCA(u,v),res=jumpg(u,dep[u]-dep[lca])^jumpg(v,dep[v]-dep[lca]-1)^G[u];
		if(lca==v) res^=(n-sz[v]);
		else{
			res^=G[v];
			if(lca<=n){
				res^=sz[jumpf(v,dep[v]-dep[lca]-1)]^(n-sz[lca]);
			}
			else{
				res^=G[jumpf(v,dep[v]-dep[lca]-1)]^g[lca][0];
				if(f[lca][0]) res^=(n-sz[f[lca][0]]);
			}
		}
		write(res);putchar('\n');
	}
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}