#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e5+5;
int N,K,M,L[Mxn],R[Mxn],S[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
signed main() {
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	N=_(),K=_(),M=_();
	bool Flag=0;
	For(i,1,M) {
		L[i]=_(),R[i]=_(),S[i]=_();
		if(K==0&&S[i]!=0) Flag=1;
	}
	if(Flag) pc('0'),exit(0);
	return 0;
}
