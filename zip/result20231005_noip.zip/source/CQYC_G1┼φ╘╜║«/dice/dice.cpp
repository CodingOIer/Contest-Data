#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define int long long
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
bool ppp;
const int Mxn=1e7+5,P=998244353;
int N,K,R,Iv[Mxn],Fc[Mxn];
int Tot,Tie,Win,P_t,P_w,Pre,Ans;
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int Power(int x,int b) {
	int s=1;
	while(b) {
		if(b&1) s=1ll*s*x%P;
		x=1ll*x*x%P,b>>=1;
	}
	return s;
}
void Init() {
	Fc[0]=Iv[0]=Fc[1]=Iv[1]=1;
	For(i,2,Mxn-1) Fc[i]=1ll*Fc[i-1]*i%P,Iv[i]=1ll*Iv[P%i]*(P-P/i)%P;
	For(i,2,Mxn-1) Iv[i]=1ll*Iv[i]*Iv[i-1]%P;
}
int C(int x,int y) {
	if(x<0||y<0||x<y) return 0;
	return 1ll*Fc[x]*Iv[y]%P*Iv[x-y]%P;
}
void Upd(int &x,int y) {x+=y,x=x<0?x+P:(x<P?x:x-P);}
bool pppp;
signed main() {
//	cerr<<abs(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	N=_(),K=_()-1,R=_();
	Init();
	Tie=0,Win=Tot=Power(K+1,N<<1);
	int Flag=1;
	for(int i=0;i*(K+1)<=N*K;++i) {
		Upd(Tie,1ll*Flag*C(2*N,i)*C(2*N-1+N*K-i*(K+1),2*N-1)%P),Flag*=-1;
	}
	Upd(Win,-Tie),Win=1ll*Win*Iv[2]%P;
	P_t=1ll*Tie*Power(Tot,P-2)%P,P_w=1ll*Win*Power(Tot,P-2)%P;
	Pre=1;
	For(i,1,R) 
		Upd(Ans,1ll*Pre*P_w%P),Pre=1ll*Pre*P_t%P;
	__(Ans);
	return 0;
}
