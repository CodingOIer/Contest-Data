#include<bits/stdc++.h> 
using namespace std;

vector<int> permutation_sum(const vector<int>& p, const vector<int>& q) {
    vector<int> result(p.size());
    for (int i = 0; i < p.size(); i++) {
        result[p[i]-1] = q[i];
    }
    return result;
}

int main() {
	freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    int n, k;
    cin >> n >> k;

    vector<int> p(n), q(n);
    for (int i = 0; i < n; i++) {
        cin >> p[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> q[i];
    }

    for (int i = 2; i <= k; i++) {
        vector<int> next = permutation_sum(p, q);
        p = q;
        q = next;
    }

    for (const int& num : q) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}

