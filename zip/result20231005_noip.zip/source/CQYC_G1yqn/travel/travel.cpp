#include <iostream>
#include <vector>

const int MOD = 998244353;

int main() {
	    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    int n, k, m;
    std::cin >> n >> k >> m;
    std::vector<std::vector<int>> dp(n, std::vector<int>(1 << k, 0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < (1 << k); ++j)
            dp[i][j] = 1;

    while (m--) {
        int l, r, s;
        std::cin >> l >> r >> s;
        l--; r--;
        for (int i = l; i <= r; ++i) {
            int cnt = 0;
            for (int j = 0; j < (1 << k); ++j)
                if ((j ^ s) >= l && (j ^ s) <= r)
                    cnt = (cnt + dp[i][j]) % MOD;
            for (int j = 0; j < (1 << k); ++j)
                dp[i][j] = (j ^ s) >= l && (j ^ s) <= r ? cnt : 0;
        }
    }

    int res = 1;
    for (int i = 0; i < n; ++i) {
        int cnt = 0;
        for (int j = 0; j < (1 << k); ++j)
            cnt = (cnt + dp[i][j]) % MOD;
        res = (1LL * res * cnt) % MOD;
    }
    std::cout << res;

    return 0;
}

