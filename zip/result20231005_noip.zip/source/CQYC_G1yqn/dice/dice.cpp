#include<bits/stdc++.h>
using namespace std;

const int MOD = 998244353;

int N, K, R;
long long dp[2][15];

long long qpow(long long a, long long b) {
    long long res = 1;
    while (b) {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
        b >>= 1;
    }
    return res;
}

int main() {
	    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    cin >> N >> K >> R;

    dp[0][0] = 1;
    int cur = 0;
    for(int i=1; i<=N; ++i) {
        memset(dp[1 - cur], 0, sizeof(dp[1 - cur]));
        for(int j=0; j<=i*K; ++j) {
            for(int k=1; k<=K; ++k) {
                if(j-k >= 0) {
                    dp[1 - cur][j] = (dp[1 - cur][j] + dp[cur][j-k]) % MOD;
                }
            }
        }
        cur = 1 - cur;
    }

    long long winProb = 0;
    for(int s=N; s<=N*K; ++s) {
        for(int t=0; t<s; ++t) {
            winProb = (winProb + dp[cur][s] * dp[cur][t]) % MOD;
        }
    }

    long long totalWays = 1;
    for(int i=0; i<2*N; ++i) totalWays = totalWays * K % MOD;

    long long res = winProb * qpow(totalWays, MOD - 2) % MOD;

    cout << res << endl;
    return 0;
}

