#include<bits/stdc++.h>
#define fi first
#define se second
#define mk make_pair
#define pi pair<ull,ull>
using namespace std;
typedef unsigned long long ull;
const int N=1e5+10,base=233;
int n,k,a[N],b[N],c[N];
map<pi,int>s;
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	for(int i=1;i<=n;i++) scanf("%d",b+i);
	ull H1=0,H2=0;
	for(int j=1;j<=n;j++)
		H1=H1*base+a[j],H2=H2*base+b[j];
	s[mk(H1,H2)]=1;
	for(int i=2;i<=k;i++)
	{
		for(int j=1;j<=n;j++) c[a[j]]=b[j];
		for(int j=1;j<=n;j++) swap(a[j],c[j]);
		for(int j=1;j<=n;j++) swap(a[j],b[j]);
		H1=0,H2=0;
		for(int j=1;j<=n;j++)
			H1=H1*base+a[j],H2=H2*base+b[j];
		int &T=s[mk(H1,H2)];
		if(T)
		{
			k-=T;
			k%=(i-T);
			i=0;
			s.clear();
		}
		T=i;
	}
	for(int i=1;i<=n;i++)
		cout<<b[i]<<" \n"[i==n];
	fclose(stdin);fclose(stdout);
	return 0;
}
