#include<bits/stdc++.h>
using namespace std;
typedef unsigned int ui;
const int N=1e5+10,mod=998244353;
int n,m,k,S,ans=1,l[N],r[N],s[N],t[N],a[N],b[N];
void check(int x)
{
	for(int i=1;i<=n;i++) b[i]=a[i]^b[i-1];
	for(int i=1;i<=m;i++)
		if((b[r[i]]^b[l[i]-1])!=t[i]) return;
	++S;
}
void dfs(int x,int T)
{
	if(x>n) return check(T);
	a[x]=0,dfs(x+1,T);
	a[x]=1,dfs(x+1,T);
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d%d",&n,&k,&m);
	for(int i=1;i<=m;i++) scanf("%d%d%d",l+i,r+i,s+i);
	if(!k)
	{
		for(int i=1;i<=m;i++)
			if(s[i]) return puts("0"),0;
		return puts("1"),0;
	}
	for(int i=0;i<k;i++)
	{
		for(int j=1;j<=m;j++) t[j]=s[j]>>i&1;
		S=0,dfs(1,i),ans=1ll*S*ans%mod;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
