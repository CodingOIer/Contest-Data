#include<bits/stdc++.h>
using namespace std;
const int N=1e7+10,M=2e7+10,mod=998244353;
int n,k,r,ans,P,win;
int f[N],fac[M],inv[M];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
	}
	return res;
}
void pre()
{
	fac[0]=1;
	for(int i=1;i<M;i++) fac[i]=1ll*i*fac[i-1]%mod;
	inv[M-1]=ksm(fac[M-1],mod-2);
	for(int i=M-1;i;i--) inv[i-1]=1ll*i*inv[i]%mod;
}
int C(int x,int y) {if(y>x) return 0;return 1ll*fac[x]*inv[y]%mod*inv[x-y]%mod;}
int main()
{
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	pre();
	cin>>n>>k>>r;
	int Inv=1,Mx=n*(k-1)+n+n-1-(n-1)*k;
	assert(Mx>0);
	f[n-1]=1;
	for(int i=1;i<=n*(k-1);i++) Inv=1ll*i*Inv%mod;
	Inv=ksm(Inv,mod-2);
	for(int i=1;i<=Mx;i++) f[n-1]=1ll*i*f[n-1]%mod;
	for(int i=n-1;i;i--)
	{
		f[i-1]=1ll*(Mx+1)*f[i]%mod;
		for(int j=Mx+2;j<=Mx+k;j++) f[i-1]=1ll*f[i-1]*j%mod;
		Mx+=k;
	}
	for(int i=0,t=1,l,r;i<n;i++)
	{
		if(t) upd(P,1ll*C(n+n,i)*f[i]%mod*Inv%mod*inv[n+n-1]%mod);
		else upd(P,mod-1ll*C(n+n,i)*f[i]%mod*Inv%mod*inv[n+n-1]%mod);
		t^=1;
		l=n*(k-1)-(i+1)*k,r=n*(k-1)-i*k;
		if(l<0) break;
		for(int j=l+1;j<=r;j++) Inv=1ll*Inv*j%mod;
	}
	P=1ll*P*ksm(ksm(k,n+n),mod-2)%mod;
	win=1ll*(1-P+mod)*((mod+1)/2)%mod;
	for(int i=1,now=1;i<=r;i++)
		upd(ans,1ll*now*win%mod),now=1ll*now*P%mod;
	cout<<ans<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
