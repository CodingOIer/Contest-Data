#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
const int N=1e5+10,M=N<<1,K=N<<2;
int n,m,q,T,a[N];
int sum[K];
int Fa[N],ID[N],dep[N],dfn[N],low[N],num[N],son[N],top[N],tot[N];
int first[N],to[M],nxt[M],cnt;
stack<int>stk;
vector<int>bic[N];
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
int check(int f,int s)
{
	if(f>n)
	{
		assert(s<=n);
		return tot[s]-1;
	}
	return tot[s];
}
void dfs1(int x,int fa)
{
	stk.push(x);
	dfn[x]=low[x]=++cnt;
	for(int i=first[x],v;i;i=nxt[i])
		if(!dfn[v=to[i]])
		{
			dfs1(v,x);
			low[x]=min(low[x],low[v]);
			if(low[v]>=dfn[x])
			{
				++T;
				while(!stk.empty())
				{
					bic[T].push_back(stk.top());
					stk.pop();
					if(bic[T].back()==v) break;
				}
				bic[T].push_back(x);
			}
		}
		else if(v!=fa) low[x]=min(low[x],dfn[v]);
	if(!fa&&!first[x]) bic[++T].push_back(x);
}
void dfs2(int x,int fa)
{
	Fa[x]=fa;dep[x]=dep[fa]+1;
	num[x]=1;tot[x]=(x<=n);
	for(int i=first[x],v;i;i=nxt[i])
	{
		if((v=to[i])==fa) continue;
		dfs2(v,x);
		num[x]+=num[v];tot[x]+=tot[v];
		if(num[v]>num[son[x]]) son[x]=v;
	}
}
void dfs3(int x,int t)
{
	top[x]=t;
	ID[dfn[x]=++cnt]=x;
	if(!son[x]) return;
	dfs3(son[x],t);
	for(int i=first[x],v;i;i=nxt[i])
		if((v=to[i])!=Fa[x]&&v!=son[x])
			dfs3(v,v),a[x]^=check(x,v);
}
void build(int id,int l,int r)
{
	if(l==r) return sum[id]=a[ID[l]],void();
	int mid=(l+r)>>1;
	build(lt,l,mid);build(rt,mid+1,r);
	sum[id]=sum[lt]^sum[rt];
}
int query(int id,int l,int r,int L,int R)
{
	if(l>R||r<L) return 0;
	if(L<=l&&r<=R) return sum[id];
	int mid=(l+r)>>1;
	return query(lt,l,mid,L,R)^query(rt,mid+1,r,L,R);
}
int LCA(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=Fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	return y;
}
int Query(int x,int y)
{
	int res=a[x]^a[y],lca=LCA(x,y);
	if(x!=lca) res^=(tot[x]-1);
	if(y!=lca) res^=(tot[y]-1);
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		res^=query(1,1,n+T,dfn[top[x]],dfn[x]);
		res^=check(Fa[top[x]],top[x]);
//		if(son[Fa[top[x]]]) res^=tot[son[Fa[top[x]]]];
		x=Fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	res^=query(1,1,n+T,dfn[y],dfn[x]);
	if(lca>n) res^=(n-tot[Fa[lca]]);
	else res^=(n-tot[lca]);
	return res;
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%d%d",&n,&m);
	int x,y;
	while(m--)
		scanf("%d%d",&x,&y),inc(x,y),inc(y,x);
	cnt=0;dfs1(1,0);cnt=0;
	for(int i=1;i<=n;i++) first[i]=0;
	for(int i=1;i<=T;i++)
		for(int j:bic[i]) inc(n+i,j),inc(j,n+i);
	dfs2(1,0);cnt=0;dfs3(1,1);
	build(1,1,n+T);
	scanf("%d",&q);
	while(q--)
	{
		scanf("%d%d",&x,&y);
		printf("%d\n",Query(x,y));
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
