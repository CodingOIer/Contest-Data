#include<bits/stdc++.h>
#define M 998244353
using namespace std;
int n,m,R;
int s[60000000];
int ksm(int x,int y){
    int res=1;
    while(y){
        if(y&1) res=1ll*res*x%M;
        x=1ll*x*x%M;
        y>>=1;
    }
    return res;
}
inline int inv(int x){
    return ksm(s[x],M-2);
}
int C(int x,int y){
    if(y<0||y>x) return 0;
    return 1ll*s[x]*inv(y)%M*inv(x-y)%M;
}
int main(){
    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    s[0]=1;
    for(int i=1;i<=60000000;i++) s[i]=1ll*s[i-1]*i%M;
    int ans=0;
    cin>>n>>m>>R;
    m--;
    for(int i=0,c=1;i<=n;i++,c=-c) ans=(ans+1ll*c*C(n*m+2*n-1-i*(m+1),2*n-1)*C(2*n,i))%M;
    int res=(M+1ll-1ll*ans*ksm(ksm(m+1,2*n),M-2)%M)*ksm(2,M-2)%M;
    res=(1ll*res*2)%M;
    res=(1ll-res+M)%M;
    res=ksm(res,R);
    res=(1ll-res+M)%M;
    res=(1ll*res*ksm(2,M-2))%M;
    cout<<res<<"\n";
    return 0;
}