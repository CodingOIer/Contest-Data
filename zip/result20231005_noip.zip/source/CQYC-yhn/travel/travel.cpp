#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,K,m,s[100005],inv[100005],b[100005];
struct ok{
    int l,r,o;
    bool operator < (const ok &A) const{
        return r<A.r;
    }
}a[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
inline int C(int x,int y){
    if(x<y) return 0;
    int s1=s[x],s2=inv[y],s3=inv[x-y];
    s2=(s2*s3)%M;
    s1=(s1*s2)%M;
    return s1;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
signed main(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    s[0]=inv[0]=1;
    for(int i=1;i<=100000;i++) s[i]=(s[i-1]*i)%M,inv[i]=ksm(s[i],M-2);
    n=read(),K=read(),m=read();
    for(int i=1;i<=m;i++) a[i].l=read(),a[i].r=read(),a[i].o=read();
    if(K==0){
        for(int i=1;i<=m;i++) if(a[i].o>0) {cout<<"0";return 0;}
        cout<<"1";
    }
    else if(n<=10&&m<=10){
        int t=1;
        for(int i=0;i<K;i++){
            int cnt=0;
            for(int j=0;j<(1<<n);j++){
                for(int g=1;g<=n;g++) b[g]=(j&(1<<(g-1)))>0;
                for(int g=1;g<=n;g++) b[g]^=b[g-1];
                bool flag=1;
                for(int g=1;g<=m;g++){
                    int d=b[a[g].r]^b[a[g].l-1];
                    int D=(a[g].o&(1<<i))>0;
                    if(d!=D) flag=0;
                }
                if(flag) cnt++;
            }
            t=(t*cnt)%M;
        }
        cout<<t;
    }
    else{
        sort(a+1,a+1+m);
        int t=1;
        for(int i=1;i<=m;i++){
            int d=a[i].r-a[i-1].r;
            int D=(a[i].o!=a[i-1].o);
            int w=0;
            for(int j=D;j<=d;j+=2) add(w,C(d,j));
            t=(t*w)%M;
        }
        cout<<t;
    }
    return 0;
}