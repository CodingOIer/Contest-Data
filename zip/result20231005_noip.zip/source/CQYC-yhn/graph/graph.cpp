#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,Q,t1,t2,cnt,head[100005],nxt[600005],txt[600005],dfn[100005],low[100005],tnt,tot,dep[200005],fa[200005],res;
vector<int> e[100005],E[200005];
stack<int> q;
bool v[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void dfs(int k,int f,int g){
    dfn[k]=low[k]=++tnt;
    q.push(k);
    v[k]=1;
    int son=0;
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        if(!dfn[txt[i]]){
            son++;
            dfs(txt[i],k,g);
            low[k]=min(low[k],low[txt[i]]);
            if(dfn[k]<=low[txt[i]]){
                tot++;
                while(q.top()!=txt[i]){
                    e[tot].push_back(q.top());
                    v[q.top()]=0;
                    q.pop();
                }
                e[tot].push_back(q.top());
                v[q.top()]=0;
                q.pop();
                e[tot].push_back(k);
            }
        }
        else if(v[txt[i]]) low[k]=min(low[k],dfn[txt[i]]);
    }
    if(k==g&&son==0){
        tot++;
        while(!q.empty()){
            e[tot].push_back(q.top());
            v[q.top()]=0;
            q.pop();
        }
    }
}
inline void dfs2(int k,int f){
    fa[k]=f;dep[k]=dep[f]+1;
    for(int i=0;i<(int)E[k].size();i++){
        if(E[k][i]==f) continue;
        dfs2(E[k][i],k);
    }
}
inline void dfs3(int k){
    res++;v[k]=1;
    for(int i=head[k];i;i=nxt[i]){
        if(v[txt[i]]) continue;
        dfs3(txt[i]);
    }
}
signed main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    Q=read();
    dfs(1,0,1);
    for(int i=1;i<=tot;i++) for(int j=0;j<(int)e[i].size();j++) E[n+i].push_back(e[i][j]),E[e[i][j]].push_back(n+i);
    dfs2(1,0);
    for(int i=1;i<=Q;i++){
        // cerr<<i<<"\n";
        for(int j=1;j<=n;j++) v[j]=0;
        t1=read(),t2=read();
        if(dep[t1]<dep[t2]) swap(t1,t2);
        vector<int> G;
        while(dep[t1]>dep[t2]){
            G.push_back(t1);
            t1=fa[t1];
        }
        while(t1!=t2){
            G.push_back(t1);G.push_back(t2);
            t1=fa[t1];t2=fa[t2];
        }
        G.push_back(t1);
        for(int j=0;j<(int)G.size();j++){
            int d=G[j];
            if(d<=n) v[d]=1;
            else for(int g=0;g<(int)e[d-n].size();g++) v[e[d-n][g]]=1;
        }
        int Ans=0;
        for(int j=1;j<=n;j++){
            if(v[j]) continue;
            res=0;
            dfs3(j);
            Ans^=res;
        }
        printf("%lld\n",Ans);
    }
    return 0;
}