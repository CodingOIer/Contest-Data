#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,K;
struct ok{
    vector<int> a;
    ok operator + (const ok &A) const{
        ok C;
        C.a.resize(n+5);
        for(int i=1;i<=n;i++) C.a[a[i]]=A.a[i];
        return C;
    }
    bool operator == (const ok &A) const{
        for(int i=1;i<=n;i++) if(a[i]!=A.a[i]) return 0;
        return 1;
    }
}f[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    n=read(),K=read();
    f[0].a.resize(n+5);f[1].a.resize(n+5);
    for(int i=1;i<=n;i++) f[0].a[i]=read();
    for(int i=1;i<=n;i++) f[1].a[i]=read();
    int t=-1;
    for(int i=2;i<=K;i++){
        f[i]=f[i-2]+f[i-1]; 
        if(i>4&&f[i]==f[3]&&f[i-1]==f[2]){
            t=i-2;
            break;
        }
    }
    // cerr<<t<<"\n";
    if(t==-1) for(int i=1;i<=n;i++) cout<<f[K].a[i]<<" ";
    else{
        int d=(K-1)%(t-1);
        if(d==0) d=t-1;
        for(int i=1;i<=n;i++) cout<<f[d+1].a[i]<<" ";
    }
    return 0;
}
