#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5,mod=998244353;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,k,m,q;
struct name{
    int to,v;
};
vector<name> g[N];
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=1ll*ans*x%mod;
        x=1ll*x*x%mod;
        base>>=1;
    }
    return ans;
}
int vis[N],ans,flag;
void dfs(int x){
    // cout<<x<<" "<<vis[x]<<"\n";
    for(auto y:g[x]){
        int t=y.to,z=vis[x]^y.v;
        if(vis[t]==-1){
            vis[t]=z;
            dfs(t);
        }
        else if(vis[t]!=z){
            flag=1;
            return;
        }
    }
}
int main(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    n=read(),k=read(),m=read();
    for(int i=1;i<=m;i++){
        int l=read(),r=read(),s=read();
        g[l-1].push_back({r,s});
        g[r].push_back({l-1,s});
    }
    memset(vis,-1,sizeof(vis));
    vis[0]=0;
    dfs(0);
    for(int i=1;i<=n;i++){
        if(vis[i]==-1){
            ans++;
            vis[i]=0;
            dfs(i);
            if(flag){
                cout<<0;
                return 0;
            }
        }
    }
    cout<<pow(pow(2,k),ans)<<"\n";
    return 0;
}