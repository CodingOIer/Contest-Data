#include <bits/stdc++.h>
using namespace std;
const int N=1e7+5,mod=998244353;
int n,k,r,jc[N],ijc[N],p,ans,w,z;
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=1ll*ans*x%mod;
        x=1ll*x*x%mod;
        base>>=1;
    }
    return ans;
}
int C(int n,int m){
    if(m<0||n>m) return 0; 
    return 1ll*jc[m]*ijc[n]%mod*ijc[m-n]%mod;
}
signed main(){
    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    cin>>n>>k>>r;
    jc[0]=1;
    ijc[0]=1;
    for(int i=1;i<=n*k;i++){
        jc[i]=1ll*jc[i-1]*i%mod;
        ijc[i]=pow(jc[i],mod-2);
    }
    for(int i=0;i<=n*k;i++){
        int ans=0;
        for(int j=0;j<n;j++){
            int c=i-(n+j*k);
            if(c<0) break;
            ans=(ans+1ll*C(n-1,n+c-1)*C(j,n)%mod*((j&1)?-1:1)+mod)%mod;
        }
        p=(p+1ll*ans*ans%mod)%mod;
    }
    z=pow(k,n*2);
    w=1ll*(z-p+mod)%mod*pow(2,mod-2)%mod;
    // cout<<z<<" "<<p<<" "<<w<<"\n";
    p=1ll*p*pow(z,mod-2)%mod,w=1ll*w*pow(z,mod-2)%mod;
    for(int i=1;i<=r;i++){
        ans=(ans+1ll*w*pow(p,i-1)%mod)%mod;
    }
    cout<<ans;
    // cout<<"\n"<<ans*z%mod<<"\n";
    return 0;
}