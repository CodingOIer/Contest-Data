#include <bits/stdc++.h>
using namespace std;
const int N=1e5;
int n,k;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
struct pri{
    int a[N];
}p1,p,q;
pri operator *(pri a,pri b){
    pri c;
    for(int i=1;i<=n;i++) c.a[a.a[i]]=b.a[i];
}
struct mar{
    pri a00,a01,a10,a11;
}e;
mar operator *(mar a,mar b){
    return {(a.a00*b.a00)*(a.a01*b.a10),(a.a00*b.a01)*(a.a01*b.a11),(a.a10*b.a00)*(a.a11*b.a10),(a.a10*b.a01)*(a.a11*b.a11)};
}
int Pow(mar a,int k){
    mar ans=e;
}
int main(){
    n=read(),k=read();
    for(int i=1;i<=n;i++) p.a[i]=read(),p1.a[i]=i;
    for(int i=1;i<=n;i++) q.a[i]=read();
    e={p1,p1,p1,p1};
    return 0;
}