#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 2e5 + 10, M = 18;

struct node {
	int p, x;
};

int n, m, q, cnt, tot, top;
int dfn[N], low[N], stk[N], dep[N], siz[N], f[N];
int fa[N][M], st[N][M];

vector<int> E[N], e[N];

void tarjan(int x, int f) {
	dfn[x] = low[x] = ++cnt, stk[++top] = x, siz[x] = 1;
	for(int v : E[x]) if(v ^ f) {
		if(!dfn[v]) {
			tarjan(v, x), low[x] = min(low[x], low[v]);
			if(low[v] >= dfn[x]) {
				tot++, e[x].push_back(tot);
				while(stk[top + 1] ^ v) e[tot].push_back(stk[top--]);				
			}
		}
		else low[x] = min(low[x], dfn[v]);
	}
}

void dfs1(int x) {
	dep[x] = dep[fa[x][0]] + 1;
	for(int v : e[x]) fa[v][0] = x, dfs1(v), siz[x] += siz[v];
	if(x > n) {
		for(int v : e[x]) f[x] ^= f[v];
		st[x][0] = f[x] ^ siz[x];
	}
	else for(int v : e[x]) f[x] ^= siz[v];
}

void dfs2(int x) {
	for(int i = 1; i < M; i++) {
		fa[x][i] = fa[fa[x][i - 1]][i - 1];
		st[x][i] = st[x][i - 1] ^ st[fa[x][i - 1]][i - 1];
	}
	for(int v : e[x]) dfs2(v);
}

void init() {
	tarjan(1, 0), dfs1(1), dfs2(1);
}

node lca(int x, int y) {
	int res = 0; if(dep[x] < dep[y]) swap(x, y);
	for(int i = M - 1; i + 1; i--) if(dep[fa[x][i]] >= dep[y]) res ^= st[x][i], x = fa[x][i];
	if(x == y) return { x, res };
	for(int i = M - 1; i + 1; i--) if(fa[x][i] ^ fa[y][i])
		res ^= st[x][i] ^ st[y][i], x = fa[x][i], y = fa[y][i];
	res ^= st[x][0] ^ st[y][0];
	return { fa[x][0], res };
}

void work() {
	q = read();
	while(q--) {
		node l = lca(read(), read());
		if(l.p > n) l.x ^= f[l.p] ^ siz[l.p] ^ f[fa[l.p][0]] ^ (n - siz[fa[l.p][0]]);
		else l.x ^= f[l.p] ^ (n - siz[l.p]); write(l.x), putchar('\n');
	}
}

bool edmer;
signed main() {
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
	n = tot = read(), m = read();

	for(int i = 1; i <= m; i++) {
		int u = read(), v = read();
		E[u].push_back(v), E[v].push_back(u);
	}

	init(), work();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 