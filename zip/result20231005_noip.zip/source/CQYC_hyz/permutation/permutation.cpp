#include<bits/stdc++.h>
#define ull unsigned long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e3 + 10;
const ull base = 1e9 + 9;

int n, k;

ull ml;

unordered_map<ull, int> mp;

struct node {
    vector<int> t;

    void input() {
        for(int i = 1; i <= n; i++) t.push_back(read() - 1);
    }

    node operator + (const node &p) const {
        vector<int> tmp(n);
        for(int i = 0; i < n; i++) tmp[p.t[i]] = t[i];
        return (node) { tmp };
    }

    void output() {
        for(int x : t) write(x + 1), putchar(' ');
        putchar('\n');
    }

    ull ha() {
        ull res = 0;
        for(int x : t) res = res * base + x;
        return res;
    }
} p, q;

bool edmer;
signed main() {
	freopen("permutation.in", "r", stdin);
	freopen("permutation.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), k = read() - 1, p.input(), q.input();
    
    ml = 1;
    for(int i = 1; i <= n; i++) ml *= base;

    for(int i = 1; i <= k; i++) {
        p = q + p, swap(p, q);
        ull ha = p.ha() * ml + q.ha();

        if(mp.count(ha)) {
            int x = i - mp[ha];
            k = (k - i) % x + i;
        }
        else mp[ha] = i;
    }

    q.output();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 