#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e7 + 10, mod = 998244353, inv2 = (mod + 1) / 2;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

int n, k, r, sum, ans;
int val[N];

void work() {
    for(int i = 0; i <= n; i++) val[i] = 1;

    int a[4] = { 1, 1, 1, 1 }, b[2] = { n * k, 0 };

    for(int i = 1; i <= n; i++) mul(a[0], i); a[1] = a[0];
    for(int i = n + 1; i <= 2 * n; i++) mul(a[1], i);
    for(int i = 1; i <= n * k; i++) mul(a[2], i);

    a[0] = q_pow(a[0], mod - 2);
    a[1] = q_pow(a[1], mod - 2);
    a[2] = q_pow(a[2], mod - 2);

    for(int i = 0; i <= n; i++) {
        mul(val[n - i], a[0]), mul(val[i], a[1]);
        mul(a[0], n - i), mul(a[1], 2 * n - i);

        int lim = n * k + 2 * n - 1 - (n - i) * (k + 1);
        if(lim < 0) val[n - i] = 0;
        else if(lim > 0) {
            while(b[1] < lim) mul(a[3], ++b[1]);
            mul(val[n - i], a[3]);
        }
        
        lim = n * k - i * (k + 1);

        if(lim < 0) val[i] = 0;
        else if(lim > 0) {
            while(b[0] > lim) mul(a[2], b[0]--);
            mul(val[i], a[2]);
        }
    }

    for(int i = 0; i <= n; i++) add(sum, 2ll * n * (i & 1 ? mod - val[i] : val[i]) % mod);

    mul(sum, 1ll * q_pow(k + 1, 1ll * (mod - 2) * 2 * n % (mod - 1)));

    for(int i = 1, ml = 1; i <= r; i++, mul(ml, sum)) 
        add(ans, 1ll * ml * (mod + 1 - sum) % mod * inv2 % mod);
}

bool edmer;
signed main() {
	freopen("dice.in", "r", stdin);
	freopen("dice.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), k = read() - 1, r = read();

    work(), write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 