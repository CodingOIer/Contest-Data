#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10, mod = 998244353;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

struct edge {
    int v, w;
};

int n, K, m, ans, cnt;
int d[N];

bool vis[N];

vector<edge> e[N];

void dfs(int x) {
    vis[x] = 1;
    
    for(edge l : e[x]) {
        if(vis[l.v] and d[l.v] ^ d[x] ^ l.w) ans = 0;
        else if(!vis[l.v]) d[l.v] = d[x] ^ l.w, dfs(l.v);
    }
}

bool edmer;
signed main() {
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read() + 1, K = (1ll << read()) % mod, m = read(), ans = 1;

    for(int i = 1; i <= m; i++) {
        int l = read(), r = read() + 1, s = read();
        e[l].push_back({ r, s }), e[r].push_back({ l, s });
    }

    dfs(1);

    for(int i = 1; i <= n; i++) if(!vis[i]) dfs(i), mul(ans, K);

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 