
#include<bits/stdc++.h>
using namespace std;
const int maxn=2e7+2;
const int mod=998244353;
bool memst;
int n,K,R;
int va[maxn];
// int fac[maxn],inv_fac[maxn];
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p/=2;
    }
    return ret;
}
// void pre(){
//     fac[0]=1;
//     for(int i=1;i<=n*K+2*n;i++)fac[i]=1ll*fac[i-1]*i%mod;
//     inv_fac[n*K+2*n]=f_pow(fac[n*K+2*n],mod-2);
//     for(int i=n*K+2*n;i;i--)inv_fac[i-1]=1ll*inv_fac[i]*i%mod;
//     return ;
// }
// int calc_C(int a,int b){
//     if(a<0||b<0||a<b)return 0;
//     return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
// }
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
// int getu(int x){
//     if(n*(K+1)-1-x*K-2*n-1<0)return 0;
//     return inv_fac[n*(K+1)-1-x*K-2*n+1];
// }
// int getv(int x){
//     if(n*(K+1)-1-x*K<0)return 0;
//     return fac[n*(K+1)-1-x*K];
// }
bool memed;
int main(){
    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    // cerr<<(&memst-&memed)/1024/1024<<'\n';
    scanf("%d%d%d",&n,&K,&R);
    int pr=0;
    int m1=1,m2=1,ad,m3=1,nw=n*(K+1)-1-2*n+1;
    int fc1=1,fc2=1,nw2=0;
    for(int i=1;i<=2*n;i++)m1=1ll*m1*i%mod;
    m1=f_pow(m1,mod-2);
    m2=m1;
    for(int i=1;i<=n*(K+1)-1-2*n+1;i++)m3=1ll*m3*i%mod;
    m3=f_pow(m3,mod-2);
    // pre();
    for(int i=2*n;i>=0;i--){
        while(nw2<n*(K+1)-1-i*K)fc2=1ll*fc2*(++nw2)%mod;
        // printf("%d %d %d %d\n",m1,fc2,(m1==inv_fac[i]),(((n*(K+1)-1-i*K<0)?0:fc2)==getv(i)));
        va[i]=1ll*((i&1)?(mod-1):1)*m1%mod*((n*(K+1)-1-i*K<0)?0:fc2)%mod;
        m1=1ll*m1*i%mod;
        if(i==2*n)ad=m1;
        if(i)fc1=1ll*fc1*i%mod;
        // upd(pr,1ll*((i&1)?(mod-1):1)*calc_C(2*n,i)%mod*calc_C(n*(K+1)-1-i*K,2*n-1)%mod);
        // printf("add %d %d %d %d\n",calc_C(2*n,i),calc_C(n*(K+1)-1-i*K,2*n-1),n*(K+1)-1-i*K,2*n-1);
    }

    for(int i=0;i<=2*n;i++){
        while(nw>=0&&nw>n*(K+1)-1-i*K-2*n+1)m3=1ll*m3*(nw--)%mod;
        va[i]=1ll*va[i]*m2%mod*ad%mod*fc1%mod*m3%mod;
        // if(n*(K+1)-1-i*K<2*n-1)va[i]=0;
        // printf("co %d %d %d %d\n",(m2==inv_fac[2*n-i]),(ad==inv_fac[2*n-1]),(fc1==fac[2*n]),(m3==getu(i)));
        // va[i]=1ll*((i&1)?(mod-1):1)*inv_fac[2*n-i]%mod*fac[2*n]*inv_fac[i]%mod*getv(i)%mod*inv_fac[2*n-1]%mod*getu(i)%mod;
        // va[i]=1ll*((i&1)?(mod-1):1)*inv_fac[2*n-i]%mod*fac[2*n]*inv_fac[i]%mod*calc_C(n*(K+1)-1-i*K,2*n-1)%mod;
        m2=1ll*m2*(2*n-i)%mod;
        upd(pr,va[i]);
    }
    // printf("%d\n",calc_C(4,2));
    // printf("%d %d\n",pr,f_pow(K,2*n));
    pr=1ll*pr*f_pow(K,2ll*n*(mod-2)%(mod-1))%mod;
    int ans=0,mul=1,inv2=f_pow(2,mod-2);
    for(int i=1;i<=R;i++){
        upd(ans,1ll*mul*inv2%mod*(mod+1-pr)%mod);
        mul=1ll*mul*pr%mod;
    }
    printf("%d\n",ans);
    // cerr<<clock();
    return 0;
}