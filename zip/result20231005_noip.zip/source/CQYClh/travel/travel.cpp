#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+2;
const int mod=998244353;
int n,K,m;
int sum[maxn];
bool vis[maxn];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
struct node{
    int l,r,s;
}q[maxn];
struct UFS{
    int fa[maxn],d[maxn];
    void init(int mx){
        for(int i=0;i<=mx;i++)fa[i]=i,d[i]=0;
        return ;
    }
    int find(int x){
        if(x==fa[x])return x;
        int pa=(d[fa[x]]^d[x]),pp=fa[x];
        fa[x]=find(fa[x]);
        d[x]=pa^d[pp];
        return fa[x];
    }
    bool merge(int u,int v,int va){
        int r1=find(u),r2=find(v);
        // printf("mer %d %d %d %d\n",u,v,r1,r2);
        if(r1==r2){
            if((d[u]^d[v])!=va)return 1;
            return 1;
        }
        fa[r2]=r1,d[r2]=d[v]^d[u]^va;
        return 1;
    }
}ufs;
int main(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    n=read(),K=read(),m=read();
    int num=0,l,r,s,f=1;
    ufs.init(n);
    for(int i=1;i<=m;i++){
        l=read(),r=read(),s=read();
        if(!ufs.merge(l-1,r,s))f=0;
        // vis[r]=1;
    }
    // if(!f)printf("pang\n");
    if(!f){printf("0\n");return 0;}
    for(int i=0;i<=n;i++)num+=(ufs.find(i)==i);
    num--;
    int ans=1,mul=(1ll<<K)%mod;
    for(int i=1;i<=num;i++)ans=1ll*ans*mul%mod;
    printf("%d\n",ans);
    return 0;
}