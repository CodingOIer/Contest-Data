#include<bits/stdc++.h>
using namespace std;
// const int maxn=1e5+2,maxm=3e5+2,logn=20;
// int n,m,Q;
// int idx,vcccnt;
// int dfn[maxn],low[maxn],bel[maxn],siz[maxn],sum[maxn],dep[maxn];
// int top,sta[maxn];
// int fa[logn][maxn],d[logn][maxn];
// bool vis[maxn];
// vector<int>ecc[maxn];
// struct node_G{
//     int cnt=1;
//     int hed[maxn*2];
//     struct node_edge{
//         int nxt,to;
//     }G[maxm*2];
//     void add(int u,int v){
//         G[++cnt]=(node_edge){hed[u],v};
//         hed[u]=cnt;
//         return ;
//     }
// }G,T;
// void tarjan(int x,int rt){
//     dfn[x]=low[x]=++idx;
//     sta[++top]=x,vis[x]=1;
//     for(int i=G.hed[x],v;i;i=G.G[i].nxt){
//         v=G.G[i].to;
//         if(!dfn[v]){
//             tarjan(v,rt);
//             low[x]=min(low[x],low[v]);
//             if(low[v]>=dfn[x]){
//                 vcccnt++;
//             }
//         }
//         else low[x]=min(low[x],dfn[v]);
//     }
//     return ;
// }
// void dfs(int x,int f){
//     sum[x]=0,dep[x]=dep[f]+1;
//     for(int i=T.hed[x],v;i;i=T.G[i].nxt){
//         v=T.G[i].to;
//         if(v==f)continue;
//         dfs(v,x);
//         siz[x]+=siz[v];
//         sum[x]^=siz[v];
//     }
//     for(int i=T.hed[x],v;i;i=T.G[i].nxt){
//         v=T.G[i].to;
//         if(v==f)continue;
//         fa[0][v]=x,d[0][v]=sum[x]^siz[v];
//     }
//     return ;
// }
// void pre(){
//     for(int i=1;i<logn;i++){
//         for(int j=1;j<=n;j++){
//             fa[i][j]=fa[i-1][fa[i-1][j]];
//             d[i][j]=d[i-1][j]^d[i-1][fa[i-1][j]];
//         }
//     }
//     return ;
// }
// int read(){
//     int x=0;
//     bool f=0;
//     char ch=getchar();
//     while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
//     while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
//     return (f)?-x:x;
// }
// int lca(int u,int v){
//     if(u==v)return sum[u]^(n-siz[u]);
//     int ret=sum[u]^sum[v];
//     if(dep[u]<dep[v])swap(u,v);
//     for(int i=logn-1;i>=0;i--){
//         if(dep[fa[i][u]]>=dep[v])ret^=d[i][u],u=fa[i][u];
//     }
//     if(u==v)return ret^(n-siz[v]);
//     for(int i=logn-1;i>=0;i--){
//         if(fa[i][u]!=fa[i][v]){
//             ret^=d[i][u],ret^=d[i][v];
//             u=fa[i][u],v=fa[i][v];
//         }
//     }
//     return ret^sum[fa[0][u]]^siz[u]^siz[v]^(n-siz[fa[0][u]]);
// }
int main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    // // scanf("%d%d%d",&n,&m,&Q);
    // n=read(),m=read(),Q=read();
    // int u,v;
    // for(int i=1;i<=m;i++){
    //     // scanf("%d%d",&u,&v);
    //     u=read(),v=read();
    //     G.add(u,v);
    //     G.add(v,u);
    // }
    // tarjan(1,0);
    // // for(int i=1;i<=n;i++)printf("bel[%d]=%d\n",i,bel[i]);
    // pre();
    // for(int i=1;i<=Q;i++){
    //     u=read(),v=read();
    //     printf("%d\n",lca(bel[u],bel[v]));
    // }
    printf("没写完\n");
    return 0;
}