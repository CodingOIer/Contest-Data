//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,Maxm=3e5+10;
int N,M,Q,hed[Maxn],cnt,fa[Maxn],Siz[Maxn];
struct node{int nxt,to;}G[Maxm<<1];
pair<int,int> E[Maxm];
bool Vis[Maxn],To[Maxn];
int dep[Maxn],Val[Maxn],Son[Maxn],top[Maxn],dfn[Maxn];
int ID[Maxn],tot,T[Maxn<<2],TR[Maxn<<2];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

int find(int x){return fa[x]=(fa[x]==x?x:find(fa[x]));}

bool DFS(int x,int p,int t){
    if(x==t||Vis[x]) return Vis[x]=1;
    To[x]=1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p||To[y]) continue;
        if(DFS(y,x,t)) Vis[x]=1;
    }
    To[x]=0;
    return Vis[x];
}

void DFS1(int x,int p){
    fa[x]=p,Siz[x]=1,dep[x]=dep[p]+1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        DFS1(y,x); Siz[x]+=Siz[y];
        Val[x]^=Siz[y];
        if(Siz[y]>Siz[Son[x]]) Son[x]=y;
    }
}

void DFS2(int x,int t){
    top[x]=t,dfn[x]=++tot,ID[tot]=x;
    if(!Son[x]) return;
    DFS2(Son[x],t);
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==fa[x]||y==Son[x]) continue;
        DFS2(y,y);
    }
}

void Build(int id,int l,int r){
    if(l==r) return T[id]=Val[ID[l]],TR[id]=Siz[ID[l]],void();
    Build(ls,l,mid); Build(rs,mid+1,r);
    T[id]=T[ls]^T[rs]; TR[id]=TR[ls]^TR[rs];
}

int Query(int id,int l,int r,int L,int R){
    if(L<=l&&r<=R) return T[id]^TR[id];
    int ret=0;
    if(L<=mid) ret^=Query(ls,l,mid,L,R);
    if(R>mid) ret^=Query(rs,mid+1,r,L,R);
    return ret;
}

int Ask(int x,int y){
    int ret=0;
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        ret^=Query(1,1,N,dfn[top[x]],dfn[x]);
        x=fa[top[x]];
    }
    if(dep[x]>dep[y]) swap(x,y);
    ret^=Query(1,1,N,dfn[x],dfn[y]);
    ret^=Siz[x];
    return ret;
}

void Solve0(){
    DFS1(1,0); DFS2(1,1); Build(1,1,N);
    Q=read();
    while(Q--){
        int u=read(),v=read();
        write(Ask(u,v)),pc('\n');
    }
}

int main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    N=read(),M=read();
    For(i,1,M){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
        E[i]=mp(u,v);
    }
    if(M>5000&&M==N-1) Solve0(),exit(0);
    Q=read();
    while(Q--){
        int u=read(),v=read();
        For(i,1,N) fa[i]=i,Vis[i]=To[i]=0,Siz[i]=1;
        DFS(u,0,v);
        For(i,1,M)if(!Vis[E[i].fi]&&!Vis[E[i].se]){
            int x=E[i].fi,y=E[i].se,fx=find(x),fy=find(y);
            if(fx!=fy){
                if(Siz[fx]>Siz[fy]) swap(fx,fy);
                fa[fx]=fy,Siz[fy]+=Siz[fx];
            }
        }
        int Ans=0;
        For(i,1,N) if(!Vis[i]&&find(i)==i) Ans^=Siz[i];
        write(Ans),pc('\n');
    }
    return 0;
}