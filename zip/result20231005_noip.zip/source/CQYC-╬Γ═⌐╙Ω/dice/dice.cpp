//1s 256M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ll long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

// bool ppp;
const int Maxn=1e7+3,Mod=998244353,INV2=499122177;
int N,K,R,N2,eq,NM,ans,fac_N2;
int inv[Maxn<<1],V1[Maxn],V2[Maxn];
// bool ttt;

int Power(ll x,int d,int r=1){
    while(d){if(d&1) r=1ll*r*x%Mod; x=1ll*x*x%Mod,d>>=1;}
    return r;
}

void Init(){
    int Mx=N2+NM,ff=1;
    //i=0 Get V1
    if((Mx-1)%(K+1)==0){
        int x=(Mx-1)/(K+1);
        if(x<=N) V1[x]=1;
    }
    //i=[1,Mx] Get V1
    For(i,1,Mx){
        ff=1ll*ff*i%Mod;
        if(i==N2) fac_N2=ff;
        if((Mx-1-i)%(K+1)==0){
            int x=(Mx-1-i)/(K+1);
            if(x<=N) V1[x]=ff;
        }
    }
    int gg=Power(ff,Mod-2);
    Rof(i,Mx-1,0){
        gg=1ll*gg*(i+1)%Mod;
        if(i<=N2) inv[i]=gg;
        if(NM>=i&&(NM-i)%(K+1)==0){
            int x=(NM-i)/(K+1);
            if(x<=N) V2[x]=gg;
        }
    }
}

signed main(){
    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    // cerr<<"[Memory]="<<((&ttt)-(&ppp))/1024.0/1024.0<<"\n";
    N=read(),K=read()-1,R=read(); 
    N2=N<<1,NM=N*K,Init();
    For(i,0,N){
        int op=((i&1)?-1:1);
        int t1=1ll*fac_N2*inv[i]%Mod*inv[N2-i]%Mod; //C(N2,i)
        int t2=1ll*V1[i]*inv[N2-1]%Mod*V2[i]%Mod;
        //C(N2-1+NM-i*(K+1),N2-1)
        (eq+=1ll*op*t1*t2%Mod)%=Mod;
    }
    (eq+=Mod)%=Mod;
    int pr=1,t=Power(K+1,N2),c=Power(t,Mod-2);
    For(i,1,R){
        (ans+=1ll*(t-eq%Mod+Mod)%Mod*INV2%Mod*c%Mod*pr%Mod)%=Mod;
        pr=1ll*pr*eq%Mod*c%Mod;
    }
    write(ans);
    // cerr<<"\n[Clock]="<<clock();
    return 0;
}