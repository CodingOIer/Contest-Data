//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,K,P[Maxn],Q[Maxn],W[Maxn],T1[Maxn],T2[Maxn],len;

bool check(){
    For(i,1,N) if(P[i]!=T1[i]||Q[i]!=T2[i]) return 0;
    return 1;
}

int main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    N=read(),K=read()+1;
    For(i,1,N) P[i]=T1[i]=read();
    For(i,1,N) Q[i]=T2[i]=read();
    For(i,3,K){
        For(j,1,N) W[P[j]]=Q[j];
        For(j,1,N) P[j]=Q[j],Q[j]=W[j];
        if(check()){ len=i-2;break; }
    }
    if(len) K=(K-1)%len+1;
    For(i,1,N) P[i]=T1[i],Q[i]=T2[i];
    For(i,3,K){
        For(j,1,N) W[P[j]]=Q[j];
        For(j,1,N) P[j]=Q[j],Q[j]=W[j];
    }
    For(i,1,N) write(Q[i]),pc(' ');
    return 0;
}