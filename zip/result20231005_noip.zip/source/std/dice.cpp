#include <bits/stdc++.h>
#define N 20000001
#define mod 998244353

int n, k, r, i, j, res, ans, fac, inv[N], c[N];

int power(int x, int y)
{
	int ans = 1;
	
	while(y)
	{
		if(y & 1)
			ans = 1ll * ans * x % mod;

		x = 1ll * x * x % mod;
		y >>= 1;
	}

	return ans;
}

int main()
{
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	scanf("%d%d%d", &n, &k, &r);

	fac = 1;

	for (i = 1; i <= n * 2; i++)
		fac = 1ll * fac * i % mod;
	
	inv[n * 2] = power(fac, mod - 2);
	
	for (i = n * 2; i; i--)
		inv[i - 1] = 1ll * inv[i] * i % mod;

	for (i = 0; i <= 2 * n; i++)
		c[i] = 1ll * fac * inv[i] % mod * inv[2 * n - i] % mod;
		
	for (i = n, j = res = 1; ~i; i--)
	{
		while (j < k * (n - i) + n - 1)	
			res = 1ll * res * ++j % mod;
		
		c[i] = 1ll * c[i] * res % mod * inv[2 * n - 1] % mod;
	}

	for (i = res = 1; i <= n * k - n; i++)
		res = 1ll * res * i % mod;
	 
	res = power(res, mod - 2);

	for (i = 0, j = n * k - n; j >= 0; i++)
	{
		while (j > k * (n - i) - n)
			res = 1ll * res * j-- % mod;
		
		c[i] = 1ll * c[i] * res % mod;
	}

	for (i = 0; k * (n - i) - n >= 0; i++)
		ans = (ans + (i & 1 ? mod - c[i] : c[i])) % mod;

	printf("%lld", 1ll * (mod + 1 - power(1ll * ans * power(power(k, n * 2), mod - 2) % mod, r)) * power(2, mod - 2) % mod);
}
