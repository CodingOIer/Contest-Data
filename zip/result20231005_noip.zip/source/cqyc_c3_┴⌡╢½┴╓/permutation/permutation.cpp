#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 1005;
int f[N][N];
int n,K;

int main(){
    freopen("permutation.in","r",stdin);
    freopen("permutation.out","w",stdout);
    n = in,K = in;
    for(int k=1;k<=n;k++)
        f[0][k] = in;
    for(int k=1;k<=n;k++)
        f[1][k] = in;
    for(int k=2;k<=K;k++)
        for(int j=1;j<=n;j++)
            f[k][f[k-2][j]] = f[k-1][j];
    for(int k=1;k<=n;k++)
        out(f[K][k],' ');
    return 0;
}