#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
	struct{template<typename T>operator T(){
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0){
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;

const int N = 100005,mod = 998244353;
vector<pair<int,int>> g[N];
int val[N];
bool flag[N];
int n,K,q;


void dfs(int u){
	for(auto [v,w]:g[u]){
		if(val[v]==-1){
			val[v] = val[u]^w;
			dfs(v);
		}
		else if(val[v]!=(val[u]^w)){
			puts("0");
			exit(0);
		}
	}
}

signed main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n = in,K = in,q = in;
	int t = 1;
	for(int k=1;k<=K;k++)
		t = t*2%mod;
	for(int k=1;k<=q;k++){
		int l = in,r = in,s = in;
		g[l-1].emplace_back(r,s);
		g[r].emplace_back(l-1,s);
	}
	memset(val,-1,sizeof(val));
	val[0] = 0;
	dfs(0);
	int ans = 1;
	for(int k=1;k<=n;k++)
		if(val[k]==-1){
			val[k] = 0;
			ans = ans*t%mod;
			dfs(k);
		}
	out(ans);
	return 0;
}
