#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 400005;
vector<int> g[N],gk[N];
int n,m,q;

namespace ODtree{
    int dfn[N],low[N],idx;
    int stk[N],tp,nod;
    void dfs(int u,int father){
        dfn[u] = low[u] = ++idx;
        stk[++tp] = u;
        for(int v:g[u]){
            if(!dfn[v]){
                dfs(v,u);
                low[u] = min(low[u],low[v]);
                if(low[v]>=dfn[u]){
                    nod++;
                    do{
                        gk[stk[tp]].push_back(nod);
                        gk[nod].push_back(stk[tp--]);
                    }while(stk[tp+1]!=v);
                    gk[u].push_back(nod);
                    gk[nod].push_back(u);
                }
            }
            else if(v!=father)
                low[u] = min(low[u],dfn[v]);
        }
    }
    void build(){
        nod = n;
        dfs(1,0);

        // for(int k=1;k<=nod;k++)
        //     for(int j:gk[k])
        //         cerr << k << " " << j << endl;
    }
}

int fa[N],dep[N],siz[N],son[N],top[N],dfn[N],idx;
int sum[N],val[N];

void dfs1(int u){
    siz[u]++;
    for(int v:gk[u]){
        if(v==fa[u])
            continue;
        fa[v] = u;
        dep[v] = dep[u]+1;
        dfs1(v);
        siz[u] += siz[v];
        sum[u] += sum[v];
        if(siz[v]>siz[son[u]])
            son[u] = v;
    }
}

int vvl[N];
void dfs3(int u){
    for(int v:gk[u]){
        if(v==fa[u])
            continue;
        dfs3(v);
        if(u<=n)
            vvl[u] ^= sum[v];
    }
}

void dfs2(int u,int tp){
    dfn[u] = ++idx;
    top[u] = tp;
    if(son[u])
        dfs2(son[u],tp);
    for(int v:gk[u]){
        if(v==fa[u]||v==son[u])
            continue;
        dfs2(v,v);
        if(u<=n)
            val[dfn[u]] ^= sum[v];
        else
            val[dfn[u]] ^= vvl[v];
    }
}


int query(int x,int y){
    int ans = 0;
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]])
            swap(x,y);
        
        ans ^= val[dfn[x]]^val[dfn[top[x]]-1];
        if(son[x]){
            if(x<=n)
                ans ^= sum[son[x]];
            else
                ans ^= vvl[son[x]];
        }
        
        x = top[x];

        if(fa[x]<=n)
            ans ^= sum[x];
        else
            ans ^= vvl[x];

        x = fa[x];
    }
    if(dep[x]<dep[y])
        swap(x,y);
    
    ans ^= val[dfn[x]]^val[dfn[y]-1];

    if(son[x]){
        if(x<=n)
            ans ^= sum[son[x]];
        else
            ans ^= vvl[son[x]];
    }

    if(y<=n)
        ans ^= sum[1]-sum[y];
    else
        ans ^= vvl[fa[y]]^sum[y]^(sum[1]-sum[fa[y]]);

    return ans;
}


int main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    n = in,m = in;
    for(int k=1;k<=m;k++){
        int a = in,b = in;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    ODtree::build();
    for(int k=1;k<=n;k++)
        sum[k] = 1;
    dfs1(1);
    dfs3(1);
    dfs2(1,1);
    for(int k=1;k<=idx;k++)
        val[k] ^= val[k-1];
    int q = in;
    while(q--){
        int x = in,y = in;
        out(query(x,y),'\n');
    }
    return 0;
}

/*
建立圆方树
对圆方树预处理 树剖
    - 子树大小指原图中的点
    在重链上
        对于圆点 设轻边连接的某个子树大小为 s 权值为  所有 s 的异或和
        对于方点 设轻边连接的某个子树大小为 s 权值为  所有 (s-1) 的异或和
        对于重链尾要单独计算重链本身的贡献，算法一样。
    在轻边上
        轻边需要自己对消去父亲的贡献，同时计算儿子的贡献。
        算法和重链一样。
    对于 lca
        单独计算 lca 的父亲那颗子树的答案。
        算法和重链一样。
*/