#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 50000005,mod = 998244353;
int f[2][N];
int n,K,R;

int ksm(int a,int b){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

signed main(){
    freopen("dice.in","r",stdin);
    freopen("dice.out","w",stdout);
    n = in,K = in,R = in;
    int p = ksm(K,mod-2);
    int ans = 0,s = 1;
    while(R--){
        int o = 0;
        for(int k:{0,1})
            for(int j=0;j<=n*K;j++)
                f[k][j] = 0;
        f[o][0] = s;
        s = 0;
        for(int k=1;k<=n;k++){
            for(int j=1;j<=K;j++)
                for(int i=k-1;i<=(k-1)*K;i++)
                    f[o^1][i+j] = (f[o^1][i+j]+f[o][j]*p)%mod;
            o ^= 1;
        }
        for(int k=K;k<=n*K;k++)
            for(int j=K;j<=n*K;j++)
                if(k>j)
                    ans = (ans+f[o][k]*f[o][j])%mod;
                else if(k==j)
                    s = (s+f[o][k]*f[o][j])%mod;
    }
    out(ans);
    return 0;
}