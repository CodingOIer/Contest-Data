#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1005;
int n,k,A[N],B[N],C[N];
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int a=1;a<=n;a++) scanf("%d",&A[a]);
    for(int a=1;a<=n;a++) scanf("%d",&B[a]);
    for(int a=1;a<k;a++)
    {
    	for(int b=1;b<=n;b++) C[A[b]]=B[b];
    	for(int b=1;b<=n;b++) A[b]=B[b],B[b]=C[b];
	}
	for(int a=1;a<=n;a++) cout<<B[a]<<" ";
} 
