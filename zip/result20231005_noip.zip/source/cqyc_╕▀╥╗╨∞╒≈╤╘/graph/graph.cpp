#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5,M=6e5+5,V=6e5+5,E=1.2e6+5;
int n,m,q,e,head[N],nxt[M],to[M],rt,dfn[N],low[N],num,cut[N],cnt,new_id[N],dcc[N];
int e2,head2[V],to2[E],nxt2[E],Size[V],tots[V],tot[V],fa[V][21],dep[V];
vector<int> son[N];
stack<int> sta;
void add_edge(int x,int y)
{
	to[++e]=y;
	nxt[e]=head[x];
	head[x]=e;
}
void tarjan(int p,int f)
{
	dfn[p]=low[p]=++num;
	sta.push(p);
	int cnts=0;
	for(int a=head[p];a>0;a=nxt[a])
	{
		int s=to[a];
		if(s==f) continue;
		if(dfn[s]==0)
		{
			cnts++;
			tarjan(s,p);
			low[p]=min(low[p],low[s]);
			if(low[s]>=dfn[p]&&p!=rt) cut[p]=1;
			if(low[s]>=dfn[p])
			{
				int t;
				cnt++;
				do
				{
					t=sta.top();
					sta.pop();
					son[cnt].push_back(t);
					dcc[t]=cnt;
				//	cout<<t<<" ";
				}while(t!=s);
				dcc[p]=cnt;
				son[cnt].push_back(p);
			}
		}
		else low[p]=min(low[p],dfn[s]);
	}
	if(p==rt&&cnts>=2) cut[p]=1;
}
void add_edge2(int x,int y)
{
	to2[++e2]=y;
	nxt2[e2]=head2[x];
	head2[x]=e2;
}
void dfs1(int p,int f)
{
	if(p>cnt) Size[p]=1;
	else
	{
		for(int a=0;a<(int)son[p].size();a++)
		{
			int s=son[p][a];
			if(cut[s]==0) Size[p]++;
		}
	}
	for(int a=head2[p];a>0;a=nxt2[a])
	{
		int s=to2[a];
		if(s==f) continue;
		dfs1(s,p);
		Size[p]+=Size[s];
	}
//	cout<<p<<" "<<Size[p]<<endl;
}
void dfs2(int p,int f)
{
	dep[p]=dep[f]+1;
	fa[p][0]=f;
	for(int a=1;a<=20;a++) fa[p][a]=fa[fa[p][a-1]][a-1];
//	cout<<p<<" "<<tots[p]<<endl;
	for(int a=head2[p];a>0;a=nxt2[a])
	{
		int s=to2[a];
		if(s==f) continue;
		dfs2(s,p);
		tots[p]^=tot[s];
		if(p>cnt) tot[p]^=tot[s];
	}
	if(p<=cnt) tot[p]=Size[p];
}
void dfs3(int p,int f)
{
	tot[p]^=tot[f];
	tots[p]^=tots[f];
	for(int a=head2[p];a>0;a=nxt2[a])
	{
		int s=to2[a];
		if(s==f) continue;
		dfs3(s,p);
	}
}
int get_lca(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	for(int a=20;a>=0;a--)
	{
		if(dep[fa[x][a]]>=dep[y]) x=fa[x][a];
	}
	if(x==y) return y;
	for(int a=20;a>=0;a--)
	{
		if(fa[x][a]!=fa[y][a]) x=fa[x][a],y=fa[y][a];
	}
	return fa[x][0];
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int a=1;a<=m;a++)
    {
    	int x,y;
    	scanf("%d%d",&x,&y);
    	add_edge(x,y);
    	add_edge(y,x);
	}
	rt=1,tarjan(1,0);
	num=cnt;
	for(int a=1;a<=n;a++)
	{
		if(cut[a]==1) new_id[a]=++num;
	}
	for(int a=1;a<=cnt;a++)
	{
		for(int b=0;b<(int)son[a].size();b++)
		{
			int s=son[a][b];
		//	cout<<a<<" "<<s<<endl;
			if(cut[s]==1)
			{
			//	cout<<a<<" "<<new_id[s]<<endl;
				add_edge2(a,new_id[s]);
				add_edge2(new_id[s],a);
			}
		}
	}
	dfs1(1,0);
	dfs2(1,0);
	dfs3(1,0);
	scanf("%d",&q);
	while(q--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		if(cut[x]==1) x=new_id[x];
		else x=dcc[x];
		if(cut[y]==1) y=new_id[y];
		else y=dcc[y];
	//	cout<<x<<" "<<y<<endl;
		int l=get_lca(x,y);
		int ans=(tot[x]^tot[y]^tots[x]^tots[y]);
		ans^=(tots[l]^tots[fa[l][0]]);
	//	cout<<tot[l]<<endl;
	    if(l!=1)
	    {
	    	if(l<=cnt)
	    	{
	    		ans^=((n-Size[fa[l][0]])^tots[fa[l][0]]^tots[fa[l][1]]^tot[l]^tot[fa[l][0]]);
			}
			else ans^=(n-Size[l]);
		}
		printf("%d\n",ans);
	}
}
