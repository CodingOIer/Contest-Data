#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e7+5,M=2e7+5,mo=998244353;
int n,k,r,m,ans[N],jc[M],ny[M],p,Ans;
int ksm(int a,int b,int c)
{
	int ans=1;
	while(b>0)
	{
		if(b%2==1) ans=(ll)ans*a%c;
		a=(ll)a*a%c;
		b/=2;
	}
	return ans;
}
int get_C(int a,int b)
{
	if(a<b||a<0||b<0) return 0;
	return (ll)jc[a]*ny[b]%mo*ny[a-b]%mo;
}
int main()
{
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
    scanf("%d%d%d",&n,&k,&r);
    m=n*(k+1);
    jc[0]=1;
    for(int a=1;a<=2*n;a++)
    {
    	jc[a]=(ll)jc[a-1]*a%mo;
	}
	ny[2*n]=ksm(jc[2*n],mo-2,mo);
	for(int a=2*n-1;a>=0;a--)
	{
		ny[a]=(ll)(a+1)*ny[a+1]%mo;
	}
	int mx=0;
	for(int i=0;m-i*k>=2*n;i++)
	{
		mx=max(mx,i);
		if(i%2==0)
		{
			ans[i]=get_C(2*n,i);
		}
		else ans[i]=(-get_C(2*n,i)+mo)%mo;
	}
//	cout<<mx<<endl;
	int j=1;
//	cout<<"h";
	for(int a=0;a<=m;a++)
	{
		if((-a-1+m)%k==0)
		{
			//cout<<a+1-m<<" ";
			if((-a-1+m)/k>=0&&(-a-1+m)/k<=mx) ans[(-a-1+m)/k]=(ll)ans[(-a-1+m)/k]*j%mo;
		}
		if(a!=m) j=(ll)j*(a+1)%mo;
	}
//	cout<<"h";
	int y=ksm(j,mo-2,mo);
	if((-m+m-2*n)%k==0)
	{
		if((-m+m-2*n)/k>=0&&(-m+m-2*n)/k<=mx) ans[(-m+m-2*n)/k]=(ll)ans[(-m+m-2*n)/k]*y%mo;
	}
	for(int a=m-1;a>=0;a--)
	{
		y=(ll)(a+1)*y%mo;
		if((-a+m-2*n)%k==0)
		{
			if((-a+m-2*n)/k>=0&&(-a+m-2*n)/k<=mx) ans[(-a+m-2*n)/k]=(ll)ans[(-a+m-2*n)/k]*y%mo;
		}
	}
//	cout<<"h";
	for(int a=0;a<=mx;a++)
	{
		p=((ll)p+(ll)ans[a]*ny[2*n-1])%mo;
	}
	p=(ll)p*ksm(ksm(k,2*n,mo),mo-2,mo)%mo;
	int sum=(ll)(1-p+mo)*ksm(2,mo-2,mo)%mo;
	for(int a=1;a<=r;a++)
	{
		Ans=(Ans+sum)%mo;
		sum=(ll)sum*p%mo;
	}
	printf("%d",Ans);
} 
