#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
int n,k,m;
map<int,int> l[100011];
set<pair<int,int> > st;
int L,R,x;
long long ans = 1;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin >> n >> k >> m;
	for(int i = 1;i <= m;i++)
	{
		cin >> L >> R >> x;
		if(st.find({L,R}) != st.end())
		{
			if(l[R][L] != x)
			{
				cout << 0;
				return 0;
			}
		}
		l[R][L] = x;
		st.insert({L,R});
	}
	for(int i = n;i;i--)
	{
		if(l[i].empty())
		{
			(ans <<= (long long)k) %= mod;continue;
		}
		pair<int,int> p = *l[i].begin();
		int ls = p.first,lsv = p.second;
		for(auto y:l[i]) if(y.first != ls)
		{
			L = ls,R = y.first - 1,x = lsv ^ y.second;
			if(st.find({L,R}) != st.end())
			{
				if(l[R][L] != x)
				{
					cout << 0;
					return 0;
				}
			}
			l[R][L] = x;
			st.insert({L,R});
		}
	}
	cout << ans;
	return 0;
}
