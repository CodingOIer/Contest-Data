#include<bits/stdc++.h>
#define lowbit(x) ((x)&-(x))
using namespace std;
vector<int> v[100011];
int n,m,q;
int t[100011],Bgsn[100011],Siz[100011],upt[100011],deep[100011];
inline void add(int p,int val)
{
	while(p <= n)
	{
		t[p] += val;
		p += lowbit(p);
	}
}
inline int ask(int p)
{
	int res = 0;
	while(p)
	{
		res += t[p];
		p -= lowbit(p);
	}
	return res;
}
int dfn[100011],dui[100011],fa[100011],idx;
void DFS1(int p,int f)
{
	deep[p] = deep[f] + 1;
	fa[p] = f;
	Siz[p] = 1;
	for(auto i:v[p]) if(i != f)
	{
		DFS1(i,p);
		Siz[p] += Siz[i];
		if(Siz[i] > Siz[Bgsn[p]]) Bgsn[p] = i;
	}
}
void DFS2(int p,int upto)
{
	upt[p] = upto;
	dfn[p] = ++idx;
	dui[idx] = p;
	if(Bgsn[p]) DFS2(Bgsn[p],upto);
	for(auto i:v[p]) if(!dfn[i])
	{
		DFS2(i,i);
		add(dfn[p],Siz[i]);
	}
}
inline void Clac(int x,int y)
{
	long long ans = 0;
	int lx = 0,ly = 0;
	while(upt[x] != upt[y])
	{
		if(deep[upt[x]] < deep[upt[y]]) swap(x,y),swap(lx,ly);
		if(lx) ans ^= Siz[lx];
		lx = upt[x];
		ans ^= ask(dfn[x]) ^ ask(dfn[upt[x]] - 1);
		x = fa[upt[x]];
	}
	if(deep[x] > deep[y]) swap(x,y),swap(lx,ly);
	if(lx) ans ^= Siz[lx];
	if(ly) ans ^= Siz[ly];
	ans ^= ask(dfn[y]) ^ ask(dfn[x] - 1);
	cout << ans << "\n";
}
int x,y;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= m;i++)
	{
		cin >> x >> y;
		v[x].push_back(y),v[y].push_back(x);
	}
	DFS1(1,1);
	DFS2(1,1);
	cin >> q;
	while(q--)
	{
		cin >> x >> y;
		Clac(x,y);
	}
	return 0;
}
