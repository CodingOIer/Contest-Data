#include<bits/stdc++.h>
#define base 131
using namespace std;
int n,k;
int f[1011][1011],ans,c;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	cin >> n >> k;
	for(int i = 1;i <= n;i++) cin >> f[0][i];
	for(int i = 1;i <= n;i++) cin >> f[1][i];
	for(int i = 2;i <= k;i++)
		for(int j = 1;j <= n;j++)
			f[i][f[i - 2][j]] = f[i - 1][j];
	for(int i = 1;i <= n;i++) cout << f[k][i] << " ";
	return 0;
}
