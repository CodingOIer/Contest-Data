#include<bits/stdc++.h>
#define mod 998244353ll
using namespace std;
inline long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1)
			(res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}
int ex[60000011];
long long fac,pl;
inline long long Fac(int k)
{
	while(pl < k) (fac *= (++pl)) %= mod;
	return fac;
}
inline long long C(int n,int m)
{
	if(m > n) return 0;
	return Fac(n) * ex[m] % mod * ex[n - m] % mod;
}
long long fac2n;
inline long long C2(int n,int k)
{
	return fac2n * ex[k] % mod * ex[n - k] % mod;
}
int n,k,m;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	cin >> n >> m >> k;
	m--;
	ex[0] = 1;
	for(int i = 1;i <= n * m + 2 * n;i++) ex[i] = (long long)ex[i - 1] * i % mod;
	fac2n = ex[2 * n];
	ex[n * m + 2 * n] = qmi(ex[n * m + 2 * n],mod - 2);
	for(int i = n * m + 2 * n - 1;i >= 0;i--) ex[i] = (long long)ex[i + 1] * (i + 1) % mod;
	long long d = 0,w;
	fac = 1;
	for(int i = n,c = ((n & 1) ? -1 : 1);i >= 0;i--,c = -c)
		(d += (mod + C2(2 * n,i) * C(2 * n - 1 + n * m - i * (m + 1),2 * n - 1) % mod * c)) %= mod;
	(d *= qmi(qmi(m + 1,2 * n),mod - 2)) %= mod;
	w = (long long)(mod + 1 - d) * (mod + 1) / 2 % mod;
	long long ans = 0;
	for(long long t = 1,i = 1;i <= k;i++,(t *= d) %= mod)
		(ans += t * w) %= mod;
	cout << ans;
	cerr << clock();
	return 0;
}

