#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =5e7+5,M=1e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int n,k,r;
inline ll qp(ll a,ll b){
	if(!b)return 1;
	ll c=qp(a,b>>1);
	c=c*c%mod;
	if(b&1)c=c*a%mod;
	return c;
}
int dp[N];//sumС�ڵ���i�ĸ��� 
ll pos;
int main(){
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	n=read(),k=read(),r=read();
	ll inv=qp(qp(k,n),mod-2);
	dp[0]=1;
	rep(i,1,k)dp[i]=1;
	rep(i,1,n){
		per(j,i*k,i){
			if(j<k+1)dp[j]=dp[j-1];
			else dp[j]=(0LL+dp[j-1]-dp[j-k-1]+mod)%mod;
		}
		rep(j,0,i-1)dp[j]=0;
		rep(j,1,i*k)(dp[j]+=dp[j-1])%=mod;
		if(i^n)rep(j,i*k+1,(i+1)*k)dp[j]=dp[j-1];
	} 
	rep(i,n-1,n*k)dp[i]=1LL*dp[i]*inv%mod;
	rep(i,n,n*k)(pos+=1LL*(dp[i]-dp[i-1])*(dp[i]-dp[i-1])%mod)%=mod;
	ll now=pos,pj=pos;
	ll i2=qp(2,mod-2);
	pos=(1LL-pos+mod)%mod*i2%mod;
	ll sl=pos;
	rep(i,2,r){
		(pos+=now*sl%mod)%=mod;
		now=now*pj%mod;
	}
	pf(pos);	
	return 0;
}
