#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 3e5 + 1000;

int n, m, q;
int head[N], nxt[N << 1], to[N << 1], cnt;

void Add(int u, int v) {
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt;
}

int dfn[N], low[N], num, stk[N], tp;

vector<int> ve[N]; int id;

void tarjan(int u) {
    dfn[u] = low[u] = ++num, stk[++tp] = u;
    Eor(u) if (!dfn[to[i]]) {
        tarjan(to[i]), low[u] = min(low[u], low[to[i]]);
        if (dfn[u] <= low[to[i]]) { 
            ve[u].pb(++id);
            while (stk[tp + 1] != to[i]) 
                ve[id].pb(stk[tp--]);
        } 
    } else low[u] = min(low[u], dfn[to[i]]);
}

int val[N], siz[N], fa[22][N], g[22][N], h[22][N], dep[N];

void dfs(int u) {
    siz[u] = u <= n, dep[u] = dep[fa[0][u]] + 1;
    for (int v : ve[u]) {
        fa[0][v] = u, dfs(v), siz[u] += siz[v];
        if (u > n) val[u] ^= siz[v] - 1;
        else val[u] ^= siz[v];
    } g[0][u] = val[u], h[0][u] = siz[u] - (u <= n);
}

pii Lca(int u, int v) { int w = 0;
    if (dep[u] < dep[v]) swap(u, v);
    Rof(i, 20, 0) if (dep[fa[i][u]] >= dep[v])
        w ^= g[i][u] ^ h[i][u], u = fa[i][u];
    if (u == v) return pii(u, w ^ val[u]);
    Rof(i, 20, 0) if (fa[i][u] != fa[i][v]) {
        w ^= g[i][u] ^ g[i][v];
        w ^= h[i][u] ^ h[i][v];
        u = fa[i][u], v = fa[i][u];
    }
    return pii(fa[0][u], w ^ val[u] ^ val[v] ^ val[fa[0][u]] ^ h[0][u] ^ h[0][v]);
}
signed main() {
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);
    n = read(), m = read();
    For(i, 1, m) Add(read(), read());
    id = n, tarjan(1), dfs(1);

    // For(i, 1, id) {
    //     for (int v : ve[i]) cout << v <<" ";
    //     cout<<'\n';
    // }
    For(i, 1, id) cout << val[i] <<" " << siz[i] - (i > n) << '\n';

    For(i, 1, 20) For(j, 1, n) {
        fa[i][j] = fa[i - 1][fa[i - 1][j]];
        g[i][j] = g[i - 1][j] ^ g[i - 1][fa[i - 1][j]];
        h[i][j] = h[i - 1][j] ^ h[i - 1][fa[i - 1][j]];
    }
    q = read(); while (q--) {
        int u = read(), v = read(); 
        pii x = Lca(u, v); int lca = x.first, ans = x.second;
        cout << lca<<" "<<ans << '\n';
        cout << ans << " "<< (ans ^ (n - siz[u] - (u > n))) << '\n';
    }
	return 0;
}