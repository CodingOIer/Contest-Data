#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4,P=998244353;
int head[NN],ne[NN*2],e[NN*2],w[NN*2],idx=-1,val[NN];
bool flag[NN];
void add_edge(int u,int v,int l)
{
	e[++idx]=v;
	w[idx]=l;
	ne[idx]=head[u];
	head[u]=idx;
	e[++idx]=u;
	w[idx]=l;
	ne[idx]=head[v];
	head[v]=idx;
}
void dfs(int u)
{
	for(int i=head[u];~i;i=ne[i])
	{
		int v=e[i];
		if(val[v]==-1)
		{
			val[v]=val[u]^w[i];
			dfs(v);
		}
		else if(val[v]!=(val[u]^w[i]))
		{
			printf("0");
			exit(0);
		}
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	memset(head,-1,sizeof(head));
	int n,k,q,t=1;
	scanf("%d%d%d",&n,&k,&q);
	for(int i=1;i<=k;i++)
		t=2ll*t%P;
	for(int i=1;i<=q;i++)
	{
		int l,r,s;
		scanf("%d%d%d",&l,&r,&s);
		add_edge(l-1,r,s);
	}
	memset(val,-1,sizeof(val));
	val[0]=0;
	dfs(0);
	int ans=1;
	for(int i=1;i<=n;i++)
		if(val[i]==-1)
		{
			val[i]=0;
			ans=1ll*ans*t%P;
			dfs(i);
		}
	printf("%d",ans);
	return 0;
}
