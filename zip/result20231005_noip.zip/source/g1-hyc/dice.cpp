#include<bits/stdc++.h>
using namespace std;
const int NN=104,MM=1004,P=998244353;
int f[NN][NN*MM],s[NN][NN*MM];
int qmi(int a,int b)
{
	int res=1;
	while(b)
	{
		if(b&1)
			res=1ll*res*a%P;
		a=1ll*a*a%P;
		b>>=1;
	}
	return res;
}
int main()
{
	freopen("dice.in","r",stdin);
	freopen("dice.out","w",stdout);
	int n,k,r;
	scanf("%d%d%d",&n,&k,&r);
	for(int i=1;i<=k;i++)
	{
		f[1][i]=1;
		s[1][i]=(s[1][i-1]+f[1][i])%P;
	}
	for(int i=2;i<=n;i++)
		for(int j=1;j<=n*k;j++)
		{
			f[i][j]=(0ll+f[i][j]+s[i-1][j-1]-s[i-1][max(0,j-k-1)]+P)%P;
			s[i][j]=(s[i][j-1]+f[i][j])%P;
		}
	int res=0;
	for(int i=1;i<=n*k;i++)
		res=(res+1ll*f[n][i]*f[n][i]%P)%P;
	printf("%d",(1-qmi((1ll*(qmi(k,n*2ll%P)-res+P)%P*qmi(2,P-2)%P+res)%P*qmi(qmi(k,n*2ll%P),P-2)%P,r)+P)%P);
	return 0;
}
