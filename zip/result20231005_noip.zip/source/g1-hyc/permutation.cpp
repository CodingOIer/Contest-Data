#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("permutation.in","r",stdin);
	freopen("permutation.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	vector<int>a(n+1),b(n+1),c(n+1);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	for(int i=1;i<k;i++)
	{
		for(int j=1;j<=n;j++)
			c[a[j]]=b[j];
		swap(a,b);
		swap(b,c);
	}
	for(int i=1;i<=n;i++)
		printf("%d ",b[i]);
	return 0;
}
