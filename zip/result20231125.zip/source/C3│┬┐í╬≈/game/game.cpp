#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=5005,mod=998244353;
inline int read(){
   int s=0,f=1;char ch=getchar();
   while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
   while(ch>='0'&&ch<='9') s=s*10+ch-'0',ch=getchar();
   return s*f;
}
int m,k,n;
int ksm(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=(res*x)%mod;
		x=(x*x)%mod;
		y>>=1;
	}
	return res;
}
int dp[N][N],inv[N<<1];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	m=read(),k=read(),n=read();
	for(int i=1;i<=10000;i++) inv[i]=ksm(i,mod-2);
	dp[0][n]=1;
	printf("%lld",(n-1)*inv[n]%mod);
	return 0;
}
