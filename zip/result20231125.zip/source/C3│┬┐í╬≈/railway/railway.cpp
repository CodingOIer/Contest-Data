#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define fi first
#define sd second
using namespace std;
const int N=1005,M=50005,inf=1e10;
inline int read(){
   int s=0,f=1;char ch=getchar();
   while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
   while(ch>='0'&&ch<='9') s=s*10+ch-'0',ch=getchar();
   return s*f;
}
int n,m,a[M<<1];

struct Path{
	int to,val,id;
};
vector<Path> e[N],ex[N];

int dis[N];
bool vis[N];
void dij(){
	priority_queue<pii,vector< pii >,greater< pii > > Q;
	for(int i=1;i<=n;i++) dis[i]=inf;
	dis[1]=0;
	Q.push({0,1});
	while(!Q.empty()){
		int u=Q.top().sd;
		Q.pop();
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=0;i<e[u].size();i++){
			int v=e[u][i].to,w=e[u][i].val;
			if(dis[v]>dis[u]+w){
				dis[v]=dis[u]+w;
				Q.push({dis[v],v});
			}
		}
	}
}

bool opt[M];
void crt(){
	for(int i=1;i<=n;i++){
		for(int j=0;j<e[i].size();j++){
			int u=i,v=e[i][j].to,w=e[i][j].val,id=e[i][j].id;
			if(dis[v]==dis[u]+w){
				ex[u].push_back({v,w,id});	
				if(u==1) opt[id]=1;
			} 
		}
	}
}

struct Point{
	int st,u,id,sum;
};
int dp[N][M];
void solve(){
	queue<Point> Q;
	for(int i=1;i<=n;i++) vis[i]=0;
	for(int i=1;i<=m;i++) 
		if(opt[i]) Q.push({1,1,i,0});
	while(!Q.empty()){
	
		int stu=Q.front().st;
		int u=Q.front().u;
		int uid=Q.front().id;
		int sm=Q.front().sum;
		Q.pop();
		if(u==n){
			dp[n][uid]=max(dp[n][uid],dp[stu][uid]+sm*sm);
			continue;
		}
		for(int i=0;i<ex[u].size();i++){
			int v=ex[u][i].to,w=ex[u][i].val,vid=ex[u][i].id;
			if(uid==vid) Q.push({stu,v,uid,sm+w});
			else{
				dp[u][vid]=max(dp[u][vid],dp[stu][uid]+sm*sm);
				Q.push({u,v,vid,w});
			}
		}
	}
	int ans=0;
	for(int i=1;i<=m;i++) ans=max(ans,dp[n][i]);
	printf("%lld %lld",dis[n],ans);
}

signed main(){
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		int s=read();
		for(int j=1;j<=(s<<1|1);j++) a[j]=read();
		for(int j=2;j<(s<<1|1);j+=2) e[a[j-1]].push_back({a[j+1],a[j],i});
	}
	
	dij();
	crt();
	solve();
	
	return 0;
}
