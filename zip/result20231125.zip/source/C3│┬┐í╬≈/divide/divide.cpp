#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(){
   int s=0,f=1;char ch=getchar();
   while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
   while(ch>='0'&&ch<='9') s=s*10+ch-'0',ch=getchar();
   return s*f;
}
int T,n,m;
signed main(){
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	T=read();
	while(T--){
		n=read(),m=read();
		if(n==1){
			printf("-1\n");
			continue;
		}
		else if(n==2&&!(m&1)){
			printf("%lld %lld\n",m/2,m/2);
			continue;
		}
		else if(n==2&&(m&1)){
			int a=m/2,b=m/2+1;
			if(a<=(a^b)) printf("-1\n");
			else printf("%lld %lld\n",a,b);
			continue;
		}
		else if(n==3){
			bool can=0;
			for(int a=1;a<=20&&!can;a++){
				m-=a;
				for(int l=1;l<=20&&!can;l++){
					if((m-l)%2||m<=l) continue;
					int b=(m-l)/2,c=b+l;
					if((a^b^c)<min(a,min(b,c))){
						printf("%lld %lld %lld\n",a,b,c);
						can=1;
					}
				}
				m+=a;
			}
			if(!can) printf("-1\n");
			continue;
		}
	}
	return 0;
}
