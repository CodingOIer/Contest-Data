#include <bits/stdc++.h>
using namespace std;
#define int long long
int n;
int d[1200000], f[1200000];
vector<int> g;
vector<tuple<int, int, int>> e[1200000];
priority_queue<pair<int, int>> q;
unordered_map<int, int> v[1200000];
unordered_map<int, vector<pair<int, int>>> s[1200000];
int read()
{
    int x = 0;
    char c = getchar();
    while (isspace(c))
        c = getchar();
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
    return x;
}
signed main()
{
    freopen("railway.in", "r", stdin);
    freopen("railway.out", "w", stdout);
    n = read();
    for (int i = 0, m = read(); i < m; i++)
        for (int j = 0, k = read(), x = read(), y, z; j < k; j++)
            z = read(), e[x].emplace_back(y = read(), z, i), x = y;
    q.emplace(-1, 1);
    while (q.size())
    {
        auto [w, x] = q.top();
        q.pop();
        if (d[x])
            continue;
        g.push_back(x);
        d[x] = -w;
        for (auto [y, z, c] : e[x])
            q.emplace(w - z, y);
    }
    for (int x : g)
        for (auto [y, z, c] : e[x])
            if (d[x] + z == d[y])
            {
                s[x].count(c) ? s[y][c] = move(s[x][c]) : s[y][c] = {{0, f[x]}};
                v[y][c] = v[x][c] + z;
                int l = 0, r = s[y][c].size();
                while (l + 1 != r)
                    ((s[y][c][(l + r) / 2].second - s[y][c][(l + r) / 2 - 1].second) > (s[y][c][(l + r) / 2].first - s[y][c][(l + r) / 2 - 1].first) * v[y][c] * 2 ? l : r) = (l + r) / 2;
                f[y] = max(f[y], s[y][c][l].second - s[y][c][l].first * v[y][c] * 2 + v[y][c] * v[y][c]);
                while (s[y][c].size() > 1 && __int128_t(f[y] - s[y][c].back().second) * (s[y][c].back().first - s[y][c][s[y][c].size() - 2].first) > __int128_t(s[y][c].back().second - s[y][c][s[y][c].size() - 2].second) * (v[y][c] - s[y][c].back().first))
                    s[y][c].pop_back();
                s[y][c].emplace_back(v[y][c], f[y] + v[y][c] * v[y][c]);
            }
    printf("%lld %lld\n", d[n] - 1, f[n]);
    return 0;
}