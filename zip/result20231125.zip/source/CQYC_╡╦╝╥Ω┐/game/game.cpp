#include <bits/stdc++.h>
using namespace std;
const int P = 998244353;
int n, m, ans;
int f[6000];
int power(int x, int y)
{
    int res = 1;
    for (; y; x = 1ll * x * x % P, y /= 2)
        res = (y % 2 ? x : 1ll) * res % P;
    return res;
}
int main()
{
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    scanf("%d%*d%d", &m, &n);
    f[0] = 1;
    for (int i = 0; i < m; i++)
    {
        f[n] = 0;
        rotate(f, f + n, f + n + 1);
        for (int j = 0; j < n; j++)
            f[j + 1] = (f[j + 1] + 1ll * f[j] * (n - j) % P * power(n + m - i - j, P - 2)) % P,
                  f[j] = 1ll * f[j] * (m - i) % P * power(n + m - i - j, P - 2) % P;
        ans = (ans + f[n]) % P;
    }
    printf("%d\n", (P + 1 - ans) % P);
    return 0;
}