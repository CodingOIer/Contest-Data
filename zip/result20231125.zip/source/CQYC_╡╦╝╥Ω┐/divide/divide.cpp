#include <bits/stdc++.h>
using namespace std;
int t, n, m;
int main()
{
    freopen("divide.in", "r", stdin);
    freopen("divide.out", "w", stdout);
    for (scanf("%d", &t); t--; puts(""))
        if (scanf("%d%d", &n, &m); n % 2 && m % 2)
            if (n > 3)
                printf("-1"); // ...
            else if (n == 1 || m < 13 || m / 4 == 4)
                printf("-1");
            else
                printf("%d %d %d", (m / 4 * 2 - 2) + m / 2 % 2, ((m / 4 - 1) ^ 1) * 2 + m / 2 % 2, 7 - m / 4 * 2 % 4 * 2);
        else if (n % 2)
            if (m < n + 3 || n == 1 || (n == 3 && m == 8))
                printf("-1");
            else if (n > 3 && printf("1 2 3 "))
                for (int i = 3; i < n; i++)
                    printf("%d ", (i < 5) * (m - n - 3) / 2 + 1);
            else
                printf("%d %d %d", m / 2 - 1, (m / 2 - 1) ^ 1, 3 - m % 4);
        else if (m % 2)
            if (m > n * 2 && n > 2)
                for (int i = 0; i < n; i++)
                    printf("%d ", ((i < 2) * (m / 2 - n) + (i > 1 && i < 4) * m / 2 % 2 + 2) ^ !i);
            else
                printf(m & (m + 1) ? "%d %d" : "-1", m / 2, m / 2 + 1);
        else
            for (int i = 0; i < n; i++)
                printf("%d ", (i < 2) * (m - n) / 2 + 1);
    return 0;
}