#include<bits/stdc++.h>
using namespace std;
const int NN=3e5+4;
int ans[NN],n;
int solve2(int x)
{
	if(x<2)
		return 2e9;
	int a=0,b=0;
	for(int i=30;~i;i--)
		if(x>>i&1)
		{
			if((x&(1<<i+1)-1)==(1<<i+1)-1)
			{
				a|=(1<<i+1)-1;
				break;
			}
			a|=1<<i-1,b|=1<<i-1;
		}
	ans[1]=a,ans[2]=b;
	return a^b;
}
int calc_min()
{
	int minn=1e9;
	for(int i=1;i<=n;i++)
		minn=min(minn,ans[i]);
	return minn;
}
int solve3(int x)
{
	if(x<3)
		return 2e9;
	int a=0,b=0,c=0;
	for(c=1;c<=7;c++)
	{
		a=0,b=0;
		x--;
		int tmp=x;
		if(x<3)
			return 2e9;
		for(int i=30;~i;i--)
			if(tmp>>i&1)
			{
				if((tmp&(1<<i+1)-1)==(1<<i+1)-1)
				{
					if(!a)
						a|=(1<<i+1)-1;
					else
						b|=(1<<i+1)-1;
					break;
				}
				if(i>1&&(c>>i-1&1)&&!(tmp>>i-1&1))
				{
					if(!b)
						b|=1<<i-1;
					else
						a|=1<<i-1;
					tmp|=1<<i-1;
				}
				else
					a|=1<<i-1,b|=1<<i-1;
			}
		ans[1]=a,ans[2]=b,ans[3]=c;
		if((a^b^c)<calc_min())
			return a^b^c;
	}
	ans[1]=a,ans[2]=b,ans[3]=c;
	return a^b^c;
}
int main()
{
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int m;
		scanf("%d%d",&n,&m);
		if(n==1)
		{
			puts("-1");
			continue;
		}
		if(!(n%2))
		{
			int x=m;
			for(int i=3;i<=n;i++)
			{
				ans[i]=m%2+1;
				x-=ans[i];
			}
			if(solve2(x)>=calc_min())
			{
				if(n<=3)
				{
					puts("-1");
					continue;
				}
				ans[n]++,ans[n-1]++;
				x-=2;
				if(solve2(x)>=calc_min())
				{
					puts("-1");
					continue;
				}
			}
		}
		else
		{
			int x=m;
			for(int i=4;i<=n;i++)
			{
				ans[i]=m%2+1;
				x-=ans[i];
			}
			if(solve3(x)>=calc_min())
			{
				if(n<=3)
				{
					puts("-1");
					continue;
				}
				ans[n]++,ans[n-1]++;
				x-=2;
				if(solve3(x)>=calc_min())
				{
					puts("-1");
					continue;
				}
			}
		}
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		puts("");
	}
	return 0;
}
