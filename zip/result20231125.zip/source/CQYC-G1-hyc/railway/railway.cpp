#include<bits/stdc++.h>
using namespace std;
const int NN=1e6+4;
vector<pair<int,int> >g1[NN],g2[NN];
int d[NN],f[NN],du[NN];
bool vis[NN];
void dij(int s)
{
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >q;
	memset(d,0x3f,sizeof(d));
	d[s]=0;
	q.push({0,s});
	while(q.size())
	{
		int u=q.top().second;
		q.pop();
		if(vis[u])
			continue;
		vis[u]=true;
		for(int i=0;i<g1[u].size();i++)
		{
			int v=g1[u][i].first,w=g1[u][i].second;
			if(d[v]>d[u]+w)
			{
				d[v]=d[u]+w;
				q.push({d[v],v});
			}
		}
	}
}
int main()
{
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int s,u;
		scanf("%d%d",&s,&u);
		while(s--)
		{
			int w,v;
			scanf("%d%d",&w,&v);
			g1[u].push_back({v,w});
			u=v;
		}
	}
	dij(1);
	for(int i=1;i<=n;i++)
		for(int j=0;j<g1[i].size();j++)
		{
			int v=g1[i][j].first,w=g1[i][j].second;
			if(d[i]+w==d[v])
			{
				g2[i].push_back({v,w});
				du[v]++;
			}
		}
	queue<int>q;
	for(int i=1;i<=n;i++)
		if(du[i]==0)
			q.push(i);
	while(q.size())
	{
		int u=q.front();
		q.pop();
		for(int i=0;i<g2[u].size();i++)
		{
			int v=g2[u][i].first,w=g2[u][i].second;
			du[v]--;
			if(!du[v])
				q.push(v);
			f[v]=max(f[v],f[u]+w*w);
		}
	}
	printf("%d %d",d[n],f[n]);
	return 0;
}
