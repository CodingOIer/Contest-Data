#include<bits/stdc++.h>
#define ll long long
#define L t[x].l
#define R t[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=6e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353;
using namespace std;
int T,n,m;
inline bool check(int x){
    while(x){
        if(!(x&1))return 1;
        x>>=1;
    }
    return 0;
}
inline int getbit(int x){
    int ans=0;
    while(x)ans++,x>>=1;
    return ans;
}
inline int get1(int x){
    int ans=0;
    while(x)ans++,x-=x&-x;
    return ans;
}
int main(){
	freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        if(n==1){
            cout <<"-1\n";
            continue;
        }
        if(n%2==0&&m%2==0){
            rep(i,1,n-2)printf("1 ");
            printf("%d %d\n",(m-n)/2,(m-n)/2);
            continue;
        }
        if(n==2){
            if(!check(m)){
                cout << "-1\n";
                continue;
            }
            int ans=0,k=getbit(m);
            per(i,k-2,0){
                ans+=(1<<i);
                if(!((m>>i)&1))break;
            }
            cout <<ans<<" "<<m-ans<<'\n';
            continue;
        }
        if(n==3){
            if(m%2==0){
                if(m==4||m==8){
                    cout <<"-1\n";
                    continue;
                }
                if(get1(m)==1){
                    printf("%d %d %d\n",3,(m-3)/2,m-3-(m-3)/2);
                    continue;
                }
                int w=m/2;
                printf("%d %d %d\n",w,w&-w,w-(w&-w));
                continue;
            }
            if(m==3||m==5||m==7||m==9||m==11||m==17||m==19){
                cout <<"-1\n";
                continue;
            }
            int a,b,c;
            if(m%16==1)a=6,b=3;
            if(m%16==3)a=7,b=2;
            if(m%16==5)a=2,b=3;
            if(m%16==7)a=3,b=2;
            if(m%16==9)a=4,b=5;
            if(m%16==11)a=4,b=7;
            if(m%16==13)a=2,b=3;
            if(m%16==15)a=3,b=2;
            c=(b+m-a)/2;
            printf("%d %d %d\n",a,c,m-a-c);
            continue;
        }
    }
    return 0;
}