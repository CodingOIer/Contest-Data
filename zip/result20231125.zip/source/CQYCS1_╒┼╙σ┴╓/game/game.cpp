#include<bits/stdc++.h>
#define ll long long
#define L t[x].l
#define R t[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =5e3+5,M=6e5+5,inf=(1LL<<31)-1,mod=998244353;
const ll llf=1e18;
using namespace std;
int m,n,a[N];
inline void Add(int &a,int b){
    ((a+=b)>=mod) and (a-=mod);
}
inline int add(int a,int b){
    ((a+=b)>=mod) and (a-=mod);
    return a;
}
inline int mul(int a,int b){
    return 1LL*a*b%mod;
}
inline void Mul(int &a,int b){
    a=mul(a,b);
}
inline int qp(int a,int b){
    if(!b)return 1;
    int c=qp(a,b>>1);
    Mul(c,c);
    if(b&1)Mul(c,a);
    return c;
}
int inv[N<<2],ml[N<<2];
inline void prep(){
    ml[0]=1;
    rep(i,1,N*3-5)ml[i]=mul(ml[i-1],i);
    inv[N*3-5]=qp(ml[N*3-5],mod-2);
    per(i,N*3-6,0)inv[i]=mul(inv[i+1],i+1);
}
inline int iv(int x){
    if(x==0)return 0;
    return mul(ml[x-1],inv[x]);
}
inline int C(int x,int y){
    if(x<0||y<0||x<y)return 0;
    return mul(ml[x],mul(inv[y],inv[x-y]));
}
inline int A(int x,int y){
    if(x<0||y<0||x<y)return 0;
    return mul(C(x,y),ml[y]);
}
inline void red(int &a,int b){
    ((a-=b-mod)>=mod) and (a-=mod);
}
int dp[N][N],s,f[N][N],ans,g[N][2];//i 个 b,j 个 a，dp:b走，f:a走
int main(){
	freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    m=read(),n=read(),prep();
    rep(i,1,n)a[i]=read(),s+=a[i];
    dp[m][s]=1;
    per(i,m,1)per(j,s,1){
        Add(f[i][j-1],dp[i][j]);
        Add(dp[i-1][j],mul(f[i][j],mul(i,iv(i+j))));
        Add(f[i][j-1],mul(f[i][j],mul(j,iv(i+j))));
    }
    if(n==1){
        rep(i,1,s)Add(ans,dp[0][i]);
        pf(ans);
        return 0;
    }
    g[0][0]=1;
    rep(i,1,n){
        per(j,s,a[i])Add(g[j][0],g[j-a[i]][1]),Add(g[j][1],g[j-a[i]][0]);
    }
    //1:+ 2:-
    rep(i,0,s){
        int del=s-i,tot=qp(A(s,del),mod-2),los,cnt=0;
        rep(j,1,del){
            los=mul(A(j,j),mul(C(s-j,del-j),mul(ml[del],inv[j])));
            Add(cnt,mul(g[j][1],los));
            red(cnt,mul(g[j][0],los));
        }
        cnt=(A(s,del)-cnt+mod)%mod;
        Mul(cnt,tot);
        Add(ans,mul(cnt,dp[0][i]));
    }
    pf(ans);
    return 0;
}