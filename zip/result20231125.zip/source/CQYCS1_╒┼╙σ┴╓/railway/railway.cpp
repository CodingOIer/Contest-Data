#include<bits/stdc++.h>
#define ll long long
#define L t[x].l
#define R t[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define OK Ll<=l&&r<=Rr
#define Root 1,1,n
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e6+5,M=6e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7;
using namespace std;
int n,m,h[N],to[N],nxt[N],w[N],cnt;
inline void add(int a,int b,int c){
    to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,w[cnt]=c;
}
struct node{
    int x,d;
    bool friend operator <(node a,node b){
        return a.d>b.d;
    }
};
int dis[N];
bool vis[N];
inline void dijk(){
    rep(i,1,n)dis[i]=inf;
    dis[1]=0;
    priority_queue<node>q;
    q.push({1,0});
    while(!q.empty()){
        int x=q.top().x;q.pop();
        if(vis[x])continue;
        vis[x]=1;
        e(x)if(dis[y]>dis[x]+w[i]){
            dis[y]=dis[x]+w[i],q.push({y,dis[y]});
        }
    }
}
vector<Pi >p[N];
ll dp[N];
int rd[N];
inline void Dp(){
    queue<int>q;
    q.push(1);
    rep(i,1,n)dp[i]=-llf;
    dp[1]=0;
    while(!q.empty()){
        int x=q.front();q.pop();
        E(x){
            rd[y.first]--;
            dp[y.first]=max(dp[y.first],dp[x]+y.second*y.second);
            if(rd[y.first]==0)q.push(y.first);
        }
    }
}
int st[N];
vector<Pi >ed[N];
int main(){
	freopen("railway.in","r",stdin);
    freopen("railway.out","w",stdout);
    n=read(),m=read();
    rep(i,1,m){
        int k=read(),x=read();
        st[i]=x;
        for(int j=1,y,w;j<=k;j++)w=read(),y=read(),add(x,y,w),x=y,ed[i].pb({y,w});
    }
    dijk();
    rep(i,1,m){
        vector<int>P;
        int nx=st[i];P.pb(nx);
        for(auto nw:ed[i]){
            int y=nw.first,w=nw.second;
            if(dis[y]==dis[nx]+w){
                for(auto z:P)p[z].pb({y,dis[y]-dis[z]}),rd[y]++;
            }else P.clear();
            P.pb(y);
            nx=y;
        }
    }
    Dp();
    cout <<dis[n]<<" "<<dp[n];
    return 0;
}