#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n,m;
int cnt,s[105];
int f[300005];
signed main(){
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld %lld",&n,&m);
		cnt=0;
		if(n==1){
			printf("-1\n");
			continue;
		}
		if(!(n&1)&&!(m&1)){
			for(int i=1;i<=n-2;i++){
				printf("1 ");
				m--;
			}
			printf("%lld %lld\n",m/2,m/2);
			continue;
		}
		if(n==2&&(m&1)){
			int mm=m;
			bool z=0;
			while(mm){
				s[cnt]=(mm&1);
				if(s[cnt]==0) z=1;
				cnt++;
				mm>>=1;
			}
			if(z==0) printf("-1\n");
			else{
				int a=0;
				bool p=0;
				for(int i=cnt-2;i>=0;i--){
					if(s[i]==1) a+=(1<<i);
					else if(!p) a+=(1<<i),p=1;
				}
				printf("%lld %lld\n",a,m-a);
			}
			continue;
		}
	}
	return 0;
} 
