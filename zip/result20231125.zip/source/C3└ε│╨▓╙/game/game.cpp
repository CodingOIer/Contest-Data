#include<bits/stdc++.h>
#define int long long
using namespace std;
int m,k,a[5005];
int f[5005][5005];
int sum,ans;
const int mod=998244353;
int Pow(int x,int y){
	x%=mod;
	int z=1;
	while(y){
		if(y&1) z=z*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return z;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld",&m,&k);
	for(int i=1;i<=k;i++) scanf("%lld",&a[i]),sum+=a[i];
	if(k==1){
		for(int i=1;i<=a[1]-m;i++) f[0][i]=1;
		for(int i=1;i<=m;i++){
			for(int j=k;j<=a[1];j++){
				int s=1;
				for(int w=0;w<j-1;w++){
					f[i][j]+=f[i-1][j-1-w]*s%mod*i%mod*Pow(i+j-1-w,mod-2)%mod;
					f[i][j]%=mod;
					s=s*(j-1-w)%mod*Pow(i+j-1-w,mod-2)%mod;
				}
			}
		}
	}
	printf("%lld",f[m][a[1]]);
	return 0;
} 
