#include<bits/stdc++.h>
#define int long long
#define N 1000005
using namespace std;
int n,m;
int tot,head[N],nxt[N],to[N],val[N];
int p[1005][1005];
int in[N];
int e[N],t[N];
int d[N];
bool vis[N];
vector<pair<int,int> > h[N];
void add(int u,int v,int w){
	nxt[++tot]=head[u];
	to[tot]=v;
	val[tot]=w;
	head[u]=tot;
}
void dij(){
	for(int i=1;i<=n;i++) d[i]=1e16,vis[i]=0;
	d[1]=0;
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > q;
	q.push({0,1});
	while(!q.empty()){
		int x=q.top().second;
		q.pop();
		if(vis[x]) continue;
		vis[x]=1;
		for(int i=head[x];i;i=nxt[i]){
			if(!vis[to[i]]&&d[x]+val[i]<d[to[i]]){
				d[to[i]]=d[x]+val[i];
				q.push({d[x]+val[i],to[i]});
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=head[i];j;j=nxt[j]){
			if(d[i]+val[j]==d[to[j]]){
				h[i].push_back({to[j],val[j]*val[j]});
				in[to[j]]++;
			}
		}
	}
}
void Work(){
	queue<int> q;
	for(int i=1;i<=n;i++) d[i]=0;
	q.push(1);
	while(!q.empty()){
		int x=q.front();
		q.pop();
		for(int i=0;i<h[x].size();i++){
			int v=h[x][i].first,w=h[x][i].second;
			d[v]=max(d[v],d[x]+w);
			in[v]--;
			if(in[v]==0) q.push(v);
		}
	}
}
signed main(){
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) p[i][j]=1e16;
	}
	for(int i=1;i<=m;i++){
		int s;
		scanf("%lld %lld",&s,&e[1]);
		for(int j=2;j<=s+1;j++) scanf("%lld %lld",&t[j],&e[j]),t[j]+=t[j-1];
		for(int j=1;j<=s+1;j++){
			for(int r=j+1;r<=s+1;r++){
				p[e[j]][e[r]]=min(p[e[j]][e[r]],t[r]-t[j]);
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(p[i][j]!=1e16) add(i,j,p[i][j]);
		}
	}
	dij();
	printf("%lld ",d[n]);
	Work();
	printf("%lld",d[n]);
	return 0;
} 
