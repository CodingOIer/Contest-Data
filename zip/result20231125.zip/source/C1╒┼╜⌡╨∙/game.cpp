#include <bits/stdc++.h>
using namespace std;

int f[5001][5001][2], invl[20001];
int a, b;
const int p = 998244353;
int dfs(int a, int b, bool who) { // who = 1 -> B, who = 0 -> A
	// ����ֵ�� A ����ʤ���� 
	if (a == 0) {
		return 0;
	}
	if (b == 0) return 1;
	if (f[a][b][who] != -1) return f[a][b][who];
	if (who == 1) {
		return f[a][b][who] = dfs(a - 1, b, who ^ 1);
	} else {
		int tmp = invl[a + b];
		return f[a][b][who] = (1ll * dfs(a - 1, b, who) * tmp % p * a + 1ll * dfs(a, b - 1, who ^ 1) * tmp % p * b) % p;
		// ����ʱ�����������ģ��� a/(a+b) �ĸ���ѡ���Լ����� b/(a+b) �ĸ���ѡ�� B �� 
	}
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int tmp;
	scanf("%d%d%d", &b, &tmp, &a);
	if (b > 5000 || a > 5000 || tmp > 1) return puts("0"), 0;
	memset(f, 255 ,sizeof(f));
	invl[1] = 1;
	for (int i = 2; i <= 20000; ++i) {
		invl[i] = 1ll * (p - p / i) * invl[p % i] % p;
	}
	printf("%d\n", (1ll * dfs(a, b, 1) + p) % p);
}/*
2000 5000 ->757796617
741202878

20pts
*/
