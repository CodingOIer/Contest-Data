#include <bits/stdc++.h>
using namespace std;

int t, n, m;

void solve() {
	scanf("%d%d", &n, &m);
	if (n == 1) {
		printf("-1\n");
	} else if (n == 2) {
		if (m % 2 == 0) {
			printf("%d %d\n", m / 2, m / 2);
		} else {
			if (m & (m + 1)) {
				printf("%d %d\n", m / 2, m / 2 + 1);
			} else printf("-1\n"); 
		}
	} else if (n % 2 == 0 && m % 2 == 0) {
		if (n == m) {
			for (int i = 1; i <= n; ++i) printf("1%c", " \n"[i == n]);
			return;
		}
		for (int i = 1; i <= n - 2; ++i) printf("1 ");
		printf("%d %d\n", (m - n + 2) / 2, (m - n + 2) / 2);
	} else if (n == 3 && m % 2 == 0) {
		if ((m & (m - 1)) == 0) {
			if (m == 4 || m == 8) printf("-1\n");
			else {
				int a = m / 2 - 1;
				int b = m / 2 - 2;
				int c = 3;
				printf("%d %d %d\n", a, b, c);
			}
		} else {
			int tmp = m / 2;
			int a = tmp;
			int b = tmp & (-tmp);
			int c = tmp - b;
			printf("%d %d %d\n", a, b, c);
		}
	}
}
int main() {
	freopen("divide.out", "w", stdout);
	freopen("divide.in", "r", stdin);
	scanf("%d", &t);
	while (t--) {
		solve();
	}
	return 0;
}
/*
4pts~36pts?
  _________
 /        | 4
v 3   3(1)| 5    10
1 -> 2 -> 3 -> 5 -> 4
      y____________/
           2
           

*/
