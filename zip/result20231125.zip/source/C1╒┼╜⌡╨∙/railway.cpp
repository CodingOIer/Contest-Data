#include <bits/stdc++.h>
using namespace std;

struct Edge {
	int node;
	long long w, sw;
	bool operator < (const Edge &e) const {
		if (w != e.w) return w < e.w;
		if (sw != e.sw) return sw < e.sw;
		return node < e.node;
	}
};
vector<Edge> edges[1213];
int n, m, a, b, w;
set<Edge> q;
pair<long long, long long> d[1233];
void dij() {
	d[1] = {0, 0};
	q.insert({1, 0, 0});
	for (int i = 2; i <= n; ++i) {
		d[i] = {1ll << 60, 1ll << 60};
		q.insert({i, d[i].first, d[i].second});
	}
	while (!q.empty()) {
		Edge fx = *(q.begin());
		q.erase(q.begin());
		for (auto i : edges[fx.node]) {
			if (make_pair(d[fx.node].first + i.w, d[fx.node].second + i.sw) < d[i.node]) {
				q.erase({i.node, d[i.node].first, d[i.node].second});
				d[i.node] = {d[fx.node].first + i.w, d[fx.node].second + i.sw}; 
				q.insert({i.node, d[i.node].first, d[i.node].second});
			}
		}
	}
}

int main() {
	freopen("railway.in", "r", stdin);
	freopen("railway.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) {
		int tot, last, w, x;
		scanf("%d%d", &tot, &last); 
		for (int i = 1; i <= tot; ++i) {
			scanf("%d%d", &w, &x);
			edges[last].push_back({x, w, -1ll * w * w});
			last = x;
		}
	}
	dij();
	printf("%lld %lld\n", d[n].first, -d[n].second);
}
