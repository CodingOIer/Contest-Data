#include <bits/stdc++.h>
#define ll long long
using namespace std;

/*
20 �� 
*/

const ll Maxn=1e6+7,inf=1e12;
ll t,m,s[Maxn],dis[Maxn];



vector<pair<ll,ll> >e[Maxn],path[Maxn];
ll deg[Maxn],f[Maxn];
bool vis[Maxn];

struct node{
	ll u,val;
	inline friend bool operator <(const node x,const node y){
		return x.val>y.val;
	}
};

inline void Dijkstra(){
	for(ll i=1;i<=t;i++) dis[i]=inf;
	dis[1]=0;
	priority_queue<node>q;
	q.push((node){1,0});
	while(!q.empty()){
		node tp=q.top();
		q.pop();
		if(vis[tp.u]) continue;
		vis[tp.u]=1;
		for(auto i:e[tp.u]){
			ll v=i.first,w=i.second;
			if(dis[tp.u]+w<dis[v]){
				dis[v]=dis[tp.u]+w;
				q.push((node){v,dis[v]});
			}
		}
	}
	
	printf("%lld ",dis[t]);
	
	q.push((node){1,0});
	memset(vis,0,sizeof vis);
	while(!q.empty()){
		node tp=q.top();
		q.pop();
		if(vis[tp.u]) continue;
		vis[tp.u]=1;
		for(auto i:e[tp.u]){
			ll v=i.first,w=i.second;
			if(dis[tp.u]+w==dis[v]){
				path[tp.u].emplace_back(v,w);
				deg[v]++;
				q.push((node){v,dis[v]});
			}
		}
	}
	
}
inline void solve(){
	queue<ll>q;
	for(ll i=1;i<=t;i++) if(!deg[i]) q.push(i);
	
	while(!q.empty()){
		ll u=q.front();
		q.pop();
		for(auto i:path[u]){
			ll v=i.first,w=i.second;
			deg[v]--;
			f[v]=max(f[v],f[u]+w*w);
			if(!deg[v]) q.push(v);
		}
	}
	
	printf("%lld",f[t]);
}

int main(){
	freopen("raliway.in","r",stdin);
	freopen("railway.out","w",stdout);
	scanf("%lld%lld",&t,&m);
	for(ll i=1;i<=m;i++){
		scanf("%lld",&s[i]);
		for(ll j=1,x,lst=0,c=0;j<=2*s[i]+1;j++){
			scanf("%lld",&x);
			if(j&1){
				if(lst!=0) e[lst].emplace_back(x,c); 
				lst=x;
			}
			else{
				c=x;
			} 
		}
	}
	
	Dijkstra();
	solve();
	
	
	return 0;
}
/*
2 1
1 1 3 2
*/


