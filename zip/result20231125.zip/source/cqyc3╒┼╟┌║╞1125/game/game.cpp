#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Mod=998244353;
const ll Maxn=5010;
ll m,k,a[Maxn],ans;

inline ll ksm(ll a,ll b,ll mod){
	ll z=1;
	while(b){
		if(b&1) z=z*a%Mod;
		a=a*a%Mod;
		b>>=1;
	}
	return z;
}
inline ll Inv(ll a,ll mod){
	return ksm(a,mod-2,mod);
}
inline ll up(ll a){
	return (a%Mod+Mod)%Mod;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld",&m,&k);
	for(ll i=1;i<=k;i++) scanf("%lld",&a[i]);
	
	ll x=up(ksm(m,a[1]-1,Mod)+a[1]-m-(m&1)),y=up(ksm(m,a[1],Mod)+a[1]-m+(a[1]&1));
	ans=x*Inv(y,Mod)%Mod;
	
	printf("%lld",ans%Mod);
	
	return 0;
}

/*
1
1
4

3/4

2
1
5

19/36
*/
