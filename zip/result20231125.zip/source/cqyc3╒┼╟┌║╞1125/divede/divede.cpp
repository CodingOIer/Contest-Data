#include <bits/stdc++.h>
#define ll long long
using namespace std;

ll T,n,m;

/*
���������г��ֵĲ�ͬ�����ֻ�� 5 ������� 3 ��С�ģ�2 ����� 
*/

int main(){
	freopen("divide.in","r",stdin);
	freopen("divede.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld%lld",&n,&m);
	
		if(n==1){
			printf("-1\n");
		}
		else if(n==2){
			ll x=m/2,y=m-x;
			ll cx=0,cy=0;
			while(x) x/=2,cx++;
			while(y) y/=2,cy++;
			if(cx==cy) printf("%lld %lld\n",m/2,m-m/2);
			else printf("-1\n");
		}
		else if(n==3){
			bool flg=0;
			for(ll i=1;i<=10&&!flg;i++){
				ll b=(m-i)/2;
				for(ll j=-4;j<=-1&&!flg;j++){
					ll x=m-i-b-j,y=m-i-x;
					if(x<=0||y<=0) continue;
					if((x^y^i)<min(min(i,x),y)){
						flg=1;
						printf("%lld %lld %lld\n",i,x,y);
					}
				}
			}
			if(!flg){
				printf("-1\n");
			}
		}
		else{
			if(n%2==0&&m%2==0){
				for(ll i=1;i<=n-2;i++) printf("1 ");
				m-=(n-2);
				printf("%lld %lld\n",m/2,m/2);
			}
			else if(n%2==0){
				if(m<(n-3)*2+3+3){
					printf("-1\n");
					continue;
				}
				for(ll i=1;i<=n-3;i++) printf("2 ");
				m-=((n-3)*2+3);
				printf("3 ");
				printf("%lld %lld\n",m/2,m/2);
			}
			else if(m%2==0){ 
				if(m<n+1+2){
					printf("-1\n");
					continue;
				}
				for(ll i=1;i<=n-4;i++) printf("1 ");
				m-=(n+1);
				printf("2 3 ");
				printf("%lld %lld\n",m/2,m/2);
			}
			else{
				if(m<(n-4)*2+3+3){
					printf("-1\n");
					continue;
				}
				for(ll i=1;i<=n-4;i++) printf("2 ");
				printf("3 ");
				m-=((n-4)*2+3);
				ll x=m/2;
				printf("%lld %lld %lld\n",x,(x&-x),x-(x&-x));
			}
		}
	}
	return 0;
}

/*

1
21 256628388


5944
2 3
2 5
2 7
2 9
2 15
2 31
2 33554431
2 536870911

5873
3 3
3 5
3 7
3 9
3 11 
3 13 
3 15 
3 17
3 19
3 21
3 23
3 25
3 27
3 29
3 31
3 33
3 35
3 37
3 39
3 536870913
3 536870915
3 536870911 

100000
3 4
3 6 
3 8 
3 10 
3 12 
3 14 
3 16 
3 18 
3 20 
3 22 
3 24 
3 26 
3 28 
3 30 
3 32
3 536870912
3 536870914
3 3
3 5
3 7
3 9
3 11 
3 13 
3 15 
3 17
3 19
3 21
3 23
3 25
3 27
3 29
3 31
3 33
3 35
3 37
3 39

*/

