#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 10005,mod = 998244353;
int fac[N],inv[N],Inv[N];
int f[N][N],g[N][N],t[N][2];
int a[N];
int n,m;

int C(int a,int b){
    if(a<0||b<0||b>a)
        return 0;
    return fac[a]*inv[b]%mod*inv[a-b]%mod;
}

int A(int a,int b){
    if(a<0||b<0||b>a)
        return 0;
    return fac[a]*inv[a-b]%mod;
}

int ksm(int a,int b){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    inv[0] = fac[0] = 1;
    for(int k=1;k<N;k++)
        fac[k] = fac[k-1]*k%mod;  
    inv[N-1] = ksm(fac[N-1],mod-2);
    for(int k=N-2;k;k--)
        inv[k] = inv[k+1]*(k+1)%mod;
    for(int k=1;k<N;k++)
        Inv[k] = inv[k]*fac[k-1]%mod;

    m = in,n = in;
    int s = 0;
    for(int k=1;k<=n;k++)
        s += a[k] = in;
    g[m][s] = 1;
    for(int k=m;k;k--)
        for(int j=s;j;j--){
            f[k][j-1] = (f[k-1][j]+g[k][j])%mod;
            g[k-1][j] = (g[k-1][j]+(f[k][j]*Inv[k+j]%mod*k))%mod;
            f[k][j-1] = (f[k][j-1]+(f[k][j]*Inv[k+j]%mod*j))%mod;
        }
    t[0][0] = 1;
    for(int k=1;k<=n;k++)
        for(int j=s;j>=a[k];j--){
            t[j][0] = (t[j][0]+t[j-a[k]][1])%mod;
            t[j][1] = (t[j][1]+t[j-a[k]][0])%mod;
        }
    int ans = 0;
    for(int k=0;k<=s;k++){
        int cnt = 0;
        for(int j=1;j+k<=s;j++){
            int w = fac[j]*C(s-j,s-k-j)%mod*fac[s-k]%mod*inv[j]%mod;
            cnt = (cnt-t[j][0]*w%mod+t[j][1]*w%mod+mod)%mod;
        }
        cnt = (A(s,s-k)-cnt+mod)%mod*ksm(A(s,s-k),mod-2)%mod;
        ans = (ans+cnt*g[0][k])%mod;
    }
    out(ans);
    return 0;
}