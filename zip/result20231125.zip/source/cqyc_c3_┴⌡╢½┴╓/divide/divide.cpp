#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    int t = in;
    while(t--){
        int n = in,m = in;
        if(n==1){
            puts("-1");
            continue;
        }
        if(n%2==0&&m%2==0){
            int v = m/n;
            for(int k=m%n;k;k--)
                out(v+1,' ');
            for(int k=n-m%n;k;k--)
                out(v,' ');
            putchar('\n');
            continue;
        }
        puts("-1");
    }
    return 0;
}