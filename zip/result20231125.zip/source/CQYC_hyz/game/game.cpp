#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e4 + 10;

int n, m, ans, sum;
int fac[N], inv[N], f[N], g[N], h[N];

int C(int x, int y) { return (y > x or y < 0) ? 0 : 1ll * fac[x] * inv[y] % mod * inv[x - y] % mod; }

void init() {
    fac[0] = 1;
    for(int i = 1; i < N; i++) fac[i] = 1ll * fac[i - 1] * i % mod;
    inv[N - 1] = q_pow(fac[N - 1], mod - 2);
    for(int i = N - 1; i; i--) inv[i - 1] = 1ll * inv[i] * i % mod;
}

bool edmer;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), f[0] = 1, init();
    
    for(int i = 1; i <= m; i++) {
        int x = read();
        for(int j = 0; j <= sum; j++) for(int k = 0; k < x; k++)
            inc(g[j + k], 1ll * f[j] * C(x, k) % mod);
        sum += x;
        for(int j = 0; j <= sum; j++) f[j] = g[j], g[j] = 0;
    }

    h[0] = 1;

    for(int i = 1; i <= n; i++) {
        int tot = 0;
        for(int j = i - 1; j <= sum; j++) {
            int val = h[j]; h[j] = 1ll * tot * (n - i + sum - j) % mod;
            inc(tot, 1ll * val * inv[sum - j] % mod * fac[sum - j - 1] % mod);
        }
    }

    for(int i = n; i <= sum; i++) {
        int val = 1ll * f[i] * fac[i] % mod * h[i] % mod * fac[n] % mod;
        mul(val, 1ll * inv[n + sum - 1] % mod * fac[sum - i - 1] % mod);
        inc(ans, val);
    }

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 