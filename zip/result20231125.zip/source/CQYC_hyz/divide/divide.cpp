#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e5 + 10;

int n, m;

namespace sub1 {
    int s[N];

    void update(int l, int r, int x) {
        s[l] += x;
        if(r <= n) s[r] -= x;
        else l = 0, r %= n, s[l] += x, s[r] -= x;
    }

    void main() {
        for(int i = 0; i < n; i++) s[i] = 0;
        int l = 0, now = 0, r, x;
        for(int i = 30; i + 1; i--) {
            now = (now << 1) + (m >> i & 1);
            if((now << 1) >= n or !i) {
                int len = min(n - (n & 1), now);
                r = l + len, x = 1 << i;
                update(l, r, x), l = r % n, now -= len;
            }
        }
        if(now) return puts("-1"), void();

        for(int i = 1; i < n; i++) s[i] += s[i - 1];
        for(int i = 0; i < n; i++) if(!s[i]) return puts("-1"), void();
        for(int i = 0; i < n; i++) write(s[i]), putchar(' '); putchar('\n');
    }
}

void solve() {
    n = read(), m = read();
    if(n == 1) return puts("-1"), void();
    if(n == 2 and !(m & 1)) {
        write(m / 2), putchar(' '), write(m / 2), putchar('\n');
        return;
    }
    if(n == 2 and (m & 1)) {
        int x = m / 2, y = m - x;
        if((x ^ y) >= min(x, y)) puts("-1");
        else write(x), putchar(' '), write(y), putchar('\n');
        return;
    }
    // if(n == 3 and !(m & 1)) {
    //     int x = 0, y = m / 2, z = m / 2;
    //     x = y & -y, y -= x;
    //     if((x ^ y ^ z) >= min({ x, y, z }) or !x or !y) puts("-1");
    //     else {
    //         write(x), putchar(' ');
    //         write(y), putchar(' ');
    //         write(z), putchar('\n');
    //     }
    //     return;
    // }
    // if(n == 3 and (m & 1)) {
    //     int x = 1, y = m / 2, z = m / 2;
    //     if(y & 1) {
    //         x += (y - 1) & (1 - y);
    //         y -= x - 1;
    //     }
    //     else x += y & -y, y -= y & -y;
        
    //     if((x ^ y ^ z) >= min({ x, y, z }) or !x or !y) puts("-1");
    //     else {
    //         write(x), putchar(' ');
    //         write(y), putchar(' ');
    //         write(z), putchar('\n');
    //     }
    //     return;
    // }
    sub1 :: main();
}

bool edmer;
signed main() {
	freopen("divide.in", "r", stdin);
	freopen("divide.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 