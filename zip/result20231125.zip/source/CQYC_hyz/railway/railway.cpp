#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e6 + 10, inf = 1e18;

int n, m, cnt;
int tag[N], d[N], pw[N];

struct edge {
    int v, w, x, y;
};

struct node {
    int x, w;
    bool operator < (const node &p) const { return w > p.w; }
};

struct line {
    int k, b;
    int f(int x) { return k * x + b; }
};

vector<line> tmp;

struct Line_Set {
    int mx;
    vector<line> f;

    void insert(line p) {
        bool flag = 1; tmp.clear();
        for(line l : f) {
            if(l.b > p.b and l.k > p.k) flag = 0;
            if(l.b > p.b or l.k > p.k) tmp.push_back(l);
        }
        if(flag) tmp.push_back(p); swap(f, tmp);
    }

    void upk(int k) { for(line &l : f) l.b += k * k + 2 * l.k * k, l.k += k, Max(mx, l.b); }
} t[N];

vector<int> rt[N];
vector<edge> e[N];
vector<node> fr[N];

priority_queue<node> q;

void addcol(int x, int c) { if(tag[x] ^ c) tag[x] = c, rt[x].push_back(++cnt); }
void addedge(int u, int v, int w, int x, int y) { e[u].push_back({ v, w, x, y }); }

void work() {
    q.push({ 1, 0 });
    while(!q.empty()) {
        node point = q.top(); q.pop();
        if(point.w > d[point.x]) continue;
        int x = point.x;

        for(node l : fr[x]) rt[x][l.x] = l.w, Max(pw[x], t[l.w].mx);

        for(edge l : e[x]) {
            if(d[x] + l.w < d[l.v]) d[l.v] = d[x] + l.w, q.push({ l.v, d[l.v] }), fr[l.v].clear();
            if(d[x] + l.w == d[l.v]) {
                t[rt[x][l.x]].insert({ 0, pw[x] }), t[rt[x][l.x]].upk(l.w);
                fr[l.v].push_back({ l.y, rt[x][l.x] });
            }
        }
    }

    write(d[n]), putchar(' '), write(pw[n]);
}

bool edmer;
signed main() {
	freopen("railway.in", "r", stdin);
	freopen("railway.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();

    for(int i = 1; i <= n; i++) addcol(i, 0);

    for(int i = 1; i <= m; i++) {
        int k = read(), u = read(); addcol(u, i);
        for(int j = 1; j <= k; j++) {
            int w = read(), v = read(); addcol(v, i);
            addedge(u, v, w, rt[u].size() - 1, rt[v].size() - 1), u = v;
        }
    }

    for(int i = 2; i <= n; i++) d[i] = inf;

    work();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 