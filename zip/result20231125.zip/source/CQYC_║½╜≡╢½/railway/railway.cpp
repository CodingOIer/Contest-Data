#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 300010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N],to[N],w[N],t;
il void add(int u,int v,int d){
    nxt[++t]=head[u];head[u]=t;to[t]=v;w[t]=d;
}
int n,m,f[N],du[N],C[N],T[N];
bool vis[N];
queue<int> Q;
map<int,int> mp;
struct node1{
    int a,b;
    il bool operator<(node1 v)ct{
        if(a==v.a) return b>v.b;
        return a<v.a;
    }
} dis[N];
struct node2{
    node1 dis;int x;
    il bool operator<(node2 v)ct{
        return v.dis<dis;
    }
} ;
priority_queue<node2> P;
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<=m;++i){
        int s=read();
        C[0]=read();
        for(int j=1;j<=s;++j){
            T[j]=read();C[j]=read();
        }
        for(int j=0;j<s;++j){
            for(int k=j+1,sum=0;k<=s;++k){
                sum+=T[k];add(C[j],C[k],sum);
            }
        }
    }
    for(int i=1;i<=n;++i) dis[i]=(node1){inf,0};
    dis[1]=(node1){0,0};P.push((node2){dis[1],1});
    while(!P.empty()){
        int x=P.top().x;P.pop();
        if(vis[x]) continue;
        vis[x]=1;
        for(int i=head[x];i;i=nxt[i]){
            node1 tmp=dis[x];
            tmp.a+=w[i];tmp.b+=w[i]*w[i];
            if(tmp<dis[to[i]]){
                dis[to[i]]=tmp;P.push((node2){dis[to[i]],to[i]});
            }
        }
    }
    write(dis[n].a);putchar(' ');write(dis[n].b);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}
