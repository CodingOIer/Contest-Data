#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 5010
#define inf (int)(1000000000000000000)
#define mod 998244353
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
int K,m,fac[N],inv[N],n[N],f[N],sum[N],dp[N][N][2],invf[N];
// int f1[N][N][2];
il void init(){
    fac[0]=1;
    for(int i=1;i<N;++i) fac[i]=fac[i-1]*i%mod;
    inv[N-1]=Pow(fac[N-1],mod-2);
    for(int i=N-1;i;--i) inv[i-1]=inv[i]*i%mod;
}
il int C(int a,int b){
    if(!b||a==b) return 1;
    if(a<0||b<0||a<b) return 0;
    return fac[a]*inv[b]%mod*inv[a-b]%mod;
}
// il void solve1(){
//     for(int i=0;i<=m;++i){
//         for(int j=0;j<=n[1];++j) if(i||j){
//             if(!i) f1[i][j][0]=0;
//             else f1[i][j][0]=(1-f1[i][j-1][1]+mod)%mod;
//             if(!j) f1[i][j][1]=0;
//             else{
//                 int p=i*Pow(i+j,mod-2)%mod;
//                 f1[i][j][1]=((1-f1[i-1][j][0]+mod)*p+f1[i][j-1][1]*(1-p+mod))%mod;
//             }
//             // cerr<<i<<" "<<j<<" "<<f1[i][j][0]<<" "<<f1[i][j][1]<<"\n";
//         }
//     }
//     write((1-f1[m][n[1]][0]+mod)%mod);
// }
il void solve2(){
    f[0]=1;
    int sumn=0;
    for(int i=1;i<=K;++i){
        sumn+=n[i];
        for(int j=0;j<=sumn;++j){
            sum[j]=f[j];
            if(j) sum[j]=(sum[j]+sum[j-1])%mod;
        }
        for(int j=0;j<=sumn;++j){
            f[j]=sum[j-1];
            // cerr<<sum[j-1]<<" ";
            if(j-n[i]-1>=0) f[j]=(f[j]-sum[j-n[i]-1]+mod)%mod;
        }
    }
    for(int i=0;i<=sumn;++i){
        // cerr<<f[i]<<" ";
        f[i]=f[i]*Pow(C(i-1,K-1),mod-2)%mod;
        invf[i]=Pow(f[i],mod-2);
    }
    // cerr<<"\n";
    for(int i=1;i<=m;++i){
        for(int j=1;j<=sumn;++j){
            dp[i][j][0]=(1-dp[i][j-1][1]+mod)%mod;
            int p=i*Pow(i+j,mod-2)%mod;
            dp[i][j][1]=((1-dp[i-1][j][0]+mod)*p%mod+dp[i][j-1][1]*invf[j-1]%mod*(1-p+mod)%mod)*f[j]%mod;
            // cerr<<i<<" "<<j<<" "<<dp[i][j][0]<<" "<<dp[i][j][1]<<"\n";
        }
    }
    // cerr<<(Pow(3,mod-2)+Pow(2,mod-2))%mod<<"\n";
    write((1-dp[m][sumn][0]+mod)%mod);
}
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    init();m=read();K=read();
    for(int i=1;i<=K;++i) n[i]=read();
    solve2();
    // if(K==1) solve1();
    // else solve2();
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}
