#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 600010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,m,a[N],t;
bool pppp;
signed main(){
	// cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
    T=read();
    while(T--){
        n=read();m=read();
		if(n==1){
			puts("-1");continue;
		}
		int flag=0;
		for(int i=0;i<30;++i){
			for(int j=0;j<=n*2;++j) a[j]=0;
			t=0;
			int tot=0;
			for(int j=29;j>=i;--j){
				while(t<n&&(tot<<1)+(((1<<j)&m)!=0)>n){
					a[++t]+=(1<<(j+1));a[++t]+=(1<<(j+1));tot-=2;
					if(t>n){
						for(int k=n+1;k<=t;++k) a[k-n]+=a[k];
						t=n;
					}
				}
				// if(i==1&&j==1) cerr<<t<<" "<<tot<<"\n";
				tot=(tot<<1)+(((1<<j)&m)!=0);
				while(t<n&&t+tot/2*2>=n&&tot>=2){
					a[++t]+=(1<<j);a[++t]+=(1<<j);tot-=2;
					if(t>n){
						for(int k=n+1;k<=t;++k) a[k-n]+=a[k];
						t=n;
					}
				}
				while(t==n&&tot>=2){
					a[1]+=(1<<j);a[2]+=(1<<j);tot-=2;
				}
			}
			// if(i==1) cerr<<tot<<" ";
			if(!tot&&t==n){
				a[1]+=(m%(1<<i));
				for(int j=1;j<=n;++j){
					write(a[j]);putchar(' ');
				}
				putchar('\n');flag=1;break;
			}
		}
		if(!flag) puts("-1");
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}
