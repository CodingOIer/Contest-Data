#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 5010;
const int mod = 998244353;
int m, k;
int n[Maxn];
int f[Maxn][Maxn][2];
int ksm(int x, int y){
    int s = 1;
    while(y){
        if(y & 1) s = s * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return s;
}
int dfs(int x, int y, int t){
    if(y == 0) return f[x][y][t] = 0;
    if(x == 0) return f[x][y][t] = 1;
    if(f[x][y][t]) return f[x][y][t];
    if(t) f[x][y][t] = dfs(x, y - 1, 0);
    else f[x][y][t] = (dfs(x, y - 1, 0) * y % mod * ksm(x + y, mod - 2) % mod + dfs(x - 1, y, 1) * x % mod * ksm(x + y, mod - 2) % mod) % mod;
    return f[x][y][t];
}
map<int, int> g[2];
int Hash(){
    int l = 233, Mod = 147744151, s = 0;
    for(int i = 1 ; i <= k ; i++)
        s = (s * l % Mod + n[i]) % Mod;
    return s;
}
int dfs1(int x, int y, int t){
    // for(int i = 1 ; i <= k ; i++) cout << n[i] << " ";
    // int aa = Hash();
    // cout << aa <<'\n';
    for(int i = 1 ; i <= k ; i++){
        if(n[i] == 0) return 0;
    }
    if(x == 0) return 1;
    int s = 0;
    // if(g[t][aa] != 0) return g[t][aa];
    if(t == 1){
        for(int i = 1 ; i <= k ; i++){
            n[i]--;
            s += dfs1(x, y - 1, 0) * ++n[i] % mod * ksm(y, mod - 2) % mod;
            s %= mod;
        }
        return s % mod;
    }
    for(int i = 1 ; i <= k ; i++){
        n[i]--;
        s += dfs1(x, y - 1, 0) * ++n[i] % mod * ksm(x + y, mod - 2) % mod;
        s %= mod;
    }
    s += dfs1(x - 1, y, 1) * x % mod * ksm(x + y, mod - 2) % mod;
    s %= mod;
    return s % mod;
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    cin >> m >> k;
    int sum = 0;
    for(int i = 1 ; i <= k ; i++) cin >> n[i], sum += n[i];
    if(k == 1){
        dfs(m, n[1], 1);
        cout << f[m][n[1]][1] << '\n';
        return 0;
    }
    cout << dfs1(m, sum, 1) << '\n';
    // cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}