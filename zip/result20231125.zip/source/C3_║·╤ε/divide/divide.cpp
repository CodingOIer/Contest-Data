#include<bits/stdc++.h>
#define int long long
using namespace std;
int T, n, m;
signed main(){
    ios::sync_with_stdio(false);
    freopen("divide.in", "r", stdin);
    freopen("divide.out", "w", stdout);
    cin >> T;
    while(T--){
        cin >> n >> m;
        if(n == 1){
            cout << -1 << '\n';
        }
        if(n == 2){
            if(!(m & 1)) cout << m / 2 << " " << m / 2 << '\n';
            else{
                if(((m / 2) ^ (m / 2 + 1)) == m) cout << -1 << '\n';
                else cout << m / 2 << " " << m / 2 + 1 << '\n';
            }
            continue;
        }
        if(n % 2 == 0 && m % 2 == 0){
            for(int i = 1 ; i <= n - 2 ; i++) cout << 1 << " ";
            m -= n - 2;
            cout << m / 2 << " " << m / 2 << '\n';
        }
        if(n % 2 == 0){
            int ops = 0;
            for(int i = 1 ; i <= n ; i++){
                int x = n, y = m;
                y -= (x - 2) * i;
                if(y <= 0) break;
                if(((y / 2 + 1) ^ (y / 2)) < min(y / 2, i)){
                    for(int j = 1 ; j <= n - 2 ; j++) cout << i << " ";
                    cout << y / 2 + 1 << " " << y / 2 << '\n';
                    ops = 1;
                    break;
                }
                y += i;
                if(y % 3 != 0) continue;
                y /= 3;
                if((y ^ i) < min(y, i)){
                    for(int j = 1 ; j <= n - 3 ; j++) cout << i << " ";
                    cout << y << " " << y << " " << y << '\n';
                    ops = 1;
                    break;
                }
            }
            if(!ops) cout << -1 << '\n';
        }
    }
    // cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}