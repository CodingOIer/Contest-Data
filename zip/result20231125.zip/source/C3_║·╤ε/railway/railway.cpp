#include<bits/stdc++.h>
#define int long long
#define fir first
#define sec second
using namespace std;
const int Maxn = 1010;
int n, m;
int a[Maxn << 1], w[Maxn << 1];
struct Edge{
    int to, nxt, w;
}edge[Maxn * Maxn];
int head[Maxn * Maxn], tot;
void add(int x, int y, int w){
    edge[++tot] = {y, head[x], w};
    head[x] = tot;
}
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
int dis[Maxn], vis[Maxn], Max[Maxn];
void dij(){
    memset(dis, 0x3f, sizeof(dis));
    dis[1] = 0;
    q.push({0, 1});
    while(!q.empty()){
        int x = q.top().sec;
        q.pop();
        if(vis[x]) continue;
        vis[x] = 1;
        for(int i = head[x] ; i ; i = edge[i].nxt){
            int to = edge[i].to;
            int w = edge[i].w;
            if(dis[to] > dis[x] + w){
                dis[to] = dis[x] + w;
                Max[to] = Max[x] + w * w;
                q.push({dis[to], to});
            }
            if(dis[to] == dis[to] + w && Max[to] < Max[x] + w * w){
                Max[to] = Max[x] + w * w;
                q.push({dis[to], to});
            }
        }
    }
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("railway.in", "r", stdin);
    freopen("railway.out", "w", stdout);
    cin >> n >> m;
    for(int i = 1 ; i <= m ; i++){
        int len, s = 0, cnt = 0;
        cin >> len;
        for(int i = 1 ; i <= len * 2 + 1 ; i++){
            w[i] = w[i - 1];
            int s;
            if(i & 1) cin >> a[i];
            else cin >> s, w[i] += s;
            if(!(i & 1)) continue;
            for(int x = 1 ; x < i ; x += 2)
                add(a[x], a[i], w[i] - w[x - 1]);
        }
    }
    dij();
    cout << dis[n] << " " << Max[n] << '\n';
    // cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}