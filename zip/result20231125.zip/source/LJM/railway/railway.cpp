#include<bits/stdc++.h>
#define int long long
#define N 1000006
using namespace std;
int n, m;
struct edge{
    int to, w;
};
vector<edge>p[N];
void add(int u, int v, int w) {
	p[u].push_back((edge){v, w});
	//cout << u << " -> " << v << " : " << w << endl;
}
int s[N], c[N], t[N], sum[N];
int dis1[N], dis2[N];
struct node{
	int v, w;
	friend bool operator < (node x, node y) {
		return x.w > y.w;
	}
};
priority_queue<node>Q;
bool vis[N];
signed main() {
	freopen("railway.in", "r", stdin);
	freopen("railway.out", "w", stdout);
    scanf("%lld %lld", &n, &m);
    for(int i = 1; i <= m; i++) {
    	scanf("%lld", &s[i]);
    	for(int j = 1; j <= s[i]; j++) {
    		scanf("%lld %lld", &c[j], &t[j]);
    		sum[j] = sum[j - 1] + t[j - 1];
		}
		scanf("%lld", &c[s[i] + 1]);
		sum[s[i] + 1] = sum[s[i]] + t[s[i]];
		for(int j = 1; j <= s[i]; j++) {
			for(int k = j + 1; k <= s[i] + 1; k++) add(c[j], c[k], sum[k] - sum[j]);
		}
	}
	for(int i = 1; i <= n; i++) {
		dis1[i] = 1e18;
		dis2[i] = -1e18;
	}
	dis1[1] = dis2[1] = 0;
	Q.push((node){1, 0});
	while(!Q.empty()) {
		int x = Q.top().v;
		Q.pop();
		if(vis[x]) continue;
		vis[x] = 1;
		for(int i = 0; i < p[x].size(); i++) {
			int y = p[x][i].to;
			if(dis1[y] > dis1[x] + p[x][i].w) {
				dis1[y] = dis1[x] + p[x][i].w;
				dis2[y] = dis2[x] + p[x][i].w * p[x][i].w;
				Q.push((node){y, dis1[y]});
			}
			else if(dis1[y] == dis1[x] + p[x][i].w && dis2[y] < dis2[x] + p[x][i].w * p[x][i].w) {
				dis2[y] = dis2[x] + p[x][i].w * p[x][i].w;
			}
		}
	}
	printf("%lld %lld", dis1[n], dis2[n]);
	return 0;
}
/*
2 1
1 1 3 2
*/

