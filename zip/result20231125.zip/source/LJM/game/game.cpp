#include<bits/stdc++.h>
#define int long long
#define N 5010
#define mod 998244353 
using namespace std;
int m, k, ans;
int n[N];
int f[N][N][2]; //1:�ϻغ�δ���� 0:�ϻغ��Ѿ�����
int Inv[N * 3];
int Pow(int a, int n) {
	if(n == 0) return 1;
	if(n == 1) return a % mod;
	int x = Pow(a, n / 2);
	if(n % 2 == 0) return x * x % mod;
	else return x * x % mod * a % mod;
} 
int inv(int x) {
	return Pow(x, mod - 2);
}
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
    scanf("%lld %lld", &m, &k);
    for(int i = 1; i <= k; i++) scanf("%lld", &n[i]);
    for(int i = 1; i <= m + n[1]; i++) Inv[i] = inv(i);
	f[m][n[1]][0] = 1;
	for(int i = m; i >= 1; i--) 
	for(int j = n[1]; j >= 1; j--) {
		f[i][j - 1][1] = (f[i][j - 1][1] + f[i][j][0]) % mod; //B��һ��A 
		f[i][j - 1][1] = (f[i][j - 1][1] + f[i][j][1] * j % mod * Inv[i + j] % mod) % mod; //A������A 
		f[i - 1][j][0] = (f[i - 1][j][0] + f[i][j][1] * i % mod * Inv[i + j] % mod) % mod; //A������B 
	}
	//for(int i = 1; i <= n[1]; i++) cout << f[0][i][0] + f[0][i][1] << endl;
	//cout << endl;
	for(int i = 1; i <= n[1]; i++) ans = (ans + (f[0][i][0] + f[0][i][1]) % mod) % mod;
	printf("%lld", ans); 
	return 0;
}
// 2 1 2
