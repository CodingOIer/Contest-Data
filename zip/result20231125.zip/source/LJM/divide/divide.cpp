#include<bits/stdc++.h>
#define int long long
using namespace std;
int T, n, m;
signed main() {
	freopen("divide.in", "r", stdin);
	freopen("divide.out", "w", stdout);
    scanf("%lld", &T);
    while(T--) {
    	scanf("%lld %lld", &n, &m);
    	//cout << "e";
    	if(n == 1) printf("-1\n");
    	else if(n == 2) {
    		int a = m / 2, b = m - m / 2;
    		int z = b;
    		bool flag = 1;
    		while(1) {
    			if(z == 1) break;
    			if(z % 2 == 0) z /= 2;
    			else {
    				flag = 0;
    				break;
				}
			}
			if(flag) printf("-1\n");
    		else printf("%lld %lld\n", m / 2, m - m / 2);
		} 
		else if(n == 3) {
			//if(m % 2 == 0) {
				for(int x = 1; x <= 15; x++) {
					for(int a = 1; a <= 15; a++) {
						int w = m - x;
						if((a + w) % 2 != 0) continue;
		
						int z = (a + w) / 2;
						int y = w - z;
						if(x < 1 || y < 1 || z < 1) continue;
						//if(x == 3 && a == 1) cout << "e";
						if(min(x, min(y, z)) > (x ^ y ^ z)) {
							printf("%lld %lld %lld\n", x, y, z);
							goto end;
						}
					}
				}
				printf("-1\n");
				end:;
			//}
		}
	}
	return 0;
}
/*
100
3 24
*/
