#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
inline int Mod(int x){if(x>=mod)x-=mod;return x;}
int poww(int x,int y){
	int sum=1;
	while(y){
		if(y&1)sum=1ll*x*sum%mod;
		x=1ll*x*x%mod;
		y>>=1;
	}
	return sum;
}
int inv[10005];
void Init(int x){for(int i=1;i<=x;i++)inv[i]=poww(i,mod-2);}
int n,m,k;
int a[5005];
int f[5005][5005][2],ans;
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	Init(1e4);
	cin>>m>>k>>n;
	f[0][0][1]=1;
	for(int i=0;i<n+m;i++){
		for(int j=0;j<m;j++){
			if(j>i)continue;
			if(i-j>=n)continue;
			if(i+1-j<n)f[i+1][j][0]=Mod(f[i+1][j][0]+Mod(f[i][j][1]+1ll*f[i][j][0]*(n-(i-j))%mod*inv[n+m-i]%mod));
			f[i+1][j+1][1]=Mod(f[i+1][j+1][1]+1ll*f[i][j][0]*(m-j)%mod*inv[n+m-i]%mod);
		}
	}
	for(int i=1;i<=n+m;i++)
		ans=Mod(ans+f[i][m][1]);
	cout<<ans;
	return 0;
}
