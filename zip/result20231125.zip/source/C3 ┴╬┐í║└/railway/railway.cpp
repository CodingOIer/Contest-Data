#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*P1=buff,*P2=buff;
    char getch(){
        return P1==P2&&(P2=((P1=buff)+fread(buff,1,1<<21,stdin)),P1==P2)?EOF:*P1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,m;
struct node{
	int len,w;
};
struct Edge{
	int to,w;
};
vector<node>s[1000005];
vector<Edge>to[1000005],G[1000005];
bool vis[1000005];
int dis[1000005];
int in[1000005];
long long int maxn[1000005];
void dijk(int S){
	memset(dis,0x3f,sizeof dis);
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >q;
	q.push(make_pair(0,S));
	dis[S]=0;
	while(!q.empty()){
		int x=q.top().second;
		q.pop();
		if(vis[x])continue;
		vis[x]=1;
		for(auto E:to[x]){
			int y=E.to,w=E.w;
			if(vis[y])continue;
			if(dis[x]+w<dis[y]){
				dis[y]=dis[x]+w;
				q.push(make_pair(dis[y],y));
			}
		}
	}
}
void sol(){
	queue<int>q;
	for(int i=1;i<=n;i++)if(in[i]==0)q.push(i);
	while(!q.empty()){
		int x=q.front();
		q.pop();
		for(auto E:G[x]){
			int y=E.to,w=E.w;
			maxn[y]=max(maxn[y],maxn[x]+1ll*w*w);
			in[y]--;
			if(!in[y]){
				q.push(y);
			}
		}
	}
}
signed main(){
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	read(n,m);
	for(int i=1;i<=m;i++){
		int S;
		read(S);
		int u;
		read(u);
		s[i].push_back((node){0,u});
		for(int j=1;j<=S;j++){
			int w,v;
			read(w,v);
			s[i].push_back((node){s[i][j-1].len+w,v});
			to[u].push_back((Edge){v,w});
			u=v;
		}
	}
	dijk(1);
	for(int i=1;i<=m;i++){
		int now=0;
		for(int j=1;j<s[i].size();j++){
			while(now<j&&dis[s[i][j].w]<dis[s[i][now].w]+s[i][j].len-s[i][now].len){
				now++;
			}
			if(now==j)continue;
			G[s[i][now].w].push_back((Edge){s[i][j].w,s[i][j].len-s[i][now].len});
			in[s[i][j].w]++;
		}
	}
	sol();
	cout<<dis[n]<<" "<<maxn[n];
	return 0;
}
