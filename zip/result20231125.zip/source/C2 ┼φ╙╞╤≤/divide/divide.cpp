#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
int n,m;
inline void solve()
{
	read(n),read(m);
	if(n==1) return puts("-1"),void();
	if(n%2==0&&m%2==0)
	{
		for(int i = 1;i<=n-2;i++)
			putchar('1'),putchar(32),m--;
		write(m/2),putchar(32),writen(m/2);
		return;
	}
	if(n!=3&&n%2==1&&m%2==0)
	{
		if(n-3>m-6) return puts("-1"),void();
		write(1),putchar(32),write(2),putchar(32),write(3),putchar(32);
		m-=6,n-=3;
		for(int i = 1;i<=n-2;i++)
			putchar('1'),putchar(32),m--;
		write(m/2),putchar(32),writen(m/2);
		return;
	}
	int mid = m/2; 
	if(n==2)
	{
		for(int i = -100;i<=100;i++)
		{
			int x = mid-i,y = mid+i;
			x++;
			if(x>0&&y>0&&min(x,y)>(x^y)) return write(x),putchar(32),writen(y),void(); 
			x--,y++;
			if(x>0&&y>0&&min(x,y)>(x^y)) return write(x),putchar(32),writen(y),void(); 
		}
		puts("-1");
		return;
	}
	if(n==3)
	{
		for(int i = -20;i<=20;i++)
			for(int j = -20;j<=20;j++)
			{
				int x,y,z;
				x = mid+i,y = mid+j,z = m-x-y;
				if(x>0&&y>0&&z>0&&min(x,min(y,z))>(x^y^z)) return write(x),putchar(32),write(y),putchar(32),writen(z),void();
			}
		puts("-1");
		return;
	}
	puts("-1");
}
int T;
signed main()
{
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	read(T);
	while(T--) solve();
	return 0;
}

