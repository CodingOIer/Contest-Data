#include <bits/stdc++.h>
#define int long long
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x>9) write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    putchar(10);
}
const int N = 1e6+5;
int n,m;
struct node{
	int cnt,head[N],to[N],nxt[N],g[N],typ[N];
	inline void add(int x,int y,int z,int tp)
	{
		nxt[++cnt] = head[x];
		head[x] = cnt;
		to[cnt] = y,g[cnt] = z,typ[cnt] = tp;
	}
}e,E;
int dis[N];
bool vis[N];
vector<int> pre[N];
void dij()
{
	memset(dis,63,sizeof dis);
	priority_queue<pair<int,int> > q;
	q.push({0,1});
	dis[1] = 0;
	while(!q.empty())
	{
		int u = q.top().second;q.pop();
		if(vis[u]) continue;
		vis[u] = 1;
		for(int i = e.head[u];i;i = e.nxt[i])
		{
			int v = e.to[i];
			if(dis[v]>dis[u]+e.g[i]) dis[v] = dis[u]+e.g[i],q.push({-dis[v],v});
			if(dis[v]==dis[u]+e.g[i]) E.add(u,v,e.g[i],e.typ[i]);
		}
	}
}
inline int pw(int x){return x*x;}
int ans;
void dfs(int u,int tp,int las,int sum)
{
	if(u==n)
	{
		sum+=pw(dis[u]-dis[las]);
		ans = max(ans,sum);
		return;
	}
	int tmps = sum;
	for(int i = E.head[u];i;i = E.nxt[i])
	{
		int v = E.to[i];
		if(tp!=E.typ[i]&&tp!=0)	dfs(v,E.typ[i],u,sum+pw(dis[u]-dis[las]));
		else dfs(v,E.typ[i],las,sum);
	}
}
signed main()
{
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	read(n),read(m);
	for(int i = 1,s,las,x,t;i<=m;i++)
	{
		read(s);
		read(las);
		for(int j = 1;j<=s;j++)
			read(t),read(x),e.add(las,x,t,i),las = x;
	}
	dij();
	write(dis[n]),putchar(32);
	dfs(1,0,1,0);
	write(ans);
	return 0;
}

