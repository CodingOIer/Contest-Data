#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=5005,M=1e4+5,mo=998244353;
int totn,m,k,n[N],dp[N][N],ny[M],jc[M],jc_ny[M],f[N],pre[N][N];
int ksm(int a,int b,int c)
{
	int ans=1;
	while(b>0)
	{
		if(b%2==1) ans=(ll)ans*a%c;
		a=(ll)a*a%c;
		b/=2;
	}
	return ans;
}
int get_C(int a,int b)
{
	if(a<b||a<0||b<0) return 0;
	return (ll)jc[a]*jc_ny[b]%mo*jc_ny[a-b]%mo;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
    scanf("%d%d",&m,&k);
    for(int a=1;a<=k;a++) scanf("%d",&n[a]),totn+=n[a];
    for(int a=1;a<=1e4;a++) ny[a]=ksm(a,mo-2,mo);
    jc[0]=1;
    for(int a=1;a<=1e4;a++) jc[a]=(ll)jc[a-1]*a%mo;
    for(int a=0;a<=1e4;a++) jc_ny[a]=ksm(jc[a],mo-2,mo);
    f[0]=1;
   // cout<<"h";
    for(int a=1;a<=k;a++)
    {
    //	cout<<f[1]<<endl;
    	for(int b=totn;b>=0;b--)
    	{
    		for(int c=1;c<n[a]&&b-c>=0;c++)
    		{
    			f[b]=((ll)f[b]+(ll)f[b-c]*get_C(n[a],c))%mo;
			}
		}
	}
	for(int a=1;a<=totn;a++) f[a]=(ll)f[a]*jc[a]%mo;
//	cout<<f[1]<<endl;
	for(int a=1;a<=totn;a++) dp[0][a]=f[totn-a],pre[0][a]=(pre[0][a-1]+(ll)dp[0][a]*jc[a]%mo)%mo;
	for(int a=1;a<=m;a++)
	{
		for(int b=1;b<=totn;b++)
		{
			dp[a][b]=(ll)ny[b]*jc_ny[a+b-1]%mo*a%mo*pre[a-1][b-1]%mo;
			pre[a][b]=(pre[a][b-1]+(ll)dp[a][b]*jc[a+b]%mo)%mo;
		}
	}
	printf("%d",dp[m][totn]);
}
