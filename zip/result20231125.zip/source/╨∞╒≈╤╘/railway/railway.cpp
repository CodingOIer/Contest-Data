#include<bits/stdc++.h>
#define ll long long
#define Pair pair<int,int>
#define Mp make_pair
using namespace std;
const int N=1e6+5;
int n,m,k[N],mn[N],head[N],to[N],nxt[N],e,C[N],dis[N],num;
ll dp2[N];
bool vis[N];
vector<int> pos[N],cost[N],pre[N],id[N];
vector<Pair> son[N];
Pair A[N];
void add_edge(int x,int y,int z)
{
	to[++e]=y;
	C[e]=z;
	nxt[e]=head[x];
	head[x]=e;
}
struct X
{
	int l,r;
	ll k,b;
};
stack<X> sta[N];
X make_j(int l,int r,ll k,ll b)
{
	X j;
	j.l=l,j.r=r,j.k=k,j.b=b;
	return j;
}
priority_queue<Pair,vector<Pair>,greater<Pair> > pq;
void dij()
{
	memset(dis,0x3f,sizeof(dis));
	dis[1]=0;
	pq.push(Mp(0,1));
	while(!pq.empty())
	{
		int t=pq.top().second;
		pq.pop();
		if(vis[t]==1) continue;
		vis[t]=1;
		for(int a=head[t];a>0;a=nxt[a])
		{
			int s=to[a];
			if(dis[s]>dis[t]+C[a])
			{
				dis[s]=dis[t]+C[a];
				pq.push(Mp(dis[s],s));
			}
		}
	}
}
int main()
{
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int a=1;a<=m;a++)
    {
    	int k;
    	scanf("%d",&k);
    	for(int b=1;b<=k+1;b++)
    	{
    		int x,y;
    		scanf("%d",&x);
    		pos[a].push_back(x);
    		if(b!=1) pre[a].push_back(pre[a][b-2]+cost[a][b-2]);
    		else pre[a].push_back(0);
    		if(b!=k+1) scanf("%d",&y),cost[a].push_back(y);
    		son[x].push_back(Mp(a,b-1));
		}
		for(int b=0;b<k;b++)
		{
			add_edge(pos[a][b],pos[a][b+1],cost[a][b]);
		}
	}
	dij();
	memset(mn,0x3f,sizeof(mn));
	memset(dp2,-0x3f3f,sizeof(dp2));
	for(int a=1;a<=n;a++) A[a].first=dis[a],A[a].second=a;
	for(int a=1;a<=m;a++)
	{
		id[a].push_back(++num);
		for(int b=1;b<pos[a].size();b++)
		{
			if(dis[pos[a][b-1]]+cost[a][b-1]!=dis[pos[a][b]]) num++;
			id[a].push_back(num);
		}
	}
//	for(int a=1;a<=n;a++) cout<<a<<" "<<dis[a]<<endl;
	sort(A+1,A+1+n);
	dp2[1]=0;
	for(int h=1;h<=n;h++)
	{
		int a=A[h].second;
		for(int b=0;b<son[a].size();b++)
		{
			int i=son[a][b].first,j=son[a][b].second,I=id[i][j];
		//	cout<<a<<" "<<i<<" "<<mn[i]+pre[i][j]<<endl;
			if(j==0) continue;
            if(mn[I]+pre[i][j]==dis[a])
			{
			//	if(a==3) cout<<i<<" "<<j<<endl;
				while(sta[I].top().r<pre[i][j]) sta[I].pop();
				dp2[a]=max(dp2[a],sta[I].top().k*pre[i][j]+sta[I].top().b+(ll)pre[i][j]*pre[i][j]);
			}
		}
	//	cout<<a<<" "<<dp2[a]<<endl;
		for(int b=0;b<son[a].size();b++)
		{
			int i=son[a][b].first,j=son[a][b].second,I=id[i][j];
			ll k1=-2*pre[i][j],b1=dp2[a]+(ll)pre[i][j]*pre[i][j];
			if(dis[a]-pre[i][j]<mn[I])
			{
				mn[I]=dis[a]-pre[i][j];
				while(!sta[I].empty()) sta[I].pop();
				sta[I].push(make_j(1,1e9,k1,b1));
			}
			else if(dis[a]-pre[i][j]==mn[I])
			{
				int l1=1,r1=0;
				while(1)
				{
					if(sta[I].empty())
					{
						sta[I].push(make_j(l1,r1,k1,b1));
						break;
					}
					X j=sta[I].top();
					sta[I].pop();
					if(j.k*j.l+j.b>=k1*j.l+b1)
					{
					    sta[I].push(j);
						if(l1<=r1)
						{
							sta[I].push(make_j(l1,r1,k1,b1));
						}
						break;
					}
					if(j.k*j.r+j.b<=k1*j.r+b1)
					{
						r1=j.r;
						continue;
					}
					int l=j.l,r=j.r;
					while(l<r)
					{
						int mid=(l+r+1)/2;
						if(j.k*mid+j.b<=k1*mid+b1) l=mid;
						else r=mid-1;
					}
					sta[I].push(make_j(l+1,j.r,j.k,j.b));
					sta[I].push(make_j(l1,l,k1,b1));
					break;
				}
			}
		}
	}
	printf("%d %lld",dis[n],dp2[n]);
} 
