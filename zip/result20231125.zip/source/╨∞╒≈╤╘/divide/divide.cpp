#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e6+5;
int T,n,m; 
int main()
{
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
    scanf("%d",&T);
    while(T--)
    {
    	scanf("%d%d",&n,&m);
    	if(n==1)
    	{
    		printf("-1\n");
    		continue;
		}
		if(m%2==0) printf("%d %d\n",m/2,m/2);
	}
}
