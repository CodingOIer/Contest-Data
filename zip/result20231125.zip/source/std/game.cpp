#include <bits/stdc++.h>

#define gc() getchar()
template <typename T> inline void rd(T& x) {
	int si = 1; char c = gc(); x = 0;
	while(!isdigit(c)) si = c == '-' ? -1 : si, c = gc();
	while(isdigit(c)) x = x * 10 + c - 48, c = gc();
	x *= si;
}
template <typename T, typename... Args>
inline void rd(T& x, Args&... args) { rd(x); rd(args...); }
#define fi first
#define se second
#define mkp std::make_pair
typedef unsigned ui;
typedef long long ll;
typedef unsigned long long ull;
typedef double ff;
typedef std::pair <int, int> pii;
const int N = 5e3 + 5, M = 1e5 + 5, MOD = 998244353;

int QPow(int a, int b) {
	int ret = 1, bas = a;
	for(; b; b >>= 1, bas = 1LL * bas * bas % MOD)
		if(b & 1) ret = 1LL * ret * bas % MOD;
	return ret;
}

int fac[M], fac_inv[M], inv[M];
void Init() {
	fac[0] = 1;
	for(int i = 1; i < M; ++i) fac[i] = 1LL * fac[i - 1] * i % MOD;
	fac_inv[M - 1] = QPow(fac[M - 1], MOD - 2);
	for(int i = M - 2; ~i; --i)
		fac_inv[i] = 1LL * fac_inv[i + 1] * (i + 1) % MOD;
	for(int i = 1; i < M; ++i)
		inv[i] = 1LL * fac[i - 1] * fac_inv[i] % MOD;
}

int C(int x, int y) {
	if(x < y || y < 0) return 0;
	return 1LL * fac[x] * fac_inv[y] % MOD * fac_inv[x - y] % MOD;
}
int CInv(int x, int y) {
	if(x < y || y < 0) return 0;
	return 1LL * fac_inv[x] * fac[y] % MOD * fac[x - y] % MOD;
}

int n, k, m, f[N][N], a[N];

void Upd(int &x, int y, int c = 1) { x = (x + 1LL * y * c) % MOD; }

void Solve() {
	f[n][m] = 1;
	for(int i = n; i; --i)
		for(int j = m; j; --j) {
			Upd(f[i - 1][j], f[i][j], 1LL * i * inv[i + j] % MOD);
			Upd(f[i - 1][j - 1], f[i][j], 1LL * j * inv[i + j] % MOD);
		}
}

/*void Output(int x) {
	if(x <= 100000) printf("%d\n", x);
	else {
		for(int i = 1; i <= 100000; ++i)
			for(int j = 2; j <= 100000; ++j)
				if(1LL * i * inv[j] % MOD == x) {
					printf("%d / %d\n", i, j);
					return;
				}
	}
}*/

int g[N], _g[N];

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int test_case_cnt = 1; //rd(test_case_cnt);
	while(test_case_cnt--) {
		rd(m, k); Init();
		g[0] = 1;
		for(int i = 1; i <= k; ++i) {
			rd(a[i]);
			memset(_g, 0, sizeof(_g));
			for(int j = 0; j < a[i]; ++j)
				for(int k = 0; k <= n; ++k)
					Upd(_g[j + k], g[k], C(a[i], j));
			memcpy(g, _g, sizeof(g));
			n += a[i];
		}
		--n;
		Solve();
		int ans = 0;
		for(int i = 0; i < n; ++i) {
			int d = f[i][0], x = i + 1, c = 1LL * CInv(n + 1, x) * g[n + 1 - x] % MOD;
			Upd(ans, d, c);
		}
//		Output(ans);
		printf("%d\n", ans);
	} return 0;
}
