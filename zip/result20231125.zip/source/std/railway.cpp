#include<bits/stdc++.h>
#define reg register
#define int long long
inline int read(){
    reg int x=0,k=1; reg char ch=getchar();
    while ('0'>ch||ch>'9') (ch=='-')&&(k=-1),ch=getchar();
    while ('0'<=ch&&ch<='9') x=x*10+ch-48,ch=getchar();
    return x*k;
}
inline bool cmin(reg int &x,reg int y){return x>y?x=y,1:0;}
inline bool cmax(reg int &x,reg int y){return x<y?x=y,1:0;}
const int N=1e6+10,INF=2e9;
int n,m,cnt,head[N],s[N],f[N],dis[N],idx,X[N],Y[N],id[N];
struct EDGE{int pre,to,val;}edge[N];
inline void add(reg int u,reg int v,reg int w){edge[++cnt]={head[u],v,w},head[u]=cnt;}
std::priority_queue<std::pair<int,int>> pq;
std::vector<int> vc[N],sum[N],lim[N],stk[N<<1],sid[N];
std::vector<std::pair<int,int> > bel[N];
inline void dij(){ 
    for (reg int i=1;i<=n;i++) dis[i]=INF; dis[1]=0,pq.push({0,1});
    while (!pq.empty()){
        reg int u=pq.top().second,d=-pq.top().first;
        pq.pop(); if (d!=dis[u]) continue;
        for (reg int i=head[u],v;v=edge[i].to,i;i=edge[i].pre){
            cmin(f[i],dis[u]+edge[i].val);
            if (cmin(dis[v],dis[u]+edge[i].val)) pq.push({-dis[v],v});
        }
    }
}
inline long double slope(reg int x,reg int y){return 1.0L*(Y[x]-Y[y])/(X[x]-X[y]);}
signed main(){
    freopen("railway.in","r",stdin);freopen("railway.out","w",stdout);
    n=read(),m=read();
    for (reg int i=1,lst;i<=m;i++){
        s[i]=read(),lst=read(); vc[i].push_back(0); 
        sum[i].push_back(0),vc[i].push_back(lst);
        for (reg int j=1,x,y;j<=s[i];j++){
            x=read(),y=read(),add(lst,y,x),lst=y;
            vc[i].push_back(y),sum[i].push_back(x);
        }
        sid[i].push_back(0);
        for (reg int j=1;j<=s[i]+1;j++) bel[vc[i][j]].push_back({i,j}),sid[i].push_back(0);
    } 
    dij(); for (reg int i=1;i<=n;i++) id[i]=i;
    std::sort(id+1,id+n+1,[&](reg int x,reg int y){return dis[x]<dis[y];});        
    for (reg int t=1,x;x=id[t],t<=n;t++){
        for (reg auto it:bel[x]){
            reg int ty=it.first,ID=it.second;
            if (ID!=1&&dis[vc[ty][ID-1]]+sum[ty][ID-1]==dis[x]) 
                sid[ty][ID]=sid[ty][ID-1];
            else sid[ty][ID]=++idx; reg int nw=sid[ty][ID];
            while (stk[nw].size()>1&&slope(stk[nw][stk[nw].size()-2],stk[nw].back())<dis[x])
                stk[nw].pop_back();
            if (stk[nw].size()){
                reg int y=stk[nw].back();
                cmax(f[x],f[y]+(dis[x]-dis[y])*(dis[x]-dis[y]));
            }
        }
        for (reg auto it:bel[x]){
            reg int ty=it.first,nw=sid[ty][it.second]; X[x]=dis[x]*2,Y[x]=dis[x]*dis[x]+f[x];
            while (stk[nw].size()>1&&slope(stk[nw][stk[nw].size()-2],stk[nw].back())<slope(x,stk[nw][stk[nw].size()-2]))
                stk[nw].pop_back();
            stk[nw].push_back(x);
        }
    }
    printf("%lld %lld",dis[n],f[n]);
    return 0;
}
