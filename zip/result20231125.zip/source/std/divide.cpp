#include<cstdio>
#include<algorithm>

const int N=1e5,M=1e7;

int T,n,m;

inline int lb(int x){return x&-x;}
inline int hb(int x){
    if(x==0)return 0;
    x|=x>>1,x|=x>>2,x|=x>>4,x|=x>>8,x|=x>>16;
    return (x>>1)+1;
}

inline void solve3(bool o){
    //ou
	if(m%2==0){
		if(m==lb(m)){//2^k
			if(m==4||m==8)puts("-1");
			else printf("%d %d %d\n",3*(m/16),6*(m/16),7*(m/16));
		}
		else{//others
			int z=hb(m);
			printf("%d %d %d\n",m>>1,z>>1,(m^z)>>1);
		}
	}
    else{//ji
		if(m-1==lb(m-1)){//2^k+1
			if(m<=17)puts("-1");
			else printf("%d %d %d\n",3*(m/16),6*(m/16),7*(m/16)+1);
		}
		else if(m-3==lb(m-3)){//2^k+3
			if(m<=19)puts("-1");
			else printf("%d %d %d\n",3*(m/16)+1,6*(m/16)+1,7*(m/16)+1);
		}
		else{//others
			int z=hb(m);
			printf("%d %d %d\n",m>>1,(z>>1)+1,(m^z)>>1);
		}
	}
}
inline void solve4(bool o){
    //ou
    if(m%2==0)printf("%d %d %d %d\n",1,1,(m-2)/2,(m-2)/2);
    else{//ji
        if(m<9)puts("-1");
        else printf("%d %d %d %d\n",(m-5)/2,(m-5)/2,2,3);
    }
}
inline void solve5(bool o){
    if(m%2==0){//ou
        if(m==6)puts("-1");
        else{
            printf("%d %d ",(m-6)/2,(m-6)/2);
            n=3,m=6;
            solve3(0);
        }
    }
    else{//ji
        if(m<=15)puts("-1");
        else{
            printf("%d %d ",(m-13)/2,(m-13)/2);
            n=3,m=13;
            solve3(0);
        }
    }
}
inline void solve(){
    scanf("%d%d",&n,&m);
    if(n==1)puts("-1");
    else if(n==2){
        //ou
        if(m%2==0)printf("%d %d\n",m/2,m/2);
        //ji
        else{
			if(m+1==lb(m+1))puts("-1");
            else printf("%d %d\n",m/2,m/2+1);
		}
    }
    else if(n==3)solve3(1);
    else if(n==4)solve4(1);
    else if(n==5)solve5(1);
    else if(n%2==0){
        //ou
        if(m%2==0){
            for(int i=1;i<=n-2;++i)printf("%d ",1);
            printf("%d %d\n",(m-n+2)/2,(m-n+2)/2);
        }
        else{//ji
			if(m<2*n+1)puts("-1");
			else{
            	for(int i=1;i<=n-4;++i)printf("%d ",2);
            	m-=2*(n-4),n=4;
            	solve4(0);
			}
        }
    }
    else if(n%2==1){
        if(m%2==0){//ou
            if(m==n+1)puts("-1");
            else{
                for(int i=1;i<=n-5;++i)printf("1 ");
                m-=n-5,n=5;
                solve5(0);
            }
        }
        else{//ji
            if(m<=2*n+5)puts("-1");
            else{
                for(int i=1;i<=n-5;++i)printf("2 ");
                m-=2*(n-5),n=5;
                solve5(0);
            }
        }
    }
}

int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);

    scanf("%d",&T);
    while(T--)solve();

    return 0;
}
