#include<bits/stdc++.h>
using namespace std;
int n,m;
signed main()
{
	freopen("devide.in","r",stdin);
	freopen("devide.out","w",stdout);
	int T;
	cin>>T;
	while(T--)
	{
		cin>>n>>m;
		if(n>m)
		{
			cout<<-1<<'\n';
		}else if(n==1)
		{
			cout<<-1<<'\n';
		}else if(n==2)
		{
			if(m&1)
			{
				int sum=0;
				for(int i=0;i<=30;i++)
				{
					if((m>>i)&1)
						continue;
					if(((1<<i)-1)>=m)
					{
						sum=-1;
						break;
					}
					sum=(1<<i)-1;
					break;
				}
				if(sum==-1)
					cout<<-1<<'\n';
				else 
					cout<<(m-sum)/2<<' '<<(m-sum)/2+sum<<'\n';
			}
			else
			{
				cout<<m/2<<' '<<m/2<<'\n';
			}
		}
		else 
		if(((m&1)==0)&&((n&1)==0))
		{
			for(int i=1;i<=n-2;i++)cout<<"1 ";
			cout<<(m-n)/2+1<<' '<<(m-n)/2+1<<'\n';
		}
	}
	return 0;
}
