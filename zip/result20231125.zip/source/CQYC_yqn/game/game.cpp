#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int m,k,n[5005],inv[10005];
inline int qpow(int x)
{
	int ans=1;
	for(int y=mod-2;y;y>>=1)
	{
		if(y&1) ans=1ll*ans*x%mod;
		x=1ll*x*x%mod;
	}
	return ans;
}
inline void add(int &x,int y){x+=y;if(x>=mod)x-=mod;}
int f[5005][5005][2],sum,ans;
inline void sub1(){
	f[m][n[1]][1]=1;
	for(int i=m;~i;--i)
		for(int j=n[1];~j;--j)
		{
			if(j>0) 
				add(f[i][j-1][0],1ll*(f[i][j][0]+f[i][j][1])*j%mod*inv[i+j]%mod);
			if(i>0) 
				add(f[i-1][j][1],1ll*f[i][j][0]*i%mod*inv[i+j]%mod);
		}
	for(int j=1;j<=n[1];++j) 
		ans=(ans+f[0][j][1])%mod;
	for(int i=1;i<=m;++i) 
		sum=(sum+f[i][0][0])%mod;
	sum=(sum+ans)%mod;
	printf("%d\n",1ll*ans*qpow(sum)%mod);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	m=read(),k=read();
	for(int i=1;i<=k;++i) 
		n[i]=read();
	inv[0]=1;
	for(int i=1;i<=10000;++i) 
		inv[i]=qpow(i);	
	sub1();
	return 0;
}

