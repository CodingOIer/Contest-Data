#include<bits/stdc++.h>
using namespace std;
const int inf=1e9;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');return ;
}
namespace brute1{
    void solve(int n,int m){
        puts("-1");
        return ;
    }
}
namespace brute2{
    void solve(int n,int m){
        if(m&1){
            if((1<<((int)log2(m)+1))-1==m)puts("-1");
            else write(m/2),putchar(' '),write(m/2+1),putchar('\n');
        }
        else write(m/2),putchar(' '),write(m/2),putchar('\n');
        return ;
    }
}
namespace brute3{
    void solve(int n,int m){
        for(int i=1,w;i<=10;i++){
            if(m-1*(n-3)-i>0){
                w=(m-1*(n-3)-i)/2;
                if(w==0)continue;
                for(int j=0;j<=min(10,w-1);j++){
                    if(((w-j)^(m-1*(n-3)-i-(w-j))^i^((n-3&1)?1:0))<min((w-j),min((m-1*(n-3)-i-(w-j)),min(i,((n-3)?1:inf))))){
                        for(int i=1;i<=n-3;i++)write(1),putchar(' ');
                        write(i),putchar(' ');
                        write(w-j),putchar(' ');
                        write(m-1*(n-3)-i-(w-j)),putchar('\n');
                        return ;
                    }
                }
            }
        }
        for(int i=1,w;i<=10;i++){
            if(m-2*(n-3)-i>0){
                w=(m-2*(n-3)-i)/2;
                if(w==0)continue;
                for(int j=0;j<=min(10,w-1);j++){
                    if(((w-j)^(m-2*(n-3)-i-(w-j))^i^((n-3&1)?2:0))<min((w-j),min((m-2*(n-3)-i-(w-j)),min(i,((n-3)?2:inf))))){
                        // printf("vo %d %d\n",(w-j)^(m-2*(n-3)-i-(w-j))^i^((n-3&1)?2:0),min((w-j),min((m-2*(n-3)-i-(w-j)),min(i,((n-3)?2:inf)))));
                        for(int i=1;i<=n-3;i++)write(2),putchar(' ');
                        write(i),putchar(' ');
                        write(w-j),putchar(' ');
                        write(m-2*(n-3)-i-(w-j)),putchar('\n');
                        return ;
                    }
                }
            }
        }
        puts("-1");
    }
}
int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    int T=read(),n,m;
    while(T--){
        n=read(),m=read();
        if(n==1)brute1::solve(n,m);
        else if(n==2)brute2::solve(n,m);
        else brute3::solve(n,m);
    }
    return 0;
}