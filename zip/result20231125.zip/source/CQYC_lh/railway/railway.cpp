#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int n,m;
namespace brute1{
    const int maxn=1e3+2,inf=1e9;
    long long sum[maxn][maxn];
    long long f[maxn],g[maxn];
    int sr[maxn];
    vector<long long>cr[maxn],tr[maxn],bel[maxn];
    long long pw(long long x){return x*x;}
    void solve(){
        for(int i=1;i<=m;i++){
            sr[i]=read();
            cr[i].resize(sr[i]+1),tr[i].resize(sr[i]);
            for(int j=1;j<=n;j++)sum[i][j]=inf;
            for(int j=0;j<=sr[i];j++){
                cr[i][j]=read(),bel[cr[i][j]].push_back(i);
                if(!j)sum[i][cr[i][j]]=0;
                if(j<sr[i])tr[i][j]=read();
                if(j>0)sum[i][cr[i][j]]=sum[i][cr[i][j-1]]+tr[i][j-1];
            }
        }
        memset(f,0x3f,sizeof(f));
        memset(g,0x3f,sizeof(g));
        f[1]=g[1]=0;
        for(int i=2;i<=n;i++){
            for(int k=0,co;k<bel[i].size();k++){
                co=bel[i][k];
                for(int j=1;j<n;j++){
                    if(sum[co][i]-sum[co][j]<0)continue;
                    if(f[j]+sum[co][i]-sum[co][j]<f[i])f[i]=f[j]+sum[co][i]-sum[co][j],g[i]=g[j]+pw(sum[co][i]-sum[co][j]);
                    else if(f[j]+sum[co][i]-sum[co][j]==f[i])g[i]=max(g[i],g[j]+pw(sum[co][i]-sum[co][j]));
                }
            }
        }
        printf("%lld %lld\n",f[n],g[n]);
        return ;
    }
}
int main(){
    freopen("railway.in","r",stdin);
    freopen("railway.out","w",stdout);
    n=read(),m=read();
    if(n<=1000)brute1::solve();
    return 0;
}