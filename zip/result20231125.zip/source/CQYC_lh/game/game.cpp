#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=5e3+7;
const int mod=998244353;
int m,K,n;
int ar[maxn],inv[maxn],fac[maxn],inv_fac[maxn];
int g[maxn],dp[maxn][maxn][2];
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void pre_calc(){
    fac[0]=1;for(int i=1;i<maxn;i++)fac[i]=1ll*fac[i-1]*i%mod;
    inv_fac[maxn-1]=f_pow(fac[maxn-1],mod-2);
    for(int i=maxn-1;i;i--)inv_fac[i-1]=1ll*inv_fac[i]*i%mod;
    return ;
}
int calc_C(int a,int b){
    if(b==0)return 1;
    if(a<0||b<0||a<b)return 0;
    return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
}
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    pre_calc();
    m=read(),n=m;
    K=read();
    for(int i=1;i<=K;i++)ar[i]=read(),n+=ar[i];
    inv[1]=1;for(int i=2;i<=n;i++)inv[i]=1ll*(mod-mod/i)*inv[mod%i]%mod;
    g[0]=1;
    for(int p=1;p<=K;p++){
        for(int j=n-m;j>=ar[p];j--)upd(g[j],mod-g[j-ar[p]]);
    }
    dp[0][0][1]=1;
    for(int i=0;i<=n-m;i++){
        for(int j=0;j<=m;j++){
            upd(dp[i+1][j][0],dp[i][j][1]);
            upd(dp[i+1][j][0],1ll*inv[n-i-j]*(n-m-i)%mod*dp[i][j][0]%mod);
            upd(dp[i][j+1][1],1ll*inv[n-i-j]*(m-j)%mod*dp[i][j][0]%mod);
            // for(int ty=0;ty<2;ty++)printf("dp[%d][%d][%d]=%d\n",i,j,ty,dp[i][j][ty]);
        }
    }
    int ans=0;
    for(int i=0,va;i<=n-m;i++){
        va=f_pow(calc_C(n-m,i),mod-2);
        for(int j=0;j<=i;j++){
            upd(ans,1ll*g[j]*va%mod*calc_C(n-m-j,i-j)%mod*dp[i][m][1]%mod);
        }
    }
    printf("%d\n",ans);
    return 0;
}