#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main() {
    return 0;
}