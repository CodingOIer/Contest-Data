#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int f[5005][5005][2],a[5005];
int ksm(int x,int y) {
    if(x<0) return 0;
    int ans=1;
    while(y) {
        if(y&1) ans=(ans*x)%mod;
        x=(x*x)%mod;
        y>>=1;
    }
    return ans;
}
signed main() {
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    int m,k;
    scanf("%lld %lld",&m,&k);
    for(int i=1;i<=k;i++) scanf("%lld",&a[i]);
    if(k==1) {
        f[0][0][0]=1;
        for(int i=1;i<=a[1]+m;i++) {
            for(int j=0;j<=m;j++) {
                if(i-j>a[1]) break;
                f[i][j][1]=(f[i][j][1]+f[i-1][j][0]%mod+(a[1]-(i-j-1))*f[i-1][j][1]*ksm(a[1]+m-i+1,mod-2)%mod)%mod;
                f[i][j+1][0]=(f[i][j+1][0]+(m-j)*f[i-1][j][1]*ksm(a[1]+m-i+1,mod-2))%mod;
            }
        }
        int ans=0;
        for(int i=1;i<=a[1]+m;i++) {
            ans=(ans+f[i][m][0])%mod;
        }
        printf("%d\n",ans);
    }
    return 0;
}