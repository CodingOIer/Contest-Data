#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
int check(int x) {
    int f=0;
    for(int j=32;j>=0;j--) {
        if(x&(1<<j)) {
            f=j;
            break;
        }
    }
    if((1<<(f+1))==x+1) return 0;
    return 1;
}
signed main() {
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    int T;
    scanf("%lld",&T);
    while(T--) {
        scanf("%lld %lld",&n,&m);
        if(n==1) {
            printf("-1\n");
            continue;
        }
        if(m<n) {
            printf("-1\n");
            continue;
        }
        if(m%2==0 && n%2==1) {
            for(int i=1;i<=n-1;i++) printf("1 ");
            printf("%lld \n",(m-(n-1)));
            continue;
        } else if((m%2==0 && n%2==0)) {
            for(int i=1;i<=n-2;i++) printf("1 ");
            for(int i=1;i<=2;i++) printf("%lld ",(m-(n-2))/2);
            printf("\n");
            continue;
        } else {
            if(n*2>m) {
                    printf("-1\n");
                    continue;
                }
                if(n%2==0 && m-2*n==1) {
                    for(int i=1;i<=n-1;i++) printf("2 ");
                    printf("3 \n");
                    continue;
                }else if(((m-2*(n-2)))%2==1 && check((m-2*(n-2))/2)) {
                    for(int i=1;i<=n-2;i++) printf("2 ");
                    printf("%lld ",(m-2*(n-2))/2);
                    printf("%lld \n",(m-2*(n-2))/2+1);
                    continue;
                }else if(n%2==0 && n>=3 && ((m-2*(n-2)-3))%2==0){
                    for(int i=1;i<=n-3;i++) printf("2 ");
                    printf("3 ");
                    for(int i=1;i<=2;i++) printf("%lld ",(m-2*(n-2)-1)/2);
                    printf("\n");
                    continue;
                } 
            }
        printf("-1\n");
    }
    return 0;
}