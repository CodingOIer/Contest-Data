#include<bits/stdc++.h>
using namespace std;
const int N=5010,mod=998244353;
int n,k,ans,a[N],inv[N+N],f[N][N][2];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int ksm(int x,int y)
{
    int res=1;
    for(;y;y>>=1)
    {
        if(y&1) res=1ll*res*x%mod;
        x=1ll*x*x%mod;
    }
    return res;
}
int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    for(int i=1;i<N+N;i++) inv[i]=ksm(i,mod-2);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=k;i++) scanf("%d",a+i);
    f[n][a[1]][0]=1;
    for(int i=n;~i;i--)
        for(int j=a[1];j;j--)
        {
            upd(f[i][j][0],1ll*(i+1)*inv[i+1+j]%mod*f[i+1][j][1]%mod);
            upd(f[i][j][1],f[i][j+1][0]);
            upd(f[i][j][1],1ll*(j+1)*inv[i+j+1]%mod*f[i][j+1][1]%mod);
        }
    for(int i=1;i<a[1];i++) upd(ans,f[0][i][0]);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
