#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=1e6+10;
struct ok{
    int x,y;
    bool operator <(const ok &A) const{return y>A.y;}
};
int n,m,in[N],dis[N];
int first[N],to[N],nxt[N],lth[N],cnt;
bool vis[N];
ll dp[N];
vector<ok>ned[N],edge[N];
queue<int>qq;
priority_queue<ok>q;
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
inline void Max(ll &x,ll y) {x=x>y?x:y;}
inline ll pw(int x) {return 1ll*x*x;}
void Dij()
{
    memset(dis,0x3f,sizeof(dis));
    dis[1]=0,q.push((ok){1,0});
    while(!q.empty())
    {
        int x=q.top().x,l=q.top().y;
        q.pop();
        if(vis[x]) continue;
        vis[x]=1;
        for(int i=first[x],v;i;i=nxt[i])
            if(dis[v=to[i]]>dis[x]+lth[i])
                dis[v]=dis[x]+lth[i],ned[v].clear(),ned[v].push_back((ok){x,lth[i]}),q.push((ok){v,dis[v]});
            else if(dis[v]==dis[x]+lth[i]) ned[v].push_back((ok){x,lth[i]});
    }
}
void topu()
{
    for(int i=1;i<=n;i++)
        if(!in[i]) qq.push(i);
    while(!qq.empty())
    {
        int x=qq.front();
        qq.pop();
        for(ok v:edge[x])
        {
            if(!--in[v.x]) qq.push(v.x);
            Max(dp[v.x],dp[x]+pw(v.y));
        }
    }
}
int main()
{
    freopen("railway.in","r",stdin);
    freopen("railway.out","w",stdout);
    n=read(),m=read();
    for(int i=1,s,l,t,c;i<=m;i++)
    {
        s=read(),l=read();
        while(s--)
            t=read(),c=read(),inc(l,c,t),l=c;
    }
    Dij();
    printf("%d ",dis[n]);
    for(int i=1;i<=n;i++)
        for(ok v:ned[i])
            edge[v.x].push_back((ok){i,v.y}),++in[i];
    topu();
    printf("%lld\n",dp[n]);
    fclose(stdin);fclose(stdout);
    return 0;
}
