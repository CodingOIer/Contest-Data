#include<bits/stdc++.h>
using namespace std;
int stk[10],tp;
inline void write(int x)
{
    if(!x) return putchar('0'),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
}
const int N=1e5+10;
int T,n,m,a[N];
int main()
{
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    scanf("%d",&T);
L:  while(T--)
    {
        scanf("%d%d",&n,&m);
        if(n==1) {puts("-1");continue;}
        if(n&1)
        {
            if(n==m) {puts("-1");continue;}
            if(n==3)
            {
                for(int i=1,x,y;i<min(m-1,10);i++)
                {
                    x=(m-i)/2,y=m-i-x;
                    for(int j=x;j&&x-j<10;j--,y++)
                        if((i^j^y)<min({i,j,y}))
                        {
                            write(i),putchar(' ');
                            write(j),putchar(' ');
                            write(y),putchar('\n');
                            goto L;
                        }
                }
                puts("-1");
                continue;
            }
            if(m&1)
            {
                m-=(13+(n-3));
                if(m<=0) {puts("-1");continue;}
                write(3),putchar(' ');
                write(6),putchar(' ');
                write(4),putchar(' ');
                for(int i=1;i<=n-3;i++) a[i]=1;
                for(int i=31;i;i--)
                    if(m>>i&1) a[1]+=(m>>(i-1)),a[2]+=(m>>(i-1));
                for(int i=1;i<=n-3;i++)
                    write(a[i]),putchar(i==n-3?'\n':' ');
            }
            else
            {
                if(m-6<n-3) {puts("-1");continue;}
                for(int i=1;i<=3;i++)
                    write(i),putchar(' ');
                m-=6,n-=3;
                if(!n) putchar('\n');
                for(int i=1;i<=n;i++)
                    write(m/n+(m%n>=i)),putchar(i==n?'\n':' ');
            }
        }
        else
        {
            if(m&1)
            {
                if(n==2)
                {
                    if(((m/2)^(m/2+1))>=(m/2)) {puts("-1");continue;}
                    write(m/2),putchar(' '),
                    write(m/2+1),putchar('\n');
                    continue;
                }
                for(int i=1;i<=n-3;i++) a[i]=2;
                a[n-2]=3;
                m--,m-=(n-2)*2;
                if(m<=2) {puts("-1");continue;}
                a[n-1]=a[n]=m/2;
                for(int i=1;i<=n;i++)
                    write(a[i]),putchar(i==n?'\n':' ');
            }
            else
                for(int i=1;i<=n;i++)
                    write(m/n+(m%n>=i)),putchar(i==n?'\n':' ');
        }
    }
     fclose(stdin);fclose(stdout);
    return 0;
}
