#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int P=998244353;
int M,K,A[5010],N,f[5010][5010],Ans;

int Power(int x,int d,int r=1){
    while(d){if(d&1) (r*=x)%=P; (x*=x)%=P,d>>=1;}
    return r;
}

void Add(int &x,int y){x+=y; if(x>=P) x-=P;}

void DFS(int A,int B,int w){
    if(!B) return Add(Ans,w),void();
    if(!A) return;
    DFS(A-1,B,w*(A*Power(A+B,P-2)%P)%P);
    DFS(A-1,B-1,w*(B*Power(A+B,P-2)%P)%P);
}

signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    M=read(); K=read(); For(i,1,K) A[i]=read();
    if(K==1){
        if((N=A[1])<=M) pc('0'),exit(0);
        DFS(N-1,M,1);
        // f[0][N]=1;
        // For(i,1,M){
        //     For(j,0,N) Add(f[i][j],f[i-1][j+1]);
        //     Rof(j,N,1) if(f[i][j]){
        //         Add(f[i][j-1],f[i][j]*(j*Power(j+(M-i+1),P-2)%P)%P);
        //     }
        // }
        // For(i,1,N) Add(Ans,f[M][i]);
        write(Ans);
    }
    return 0;
}
/*
g++ game.cpp -o game -O2
./game
*/