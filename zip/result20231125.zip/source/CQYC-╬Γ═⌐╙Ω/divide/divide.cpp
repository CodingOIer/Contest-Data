#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

int T,N,M;

void Solve(){
    N=read(),M=read();
    // write(N),pc(' '),write(M),pc('\n');
    if(N&1){
        if(N==1) return puts("-1"),void();
        if(N==3){
            if(M&1){
                puts("-1");
            }else{
                if(M==4||M==8) return puts("-1"),void();
                int a=0,b=0;
                if(M%4==2) a=(M>>1)-1,b=M>>1;
                else a=(M-2)/2-1,b=a+1;
                write(a),pc(' '),write(b),pc(' '),write(M-a-b),pc('\n');
            }
        }else{
            if(M&1){
                puts("-1");
            }else{
                int tt=M-6;
                if(tt<(N-3)) return puts("-1"),void();
                For(i,1,N-5) printf("1 ");
                int cc=(tt-(N-5))>>1;
                write(cc),pc(' '),write(cc),printf(" 1 2 3\n");
            }
        }
    }else{
        if(M&1){
            if(N==2){
                int lg=log2(M+1);
                if((1<<lg)==M+1) puts("-1");
                else write(M>>1),pc(' '),write((M>>1)+1),pc('\n');
                return;
            }
            if(M/N==1) return puts("-1"),void();
            int tt=M-5;
            if(tt<(N-2)*2) return puts("-1"),void();
            For(i,1,N-4) printf("2 ");
            int cc=(tt-(N-4)*2)>>1;
            write(cc),pc(' '),write(cc),printf(" 2 3\n");
        }else{
            For(i,1,N-2) printf("1 ");
            write((M-(N-2))>>1),pc(' '),write((M-(N-2))>>1),pc('\n');
        }
    }
}

int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    T=read();  // write(T),pc('\n');
    while(T--) Solve();
    return 0;
}
/*
g++ divide.cpp -o divide -O2
./divide
*/