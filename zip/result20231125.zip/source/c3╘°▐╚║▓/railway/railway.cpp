#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,m;
int dis[1000005];
int d[1000005];
int c[1000005];
vector<pair<int,int> >q[1000005];
void dijkstra(){
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >gg;
	gg.push({0,1});
	memset(dis,0x3f,sizeof(dis));
	dis[1]=0;
	d[1]=0;
	while(!gg.empty()){
		pair<int,int >e=gg.top();
		gg.pop();
		int u=e.second,w=-e.first;
		for(auto edge:q[u]){
			int v=edge.first,val=edge.second;
			if(dis[v]>dis[u]+val){
				dis[v]=dis[u]+val;
				d[v]=d[u]+val*val;
				gg.push({-dis[v],v});
			}
			else if(dis[v]==dis[u]+val){
				if(d[v]<d[u]+val*val) gg.push({-dis[v],v});
				d[v]=max(d[v],d[u]+val*val);
			}
		}
	}
}
signed main(){
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		int s=read();
		c[0]=read();
		for(int i=1;i<=s;i++){
			int t=read();
			c[i]=read();
			q[c[i-1]].push_back({c[i],t});
		}
	}
	dijkstra();
	cout<<dis[n]<<" "<<d[n];
	return 0;
} 
/*
what is the mean?
*/
