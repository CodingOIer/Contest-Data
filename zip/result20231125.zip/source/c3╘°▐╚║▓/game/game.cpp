#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
const int Mod=998244353;
int m,k;
int a[100005];
int dp[5005][5005];
int inv[100005];
int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1) res=(res*a)%Mod;
		a=(a*a)%Mod;
		b>>=1;
	}
	return res;
}
int jyh[5005][5005];
int dfs(int x,int y){
	if(x==0) return jyh[x][y]=1;
	if(y==0) return jyh[x][y]=0;
	if(x>y) return 0;
	if(jyh[x][y])return jyh[x][y];
	return jyh[x][y]=(inv[x+y]*x%Mod*dfs(x-1,y-1)%Mod+inv[x+y]*y%Mod*dfs(x,y-1)%Mod)%Mod;
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	m=read();k=read();
	for(int i=1;i<=k;i++){
		a[i]=read();
	}
	if(k==1){
		if(m>a[1]){
			cout<<0;
			return 0;
		}
		for(int i=1;i<=50000;i++){
			inv[i]=ksm(i,Mod-2);
		}
		for(int i=1;i<=10;i++){
			for(int j=1;j<=10;j++){
				jyh[i][j]=dfs(i,j);
			}
		}
		cout<<dfs(m,a[1]-1)%Mod;
	}
	else{
		cout<<0;
	}
	return 0;
} 
/*
I can't reply.

*/
