#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
signed main(){
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	int T=read();
	while(T--){
		int n=read(),m=read();
		if(n==1){
			printf("-1\n");
			continue;
		} 
		if(n==2){
			if(((m/2)^(m-m/2))<m/2){
				printf("%lld %lld\n",m/2,m-m/2);
				continue;
			}
			bool flag=0;
			for(int i=max(m/2-1000,0ll);i<=m/2+1;i++){
				if(m-i>=0&&(i^(m-i))<min(i,m-i)){
					printf("%lld %lld\n",i,m-i);
					flag=1;
					break;
				}
			}
			if(!flag) printf("-1\n");
			continue;
		}
		if(n==3){
			bool flag=0;
			for(int i=1;i<=min(100ll,m);i++){
				if(((((m-i)/2)^(m-i-(m-i)/2))^i)<min(min((m-i)/2,i),m-i-(m-i)/2)){
					printf("%lld %lld %lld\n",i,(m-i)/2,(m-i-(m-i)/2));
					flag=1;
					break;
				}
			}if(flag) continue;
			for(int i=1;i<=min(100ll,m);i++){
				if((m-i)/2-1<=0) continue;
				if(((((m-i)/2-1)^(m-i-(m-i)/2+1))^i)<min(min((m-i)/2-1,i),m-i-(m-i)/2+1)){
					printf("%lld %lld %lld\n",i,(m-i)/2-1,(m-i-(m-i)/2+1));
					flag=1;
					break;
				}
			}
			if(!flag){
				printf("-1\n");
			}
			continue;
		}
		if(n>m||n==1){
			printf("-1\n");
			continue;
		}
		if(n%2==m%2){
			if(n%2==0){
				for(int i=2;i<=n/2;i++){
					printf("1 1 ");
				}
				printf("%lld ",(m-n)/2+1);
				printf("%lld ",(m-n)/2+1);
				printf("\n");
			}
			else{
//				printf("1 2 3");
//              3 4 7 2 3
				if(n==5){
					if(m==19){
						printf("3 4 7 2 3\n");
						continue;
					}
					
					if(m>19&&(((m-14)/2)^((m-14)/2+1))<3) printf("3 4 7 %lld %lld",(m-14)/2,(m-14)/2+1);
					else{
						printf("-1\n");
					}
					continue;
				}
				if(n<5||m<19+(n-5)*2)printf("-1\n");
				else{
					printf("3 4 7 2 3 ");//1 2 5 0 1
					for(int i=2;i<=(n-5)/2;i++){
						printf("2 2 ");
					}
					if(n!=5) printf("%lld %lld",(m-2*n+4-9)/2,(m-2*n+4-9)/2);
					printf("\n");
				}
			} 
		}
		else{
			if(n%2==0&&m%2==1){
				if(n*2+1<=m){
					printf("2 3 ");
					if(n>2)
					for(int i=2;i<=n/2-1;i++){
						printf("2 2 ");
					}
					if(n>2)printf("%lld %lld",(m-n*2+3)/2,(m-n*2+3)/2);
					
					printf("\n");
				}
				else{
					printf("-1\n");
					continue;
				}
			}
			else{
				if(m-6<n-3){
					printf("-1\n");
					continue;
				}
				printf("1 2 3 ");
				for(int i=2;i<=(n-3)/2;i++){
					printf("1 1 ");
				}
				printf("%lld %lld\n",(m-n-1)/2,(m-n-1)/2);
			} 
		}
	}
	return 0;
} 
/*
n%2=0  7+2+1==40;
m%2=0 2+3=20
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19
76 points.

*/
