#include <bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=1e6+5;
int n,m;
vector<pair<int,int> >e[N]; 
int dis[N];
void dijkstra(int s){
    priority_queue<pair<int,int> >q;
    memset(dis,0x3f,sizeof(dis));
    dis[s]=0;
    q.push(make_pair(0,s));
    while(!q.empty()){
        int u=q.top().second;
        q.pop();
        for(auto [v,w]:e[u]){
            if(dis[v]>dis[u]+w){
                dis[v]=dis[u]+w;
                q.push(make_pair(-dis[v],v));
            }
        }
    }
}
int dp[N],d[N];
vector<pair<int,int> > g[N];
queue<int> q;
signed main(){
    freopen("railway.in","r",stdin);
    freopen("railway.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        int s=read();
        int st=read();
        while(s--){
            int x=read(),y=read();
            e[st].push_back({y,x});
            st=y;
        }
    }
    dijkstra(1);
    for(int i=1;i<=n;i++)
        for(auto j:e[i])
            if(dis[i]+j.second==dis[j.first]) g[i].push_back(make_pair(j.first,j.second)),d[j.first]++;
    for(int i=1;i<=n;i++)
        if(d[i]==0) q.push(i);
    while(!q.empty()){
        int x=q.front();
        q.pop();
        for(auto [y,v]:g[x]){
            d[y]--;
            if(d[y]==0) q.push(y);
            dp[y]=max(dp[y],dp[x]+v*v);
        }
    }
    for(int i=1;i<=n;i++) cout<<dp[i]<<"\n";
    cout<<dis[n]<<" "<<dp[n]<<"\n";
    return 0;
}