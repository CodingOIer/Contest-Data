#include <bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=5005,mod=998244353,inv2=499122177;
void add(int &x,int y){
    x=(x+y)%mod;
}
int m,n,a[N],jc[N*2],inv[N*2];
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=ans*x%mod;
        x=x*x%mod;
        base>>=1;
    }
    return ans;
}
namespace sub1{
    int dp[N][N],ans;
    int mian(){
        int x=m,y=a[1];
        dp[x][y]=1;
        for(int i=x;i;i--){
            int res=0;
            for(int j=y;~j;j--){
                add(dp[i-1][j],res*inv[j]%mod*jc[i+j-1]%mod*i%mod);
                add(res,dp[i][j]*jc[j-1]%mod*inv[i+j-1]%mod);
            }
        }
        for(int i=0;i<x;i++) add(ans,dp[i][0]);
        cout<<(1-ans+mod)%mod;
        return 0;
    }
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    jc[0]=1;
    for(int i=1;i<N*2;i++) jc[i]=jc[i-1]*i%mod;
    inv[N*2-1]=pow(jc[N*2-1],mod-2);
    for(int i=N*2-2;~i;i--) inv[i]=inv[i+1]*(i+1)%mod;
    m=read(),n=read();
    for(int i=1;i<=n;i++) a[i]=read();
    sub1::mian();
    return 0;
}