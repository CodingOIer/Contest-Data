#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int t,n,m,res;
bitset<30> b;
vector<int> ans;
int solve_even(int n,int m){
    int now=1,res=0;
    ans.clear();
    while(m>=1ll*now*n) now<<=1;
    now>>=1;
    m-=now*n;
    while(m>=2ll*now) m-=2ll*now,res+=2;
    int kkk=0,minn=1e9;
    for(int i=1;i<=n;i++){
        ans.push_back(now+min(m,now-1)+(i<=res?now:0));
        m-=min(m,now-1);
        kkk^=ans.back();
        minn=min(minn,ans.back());
    }
    if(m||kkk>=minn||res>n) return m;
    return 0;
}
#define re0 {cout<<"-1\n";return ;}
void solve3(int n,int m){
	if(m<3) re0;
	int a=0,b=0,c=0;
	for(c=1;c<=7;c++){
		a=0,b=0;
		m--;
		int tmp=m;
		if(m<3) re0;
		for(int i=30;~i;i--){
			if(tmp>>i&1){
				if((tmp&((1<<(i+1))-1))==(1<<(i+1))-1){
					if(!a) a|=(1<<(i+1))-1;
					else b|=(1<<(i+1))-1;
					break;
				}
				if(i>1&&(c>>(i-1)&1)&&!(tmp>>(i-1)&1)){
					if(!b) b|=1<<(i-1);
					else a|=1<<(i-1);
					tmp|=1<<(i-1);
				}
				else a|=1<<(i-1),b|=1<<(i-1);
			}
        }
        if((a^b^c)<min(min(a,b),c)){
            cout<<a<<" "<<b<<" "<<c<<"\n";
            return;
        }
	}
    if((a^b^c)<min(min(a,b),c)) cout<<a<<" "<<b<<" "<<c<<"\n";
    else re0;
}
void solve_odd(){
    if(n==1){
        cout<<"-1\n";
        return;
    }
    if(n==3){
        solve3(n,m);
        return;
    }
    for(int i=0;(1<<i)*n<=m-(1<<i);i++){
        int cnt=0,res=0,x=0,bj=0;
        int k=solve_even(n-1,m-(2<<i));
        if(k>=1<<i) continue;
        x=(1<<i)+k;
        solve_even(n-1,m-x-(1<<i));
        for(auto j:ans){
            cnt+=(j&(1<<i))!=0;
            res+=(j<(1<<i)?j:0);
            if(j<(1<<i)){
                bj=1;
                break;
            }
        }
        if(bj) continue;
        if(cnt&1){
            for(auto &j:ans)
                if(!(j&(1<<i))) j|=1<<i;
                
            int kkk=0,minn=1e9;
            for(auto j:ans){
                minn=min(minn,j);
                kkk^=j;
            }
            minn=min(x,minn);
            kkk^=x;
            if(kkk>=minn) continue;

            for(auto j:ans) cout<<j<<" "; 
            cout<<x<<"\n";
            return;
        }
        else{
            if(cnt==n-1) continue;
            for(auto &j:ans)
                if(!(j&(1<<i))){
                    j|=(1<<i);
                    break;
                }
            int kkk=0,minn=1e9;
            for(auto j:ans){
                minn=min(minn,j);
                kkk^=j;
            }
            minn=min(x,minn);
            kkk^=x;
            if(kkk>=minn) continue;
            for(auto j:ans) cout<<j<<" ";
            cout<<x<<"\n";
            return;
        }
    }
    cout<<"-1\n";
}
void solve(){
    res=0;
    n=read(),m=read();
    if(n&1) solve_odd();
    else{
        if(!solve_even(n,m)) for(auto i:ans) cout<<i<<" ";
        else cout<<-1;
        cout<<"\n";
    }
}
int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    t=read();
    while(t--) solve();
    return 0;
}