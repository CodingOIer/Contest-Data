#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <vector>
#define int long long
using namespace std;
#ifdef ONLOINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

namespace Subtask1 {

void main(int n, int m) {
	puts("-1");
	return;
}

}

namespace Subtask2 {

void main(int n, int m) {
	if (~m & 1) {
		write(m / 2), putchar(32);
		write(m / 2), puts("");
		return;
	}
	int ans1 = 0, ans2 = 0, tp = 0;
	bool flg = false;
	while (m) {
		/* write(m), puts(""); */
		if (!(m & 1) && !flg) m >>= 1, flg = 1;
		ans1 += (m & 1) << tp;
		if (flg)
			ans2 += (m & 1) << tp;
		m >>= 1, tp++;
	}
	if (flg) {
		write(ans1), putchar(32);
		write(ans2), puts("");
		return;
	}
	puts("-1");
	return;
}

}

namespace Subtask3 {

const int N = 1e5 + 5;

vector <int> isl;
array <int, N> ans, fac;
void main(int n, int m) {
	fac[0] = 1;
	for (int i = 1; i <= 100; i++) {
		fac[i] = fac[i - 1] * n;
		if (fac[i] > m) break;
	}
	isl.clear();
	while (m) {
		isl.push_back(m % n);
		m /= n;
	}
	bool flg = false;
	int tp = 0;
	for (int i = 1; i <= n; i++)
		ans[i] = 0;
	for (int i = 0; i < (int)isl.size(); i++) {
		if (i + 1 < (int)isl.size() && isl[i] < isl[i + 1] && !flg) {
			/* for (int j = 1; j <= isl[i]; j++) */
			ans[1] = ans[1] + isl[i] * fac[tp];
			flg = 1, i++;
		}
		ans[1] = ans[1] + isl[i] * fac[tp];
		if (flg)
			for (int j = 2; j <= n; j++)
				ans[j] = ans[j] + isl[i] * fac[tp];
		tp++;
	}
	if (!flg) {
		puts("-1");
		return;
	}
	for (int i = 1; i <= n; i++)
		write(ans[i]), putchar(32);
	puts("");
	return;
}

}

signed main() {
	freopen("divide.in", "r", stdin);
	freopen("divide.out", "w", stdout);
	int T = read();
	while (T--) {
		int n = read(), m = read();
		if (n == 1) Subtask1::main(n, m);
		/* if (n == 2) Subtask2::main(n, m); */
		if (n >= 2) Subtask3::main(n, m);
	}
	return 0;
}
