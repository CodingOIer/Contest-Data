#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define int long long
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 1e5 + 5, M = 505, mod = 998244353;
array <int, N> s;

int f[5005][5005][2];

void Mod(int &x) {
	if (x >= mod) x -= mod;
	if (x < 0) x += mod;
}

int pow_(int x, int k, int p) {
	int ans = 1;
	while (k) {
		if (k & 1) ans = ans * x % p;
		x = x * x % p;
		k >>= 1;
	}
	return ans;
}

array <int, N> fac, inv;

void init() {
	int n = 1e5;
	for (int i = 1; i <= n; i++)
		inv[i] = pow_(i, mod - 2, mod);
}


void update(int &x, int y) {
	x += y, Mod(x);
}

signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int m = read(), n = read();
	int n1 = 0;
	for (int i = 1; i <= n; i++)
		s[i] = read(), n1 += s[i];
	int ans = 0;
	init();
	f[n1][m][0] = 1;
	for (int i = n1; i; i--) {
		for (int j = m; ~j; j--) {
			int tp1 = f[i][j][0], tp2 = f[i][j][1];
			if (i) update(f[i - 1][j][1], tp1);
			if (i) update(f[i - 1][j][1], tp2 * inv[i + j] % mod * i % mod);
			if (j) update(f[i][j - 1][0], tp2 * inv[i + j] % mod * j % mod);
		}
		ans += f[i][0][0], Mod(ans);
	}
	/* write(inv[4]), putchar(32); */
	/* write(f[2][0][0]), puts("@"); */
	write(ans), puts("");

	return 0;
}
