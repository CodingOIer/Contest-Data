#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <queue>
#include <bitset>
#define int long long
#define pii pair <int, int>
using namespace std;
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

const int N = 1e6 + 5;

namespace G {

array <int, N> fir;
array <int, N * 4> nex, to, len;
int cnt;
void add(int x, int y, int z) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	len[cnt] = z;
	fir[x] = cnt;
}

}
namespace T {

array <int, N> fir;
array <int, N * 4> nex, to, len;
int cnt;
void add(int x, int y, int z) {
	write(x), putchar(32);
	write(y), putchar(32);
	write(z), puts("");
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	len[cnt] = z;
	fir[x] = cnt;
}

}

priority_queue <pii, vector <pii>, greater <pii> > q;
array <int, N> dis, cur;
bitset <N> vis;

void dijkstra() {
	dis.fill(1e18), cur.fill(1e18);
	vis = 0;
	dis[1] = 0, cur[1] = 0;
	q.push(make_pair(dis[1], 1));
	while (!q.empty()) {
		int u = q.top().second;
		q.pop();
		if (vis[u]) continue;
		vis[u] = 1;
		for (int i = T::fir[u]; i; i = T::nex[i]) {
			if (dis[T::to[i]] <= dis[u] + T::len[i]) continue;
			dis[T::to[i]] = dis[u] + T::len[i];
			cur[T::to[i]] = cur[u] + T::len[i] * T::len[i];
			q.push(make_pair(dis[T::to[i]], T::to[i]));
		}
	}
}

bitset <N> mark;

void dfs(int x, int Mgn, int sum) {
	if (vis[x]) return;
	vis[x] = 1;
	for (int i = G::fir[x]; i; i = G::nex[i]) {
		if (mark[G::to[i]]) {
			if (Mgn) T::add(Mgn, G::to[i], sum + G::len[i]);
			dfs(G::to[i], G::to[i], 0);
			continue;
		}
		dfs(G::to[i], Mgn, sum + G::len[i]);
	}
}

signed main() {
	freopen("railway.in", "r", stdin);
	freopen("railway.out", "w", stdout);
	int n = read(), m = read();
	for (int i = 1; i <= m; i++) {
		int k = read(), x = read();
		if (!vis[x]) vis[x] = 1;
		else mark[x] = 1;
		for (int j = 1; j <= k; j++) {
			int z = read(), y = read();
			if (!vis[y]) vis[y] = 1;
			else mark[y] = 1;
			G::add(x, y, z);
			x = y;
		}
	}
	mark[1] = mark[n] = 1;
	vis = 0;
	for (int i = 1; i <= n; i++)
		if (!vis[i]) dfs(i, mark[i], 0);
	dijkstra();
	write(dis[n]), putchar(32);
	write(cur[n]), puts("");
	return 0;
}
