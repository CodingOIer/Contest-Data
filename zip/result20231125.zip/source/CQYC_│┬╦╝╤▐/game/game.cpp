#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int m,k,n[5005],f[5005][5005][2];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int power(int a,int b){
    int res=1;
    while(b){
        if(b&1)
            res=res*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return res;
}
void add(int& a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    m=read(),k=read();
    for(int i=1;i<=k;i++)
        n[i]=read();
    if(k==1){
        f[m][n[1]][0]=1;
        for(int i=m;i>=0;i--)
            for(int j=n[1];j>=0;j--){
                if(j)
                    add(f[i][j][0],f[i+1][j][1]*(i+1)%mod*power((i+j+1)%mod,mod-2)%mod);
                if(i){
                    add(f[i][j][1],f[i][j+1][0]);
                    add(f[i][j][1],f[i][j+1][1]*(j+1)%mod*power((i+j+1)%mod,mod-2)%mod);
                }
            }
        int a=0;
        for(int i=1;i<=n[1];i++)
            add(a,f[0][i][0]);
        printf("%lld\n",a);
    }
    return 0;
}
