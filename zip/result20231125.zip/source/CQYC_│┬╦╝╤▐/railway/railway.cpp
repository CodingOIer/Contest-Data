#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e6+5;
int n,m,s,u,v,w,dis[maxn],val[maxn],vis[maxn];
vector<pair<int,int> > to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("railway.in","r",stdin);
    freopen("railway.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        s=read(),u=read();
        for(int j=1;j<=s;j++){
            w=read(),v=read();
            to[u].push_back({v,w});
            u=v;
        }
    }
    for(int i=1;i<=n;i++)
        dis[i]=1e18;
    priority_queue<pair<pair<int,int>,int> > q;
    dis[1]=0;
    q.push({{0,0},1});
    while(!q.empty()){
        int u=q.top().second;
        q.pop();
        if(u==n){
            printf("%lld %lld\n",dis[u],val[u]);
            return 0;
        }
        if(vis[u])
            continue;
        vis[u]=1;
        for(auto i:to[u]){
            int v=i.first;
            if(vis[v])
                continue;
            if(dis[v]>dis[u]+i.second){
                dis[v]=dis[u]+i.second;
                val[v]=val[u]+i.second*i.second;
                q.push({{-dis[v],val[v]},v});
            }
            else
                if(dis[v]==dis[u]+i.second&&val[v]<val[u]+i.second*i.second){
                    val[v]=val[u]+i.second*i.second;
                    q.push({{-dis[v],val[v]},v});
                }
        }
    }
    return 0;
}