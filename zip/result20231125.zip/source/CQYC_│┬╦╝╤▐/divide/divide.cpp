#include <bits/stdc++.h>
using namespace std;
int t,n,m;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    t=read();
    while(t--){
        n=read(),m=read();
        if(n==1){
            puts("-1");
            continue;
        }
        if(n==2){
            int a=m/2,b=m-a;
            if((a^b)<a&&(a^b)<b)
                printf("%d %d\n",a,b);
            else
                puts("-1");
            continue;
        }
        if(n==3){
            if(m%2==0){
                if(m/2%2)
                    printf("%d %d %d\n",1,m/2-1,m/2);
                else{
                    if(m<=8)
                        puts("-1");
                    else
                        printf("%d %d %d\n",3,m/2-2,m/2-1);
                }
            }
            else{
                int a=2,b=(m-2)/2,c=(m-2)/2+1;
                if(a&&b&&c&&(a^b^c)<a&&(a^b^c)<b&&(a^b^c)<c)
                    printf("%d %d %d\n",a,b,c);
                else
                    puts("-1");
            }
            continue;
        }
    }
    return 0;
}