#include<bits/stdc++.h>
#define pt pair<int,int>
#define pd pair<int,long long>
#define P pair<pd,pt >
#define ft first
#define sc second
using namespace std;
const int N=2005,M=6e5+5;
inline int read(int &x){
	x=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int head[N],nxt[M],w[M],id[M],to[M],tot;
inline void add(int s,int x,int y,int z){
	to[++tot]=y;
	nxt[tot]=head[x];
	id[tot]=s;
	w[tot]=z;
	head[x]=tot;
}
int n,m,scnt,a[N],sum,b[N];
pd dis[N][N],val,ans;
P t;
bool vis[N][N];
priority_queue<P,vector<P >,greater<P > > hp;
int main(){
	freopen("railway.in","r",stdin);
	freopen("railway.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=m;++i){
		read(scnt);
		read(a[1]);++scnt;
		for(int j=2;j<=scnt;++j) read(b[j]),read(a[j]);
		for(int j=1;j<scnt;++j){
			sum=0;
			for(int k=j+1;k<=scnt;++k){
				sum+=b[k];
				add(i,a[j],a[k],sum);
			}
		}
		for(int j=1;j<=n;++j) dis[i][j].ft=1.5e9;	
	}
	dis[0][1]={0,0};
	hp.push({dis[0][1],{1,0}});
	while(!hp.empty()){
		t=hp.top(),hp.pop();
		if(vis[t.sc.sc][t.sc.ft]) continue;
		vis[t.sc.sc][t.sc.ft]=1;
		for(int o=head[t.sc.ft],v;o;o=nxt[o]){
			if(id[o]==t.sc.sc) continue;
			v=to[o];val=dis[t.sc.sc][t.sc.ft];
			val.ft+=w[o],val.sc-=w[o]*w[o];
			if(dis[id[o]][v]>val){
				dis[id[o]][v]=val;
				hp.push({val,{v,id[o]}});
			}
		}
	}
	ans.ft=2e9;
	for(int i=1;i<=m;++i) ans=min(ans,dis[i][n]);
	printf("%d %lld",ans.ft,-ans.sc);
	return 0;
}
