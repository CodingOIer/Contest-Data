#include<bits/stdc++.h>
using namespace std;
inline int read(int &x){
	x=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int T,n,m,ans[300005];
void print(int x){
	if(x>9) print(x/10);
	putchar(48+x%10);
}
inline bool solve(){
	if(n==1) return 1;
	if(!(n&1)&&!(m&1)){
		if(n==2) ans[1]=ans[2]=m/2;
		else{
			for(int i=1;i<n-1;++i) ans[i]=1,--m;
			ans[n-1]=ans[n]=m/2;
		}return 0;
	}
	if((n&1)&&!(m&1)){
		if(n==3){
			for(int a=1;a<=4;++a){
				ans[1]=a;--m;
				for(int i=m/2,j=1;i>=a&&j<=30;--i,++j)
					if(m-i>=a&&(i^(m-i)^a)<a){
						ans[2]=i,ans[3]=m-i;
						return 0;
					}
			}
			return 1;
		}else if(m<n+3) return 1;
		else{
			ans[1]=1,ans[2]=2,ans[3]=3;
			m-=6;
			for(int i=4;i<n-1;++i) ans[i]=1,--m;
			ans[n-1]=ans[n]=m/2;
		}	
		return 0;
	}
	if(!(n&1)&&(m&1)){
		if(n==2){
			for(int i=m/2,j=1;j<=30&&i;++j,--i)
				if((i^(m-i))<min(m-i,i)){
					ans[1]=i,ans[2]=m-i;
					return 0;
				}
			return 1;
		}
		if(m<n*2+1) return 1;
		ans[1]=2,ans[2]=3;
		m-=5;
		for(int i=3;i<n-1;++i) ans[i]=2,m-=2;
		ans[n-1]=ans[n]=m/2;
		return 0;
	}
	if((n&1)&&(m&1)){
		if(n==3){
			--m;
			for(int a=2;a<=7;++a){
				ans[1]=a;--m;
				for(int i=m/2,j=1;i>=a&&j<=20;--i,++j)
					if(m-i>=a&&(i^(m-i)^a)<a){
						ans[2]=i,ans[3]=m-i;
						return 0;
					}
			}return 1;
		}
		if(m>=(n-3)*2+13){
			ans[1]=2,ans[2]=4,ans[3]=7;
			if(n>3){
				for(int i=4;i<n-1;++i) ans[i]=2;
				m-=(n-5)*2+13;
				ans[n-1]=ans[n]=m/2;
			}
			return 0;
		}
		return 1;
	}
	return 1;
}
int main(){
	freopen("divide.in","r",stdin);
	freopen("divide.out","w",stdout);
	read(T);
	while(T--){
		read(n),read(m);
		if(solve()) puts("-1");
		else{
			for(int i=1;i<=n;++i) print(ans[i]),putchar(' ');
			putchar('\n');
		}
	}
	return 0;
}

