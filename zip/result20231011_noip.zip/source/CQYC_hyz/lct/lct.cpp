#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

int n, m, tot;
int fa[N];

char s[N];

vector<int> e[N];

int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }

namespace sub1 {
    int cnt, ans, sum;
    int d[N], siz[N], w[N], g[N];

    bool vis[N];

    void dfs1(int x, int f) {
        for(int v : e[x]) if(v ^ f) dfs1(v, x), d[x] += d[v], siz[x] += siz[v];
        d[x] += siz[x], siz[x]++, ans += d[x], g[cnt]++;
    }

    void dfs2(int x, int f) {
        w[cnt] = max(w[cnt], d[x]); for(int v : e[x]) if(v ^ f) 
        d[v] = d[x] + g[cnt] - siz[v] - siz[v], dfs2(v, x);
    }

    void solve() {
        for(int i = 1; i <= n; i++) if(!vis[i]) cnt++, dfs1(i, 0), dfs2(i, 0);
        
        if(tot == 2) {
            write(ans + w[1] * g[2] + w[2] * g[1]), putchar('\n');
        }
    }
}

namespace sub2 {
    void solve() { puts("-1"); }
}

bool edmer;
signed main() {
	freopen("lct.in", "r", stdin);
	freopen("lct.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read(), scanf("%s", s + 1);

    for(int i = 1; i <= n; i++) fa[i] = i;

    for(int i = 1; i <= m; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u), fa[find(u)] = find(v);
    }

    for(int i = 1; i <= n; i++) if(find(i)) fa[find(i)] = 0, tot++;

    sub1 :: solve(), sub2 :: solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 