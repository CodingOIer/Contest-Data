#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10, mod = 998244353;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

int n, m, sum, ans;
int f[N], g[N];

bool edmer;
signed main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    
	for(int i = 1; i <= m; i++) f[i] = 1;

    for(int i = 1; i <= n; i++) {
        for(int j = m; j; f[j--] = 0) for(int k = j + j; k <= m; k += j) add(f[k], f[j]);
		
		for(int j = 1; j <= m; j++) add(g[i], f[j]);
		
		if(!g[i]) break; if(i & 1) g[i] = mod - g[i];
    } 

	f[0] = 1;

	for(int i = 0; i <= n; i++) {
		add(f[i + 1], 1ll * f[i] * m % mod);
		for(int j = 1; g[j] and i + j < n; j++) add(f[i + j + 1], 1ll * f[i] * g[j] % mod);
	}

    write(f[n]);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 