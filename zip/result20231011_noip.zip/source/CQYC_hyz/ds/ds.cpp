#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e6 + 10;

struct node {
    int x, y;
    bool operator < (const node &p) const { return x == p.x ? y > p.y : x < p.x; }
} a[N];

struct oper {
    int u, r, d, l, id;
    bool operator < (const oper &p) const { return u < p.u; }
} op[N];

int n, q;
int ans[N];

namespace sub1 {
    int stk[N], top;

    void solve() {
        for(int i = 1; i <= q; i++) {
            int u = op[i].u, r = op[i].r, d = op[i].d, l = op[i].l;
            int L = lower_bound(a + 1, a + n + 1, (node) { d, n + 1 }) - a;
            top = 0;
            for(int j = L; j <= n and a[j].x <= u; j++) {
                if(a[j].y < l or a[j].y > r) continue;
                while(top and a[j].x > a[stk[top]].x and a[j].y > a[stk[top]].y) top--;
                stk[++top] = j;
            }
            ans[op[i].id] = top;
        }

        for(int i = 1; i <= q; i++) write(ans[i]), putchar('\n');
    }
}

bool edmer;
signed main() {
	freopen("ds.in", "r", stdin);
	freopen("ds.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), q = read();

    for(int i = 1; i <= n; i++) a[i].x = read();
    for(int i = 1; i <= n; i++) a[i].y = read();

    for(int i = 1; i <= q; i++) op[i] = { read(), read(), read(), read(), i };

    sort(a + 1, a + n + 1), sort(op + 1, op + q + 1);

    // if(max(n, q) <= 1e4) 
    sub1 :: solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 