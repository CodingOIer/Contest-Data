#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,M,s[100005],inv[100005],a[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
inline int C(int x,int y){
    if(x<y) return 0;
    int s1=s[x],s2=inv[y],s3=inv[x-y];
    s2=(s2*s3)%M;
    s1=(s1*s2)%M;
    return s1;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void del(int &x,int y){
    if(x<y) x=x-y+M;
    else x-=y;
}
signed main(){
    freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
    n=read(),M=read();
    s[0]=inv[0]=1;
    for(int i=1;i<=10000;i++) s[i]=(s[i-1]*i)%M,inv[i]=ksm(s[i],M-2);
    if(n&1){
        cout<<s[n];
    }
    else{
        a[0]=1;a[1]=1;
    for(int i=2;i<=n;i++){
        int d=(i+1)/2;
        for(int j=1;j<=d;j++){
            if(j&1) add(a[i],C(i+1,j*2)*a[i-j]%M);
            else del(a[i],C(i+1,j*2)*a[i-j]%M);
        }
    }
    int t=ksm(2,n-1)*a[n/2-1]%M;
    cout<<(s[n]-t+M)%M<<"\n";
    }
    
    return 0;
}
/*
1 1                      0
1= 1                     2
3=C()                 4
17=C(4,2)*3-1*(C(4,0)||C(4,4))                6
155=C(6,2)*17-C(6,4)*3+C(6,6)*1                  8
2073                                  10
*/
