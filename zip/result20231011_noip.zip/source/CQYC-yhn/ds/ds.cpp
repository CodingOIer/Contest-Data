#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,t1,t2,t3,t4,Q[1000005],cnt,a[1000005],b[1000005],ans;
vector<int> e[1000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++) b[i]=read();
    for(int i=1;i<=n;i++) e[a[i]].push_back(b[i]);
    for(int i=1;i<=q;i++){
        t1=read(),t2=read(),t3=read(),t4=read();
        cnt=ans=0;
        for(int j=t1;j>=t3;j--){
            int mx=0;
            for(int g=0;g<(int)e[j].size();g++){
                if(e[j][g]>t2||e[j][g]<t4) continue;
                if(cnt>0&&Q[cnt]>e[j][g]) continue;
                ans++;
                mx=max(mx,e[j][g]);
            }
            if(mx>0) Q[++cnt]=mx;
        }
        cout<<ans<<"\n";
    }
    return 0;
}