#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,t,A[15],ans=0,dis[100005];
char a[100005];
vector<int> e[100005],E[3];
queue<int> q;
bool v[100005];
struct ok{
    int x,y;
}b[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void cl(){
    for(int i=1;i<=n;i++) e[i].clear();
}
inline void add(int x,int y){
    e[x].push_back(y);
    e[y].push_back(x);
}
inline void init(){
    cl();
    for(int i=1;i<=m;i++) add(b[i].x,b[i].y);
}
inline void dfs(int k){
    E[t].push_back(k);
    for(int i=0;i<(int)e[k].size();i++){
        if(!v[e[k][i]]){
            v[e[k][i]]=1;
            dfs(e[k][i]);
        }
    }
}
inline void solve(){
    int tot=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++) dis[j]=-1;
        q.push(i);
        dis[i]=0;
        while(!q.empty()){
            int t=q.front();q.pop();
            for(int j=0;j<(int)e[t].size();j++){
                if(dis[e[t][j]]==-1){
                    dis[e[t][j]]=dis[t]+1;
                    tot+=dis[e[t][j]];
                    q.push(e[t][j]);
                }
            }
        }
    }
    ans=max(ans,tot/2);
}
inline void dfs2(int k){
    if(k==t){
        init();
        add(A[0],A[1]);
        solve();
        return;
    }
    for(int i=0;i<(int)E[k].size();i++){
        A[k]=E[k][i];
        dfs2(k+1);
    }
}
signed main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    n=read(),m=read();
    scanf("%s",a+1);
    for(int i=1;i<=m;i++) b[i].x=read(),b[i].y=read();
    init();
    t=0;
    for(int i=1;i<=n;i++){
        if(!v[i]){
            dfs(i);
            t++;
        }
    }
    dfs2(0);
    cout<<ans<<"\n-1";
    return 0;
}