#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,m,f[2][200005],ans=0;
vector<int> e[200005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void del(int &x,int y){
    if(x<y) x=x-y+M;
    else x-=y;
}
signed main(){
   freopen("sequence.in","r",stdin);
   freopen("sequence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++) e[i].push_back(0);
    for(int i=1;i<=m;i++){
        for(int j=i+i;j<=m;j+=i) e[j].push_back(i);
    }
    for(int i=1;i<=m;i++) e[i].push_back(m+1);
    f[1][0]=1;
    for(int i=1;i<=n;i++){
        int t=i&1; 
        for(int j=0;j<=m;j++) f[t^1][j]=0;
        for(int j=1;j<=m;j++){
            add(f[t][j],f[t][j-1]);
            for(int g=1;g<(int)e[j].size();g++){
                if(e[j][g-1]<e[j][g]){
                    add(f[t^1][e[j][g-1]+1],f[t][j]);
                    del(f[t^1][e[j][g]],f[t][j]);
                }
            }
        }
    }
    for(int i=1;i<=m;i++) add(ans,f[n&1][i]);
    cout<<ans;
    return 0;
}
