#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4,P=998244353;
int f[2][NN];
vector<int>g[NN];
int main()
{
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
        for(int j=2;1ll*i*j<=m;j++)
			g[i*j].push_back(i);
    for(int i=1;i<=m;i++)
		f[1][i]=1;
    for(int i=1;i<n;i++)
	{
        int res=0;
        for(int j=1;j<=m;j++)
			res=(res+f[i&1][j])%P;
        for(int j=1;j<=m;j++)
			f[i&1^1][j]=res;
        for(int j=1;j<=m;j++)
        	for(int k=0;k<g[j].size();k++)
        	{
        		int v=g[j][k];
				f[i&1^1][v]=(f[i&1^1][v]-f[i&1][j]+P)%P;
			}
    }
    int res=0;
    for(int j=1;j<=m;j++)
		res=(res+f[n&1][j])%P;
	printf("%d",res);
    return 0;
}
