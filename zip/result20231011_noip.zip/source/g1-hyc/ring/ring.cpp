#include<bits/stdc++.h>
using namespace std;
const int NN=20;
int f[NN+4][1<<NN];
int main()
{
	freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
	int n,P;
	scanf("%d%d",&n,&P);
	int res=1;
	for(int i=1;i<=n;i++)
		res=1ll*res*i%P;
	if(n&1)
	{
		printf("%d",res);
		return 0;
	}
	f[0][0]=1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<1<<n;j++)
			if(f[i-1][j])
				for(int k=0;k<n;k++)
					if(!(j>>k&1)&&!((j>>(k+n-1)%n&1)^(j>>(k+1)%n&1)))
						f[i][j^1<<k]=(f[i][j^1<<k]+f[i-1][j])%P;
	printf("%d",(res-f[n][(1<<n)-1]+P)%P);
	return 0;
}
