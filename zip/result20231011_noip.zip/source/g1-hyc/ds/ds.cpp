#include<bits/stdc++.h>
using namespace std;
const int NN=1e4+4;
int x[NN],y[NN],s[NN][NN];
int main()
{
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
	int n,q;
	scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)
    	scanf("%d",&x[i]);
    for(int i=1;i<=n;i++)
    	scanf("%d",&y[i]);
    for(int i=1;i<=n;i++)
        s[x[i]][y[i]]++;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            s[i][j]=s[i][j]+s[i][j-1]+s[i-1][j]-s[i-1][j-1];
    while(q--)
	{
        int u,r,d,l,ans=0;
        scanf("%d%d%d%d",&u,&r,&d,&l);
        for(int i=1;i<=n;i++)
            if(d<=x[i]&&x[i]<=u&&l<=y[i]&&y[i]<=r&&!(s[u][r]-s[x[i]][r]-s[u][y[i]]+s[x[i]][y[i]]))
                ans++;
        printf("%d\n",ans);
    }
    return 0;
}
