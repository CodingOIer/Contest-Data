#include<bits/stdc++.h>
using namespace std;
const int N=1e4+5;
// char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,m,fa[N],rt[5],sz[N],dis[N],ans[N],root[N],cnt;
vector<int> g[N];
void dfs1(int x){
    sz[x]=1;
    for(auto y:g[x]){
        if(y==fa[x]) continue;
        fa[y]=x;
        dfs1(y);
        sz[x]+=sz[y];
        dis[x]=dis[y]+sz[y];
    }
}
void dfs2(int x,int rt){
    root[x]=rt;
    ans[x]=ans[fa[x]]-dis[x]-sz[x]+(sz[rt]-sz[x])+dis[x];
    for(auto y:g[x]){
        if(y==fa[x]) continue;
        dfs2(y,rt);
    }
}
int main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    int n=read(),m=read();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        if(!fa[i]) dfs1(rt[++cnt]=i);
    }
    ans[rt[1]]=dis[rt[1]];
    ans[rt[2]]=dis[rt[2]];
    for(auto y:g[rt[1]]) dfs2(y,rt[1]);
    for(auto y:g[rt[2]]) dfs2(y,rt[2]);
    // for(int i=1;i<=n;i++) cout<<i<<" "<<root[i]<<" "<<ans[i]<<"\n";
    int anss=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(root[i]!=root[j]) anss=max(anss,ans[i]*sz[root[j]]+ans[j]*sz[root[i]]);
        }
    }
    cout<<anss*2<<"\n";
    return 0;
}