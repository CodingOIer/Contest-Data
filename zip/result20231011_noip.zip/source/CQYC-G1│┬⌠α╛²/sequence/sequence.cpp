#include <bits/stdc++.h>
using namespace std;
const int N=2005,M=1e5+5,mod=998244353;
int n,m,dp[2][M];
vector<int> g[M];
int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=m;i++)
        for(int j=2;j*i<=m;j++) g[j*i].push_back(i);
    for(int i=1;i<=m;i++) dp[1][i]=1;
    for(int i=1;i<n;i++){
        int sum=0;
        for(int j=1;j<=m;j++) sum=(sum+dp[i&1][j])%mod;
        for(int j=1;j<=m;j++) dp[i&1^1][j]=sum;
        for(int j=1;j<=m;j++)
            for(auto k:g[j]) dp[i&1^1][k]=(dp[i&1^1][k]-dp[i&1][j]+mod)%mod;
    }
    int sum=0;
    for(int j=1;j<=m;j++) sum=(sum+dp[n&1][j])%mod;
    cout<<sum;
    return 0;
}