#include<bits/stdc++.h>
using namespace std;
const int N=1e4+5;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n,q,sum[N][N];
struct point{
    int x,y;
}a[N];
int query(int x1,int y1,int x2,int y2){
    return sum[x2][y2]-sum[x1-1][y2]-sum[x2][y1-1]+sum[x1-1][y1-1];
}
int main(){
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<=n;i++) a[i].x=read();
    for(int i=1;i<=n;i++) a[i].y=read();
    for(int i=1;i<=n;i++) sum[a[i].x][a[i].y]++;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            sum[i][j]+=sum[i-1][j];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            sum[i][j]+=sum[i][j-1];
    while(q--){
        int U=read(),R=read(),D=read(),L=read(),ans=0;
        for(int i=1;i<=n;i++){
            if(D<=a[i].x&&a[i].x<=U&&L<=a[i].y&&a[i].y<=R&&!query(a[i].x+1,a[i].y+1,U,R)) ans++;
        }
        cout<<ans<<"\n";
    }
    return 0;
}