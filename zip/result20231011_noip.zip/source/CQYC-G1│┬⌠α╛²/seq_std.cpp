#include <bits/stdc++.h>
using namespace std;
const int N=2005,M=1e5+5,mod=998244353;
int n,m,dp[N];
vector<int> g[M];
int ask2(int n,int sum){
    int ans=0;
    for(int l=1,r;l<=n;l=r+1){
		int x=n/l;
        r=n/x;
		ans=(ans+1ll*(r-l+1)*(m-x+1)%mod*sum%mod)%mod;
    }
    return ans;
}
int main(){
    // freopen("sequence.in","r",stdin);
    // freopen("sequence.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=m;i++)
        for(int j=2;j*i<=m;j++) g[j*i].push_back(i);
    dp[1]=1;
    for(int i=1;i<n;i++) dp[i+1]=ask2(m,dp[i]);
    for(int i=1;i<=n;i++) cout<<dp[i]<<"\n";
    cout<<dp[n];
    return 0;
}