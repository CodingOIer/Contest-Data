#include <bits/stdc++.h>
using namespace std;
const int N=1e4+5;
int n,p[N],d[N],mod,ans,pp[N],cnt;
int pos(int x){
    return (x-1+n)%n+1;
}
int pd(){
    int ans=0;
    mempcpy(pp,p,sizeof(p));
    for(int i=1;i<=n;i++) d[p[i]]=i;
    for(int i=1;i<=n;i++){
        int k=d[i];
        swap(p[pos(k-1)],p[pos(k+1)]);
        if(min(p[pos(k-1)],p[pos(k+1)])<i&&i<max(p[pos(k-1)],p[pos(k+1)])) ans++;
        d[p[pos(k-1)]]=pos(k-1);
        d[p[pos(k+1)]]=pos(k+1);
    }
    if(ans) return 1;
    return 0;
}
int main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    cin>>n>>mod;
    if(n&1){
        int ans=1;
        for(int i=1;i<=n;i++) ans=1ll*ans*i%mod;
        cout<<ans<<"\n";
        return 0;
    }
    for(int i=1;i<=n;i++) p[i]=d[i]=i;
    do{
        ans+=pd();
        mempcpy(p,pp,sizeof(pp));
    }
    while(next_permutation(p+1,p+n+1));
    cout<<ans;
    return 0;
}