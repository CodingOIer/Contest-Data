#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e4+5; 
int N,M,Ans,A[Mxn],B[Mxn],C[Mxn],D[Mxn],F[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
/*
9 998244353
*/
int Cnt=0;
bool Check() {
	For(i,1,N) B[i]=A[i],D[i]=C[i];
	For(i,1,N) {
		int x=D[i],u=x>1?x-1:N,v=x<N?x+1:1;
		if(B[u]<B[x]&&B[x]<B[v]) return 1;
		if(B[v]<B[x]&&B[x]<B[u]) return 1;
		swap(D[B[u]],D[B[v]]),swap(B[u],B[v]);
	} 
	return 0;
}
void DFS(int x) {
	if(x>N) {Ans+=Check();return ;}
	For(i,1,N) if(!F[i]) 
		A[x]=i,C[i]=x,F[i]=1,DFS(x+1),F[i]=0;
}
signed main() {                                      
	freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
	N=_(),M=_();
	if(N<=10) DFS(1),__(Ans);
	else if(N&1) {
		Ans=1;
		For(i,2,N) Ans=1ll*Ans*i%M;
		__(Ans);
	}
	return 0;
}
