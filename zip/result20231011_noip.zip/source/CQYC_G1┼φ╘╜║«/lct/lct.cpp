#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e5+5;
int N,M;
int Ct,Nt[Mxn<<1],To[Mxn<<1],Hd[Mxn];
char S[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Merge(int x,int y) {
	Nt[++Ct]=Hd[x],To[Ct]=y,Hd[x]=Ct;
	Nt[++Ct]=Hd[y],To[Ct]=x,Hd[y]=Ct;
}
signed main() {                                      
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	N=_(),M=_();
	scanf("%s",S+1);
	For(i,1,M) Merge(_(),_());
	pt("1\n-1\n");
	return 0;
}
