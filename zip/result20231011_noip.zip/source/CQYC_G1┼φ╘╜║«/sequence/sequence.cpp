#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e5+5,P=998244353;
int N,M,Ans,A[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
bool Check() {
	For(i,2,N) 
		if(A[i-1]>A[i]&&A[i-1]%A[i]==0) return 0;
//	For(i,1,N) pt("%d ",A[i]);pc('\n');
	return 1;
}
void DFS(int x) {
	if(x>N) {Ans+=Check();return ;}
	For(i,1,M) A[x]=i,DFS(x+1);
}
signed main() {                                      
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	N=_(),M=_();
	DFS(1);
	__(Ans);
	return 0;
}
