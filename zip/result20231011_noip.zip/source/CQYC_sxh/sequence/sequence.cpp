#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

char qqq;
const int N = 1e5 + 1000;

int n, m;

int col[N], s[N], num, ans;
int f[N], g[N];
vector<pii> ve[N], to[650];

void work() { int sum = 0;
    For(i, 0, num) add(sum, 1ll * f[i] * s[i] % mod);
    For(i, 0, num) g[i] = f[i], f[i] = sum;
    For(i, 1, num) for (auto x : to[i]) 
        add(f[i], mod - 1ll * g[x.first] * x.second % mod);
}

char qqqq;

signed main() {
	freopen("sequence.in", "r", stdin);
	freopen("sequence.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    n = read(), m = read();
    Rof(i, m, 1) {
        for (int j = i + i; j <= m; j += i) {
            if (!ve[i].empty() && col[j] == ve[i].back().first)
            ++ve[i].back().second;else ve[i].push_back(pii(col[j], 1));
        } col[i] = col[i + 1] + (ve[i] != ve[i + 1]), ++s[col[i]];
        if (col[i] != col[i + 1] || i == m) to[col[i]] = ve[i];
    } 
    num = col[1]; int tot = 0;
    For(i, 0, num) tot += SZ(to[i]);cout << tot << '\n';
    For(i, 0, num) f[i] = 1; For(i, 2, n) work();
    For(i, 0, num) add(ans, 1ll * f[i] * s[i] % mod); cout << ans;
    cerr << clock() / 1000.0 << '\n';
	return 0;
}