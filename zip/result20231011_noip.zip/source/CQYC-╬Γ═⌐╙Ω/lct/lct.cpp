//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define fi first
#define se second
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10;
int N,M,tot,P[4],Q[4],f[Maxn][3],g[Maxn][3];
int dep[Maxn],Siz[Maxn],u[Maxn],v[Maxn],Ans;
char C[Maxn];
vector<int> E[Maxn];
bool Vis[Maxn],Cs[4];
pair<int,int> Nd[4];

void DFS2(int x,int p){
    dep[x]=dep[p]+1,Siz[x]=1;
    for(int y,i=0;i<(int)E[x].size();++i){
        if((y=E[x][i])==p) continue;
        DFS2(y,x); Siz[x]+=Siz[y];
    }
}

void Sol(int a,int b,int c,int d){
    int ret=0;
    E[a].pb(b),E[b].pb(a);
    E[c].pb(d),E[d].pb(c);
    DFS2(1,0);
    E[a].pop_back(),E[b].pop_back();
    E[c].pop_back(),E[d].pop_back();
    For(i,1,M){
        if(dep[u[i]]>dep[v[i]]) swap(u[i],v[i]);
        ret+=Siz[v[i]]*(N-Siz[v[i]]);
    }
    if(dep[a]>dep[b]) swap(a,b);
    ret+=Siz[b]*(N-Siz[b]);
    if(dep[c]>dep[d]) swap(c,d);
    ret+=Siz[d]*(N-Siz[d]);

    Ans=max(Ans,ret);
}

void ccalc(){
    For(i,1,3) if(Q[i]) swap(Nd[P[i]].fi,Nd[P[i]].se);
    Sol(Nd[P[1]].se,Nd[P[2]].fi,Nd[P[2]].se,Nd[P[3]].fi);
    For(i,1,3) if(Q[i]) swap(Nd[P[i]].fi,Nd[P[i]].se);
}

void DDFS(int x){
    if(x>tot) return ccalc(),void();
    For(i,1,3) if(!Cs[i]){
        P[x]=i,Cs[i]=1,Q[x]=0; DDFS(x+1);
        Q[x]=1; DDFS(x+1); Cs[i]=0;
    }
}

void calc(){
    int ret=0;
    int x=P[1],y=P[2];
    E[x].pb(y),E[y].pb(x);
    DFS2(1,0);
    For(i,1,M){
        if(dep[u[i]]>dep[v[i]]) swap(u[i],v[i]);
        ret+=Siz[v[i]]*(N-Siz[v[i]]);
    }
    if(dep[x]>dep[y]) swap(x,y);
    ret+=Siz[y]*(N-Siz[y]);
    E[x].pop_back(),E[y].pop_back();
    Ans=max(Ans,ret);
}

void DFS(int x){
    if(x>tot) return calc(),void();
    P[x]=Nd[x].fi,DFS(x+1);
    P[x]=Nd[x].se,DFS(x+1);
}

void Get_g(int x,int p){
    f[x][0]=f[x][1]=0,g[x][0]=g[x][1]=x,Vis[x]=1;
    for(int y,i=0;i<(int)E[x].size();++i){
        if((y=E[x][i])==p) continue;
        Get_g(y,x); int d=f[y][0]+1,dt=g[y][0];
        if(d>f[x][0]){
            f[x][1]=f[x][0],f[x][0]=d;
            g[x][1]=g[x][0],g[x][0]=dt;
        }else if(d>f[x][1]) f[x][1]=d,g[x][1]=dt;
    }
}

signed main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    N=read(),M=read(); scanf("%s",C+1);
    For(i,1,M){
        u[i]=read(),v[i]=read();
        E[u[i]].pb(v[i]),E[v[i]].pb(u[i]);
    }
    For(i,1,N) if(!Vis[i]){
        Get_g(i,0);
        Nd[++tot]=mp(g[i][0],g[i][1]);
    }
    if(tot==2) DFS(1);
    else DDFS(1);
    write(Ans),printf("\n-1");
    return 0;
}
/*
8 6
BBWWWBBW
1 2
2 3
4 5
5 6
6 7
7 8
*/