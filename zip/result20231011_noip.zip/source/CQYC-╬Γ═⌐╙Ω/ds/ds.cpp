//3s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int N,Q,U,R,D,L,stk[Maxn],top;
struct node{
    int x,y;
    bool operator <(const node &t)const{return (x^t.x)?x<t.x:y>t.y;}
}T[Maxn];

void Solve(){
    U=read(),R=read(),D=read(),L=read(),top=0;
    For(i,1,N){
        int x=T[i].x,y=T[i].y;
        if(x>=D&&x<=U&&y>=L&&y<=R){
            while(top&&stk[top]<y) --top;
            stk[++top]=y;
        }
    }
    write(top),pc('\n');
}

int main(){
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
    N=read(),Q=read();
    For(i,1,N) T[i].x=read();
    For(i,1,N) T[i].y=read();
    sort(T+1,T+N+1);
    while(Q--) Solve();
    return 0;
}