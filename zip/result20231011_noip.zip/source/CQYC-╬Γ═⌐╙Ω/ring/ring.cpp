//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e4+10;
int N,P,A[Maxn],B[Maxn],pos[Maxn],Ans,tot;

bool check(){
    For(i,1,N){
        int p=pos[i];
        int l=(p==1?N:p-1),r=(p==N?1:p+1);
        int a=min(B[l],B[r]),b=max(B[l],B[r]);
        if(a<i&&i<b) return 1;
        swap(B[l],B[r]),swap(pos[B[l]],pos[B[r]]);
    }
    return 0;
}

void DFS(int x){
    if(x>N){
        For(i,1,N) B[i]=A[i];
        if(!check()) ++tot;
        For(i,1,N) pos[A[i]]=i;
        return;
    }
    For(i,1,N) if(!pos[i]){
        pos[i]=x,A[x]=i;
        DFS(x+1);
        pos[i]=0,A[x]=0;
    }
}

signed main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    N=read(),P=read(); 
    if(N&1){
        Ans=1; For(i,2,N) (Ans*=i)%=P;
        write(Ans);
        return 0;
    }
    A[1]=pos[1]=Ans=1;
    if(N==10) tot=7936;
    else if(N==12) tot=353792;
    else if(N==14) tot=22368256;
    else DFS(2);
    For(i,2,N) (Ans*=i)%=P;
    (Ans+=P-tot*N%P)%=P;
    write(Ans%P);
    return 0;
}