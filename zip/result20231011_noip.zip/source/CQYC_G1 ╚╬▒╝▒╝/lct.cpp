#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2e5+5 ;
int n,m,ans1,las ;
char s[N] ;
int sz[N],vis[N],dep[N] ;
vector<int>e[N] ;
void Dfs(int x)
{
    vis[x] = sz[x] = 1 ;
    for(auto v:e[x]) if(!vis[v])
    {
        Dfs(v),sz[x] += sz[v] ;
        ans1 += (n-sz[v])*sz[v] ;
    }
}
void dfs(int x)
{
    vis[x] = 1,ans1 += dep[x] ;
    for(auto v:e[x]) if(!vis[v])
        dep[v] = dep[x]+1,dfs(v) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
//	freopen(".in","r",stdin) ;
//	freopen(".out","w",stdout) ;
    read(n,m) ;//,scanf("%s",s+1) ;
    FOR(i,1,m,1)
    {
        int u,v ; read(u,v) ;
        e[u].pb(v),e[v].pb(u) ;
    }
    // ROF(i,n,1,1) if(!vis[i])
    // {
    //     Dfs(i) ;
    //     if(!las) las = i ;
    //     else e[i].pb(las),e[las].pb(i),las = i ;
    // }
    e[2].pb(5),e[5].pb(2) ;
    ans1 = 0 ;
    FOR(i,1,n,1) 
    {
        me(vis,0),me(dep,0),dfs(i) ;
    }
    print(ans1/2) ;
    return 0 ;
}