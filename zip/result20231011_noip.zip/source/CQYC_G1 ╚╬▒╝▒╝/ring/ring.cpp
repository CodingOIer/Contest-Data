#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ;// space ;
    print(p...) ;
}
bool S_GND ;
const int N = 30 ;
int n,ans,MOD ;
int vis[N],p[N],k[N] ;
void Check()
{
    FOR(i,1,n,1) k[i] = p[i] ;
    int chk = 0 ;
    FOR(i,1,n,1)
    {
        FOR(j,1,n,1) if(k[j] == i)
        {
            int las = j-1,net = j+1 ;
            if(!las) las = n ; if(net == n+1) net = 1 ;
            swap(k[las],k[net]) ;
            int mi = min(k[las],k[net]),mx = max(k[las],k[net]) ;
            if(mi < i && i < mx) chk = 1 ; 
        }
    }
    ans += chk ;
}
void Dfs(int x)
{
    if(x == n+1) {Check() ; return ;}
    FOR(i,1,n,1) if(!vis[i]) p[x] = i,vis[i] = 1,Dfs(x+1),vis[i] = 0 ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("ring.in","r",stdin) ;
	freopen("ring.out","w",stdout) ;
    read(n,MOD) ;
    if(n&1)
    {
        ans = 1 ;
        if(n == 1) {print(0) ; return 0 ;}
        FOR(i,1,n,1) ans = ans*i%MOD ; print(ans) ;
    } 
    else ans = 0,Dfs(1),print(ans%MOD) ;
    return 0 ;
}