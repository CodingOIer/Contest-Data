#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; //space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2e5+5 ;
int n,q,top,ans ;
int st[N] ;
struct Node{int x,y ;}a[N] ;
int cmp(Node x,Node y)
{
    if(x.x != y.x) return x.x > y.x ;
    return x.y > y.y ;
}
void Solve1()
{
    while(q--)
    {
        int l1,r1,l2,r2 ; 
        read(r1,r2,l1,l2),top = 0,ans = 0 ;
        FOR(i,1,n,1) if(a[i].x >= l1 && a[i].x <= r1 && a[i].y >= l2 && a[i].y <= r2)
            st[++top] = i ; 
        int mx = 0,P = 0 ;
        FOR(i,1,top,1)
        {
            int p = st[i] ;// print(p) ;
            if(mx <= a[p].y) ++ans ;
            P = max(P,a[p].y) ;
            if(a[st[i+1]].x != a[p].x) mx = max(mx,P) ;
        }
        print(ans),enter ;
    }
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("ds.in","r",stdin) ;
	freopen("ds.out","w",stdout) ;
    read(n,q) ;
    FOR(i,1,n,1) read(a[i].x) ;
    FOR(i,1,n,1) read(a[i].y) ;
    sort(a+1,a+1+n,cmp) ;
    // FOR(i,1,n,1) print(a[i].x,a[i].y),enter ; enter ;
    if(n <= 10000 && q <= 10000) Solve1() ;
    return 0 ;
}