#include<bits/stdc++.h>
#define ll long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define mod 998244353
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int n,m,dp[N],zhi[N],t;
ll f[N],ans;
bitset<N> vis;
il void init(){
	for(int i=2;i<=m;++i){
		if(!vis[i]){
			zhi[++t]=i;
			for(int j=2;j*i<=m;++j) vis[j*i]=1;
		}
	}
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
    n=read();m=read();init();
    dp[1]=1;
    for(int i=1;i<=n;++i){
		// cerr<<"ERROR";
        ll sum=0;
        for(int j=1;j<=m;++j){
			sum+=dp[j];f[j]=dp[j];
		}
		sum%=mod;
		for(int j=1;j<=t;++j)
			for(int k=m/zhi[j];k;--k) f[k]+=f[k*zhi[j]];
		for(int j=1;j<=m;++j){
			Add(dp[j],sum);Del(dp[j],f[j]%mod);
		}
    }
    for(int i=1;i<=m;++i) ans+=dp[i];
    write(ans%mod);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}