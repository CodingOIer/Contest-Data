#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,Q,x[N],y[N],sum[10010][10010];
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("ds.in","r",stdin);
	freopen("ds.out","w",stdout);
    n=read();Q=read();
    for(int i=1;i<=n;++i) x[i]=read();
    for(int i=1;i<=n;++i) y[i]=read();
    for(int i=1;i<=n;++i) sum[x[i]][y[i]]=1;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j) sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
    while(Q--){
        int rx=read(),ry=read(),lx=read(),ly=read(),ans=0;
        // for(int i=1;i<=n;++i) if(lx<=x[i]&&rx>=x[i]&&ly<=y[i]&&ry>=y[i]) cerr<<x[i]<<" "<<y[i]<<"\n";
        for(int i=1;i<=n;++i) if(lx<=x[i]&&rx>=x[i]&&ly<=y[i]&&ry>=y[i]&&!(sum[rx][ry]-sum[x[i]][ry]-sum[rx][y[i]]+sum[x[i]][y[i]])) ++ans;
        write(ans);putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}