#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 10010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,fac[N],inv[N],f[N],mod;
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il int C(int a,int b){
    return fac[a]*inv[b]%mod*inv[a-b]%mod;
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
    n=read();mod=read();
    fac[0]=1;
    for(int i=1;i<=n;++i) fac[i]=fac[i-1]*i%mod;
    inv[n]=Pow(fac[n],mod-2);
    for(int i=n;i;--i) inv[i-1]=inv[i]*i%mod;
    if(n&1){
        write(fac[n]);return 0;
    }
    f[1]=1;
    for(int i=2;i<=n;++i){
        for(int j=2;j<i;++j) f[i]+=f[j-1]*f[i-j]%mod;
		f[i]=f[i]%mod*fac[i-1]%mod;
		f[i]=f[i]*inv[i]%mod;
    }
    write((fac[n]-f[n-1]*fac[n-1]%mod*n%mod+mod)%mod);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}