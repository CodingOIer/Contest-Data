#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;


namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 10005;
int x[N],y[N];
int s[N][N];
int n,q;

int main(){
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
    n = in,q = in;
    for(int k=1;k<=n;k++)
        x[k] = in;
    for(int k=1;k<=n;k++)
        y[k] = in;
    for(int k=1;k<=n;k++)
        s[x[k]][y[k]]++;
    for(int k=1;k<=n;k++)
        for(int j=1;j<=n;j++)
            s[k][j] += s[k][j-1];
    for(int k=1;k<=n;k++)
        for(int j=1;j<=n;j++)
            s[k][j] += s[k-1][j];
    while(q--){
        auto get = [](int x1,int y1,int x2,int y2){return s[x2][y2]-s[x1-1][y2]-s[x2][y1-1]+s[x1-1][y1-1];};
        int U = in,R = in,D = in,L = in,ans = 0;
        for(int k=1;k<=n;k++)
            if(D<=x[k]&&x[k]<=U&&L<=y[k]&&y[k]<=R&&!get(x[k]+1,y[k]+1,U,R))
                ans++;
        out(ans,'\n');
    }
    return 0;
}