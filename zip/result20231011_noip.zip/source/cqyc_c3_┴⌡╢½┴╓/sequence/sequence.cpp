#include <iostream>
#include <cstring>
#include <algorithm>
#define tmod(a) ((a)>=mod?(a)-mod:(a))
using namespace std;

const int N = 100005,mod = 998244353;
int f[2][N],o;
int n,m;

int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    cin >> n >> m;
    for(int k=1;k<=m;k++)
        f[o][k] = 1;
    for(int k=2;k<=n;k++){
        memset(f[o^1],0,sizeof(int)*(m+1));
        int s = 0;
        for(int j=1;j<=m;j++)
            s = tmod(s+f[o][j]);
        for(int j=1;j<=m;j++){
            int t = 0;
            for(int i=j+j;i<=m;i+=j)
                t = tmod(t+f[o][i]);
            f[o^1][j] = tmod(s-t+mod);
        }
        o ^= 1;
    }
    int ans = 0;
    for(int k=1;k<=m;k++)
        ans = tmod(ans+f[o][k]);
    cout << ans;
    return 0;
}