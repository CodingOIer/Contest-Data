#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 10005;
int p[N],q[N],d[N];
int n,mod;

int solve(){
    int ans = 0;
    mempcpy(q,p,sizeof(p));
    for(int k=1;k<=n;k++)
        d[p[k]] = k;
    auto h = [](int x){return (x-1+n)%n+1;};
    for(int k=1;k<=n;k++){
        int j = d[k];
        swap(p[h(j-1)],p[h(j+1)]);
        if(min(p[h(j-1)],p[h(j+1)])<k&&k<max(p[h(j-1)],p[h(j+1)]))
            ans++;
        d[p[h(j-1)]] = h(j-1);
        d[p[h(j+1)]] = h(j+1);
    }
    return ans?1:0;
}

signed main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    cin >> n >> mod;
    if(n&1){
        int ans = 1;
        for(int k=1;k<=n;k++)
            ans = ans*k%mod;
        cout << ans;
    }
    else{
        for(int k=1;k<=n;k++)
            p[k] = d[k] = k;
        int ans = 0;
        do{
            ans += solve();
            mempcpy(p,q,sizeof(q));
        }
        while(next_permutation(p+1,p+n+1));
        cout << ans;
    }
    return 0;
}