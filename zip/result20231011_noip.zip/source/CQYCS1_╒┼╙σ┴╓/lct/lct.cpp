#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=1e6+5;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int n,m,h[N],to[N<<1],nxt[N<<1],cnt,col[N],dep[N],siz[N],id[N];
ll dp[N],df[N],sum[N];
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt;
}
inline void dfs(int x,int fa){
	dep[x]=dep[fa]+1,siz[x]=1,dp[x]=dep[x],id[x]=x;
	e(x)if(y^fa)dfs(y,x),siz[x]+=siz[y],dp[x]+=dp[y];
	df[x]=siz[x];
}
inline void dfs_(int x,int fa){
	sum[x]=0;
	e(x)if(y^fa)dp[y]=dp[x]-siz[y]+df[x]-siz[y],df[y]=df[x],dfs_(y,x),sum[x]+=sum[y]+1LL*siz[y]*(df[x]-siz[y]);
}
inline void Dfs(int x,int fa){
	e(x)if(y^fa){
		Dfs(y,x);
		if(dp[y]>dp[x])dp[x]=dp[y],id[x]=id[y];
	}
}
int rt[4],tot,X[N],Y[N],val[N];
inline ll solve(int a,int b,int c){
	int prea=h[id[a]],preb=h[id[b]];
	add(id[a],id[b]),add(id[b],id[a]);
	dfs(a,0),dfs_(a,0),Dfs(a,0);
	memset(h,0,sizeof(h)),cnt=0;
	rep(i,1,m)add(X[i],Y[i]),add(Y[i],X[i]);
	ll ans=1LL*dp[a]*siz[c]+1LL*dp[c]*siz[a]+1LL*siz[a]*siz[c]+sum[a]+sum[c];
	dfs(a,0),dfs_(a,0),Dfs(a,0);
	dfs(b,0),dfs_(b,0),Dfs(b,0);
	return ans;
}
int Id[N<<1];
vector<int>p;
inline void Add(int a,int b,int c){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,Id[cnt]=c;
} 
inline void dfs2(int x,int fa){
	e(x)if(y^fa){
		dfs2(y,x);
		if(val[y]^col[y])val[y]^=1,val[x]^=1;
		else p.pb(Id[i]);
	}
}
int main(){
    freopen("lct.in","r",stdin);
    freopen("lct.out","w",stdout);
    n=read(),m=read();
    rep(i,1,n){
    	char c=getchar();
    	while(c!='B'&&c!='W')c=getchar();
    	col[i]=c=='B';
	}
	for(int i=1,x,y;i<=m;i++)x=read(),y=read(),add(x,y),add(y,x),X[i]=x,Y[i]=y,val[x]^=1,val[y]^=1;
	dep[0]=-1;
	rep(i,1,n)if(!siz[i])dfs(i,0),dfs_(i,0),Dfs(i,0),rt[++tot]=i;
	if(tot==2){
		pf(1LL*dp[rt[1]]*siz[rt[2]]+1LL*dp[rt[2]]*siz[rt[1]]+1LL*siz[rt[1]]*siz[rt[2]]+sum[rt[1]]+sum[rt[2]]);
		putchar('\n');
	}else {
		pf(max({solve(rt[1],rt[2],rt[3]),solve(rt[2],rt[3],rt[1]),solve(rt[1],rt[3],rt[2])}));
		putchar('\n');
	}
	memset(h,0,sizeof(h)),cnt=0;
	rep(i,1,m)Add(X[i],Y[i],i),Add(Y[i],X[i],i);
	rep(i,1,tot){
		dfs2(rt[i],0);
		if(col[rt[i]]^val[rt[i]]){
			pf(-1);
			return 0;
		}
	}
	sort(p.begin(),p.end());
	int sz=p.size();
	pf(sz),putchar('\n');
	for(auto x:p)pf(x),putchar(' ');
    return 0;
}
