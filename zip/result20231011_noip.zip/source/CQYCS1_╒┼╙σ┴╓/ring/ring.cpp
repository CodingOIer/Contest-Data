#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e4+5,M=1e6+5;
const ll llf=1e18,bas=131;
const ui base=13331;
using namespace std;
int n,mod,a[25],b[25],p[25],ans;
bool vis[25];
inline int check(){
	rep(i,1,n)b[i]=a[i],p[a[i]]=i;
	rep(i,1,n){
		int ps=p[i];
		int l=ps==1?n:ps-1,r=ps==n?1:ps+1;
		swap(p[b[l]],p[b[r]]),swap(b[l],b[r]);
		if(i>min(b[l],b[r])&&i<max(b[l],b[r]))return 1;
	}
	return 0;
}
ll mul[N],inv[N];
inline ll qp(ll a,ll b){
	if(!b)return 1;
	ll c=qp(a,b>>1);
	c=c*c%mod;
	if(b&1)c=c*a%mod;
	return c;
}
inline void prep(){
	mul[0]=inv[0]=1;
	rep(i,1,n)mul[i]=mul[i-1]*i%mod;
	inv[n]=qp(mul[n],mod-2);
	per(i,n-1,1)inv[i]=inv[i+1]*(i+1)%mod;
} 
inline ll c(int x,int y){
	if(x<0||y<0||x<y)return 0;
	return mul[x]*inv[y]%mod*inv[x-y]%mod;
}
inline ll A(int x,int y){
	if(x<0||y<0||x<y)return 0;
	return mul[x]*inv[x-y]%mod;
}
inline void dfs(int pos){
	if(pos==n+1){
		ans+=check();
		ans%=mod;
		return;
	}
	rep(i,1,n)if(!vis[i])vis[i]=1,a[pos]=i,dfs(pos+1),vis[i]=0;
}
int main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    n=read(),mod=read(),prep();
	if(n%2==1){
		pf(mul[n]);
		return 0;
	}
	
    	dfs(1);
    	pf(ans);
    	return 0;
	
    return 0;
}
