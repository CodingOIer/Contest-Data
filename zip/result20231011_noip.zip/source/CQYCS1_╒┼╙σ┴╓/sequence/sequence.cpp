#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=1e6+5;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int dp[2005][2005],n,m;
int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    n=read(),m=read();
    rep(i,1,m)dp[1][i]=1;
    rep(i,1,n-1){
    	int sum=0;
    	rep(j,1,m)(sum+=dp[i][j])%=mod;
    	rep(j,1,m)dp[i+1][j]=sum;
    	rep(j,1,m)for(int k=2;k*j<=m;k++)dp[i+1][k*j]=(dp[i+1][k*j]-dp[i][j]+mod)%mod;
	}
	int ans=0;
	rep(j,1,m)(ans+=dp[n][j])%=mod;
	pf(ans);
    return 0;
}
