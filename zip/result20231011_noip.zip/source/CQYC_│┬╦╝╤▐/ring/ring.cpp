#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[10005],b[10005],c[10005],ans,vis[10005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x){
    if(x>n){
        for(int i=1;i<=n;i++)
            b[i]=a[i],c[b[i]]=i;
        for(int i=1;i<=n;i++){
            int j=c[i];
            int x=j-1,y=j+1;
            if(x<1)
                x=n;
            if(y>n)
                y=1;
            if((b[x]<i&&i<b[y])||(b[x]>i&&i>b[y])){
                ++ans;
                return;
            }
            swap(b[x],b[y]);
            swap(c[b[x]],c[b[y]]);
        }
        return;
    }
    for(int i=1;i<=n;i++)
        if(!vis[i]){
            vis[i]=1,a[x]=i;
            solve(x+1);
            vis[i]=0;
        }
}
signed main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    n=read(),m=read();
    solve(1);
    printf("%lld\n",ans);
    return 0;
}