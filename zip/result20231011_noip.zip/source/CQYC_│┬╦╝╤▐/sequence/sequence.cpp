#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353,maxn=1e5+5;
int n,m,f[2][maxn][2],op,ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int &a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
signed main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++)
        f[op][i][0]=1;
    for(int i=1;i<n;i++){
        int res=0;
        for(int j=1;j<=m;j++){
            f[op^1][j][0]=f[op^1][j][1]=0;
            add(res,(f[op][j][0]+f[op][j][1])%mod);
        }
        for(int j=1;j<=m;j++){
            add(f[op^1][j][0],f[op^1][j-1][0]);
            add(f[op^1][j][0],(f[op][j][0]+f[op][j][1])%mod);
            add(f[op^1][j][1],(res+mod-f[op^1][j][0])%mod);
            for(int l=2;l*j<=m;l++)
                add(f[op^1][j][1],(mod-(f[op][j*l][0]+f[op][j*l][1])%mod)%mod);
        }
        op^=1;
    }
    for(int i=1;i<=m;i++)
        add(ans,(f[op][i][0]+f[op][i][1])%mod);
    printf("%lld\n",ans);
    return 0;
}