#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
int n,q,x[maxn],y[maxn],u,r,d,l;
map<int,int> ma[maxn];
vector<int> ve[maxn],cnt[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("ds.in","r",stdin);
    freopen("ds.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<=n;i++)
        x[i]=read();
    for(int i=1;i<=n;i++)
        y[i]=read();
    for(int i=1;i<=n;i++){
        if(!ma[x[i]][y[i]])
            ve[x[i]].push_back(y[i]);
        ma[x[i]][y[i]]++;
    }
    for(int i=1;i<=n;i++){
        sort(ve[i].begin(),ve[i].end());
        int s=ve[i].size();
        if(s){
            cnt[i].resize(s);
            cnt[i][0]=ma[i][ve[i][0]];
            for(int j=1;j<s;j++)
                cnt[i][j]=cnt[i][j-1]+ma[i][ve[i][j]];
        }
    }
    while(q--){
        u=read(),r=read(),d=read(),l=read();
        int ans=0,mi=l;
        for(int i=u;i>=d;i--){
            int k=lower_bound(ve[i].begin(),ve[i].end(),mi)-ve[i].begin();
            int p=upper_bound(ve[i].begin(),ve[i].end(),r)-ve[i].begin();
            if(k<ve[i].size()){
                if(ve[i][k]>=mi&&ve[i][k]<=r){
                    p--;
                    ans+=cnt[i][p];
                    if(k)
                        ans-=cnt[i][k-1];
                    mi=ve[i][p];
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}