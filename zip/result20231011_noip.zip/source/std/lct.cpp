#include<cstdio>
#include<cstdlib>
#include<iostream>
#define N 1111111
using namespace std;
typedef long long LL;
struct edge
{
	int f,t,id,n;
}e[N*2];
LL siz[N],up[N],down[N],dis[N],bestdown[N],bestup[N],cnt[N];
int h[N],col[N],del[N],root[5],bel[N],par[N],dep[N];
int tree,n,m,tote;
inline void adde(int f,int t,int id)
{
	e[++tote].f=f;
	e[tote].t=t;
	e[tote].id=id;
	e[tote].n=h[f];
	h[f]=tote;
	return ;
}
inline void predown(int u,int tr)
{
	siz[u]=1; 
	cnt[u]=col[u];
	bel[u]=tr; 
	dep[u]=dep[par[u]]+1;
	for (int i=h[u];i;i=e[i].n)
	{
		int v=e[i].t;
		if (v==par[u]) continue;
		par[v]=u;
		predown(v,tr);
		siz[u]+=siz[v];
		down[u]+=down[v]+siz[v];
		cnt[u]+=cnt[v];
	}
	return ;
}
inline void preup(int u,LL tsize)
{
	int fa=par[u];
	if (fa)
	{
		up[u]+=up[fa];
		for (int i=h[fa];i;i=e[i].n)
		{
			int v=e[i].t;
			if (v==u||v==par[fa]) continue;
			up[u]+=down[v]+siz[v];
		}
		up[u]+=tsize-siz[u];
	}
	for (int i=h[u];i;i=e[i].n)
	{
		int v=e[i].t;
		if (v==par[u]) continue;
		preup(v,tsize);
	}
	return ;
}
LL A,B,C;
inline void calcdown(int u)
{
	for (int i=h[u];i;i=e[i].n)
	{
		int v=e[i].t;
		if (v==par[u]) continue;
		calcdown(v);
		LL tmp=max(B*dis[v]+C,bestdown[v]+C);
		bestdown[u]=max(bestdown[u],tmp);
	}
	bestdown[u]=max(bestdown[u],B*dis[u]);
	return ;
}
inline void calcup(int u)
{
	int fa=par[u];
	LL tmp=0;
	if (fa) tmp=max(B*dis[fa]+C,bestup[fa]+C);
	for (int i=h[fa];i;i=e[i].n)
	{
		int v=e[i].t;
		if (v==par[fa]||v==u) continue;
		tmp=max(tmp,bestdown[v]+C*2);
	}
	bestup[u]=tmp;
	for (int i=h[u];i;i=e[i].n)
	{
		int v=e[i].t;
		if (v==fa) continue;
		calcup(v);
	}
	return ;
}
inline int getint()
{
	char ch;
	while (!isdigit(ch=getchar())) ;
	int ans=ch-'0';
	while (isdigit(ch=getchar())) ans=ans*10+ch-'0';
	return ans;
}
inline LL calc2(int a,int b)
{
	LL ans=0,u=-1,v=-1,ra=root[a],rb=root[b];
	for (int i=1;i<=n;i++)
	{
		if (bel[i]==a&&(u==-1||dis[i]>dis[u])) u=i;
		if (bel[i]==b&&(v==-1||dis[i]>dis[v])) v=i;
		ans+=dis[i];
	}
	ans/=2;
	ans+=dis[u]*siz[rb]+dis[v]*siz[ra]+siz[ra]*siz[rb];
	return ans;
}
inline LL calc3(int a,int b,int c)
{
	LL ans=0,x=-1,v=-1,ra=root[a],rb=root[b],rc=root[c];
	for (int i=1;i<=n;i++)
	{
		if (bel[i]==a&&(x==-1||dis[i]>dis[x])) x=i;
		if (bel[i]==c&&(v==-1||dis[i]>dis[v])) v=i;
		ans+=dis[i];
	}
	ans/=2;
	ans+=dis[x]*(siz[rb]+siz[rc]);
	ans+=dis[v]*(siz[rb]+siz[ra]);
	ans+=siz[ra]*siz[rb]+siz[rb]*siz[rc]+2*siz[ra]*siz[rc];
	A=siz[ra],B=siz[rc],C=siz[ra]*siz[rc];
	for (int i=1;i<=n;i++) bestup[i]=bestdown[i]=0;
	calcdown(rb); calcup(rb); LL tmax=0;
	for (int i=1;i<=n;i++)
	if (bel[i]==b)
	{
		LL tmp=(A+B)*dis[i];
		tmp=max(tmp,max(bestup[i],bestdown[i])+A*dis[i]);
		tmax=max(tmax,tmp);
	}
	return ans+tmax;	
}
inline void solve_cut()
{
	for (int i=1;i<=tree;i++)
	if (cnt[root[i]]%2) 
	{
		printf("-1");
		return ;
	}
	int tmp=0;
	for (int i=1;i<=tote;i+=2)
	{
		int u=e[i].f,v=e[i].t;
		if (dep[u]>dep[v]) swap(u,v);
		int s=cnt[root[bel[u]]];
		if (cnt[v]%2||(s-cnt[v])%2) continue;
		del[e[i].id]=true; tmp++;
	}
	cout<<m-tmp<<endl;
	for (int i=1;i<=m;i++) 
	if (!del[i]) printf("%d ",i);
	return ;
}
inline void solve_link()
{
	for (int i=1;i<=tree;i++) 
	preup(root[i],siz[root[i]]);
	for (int i=1;i<=n;i++) dis[i]=up[i]+down[i];
	LL ans=0;
	if (tree==2) ans=calc2(1,2);
	else 
	{
		ans=max(ans,calc3(2,1,3));
		ans=max(ans,calc3(1,2,3));
		ans=max(ans,calc3(2,3,1));
	}
	cout<<ans<<endl;
	return ;
}
inline void solve()
{
	n=getint(); m=getint();
	for (int i=1;i<=n;i++) 
	{
		char ch=' ';
		while (ch!='W'&&ch!='B') ch=getchar();
		if (ch=='B') col[i]=1;
	} 
	for (int i=1;i<=m;i++)
	{
		int u=getint(),v=getint();
		adde(u,v,i); adde(v,u,i);
	}
	for (int i=1;i<=n;i++)
	if (!dep[i])
	{
		root[++tree]=i;
		predown(i,tree);
	}
	solve_link();
	solve_cut();
	return ;
}
int main()
{
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
