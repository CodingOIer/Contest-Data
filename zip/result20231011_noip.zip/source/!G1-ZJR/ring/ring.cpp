#include<bits/stdc++.h>
using namespace std;
int mod;
inline long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1) (res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}
long long fac[10011],exfac[10011];
inline long long C(int n,int m) {return fac[n] * exfac[m] % mod * exfac[n - m] % mod;}
int n;
vector<long long> lst = {0,0,2,0,8,0,96,0,2176,0,79360,0,4245504,0,313155584,0,30460116992,0,3777576173568,0,581777702256640,0};
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
	cin >> n >> mod;
	fac[0] = 1;
	for(int i = 1;i <= n;i++) fac[i] = fac[i - 1] * i % mod;
	exfac[n] = qmi(fac[n],mod - 2);
	for(int i = n;i;i--) exfac[i - 1] = exfac[i] * i % mod;
	if(n & 1)
	{
		cout << fac[n];
		return 0;
	}else if(n < lst.size())
	{
		cout << (fac[n] + mod - lst[n] % mod) % mod;
		return 0;
	}else{
		cout << "Please wait for my programming...";
	}
	return 0;
}
