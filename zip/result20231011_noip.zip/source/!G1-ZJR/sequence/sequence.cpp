#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
int n,m;
int f[2][100011],ans[2011];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= m;i++) f[n & 1][i] = 1;
	ans[n] = m;
	for(int i = n - 1,op = (n - 1) & 1;i;i--,op ^= 1)
	{
		for(int j = 1;j <= m;j++) f[op][j] = ans[i + 1];
		for(int j = 1;j <= m;j++)
		{
			for(int k = 2 * j;k <= m;k += j)
			{
				f[op][k] += (mod - f[op ^ 1][j]);
				if(f[op][k] >= mod) f[op][k] -= mod;
			}
			ans[i] += f[op][j];
			if(ans[i] >= mod) ans[i] -= mod;
		}
	}
	cout << ans[1];
	return 0;
}
