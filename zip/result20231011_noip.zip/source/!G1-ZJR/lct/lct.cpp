#include<bits/stdc++.h>
using namespace std;
long long f[100011];
int Siz[100011],root;
vector<int> v[100011];
int n,m;
char cl[100011];
bool svd[100011];
int idx,siz[13];
long long mx[13];
void DFS1(int p,int fa)
{
	svd[p] = 1;
	Siz[p] = 1;
	for(auto i:v[p]) if(i != fa)
	{
		DFS1(i,p);
		Siz[p] += Siz[i];
		f[p] += f[i] + (long long)Siz[i] * (n - Siz[i]); 
	}
}
void DFS2(int p,int fa)
{
	mx[idx] = max(mx[idx],f[p]);
	for(auto i:v[p]) if(i != fa)
	{
		f[i] += f[p] - f[i] - (long long)Siz[i] * (n - Siz[i]) + (long long)(Siz[root] - Siz[i]) * (n - Siz[root] + Siz[i]);
		DFS2(i,p);
	}
}
inline void Solve(int p)
{
	idx++;
	root = p;
	DFS1(p,p);
	DFS2(p,p);
	siz[idx] = Siz[root];
}
inline void Clac()
{
	long long ans = 0,add = 0;
	for(int i = 1;i <= idx;i++) ans += mx[i];// + (long long)siz[i] * (n - siz[i]);
	if(idx == 2)
		ans += (long long)siz[1] * siz[2];
	else
		for(int x = 1;x < 3;x++)
			for(int y = x + 1;y <= 3;y++)
				add = max(add,(long long)siz[x] * (n - siz[x]) + (long long)siz[y] * (n - siz[y]));
//	cerr << add << "\n";
	cout << ans + add << "\n";
}
int x,y;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("lct.in","r",stdin);
	freopen("lct.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= n;i++)
		cin >> cl[i];
	for(int i = 1;i <= m;i++)
	{
		cin >> x >> y;
		v[x].push_back(y),v[y].push_back(x);
	}
	for(int i = 1;i <= n;i++)
	{
		if(!svd[i])
			Solve(i);
	}
	Clac();
	cout << -1;
	return 0;
}
