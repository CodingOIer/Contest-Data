#include<bits/stdc++.h>
using namespace std;
typedef struct{
	int x,y;
}AD;
AD p[1000011];
inline bool cmp(AD A,AD B)
{
	return A.x == B.x ? A.y < B.y : A.x > B.x;
}
int n,q;
int u,d,l,r;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("ds.in","r",stdin);
	freopen("ds.out","w",stdout);
	cin >> n >> q;
	for(int i = 1;i <= n;i++) cin >> p[i].x;
	for(int i = 1;i <= n;i++) cin >> p[i].y;
	sort(p + 1,p + n + 1,cmp);
	while(q--)
	{
		cin >> u >> r >> d >> l;
		int L = 1,R = n,mid,U = n + 1;
		while(L <= R)
		{
			mid = L + R >> 1;
			if(p[mid].x <= u) U = mid,R = mid - 1;
			else L = mid + 1;
		}
		int mx = l,ans = 0;
		for(int i = U;i <= n && p[i].x >= d;i++) if(mx <= p[i].y && p[i].y <= r)
			mx = p[i].y,ans++;
		cout << ans << "\n";
	}
	return 0;
}
