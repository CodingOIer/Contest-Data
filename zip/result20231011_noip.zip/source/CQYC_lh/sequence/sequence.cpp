#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+2,logn=20;
const int mod=998244353;
int n,m;
int f[maxn],g[maxn];
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int main(){
    freopen("sequence.in","r",stdin);
    freopen("sequence.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)f[i]=1;
    int sum=0,nsum=m;
    for(int i=1;i<n;i++){
        for(int j=1;j<=m;j++)g[j]=0,swap(f[j],g[j]);
        sum=0,swap(sum,nsum);
        for(int j=1;j<=m;j++){
            upd(f[j],sum);
            for(int k=j+j;k<=m;k+=j)upd(f[j],mod-g[k]);
            // printf("%d ",f[j]);
            upd(nsum,f[j]);
        }
        // printf("nsum=%d\n",nsum);
    }
    int ans=0;
    for(int i=1;i<=m;i++)upd(ans,f[i]);
    printf("%d\n",ans);
    return 0;
}