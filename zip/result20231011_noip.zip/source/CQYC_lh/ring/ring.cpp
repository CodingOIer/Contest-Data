#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+2;
int n,mod;
int f[2][maxn];
int fac[maxn];
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int main(){
    freopen("ring.in","r",stdin);
    freopen("ring.out","w",stdout);
    scanf("%d%d",&n,&mod);
    fac[0]=1;
    for(int i=1;i<=n;i++)fac[i]=1ll*i*fac[i-1]%mod;
    if(n&1){printf("%d\n",fac[n]);return 0;}
    else {
        f[0][2]=2;
        for(int i=n-2;i;i--){
            for(int j=0;j<=n;j++){
                if(j>1)upd(f[i][j],1ll*f[i+1][j-1]*(j-1)%mod);
                upd(f[i][j],1ll*f[i+1][j+1]*(j+1)%mod);
                // printf("f[%d][%d]=%d\n",i,j,f[i][j]);
            }
        }
        printf("%d\n",(fac[n]-1ll*(n/2)*f[1][0]%mod+mod)%mod);
    }
    return 0;
}