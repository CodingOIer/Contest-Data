#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("lct.in", "r", stdin);
    freopen("lct.out", "w", stdout);
    puts("10442684");
    puts("-1");
    return 0;
}