#include <bits/stdc++.h>
using namespace std;
const int P = 998244353;
int n, m, ans = 1;
map<string, int, greater<>> k, g;
void dfs(size_t x, string s, string t)
{
    if (x == s.size())
    {
        sort(t.begin(), t.end(), greater());
        if (s != t)
            g[t]++;
        return;
    }
    for (int i = 0; i <= s[x]; i++)
        dfs(x + 1, s, i ? t + char(i) : t);
}
int main()
{
    freopen("sequence.in", "r", stdin);
    freopen("sequence.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++)
    {
        int x = i;
        string s;
        for (int j = 2; j * j <= x; j++)
            if (x % j == 0)
            {
                s.push_back(0);
                while (x % j == 0)
                    x /= j, s.back()++;
            }
        if (x != 1)
            s.push_back(1);
        sort(s.begin(), s.end(), greater());
        k[s]++;
    }
    int t = 0;
    vector<tuple<int, int, vector<pair<int *, int>>>> p(k.size());
    for (auto &[x, y] : k)
        get<0>(p[t]) = y, y = t++;
    t = 0;
    for (auto &[x, y] : k)
    {
        dfs(0, x, "");
        for (auto &[u, v] : g)
            get<2>(p[t]).emplace_back(&get<1>(p[k[u]]), v);
        t++;
        g.clear();
    }
    cerr << clock() << endl;
    while (n--)
    {
        int sum = 0;
        for (auto &[x, y, z] : p)
        {
            y = ans;
            for (auto &[u, v] : z)
                y = (y - 1ll * *u * v % P + P) % P;
            sum = (sum + 1ll * x * y) % P;
        }
        ans = sum;
    }
    printf("%d\n", ans);
    cerr << clock() << endl;
    return 0;
}