#include <bits/stdc++.h>
using namespace std;
int n, m;
int fac[20000], inv[20000], f[20000];
int power(int x, int y)
{
    int res = 1;
    while (y)
    {
        if (y % 2)
            res = 1ll * res * x % m;
        x = 1ll * x * x % m;
        y /= 2;
    }
    return res;
}
int main()
{
    freopen("ring.in", "r", stdin);
    freopen("ring.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = fac[0] = f[1] = 1; i <= n; i++)
        fac[i] = 1ll * fac[i - 1] * i % m;
    inv[n] = power(fac[n], m - 2);
    for (int i = n; i; i--)
        inv[i - 1] = 1ll * inv[i] * i % m;
    for (int i = 3; i <= n; i += 2)
        for (int j = 2; j < i; j += 2)
            f[i] = (f[i] + 1ll * f[j - 1] * f[i - j] % m * fac[i - 1] % m * inv[j - 1] % m * inv[i - j]) % m;
    printf("%lld\n", (fac[n] - 1ll * f[n - 1] * n % m + m) % m);
    return 0;
}