#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=635,mod=998244353;
struct ok{
	int x,l,r;
};
int n,m,S,T,a[N],num[N],sum[M],P[M],dp[M];
vector<ok>ned[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	cin>>n>>m;S=m;
	for(int i=1;i<=m;i++)
		a[i]=m/i,++num[m/a[i]];
	sort(a+1,a+m+1);
	T=unique(a+1,a+m+1)-a-1;
	for(int i=1;i<=T;i++)
	{
		sum[i]=i;
		for(int j=i+1;j<=T;j++)
			P[j]=a[j]/a[i]-a[j-1]/a[i];
		for(int l=i+1,r;l<=T;)
		{
			r=l;
			while(r<=T&&P[l]==P[r]) ++r;
			if(P[l]) ned[i].push_back((ok){P[l],l,r-1});
			l=r;
		}
	}
	for(int i=2;i<=n;i++)
	{
		for(int j=1;j<=T;j++)
		{
			dp[j]=S;
			for(ok k:ned[j])
				upd(dp[j],mod-1ll*k.x*(sum[k.r]-sum[k.l-1]+mod)%mod);
		}
		S=0;
		for(int j=1;j<=T;j++)
		{
			upd(S,1ll*num[a[j]]*dp[j]%mod);
			sum[j]=dp[j],upd(sum[j],sum[j-1]);
		}
	}
	cout<<S<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
