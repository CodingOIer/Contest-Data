#include<bits/stdc++.h>
using namespace std;
const int N=1e4+10;
int n,ans,mod,a[N],dp[2][N][2];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int main()
{
	freopen("ring.in","r",stdin);
	freopen("ring.out","w",stdout);
	cin>>n>>mod;
	ans=1;
	for(int i=2;i<=n;i++) ans=1ll*i*ans%mod;
	dp[0][0][0]=1;
	for(int i=1,t,p;i<=n;i++)
	{
		t=i&1,p=t^1;
		dp[t][0][0]=0;
		for(int j=1;j<=i;j++)
		{
			dp[t][j][0]=1ll*j*(dp[p][j-1][0]+dp[p][j+1][0])%mod;
			if(i==n||j>=2) dp[t][j][1]=1ll*j*(dp[p][j-1][1]+dp[p][j+1][1])%mod;
			if(j==3) dp[t][j][1]=dp[p][2][1];
			if(j>1) upd(dp[t][j][1],2ll*dp[p][j][0]%mod);
		}
		if(i==n) upd(dp[t][1][1],2ll*dp[p][1][0]%mod);
//		for(int j=1;j<=i;j++)
//			cerr<<dp[t][j][0]<<" \n"[i==j];
//		for(int j=1;j<=i;j++)
//			cerr<<dp[t][j][1]<<" \n"[i==j];
//		cerr<<endl;
	}
	upd(ans,mod-dp[n&1][1][1]);
	cout<<ans<<endl;
//	fclose(stdin);fclose(stdout);
	return 0;
}
