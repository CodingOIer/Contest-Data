#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n, ans;
int a[N], now[N];
int f[N], g[N];
void dfs(int x) {
	if(x > n) {
		int res = 0;
		for(int i = 1; i <= n; i++) {
			if(now[i] == 0) res++;
			f[i] = g[i] = 0;
		}
		if(res == 0 || res == n) return;
		int Max = 0, Min = 1e18, Get = 0;
		for(int i = 1; i <= n; i++) {
			if(now[i] == 0) {
				Max = max(Max, a[i]);
				f[Max]++;
				if(f[Max] == 1) Get++;
			}
			else {
				Min = min(Min, a[i]);
				g[Min]++;
				if(g[Min] == 1) Get++;
			}
		}
		if(Get > ans) {
			ans = Get;
		}
		return;
	}
	now[x] = 0;
	dfs(x + 1);
	now[x] = 1;
	dfs(x + 1);
}
signed main() {
	freopen("escape.in", "r", stdin);
	freopen("escape.out", "w", stdout);
    scanf("%lld", &n);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    dfs(1);
    printf("%lld", ans);	
	return 0;
}

