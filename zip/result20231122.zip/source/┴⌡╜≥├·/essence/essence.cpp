#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n, m, tot, ans;
int A[N], a[N], l[N], r[N], c[N], t[N];
int L[N], R[N], C[N];
vector<int>p[N];
bool cmp(int a, int b) {
	return R[a] < R[b];
}
signed main() {
	freopen("essence.in", "r", stdin);
	freopen("essence.out", "w", stdout);
    scanf("%lld %lld", &n, &m);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for(int i = 1; i <= m; i++) {
        scanf("%lld %lld %lld %lld", &l[i], &r[i], &c[i], &t[i]);	
	}
	int tot = 0, h = 0;
	for(int x = 1; x <= n; x++) {
		ans = 0;
		for(int i = 1; i <= n; i++) A[i] = a[i], p[i].clear();
		for(int j = 1; j <= m; j++) {
			L[j] = l[j], R[j] = r[j];
			C[j] = c[j];
			if(t[j]) L[j] = min(L[j], x), R[j] = max(R[j], x);
			for(int k = L[j]; k <= R[j]; k++)
			    p[k].push_back(j);
		}
		for(int i = 1; i <= n; i++) {
			sort(p[i].begin(), p[i].end(), cmp);
            for(int j = 0; j < p[i].size(); j++) {
            	if(A[i] == 0) break;
            	
            	int now = p[i][j];
            	if(C[now] == 0) tot++;
            	h++;
            	int use = min(A[i], C[now]);
            	A[i] -= use;
            	C[now] -= use;
            	ans += use;
			}			
		}
		//cerr << h - tot << endl;
		printf("%lld ", ans);
	}
	return 0;
}







