#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,m;
struct XXX{
	int l,r,c;
	bool t;
}z[200005];
int a[200005];
struct Lq{
	int l,r,c;
}q[200005];
int qzh[200005];
inline bool cmp(Lq x,Lq y){
	if(x.l==y.l) return x.r<y.r;
	return x.l<y.l;
}
inline bool cmb(Lq x,Lq y){
	if(x.r==y.r) return x.l<y.l;
	return x.r<y.r;
}
int gg[2005],gg2[2005];
int maxx,sums;
signed main(){
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;++i) a[i]=read();
	for(register int i=1;i<=m;++i){
		z[i].l=read(),z[i].r=read();
		z[i].c=read( ),z[i].t=read();
		maxx=max(maxx,z[i].r);
		sums+=z[i].c;
	}
	for(register int i=1;i<=n;++i){
		qzh[i]=qzh[i-1]+a[i];
	}
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=m;++j){
			if(z[j].t){
				q[j].l=min(z[j].l,i);
				q[j].r=max(z[j].r,i);
			}
			else{
				q[j].l=z[j].l;
				q[j].r=z[j].r;
			}
			q[j].c=z[j].c;
		}
		int s=0;
		ll ans=0;
		if(n<=2000){
			sort(q+1,q+m+1,cmb);
			for(register int j=1;j<=m;++j) gg[j]=q[j].c;
			for(register int j=1;j<=m;++j) gg2[j]=q[j].r;
			for(register int t=1;t<=n;++t){
				int k=upper_bound(gg2+1,gg2+m+1,t-1)-gg2;
				if(k==m+1) break;
				int qiqi=k;
				int Ttuo=0;
				while(k<=m){
					while(q[k].l>t&&k<=m) ++k;
					if(k>m||k<=0) break;
					if(gg[k]+Ttuo<=a[t]){
						Ttuo+=gg[k];
						ans+=gg[k];
						gg[k]=0;
					}
					else{
						ans+=(a[t]-Ttuo);
						gg[k]-=(a[t]-Ttuo);
						break;
					}
					k++; 
				}
			}
		}
		else{
			sort(q+1,q+m+1,cmp);
			for(register int j=1;j<=m;++j){
	//			cout<<q[j].l<<" "<<q[j].r<<" "<<q[j].c<<" ";
				if(q[j].l!=q[j-1].l){
					s=max(0,s-(qzh[q[j].l-1]-qzh[q[j-1].l-1]));
				}
				int sx=qzh[q[j].r]-qzh[q[j].l-1];
				ans+=min(sx-s,q[j].c);
				s=min(sx,s+q[j].c);
			}
			
		}
		if(maxx<i){
			for(int j=i;j<=n;++j){
				printf("%lld ",ans);
			}
			return 0;
		}
		printf("%lld ",ans);
	}
	return 0;
}

