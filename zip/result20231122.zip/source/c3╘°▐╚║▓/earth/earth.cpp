#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
constexpr int mod = 998244353;
namespace Poly
{
	int t, w2[(1 << 16) + 1];
	int plus (int x, int y) {return x + y >= mod ? x + y - mod : x + y;}
	int power (int x, int y)
	{
		int z = 1;
		for (; y; y >>= 1, x = 1LL * x * x % mod) if (y & 1) z = 1LL * z * x % mod;
		return z;
	}
	void init (void)
	{
		*w2 = 1; w2[1 << 16] = power(power(3, 119), 1 << 5);
		for (int i = 16; i; i--) w2[1 << (i - 1)] = 1LL * w2[1 << i] * w2[1 << i] % mod;
		for (int i = 1; i < (1 << 16); i++) w2[i] = 1LL * w2[i & (i - 1)] * w2[i & -i] % mod;
	}
	void DIF (int *a)
	{
		for (int i = t >> 1; i; i >>= 1)
			for (int *j = a, *o = w2; j < a + t; j += i << 1, o++)
				for (int *k = j, r; k < j + i; k++) r = 1LL * *o * k[i] % mod, k[i] = plus(*k, mod - r), *k = plus(*k, r);
	}
	void DIT (int *a)
	{
		for (int i = 1; i < t; i <<= 1)
			for (int *j = a, *o = w2; j < a + t; j += i << 1, o++)
				for (int *k = j, r; k < j + i; k++) r = plus(*k, k[i]), k[i] = 1LL * *o * (*k - k[i] + mod) % mod, *k = r;
		std::reverse(a + 1, a + t);
		for (int *i = a, invt = mod - (mod - 1) / t; i < a + t; i++) *i = 1LL * *i * invt % mod;
	}
	void mul (int *a, int *b, int k) {t = 1 << k; DIF(a); DIF(b); for (int i = 0; i < t; i++) a[i] = 1LL * a[i] * b[i] % mod; DIT(a);}
}
using Poly::mul;
int k,n,p;
int a[21],ans;
int b[21];
int ggb[21];
int mex(int c[]){
	if(c[1]!=0) return 0;
	for(int i=1;i<=n;i++){
		if(c[i]>=c[i-1]+2){
			return c[i-1]+1;
		}
	}
	return c[n]+1;
}
void dfs(int x,int c){
	if(x>(1<<k)) return;
	if(c==n){
		for(int i=1;i<=n;i++ )a[i]=ggb[i];
		int gg=1,mp=-1;
		int last=-1;
		memset(b,0,sizeof(b));
		while(gg<=k+1){
			gg++;
			sort(a+1,a+n+1);
			int t=mex(a)-1;
			for(int i=1;i<=n;i++){
				b[i]=a[i]^t;
			}
			
			bool tot=0;
			for(int i=1;i<=n;i++){
				if(a[i]!=b[i]){
					tot=1;
					break;
				}
			}
			if(last==t){
				mp=t+1;
				break;
			}
			if(t==0){
				mp=1;
				break;
			}
			if(!tot){
				mp=t+1;
				break;
			}
			mp=t+1;
			last=t;
			swap(a,b);
		}
		if(mp==p){
			ans++;
		}
		return;
	}
	for(int i=x+1;i<(1<<k);i++){
		ggb[c+1]=i;
		dfs(i,c+1);
		ggb[c+1]=0;
	}
}
signed main(){
	freopen("earth.in","r",stdin);
	freopen("earth.out","w",stdout);
	Poly::init();
	int T=read();
	while(T--){
		k=read(),n=read(),p=read();
		ans=0;
		a[1]=0;
//		if(k<=4){
			dfs(0,1);
			cout<<ans<<endl;
			continue;
//		}
	}
	return 0;
} 

