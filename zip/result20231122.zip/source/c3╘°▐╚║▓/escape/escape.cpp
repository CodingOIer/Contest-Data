#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n;
int a[100005];
signed main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	cout<<n;
	return 0;
}

