#include <bits/stdc++.h>
using namespace std;
int n, m;
int a[400000], b[400000], l[400000], r[400000], c[400000], t[400000];
int main()
{
    freopen("essence.in", "r", stdin);
    freopen("essence.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < m; i++)
        scanf("%d%d%d%d", &l[i], &r[i], &c[i], &t[i]);
    for (int i = 1; i <= n; i++)
    {
        fill(b, b + n + 1, 0);
        for (int j = 0; j < m; j++)
            for (int k = min(l[j], t[j] ? i : n), s = c[j], p; k <= max(r[j], t[j] ? i : 0); k++)
                b[k] += p = min(s, a[k] - b[k]),
                        s -= p;
        printf("%lld ", accumulate(b, b + n + 1, 0ll));
    }
    puts("");
    return 0;
}