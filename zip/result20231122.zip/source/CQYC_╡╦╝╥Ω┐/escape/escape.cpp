#include <bits/stdc++.h>
using namespace std;
int n, ans;
int f[240][240][240];
int main()
{
    freopen("escape.in", "r", stdin);
    freopen("escape.out", "w", stdout);
    scanf("%d", &n);
    memset(f, 0x80, sizeof f);
    f[0][1][n] = 0;
    for (int i = 0, x; i < n; i++)
    {
        scanf("%d", &x);
        for (int j = 1; j <= n; j++)
            for (int k = 1; k <= n; k++)
                f[i + 1][max(j, x)][k] = max(f[i + 1][max(j, x)][k], f[i][j][k] + (x >= j)), f[i + 1][j][min(k, x)] = max(f[i + 1][j][min(k, x)], f[i][j][k] + (x <= k));
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            ans = max(ans, f[n][i][j]);
    printf("%d\n", ans);
    return 0;
}