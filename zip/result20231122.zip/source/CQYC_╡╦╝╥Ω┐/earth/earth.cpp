#include <bits/stdc++.h>
using namespace std;
int t, k, n, p;
int ans[20][20][20];
const int P = 998244353;
int main()
{
    freopen("earth.in", "r", stdin);
    freopen("earth.out", "w", stdout);
    for (int k = 1; k < 5; k++)
        for (int i = 0; i < 1 << (1 << k); i++)
        {
            set<int> s;
            for (int j = 0; j < 1 << k; j++)
                if (i >> j & 1)
                    s.insert(j);
            for (int j = 0; j < 10; j++)
            {
                int mex = 0;
                set<int> t;
                for (int x : s)
                    mex += x == mex;
                for (int x : s)
                    t.insert(x ^ (mex - 1));
                s = t;
            }
            int mex = 0;
            for (int x : s)
                mex += x == mex;
            ans[k][__builtin_popcount(i)][mex]++;
        }
    scanf("%d", &t);
    while (t--)
        scanf("%d%d%d", &k, &n, &p), printf("%d\n", ans[k][n][p]);
    return 0;
}