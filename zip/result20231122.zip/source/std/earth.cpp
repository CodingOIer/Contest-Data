#include <bits/stdc++.h>
constexpr int mod = 998244353;
constexpr int B = 17;
int t, w2[(1 << 16) + 1];
int plus (int x, int y) {return x + y >= mod ? x + y - mod : x + y;}
int power (int x, int y)
{
	int z = 1;
	for (; y; y >>= 1, x = 1LL * x * x % mod) if (y & 1) z = 1LL * z * x % mod;
	return z;
}
void init (void)
{
	*w2 = 1; w2[1 << 16] = power(power(3, 119), 1 << 5);
	for (int i = 16; i; i--) w2[1 << (i - 1)] = 1LL * w2[1 << i] * w2[1 << i] % mod;
	for (int i = 1; i < (1 << 16); i++) w2[i] = 1LL * w2[i & (i - 1)] * w2[i & -i] % mod;
}
void DIF (int *a)
{
	for (int i = t >> 1; i; i >>= 1)
		for (int *j = a, *o = w2; j < a + t; j += i << 1, o++)
			for (int *k = j, r; k < j + i; k++) r = 1LL * *o * k[i] % mod, k[i] = plus(*k, mod - r), *k = plus(*k, r);
}
void DIT (int *a)
{
	for (int i = 1; i < t; i <<= 1)
		for (int *j = a, *o = w2; j < a + t; j += i << 1, o++)
			for (int *k = j, r; k < j + i; k++) r = plus(*k, k[i]), k[i] = 1LL * *o * (*k - k[i] + mod) % mod, *k = r;
	std::reverse(a + 1, a + t);
	for (int *i = a, invt = mod - (mod - 1) / t; i < a + t; i++) *i = 1LL * *i * invt % mod;
}
int fct[1 << B], inv[1 << B], dp[B + 1][2][1 << B], a[1 << B], b[1 << B]; std::vector<int> ans[B + 1][B + 1];
int binom (int n, int m) {return m < 0 or m > n ? 0 : 1LL * fct[n] * inv[m] % mod * inv[n - m] % mod;}
signed main ()
{
	freopen("earth.in", "r", stdin);
	freopen("earth.out", "w", stdout);
	init(); fct[0] = inv[0] = inv[1] = 1;
	for (int i = 1; i < (1 << B); i++) fct[i] = 1LL * fct[i - 1] * i % mod;
	for (int i = 2; i < (1 << B); i++) inv[i] = 1LL * (mod - mod / i) * inv[mod % i] % mod;
	for (int i = 3; i < (1 << B); i++) inv[i] = 1LL * inv[i - 1] * inv[i] % mod;
	for (int p = 0; p < B; p++)
	{
		for (int k = p; k <= B; k++) ans[p][k].resize(1 << k);
		for (int k = p + 1; k <= B; k++) for (int n = 0; n < (1 << B); n++) dp[k][0][n] = dp[k][1][n] = 0;
		for (int n = 0; n <= std::max((1 << p) - 2, 0); n++)
			ans[p][p + 1][(1 << p) + n] = dp[p + 1][0][(1 << p) + n] = dp[p + 1][1][(1 << p) + n] = binom(std::max((1 << p) - 2, 0), n);
		for (int k = p + 2; k <= B; k++)
		{
			for (int n = 1; n < (1 << (k - 1)); n++)
				dp[k][0][(1 << (k - 1)) + n] = plus(dp[k - 1][0][n], dp[k - 1][1][n]), dp[k][1][(1 << (k - 1)) + n] = dp[k - 1][1][n];
			for (int r = 0; r < (1 << k); r++) a[r] = binom(1 << (k - 1), r), b[r] = binom((1 << (k - 1)) - 1, r);
			t = 1 << k; DIF(dp[k - 1][0]); DIF(a); DIF(b);
			for (int i = 0; i < t; i++) a[i] = 1LL * a[i] * dp[k - 1][0][i] % mod, b[i] = 1LL * b[i] * dp[k - 1][0][i] % mod;
			DIT(a); DIT(b);
			for (int n = 0; n < (1 << k); n++) ans[p][k][n] = dp[k][0][n] = plus(dp[k][0][n], a[n]), dp[k][1][n] = plus(dp[k][1][n], b[n]);
		}
	}
	int T;
	for (scanf("%d", &T); T--; ) {int k, n, p; scanf("%d%d%d", &k, &n, &p); printf("%d\n", (p & (p - 1)) or p == (1 << k) ? 0 : ans[std::__lg(p)][k][n]);}
	return 0;
}
