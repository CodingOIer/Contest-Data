// ��ݴ����� Falco �ύ
// �ύ�� UID��2208
#include <bits/stdc++.h>
constexpr int inf = 1 << 30;
constexpr int maxn = 1 << 18;
int n, a[maxn], b[maxn], lis_l[maxn], lis_r[maxn], lds_l[maxn], lds_r[maxn];
int dp_lis[maxn], dp_lds[maxn], premax[maxn], premin[maxn], ans; std::set<int> s;
struct SegmentTree
{
	int max[maxn << 2], tag[maxn << 2];
	#define ls (k << 1)
	#define rs (k << 1 | 1)
	#define mid ((l + r) >> 1)
	void modify (int k, int w) {max[k] += w; tag[k] += w;}
	void update (int k, int l, int r, int ql, int qr, int w)
	{
		if (ql <= l and r <= qr) {modify(k, w); return;}
		if (tag[k]) modify(ls, tag[k]), modify(rs, tag[k]), tag[k] = 0;
		if (ql <= mid) update(ls, l, mid, ql, qr, w);
		if (qr > mid) update(rs, mid + 1, r, ql, qr, w);
		max[k] = std::max(max[ls], max[rs]);
	}
	int query (int k, int l, int r, int ql, int qr)
	{
		if (ql <= l and r <= qr) return max[k];
		if (tag[k]) modify(ls, tag[k]), modify(rs, tag[k]), tag[k] = 0;
		return std::max(ql <= mid ? query(ls, l, mid, ql, qr) : -inf, qr > mid ? query(rs, mid + 1, r, ql, qr) : -inf);
	}
} LIS, LDS;
signed main ()
{
	freopen("escape.in", "r", stdin);
	freopen("escape.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) assert(scanf("%d", &a[i]) == 1);
	for (int i = 1; i <= n; i++) b[i] = -1;
	for (int i = n; i >= 1; i--)
	{
		int p = std::lower_bound(b + 1, b + n + 1, -a[i]) - b;
		lis_l[i] = -b[p]; lis_r[i] = a[i] - 1;
		if (lis_l[i] <= lis_r[i]) LIS.update(1, 1, n, lis_l[i], lis_r[i], 1);
		b[p] = -a[i]; dp_lis[a[i]] = p + 1;
	}
	for (int i = 1; i <= n; i++) b[i] = n + 1;
	for (int i = n; i >= 1; i--)
	{
		int p = std::lower_bound(b + 1, b + n + 1, a[i]) - b;
		lds_l[i] = a[i]; lds_r[i] = b[p] - 1;
		if (lds_l[i] <= lds_r[i]) LDS.update(1, 1, n, lds_l[i], lds_r[i], 1);
		b[p] = a[i]; dp_lds[a[i]] = p + 1;
	}
	s.insert(0); s.insert(n + 1);
	for (int i = 1; i <= n; i++)
	{
		if (lis_l[i] <= lis_r[i]) LIS.update(1, 1, n, lis_l[i], lis_r[i], -1);
		if (lds_l[i] <= lds_r[i]) LDS.update(1, 1, n, lds_l[i], lds_r[i], -1);
		int w = a[i], L = *std::prev(s.lower_bound(w)), R = *s.lower_bound(w);
		ans = std::max(ans, (R <= n ? LIS.query(1, 1, n, R, n) : 0) + LDS.query(1, 1, n, w, w) + 1);
		ans = std::max(ans, LIS.query(1, 1, n, w, w) + (L >= 1 ? LDS.query(1, 1, n, 1, L) : 0) + 1);
		ans = std::max(ans, (premax[w] = (L >= 1 ? premax[L] : 0) + 1) + (premin[w] = (R <= n ? premin[R] : 0) + 1) - 1);
		if (L >= 1) LIS.update(1, 1, n, L, L, 1);
		if (R <= n) LDS.update(1, 1, n, R, R, 1);
		LIS.update(1, 1, n, w, w, premax[w] + premin[w] - 1);
		LDS.update(1, 1, n, w, w, premax[w] + premin[w] - 1);
		s.insert(w);
	}
	return !printf("%d\n", ans);
}
