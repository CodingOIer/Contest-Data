// ��ݴ����� Falco �ύ
// �ύ�� UID��2208
#include <bits/stdc++.h>

#define fr first
#define sc second
#define all(a) (a).begin(), (a).end()
#define mall(a, n) (a).begin(), (a).begin() + n
#define TIME (clock() / (double)CLOCKS_PER_SEC)
using namespace std;

template <typename T>
void setmin(T &x, T y)
{
	x = min(x, y);
}

template <typename T>
void setmax(T &x, T y)
{
	x = max(x, y);
}

using ll = long long;

const ll llinf = 1e18 + 100;

const int maxn = 5e5 + 100, maxc = 1010, inf = 1e9 + 100;

vector<ll> pans, sans;

int a[maxn];

int n;

namespace precalc
{
	struct item
	{

		ll w = 0, u = 0;

		void init(const int &t)
		{
			w = t;
			u = 0;
		}

		void update(const item &first, const item &second)
		{
			w = min(first.w, second.w);
		}

		static item merge(const item &first, const item &second)
		{
			item res;
			res.update(first, second); // careful with different lengths
			return res;
		}

		void modify(ll m)
		{
			w += m;
			u += m;
		}

		void push(item &first, item &second)
		{
			first.modify(u);
			second.modify(u);
			u = 0;
		}
	};

	struct segtree
	{
		vector<item> tree;
		int n = 1;

		void init(int n_)
		{
			n = n_;
			tree.resize(1 << (__lg(max(1, n - 1)) + 2));
		}

		item ask(int l, int r, int i, int vl, int vr)
		{
			if (vl != vr)
			{
				tree[i].push(tree[i * 2 + 1], tree[i * 2 + 2]);
			}
			if (l == vl && r == vr)
			{
				return tree[i];
			}
			int m = (vl + vr) >> 1;
			if (r <= m)
			{
				return ask(l, r, i * 2 + 1, vl, m);
			}
			else if (m < l)
			{
				return ask(l, r, i * 2 + 2, m + 1, vr);
			}
			else
			{
				return item::merge(ask(l, m, i * 2 + 1, vl, m), ask(m + 1, r, i * 2 + 2, m + 1, vr));
			}
		}

		item ask(int l, int r)
		{
			l = max(l, 0);
			r = min(r, n - 1);
			if (l > r)
				return item();
			return ask(l, r, 0, 0, n - 1);
		}

		void modify(int l, int r, ll modifier, int i, int vl, int vr)
		{
			if (vl != vr)
			{
				tree[i].push(tree[i * 2 + 1], tree[i * 2 + 2]);
			}
			if (l == vl && r == vr)
			{
				tree[i].modify(modifier);
				return;
			}
			int m = (vl + vr) >> 1;
			if (r <= m)
			{
				modify(l, r, modifier, i * 2 + 1, vl, m);
			}
			else if (m < l)
			{
				modify(l, r, modifier, i * 2 + 2, m + 1, vr);
			}
			else
			{
				modify(l, m, modifier, i * 2 + 1, vl, m);
				modify(m + 1, r, modifier, i * 2 + 2, m + 1, vr);
			}
			tree[i].update(tree[i * 2 + 1], tree[i * 2 + 2]);
		}

		void modify(int l, int r, ll modifier)
		{
			l = max(l, 0);
			r = min(r, n - 1);
			if (l > r)
				return;
			modify(l, r, modifier, 0, 0, n - 1);
		}
	};

	void prec(vector<tuple<int, int, int>> const &segs)
	{
		vector<vector<pair<int, int>>> cl(n);
		for (auto [l, r, c] : segs)
		{
			cl[l].emplace_back(r, c);
			if (l != r)
				cl[r].emplace_back(l, c);
		}
		for (int t = 0; t < 2; t++)
		{
			segtree q;
			q.init(n + 1);
			vector<ll> pa(n + 1);
			for (int i = 0; i < n; i++)
				pa[i + 1] = a[i] + pa[i];
			ll lastans = 0;
			pans[0] = 0;
			for (int i = 0; i < n; i++)
			{
				for (auto [l, c] : cl[i])
					if (l <= i)
						q.modify(0, l, -c);
				setmin(lastans, q.ask(0, n).w + pa[i + 1]);
				pans[i + 1] = lastans;
				q.modify(i + 1, i + 1, lastans - pa[i + 1]);
			}

			for (int i = 0; i < n; i++)
				for (auto &[j, c] : cl[i])
					j = n - 1 - j;
			reverse(a, a + n);
			reverse(all(cl));
			swap(sans, pans);
		}
		reverse(mall(sans, n + 1));
	}
}

struct item
{
	ll w = 0, s = 0;

	template <typename T>
	void init(const T &t, int l)
	{
		w = s = t;
		w += sans[l + 1];
	}

	void update(const item &first, const item &second)
	{
		w = min(first.w, first.s + second.w);
		s = first.s + second.s;
	}

	void upd(int x)
	{
		w += x;
		s += x;
	}

	static item merge(const item &first, const item &second, int l, int r)
	{
		item res;
		res.update(first, second); // careful with different lengths
		return res;
	}
};

struct segtree
{
	vector<item> tree;
	int n = 1;
	int tp;

	template <typename T>
	void build(const vector<T> &v, int i, int l, int r)
	{
		if (l == r)
		{
			tree[i].init(v[l], l);
			return;
		}
		int m = (l + r - tp) >> 1;
		build(v, i * 2 + 1, l, m);
		build(v, i * 2 + 2, m + 1, r);
		tree[i].update(tree[i * 2 + 1], tree[i * 2 + 2]);
	}

	template <typename T>
	void build(const vector<T> &v)
	{
		n = v.size();
		tree.resize(1 << (__lg(max(1, n - 1)) + 2));
		build(v, 0, 0, n - 1);
	}

	template <typename T>
	void set(int ind, const T &t)
	{
		int l = 0, r = n - 1, i = 0;
		int ptr = -1;
		while (l != r)
		{
			int m = (l + r - tp) >> 1;
			if (ind <= m)
			{
				i = i * 2 + 1;
				r = m;
			}
			else
			{
				i = i * 2 + 2;
				l = m + 1;
			}
		}
		tree[i].upd(t);
		while (i != 0)
		{
			i = (i - 1) / 2;
			tree[i].update(tree[i * 2 + 1], tree[i * 2 + 2]);
			--ptr;
		}
	}
};

vector<pair<int, int>> op[maxn];

vector<ll> vans, ans;

ll tmp[maxn];

segtree t;

void go(int v, int l, int r, int tp)
{
	if (l == r)
	{
		// try removing this
		ll s = a[l];
		for (auto [r, c] : op[l])
			if (r == l)
			{
				s -= c;
				t.set(r, -c);
			}
		setmin(ans[l], s + pans[l] + sans[l + 1]);
		return;
	}
	int m = (l + r - tp) / 2;
	go(2 * v + 2, m + 1, r, tp);

	ll tval = t.tree[2 * v + 2].w;
	ll s = 0;
	for (int i = m; i >= l; i--)
	{
		s += a[i];
		for (auto [R, c] : op[i])
			if (R >= i && R <= r)
			{
				if (R > m)
				{
					t.set(R, -c);
					tval = t.tree[2 * v + 2].w;
				}
				else
				{
					s -= c;
				}
			}
		tmp[i] = tval + s + pans[i];
	}
	s = 0;
	for (int i = l; i <= m; i++)
	{
		setmin(s, tmp[i]);
		setmin(ans[i], s);
	}
	go(2 * v + 1, l, m, tp);
}

void solve()
{
	int m;
	cin >> n >> m;
	vans.assign(n + 1, 0);
	ans.assign(n + 1, 0);
	sans.assign(n + 1, 0);
	pans.assign(n + 1, 0);
	for (int i = 0; i < n; i++)
	{
		op[i].clear();
	}
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	ll B = 0;
	vector<tuple<int, int, int>> q0;
	for (int i = 0; i < m; i++)
	{
		int l, r, c, t;
		cin >> l >> r >> c >> t;
		l--;
		r--;
		B += c;
		op[l].emplace_back(r, c);
		if (l != r)
			op[r].emplace_back(l, c);
		if (t == 0)
			q0.emplace_back(l, r, c);
	}
	precalc::prec(q0);
	// try removing this
	for (int i = 0; i < n; i++)
		setmin(ans[i], pans[n]);
	for (int its = 0; its < 2; its++)
	{
		vector<ll> q(a, a + n);
		t.tp = its;
		t.build(q);
		go(0, 0, n - 1, its);
		for (int i = 0; i < n; i++)
			for (auto &[j, c] : op[i])
			{
				j = n - 1 - j;
			}
		reverse(a, a + n);
		reverse(op, op + n);
		reverse(mall(pans, n + 1));
		reverse(mall(sans, n + 1));
		swap(pans, sans);
		swap(ans, vans);
	}
	reverse(mall(vans, n));
	for (int i = 0; i < n; i++)
		setmin(ans[i], vans[i]);
	for (int i = 0; i < n; i++)
		cout << B + ans[i] << ' ';
	cout << '\n';
}

int main()
{
	freopen("essence.in", "r", stdin);
	freopen("essence.out", "w", stdout);

	ios::sync_with_stdio(0);
	cin.tie(0);

	solve();
}
