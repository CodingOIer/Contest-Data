#include<bits/stdc++.h>
using namespace std;
int k,n,p,s;
bitset<1000> a[1000];
int ultra(int x) {
	for(int i=1;i<=x;i++) {
		
	}
}
void check(int x) {
	a[0]=x<<1|1;
	for(int i=1;i<=100;i++) {
		a[i]=ultra(i-1);
	}
}
int main() {
	freopen("earth.in","r",stdin);
	freopen("earth.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) {
		scanf("%d %d %d",&k,&n,&p);
		s=(1<<k)-1;
		for(int i=0;i<(1<<s);i++) {
			int num=0;
			for(int j=1;j<=s;j++) if(i&(1<<(j-1))) num++;
			if(num==n-1) check(i);
		}
		printf("%d\n",s-2); 
	}
	return 0;
}
