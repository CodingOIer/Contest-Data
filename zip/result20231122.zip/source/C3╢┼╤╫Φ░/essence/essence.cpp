#include<bits/stdc++.h>
using namespace std;
int a[100005];
struct node {
	int l,r,c,t;
}d[100005];
int main() {
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d %d %d %d",&d[i].l,&d[i].r,&d[i].c,&d[i].t);	
	for(int i=1;i<=n;i++) {
		int L=d[1].l,R=d[1].r;
		if(d[1].t) {
			L=min(L,i);
			R=max(R,i);
		}
		int ans=0,s=d[1].c;
		for(int j=1;j<=n;j++) {
			if(L<=j && j<=R) {
				if(s>=a[j]) ans+=a[j],s-=a[j];
				else ans+=s,s=0;
			}
		}
		printf("%d ",ans);
	}
	return 0;
} 
