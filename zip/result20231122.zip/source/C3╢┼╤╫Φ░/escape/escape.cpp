#include<bits/stdc++.h>
using namespace std;
int f[2][2005][2005],a[2005];
int main() {
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) {
		memset(f[i&1],-0x3f,sizeof f[i&1]);
		for(int j=0;j<i;j++) {
			for(int k=0;k<i;k++) {
				if(j==k && j+k!=0) continue;
				if(a[i]<a[j] || j==0) f[i&1][a[i]][a[k]]=max(f[i&1][a[i]][a[k]],f[1-i&1][a[j]][a[k]]+1);
				else f[i&1][a[j]][a[k]]=max(f[i&1][a[j]][a[k]],f[1-i&1][a[j]][a[k]]);
				if(a[i]>a[k] || k==0) f[i&1][a[j]][a[i]]=max(f[i&1][a[j]][a[i]],f[1-i&1][a[j]][a[k]]+1);
				else f[i&1][a[j]][a[k]]=max(f[i&1][a[j]][a[k]],f[1-i&1][a[j]][a[k]]);
			}
		}
	}
	int maxn=0;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			if(i==j) continue;
			maxn=max(maxn,f[n&1][a[i]][a[j]]);
		}	 
	}
	printf("%d\n",maxn);
	return 0;
} 
