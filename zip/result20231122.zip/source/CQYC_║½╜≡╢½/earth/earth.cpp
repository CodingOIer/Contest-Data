#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,K,n,P,ans;
bool vis[N];
il int calc(int *a,int t){
    for(int p=0,lst=-1;p<=(1<<K);++p){
        int now=0;
        for(int i=1;i<=t;++i) vis[a[i]]=1;
        while(vis[now]) ++now;
        for(int i=1;i<=t;++i) vis[a[i]]=0;
        --now;
        if(lst==now) return now+1;
        for(int i=1;i<=t;++i) a[i]^=now;
        lst=now;
    }
    return -1;
}
int a[N],t;
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("earth.in","r",stdin);
	freopen("earth.out","w",stdout);
	T=read();
    // T=1;
	while(T--){
        K=read();n=read();P=read();ans=0;
        for(int i=1;i<(1<<(1<<K));i+=2){
            t=0;
            for(int j=0;j<(1<<K);++j) if((1<<j)&i) a[++t]=j;
            // if(t==n) cerr<<i<<" "<<calc(a,t)<<"\n";
            if(t==n&&calc(a,t)==P) ++ans;
        }
        write(ans);putchar('\n');
	}
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}