#include<bits/stdc++.h>
#define ll long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 400010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(ll x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,m,a[N],tot,z[N];
ll sum[N];
struct node{
    int l,r,c,t;
} b[N];
vector<pii> V[N];
il int find(int x){
    return lower_bound(z+1,z+1+tot,x)-z;
}
priority_queue<pii,vector<pii>,greater<pii>> P;
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<=n;++i){
        a[i]=read();sum[i]=sum[i-1]+a[i];
    }
    for(int i=1;i<=m;++i){
        b[i].l=read();b[i].r=read();b[i].c=read();b[i].t=read();
    }
    for(int x=1;x<=n;++x){
        tot=0;z[++tot]=1;z[++tot]=n+1;
        for(int i=1;i<=m;++i){
            int l=b[i].l,r=b[i].r;
            if(b[i].t){
                l=min(l,x);r=max(r,x);
            }
            z[++tot]=l;z[++tot]=r+1;
        }
        sort(z+1,z+1+tot);
        tot=unique(z+1,z+1+tot)-z-1;
        for(int i=1;i<=m;++i){
            int l=b[i].l,r=b[i].r;
            if(b[i].t){
                l=min(l,x);r=max(r,x);
            }
            V[find(l)].pk(pii(r,b[i].c));
        }
        ll ans=0;
        for(int i=1,now=1;i<tot;++i){
            ll A=sum[z[i+1]-1]-sum[z[i]-1];
            for(auto y:V[i]) P.push(y);
            V[i].clear();
            // cerr<<z[i]<<" "<<now<<"\n";
            while(!P.empty()&&A){
                pii y=P.top();P.pop();
                if(y.fi<z[i]) continue;
                int tmp=min((ll)y.se,A);
                y.se-=tmp;A-=tmp;ans+=tmp;
                // cerr<<z[i]<<" "<<z[i]<<"\n";
                if(y.se) P.push(y);
            }
        }
        write(ans);putchar(' ');
        while(!P.empty()) P.pop();
        // break;
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}