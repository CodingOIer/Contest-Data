#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 2010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Mx(int &a,int b){
    a=a>b?a:b;
}
int n,p[N],ans,dp[N][N];
vector<int> V[N];
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i) p[i]=read();
    memset(dp,-0x3f,sizeof(dp));
    dp[0][0]=0;
    for(int i=0;i<=n;++i){
        for(int j=0;j<=n;++j) if(dp[i][j]>=0){
            ans=max(ans,dp[i][j]);
            int now=max(i,j);
            for(int k=now+1;k<=n;++k){
                if(p[k]>p[i]||!i) Mx(dp[k][j],dp[i][j]+1);
                if(p[k]<p[j]||!j) Mx(dp[i][k],dp[i][j]+1);
                if((p[k]>p[i]||!i)&&(p[k]<p[j]||!j)) break;
            }
        }
    }
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}