#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10,mod=998244353;
int T,k,n,p,ans,a[N];
bool vis[N],ned[N];
vector<int>pp;
void check()
{
    // for(int i=0;i<=k;i++) ned[i]=0;
    // for(int i=1;i<(1<<k);i++)
    //     if(vis[i]) ned[31-__builtin_clz(i)]=1;
    // for(int i=0;i<p;i++)
    //     if(!ned[i]) return;
    // if(ned[p]) return;
    
    ned[0]=1;
    for(int i=1;i<(1<<k);i++) ned[i]=vis[i];
    ned[1<<k]=0;
    for(int P=0,m;P<=k;P++)
    {
        for(int i=0;i<=(1<<k);i++)
            if(!ned[i]) {m=i-1;break;}
        pp.clear();
        for(int i=0;i<(1<<k);i++)
            if(ned[i^m]) pp.push_back(i);
        for(int i=0;i<(1<<k);i++) ned[i]=0;
        for(int x:pp) ned[x]=1;
    }
    for(int i=0;i<=(1<<k);i++)
    {
        if(!ned[i])
        {
            if(i==p)
            {
                ++ans;
                // for(int j=1;j<(1<<k);j++)
                //     if(vis[j]) cout<<j<<" ";
                // cout<<"->";
                // for(int j=1;j<(1<<k);j++)
                //     if(ned[j]) cout<<j<<" ";
                // cout<<endl;
            }
            return;
        }
    }
}
void dfs(int x,int rest)
{
    if(!rest) return check();
    if(x==(1<<k)) return;
    vis[x]=1,dfs(x+1,rest-1);
    vis[x]=0,dfs(x+1,rest);
}
int main()
{
    freopen("earth.in","r",stdin);
    freopen("earth.out","w",stdout);
    // cerr<<__builtin_clz(1)<<endl;
    scanf("%d",&T);
    while(T--)
    {
        ans=0;
        scanf("%d%d%d",&k,&n,&p);
        if(p&(p-1)) {puts("0");continue;}
        // p=31-__builtin_clz(p);
        dfs(1,n-1);
        printf("%d\n",ans);
        // return 0;
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
