#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
typedef long long ll;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=2e5+10,M=1e6+10;
const ll inf=1e18;
int n,m,S,T,sid,a[N],L[N],R[N],c[N],t[N];
int ID[N],dep[N],cur[N];
int first[N],to[M],nxt[M],cnt;
ll lth[M];
queue<int>q;
inline void inc(int x,int y,ll l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
inline void Inc(int x,int y,ll l) {inc(x,y,l);inc(y,x,0);}
void build(int id,int l,int r)
{
    if(!ID[id]) ID[id]=++sid;
    first[ID[id]]=0;
    if(l==r) return Inc(ID[id],T,a[l]);
    int mid=(l+r)>>1;
    build(lt,l,mid);
    build(rt,mid+1,r);
    Inc(ID[id],ID[lt],inf);
    Inc(ID[id],ID[rt],inf);
}
void add(int id,int l,int r,int L,int R,int x)
{
    if(l>R||r<L) return;
    if(L<=l&r<=R) return Inc(x,ID[id],inf);
    int mid=(l+r)>>1;
    add(lt,l,mid,L,R,x);
    add(rt,mid+1,r,L,R,x);
}
bool bfs()
{
    while(!q.empty()) q.pop();
    for(int i=1;i<=sid;i++) dep[i]=0;
    dep[S]=1,cur[S]=first[S],q.push(S);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        for(int i=first[x],v;i;i=nxt[i])
            if(lth[i]&&!dep[v=to[i]])
            {
                dep[v]=dep[x]+1;
                cur[v]=first[v];
                if(v==T) return 1;
                q.push(v);
            }
    }
    return 0;
}
ll dfs(int x,ll flow)
{
    if(x==T) return flow;
    ll rest=flow;int v;
    for(int &i=cur[x];i;i=nxt[i])
        if(dep[v=to[i]]==dep[x]+1&&lth[i])
        {
            ll k=dfs(v,min(lth[i],rest));
            if(!k) dep[v]=0;
            lth[i]-=k,lth[i^1]+=k;
            rest-=k;
            if(!rest) break;
        }
    return flow-rest;
}
ll dinic()
{
    ll res=0;
    while(bfs()) res+=dfs(S,inf);
    return res;
}
int main()
{
    freopen("essence.in","r",stdin);
    freopen("essence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=m;i++)
        L[i]=read(),R[i]=read(),c[i]=read(),t[i]=read();
    S=m+1,T=m+2,sid=T;
    for(int x=1;x<=n;x++)
    {
        for(int j=1;j<=T;j++) first[j]=0;
        cnt=1;build(1,1,n);
        for(int j=1;j<=m;j++)
        {
            Inc(S,j,c[j]);
            if(t[j]) add(1,1,n,min(x,L[j]),max(x,R[j]),j);
            else add(1,1,n,L[j],R[j],j);
        }
        // cerr<<cnt<<endl;
        printf("%lld%c",dinic()," \n"[x==n]);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
