#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10,M=210;
int n,ans,a[N],loc[N],dp[M][M][M];
inline void Max(int &x,int y) {x=x>y?x:y;}
int main()
{
    freopen("escape.in","r",stdin);
    freopen("escape.out","w",stdout);
    scanf("%d",&n);
    if(n>200) return printf("%d\n",n),0;
    for(int i=1;i<=n;i++)
        scanf("%d",a+i),loc[a[i]]=i;
    memset(dp,0xcf,sizeof(dp));
    dp[0][0][n+1]=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<a[i];j++)
            for(int k=1;k<=n+1;k++)
                Max(dp[i][a[i]][k],dp[i-1][j][k]+1);
        for(int j=a[i]+1;j<=n;j++)
            for(int k=1;k<=n+1;k++)
                Max(dp[i][j][k],dp[i-1][j][k]);
        for(int j=0;j<=n;j++)
            for(int k=a[i]+1;k<=n+1;k++)
                Max(dp[i][j][a[i]],dp[i-1][j][k]+1);
        for(int j=0;j<=n;j++)
            for(int k=1;k<a[i];k++)
                Max(dp[i][j][k],dp[i-1][j][k]);
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) Max(ans,dp[n][i][j]);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
