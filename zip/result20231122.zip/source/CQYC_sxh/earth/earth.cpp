#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 1e5 + 100;

int n, k, p; vector<int> a, b; int ans[100][100][100];

int Mex(vector<int> &s) { int p = 0; for (auto x : s) { if (x == p) ++p; else return p; } return p; }

signed main() {
	freopen("earth.in", "r", stdin);
	freopen("earth.out", "w", stdout);


    for (k = 1; k <= 4; ++k) 
    for (n = 1; n < (1 << k); ++n) {
        int l = 1 << k, o = (1 << l) - 1;

        For(_, 0, o) {
            if (_ % 2 == 0) continue;
            if (__builtin_popcount(_) != n) continue;
            a.clear(), b.clear();
            For(i, 0, l - 1) if ((_ >> i) & 1) a.push_back(i);
            while (1) {
                swap(a, b), a.clear(); int m = Mex(b) - 1;
                for (auto x : b) {
                    auto it = lower_bound(b.begin(), b.end(), x ^ m);
                    if (it != b.end() && *it == (x ^ m)) a.push_back(x);
                }
                if (a == b) break;
            }
            ++ans[k][n][Mex(a)];
        }
    }
    int T = read();
    while (T--) {
        k = read(), n = read(), p = read();
        cout << ans[k][n][p] <<'\n';
    }
	return 0;
}
