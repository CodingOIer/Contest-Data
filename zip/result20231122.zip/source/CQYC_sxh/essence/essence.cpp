#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 100;

int n, m, a[N];

struct node {
    int l, r, c, t;
}b[N];

namespace part1 {
    set<pii> s;
    i64 calc(int k) { 
        i64 ans = 0; s.clear();
        sort(b + 1, b + m + 1, [&](const node &x, const node &y){
            return max(x.r, x.t * k) < max(y.r, y.t * k);
        }); For(i, 1, n) if (a[i]) s.insert(pii(i, a[i])); 
        
        For(i, 1, m) {
            int x = b[i].c, l = b[i].l, r = b[i].r;
            if (b[i].t) Min(l, k), Max(r, k);
            while (x) {
                auto it = s.lower_bound(pii(l, 0));
                if (it == s.end() || it->first > r) break;
                int op = min(it->second, x); ans += op;
                pii tmp = *it; s.erase(it), tmp.second -= op;
                x -= op; if (tmp.second) s.insert(tmp);
            }
        }

        return ans;
    }
    void solve() { For(i, 1, n) cout << calc(i) <<" "; }
}

namespace part2 {
    
    #define ls (x << 1)
    #define rs (x << 1 | 1)
    #define mid ((l + r) >> 1)

    i64 t[N << 2], tmp[N << 2]; bool tag[N << 2];    
    bool vis[N << 2]; int stk[N << 2], tp;

    void build(int x = 1, int l = 1, int r = n) {
        if (l == r) return t[x] = a[l], tag[x] = 0, void();
        build(ls, l, mid), build(rs, mid + 1, r), t[x] = t[ls] + t[rs];
    }
    void Push(int x) { if (!vis[x]) stk[++tp] = x, vis[x] = 1; }
    void pushdown(int x) { if (tag[x]) t[ls] = t[rs] = 0, tag[ls] = tag[rs] = 1, tag[x] = 0; }
    int modify(int L, int R, int v, int x = 1, int l = 1, int r = n) {
        if (!v || !t[x]) return v;
        Push(x), Push(ls), Push(rs);
        if (l >= L && r <= R) {
            if (l == r) { int k = min(t[x], (i64)v); t[x] -= k, v -= k; return v; }
            pushdown(x);
            if (t[ls] <= v) v -= t[ls], t[ls] = 0, tag[ls] = 1;
            else v = modify(L, R, v, ls, l, mid);

            if (t[rs] <= v) v -= t[rs], t[rs] = 0, tag[rs] = 1;
            else v = modify(L, R, v, rs, mid + 1, r);

            t[x] = t[ls] + t[rs]; return v;
        } pushdown(x);
        if (mid >= L) v = modify(L, R, v, ls, l, mid);
        if (mid < R) v = modify(L, R, v, rs, mid + 1, r);
        t[x] = t[ls] + t[rs]; return v;
    }
    i64 calc(int k) {  
        i64 ans = 0;
        sort(b + 1, b + m + 1, [&](const node &x, const node &y){
            return max(x.r, x.t * k) < max(y.r, y.t * k);
        });
        For(i, 1, m) {
            int x = b[i].c, l = b[i].l, r = b[i].r;
            if (b[i].t) Min(l, k), Max(r, k);
            ans += x - modify(l, r, x);
        }
        while (tp) {
            t[stk[tp]] = tmp[stk[tp]];
            tag[stk[tp]] = 0;
            vis[stk[tp]] = 0, --tp;
        }
        return ans;
    }

    void solve() { 
        build(), tp = 0;
        For(i, 1, n << 2) tmp[i] = t[i], vis[i] = 0;
        For(i, 1, n) cout << calc(i) <<" ";
    }
}
signed main() {
	freopen("essence.in", "r", stdin);
	freopen("essence.out", "w", stdout);
    n = read(), m = read(); For(i, 1, n) a[i] = read();
    For(i, 1, m) b[i] = {read(), read(), read(), read()};
    if (n <= 100 && m <= 100) part1::solve(), exit(0);
    part2::solve(), exit(0);
	return 0;
}
