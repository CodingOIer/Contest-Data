#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


const int N = 2e5 + 100, inf = 1e9;

char qqq;

int n, a[N];

namespace part1 {

    struct SEG{
        #define ls (x << 1)
        #define rs (x << 1 | 1)
        #define mid ((l + r) >> 1)
        int t[2010 << 2], tag[2010 << 2];
        void update(int x, int v) { t[x] = tag[x] = v; }
        void pushdown(int x) { if (tag[x] != -1) update(ls, tag[x]), update(rs, tag[x]), tag[x] = -1; }        
        void modify(int p, int v, int x = 1, int l = 0, int r = n) {
            if (r <= p) return update(x, v);
            pushdown(x), modify(p, v, ls, l, mid);
            if (mid < p) modify(p, v, rs, mid + 1, r);
            t[x] = max(t[ls], t[rs]);
        }
        void change(int p, int v, int x = 1, int l = 0, int r = n) {
            if (l == r) return update(x, v); ; pushdown(x);
            if (mid >= p) change(p, v, ls, l, mid);
            else change(p, v, rs, mid + 1, r);
            t[x] = max(t[ls], t[rs]);
        }
        int ask(int p, int x = 1, int l = 0, int r = n) {
            if (r <= p) return t[x]; pushdown(x);
            int res = ask(p, ls, l, mid);
            if (p > mid) Max(res, ask(p, rs, mid + 1, r));
            return res;
        }
    }tr1[2010], tr2[2010];

    void upd(int x, int y, int v) {
        int val = tr1[x].ask(y);
        if (v <= val || v < 0) return;
        tr1[x].change(y, v), tr2[y].change(x, v);
    }

    int f[2010], g[2010];

    void solve() {
        For(i, 0, n) tr1[i].modify(n, -2);
        For(i, 0, n) tr2[i].modify(n, -2);
        upd(0, 0, 0);

        For(i, 1, n) {
            int x = a[i], y = n - a[i] + 1;
            
            For(j, 0, n) f[j] = -2;
            For(j, 0, n) g[j] = -2;

            For(j, 0, n) Max(f[j], tr2[j].ask(x - 1) + 1);
            For(j, 0, n) Max(g[j], tr1[j].ask(y - 1) + 1);

            For(j, 0, n) upd(x, j, f[j]);
            For(j, 0, n) upd(j, y, g[j]);

            For(j, 0, x - 1) tr1[j].modify(y - 1, -2);
            For(j, 0, y - 1) tr2[j].modify(x - 1, -2);

        }
        int ans = 0; For(i, 0, n) ans = max(ans, tr1[i].t[1]);
        cout << ans;
    }
}

char qqqq;

signed main() {
	freopen("escape.in", "r", stdin);
	freopen("escape.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    n = read(); For(i, 1, n) a[i] = read();
    if (n <= 2000) part1::solve(), exit(0);
	return 0;
}
