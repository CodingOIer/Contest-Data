#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int k,n,p;
int ans;
int tot=1,s[100005];
int t[100005];
int w[100005][2];
bool vis[100005];
int ww[105][105][105];
bool viss[105][105];
const int mod=998244353;
void dfs(int x){
	if(x>t[k]-1){
		if(tot!=n) return;
		int m=0,o=0;
		for(int i=1;i<=n;i++) w[i][0]=s[i],vis[s[i]]=1;
		for(int i=0;;i++) if(!vis[i]){
			m=i-1;
			break;
		}
		for(int i=1;i<=n;i++) vis[s[i]]=0;
		for(int i=1;i<=50;i++){
			for(int j=1;j<=n;j++) w[j][o^1]=(w[j][o]^m),vis[w[j][o^1]]=1;
			for(int j=0;;j++){
				if(!vis[j]){
					m=j-1;
					break;
				}
			}
			for(int j=1;j<=n;j++) vis[w[j][o^1]]=0;
			o^=1;
		}
		ww[k][n][m+1]++;
		return;
	}
	if(tot<n){
		s[++tot]=x;
		dfs(x+1);
		tot--;
	}
	dfs(x+1);
}
signed main(){
	freopen("earth.in","r",stdin);
	freopen("earth.out","w",stdout);
	scanf("%lld",&T);
	t[0]=1;
	for(int i=1;i<=17;i++) t[i]=t[i-1]*2;
	while(T--){
		scanf("%lld %lld %lld",&k,&n,&p);
		ans=0;
		if(!viss[k][n]) viss[k][n]=1,dfs(1);
		printf("%lld\n",ww[k][n][p]%mod);
	}
	return 0;
}


