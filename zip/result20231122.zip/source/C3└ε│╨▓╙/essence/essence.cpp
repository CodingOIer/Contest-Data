#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n,m;
int a[N];
int b[N],g[N];
int l[N],r[N],c[N],t[N];
int ans,sum,w;
vector<pair<int,int> > v[N];
signed main(){
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++) scanf("%lld %lld %lld %lld",&l[i],&r[i],&c[i],&t[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) b[j]=0,v[j].clear();
		for(int j=1;j<=m;j++){
			int ll,rr;
			if(t[j]==1) ll=min(l[j],i),rr=max(r[j],i);
			else ll=l[j],rr=r[j];
			b[ll]+=c[j];
			b[rr+1]-=c[j];
			v[ll].push_back({rr,c[j]});
		}
		priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > q;
		ans=sum=0;
		for(int j=1;j<=n;j++){
			sum+=b[j];
			for(int w=0;w<v[j].size();w++) q.push(v[j][w]);
			int k=min(sum,a[j]);
			ans+=k;
			sum-=k;
			while(k>0&&!q.empty()){
				int x=q.top().first,y=q.top().second;
				q.pop();
				int o=min(k,y);
				k-=o;
				y-=o;
				b[x+1]+=o;
				if(y>0&&x>j) q.push({x,y});
			}
			while(!q.empty()){
				if(q.top().first==j) q.pop();
				else break;
			}
		}
		printf("%lld ",ans);
	}
	return 0;
}


