#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n;
int a[N];
int tot1,tot2,s1[N],s2[N];
int ans;
void dfs(int x){
	if(x>n){
		if(tot1==0||tot2==0) return;
		int o=0,res=0;
		for(int i=1;i<=tot1;i++){
			if(s1[i]>o) res++,o=s1[i];
		}
		o=1e18;
		for(int i=1;i<=tot2;i++){
			if(s2[i]<o) res++,o=s2[i];
		}
		ans=max(ans,res);
		return;
	}
	s1[++tot1]=a[x];
	dfs(x+1);
	tot1--;
	s2[++tot2]=a[x];
	dfs(x+1);
	tot2--;
}
signed main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	dfs(1);
	printf("%lld",ans);
	return 0;
}


