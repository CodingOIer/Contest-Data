#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=5e5+7;
int n,m,a[Maxn];
struct node{
	int l,r,c,t;
}e[Maxn];

int main(){
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) 
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d%d%d%d",&e[i].l,&e[i].r,&e[i].c,&e[i].t);
	if(m<=1){
		for(int i=1;i<=n;i++){
			int x=i;
			if(e[1].t==1){
				int l=min(e[1].l,x),r=max(e[1].r,x);
				int maxx=-1;
				for(int j=l;j<=r;j++){
					maxx=max(maxx,a[j]);
				}
				printf("%d ",min(maxx,e[1].c));
			}
			else{
				int maxx=-1;
				for(int j=e[1].l;j<=e[1].r;j++){
					maxx=max(maxx,a[j]);
				}
				printf("%d ",min(maxx,e[1].c));
			}
		}
	}
	else{
		ll ans=0;
		for(int i=1;i<=m;i++) ans+=e[i].c;
		for(int i=1;i<=n;i++) printf("%lld ",ans);
	}	
	return 0;
}

/*
4 1
3 3 2 2
3 4 5 1
*/

