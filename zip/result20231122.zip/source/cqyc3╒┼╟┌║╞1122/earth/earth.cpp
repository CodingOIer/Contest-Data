#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Mod=998244353;
const int I=16;
ll f[18][36][36];
int T,xml[28]; 

bool vis[30];

/*
p=2^l 
*/

inline int Gmex(vector<int>g){
	memset(vis,0,sizeof vis);
	int mx=0;
	for(auto i:g) vis[i]=1;
	while(vis[mx]) ++mx;
	return mx;
}

int main(){
	freopen("earth.in","r",stdin);
	freopen("earth.out","w",stdout);
	
	scanf("%d",&T);
	
	xml[0]=1;
	for(int i=1;i<=20;i++) xml[i]=xml[i-1]*2;
	
	int res=0;
	//int J=xml[k];
	for(int i=0;i<(1<<I);i++){
		int len=0,pb=0;
		if(!(i>>0&1)) continue;
		vector<int>R;
		for(int j=0;j<I;j++){
			if(i>>j&1){
				len++;
				R.emplace_back(j);
			}
		}
		
		int lstmx=-2;
		while(1){
			int mx=Gmex(R)-1;
			for(auto &i:R) i^=mx;
			if(mx==lstmx||!mx) break;
			lstmx=mx;
		}
		int M=0;
		for(int j=1;j<=4;j++){
			if(xml[xml[j]]>=i) f[j][len][Gmex(R)]++;
		}
		
	}
	
	while(T--){
		int k,n,p;
		scanf("%d%d%d",&k,&n,&p);
		
		int M=0;
		while(xml[M]<p) ++M;
		if(xml[M]!=p){
			printf("0\n");
			continue;
		}
		
		printf("%lld\n",f[k][n][p]%Mod);
	}
	return 0;
}

/*
6
3 2 1
3 2 2
3 2 3
3 2 4
3 5 1
4 6 1
*/


