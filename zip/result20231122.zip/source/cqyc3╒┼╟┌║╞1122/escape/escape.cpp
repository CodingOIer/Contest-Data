#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=25;
int n,p[Maxn],ans=0;

int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&p[i]);
	
	
	if(n<=20){
		for(int i=0;i<(1<<n);i++){
			vector<int>bw,nw;
			for(int j=0;j<n;j++) if(i>>j&1) bw.emplace_back(p[j+1]);else nw.emplace_back(p[j+1]);
			
			int minn=1e9,maxx=-1,res1=0,res2=0;
			for(auto j:bw){
				maxx=max(maxx,j);
				if(j>=maxx) res1++;
			}		
			for(auto j:nw){
				minn=min(minn,j);
				if(j<=minn) res2++;
			}
			ans=max(ans,res1+res2);
		}
		printf("%d",ans);	
	} 
	else{
		printf("%d",n);
	}

	return 0;
}



