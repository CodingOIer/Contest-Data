//#include<bits/stdc++.h>
//#define mid ((l+r)>>1)
//#define ls (x<<1)
//#define rs ((x<<1)|1)
//using namespace std;
//int n,ans;
//int a[2005];
//int f[2005][2005]; 
//struct Node{
//	int tree[8005];
//	void modify(int x,int l,int r,int W,int V){
//		if(l==r)return tree[x]=V,void();
//		if(W<=mid)modify(ls,l,mid,W,V);
//		else modify(rs,mid+1,r,W,V);
//		tree[x]=max(tree[ls],tree[rs]);
//	}
//	int query(int x,int l,int r,int L,int R){
//		if(L>R)return 0;
//		if(L<=l&&r<=R)return tree[x];
//		if(R<=mid)return query(ls,l,mid,L,R);
//		else if(L>mid)return query(rs,mid+1,r,L,R);
//		else return max(query(ls,l,mid,L,R),query(rs,mid+1,r,L,R));
//	}
//}HH[2005],LL[2005];
//void change(int x,int y){
//	HH[x].modify(1,0,n,y,f[x][y]);
//	LL[y].modify(1,0,n,x,f[x][y]);
//	return;
//}
//signed main(){
////	freopen("escape.in","r",stdin);
////	freopen("escape.out","w",stdout);
//	cin>>n;
//	for(int i=1;i<=n;i++)cin>>a[i];
//	
//	for(int i=1;i<=n;i++){
//		for(int k=0;k<=n;k++){
//			if(a[i])
//			f[a[i]][k]=max(f[a[i]][k],LL[k].query(1,0,n+1,0,a[i]-1)+1);
//		}
//		for(int j=0;j<=n;j++)f[j][a[i]]=max(f[j][a[i]],HH[j].query(1,0,n,a[i]+1,n)+1);
//		for(int k=0;k<=n;k++)change(a[i],k);
//		for(int j=0;j<=n;j++)change(j,a[i]);
//	}
//	for(int i=0;i<=n;i++)
//		for(int j=0;j<=n;j++)
//			ans=max(ans,f[i][j]);
//	cout<<ans;
//} 
#include<bits/stdc++.h>
using namespace std;
int n,ans;
int a[2005];
int f[2][2005][2005]; 
signed main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	memset(f,-0x3f,sizeof f);
	f[0][0][n+1]=0;
	for(int i=1;i<=n;i++){
		memset(f[i&1],-0x3f,sizeof f[i&1]);
		for(int j=0;j<=n+1;j++)
			for(int k=0;k<=n+1;k++)
				f[i&1][max(j,a[i])][k]=max(f[i&1][max(j,a[i])][k],f[(i-1)&1][j][k]+(a[i]>j)),
				f[i&1][j][min(a[i],k)]=max(f[i&1][j][min(a[i],k)],f[(i-1)&1][j][k]+(a[i]<k));
	}
	for(int i=0;i<=n+1;i++)
		for(int j=0;j<=n+1;j++)
			ans=max(ans,f[n&1][i][j]);
	cout<<ans;
} 
