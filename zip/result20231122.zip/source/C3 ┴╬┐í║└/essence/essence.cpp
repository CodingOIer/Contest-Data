#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,m;
int a[20005],A[20005];
struct node{
	int l,r,c,t;
}p[20005],P[20005];
bool cmp(node A,node B){
	return A.l<B.l;
}
int check(){
	sort(P+1,P+m+1,cmp);
	priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >q;
	int now=0,sum=0;	
	for(int i=1;i<=n;i++){
		while(now<m&&P[now+1].l==i){
			now++;
//			cout<<P[now].r<<"///"<<P[now].c<<endl; 
			q.push(make_pair(P[now].r,P[now].c));
		}
		while(!q.empty()&&q.top().first<i)q.pop();
		while(A[i]>0&&!q.empty()){
			int x=q.top().second;
			int y=q.top().first;
//			cout<<y<<"{{{{"<<x<<endl;
			q.pop();
			if(x<=A[i]){
				A[i]-=x;
				sum+=x;
			}else{
				q.push(make_pair(y,x-A[i]));
				sum+=A[i];
				A[i]=0;
			}
		}
	}
	return sum;
}
signed main(){
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=m;i++)cin>>p[i].l>>p[i].r>>p[i].c>>p[i].t;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			P[j]=p[j];
			if(p[j].t==1)P[j].l=min(P[j].l,i),P[j].r=max(P[j].r,i);
		}
		for(int j=1;j<=n;j++)A[j]=a[j];
		cout<<check()<<' ';
	}
}
