#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,m,a[maxn],l[maxn],r[maxn],c[maxn],t[maxn],ma[maxn],va[maxn],ans;
vector<int> ve[maxn];
pair<int,int> p[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int cmp(int x,int y){
    return ma[x]<ma[y];
}
signed main(){
    freopen("essence.in","r",stdin);
    freopen("essence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)
        a[i]=read();
    for(int i=1;i<=m;i++)
        l[i]=read(),r[i]=read(),c[i]=read(),t[i]=read();
    for(int i=1;i<=n;i++){
        ans=0;
        if(m==1){
            int x=l[1],y=r[1];
            if(t[1])
                x=min(x,i),y=max(y,i);
            int res=0;
            for(int j=x;j<=y;j++)
                res+=a[j];
            printf("%lld ",min(res,c[1]));
            continue;
        }
        for(int j=1;j<=n;j++){
            ve[j].clear();
            ma[j]=0;
            p[j]={0,j};
        }
        for(int j=1;j<=m;j++){
            va[j]=c[j];
            int x=l[j],y=r[j];
            if(t[j])
                x=min(x,i),y=max(y,i);
            for(int k=x;k<=y;k++){
                ve[k].push_back(j);
                int s=ve[k].size();
                ma[j]=max(ma[j],s);
                p[k].first++;
            }
        }
        for(int j=1;j<=n;j++)
            sort(ve[j].begin(),ve[j].end(),cmp);
        sort(p+1,p+1+n);
        for(int j=1;j<=n;j++){
            if(!p[j].first)
                continue;
            int k=a[p[j].second];
            int w=0;
            while(k&&w<ve[p[j].second].size()){
                int x=ve[p[j].second][w];
                if(k>va[x]){
                    k-=va[x];
                    ans+=va[x];
                    va[x]=0;
                    ++w;
                }
                else{
                    va[x]-=k;
                    ans+=k;
                    k=0;
                    break;
                }
            }
        }
        printf("%lld ",ans);
    }
    return 0;
}