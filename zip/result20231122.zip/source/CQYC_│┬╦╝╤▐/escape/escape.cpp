#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,p[maxn],ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int ma,int mi,int num){
    if(x>n){
        ans=max(ans,num);
        return;
    }
    if(p[x]>ma)
        solve(x+1,p[x],mi,num+1);
    if(p[x]<mi)
        solve(x+1,ma,p[x],num+1);
    if(p[x]<ma||p[x]>mi)
        solve(x+1,ma,mi,num);
}
signed main(){
    freopen("escape.in","r",stdin);
    freopen("escape.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        p[i]=read();
    solve(1,0,1e18,0);
    printf("%lld\n",ans);
    return 0;
}
