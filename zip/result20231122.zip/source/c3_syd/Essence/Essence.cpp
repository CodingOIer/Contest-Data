#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <tuple>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
namespace Subtask1_fAKe {

const int N = 2005;
array <int, N> s;
array <tuple <int, int, int, int>, N> isl, prl;

int main(int n, int m) {
	for (int i = 1; i <= n; i++)
		s[i] = read();
	for (int i = 1; i <= m; i++) {
		get <0>(isl[i]) = read(), get <1>(isl[i]) = read();
		get <2>(isl[i]) = read(), get <3>(isl[i]) = read();
	}
	prl = isl;
	for (int i = 1; i <= n; i++) {
		isl = prl;
		for (int j = 1; j <= m; j++) {
			if (!get <3>(isl[j])) continue;
			get <0>(isl[j]) = min(get <0>(isl[j]), i);
			get <1>(isl[j]) = max(get <1>(isl[j]), i);
		}
		sort(isl.begin() + 1, isl.begin() + 1 + m);
		int ans = 0;
		int tp = 0, now = 0;
		for (int j = 1; j <= m; j++) {
			/* write(get <0>(isl[j])), putchar(32); */
			/* write(get <1>(isl[j])), putchar(32); */
			/* write(get <2>(isl[j])), putchar(32); */
			/* write(get <3>(isl[j])), puts("@"); */
		}
		for (int j = 1; j <= m; j++) {

			if (tp > get <1>(isl[j])) continue;
			if (get <0>(isl[j]) > tp) tp = get <0>(isl[j]), now = 0;
			while (get <2>(isl[j]) >= (now ? now : s[tp]) && tp <= get <1>(isl[j])) {
				int x;
				get <2>(isl[j]) -= (x = (now ? (tp++, now) : s[tp++]));
				/* write(x), puts("&"); */
				ans += x;
				now = 0;
			}
			if (get <2>(isl[j]) && tp <= get <1>(isl[j]))
				now = s[tp] - get <2>(isl[j]), ans += get <2>(isl[j]);
		}
		/* puts("@"); */
		write(ans), putchar(32);
		/* return 0; */
	}
	return 0;
}

}

namespace Subtask1 {

const int N = 15;
array <int, N> s;

int main(int n, int m) {
	for (int i = 1; i <= n; i++)
		s[i] = read();
	int l = read(), r = read(), c = read(), t = read();
	for (int i = 1; i <= n; i++) {
		int _l = l, _r = r;
		if (t) _l = min(i, _l), _r = max(i, _r);
		int _c = c, ans = 0;
		for (int j = _l; j <= _r && _c; j++) {
			if (_c >= s[i]) _c -= s[i], ans += s[i];
			else ans += _c, _c = 0;
		}
		write(ans), puts("");
	}
	return 0;
}

}

int main() {
	/* freopen("Essence.in", "r", stdin); */
	/* freopen("Essence.out", "w", stdout); */
	int n = read(), m = read();
	if (m == 1) return Subtask1::main(n, m);
	else return Subtask1_fAKe::main(n, m);
}
