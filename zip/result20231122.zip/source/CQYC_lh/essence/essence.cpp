#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
long long ot[40],otp;
void write(long long x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');return ;
}
const long long inf=1e9,inf64=1e18;
int n,m;
const int maxn=2e5+2;
int ar[maxn];
struct node_se{
    int l,r,c,t;
    bool operator < (const node_se &A)const{
        return r>A.r;
    }
}p[maxn],np[maxn];
namespace brute1{
    vector<int>ve[maxn];
    priority_queue<node_se>q;
    long long calc(int w){
        while(!q.empty())q.pop();
        for(int i=1;i<=m;i++){
            np[i]=p[i];
            if(np[i].t)np[i].l=min(np[i].l,w),np[i].r=max(np[i].r,w);
            ve[np[i].l].push_back(i);
        }
        long long ans=0;
        for(int i=1;i<=n;i++){
            for(int j=0;j<ve[i].size();j++)q.push(np[ve[i][j]]);
            while(!q.empty()&&q.top().r<i)q.pop();
            long long x=ar[i];
            node_se d;
            while(x&&!q.empty()){
                d=q.top(),q.pop();
                if(d.c>x)d.c-=x,ans+=x,x=0,q.push(d);
                else x-=d.c,ans+=d.c;
            }
        }
        for(int i=1;i<=m;i++)ve[np[i].l].pop_back();
        return ans;
    }
    void solve(){
        for(int i=1;i<=n;i++)write(calc(i)),putchar(' ');
    }
}
int main(){
    freopen("essence.in","r",stdin);
    freopen("essence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)ar[i]=read();
    for(int i=1;i<=m;i++)p[i].l=read(),p[i].r=read(),p[i].c=read(),p[i].t=read();
    brute1::solve();
    return 0;
}
