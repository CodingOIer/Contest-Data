#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');return ;
}
const int maxn=2e2+2;
int n;
int p[2][maxn];
int ans;
namespace brute2{
    int dp[202][202][202];
    void solve(){
        memset(dp,-0x3f,sizeof(dp));
        dp[0][n+1][0]=0;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n+1;j++){
                for(int k=0;k<=n;k++){
                    dp[i][min(j,p[0][i])][k]=max(dp[i][min(j,p[0][i])][k],dp[i-1][j][k]+(j>p[0][i]));
                    dp[i][j][max(k,p[0][i])]=max(dp[i][j][max(k,p[0][i])],dp[i-1][j][k]+(k<p[0][i]));
                }
            }
            // for(int j=1;j<=n+1;j++){
            //     for(int k=0;k<=n;k++)printf("dp[%d][%d][%d]=%d\n",i,j,k,dp[i][j][k]);
            // }
        }
        for(int i=1;i<=n+1;i++){
            for(int j=0;j<=n;j++)ans=max(ans,dp[n][i][j]);
        }
        printf("%d\n",ans);
    }
}
int main(){
    freopen("escape.in","r",stdin);
    freopen("escape.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)p[0][i]=p[1][i]=read();
    reverse(p[1]+1,p[1]+n+1);
    if(n<=200)brute2::solve();
    // write(ans),putchar('\n');
    return 0;
}