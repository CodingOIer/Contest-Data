#include <bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 20;
const int mod = 998244353;
int n, k;
int a[Maxn], vis[Maxn];
int b[Maxn][Maxn];
int ans[5][Maxn][Maxn];
void dfs(int x){
    if(x > 16){
        int mex = 0, Max = 0;
        while(vis[mex + 1]) mex++;
        mex--;
        int cnt = 0;
        for(int i = 1 ; i <= 16 ; i++)
            if(vis[i]) b[1][++cnt] = i, Max = i;
        return ;
    }
    vis[x] = 1;
    dfs(x + 1);
    vis[x] = 0;
    dfs(x + 1);
}
signed main(){
    ios::sync_with_stdio(false);
    for(int i = 1 ; i <= 16 ; i++)
        a[i] = i - 1;
    vis[1] = 1;
    dfs(2);
    freopen("earth.in", "r", stdin);
    freopen("earth.out", "w", stdout);
    return 0;
}