#include <bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 100;
int n, m;
int a[Maxn];
struct node{
    int l, r, c, t;
}b[Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("essence.in", "r", stdin);
    freopen("essence.in", "w", stdout);
    cin >> n >> m;
    for(int i = 1 ; i <= n ; i++) cin >> a[i];
    for(int i = 1 ; i <= m ; i++) cin >> b[i].l >> b[i].r >> b[i].c >> b[i].t;
    for(int x = 1 ; x <= n ; x++){
        int l = b[1].l, r = b[1].r;
        if(b[1].t == 1) l = min(l, x), r = max(r, x);
        int sum = 0;
        for(int i = l ; i <= r ; i++)
            sum = min(max(sum, sum + a[i]), b[1].c);    
        cout << sum << '\n';
    }
    return 0;
}