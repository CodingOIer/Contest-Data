#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 2010;
int n, ans;
int a[Maxn];
int f[3][Maxn][Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("escape.in", "r", stdin);
    freopen("escape.out", "w", stdout);
    cin >> n;
    memset(f, -0x3f, sizeof(f));
    f[0][0][n + 1] = 0;
    for(int i = 1 ; i <= n ; i++) cin >> a[i];
    for(int i = 1 ; i <= n ; i++){
        cout << i << endl;
        memset(f[i & 1], -0x3f, sizeof(f[i & 1]));
        for(int j = 0 ; j <= n + 1 ; j++){
            for(int k = 0 ; k <= n + 1 ; k++){
                f[i & 1][max(j, a[i])][k] = max(f[i & 1][max(j, a[i])][k], f[(i - 1) & 1][j][k] + (a[i] > j));
                f[i & 1][j][min(k, a[i])] = max(f[i & 1][j][min(k, a[i])], f[(i - 1) & 1][j][k] + (a[i] < k));
            }
        }
    }
    for(int i = 0 ; i <= n + 1 ; i++)
        for(int j = 0 ; j <= n + 1 ; j++)
            ans = max(ans, f[n & 1][i][j]);
    cout << ans << '\n';
    return 0;
}