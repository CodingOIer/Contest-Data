#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct oper {
    int l, r, c, t;
} b[N];

int n, m;
int a[N];

namespace sub1 {
    struct node {
        int r, s;
        bool operator < (const node &p) const { return r > p.r; }
    };
    
    int lsh[N << 1], tot;

    priority_queue<node> q;

    vector<node> op[N];

    int calc(int p) {
        int res = tot = 0;
        while(!q.empty()) q.pop();

        for(int i = 1; i <= m; i++) {
            int l = b[i].l, r = b[i].r; if(b[i].t) Min(l, p), Max(r, p);
            lsh[++tot] = l - 1, lsh[++tot] = r, op[l - 1].push_back({ r, b[i].c });
        }

        sort(lsh + 1, lsh + tot + 1), tot = unique(lsh + 1, lsh + tot + 1) - lsh - 1;
        
        for(int i = 1; i <= tot; i++) {
            int x = lsh[i], rest = a[x] - a[lsh[i - 1]];
            while(rest and !q.empty()) {
                node l = q.top(); q.pop();
                if(l.r >= x and l.s <= rest) res += l.s, rest -= l.s;
                else if(l.r >= x) res += rest, q.push({ l.r, l.s - rest }), rest = 0;
            }
            for(node l : op[x]) q.push(l); op[x].clear();
        }
        return res;
    }

    void main() {
        for(int i = 1; i <= n; i++) a[i] += a[i - 1];
        for(int i = 1; i <= n; i++) write(calc(i)), putchar(' ');
    }
}

bool edmer;
signed main() {
	freopen("essence.in", "r", stdin);
	freopen("essence.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= m; i++) b[i] = { read(), read(), read(), read() };

    if(n * m <= 4e6) sub1 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 