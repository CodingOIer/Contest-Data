#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

int n, ans;
int p[N];

namespace sub1 {
    const int N1 = 2010;

    int f[N1][N1];

    bool vis[N1];

    vector<int> v;
    
    void main() {
        v.push_back(0), v.push_back(n + 1);
        f[0][0] = f[n + 1][n + 1] = -n;

        for(int i = 1; i <= n; i++) {
            int x = p[i];
            for(int l : v) for(int r : v) {
                if(x < r) Max(f[l][x], f[l][r] + 1);
                if(x > l) Max(f[x][r], f[l][r] + 1);
                if(l < x and r > x) f[l][r] = -n;
            }
            v.push_back(x), sort(v.begin(), v.end());
        }

        for(int l : v) for(int r : v) Max(ans, f[l][r]);
        write(ans);
    }
}

bool edmer;
signed main() {
	freopen("escape.in", "r", stdin);
	freopen("escape.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) p[i] = read();
    
    if(n <= 2e3) sub1 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 