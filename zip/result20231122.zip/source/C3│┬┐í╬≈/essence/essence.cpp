#include<bits/stdc++.h>
#define int long long
#define fi first
#define sd second
using namespace std;
const int N=2005;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,m;
int a[N],as[N];
struct Node{
	int l,r,c,opt;
}q[N];
bool cmp(Node a,Node b){
	if(a.l==b.l) return a.r<b.r;
	return a.l<b.l;
}
vector<pair<int,int> > s[N];
signed main(){
	freopen("essence.in","r",stdin);
	freopen("essence.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++){
		int l=read(),r=read();
		int c=read(),opt=read();
		q[i]=(Node){l,r,c,opt};
	}
	for(int x=1;x<=n;x++){
		int res=0;
		for(int i=1;i<=n;i++) as[i]=a[i],s[i].clear();
		
		for(int i=1;i<=m;i++){
			int L=q[i].l,R=q[i].r,C=q[i].c;
			if(q[i].opt) L=min(L,x),R=max(R,x);
			s[L].push_back({R,C});
		}
		for(int i=1;i<=n;i++){
			sort(s[i].begin(),s[i].end());
			for(int j=0;j<s[i].size();j++){
				int R=s[i][j].fi,C=s[i][j].sd;
				if(as[i]>=C) as[i]-=C,res+=C; 
				else{
					C-=as[i];
					res+=as[i];
					as[i]=0;
					if(R>=i+1) s[i+1].push_back({R,C});
				} 
			}
		}
		printf("%lld ",res);
	}
	return 0;
}
