#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=205;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,a[N],ans;
signed main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int k=0;k<(1<<n);k++){
		int minn=n+1,maxn=0,res=0;
		for(int i=1;i<=n;i++){
			if(k&(1<<(i-1))){
				maxn=max(maxn,a[i]);
				res+=(a[i]==maxn);
			}
			else{
				minn=min(minn,a[i]);
				res+=(a[i]==minn);
			}
		}
		ans=max(ans,res);
	}
	printf("%lld",ans);
	return 0;
}
/*
10
3 8 10 4 1 2 7 9 5 6
*/
