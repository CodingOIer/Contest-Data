#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int T,K,n,p;
struct ok{
    int x,y,z;
    bool operator < (const ok &A) const{
        if(x==A.x){
            if(y==A.y) return z<A.z;
            return y<A.y;
        }
        return x<A.x;
    }
};
map<ok,int> mp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("earth.in","r",stdin);
    freopen("earth.out","w",stdout);
    mp[(ok){1,1,1}]=1;
    mp[(ok){1,2,2}]=1;
    mp[(ok){2,1,1}]=1;
    mp[(ok){2,2,1}]=2;
    mp[(ok){2,2,2}]=1;
    mp[(ok){2,3,1}]=3;
    mp[(ok){2,4,4}]=1;
    mp[(ok){3,1,1}]=1;
    mp[(ok){3,2,1}]=6;
    mp[(ok){3,2,2}]=1;
    mp[(ok){3,3,1}]=17;
    mp[(ok){3,3,2}]=4;
    mp[(ok){3,4,1}]=28;
    mp[(ok){3,4,2}]=6;
    mp[(ok){3,4,4}]=1;
    mp[(ok){3,5,1}]=29;
    mp[(ok){3,5,2}]=4;
    mp[(ok){3,5,4}]=2;
    mp[(ok){3,6,1}]=17;
    mp[(ok){3,6,2}]=3;
    mp[(ok){3,6,4}]=1;
    mp[(ok){3,7,1}]=7;
    mp[(ok){3,8,8}]=1;
    mp[(ok){4,1,1}]=1;
    mp[(ok){4,2,1}]=14;
    mp[(ok){4,2,2}]=1;
    mp[(ok){4,3,1}]=93;
    mp[(ok){4,3,2}]=12;
    mp[(ok){4,4,1}]=388;
    mp[(ok){4,4,2}]=66;
    mp[(ok){4,4,4}]=1;
    mp[(ok){4,5,1}]=1135;
    mp[(ok){4,5,2}]=220;
    mp[(ok){4,5,4}]=10;
    mp[(ok){4,6,1}]=2461;
    mp[(ok){4,6,2}]=497;
    mp[(ok){4,6,4}]=45;
    mp[(ok){4,7,1}]=4077;
    mp[(ok){4,7,2}]=808;
    mp[(ok){4,7,4}]=120;
    mp[(ok){4,8,1}]=5244;
    mp[(ok){4,8,2}]=980;
    mp[(ok){4,8,4}]=210;
    mp[(ok){4,8,8}]=1;
    mp[(ok){4,9,1}]=5273;
    mp[(ok){4,9,2}]=904;
    mp[(ok){4,9,4}]=252;
    mp[(ok){4,9,8}]=6;
    mp[(ok){4,10,1}]=4143;
    mp[(ok){4,10,2}]=637;
    mp[(ok){4,10,4}]=210;
    mp[(ok){4,10,8}]=15;
    mp[(ok){4,11,1}]=2524;
    mp[(ok){4,11,2}]=339;
    mp[(ok){4,11,4}]=120;
    mp[(ok){4,11,8}]=20;
    mp[(ok){4,12,1}]=1172;
    mp[(ok){4,12,2}]=131;
    mp[(ok){4,12,4}]=47;
    mp[(ok){4,12,8}]=15;
    mp[(ok){4,13,1}]=402;
    mp[(ok){4,13,2}]=33;
    mp[(ok){4,13,4}]=14;
    mp[(ok){4,13,8}]=6;
    mp[(ok){4,14,1}]=94;
    mp[(ok){4,14,2}]=7;
    mp[(ok){4,14,4}]=3;
    mp[(ok){4,14,8}]=1;
    mp[(ok){4,15,1}]=15;
    mp[(ok){4,16,16}]=1;
    T=read();
    while(T--){
        K=read(),n=read(),p=read();
        cout<<mp[(ok){K,n,p}]<<"\n";
    }
    return 0;
}