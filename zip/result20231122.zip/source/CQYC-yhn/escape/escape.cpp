#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,p[200005],a[200005],cnt,ans=0,dp[2][2005][2005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("escape.in","r",stdin);
    freopen("escape.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++){
        p[i]=read();
        if(p[i]>a[cnt]) a[++cnt]=p[i];
        else{
            int d=lower_bound(a+1,a+1+cnt,p[i])-a;
            a[d]=p[i];
        }
    }
    ans+=cnt;
    cnt=0;
    memset(a,0,sizeof(a));
    reverse(p+1,p+1+n);
    for(int i=1;i<=n;i++){
        if(p[i]>a[cnt]) a[++cnt]=p[i];
        else{
            int d=lower_bound(a+1,a+1+cnt,p[i])-a;
            a[d]=p[i];
        }
    }
    ans+=cnt;
    cnt=0;
    reverse(p+1,p+1+n); 
    if(n>2000){
        cout<<ans;
        return 0;
    } 
    else ans=0;
    for(int i=0;i<=1;i++) for(int j=0;j<=(n+1);j++) for(int g=0;g<=(n+1);g++) dp[i][j][g]=-1e9;
    dp[0][0][n+1]=0;
    for(int i=0;i<n;i++){
        int t=i&1;
        for(int j=0;j<=(n+1);j++) for(int g=0;g<=(n+1);g++) dp[t^1][j][g]=-1e9;
        for(int j=0;j<=n;j++){
            for(int g=1;g<=(n+1);g++){
                if(p[i+1]>j) dp[t^1][p[i+1]][g]=max(dp[t^1][p[i+1]][g],dp[t][j][g]+1);
                else dp[t^1][j][g]=max(dp[t^1][j][g],dp[t][j][g]);
                if(p[i+1]<g) dp[t^1][j][p[i+1]]=max(dp[t^1][j][p[i+1]],dp[t][j][g]+1);
                else dp[t^1][j][g]=max(dp[t^1][j][g],dp[t][j][g]);
            }
        }
    }
    for(int j=0;j<=n;j++) for(int g=1;g<=(n+1);g++) ans=max(ans,dp[n&1][j][g]);
    cout<<ans;
    return 0;
}
