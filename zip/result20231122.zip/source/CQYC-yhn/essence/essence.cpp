#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[200005];
struct ok{
    int l,r,c,t;
    bool operator < (const ok &A) const{
        return r>A.r;
    }
}b[200005],cs;
vector<ok> e[200005];
vector<int> E;
priority_queue<ok> q;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("essence.in","r",stdin);
    freopen("essence.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=m;i++) b[i].l=read(),b[i].r=read(),b[i].c=read(),b[i].t=read();
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            cs=b[j];
            if(cs.t) cs.l=min(cs.l,i),cs.r=max(cs.r,i);
            e[cs.l].push_back(cs);
        }
        int ans=0;
        for(int j=1;j<=n;j++){
            for(int g=0;g<(int)e[j].size();g++) q.push(e[j][g]);
            e[j].clear();
            int t=a[j];
            while((!q.empty())&&t){
                ok w=q.top();q.pop();
                if(w.r<j) continue;
                int d=min(t,w.c);
                w.c-=d;t-=d;
                if(w.c) q.push(w);
            }
            ans+=(a[j]-t);
        }
        cout<<ans<<" ";
    }
    return 0;
}