#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Mod=998244353,Maxn=2e5+10;
int T,K,N,P,M,Ans,S[Maxn],R[Maxn],Q[Maxn];
bool Vis[Maxn];

bool check(){
    // For(i,1,N) cerr<<S[i]<<" ";
    // cerr<<"\n";
    For(i,1,N) R[i]=S[i],Vis[S[i]]=1;
    int lst=0,c=0,ret=0,l=N;
    while(1){
        int m=0,r=0; ++c;
        For(i,0,M+1) if(!Vis[i]) {m=i-1; break;}
        // cerr<<"m="<<m<<"\n";
        if(m!=lst) ret=c;
        if(!m) break;
        lst=m;
        For(i,0,M) if(Vis[i^m]) Q[++r]=i;//,cerr<<"Here "<<i<<" "<<(i^m)<<"\n";
        // For(i,1,r) cerr<<Q[i]<<" "; cerr<<"\n";
        // For(i,1,l) cerr<<R[i]<<" "; cerr<<"\n";
        if(l==r){
            bool ff=0;
            For(i,1,l) if(Q[i]!=R[i]) ff=1;
            if(!ff) break;
        }
        For(i,1,l) Vis[R[i]]=0;
        For(i,1,r) Vis[Q[i]]=1;
        // cerr<<"l="<<l<<" r="<<r<<"\n";
        l=r,r=0; For(i,1,l) R[i]=Q[i];
        // cerr<<"final l="<<l<<" r="<<r<<"\n";
        // break;
    }
    For(i,0,M) Vis[i]=0;
    return ret==P;
}

void DFS(int x,int r){
    if(x>M){
        if(!r&&check()) ++Ans;
        return;
    }
    if(r) S[N-r+1]=x,DFS(x+1,r-1);
    DFS(x+1,r);
}

void Solve(){
    K=read(),N=read(),P=read(),M=(1<<K)-1,Ans=0;
    DFS(1,N-1); write(Ans),pc('\n');
}

int main(){
    freopen("earth.in","r",stdin);
    freopen("earth.out","w",stdout);
    T=read(); while(T--) Solve();
    return 0;
}