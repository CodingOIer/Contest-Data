#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10,INF=1e9+7;
int N,M,S,T,A[Maxn],C[Maxn],L[Maxn],R[Maxn],t[Maxn];
int hed[Maxn],cnt=1,Ans,deep[Maxn],cur[Maxn];
struct node{int nxt,to,w;}G[Maxn<<1];
queue<int> Q;

void Addedge(int x,int y,int w){G[++cnt]=(node){hed[x],y,w}; hed[x]=cnt;}

bool BFS(){
    For(i,1,T) deep[i]=0;
	Q.push(S); deep[S]=1; cur[S]=hed[S];
	while(!Q.empty()){
		int x=Q.front(); Q.pop();
		for(int y,i=hed[x];i;i=G[i].nxt)
			if(!deep[y=G[i].to]&&G[i].w)
				Q.push(y),deep[y]=deep[x]+1,cur[y]=hed[y];
	}
	return deep[T];
}

int DFS(int x,int in){
	if(x==T) return in;
	int out=0;
	for(int y,i=cur[x];i&&in;i=G[i].nxt){
		cur[x]=i;
		if(deep[y=G[i].to]==deep[x]+1&&G[i].w){
			int res=DFS(y,min(in,G[i].w));
			G[i].w-=res; G[i^1].w+=res;
			out+=res; in-=res;
		}
	}
	if(!out) deep[x]=0;
	return out;
}

int main(){
    freopen("essence.in","r",stdin);
    freopen("essence.out","w",stdout);
    N=read(),M=read(),S=N+M+1,T=S+1;
    For(i,1,N) A[i]=read();
    For(i,1,M) L[i]=read(),R[i]=read(),C[i]=read(),t[i]=read();
    For(x,1,N){
        cnt=1,Ans=0;
        For(i,1,T) hed[i]=cur[i]=0;
        For(i,1,N) Addedge(i,T,A[i]),Addedge(T,i,0);
        For(i,1,M){
            Addedge(S,i+N,C[i]),Addedge(i+N,S,0);
            int l=t[i]?L[i]:min(x,L[i]),r=t[i]?R[i]:max(x,R[i]);
            For(j,l,r) Addedge(i+N,j,INF),Addedge(j,i+N,0);
        }
        while(BFS()) Ans+=DFS(S,INF);
        write(Ans),pc(' ');
    }
    return 0;
}