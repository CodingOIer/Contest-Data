#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10;
int N,A[Maxn],Ans,pre[Maxn],f[Maxn],g[210][210][210];
bool Vis[Maxn];

void DFS(int x,int Mx,int t){
    if(x>N){
        int Mn=N+1,res=t;
        For(i,1,N) if(!Vis[i]&&A[i]<Mn) ++res,Mn=A[i];
        Ans=max(Ans,res);
        return;
    }
    Vis[x]=1,DFS(x+1,max(Mx,A[x]),t+(A[x]>Mx));
    Vis[x]=0,DFS(x+1,Mx,t);
}

void Solve1(){ DFS(1,0,0); write(Ans); }

void Max(int &x,int y){if(y>x) x=y;}

void Solve2(){
    Vis[0]=1;
    For(i,1,N){
        For(j,0,N)if(Vis[j]){
            For(k,0,N) if(Vis[k]&&(!j||j!=k)){
                if(A[i]>j) Max(g[i][A[i]][k],g[i-1][j][k]+1);
                if(A[i]<k) Max(g[i][j][A[i]],g[i-1][j][k]+1);
                Max(g[i][j][k],g[i-1][j][k]);
            }
        }
        Vis[A[i]]=1;
    }
    For(i,0,N) For(j,0,N) if(i!=j) Ans=max(Ans,g[N][i][j]);
    write(Ans);
}

int main(){
    freopen("escape.in","r",stdin);
    freopen("escape.out","w",stdout);
    N=read(); For(i,1,N) A[i]=read();
    if(N<=16) Solve1(),exit(0);
    if(N<=200) Solve2(),exit(0);
    For(i,1,N){
        For(j,0,i-1) if(A[j]<A[i]){
            if(f[j]+1>f[i]) f[i]=f[j]+1,pre[i]=j;
            else if(f[j]+1==f[i]&&A[j]>A[pre[i]]) pre[i]=j;
        }
    }
    int Mx=0,Mn=N+1,pos=0;
    For(i,1,N) Mx=max(Mx,f[i]);
    For(i,1,N) if(f[i]==Mx&&A[i]>A[pos]) pos=i;
    Ans=Mx;
    while(pos) Vis[pos]=1,pos=pre[pos];
    For(i,1,N) if(!Vis[i]&&A[i]<Mn) ++Ans,Mn=A[i];
    write(Ans);
    return 0;
}