#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,m;
int f[2000005],s=1,prime[2000005],cnt=0,vis[2000005],phi[2000005];
void solve(int x) {
	phi[1]=1;
	for(int i=2;i<=x;i++) {
		if(!vis[i]) {
			prime[++cnt]=i;
			phi[i]=i-1;
		} 
		for(int j=1;j<=cnt && prime[j]*i<=x;j++) {
			vis[i*prime[j]]=1;
			if(i%prime[j]==0) {
				phi[i*prime[j]]=phi[i]*prime[j];
				break ;
			}
			phi[i*prime[j]]=phi[prime[j]]*phi[i];
		}
	}
}
signed main() {
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	int w=1;
	for(int i=2;i<=n;i+=2) {
		w=w*m%mod;
		f[i]=w*(i/2)%mod*(m+1)%mod;
	}
	w=1;
	for(int i=1;i<=n;i+=2) {
		w=w*m%mod;
		f[i]=w*i;
	}
	solve(1e5);
	for(int i=1;i<=n;i++){
		for(int j=2;j<=n/i;j++) {
			f[i*j]=(f[i*j]+mod-f[i]*phi[j]%mod)%mod;
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++)  ans=(ans+f[i])%mod;
	printf("%lld",ans);
	return 0;
} 
/*
6 4
1 4 2
2 16 1
3 40
4 136
5 304
6 880

6 4
4
20
48
160
320
960

6 3
3
12
27
72
135
324

6 3
1 3 2
2 9 1
3 21
4 57
5 123
6 279
*/
