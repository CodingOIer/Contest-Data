#include<bits/stdc++.h>
using namespace std;
int cnt=0,ans=0;
vector<pair<int,int> > w[200005],q[200005];
int f[200005],siz[200005],sum[200005];
int n,k,maxn=0;
void dfs(int x,int fa,int Max,int Min) {
	if(Max-Min==k) ans++;
	for(int i=0;i<q[x].size();i++) {
		int to=q[x][i].first;
		if(to==fa) continue;
		dfs(to,x,max(Max,q[x][i].second),min(Min,q[x][i].second));
	}
}
int main() {
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<n;i++) {
		int x,y,W;
		scanf("%d %d %d",&x,&y,&W);
		q[x].push_back({y,W});
		q[y].push_back({x,W}); 
	}
	/*for(int i=1;i<=n;i++) f[i]=i;
	for(int i=1;i<=n;i++) {
		memset(sum,0,sizeof sum);
		if(i-k-1>=0)
		for(int j=0;j<w[i-k-1].size();j++) {
			int x=w[i-k-1][j].first,y=w[i-k-1][j].second;
			ma[x][y]=0; ma[y][x]=0;
			del(x,y);
		}
		if(i-k>=0)
		for(int j=0;j<w[i-k].size();j++) {
			int x=w[i-k][j].first,y=w[i-k][j].second;
			sum[f[x]]++;
		}
		for(int j=0;j<w[i].size();j++) {
			int x=w[i][j].first,y=w[i][j].second;
			merge(x,y);	
			ans+=sum[f[x]]*sum[f[y]];
			ma[x][y]=1; ma[y][x]=1;
		}
	}*/
	for(int i=1;i<=n;i++) {
		dfs(i,0,0,1e9);
	}
	printf("%d\n",ans/2);
	return 0;
} 
/*
4 2
1 2 3
2 3 1
2 4 1
*/
