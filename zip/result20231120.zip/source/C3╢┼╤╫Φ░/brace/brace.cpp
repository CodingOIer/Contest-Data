#include<bits/stdc++.h>
#define int long long
using namespace std;
int X,Y;
struct node {
	int a,b;
	char c;
}a[200005];
int n;
bool cmp(node x,node y) {
	if(x.a*X+x.b*Y==y.a*X+y.b*Y) return x.c<y.c;
	return x.a*X+x.b*Y<y.a*X+y.b*Y;
}
bool check() {
	sort(a+1,a+n+1,cmp);
	int cnt=0;
	for(int i=1;i<=n;i++) {
		if(a[i].c=='(') cnt++;
		else if(a[i].c==')') cnt--;
		if(cnt<0) return 0;
	}
	if(cnt>0) return 0;
	return 1;
}
signed main() {
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	int T;
	scanf("%lld",&T);
	while(T--) {
		scanf("%lld",&n);
		n*=2;
		for(int i=1;i<=n;i++) {
			scanf("%lld %lld %c ",&a[i].a,&a[i].b,&a[i].c);
		}  
		int flag=0;
		for(int i=1;i<=3e2;i++) {
			if(flag) break;
			for(int j=1;j<=3e2;j++) {
				X=i,Y=j;
				if(check()) {
					flag=1;
					printf("YES\n");
					break;
				}
			}
		}
		if(!flag) printf("NO\n");
	}
	return 0;
}
/*
1
1
518608 752715 (
120865 468208 )
*/
