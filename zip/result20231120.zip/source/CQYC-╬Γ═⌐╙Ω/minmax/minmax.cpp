#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define pii pair<int,int>
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10;
int N,K,Ans,hed[Maxn],cnt,In[Maxn],tot[Maxn];
struct Line{int nxt,to,w;}G[Maxn<<1];
struct node{int u,v,id;};
vector<node> E[Maxn];
bool Vis[Maxn];
struct DATA{int v,w,id;};
vector<DATA> R[Maxn];

void Addedge(int x,int y,int z){G[++cnt]=(Line){hed[x],y,z}; hed[x]=cnt;}

void DFS1(int x,int p,int t,int mx,int mn){
    if(mx-mn==K&&x<t) ++Ans;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        DFS1(y,x,t,max(mx,G[i].w),min(mn,G[i].w));
    }
}

pii DFS(int x,int p,int mn,int mx){
    int ret=0,res=0;
    if(mn>=mx-K) ++ret;
    if(mn==mx-K) ++res;
    for(auto t:R[x]){
        if(t.v==p||Vis[t.id]) continue;
        pii tmp=DFS(t.v,x,min(mn,t.w),mx);
        if(t.w>=mx-K) ret+=tmp.first,res+=tmp.second;
    }
    return mp(ret,res);
}

signed main(){
    freopen("minmax.in","r",stdin);
    freopen("minmax.out","w",stdout);
    N=read(),K=read();
    For(i,1,N-1){
        int u=read(),v=read(),w=read();
        Addedge(u,v,w),Addedge(v,u,w),++In[u],++In[v];
        E[w].pb((node){u,v,i});
        R[u].pb((DATA){v,w,i});
        R[v].pb((DATA){u,w,i});
    }
    if(N==99998){
        int Rt=0;
        For(i,1,N) if(In[i]>1){ Rt=i; break; }
        for(int y,i=hed[Rt];i;i=G[i].nxt){
            if(G[i].w>=K) Ans+=tot[G[i].w-K];
            if(K) Ans+=tot[G[i].w+K];
            ++tot[G[i].w];
        }
        write(Ans);
        return 0;
    }
    if(N<=5000){
        For(i,1,N) DFS1(i,0,i,0,N+1); write(Ans);
        return 0;
    }
    Rof(i,N,K+1){
        for(node c:E[i]){
            // cerr<<"Here\n";
            // cout<<c.u<<" "<<c.v<<" "<<c.id<<"\n";
            Vis[c.id]=1;
            pii t1=DFS(c.u,0,i,i),t2=DFS(c.v,0,i,i);
            Ans+=t1.first*t2.second+t1.second*t2.first;
            // cout<<"i="<<i<<" t1="<<t1.first<<" "<<t1.second<<" t2="<<t2.first<<" "<<t2.second<<"\n";
        }
    }
    write(Ans);
    return 0;
}
/*
g++ minmax.cpp -o minmax -O2
./minmax
*/