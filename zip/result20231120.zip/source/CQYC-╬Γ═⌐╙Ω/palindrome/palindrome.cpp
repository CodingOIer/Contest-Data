#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,P=998244353;
int N,K,A[Maxn],Ans;

void DFS(int x){
    if(x>1){
        bool c=0;
        For(i,0,x-1){
            bool f=0;
            for(int l=1,r=i;l<r;++l,--r) if(A[l]!=A[r]) {f=1;break;}
            if(f) continue;
            for(int l=i+1,r=x-1;l<r;++l,--r) if(A[l]!=A[r]) {f=1;break;}
            if(!f) {c=1;break;}
        }
        if(c) ++Ans;
    }
    if(x>N) return;
    For(i,1,K) A[x]=i,DFS(x+1);
}

signed main(){
    freopen("palindrome.in","r",stdin);
    freopen("palindrome.out","w",stdout);
    N=read(),K=read(); DFS(1); write(Ans);
    return 0;
}
/*
g++ palindrome.cpp -o palindrome -O2
./palindrome
*/