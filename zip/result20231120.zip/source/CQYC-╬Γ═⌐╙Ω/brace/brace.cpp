#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=3010;
int T,N,Num[Maxn],top,x,y,Sum[Maxn],Mx;
struct node{
    int a,b; char c;
    bool operator <(const node &t){
        int c1=a*x+b*y,c2=t.a*x+t.b*y;
        return (c1^c2)?c1<c2:c<t.c;
    }
}A[Maxn];

void Solve(){
    N=read(); top=Mx=0;
    For(i,1,N*2) A[i].a=Num[++top]=read(),A[i].b=Num[++top]=read(),cin>>A[i].c;
    if(N==1){
        if(A[1].c==')') swap(A[1],A[2]);
        if(A[1].a>A[2].a&&A[1].b>A[2].b) puts("NO");
        else puts("YES");
        return;
    }
    sort(Num+1,Num+top+1); top=unique(Num+1,Num+top+1)-Num-1;
    Mx=Num[top];
    if(Mx<=1000){
        For(i,1,Mx) For(j,1,Mx){
            x=i,y=j;
            sort(A+1,A+N*2+1);
            Sum[0]=0; bool f=0;
            For(k,1,N*2){
                Sum[k]=Sum[k-1]+(A[k].c=='('?1:-1);
                if(Sum[k]<0) {f=1; break;}
            }
            if(!f) return puts("YES"),void();
        }
        puts("NO"); return;
    }
    For(i,1,top) For(j,1,top){
        x=Num[i],y=Num[j];
        sort(A+1,A+N*2+1);
        Sum[0]=0; bool f=0;
        For(k,1,N*2){
            Sum[k]=Sum[k-1]+(A[k].c=='('?1:-1);
            if(Sum[k]<0) {f=1; break;}
        }
        if(!f) return puts("YES"),void();
    }
    puts("NO");
    // cerr<<"Clock="<<clock()<<"\n";
}

signed main(){
    freopen("brace.in","r",stdin);
    freopen("brace.out","w",stdout);
    T=read(); while(T--) Solve();
    return 0;
}
/*
g++ brace.cpp -o brace -O2
./brace
*/