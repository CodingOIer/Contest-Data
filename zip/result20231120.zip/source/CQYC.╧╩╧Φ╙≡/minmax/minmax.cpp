#include<bits/stdc++.h>
#define fi first
#define se second
#define mk make_pair
#define pi pair<int,int>
using namespace std;
typedef long long ll;
const int N=2e5+10,M=N<<1;
int n,k,siz,root,Tr[N];
int T;
int f[N],num[N],Mn[N];
int first[N],to[M],nxt[M],lth[M],cnt;
bool vis[N];
ll ans;
pi ned[N];
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
inline void Max(int &x,int y) {x=x>y?x:y;}
void Add(int x,int y) {for(;x<=n;x+=(x&-x)) Tr[x]+=y;}
int Query(int x,int res=0) {for(;x;x-=(x&-x)) res+=Tr[x];return res;}
void get_root(int x,int fr)
{
    f[x]=0;num[x]=1;
    for(int i=first[x],v;i;i=nxt[i])
    {
        if(vis[v=to[i]]||v==fr) continue;
        get_root(v,x);
        num[x]+=num[v];
        Max(f[x],num[v]);
    }
    Max(f[x],siz-num[x]);
    if(f[root]>f[x]) root=x;
}
void dfs(int x,int fr,int mn,int mx)
{
    if(mn+k<mx) return;
    ned[++T]=mk(mn,mx);
    for(int i=first[x],v;i;i=nxt[i])
        if(!vis[v=to[i]]&&v!=fr) dfs(v,x,min(mn,lth[i]),max(mx,lth[i]));
}
void add(int x)
{
    for(int i=1,l,r;i<=T;i++)
    {
        l=ned[i].fi,r=ned[i].se;
        if(l+k==r) Add(l,x);
        else Mn[l]+=x;
    }
}
void get_ans(int x)
{
    for(int i=first[x],v;i;i=nxt[i])
        if(!vis[v=to[i]]) T=0,dfs(v,x,lth[i],lth[i]),add(1);
    ll S=0;
    for(int i=first[x],v;i;i=nxt[i])
    {
        if(vis[v=to[i]]) continue;
        T=0,dfs(v,x,lth[i],lth[i]);
        add(-1);
        for(int j=1,l,r,p;j<=T;j++)
        {
            l=ned[j].fi,r=ned[j].se;
            p=(Query(l)-Query(max(0,r-k-1)));
            ans+=p;
            if(k+l==r) ++ans,S+=p;
            else if(r>k) ans+=Mn[r-k];
        }
        add(1);
    }
    ans-=S/2;
    for(int i=first[x],v;i;i=nxt[i])
        if(!vis[v=to[i]]) T=0,dfs(v,x,lth[i],lth[i]),add(-1);
}
void solve(int x)
{
    vis[x]=1;get_ans(x);
    for(int i=first[x],v;i;i=nxt[i])
    {
        if(vis[v=to[i]]) continue;
        siz=num[v];root=0;
        get_root(v,v);
        solve(root);
    }
}
int main()
{
    freopen("minmax.in","r",stdin);
    freopen("minmax.out","w",stdout);
    f[0]=1e9;
    scanf("%d%d",&n,&k);
    for(int i=1,u,v,w;i<n;i++)
        scanf("%d%d%d",&u,&v,&w),inc(u,v,w),inc(v,u,w);
    siz=n;get_root(1,0);solve(root);
    printf("%lld\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
