#include<bits/stdc++.h>
using namespace std;
const int N=1510;
struct ok{
    int a,b;
    char ch;
    void init() {cin>>a>>b>>ch;}
}a[N+N];
int T,n;
int main()
{
    freopen("brace.in","r",stdin);
    freopen("brace.out","w",stdout);
    cin>>T;
    while(T--)
    {
        cin>>n;
        for(int i=1;i<=n+n;i++) a[i].init();
        if(a[1].ch==')') swap(a[1],a[2]);
        if(a[1].a==a[2].a&&a[1].b==a[2].b) puts("YES");
        else if(a[1].a<a[2].a||a[1].b<a[2].b) puts("YES");
        else puts("NO");
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
