#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,mod=998244353;
int n,k,ans,f[N],g[N],pw[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int P(int x) {return x?(x-1)/2+1:0;}
int main()
{
    freopen("palindrome.in","r",stdin);
    freopen("palindrome.out","w",stdout);
    cin>>n>>k;
    pw[0]=1;
    for(int i=1;i<=n;i++) pw[i]=1ll*k*pw[i-1]%mod;
    for(int i=1;i<=n;i+=2) f[i]=1ll*i*pw[P(i)]%mod;
    for(int i=2;i<=n;i+=2)
        f[i]=1ll*(i>>1)*pw[P(i)]%mod,
        upd(f[i],1ll*(i>>1)*pw[P(i+1)]%mod);
    for(int i=1;i<=n;i++) g[i]=f[i];
    for(int i=1;i<=n;i++)
        for(int j=2;i*j<=n;j++)
            upd(g[i*j],mod-1ll*g[i]*j%mod);
    for(int i=1;i<=n;i++)
        upd(ans,1ll*(n/i)*g[i]%mod);
    cout<<ans<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
