#include <bits/stdc++.h>
using namespace std;

int n, k, ans;
char tmp[100002];

void dfs(int i, int limit) {
	if (i == limit + 1) {
		for (int j = 1; j <= limit + 1; ++j) { // [1, j), [j, n]
			bool ok = 1;
			for (int l = 1, r = j - 1; l < r && ok; ++l, --r)
				if (tmp[l] != tmp[r]) ok = 0;
			for (int l = j, r = limit; l < r && ok; ++l, --r)
				if (tmp[l] != tmp[r]) ok = 0;
			if (ok) {
				++ans;
				return;
			}
		}
		return;
	}
	for (int j = 1; j <= k; ++j) {
		tmp[i] = j;
		dfs(i + 1, limit);
	}
}

int main() {
	freopen("palindrome.in", "r", stdin);
	freopen("palindrome.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; ++i)
		dfs(1, i);
	printf("%d\n", ans);
	return 0;
}
/*
20pts
*/
