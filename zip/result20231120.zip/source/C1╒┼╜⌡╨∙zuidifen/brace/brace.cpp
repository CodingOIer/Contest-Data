#include <bits/stdc++.h>
using namespace std;

int t, n, a[3001], b[3001];
char c[3001][4];

void solve() {
	scanf("%d", &n);
	for (int i = 1; i <= n * 2; ++i) {
		scanf("%d%d%s", &a[i], &b[i], c[i] + 1);
	}
	if (n == 1) {
		if ((a[1] >= a[2] && b[1] <= b[2]) || (a[1] <= a[2]) && (b[1] >= b[2])) {
			puts("YES"); 
		} else {
			if (a[1] <= a[2] && b[1] <= b[2]) {
				if (c[1][1] == '('&& c[2][1] == ')') puts("YES");
				else puts("NO");
			} else {
				if (c[1][1] == ')'&& c[2][1] == '(') puts("YES");
				else puts("NO");
			}
		}
	}
}

int main() {
	freopen("brace.in", "r", stdin);
	freopen("brace.out", "w", stdout);
	scanf("%d", &t);
	while (t--) solve();
	return 0;
}
/*
10pts
*/
