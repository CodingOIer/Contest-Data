#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N<<1],to[N<<1],w[N<<1],t;
il void add(int u,int v,int d){
    nxt[++t]=head[u];head[u]=t;to[t]=v;w[t]=d;
    nxt[++t]=head[v];head[v]=t;to[t]=u;w[t]=d;
}
int n,K,mx[N],sz[N],sum,rt,dmx[N],dmn[N],ff[N],ans,cnt1[N],cnt2[N];
vector<int> V1,V2;
bool vis[N];
il void getrt(int x,int fa){
    sz[x]=1;mx[x]=0;
    for(int i=head[x];i;i=nxt[i]) if(!vis[to[i]]&&to[i]!=fa){
        getrt(to[i],x);sz[x]+=sz[to[i]];mx[x]=max(mx[x],sz[to[i]]);
    }
    mx[x]=max(mx[x],sum-sz[x]);
    // cerr<<x<<" "<<mx[x]<<"\n";
    if(mx[rt]>mx[x]) rt=x;
}
il void dfs1(int x,int fa,int faa){
    V1.pk(x);ff[x]=faa;
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa&&!vis[to[i]]){
        dmn[to[i]]=min(dmn[x],w[i]);
        dmx[to[i]]=max(dmx[x],w[i]);
        dfs1(to[i],x,faa);
    }
}
il bool cmp1(int u,int v){
    return dmn[u]<dmn[v];
}
il bool cmp2(int u,int v){
    return dmx[u]<dmx[v];
}
bool vis1[N];
il void calc(int x){
    V1.clear();V1.pk(x);dmn[x]=inf;dmx[x]=0;
    for(int i=head[x];i;i=nxt[i]) if(!vis[to[i]]){
        dmn[to[i]]=dmx[to[i]]=w[i];dfs1(to[i],x,to[i]);
    }
    V2=V1;
    sort(V1.begin(),V1.end(),cmp1);
    sort(V2.begin(),V2.end(),cmp2);
    // if(x==3){
    //     for(auto v:V2) cerr<<v<<" "<<dmn[v]<<" "<<dmx[v]<<"\n";
    // }
    for(int t1=0,t2=0,t3=0,sum1=0,sum2=0;t1<sz[x];++t1){
        while(t2<sz[x]&&dmx[V2[t2]]<dmn[V1[t1]]+K){
            if(!vis1[V2[t2]]){
                if(V2[t2]!=x) ++cnt1[ff[V2[t2]]];
                ++sum1;
            }
            ++t2;
        }
        while(t3<sz[x]&&dmx[V2[t3]]<=dmn[V1[t1]]+K){
            if(!vis1[V2[t3]]){
                if(V2[t3]!=x) ++cnt2[ff[V2[t3]]];
                ++sum2;
            }
            ++t3;
        }
        // if(x==3&&V1[t1]==2) cerr<<t2<<" "<<t3<<"\n";
        // if(x==3) cerr<<V1[t1]<<" "<<t3<<" "<<sum2<<"\n";
        if(dmx[V1[t1]]<dmn[V1[t1]]+K){
            // if(x==3) cerr<<V1[t1]<<" "<<sum2<<" "<<cnt2[ff[V1[t1]]]<<" "<<sum1<<" "<<cnt1[ff[V1[t1]]]<<"\n";
            ans+=sum2-cnt2[ff[V1[t1]]]-(sum1-cnt1[ff[V1[t1]]]);
        }
        else if(dmx[V1[t1]]==dmn[V1[t1]]+K){
            // if(x==3) cerr<<V1[t1]<<" "<<sum2<<" "<<cnt2[ff[V1[t1]]]<<"\n";
            ans+=sum2-cnt2[ff[V1[t1]]];
        }
        if(dmx[V1[t1]]<dmn[V1[t1]]+K){
            --cnt1[ff[V1[t1]]];--sum1;
        }
        if(dmx[V1[t1]]<=dmn[V1[t1]]+K){
            --cnt2[ff[V1[t1]]];--sum2;
        }
        vis1[V1[t1]]=1;
    }
    for(auto v:V1) vis1[v]=0;
    for(int i=head[x];i;i=nxt[i]) if(!vis[to[i]]) cnt1[to[i]]=cnt2[to[i]]=0;
}
il void solve(int x){
    // cerr<<x<<" ";
    vis[x]=1;getrt(x,0);calc(x);
    for(int i=head[x];i;i=nxt[i]) if(!vis[to[i]]){
        sum=sz[to[i]];getrt(to[i],rt=0);solve(rt);
    }
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
    n=read();K=read();
    for(int i=1;i<n;++i){
        int u=read(),v=read(),d=read();
        add(u,v,d);
    }
    sum=n;mx[0]=inf;getrt(1,0);solve(rt);write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}