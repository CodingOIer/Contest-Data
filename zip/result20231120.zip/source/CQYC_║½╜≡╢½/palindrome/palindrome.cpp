#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define inf (int)(1000000000000000000)
#define mod 998244353
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int n,K,ans,f[N],g[N];
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
    n=read();K=read();
    for(int i=1;i<=n;++i){
        if(i&1) f[i]=Pow(K,(i+1)>>1)*i%mod;
        else f[i]=(Pow(K,i/2+1)*(i>>1)+Pow(K,i>>1)*(i>>1))%mod;
        // for(int j=0;j<i;++j) f[i]+=Pow(K,(j+1)>>1)*Pow(K,(i-j+1)>>1);
    }
    for(int i=1;i<=n;++i){
        Add(g[i],f[i]);
        for(int j=2;j*i<=n;++j) Del(g[j*i],g[i]*j%mod);
        // for(int d=1;d<i;++d) if(!(i%d)) g[i]-=g[d]*(i/d);
    }
    for(int i=1;i<=n;++i) Add(ans,g[i]*(n/i)%mod);
    write(ans);
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}