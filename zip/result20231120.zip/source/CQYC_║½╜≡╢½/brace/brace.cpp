#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 3010
#define M 3000010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,tot;
struct node{
    int a,b,c;
} a[N];
pii b[M],K;
il bool operator<(node u,node v){
    if(u.a*K.fi+u.b*K.se==v.a*K.fi+v.b*K.se) return u.c>v.c;
    return u.a*K.fi+u.b*K.se<v.a*K.fi+v.b*K.se;
}
il bool cmp1(pii u,pii v){
    return u.fi*v.se<v.fi*u.se;
}
// int cnt=0;
il void Sort(){
    int flag=1;
    while(flag){
        flag=0;
        // cerr<<"ERROR";
        for(int i=1;i<n;++i) if(a[i+1]<a[i]){
            flag=1;swap(a[i],a[i+1]);
        }
    // ++cnt;
    // if(cnt==1000000) cerr<<"ERROR";
    // cerr<<cnt<<" ";
    }
    // cerr<<cnt<<" ";
	// cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
    // exit(0);
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
    T=read();
    while(T--){
        n=read()<<1;tot=0;
        // cerr<<n<<" ";
        char ch[1];
        for(int i=1;i<=n;++i){
            a[i].a=read();a[i].b=read();scanf(" %s",ch);
            if(ch[0]=='(') a[i].c=1;
            else a[i].c=-1;
        }
        b[++tot]=pii(1e7,1);b[++tot]=pii(1,1e7);
        // b[++tot]=pii(0,1);b[++tot]=pii(1,0);
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j) if(a[j].a<a[i].a&&a[i].b<a[j].b&&i!=j) b[++tot]=pii(a[j].b-a[i].b,a[i].a-a[j].a);
        sort(b+1,b+1+tot,cmp1);
        tot=unique(b+1,b+1+tot)-b-1;
        int flag1=0;
        for(int i=1;i<=tot;++i){
            K=b[i];
            if(i==1) sort(a+1,a+1+n);
            else Sort();
            int flag2=1;
            for(int j=1,now=0;j<=n;++j){
                now+=a[j].c;
                if(now<0){
                    flag2=0;break;
                }
            }
            if(flag2){
                flag1=1;break;
            }
        }
        puts(flag1?"YES":"NO");
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}