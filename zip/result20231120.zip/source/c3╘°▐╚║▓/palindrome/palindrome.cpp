#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Mod=998244353;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,m;
int dp[2000005],gg[1005];
int ans;
int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1) res=(res*a)%Mod;
		a=(a*a)%Mod;
		b>>=1;
	}
	return res;
}
void dfs(int x){
	for(int i=1;i<x;i++){
		bool flag=0;
		for(int j=1;j<=i;j++){
			if(gg[j]!=gg[i-j+1]) flag=1;
		}
		if(flag) continue;
		for(int j=i+1;j<x;j++){
			if(gg[j]!=gg[x-(j-i)]) flag=1;
		}
		if(flag) continue;
		ans++;
		break;
	}
	if(x==n+1){
		return;
	}
	for(int i=1;i<=m;i++){
		gg[x]=i;
		dfs(x+1);
		gg[x]=0;
	}
}
int s[1000005];
signed main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	n=read(),m=read();
	if(n<=10||(m==2&&n<=20)){
		dfs(1);
		cout<<ans;
		return 0;
	}
	if(max(n,m)<=100000){
		for(int i=1;i<=n;i++){
			dp[i]=ksm(m,(i+1)/2);
		}
		dp[0]=1;
		int sum=0,p=1;
	    for(int i=1;i<=n;i++){
	    	s[i]=ksm(m,(i+1)/2);
	    }
	    for(int i=1;i<=n;i++){
	    	for(int j=0;i+j<=n;j++){
	    		dp[i+j]+=s[i]*s[j]%Mod;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=2;j*i<=n;j++){
				dp[j*i]=(dp[j*i]-j*dp[i]%Mod+Mod)%Mod;
				for(int k=1;k<=j;k++)
					if(__gcd(j,k)!=1) dp[j*i]=(dp[j*i]+dp[i])%Mod;
			}
		}
	    for(int i=1;i<=n;i++){
	    	ans+=dp[i];
	    	ans%=Mod;
		}
		cout<<ans;
	}
	return 0;
}
