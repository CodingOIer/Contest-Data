#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,k;
int dep[200005],siz[200005],son[200005];
int fa[200005],tp[200005];
vector<pair<int,int> > q[200005];
void dfs1(int x,int fas){
	fa[x]=fas;
	siz[x]=1;
	dep[x]=dep[fas]+1;
	for(auto y:q[x]){
		if(y.first==fas) continue;
		dfs1(y.first,x);
		siz[x]+=siz[y.first];
		if(siz[y.first]>siz[son[x]]) son[x]=y.first;
	}
}
int tot=0;
int idea[200005],gg[200005];
void dfs2(int x,int Tp){
	tp[x]=Tp;
	idea[x]=++tot;
	gg[tot]=x;
	if(son[x]){
		dfs2(son[x],Tp);
	}
	for(auto y:q[x]){
		if(y.first==fa[x]||y.first==son[x]) continue;
		dfs2(y.first,y.first);
	}
}
int minx,maxx;
int stmin[200005][20],stmax[200005][20];
int lg[200005];
int querymin(int l,int r){
	l++;
	if(l>r) return 114514;
	int hh=lg[r-l+1];
	return min(stmin[l][hh],stmin[r-(1<<hh)+1][hh]);
}
int querymax(int l,int r){
	l++;
	if(l>r) return -114514;
	int hh=lg[r-l+1];
	return max(stmax[l][hh],stmax[r-(1<<hh)+1][hh]);
}
void query(int x,int y){
	while(tp[x]!=tp[y]){
		if(dep[tp[x]]<dep[tp[y]]) swap(x,y);
		minx=min(minx,querymin(idea[tp[x]]-1,idea[x]));
		maxx=max(maxx,querymax(idea[tp[x]]-1,idea[x]));
		if(maxx-minx>k) return;
		x=fa[tp[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	minx=min(minx,querymin(idea[x],idea[y]));
	maxx=max(maxx,querymax(idea[x],idea[y]));
//	cout<<x<<" "<<y<<endl;
//	if(maxx-minx==k) cout<<1<<endl;
//	cout<<endl;
}
int a[200005];
signed main(){
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	n=read(),k=read();
	int anna
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w=read();
		q[u].push_back({v,w});
		q[v].push_back({u,w});
		a[w]++;
		anna=max(anna,w);
	}
	dfs1(1,0);
	dfs2(1,1);
	if(n<=5000){
		for(int i=1;i<=n;i++){
			for(auto v:q[i])
			{
				int x=v.first,w=v.second;
				if(x==fa[i]){
					stmin[idea[i]][0]=w;
					stmax[idea[i]][0]=w;
				}
			}
		}
		for(int i=2;i<=n;i++) lg[i]=lg[i/2]+1;
		for(int k=1;k<20;k++){
			for(int i=1;i<=n;i++){
				stmin[i][k]=min(stmin[i][k-1],stmin[i+(1<<(k-1))][k-1]);
				stmax[i][k]=max(stmax[i][k-1],stmax[i+(1<<(k-1))][k-1]);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				minx=1e9,maxx=-1e9;
				query(i,j);
				if(maxx-minx==k)
					++ans;
			}
		}
		cout<<ans;
		return 0;
	}
	int p=0;
	for(int i=1;i<=n;i++){
		if(q[i].size()>1){
			p++;
		}
	}
	if(p==1){
		int ans=0;
		for(int i=1;i<=n;i++){
			ans+=a[i]*a[i+k];
		}
		cout<<ans;
		return 0;
	}
	cout<<0;
	return 0;
}
