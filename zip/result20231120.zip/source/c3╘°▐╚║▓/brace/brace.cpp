#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
vector<pair<int,int> >a,b;
vector<int> pq;
signed main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	int T=read();
	while(T--){
		pq.clear();
		int n=read();
		a.clear(),b.clear();
		if(n==1){
			int A=read(),B=read();
			char ch=getchar();
			int C=read(),D=read();
			char ch2=getchar();
			if(ch=='(') swap(A,C),swap(B,D);
			if(A<=C&&B<=D){
				cout<<"NO"<<endl;
			}
			else cout<<"YES"<<endl;
			continue;
			
		}
		for(int i=1;i<=2*n;i++){
			int x=read(),y=read();
			char ch=getchar();
			if(ch=='(') a.push_back({x,y});
			else b.push_back({x,y});
		}
		bool gg=0;
		for(auto u:b){
			bool flag=0;
			for(auto v:a){
				if(u.first>v.first||u.second>v.second){
					flag=1;
					break; 
				} 
			}
			if(!flag){
				gg=1;
				break;
			}
		} 
		for(auto u:a){
			bool flag=0;
			int gggg=0;
			for(auto v:b){
				if(u.first<v.first||u.second<v.second){
					flag=1;
				} 
				else{
					gggg++;
				}
			}
			pq.push_back(gggg);
			if(!flag){
				gg=1;
				break;
			}
		}
		sort(pq.begin(),pq.end());
		int ggg=-1;
		for(int i=pq.size()-1;i>=0;i--){
			int x=pq[i];
			if(pq.size()-i>n-pq[i]){
				if(ggg==-1) ggg=1;
				break;
			}
		}
		if(ggg==-1){
			ggg=0;
		}
		else ggg=-1;
		pq.clear();
		for(auto u:a){
			int gggg=0;
			for(auto v:b){
				if(u.first>v.first||u.second<v.second);
				else gggg++;
			}
			pq.push_back(gggg);
		}
		sort(pq.begin(),pq.end());
		for(int i=pq.size()-1;i>=0;i--){
			int x=pq[i];
			if(pq.size()-i>n-pq[i]){
				if(ggg==-1) ggg=1;
				break;
			}
		}
		if(ggg==-1){
			ggg=0;
		}
		else ggg=-1;
		pq.clear();
		for(auto u:a){
			int gggg=0;
			for(auto v:b){
				if(u.first<v.first||u.second>v.second);
				else gggg++;
			}
			pq.push_back(gggg);
		}
		sort(pq.begin(),pq.end());
		for(int i=pq.size()-1;i>=0;i--){
			int x=pq[i];
			if(pq.size()-i>n-pq[i]){
				if(ggg==-1) ggg=1;
				break;
			}
		}
		if(ggg==-1){
			ggg=0;
		}
		else ggg=-1;
		pq.clear();
		if(gg||ggg!=0) cout<<"NO"<<endl;
		else cout<<"YES"<<endl;
	} 
	return 0;
}

