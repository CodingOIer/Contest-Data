#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n,k; 
int tot,head[N],nxt[N],to[N],val[N];
int ans;
int p[200005];
void add(int u,int v,int w){
	nxt[++tot]=head[u];
	to[tot]=v;
	val[tot]=w;
	head[u]=tot;
}
void dfs(int x,int fa,int mx,int mn){
	if(mx-mn==k) ans++;
	for(int i=head[x];i;i=nxt[i]){
		if(to[i]==fa) continue;
		dfs(to[i],x,max(mx,val[i]),min(mn,val[i]));
	}
}
signed main(){
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i=1,u,v,w;i<n;i++){
		scanf("%lld %lld %lld",&u,&v,&w);
		add(u,v,w);
		add(v,u,w);
		p[w]++;
	}
	if(n<=5000){
		for(int i=1;i<=n;i++) dfs(i,0,0,1e18);
		printf("%lld",ans/2);
		return 0;
	}
	for(int i=k;i<=n;i++) ans+=p[i]*p[i-k];
	printf("%lld",ans/2);
	return 0;
}


