#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int n;
int xx,yy;
struct node{
	int a,b,c;
}t[1505];
bool cmp(node x,node y){
	return x.c<y.c;
}
bool cmp2(node x,node y){
	if(x.a*xx+x.b*yy==y.a*xx+y.b*yy) return x.c<y.c;
	return x.a*xx+x.b*yy<y.a*xx+y.b*yy;
}
signed main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld",&n);
		for(int i=1;i<=2*n;i++){
			char k;
			scanf("%lld %lld",&t[i].a,&t[i].b);
			cin>>k;
			if(k=='(') t[i].c=0;
			else t[i].c=1;
		}
		if(n==1){
			sort(t+1,t+n*2+1,cmp);
			if(t[1].a>=t[2].a&&t[1].b>=t[2].b&&(t[1].a!=t[2].a||t[1].b!=t[2].b)) cout<<"NO"<<'\n';
			else cout<<"YES"<<'\n';
			continue;
		}
		bool z=0;
		for(xx=1;xx<=200;xx++){
			for(yy=1;yy<=200;yy++){
				sort(t+1,t+n*2+1,cmp2);
				int l=0;
				z=0;
				for(int i=1;i<=2*n;i++){
					if(t[i].c==0) l++;
					else l--;
					if(l<0){
						z=1;
						break;
					}
				}
				if(z==0) break;
			}
			if(z==0) break;
		}
		if(z==0) cout<<"YES"<<'\n';
		else cout<<"NO"<<'\n';
	}
	return 0;
}


