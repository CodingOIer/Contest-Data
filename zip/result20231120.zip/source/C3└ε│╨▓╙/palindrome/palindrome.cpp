#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k;
int f[100005],g[100005];
int p[100005];
int ans;
const int mod=998244353;
signed main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	p[0]=1;
	for(int i=1;i<=n;i++) p[i]=p[i-1]*k%mod;
	if(n<=5000){
		f[1]=g[1]=ans=k;
		for(int i=2;i<=n;i++){
			for(int j=0;j<i;j++){
				f[i]+=p[(j+1)/2+(i-j+1)/2];
				f[i]%=mod;
			}
			g[i]=f[i];
			for(int j=1;j<i;j++){
				if(i%j!=0) continue;
				g[i]=(g[i]-g[j]*(i/j)%mod+mod)%mod;
				ans+=g[j];
				ans%=mod;
			}
			ans+=g[i];
			ans%=mod;
		}
		printf("%lld",ans);
		return 0;
	}
	g[1]=ans=k;
	for(int i=2;i<=n;i++){
		g[i]=(g[i]-g[1]*i%mod+mod)%mod;
		ans+=g[1];
		ans%=mod;
	}
	for(int i=2;i<=n;i++){
		if(i&1) g[i]+=p[(i+1)/2]*i%mod;
		else g[i]+=(p[i/2]+p[i/2+1])%mod*(i/2)%mod;
		g[i]%=mod;
		for(int j=2;i*j<=n;j++){
			g[i*j]=(g[i*j]-g[i]*j%mod+mod)%mod;
			ans+=g[i];
			ans%=mod;
		}
		ans+=g[i];
		ans%=mod;
	}
	printf("%lld",ans);
	return 0;
}


