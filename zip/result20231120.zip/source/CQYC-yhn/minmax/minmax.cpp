#include<bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int a[8000005],sum[200005],dep[200005],SUM[200005];
int n,K,t1,t2,t3,cnt,tnt,head[200005],nxt[400005],txt[400005],zhi[400005],ans=0,sz[200005],mx[200005],rt,Rt[200005],ch[8000005][2];
vector<pair<int,int>> e;
vector<int> E;
set<int> s;
set<int>::iterator it;
bool v[200005];
struct ok{
    int mx,mn;
    ok operator + (const ok &A) const{
        ok B;
        B.mx=max(mx,A.mx);
        B.mn=min(mn,A.mn);
        return B;
    }
}T[800005];
bool pppp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void dfs1(int k,int f){
    dep[k]=dep[f]+1;
    if(dep[k]>dep[rt]) rt=k;
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        dfs1(txt[i],k);
    }
}
inline void Dfs2(int k,int f){
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        E.push_back(zhi[i]);
        Dfs2(txt[i],k);
    }
}
inline void build(int k,int l,int r){
    if(l==r){
        T[k].mx=T[k].mn=E[l];
        return;
    }
    int mid=(l+r)>>1;
    build(k<<1,l,mid);build((k<<1)^1,mid+1,r);
    T[k]=T[k<<1]+T[(k<<1)^1];
}
inline int Query(int k,int l,int r,int ll,int rr){
    if(ll>rr) return -1e18;
    if(ll<=l&&rr>=r) return T[k].mx;
    int mid=(l+r)>>1,w=-1e18;
    if(ll<=mid) w=max(w,Query(k<<1,l,mid,ll,rr));
    if(rr>mid) w=max(w,Query((k<<1)^1,mid+1,r,ll,rr));
    return w;
}
inline int query2(int k,int l,int r,int ll,int rr){
    if(ll>rr) return 1e18;
    if(ll<=l&&rr>=r) return T[k].mn;
    int mid=(l+r)>>1,w=1e18;
    if(ll<=mid) w=min(w,query2(k<<1,l,mid,ll,rr));
    if(rr>mid) w=min(w,query2((k<<1)^1,mid+1,r,ll,rr));
    return w;
}
inline void solve2(){
    // cerr<<"bom\n";
    rt=0;
    dfs1(1,0);
    Dfs2(rt,0);
    int sz=(int)E.size()-1;
    build(1,0,sz);
    for(int i=0;i<n;i++){
        int l=0,r=sz,mid,res1=(int)E.size(),res2=-1;
        while(l<=r){
            mid=(l+r)>>1;
            if((Query(1,0,sz,i,mid)-query2(1,0,sz,i,mid))>=K) res1=min(res1,mid),r=mid-1;
            else l=mid+1;
        }
        l=0;r=sz;
        while(l<=r){
            mid=(l+r)>>1;
            if((Query(1,0,sz,i,mid)-query2(1,0,sz,i,mid))<=K) res2=max(res2,mid),l=mid+1;
            else r=mid-1;
        }
        if(res1<=res2) ans+=(res2-res1+1);
    }
    cout<<ans;
}
inline void clear(){
    for(int i=1;i<=tnt;i++) ch[i][0]=ch[i][1]=a[i]=0;
    for(it=s.begin();it!=s.end();it++) Rt[*it]=0;
    tnt=0;
}
inline void add(int &k,int l,int r,int g){
    if(!k) k=++tnt;
    if(l==r){
        a[k]++;
        return;
    }
    int mid=(l+r)>>1;
    if(g<=mid) add(ch[k][0],l,mid,g);
    else add(ch[k][1],mid+1,r,g);
    a[k]=a[ch[k][0]]+a[ch[k][1]];
}
inline int query(int k,int l,int r,int ll,int rr){
    if(!k) return 0;
    if(ll<=l&&rr>=r) return a[k];
    int mid=(l+r)>>1,w=0;
    if(ll<=mid) w+=query(ch[k][0],l,mid,ll,rr);
    if(rr>mid) w+=query(ch[k][1],mid+1,r,ll,rr);
    return w;
}
inline void dfs(int k,int f,int g){
    sz[k]=1;mx[k]=0;
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f||v[txt[i]]) continue;
        dfs(txt[i],k,g);
        sz[k]+=sz[txt[i]];
        mx[k]=max(mx[k],sz[txt[i]]);
    }
    mx[k]=max(mx[k],g-sz[k]);
    if(mx[k]<mx[rt]) rt=k;
}
inline void dfs2(int k,int f,int mx,int in){
    sz[k]=1;
    e.push_back(make_pair(mx,mx-in));
    // cerr<<mx<<" "<<in<<"\n";
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f||v[txt[i]]) continue;
        dfs2(txt[i],k,max(mx,zhi[i]),min(in,zhi[i]));
        sz[k]+=sz[txt[i]];
    }
}
inline void solve(int k){
    // cerr<<k<<"\n";
    for(int i=head[k];i;i=nxt[i]){
        if(v[txt[i]]) continue;
        e.clear();
        dfs2(txt[i],k,zhi[i],zhi[i]);
        for(int j=0;j<(int)e.size();j++){
            // cerr<<k<<" "<<e[j].first<<" "<<e[j].second<<"\n";
            if(e[j].second==K){
                ans++;
                int d=e[j].first-K;
                it=s.lower_bound(d);
                for(;(it!=s.end())&&((*it)<=e[j].first);it++) ans+=query(Rt[*it],0,n,0,(*it)-d);
            }
            else if(e[j].second<K){
                ans+=query(Rt[e[j].first-e[j].second+K],0,n,0,K);
                // cerr<<k<<" "<<ans<<"\n";
                it=s.lower_bound(e[j].first-K);
                // cerr<<k<<" "<<(*it)<<"\n";
                for(;(it!=s.end())&&((*it)<=e[j].first);it++) ans+=query(Rt[*it],0,n,(*it)-(e[j].first-K),(*it)-(e[j].first-K));
                it=s.lower_bound(e[j].first+1);
                for(;(it!=s.end())&&((*it)<(e[j].first-e[j].second+K));it++) ans+=query(Rt[*it],0,n,K,K);
            }
        }
        for(int j=0;j<(int)e.size();j++) add(Rt[e[j].first],0,n,e[j].second),s.insert(e[j].first);
    }
    clear();
    s.clear();
}
inline void divid(int k){
    v[k]=1;
    solve(k);
    // cerr<<k<<" "<<ans<<"\n";
    for(int i=head[k];i;i=nxt[i]){
        if(v[txt[i]]) continue;
        rt=0;
        dfs(txt[i],0,sz[txt[i]]);
        divid(rt);
    }
}
inline void solve3(){
//	cerr<<"bom\n";
	for(int i=1;i<=n;i++) if(sum[i]>1) rt=i;
	for(int i=1;i<=n;i++){
		if(i==rt) continue;
		SUM[zhi[head[i]]]++;
	}
	for(int i=0;(i+K)<=n;i++) ans+=(SUM[i]*SUM[i+K]);
	cout<<ans;
}
signed main(){
//    cerr<<(double)(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
    freopen("minmax.in","r",stdin);
    freopen("minmax.out","w",stdout);
    n=read(),K=read();
    if(n==1){
        cout<<"0";
        return 0;
    }
    for(int i=1;i<n;i++){
        t1=read(),t2=read(),t3=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2,zhi[cnt]=t3;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1,zhi[cnt]=t3;
        sum[t1]++;sum[t2]++;
    }
    bool FF=1,FF2=0;
    for(int i=1;i<=n;i++){
        if(sum[i]>2) FF=0;
        if(sum[i]==(n-1)) FF2=1;
    }
    if(FF) solve2();
    else if(FF2) solve3();
    else{
        mx[0]=1e18;
        dfs(1,0,n);
        divid(rt);
        cout<<ans;
    }
//    cerr<<(double)clock()/CLOCKS_PER_SEC<<"s";
    return 0;
}
