#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,m,cnt,phi[100005],ans[100005],pri[100005],t[100005],p[100005];
vector<int> g[100005];
bool flag[100005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int js(int x){
    if(x&1) return x*p[(x+1)/2]%M;
    return x/2*(m+1)%M*p[x/2]%M;
}
inline int js2(int x){
    if(t[x]) return t[x];
    int ans=js(x);
    for(auto i:g[x]) ans=(ans-phi[x/i]*js2(i)%M+M)%M;
    return t[x]=ans;
}
signed main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
    int ans=0;
    n=read(),m=read();
    phi[1]=1;
    for(int i=2;i<=n;i++){
        if(!flag[i]){
            pri[++cnt]=i;
            phi[i]=i-1;
        }
        for(int j=1;j<=cnt&&i*pri[j]<=n;j++){
            flag[i*pri[j]]=1;
            if(!(i%pri[j])){
                phi[i*pri[j]]=phi[i]*pri[j];
                break;
            }
            phi[i*pri[j]]=phi[i]*(pri[j]-1);
        }
    }
    p[0]=1;
    for(int i=1;i<=n;i++) p[i]=p[i-1]*m%M;
    for(int i=1;i<=n;i++) for(int j=2;j*i<=n;j++) g[i*j].push_back(i);
    for(int i=1;i<=n;i++) ans=(ans+js2(i))%M;
    cout<<ans;
    return 0;
}