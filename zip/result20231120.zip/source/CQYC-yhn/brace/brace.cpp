#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,n,s1,s2;
bool ans[1005];
struct ok{
    int a,b;
    char c;
}cs;
vector<ok> e[1005];
mt19937 rd(time(0));
inline int Rd(int k){
    return rd()%k+1;
}
inline bool cmp(ok x,ok y){
    int d1=x.a*s1+x.b*s2,d2=y.a*s1+y.b*s2;
    if(d1==d2) return (int)x.c<(int)y.c;
    return d1<d2;
}
inline void js(int x,int y){
    s1=x;s2=y;
    for(int i=1;i<=T;i++) sort(e[i].begin(),e[i].end(),cmp);
    for(int i=1;i<=T;i++){
        int o=0;bool f=1;
        for(int j=0;j<(int)e[i].size();j++){
            if(e[i][j].c=='(') o++;
            else o--;
            if(o<0){
                f=0;
                break;
            }
        }
        if(f) ans[i]|=1;
    } 
}
signed main(){
    freopen("brace.in","r",stdin);
    freopen("brace.out","w",stdout);
    cin>>T;
    for(int A=1;A<=T;A++){
        cin>>n;                
        for(int i=1;i<=(n<<1);i++){
            cin>>cs.a>>cs.b>>cs.c;
            e[A].push_back(cs);
        }      
        if(n==1){
        	if(e[A][0].c==')') swap(e[A][0],e[A][1]);
        	if((e[A][0].a>e[A][1].a)&&(e[A][0].b>e[A][1].b)) ans[A]=0;
        	else if((e[A][0].a>e[A][1].a)&&(e[A][0].b==e[A][1].b)) ans[A]=0;
        	else if((e[A][0].a==e[A][1].a)&&(e[A][0].b>e[A][1].b)) ans[A]=0;
        	else if((e[A][0].a==e[A][1].a)&&(e[A][0].b==e[A][1].b)) ans[A]=0;
        	else ans[A]=1;
		} 
    }
    for(int i=1;i;i++){
        for(int j=1;j<=i;j++){
            js(i,j);
            js(j,i);
            if(((double)clock()/CLOCKS_PER_SEC)>=1.5) break;
        }
        if(((double)clock()/CLOCKS_PER_SEC)>=1.5) break;
    }
    while(((double)clock()/CLOCKS_PER_SEC)<=1.9){
        int d1=Rd((int)1e6),d2=Rd((int)1e6);
        js(d1,d2);
    }
    for(int i=1;i<=T;i++){
        if(ans[i]) puts("YES");
        else puts("NO");
    }
    return 0;
}
