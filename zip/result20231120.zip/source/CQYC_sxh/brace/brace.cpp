#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


char qqq;

const int N = 3100;
int T, n, cnt;

struct node { int k, b, id; bool op; } a[N];
struct JD { 
    long double p; int x, y;
    bool operator <(const JD &b) const {
        return p < b.p;
    }
} d[N * N];

int pos[N], pre[N];

#define ls (x << 1)
#define rs (x << 1 | 1)
#define mid ((l + r) >> 1)

int t[N << 2], tag[N << 2];
void update(int x, int v) { t[x] += v, tag[x] += v; }
void pushdown(int x) { update(ls, tag[x]), update(rs, tag[x]), tag[x] = 0; }
void modify(int L, int R, int v, int x = 1, int l = 1, int r = n) {
    if (l >= L && r <= R) return update(x, v);
    pushdown(x);
    if (mid >= L) modify(L, R, v, ls, l, mid);
    if (mid < R) modify(L, R, v, rs, mid + 1, r);
    t[x] = min(t[ls], t[rs]);
}
void out(int x = 1, int l = 1, int r = n) {
    
    if (l == r) {
        cout << t[x] <<" "; return;
    }
    pushdown(x);
    out(ls, l, mid), out(rs, mid + 1, r);
}
char qqqq;

void solve() {
    n = read() * 2, cnt = 0;
    For(i, 1, n) a[i] = {read(), read(), i, getchar() == '('};
    For(i, 1, n) For(j, i + 1, n) if (a[i].k != a[j].k) {
        d[++cnt].p = (long double)(a[j].b - a[i].b) / (a[i].k - a[j].k);
        if (a[i].k > a[j].k) d[cnt].x = i, d[cnt].y = j;
        else d[cnt].x = j, d[cnt].y = i; if (d[cnt].p <= 0) --cnt;
    }
    d[++cnt] = {0.00001, 0, 0};
    d[++cnt] = {1e9, 0, 0};
    sort(d + 1, d + cnt + 1);

    if (n <= 200) {
        for (int i = 1, j; i <= cnt; i = i + 1) {
            sort(a, a + n + 1, [&](node &x, node &y) {
                long double xx = x.b + d[i].p * x.k;
                long double yy = y.b + d[i].p * y.k;
                return xx != yy ? xx < yy : x.op != y.op ? x.op > y.op : x.id < y.id;
            });
            bool flag = 0;
            For(j, 1, n) {
                pre[j] = pre[j - 1] + (a[j].op ? 1 : -1);
                if (pre[j] < 0) flag = 1;
            }
            if (!flag) return puts("YES"), void();
        }
        puts("NO");
        return;
    }

    sort(a, a + n + 1, [&](node &x, node &y) {
        long double xx = x.b + d[1].p * x.k;
        long double yy = y.b + d[1].p * y.k;
        return xx != yy ? xx < yy : x.op != y.op ? x.op > y.op : x.id < y.id;
    });
    For(i, 1, n << 2) t[i] = tag[i] = 0;
    For(i, 1, n) pos[a[i].id] = i, modify(i, n, a[i].op ? 1 : -1);

    For(i, 1, cnt) {
        if (t[1] >= 0) return puts("YES"), void();
        if (!d[i].x) continue;;int x = d[i].x, y = d[i].y;
        
        modify(pos[x], n, a[pos[x]].op ? -1 : 1);
        modify(pos[y], n, a[pos[y]].op ? -1 : 1);

        swap(pos[x], pos[y]), swap(a[pos[x]], a[pos[y]]);

        modify(pos[x], n, a[pos[x]].op ? 1 : -1);
        modify(pos[y], n, a[pos[y]].op ? 1 : -1);

        if (t[1] >= 0) return puts("YES"), void();
    }
    puts("NO");
}
signed main() {
	freopen("brace.in", "r", stdin);
	freopen("brace.out", "w", stdout);
    cerr << (&qqq - &qqqq) / 1024.0 / 1024.0 << '\n';
    T = read(); while (T--) solve();
	return 0;
}
