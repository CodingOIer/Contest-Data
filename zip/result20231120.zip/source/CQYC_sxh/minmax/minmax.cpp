#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 1000;

int n, k; i64 ans;
int head[N], nxt[N << 1], to[N << 1], w[N << 1], cnt;

void Add(int u, int v) {
    w[cnt + 1] = w[cnt + 2] = read();
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt;
}

int siz[N], maxp[N], root;
bool vis[N];

void get_root(int u, int fa, int total) {
    siz[u] = 1, maxp[u] = 0;
    Eor(u) if (to[i] != fa && !vis[to[i]]) {
        get_root(to[i], u, total), siz[u] += siz[to[i]];
        maxp[u] = max(maxp[u], siz[to[i]]);
    }
    maxp[u] = max(maxp[u], total - siz[u]);
    if (maxp[u] < maxp[root]) root = u;
}

pii a[N]; int len;
void dfs(int u, int fa, int mi, int ma) {
    if (fa) a[++len] = {mi, ma};
    Eor(u) if (to[i] != fa && !vis[to[i]]) 
        dfs(to[i], u, min(mi, w[i]), max(ma, w[i]));
}

int t[N << 1];
void modify(int x, int y) { for (; x <= 2 * n; x += x & -x) t[x] += y; }
int ask(int x, int y = 0) { for (; x; x -= x & -x) y += t[x]; return y; }

void calc(int u) {
    len = 0, dfs(u, 0, 1e9, -1e9), sort(a + 1, a + len + 1);

    For(i, 1, len) if (a[i].second - a[i].first == k) ++ans;

    for (int r = len; r >= 1; --r) {
        if (a[r].first + k >= a[r].second) ans += ask(a[r].first + k);
        if (a[r].first + k > a[r].second) ans -= ask(a[r].first + k - 1); 
        modify(a[r].second, 1);
    } 
    For(j, 1, len) modify(a[j].second, -1);

    Eor(u) if (!vis[to[i]]) {
        len = 0, dfs(to[i], u, w[i], w[i]), sort(a + 1, a + len + 1);
        for (int r = len; r >= 1; --r) {
            if (a[r].first + k >= a[r].second) ans -= ask(a[r].first + k);
            if (a[r].first + k > a[r].second) ans += ask(a[r].first + k - 1); 
            modify(a[r].second, 1);
        } 
        For(j, 1, len) modify(a[j].second, -1);
    }  
}
void solve(int u, int dep) {
    vis[u] = 1, get_root(u, 0, n), calc(u); Eor(u) if (!vis[to[i]]) 
    root = 0, get_root(to[i], u, siz[to[i]]), solve(to[i], dep + 1);
}
signed main() {
	freopen("minmax.in", "r", stdin);
	freopen("minmax.out", "w", stdout);
    n = read(), k = read();
    For(i, 2, n) Add(read(), read());
    maxp[0] = n + 1, root = 0, get_root(1, 0, n);
    solve(root, 1), cout << ans;
	return 0;
}

