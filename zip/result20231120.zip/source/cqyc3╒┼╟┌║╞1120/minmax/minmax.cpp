#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=5e3+7,inf=1e9;
int n,K;
ll ans;
vector<pair<int,int> >e[Maxn];

int dis[Maxn][Maxn];
void DFS(int u,int ft,int mxw,int mnw,int p){
	if(mxw-mnw==K) ans++;
	for(auto i:e[u]){
		int v=i.first,w=i.second;
		if(v==ft||v<u) continue;
		DFS(v,u,max(mxw,w),min(mnw,w),p);
	}
}

int main(){
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	
	scanf("%d%d",&n,&K);
	for(int i=1;i<n;i++){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		e[u].emplace_back(v,w);
		e[v].emplace_back(u,w);
	}
	
	for(int i=1;i<=n;i++){
		DFS(i,0,0,inf,i);
	}
	
	printf("%lld",ans);
	return 0;
}

/*
5 2
2 1 1
3 1 4
4 3 5
5 4 3
*/

