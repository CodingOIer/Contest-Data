#include <bits/stdc++.h>
#define ll long long
using namespace std;

int T,n;

const int Maxn=1510;
struct node{
	int x,y;
	char ch;
}a[Maxn],b[Maxn];


int main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d%d",&a[i].x,&a[i].y);
			cin>>a[i].ch;
		}
		for(int i=1;i<=n;i++){
			scanf("%d%d",&b[i].x,&b[i].y);
			cin>>b[i].ch;
		}
		if(n==1){
			if(a[1].ch==b[1].ch) printf("No");
			else{
				if(a[1].ch=='('){
					if(a[1].x>b[1].x&&a[1].y>b[1].y) printf("No");
					else if(a[1].x==b[1].x&&a[1].y>b[1].y) printf("No");
					else if(a[1].y==b[1].y&&a[1].x>b[1].x) printf("No");
					else printf("Yes");
				}
				else{
					if(a[1].x<b[1].x&&a[1].y<b[1].y) printf("No");
					else if(a[1].x==b[1].x&&a[1].y<b[1].y) printf("No");
					else if(a[1].y==b[1].y&&a[1].x<b[1].x) printf("No");
					else printf("Yes");
				}
			}
		}
		
		puts("");
	}
	return 0;
}



