#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k,ans;

const ll Mod=998244353,Maxn=1e5+7;
inline ll ksm(ll a,ll b,ll mod){
	ll z=1;
	while(b){
		if(b&1) z=z*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return z;
} 
inline ll up(ll x){
	return (x%Mod+Mod)%Mod;
}
inline ll Num(ll n,ll k){
	return ksm(k,(n+1)/2,Mod);
}

ll a[129303],cnt,ggg[Maxn],sa;

unordered_map<string,ll >ss; 

void DFS(ll p){
	if(p>n+1)	return ;
	bool gp=0,tp=0;
		string dd;
		bool flg=0;
		for(ll i=1;i<=cnt;i++) dd+=('a'+a[i]);
		string d=dd;
		reverse(d.begin(),d.end());
		if(d==dd){
			ans+=(!ss[d]);
			//if(!ss[d])cout<<d<<endl,gp=1;
			ss[d]=1;
			
		}
		ll kk=0;
		for(ll i=2;i<=cnt;i++){
			string s,t;
			for(ll j=1;j<i;j++){
				s+=('a'+a[j]);
			}
			for(ll j=i;j<=cnt;j++){
				t+=('a'+a[j]);
			}
			string s1=s,t1=t;
			reverse(s.begin(),s.end());
			reverse(t.begin(),t.end());
			//if(dd=="ab") cout<<"fck  "<<s1<<" "<<t1<<endl;
			if(t==t1&&s==s1){
				kk++;
				ans+=(!ss[dd]);
				tp=1;
				//if(!ss[dd])
				ggg[cnt]++;
//				if(cnt==4) {
//					cout<<"fuck "<<dd<<endl;
//				}
				//if(gp&&tp) cout<<"nani123"<<" "<<dd<<endl;
				//if(!ss[dd]) cout<<dd<<endl;
				ss[dd]=1;
				
				
			}
			
		}
		sa=max(sa,kk); 
		
	if(tp&&gp){
		
	}
		
	for(ll i=0;i<k;i++){
		a[++cnt]=i;
		DFS(p+1);
		--cnt;
	}
}


int main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	cin>>n>>k;
	
	DFS(1);
//	for(ll i=1;i<=n;i++) ans+=Num(i,k);
	cout<<(ans-1)%Mod<<endl;
	return 0;
}



