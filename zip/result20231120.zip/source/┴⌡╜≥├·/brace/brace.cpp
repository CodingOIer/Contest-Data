#include<bits/stdc++.h>
#define int long long
#define N 1600
using namespace std;
int T, n;
int a[N], b[N], c[N]; //0:( 1:) 
struct node{
	int a, b, c; 
}p[N];
int X, Y;
bool cmp(node x, node y) {
	if(x.a * X + x.b * Y != y.a * X + y.b * Y) return x.a * X + x.b * Y < y.a * X + y.b * Y;
	else return x.c < y.c;
}
int S[N]; 
signed main() {
    freopen("brace.in", "r", stdin);
	freopen("brace.out", "w", stdout);
    cin >> T;
    int z = 0;
    while(T--) {
    	cin >> n;
    	z += n;
    	for(int i = 1; i <= 2 * n; i++) {
    		cin >> a[i] >> b[i];
    		char s;
    		cin >> s;
    		if(s == '(') c[i] = 0;
    		else c[i] = 1;
    		p[i].a = a[i];
    		p[i].b = b[i];
    		p[i].c = c[i];
		}
		if(n == 1) {
			if(a[1] == a[2] && b[1] == b[2]) {
				cout << "YES" << endl;
			}
			else if(a[1] >= a[2] && b[1] >= b[2]) {
				if(c[1] == 0) cout << "NO" << endl;
				else cout << "YES" << endl;
			}
			else if(a[1] <= a[2] && b[1] <= b[2]) {
				if(c[1] == 0) cout << "YES" << endl;
				else cout << "NO" << endl;
			}
			else {
				cout << "YES" << endl;
			}
		}
		else {
	    bool ans = 0;
		for(X = 1; X <= 150; X++)
		for(Y = 1; Y <= 150; Y++) {
			sort(p + 1, p + 2 * n + 1, cmp);
			int h = 0;
			bool flag = 1;
			/*int top = 0;
			for(int i = 1; i <= n; i++) {
				if(p[i].c == 1) {
					if(top > 0 && S[top] == 0) {
						top--;
					}
				}
				S[++top] = p[i].c;
			}*/
			for(int i = 1; i <= 2 * n; i++) {
				if(p[i].c == 0) h++;
				else {
					h--;
					if(h < 0) {
						flag = 0;
						break;
					}
				}
			}
			if(flag) {
				ans = 1;
				goto end;
			}
			/*if(top == 0) {
				ans = 1;
				goto end;
			}*/
		}	
		end:; 
		if(ans) {
			cout << "YES" << endl;
		}
		else cout << "NO" << endl;
		}
	}
	return 0;
}

