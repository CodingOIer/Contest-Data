#include<bits/stdc++.h>
#define int long long
#define N 100005
#define mod 998244353 
using namespace std;
int n, k;
int p[N];
int f[N], g[N], ans;
int ask1(int x) {
	return x / 2 + 1;
}
int ask2(int x) {
	return x - x / 2;
}
signed main() {
	freopen("palindrome.in", "r", stdin);
	freopen("palindrome.out", "w", stdout);
	scanf("%lld %lld", &n, &k);
	p[0] = 1;
	for(int i = 1; i <= n; i++) p[i] = p[i - 1] * k % mod;
	for(int i = 1; i <= n; i++) {
		if(i % 2 == 0) {
			f[i] = ask2(i - 1) * p[i / 2 + 1] % mod;
			f[i] = (f[i] + ask1(i - 1) * p[i / 2] % mod) % mod;
		} 
		else {
			f[i] = ask1(i - 1) * p[(i + 1) / 2] % mod;
			f[i] = (f[i] + ask2(i - 1) * p[(i + 1) / 2] % mod) % mod;
		}
		g[i] += f[i];
		for(int j = 2 * i; j <= n; j += i) {
			g[j] = (g[j] - g[i] * (j / i) % mod) % mod;
		}
    }
    for(int i = 1; i <= n; i++) {
    	ans = (ans + g[i]) % mod;
		for(int j = 2 * i; j <= n; j += i) {
			ans = (ans + g[i]) % mod;
		}
	}
	cout << ans;
	return 0;
}

