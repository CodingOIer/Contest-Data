#include<bits/stdc++.h>
#define int long long
#define N 300005 
using namespace std;
int n, k;
int U[N], V[N], W[N];
struct edge{
	int to, w;
};
vector<edge>p[N];
int Max[N], Min[N], ans;
void dfs(int x, int fa, int Len) {
	if(fa != 0) Max[x] = max(Max[fa], Len);
	else Max[x] = 0;
	if(fa != 0) Min[x] = min(Min[fa], Len);
	else Min[x] = 1e18;
	if(Max[x] - Min[x] == k) ans++;
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i].to;
		if(y == fa) continue;
		dfs(y, x, p[x][i].w);
	}
}
void Subtask1() {
	ans = 0;
	for(int i = 1; i <= n; i++) {
		dfs(i, 0, 0); 
	} 
	printf("%lld ", ans / 2);
}
int f[N];
void Subtask2() {
	ans = 0;
	int Main = 0;
	for(int i = 1; i <= n; i++) {
		if(p[i].size() == n - 1) {
			Main = i;
			break;
		}
	}
	for(int i = 0; i < p[Main].size(); i++) f[p[Main][i].w]++;
	for(int i = 1; i <= n; i++) {
		if(i == Main) continue;
		if(p[i][0].w + k <= n) ans += f[p[i][0].w + k];
		if(p[i][0].w >= k) ans += f[p[i][0].w - k];
	}
	printf("%lld", ans / 2);
}
signed main() {
	freopen("minmax.in", "r", stdin);
	freopen("minmax.out", "w", stdout);
    scanf("%lld %lld", &n, &k);
    for(int i = 1; i < n; i++) {
    	scanf("%lld %lld %lld", &U[i], &V[i], &W[i]);
    	p[U[i]].push_back((edge){V[i], W[i]});
    	p[V[i]].push_back((edge){U[i], W[i]});
	}
	//Subtask1();
	//Subtask2();
	if(n <= 5000) Subtask1(); //O(n^2) 
	else if(n == 99998) Subtask2(); //�ջ�ͼ 
	return 0;
}

