#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1502;
struct pt{
	int x,y,a,b,op;
}k[N*N];
int T,n,a[N*2],b[N*2],id[N*2],ip[N*N],tot;
char c[N];int px,py,ps[N*2],cnt[N],yu[N];
bool cmp(pt x,pt y){
	ll p=1ll*x.a*y.b,q=1ll*y.a*x.b;
	if(p!=q)return p<q;
	if(x.op!=y.op)return x.op>y.op;
	return x.x>y.x;
}int minn[N<<2],tg[N<<2];
void pd(int id){
	minn[id<<1]+=tg[id];
	minn[id<<1|1]+=tg[id];
	tg[id<<1]+=tg[id];
	tg[id<<1|1]+=tg[id];tg[id]=0;
	return;
}void build(int id,int l,int r){
	tg[id]=0;
	minn[id]=-r;
	if(l==r)return;
	int mid=(l+r)>>1;
	build(id<<1,l,mid);
	build(id<<1|1,mid+1,r);
	return;
}void add(int id,int l,int r,int ql,int qr,int vl){
	if(qr<ql)return;
	if(ql<=l&&r<=qr){
		tg[id]+=vl;
		minn[id]+=vl;
		return;
	}int mid=(l+r)>>1;pd(id);
	if(ql<=mid)add(id<<1,l,mid,ql,qr,vl);
	if(qr>mid)add(id<<1|1,mid+1,r,ql,qr,vl);
	minn[id]=min(minn[id<<1],minn[id<<1|1]);return;
}signed main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cin>>T;
	while(T--){
		cin>>n;px=py=1;
		for(int i=1;i<=2*n;i++){
			cin>>a[i]>>b[i]>>c[i];
			cnt[i]=1;
		}for(int i=1;i<=2*n;i++)
			if(c[i]=='('){
				id[i]=px++;
				ps[id[i]]=i;
			}else{
				id[i]=py++;
				ps[id[i]+n]=i;
			}
		tot=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				k[++tot].x=i;
				ip[tot]=tot;
				k[tot].y=j;
				int g=ps[j+n],h=ps[i];
				if(a[g]<a[h]){
					if(b[g]<=b[h]){
						k[tot].a=1e9;
						k[tot].b=1;
						k[tot].op=1;
					}else{
						k[tot].a=b[g]-b[h];
						k[tot].b=a[h]-a[g];
						k[tot].op=0;
					}
				}else if(a[g]>a[h]){
					k[tot].a=b[h]-b[g];
					k[tot].b=a[g]-a[h];
					k[tot].op=1;
					if(k[tot].a<=0){
						k[tot].a=1e9;
						k[tot].b=1;
						k[tot].op=0;
					}
				}else{
					if(b[g]>=b[h]){
						k[tot].a=1e9;
						k[tot].b=1;
						k[tot].op=0;
					}else{
						k[tot].a=1e9;
						k[tot].b=1;
						k[tot].op=1;
					}
				}if(k[tot].op)cnt[i]++;
			}
		sort(k+1,k+tot+1,cmp);
		bool fl=0;k[0].x=0;
		build(1,1,n);
		for(int i=1;i<=n;i++)
			add(1,1,n,cnt[i],n,1);
		for(int i=0;i<=tot+1;i++)
			if(k[i].a>=1e7)
				break;
			else{
				if(k[i].x)add(1,1,n,cnt[k[i].x],n,-1);
				if(k[i].op)cnt[k[i].x]--;
				else cnt[k[i].x]++;
				if(k[i].x)add(1,1,n,cnt[k[i].x],n,1);
				if(minn[1]>=0)fl=1;
			}
		if(fl){
			cout<<"YES\n";
		}else cout<<"NO\n";
	}return 0;
}
