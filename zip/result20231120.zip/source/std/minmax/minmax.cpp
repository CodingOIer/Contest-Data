#include<stdio.h>
#include<vector>
#include<algorithm>
using namespace std;
#define ll long long
const int N=200005;

struct EDGE{
	int v,w;
};

struct node{
	int mn,mx;
	
	bool operator<(node x)const{
		return mx<x.mx;
	}
};

int n,k;
ll tr[N],ans;
int rt,mn,tot,cnt,sz[N];
vector<EDGE> g[N];
bool vis[N];
node ds[N];

inline void add(int x,ll y){
	for(;x<=n;x+=(x&-x))
	tr[x]+=y;
}

inline ll qry(int x,ll y=0){
	for(;x>0;x-=(x&-x))
	y+=tr[x];return y;
}

void getrt(int x,int fa){
	sz[x]=1;
	int res=0;
	
	for(EDGE e:g[x])
	if((!vis[e.v])&&e.v!=fa){
		getrt(e.v,x);
		res=max(res,sz[e.v]);
		sz[x]+=sz[e.v];
	}res=max(res,tot-sz[x]);
	
	if(res<mn){
		mn=res;
		rt=x;
	}
}

void getds(int x,int fa,int mn,int mx){
	sz[x]=1;
	ds[++cnt]=(node)<%mn,mx%>;
	
	for(EDGE e:g[x])
	if((!vis[e.v])&&e.v!=fa){
		getds(e.v,x,min(mn,e.w),max(mx,e.w));
		sz[x]+=sz[e.v];
	}
}

ll calc(int x,int mn,int mx){
	cnt=0;
	getds(x,0,mn,mx);
	sort(ds+1,ds+cnt+1);
	register int i,j;
	ll res=0;
	
	for(i=1;i<=cnt;i++){
		if(ds[i].mx>k){
			if(ds[i].mx-ds[i].mn<k)
			res+=qry(ds[i].mx-k)-qry(ds[i].mx-k-1);
			else if(ds[i].mx-ds[i].mn==k){
				res+=qry(n);
				res-=qry(ds[i].mn-1);
			}
		}
		
		add(ds[i].mn,1);
	}for(i=1;i<=cnt;i++) add(ds[i].mn,-1);
	
	return res;
}

void dfs(int x){
	vis[x]=true;
	ans+=calc(x,n,-n);
	
	for(EDGE e:g[x]) if(!vis[e.v]){
		ans-=calc(e.v,e.w,e.w);
		mn=tot+1;
		rt=e.v;
		tot=sz[e.v];
		getrt(e.v,x);
		dfs(rt);
	}
}

signed main(){
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	
	scanf("%d%d",&n,&k);
	register int i,u,v,w;
	
	for(i=1;i<n;i++){
		scanf("%d%d%d",&u,&v,&w);
		g[u].push_back((EDGE)<%v,w%>);
		g[v].push_back((EDGE)<%u,w%>);
	}
	
	mn=n+1;
	tot=n;
	rt=1;
	getrt(1,0);
	dfs(rt);
	
	printf("%lld\n",ans);
	return 0;
}