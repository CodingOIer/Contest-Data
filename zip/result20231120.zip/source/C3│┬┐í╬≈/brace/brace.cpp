#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=25;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int T,n,a1,a2,b1,b2;
char c1,c2;
signed main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		if(n==1){
			a1=read(),b1=read();
			cin>>c1;
			a2=read(),b2=read();
			cin>>c2;
			if(c1==')') swap(a1,a2),swap(b1,b2),swap(c1,c2);
			if(a1<a2||b1<b2||(a1==a2&&b1==b2)) printf("YES\n");	
			else printf("NO\n");
		}

	}
	return 0;
}
