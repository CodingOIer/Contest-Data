#include<bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
#define mid (l+r>>1)
using namespace std;
const int N=2e5+5,inf=1e12;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,k,ans;
int head[N],nxt[N<<1],to[N<<1],val[N<<1],tot;
void add(int u,int v,int w){to[++tot]=v,nxt[tot]=head[u],head[u]=tot,val[tot]=w;}
bool vis[N];
void dfs(int u,int f,int minn,int maxn){
	ans=ans+((maxn-minn==k)&(!vis[u]));
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i],w=val[i];
		if(v==f) continue;
		dfs(v,u,min(minn,w),max(maxn,w));
	}
}
signed main(){
	freopen("minmax.in","r",stdin);
	freopen("minmax.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w=read();
		add(u,v,w);
		add(v,u,w);
	}
	for(int i=1;i<=n;i++) vis[i]=1,dfs(i,i,inf,-inf);
	printf("%lld",ans);
	return 0;
}
