#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=25,mod=998244353;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int ans,n,k,lim,a[N];
bool check(int l,int r){
	if(l>=r) return 1;
	for(int i=l;i<=r;i++)
		if(a[r-(i-l)]!=a[i]) return 0;
	return 1;
}
void dfs(int pos){
	if(pos==lim+1){
		for(int i=0;i<lim;i++){
			if(check(1,i)&&check(i+1,lim)){
				ans++;
				break;
			} 
		}
		return;	
	}
	for(int i=1;i<=k;i++) a[pos]=i,dfs(pos+1);
}
signed main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++) lim=i,dfs(1);
	printf("%lld",ans%mod);
	return 0;
}
