#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define int long long
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
namespace Subtask1 {

const int N = 2e5 + 5, M = 4e5 + 5;

namespace G {

array <int, N> fir;
array <int, M> nex, to, len;
int cnt;
void add(int x, int y, int z) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	len[cnt] = z;
	fir[x] = cnt;
}

}

int ans;
void dfs(int x, int fa, int k, int tp1, int tp2) {
	using G::nex; using G::to; using G::len; using G::fir;
	if (tp2 - tp1 == k) ans++;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa) continue;
		dfs(to[i], x, k, min(tp1, len[i]), max(tp2, len[i]));
	}
}
void main(int n, int k) {
	for (int i = 2; i <= n; i++) {
		int x = read(), y = read(), z = read();
		G::add(x, y, z), G::add(y, x, z);
	}
	for (int i = 1; i <= n; i++)
		dfs(i, 0, k, n + 114, 0);
	write(ans / 2), puts("");
	return;
}

}

namespace Subtask2 {

const int N = 2e5 + 5, M = 4e5 + 5;

namespace G {

array <int, N> fir;
array <int, M> nex, to, len;
int cnt;
void add(int x, int y, int z) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	len[cnt] = z;
	fir[x] = cnt;
}

}

array <int, N> deg, dfn, dis;

int cnt;
void dfs(int x, int fa) {
	using G::nex; using G::to; using G::len; using G::fir;
	cnt++;
	dfn[x] = cnt;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa) continue;
		dis[x] = len[i];
		dfs(to[i], x);
	}
}

void main(int n, int k) {
	for (int i = 2; i <= n; i++) {
		int x = read(), y = read(), z = read();
		G::add(x, y, z), G::add(y, x, z);
		deg[x]++, deg[y]++;
	}
	int rt = 0;
	for (int i = 1; i <= n; i++) {
		if (deg[i] == 1) {
			rt = i;
			break;
		}
	}
	dfs(rt, 0);
	return;
}

}

signed main() {
	freopen("minmax.in", "r", stdin);
	freopen("minmax.out", "w", stdout);
	int n = read(), k = read();
	if (n <= 5000) Subtask1::main(n, k);
	else Subtask2::main(n, k);
}
