#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=1500+7;
const double eps=1e-6;
int T;
int n;
int bel[maxn],sum[maxn],vo[maxn],nv[maxn];
int cnt;
bool ans;
struct node_rd{
    int a,b;
    char c;
}in[maxn];
struct node_l{
    double k,b;
    int va;
}p[maxn];
struct node{
    int u,v;
    double x,y;
}ve[maxn*maxn];
struct SEGTREE{
    #define ls(x) (x<<1)
    #define rs(x) (x<<1|1)
    struct node{
        int l,r;
        int tag,mi;
    }t[maxn<<2];
    void pushup(int x){
        t[x].mi=min(t[ls(x)].mi,t[rs(x)].mi);
        return ;
    }
    void update(int x,int v){
        // printf("x= %d ,v=%d\n",x,v);
        t[x].mi+=v,t[x].tag+=v;
        return ;
    }
    void pushdown(int x){
        update(ls(x),t[x].tag);
        update(rs(x),t[x].tag);
        t[x].tag=0;
    }
    void build(int x,int l,int r){
        t[x].l=l,t[x].r=r;
        t[x].tag=0;
        if(l==r){t[x].mi=sum[l];return ;}
        int mid=(l+r)>>1;
        build(ls(x),l,mid);
        build(rs(x),mid+1,r);
        pushup(x);
    }
    void modify(int x,int l,int r,int v){
        // printf("modi %d (%d %d) (%d %d)%d\n",x,t[x].l,t[x].r,l,r,v);
        if(l>r)return ;
        if(t[x].l==l&&t[x].r==r){
            update(x,v);
            return ;
        }
        pushdown(x);
        int mid=(t[x].l+t[x].r)>>1;
        if(l>mid)modify(rs(x),l,r,v);
        else if(r<=mid)modify(ls(x),l,r,v);
        else {
            modify(ls(x),l,mid,v);
            modify(rs(x),mid+1,r,v);
        }
        pushup(x);
    }
}segt;
bool cmp(node_l A,node_l B){
    return (A.b!=B.b)?(A.b<B.b):A.va>B.va;
}
bool cmp2(node A,node B){
    return A.x<B.x;
}
bool cmp3(node A,node B){
    return A.y<B.y;
}
void check(int a,int b){
    if(p[a].k<=p[b].k)return ;
    double x=(p[b].b-p[a].b)/(p[a].k-p[b].k);
    ve[++cnt]=(node){a,b,x,p[a].k*x+p[a].b};
    return ;
}
bool vis[maxn];
vector<int>now;
void rec(int l,int r){
    if(l>r)return ;
    for(int i=l;i<=r;i++){
        if(!vis[bel[ve[i].u]])now.push_back(bel[ve[i].u]),vis[bel[ve[i].u]]=1;
        if(!vis[bel[ve[i].v]])now.push_back(bel[ve[i].v]),vis[bel[ve[i].v]]=1;
    }
    int num=0;
    for(int i=0;i<now.size();i++)num+=(vo[now[i]]==1);
    sort(now.begin(),now.end());
    for(int i=0;i<now.size();i++){
        if(num)nv[now[i]]=1,num--;
        else nv[now[i]]=-1;
        // if(bel[now[i]]==0)printf("ka1 %d\n",now[i]);
        segt.modify(1,now[i],n,nv[now[i]]-vo[now[i]]);
    }
    int siz=now.size();
    while(siz)vis[now[siz-1]]=0,siz--,now.pop_back();
    return ;
}
void rpi(int l,int r){
    if(l>r)return ;
    for(int i=l;i<=r;i++){
        if(!vis[bel[ve[i].u]])now.push_back(bel[ve[i].u]),vis[bel[ve[i].u]]=1;
        if(!vis[bel[ve[i].v]])now.push_back(bel[ve[i].v]),vis[bel[ve[i].v]]=1;
    }
    for(int i=0;i<now.size();i++){
        // if(bel[now[i]]==0)printf("ka1\n");
        segt.modify(1,now[i],n,vo[now[i]]-nv[now[i]]);
    }
    int siz=now.size();
    while(siz)vis[now[siz-1]]=0,siz--,now.pop_back();
    return ;
}
void calc(int l,int r){
    if(l>r)return ;
    sort(ve+l,ve+r+1,cmp3);
    int las=1;
    for(int i=l;i<=r;i++){
        if(i>l&&ve[i].y!=ve[i-1].y)rec(las,i-1),las=i;
        if(i==l)las=i;
    }
    // if(l==32)printf("ka %d %d %d %d %d %d %d\n",las,r,segt.t[1].mi,bel[ve[l].u],bel[ve[l].v],vo[bel[ve[l].u]],vo[bel[ve[l].v]]);
    rec(las,r);
    // if(l==32)printf("do %d %d %d\n",las,r,segt.t[1].mi);
    if(ve[l].x>0)ans|=(segt.t[1].mi==0);
    las=1;
    for(int i=l;i<=r;i++){
        if(i>l&&ve[i].y!=ve[i-1].y)rpi(las,i-1),las=i;
        if(i==l)las=i;
    }
    rpi(las,r);
    for(int i=l;i<=r;i++){
        if(bel[ve[i].u]>bel[ve[i].v])swap(ve[i].u,ve[i].v);
        segt.modify(1,bel[ve[i].u],bel[ve[i].v]-1,vo[bel[ve[i].v]]-vo[bel[ve[i].u]]);
        swap(vo[bel[ve[i].u]],vo[bel[ve[i].v]]);
        swap(bel[ve[i].u],bel[ve[i].v]);
    }
    ans|=(segt.t[1].mi==0);
    // if(ans)printf("X=%.3lf %d %d\n",ve[l].x,l,r);
    return ;
}
int main(){
    freopen("brace.in","r",stdin);
    freopen("brace.out","w",stdout);
    T=read();
    int num=0;
    while(T--){
        ans=0,cnt=0;
        n=read()*2;
        for(int i=1;i<=n;i++){
            in[i].a=read(),in[i].b=read(),in[i].c=getchar();
            while(in[i].c!='('&&in[i].c!=')')in[i].c=getchar();
            p[i]=(node_l){(double)in[i].a,(double)in[i].b,(in[i].c=='(')?1:(-1)};
        }
        sort(p+1,p+n+1,cmp);
        for(int i=1;i<=n;i++)bel[i]=i,sum[i]=sum[i-1]+(vo[i]=p[i].va);
        num++;
        // if(num==83){
        //     cout<<n/2<<'\n';
        //     for(int i=1;i<=n;i++)cout<<in[i].a<<' '<<in[i].b<<' '<<in[i].c<<'\n';
        // }
        // for(int i=1;i<=n;i++)printf("p[%d]=%.3lf %.3lf %d\n",i,p[i].k,p[i].b,p[i].va);
        segt.build(1,1,n);
        for(int i=1;i<=n;i++){
            for(int j=i+1;j<=n;j++){
                check(i,j);
            }
        }
        sort(ve+1,ve+cnt+1,cmp2);
        // for(int i=1;i<=cnt;i++)printf("ve[%d]=%d %d %.3lf %.3lf\n",i,ve[i].u,ve[i].u,ve[i].x,ve[i].y);
        int las=1;
        // printf("%.3lf\n",ve[cnt].x);
        if(!cnt||ve[1].x>0)ans|=(segt.t[1].mi==0);
        
        // printf("boom %d\n",ans);
        for(int i=1;i<=cnt;i++){
            // printf("ve[%d]={%d %d %.3lf %.3lf}\n",i,ve[i].u,ve[i].v,ve[i].x,ve[i].y);
            if(i>1&&ve[i].x!=ve[i-1].x)calc(las,i-1),las=i;
            if(i==1)las=i;
        }
        calc(las,cnt);
        puts((ans)?"YES":"NO");
    }
    return 0;
}