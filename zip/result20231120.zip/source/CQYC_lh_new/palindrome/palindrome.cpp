#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=1e5+2;
const int mod=998244353;
int n,m;
int pw[maxn],f[maxn],g[maxn],mu[maxn];
int pcnt,pri[maxn];
bool pvis[maxn];
int ans;
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void Euler(){
    mu[1]=1;
    for(int i=2;i<maxn;i++){
        if(!pvis[i])pri[++pcnt]=i,mu[i]=mod-1;
        for(int j=1;j<=pcnt&&i*pri[j]<maxn;j++){
            pvis[i*pri[j]]=1;
            if(i%pri[j]==0){mu[i*pri[j]]=0;break;}
            else mu[i*pri[j]]=mod-mu[i];
        }
    }
    return ;
}
void pre(){
    Euler();
    pw[0]=1;
    for(int i=1;i<=n;i++){
        pw[i]=1ll*pw[i-1]*m%mod;
        if(i&1)f[i]=1ll*i*pw[i/2+1]%mod;
        else f[i]=1ll*(i/2)*((pw[i/2]+pw[i/2+1])%mod)%mod;
    }
    for(int i=1;i<=n;i++){
        for(int j=i;j<=n;j+=i){
            upd(g[j],1ll*f[i]*mu[j/i]%mod*(j/i)%mod);
        }
    }
    return ;
}
int main(){
    freopen("palindrome.in","r",stdin);
    freopen("palindrome.out","w",stdout);
    n=read(),m=read();
    pre();
    for(int i=1;i<=n;i++)upd(ans,1ll*g[i]*(n/i)%mod);
    printf("%d\n",ans);
    return 0;
}