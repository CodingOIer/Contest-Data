#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2,inf=1e9;
int n,K;
int siz[maxn],maxson[maxn];
bool vis[maxn];
long long ans;
struct node{
    int mi,mx;
    node operator + (const node &A)const{
        return (node){min(mi,A.mi),max(mx,A.mx)};
    }
};
struct node_v{
    node d;
    int id;
};
bool cmp(node_v A,node_v B){
    return (A.d.mx!=B.d.mx)?(A.d.mx<B.d.mx):(A.id<B.id);
}
vector<node_v>now;
struct node_edge{
    int to,val;
};
vector<node_edge>G[maxn];
void add(int u,int v,int w){
    G[u].push_back((node_edge){v,w});
}
struct BIT{
    int t[maxn];
    int lowbit(int x){return x&-x;}
    void modify(int x,int v){
        if(!x)return ;
        for(int i=x;i<=n;i+=lowbit(i))t[i]+=v;
    }
    int query(int x){
        if(!x)return 0;
        // printf("que of %d\n",x);
        int ret=0;for(int i=x;i;i-=lowbit(i))ret+=t[i];return ret;
    }
}bit;
int find_root(int x,int f,int rt,int all){
    siz[x]=1,maxson[x]=0;
    for(int i=0,v;i<G[x].size();i++){
        v=G[x][i].to;
        if(v==f||vis[v])continue;
        rt=find_root(v,x,rt,all);
        siz[x]+=siz[v];
        maxson[x]=max(maxson[x],siz[x]);
    }
    maxson[x]=max(maxson[x],all-siz[x]);
    if(!rt||maxson[rt]>maxson[x])rt=x;
    return rt;
}
void dfs(int x,int f,node fv){
    now.push_back((node_v){fv,x});
    for(int i=0,v;i<G[x].size();i++){
        v=G[x][i].to;
        if(v==f||vis[v])continue;
        dfs(v,x,fv+(node){G[x][i].val,G[x][i].val});
    }
    return ;
}
void calc(bool ty){
    sort(now.begin(),now.end(),cmp);
    for(int i=0;i<now.size();i++){
        if(now[i].d.mx-K>0){
            if(now[i].d.mi==now[i].d.mx-K)ans+=1ll*((!ty)?1:-1)*(bit.query(n)-bit.query(now[i].d.mi-1));
            else if(now[i].d.mi>now[i].d.mx-K)ans+=1ll*((!ty)?1:-1)*(bit.query(now[i].d.mx-K)-bit.query(now[i].d.mx-K-1));
        }
        bit.modify(now[i].d.mi,1);
    }
    int siz=now.size();
    while(siz)bit.modify(now[siz-1].d.mi,-1),siz--,now.pop_back();
    return ;
}
void solve(int x,int all){
    int pas=ans;
    dfs(x,0,(node){n,0});
    calc(0);
    // printf("pas %d %d %d\n",x,ans-pas,bit.query(n));
    for(int i=0,v;i<G[x].size();i++){
        v=G[x][i].to;
        if(vis[v])continue;
        dfs(v,x,(node){G[x][i].val,G[x][i].val});
        calc(1);
    }
    // printf("solve %d %d\n",x,ans-pas);
    vis[x]=1;
    for(int i=0,v,nrt,nall;i<G[x].size();i++){
        v=G[x][i].to;
        if(vis[v])continue;
        nall=((siz[v]>=siz[x])?(all-siz[x]):siz[v]);
        nrt=find_root(v,x,0,nall);
        solve(nrt,nall);
    }
    return ;
}
int main(){
    freopen("minmax.in","r",stdin);
    freopen("minmax.out","w",stdout);
    n=read(),K=read();
    for(int i=1,u,v,w;i<n;i++){
        u=read(),v=read(),w=read();
        add(u,v,w);
        add(v,u,w);
    }
    int rt=find_root(1,0,0,n);
    solve(rt,n);
    printf("%lld\n",ans);
    return 0;
}