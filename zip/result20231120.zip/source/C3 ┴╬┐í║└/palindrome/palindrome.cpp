#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
inline int Mod(int x){if(x>=mod)x-=mod;return x;}
inline int poww(int x,int y){
	int sum=1;
	while(y){
		if(y&1)sum=1ll*sum*x%mod;
		x=1ll*x*x%mod;
		y>>=1; 
	}
	return sum;
}
int p[100005],tot;
int vis[100005];
int phi[100005];
void Init(int n){
	phi[1]=1;
	for(int i=2;i<=n;i++){
		if(vis[i]==0){
			p[++tot]=i;
			vis[i]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=tot;j++){
			if(i*p[j]>n)break;
			vis[i*p[j]]=p[j];
			if(vis[i]==p[j]){
				phi[i*p[j]]=phi[i]*p[j];
				break;
			}
			phi[i*p[j]]=phi[i]*(p[j]-1);
		}
	}
}
int n,m,ans;
int f[100005];
signed main(){
	freopen("palindrome.in","r",stdin);
	freopen("palindrome.out","w",stdout);
	Init(1e5);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		f[i]=Mod(1ll*((i+1)/2)*poww(m,(i+2)/2)%mod+1ll*(i/2)*poww(m,(i+1)/2)%mod);
	for(int i=1;i<=n;i++)
		for(int j=2;j*i<=n;j++)
			f[i*j]=Mod(f[i*j]+mod-1ll*f[i]*phi[j]%mod);
	for(int i=1;i<=n;i++)ans=Mod(ans+f[i]);
	cout<<ans;
	return 0;
}
