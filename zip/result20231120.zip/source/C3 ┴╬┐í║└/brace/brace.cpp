#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,T,TT;
int x,y;
struct node{
	int a,b,ops;
}p[3005];
bool cmp(node A,node B){if(1ll*A.a*x+1ll*A.b*y==1ll*B.a*x+B.b*y)return A.ops>B.ops;return 1ll*A.a*x+1ll*A.b*y<1ll*B.a*x+B.b*y;}
signed main(){
	freopen("brace.in","r",stdin);
	freopen("brace.out","w",stdout);
	read(T);TT=T;
	while(T--){
		read(n);
		for(int i=1;i<=2*n;i++){
			read(p[i].a,p[i].b);
			if(getch()=='(')p[i].ops=1;
			else p[i].ops=-1;
		}
		int S=sqrt(10000000/min(TT*n,1500));
//		int S=100;
		int ops=0;
//		cout<<T<<":"<<endl;
		x=1;
		while(x<=S){
			y=1;
			while(y<=S){
//				cout<<x<<" "<<y<<"/"<<S<<endl;
				sort(p+1,p+2*n+1,cmp);
				int sum=0;
				for(int i=1;i<=2*n;i++){
//					cout<<i<<' ';
					sum+=p[i].ops;
					if(sum<0)break; 
				}
				if(sum==0)ops=1;
				if(ops==1)break;
				y++;
			}
			if(ops==1)break;
			x++;
		}
//		cout<<T<<":"<<endl;
		if(ops)printf("YES\n");
		else printf("NO\n");
	}
//	flush();
	return 0;
}
