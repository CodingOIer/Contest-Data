#include <bits/stdc++.h>
#define int long long
#define ls (lr << 1)
#define rs (lr << 1 | 1)
#define mid ((l + r) >> 1)
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 3010;

struct node {
    int x, y, c, id;
    bool operator < (const node &p) const { return x == p.x ? (y == p.y ? c > p.c : y < p.y) : x < p.x; }
} a[N];

int n, m;
int p[N];

struct tree {
    int s, x;
    tree operator + (const tree &p) const { return { s + p.s, min(x, p.x + s) }; }
} t[N << 2];

struct oper {
    int x, y, a, b;
    bool operator  < (const oper &p) const { return a * p.b  < p.a * b; }
    bool operator == (const oper &p) const { return a * p.b == p.a * b; }
};

vector<oper> op;

tree build(int l, int r, int lr) {
    if(l == r) return t[lr] = { a[l].c, a[l].c };
    return t[lr] = build(l, mid, ls) + build(mid + 1, r, rs);
}

void init() {
    sort(a + 1, a + n + 1);

    for(int i = 1; i <= n; i++) {
        int r = i, c = a[i].c;
        while(a[i].x == a[r + 1].x and a[i].y == a[r + 1].y) c += a[++r].c;
        m++, a[m] = { a[i].x, a[i].y, c, m }, i = r, p[m] = m;
    }

    n = m, op.clear();

    for(int i = 1; i <= n; i++) for(int j = i + 1; j <= n; j++) {
        int x = a[j].x - a[i].x, y = a[i].y - a[j].y;
        if(y > 0 and x > 0) op.push_back({ i, j, x, y });
    }

    sort(op.begin(), op.end());
}

void modify(int l, int r, int x, int id, int lr) {
    if(l == r) return t[lr] = { a[id].c, a[id].c }, void();
    mid >= x ? modify(l, mid, x, id, ls) : modify(mid + 1, r, x, id, rs);
    t[lr] = t[ls] + t[rs];
}

void out(int l, int r, int lr) {
    if(l == r) {
        cout << t[lr].s << " ";
        return;
    }
    out(l, mid, ls), out(mid + 1, r, rs);
}

bool check(int l, int r) {

    for(int i = l; i <= r; i++) {
        int x = op[i].x, y = op[i].y;
        if(a[x].c < a[y].c) modify(1, n, p[x], y, 1), modify(1, n, p[y], x, 1), swap(p[x], p[y]);
    }

    for(int i = r; i >= l; i--) {
        int x = op[i].x, y = op[i].y;
        if(a[x].c < a[y].c) swap(p[x], p[y]);
    }

    return t[1].x >= 0;
}

void update(int l, int r) { 
    for(int i = l; i <= r; i++) {
        int x = op[i].x, y = op[i].y, a = min(p[x], p[y]), b = max(p[x], p[y]);
        p[x] = b, p[y] = a, modify(1, n, p[x], x, 1), modify(1, n, p[y], y, 1);
    }
}

bool work() {
    build(1, n, 1); if(t[1].x >= 0) return 1;

    for(int l = 0; l < op.size(); l++) {
        int r = l;
        while(r + 1 < op.size() and op[r + 1] == op[l]) r++;
        if(check(l, r)) return 1; update(l, r), l = r;
    }

    return 0;
}

struct node1 {
    int v, c;
    bool operator < (const node1 &p) const {
        return v == p.v ? c > p.c : v < p.v;
    }
} b[N];

void solve() {
    n = read() << 1, m = 0;
    for(int i = 1; i <= n; i++) {
        int x = read(), y = read(); char ch = getchar();
        a[i] = { x, y, ch == '(' ? 1 : -1, 0 };
    }

    if(n <= 100) {
        bool flag = 0;

        for(int i = 1; i <= n; i++) for(int j = 1; j <= n; j++) if(a[i].c ^ a[j].c) {
            int sum = 0, A = a[j].y - a[i].y, B = a[i].x - a[j].x;
            if(A <= 0 or B <= 0) {
                if(flag) continue;
                flag = 1, A = 1e6, B = 1;
            }

            for(int k = 1; k <= n; k++) b[k] = { a[k].x * A + a[k].y * B, a[k].c };
            sort(b + 1, b + n + 1);
            
            for(int k = 1; k <= n and sum >= 0; k++) sum += b[k].c;
            if(sum >= 0) return puts("YES"), void();
        }

        puts("NO");
    }
    else init(), puts(work() ? "YES" : "NO");
}

bool edmer;
signed main() {
	freopen("brace.in", "r", stdin);
	freopen("brace.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 