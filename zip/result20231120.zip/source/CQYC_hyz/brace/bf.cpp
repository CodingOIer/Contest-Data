#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 3010;

struct oper {
    int a, b, c, v;
} a[N];

struct node {
    int v, c;
    bool operator < (const node &p) const {
        return v == p.v ? c > p.c : v < p.v;
    }
} b[N];

int n;

void solve() {
    n = read() << 1;
    for(int i = 1; i <= n; i++) {
        int x = read(), y = read(); char ch = getchar();
        a[i] = { x, y, ch == '(' ? 1 : -1, 0 };
    }

    bool flag = 0;

    for(int i = 1; i <= n; i++) for(int j = 1; j <= n; j++) if(a[i].c ^ a[j].c) {
        int sum = 0, A = a[j].b - a[i].b, B = a[i].a - a[j].a;
        if(A <= 0 or B <= 0) {
            if(flag) continue;
            flag = 1, A = 1e6, B = 1;
        }

        for(int k = 1; k <= n; k++) b[k] = { a[k].a * A + a[k].b * B, a[k].c };
        sort(b + 1, b + n + 1);

        // cout << A << " " << B << ":\n";
        // for(int k = 1; k <= n; k++) cout << b[k].v << " "; cout << '\n';
        
        for(int k = 1; k <= n and sum >= 0; k++) sum += b[k].c;
        if(sum >= 0) return puts("YES"), void();
    }

    puts("NO");
}

bool edmer;
signed main() {
	freopen("brace.in", "r", stdin);
	freopen("brace.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 