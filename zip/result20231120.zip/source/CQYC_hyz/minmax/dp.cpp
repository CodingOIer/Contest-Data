#include<bits/stdc++.h>
using namespace std;
int T = 0;
signed main() {
    system("g++ -O2 -Wall -std=c++14 maker.cpp -o maker");
    system("g++ -O2 -Wall -std=c++14 bf.cpp -o bf");
    system("g++ -O2 -Wall -std=c++14 minmax.cpp -o minmax");

	while(++T) {
		system("./maker");
		double st = clock();
		system("./minmax");
		double ed = clock();
		system("./bf");

		if(system("diff -Z -s minmax.out minmax.ans")) {
			puts("Wrong Answer");
			return 0;
		} 
		else printf("Accepted, test #%d, time %0.lfms\n", T, ed - st);

	}
    return 0;
}