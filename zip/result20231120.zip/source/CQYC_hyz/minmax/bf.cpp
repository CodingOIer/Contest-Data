#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct edge {
    int v, w;
};

struct node {
    int l, r;
} q[N];

int n, k, rt, sum, cnt, tot, ans;
int cr[N], cl[N], son[N], siz[N], p[N];

vector<edge> e[N];

bool vis[N];

struct BIT {
    int t[N];
    void add(int x, int k) { while(x <= n) t[x] += k, x += x & -x; }
    int ask(int x) { int res = 0; while(x) res += t[x], x -= x & -x; return res; }
} t1, t2;

void dfs(int x, int fa, int L, int R) {
    if(R - L == k) ans++;
    for(edge l : e[x]) if(l.v ^ fa)
        dfs(l.v, x, min(L, l.w), max(R, l.w));
}

bool edmer;
signed main() {
	freopen("minmax.in", "r", stdin);
	freopen("minmax.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = son[0] = read(), k = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read(), w = read();
        e[u].push_back({ v, w }), e[v].push_back({ u, w });
    }

    for(int i = 1; i <= n; i++) dfs(i, 0, n + 1, 0);

    write(ans / 2);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 