#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct edge {
    int v, w;
};

struct node {
    int l, r;
} q[N];

int n, k, rt, sum, cnt, tot, ans;
int cr[N], cl[N], son[N], siz[N], p[N];

vector<edge> e[N];

bool vis[N];

struct BIT {
    int t[N];
    void add(int x, int k) { while(x <= n) t[x] += k, x += x & -x; }
    int ask(int x) { int res = 0; while(x) res += t[x], x -= x & -x; return res; }
} t1, t2;


void getrt(int x, int fa) {
    siz[x] = 1, son[x] = 0;
    for(edge l : e[x]) if(!vis[l.v] and l.v != fa)
        getrt(l.v, x), siz[x] += siz[l.v], Max(son[x], siz[l.v]);
    Max(son[x], sum - siz[x]);
    if(son[x] <= son[rt]) rt = x;
}

void dfs(int x, int fa, int L, int R) {
    if(R - L > k) return;
    ans += t1.ask(L) - t1.ask(max(0ll, R - k - 1)) + cl[L] + cr[R];
    (R - L == k) ? ans += t2.ask(L) - cl[L] - cr[R] + 1, p[++cnt] = L : (q[++tot] = { L, R }, 1);
    
    for(edge l : e[x]) if(!vis[l.v] and l.v != fa)
        dfs(l.v, x, min(L, l.w), max(R, l.w));
}

void calc(int x) {
    for(edge l : e[x]) if(!vis[l.v]) {
        int l1 = cnt, l2 = tot; dfs(l.v, x, l.w, l.w);
        for(int i = l1 + 1; i <= cnt; i++) t1.add(p[i], 1);
        for(int i = l2 + 1; i <= tot; i++) {
            if(q[i].r - k >= 0) cl[q[i].r - k]++;
            if(q[i].l + k <= n) cr[q[i].l + k]++;
            t2.add(max(1ll, q[i].r - k), 1);
            t2.add(q[i].l + 1, -1);
        }
    }

    for(int i = 1; i <= cnt; i++) t1.add(p[i], -1);
    for(int i = 1; i <= tot; i++) {
        if(q[i].r - k >= 0) cl[q[i].r - k]--;
        if(q[i].l + k <= n) cr[q[i].l + k]--;
        t2.add(max(1ll, q[i].r - k), -1);
        t2.add(q[i].l + 1, 1);
    }

    cnt = tot = 0;
}

void solve(int x) {
    getrt(x, 0), calc(x), vis[x] = 1; 
    for(edge l : e[x]) if(!vis[l.v]) 
        rt = 0, sum = siz[l.v], getrt(l.v, x), solve(rt);
}

bool edmer;
signed main() {
	freopen("minmax.in", "r", stdin);
	freopen("minmax.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = son[0] = sum = read(), k = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read(), w = read();
        e[u].push_back({ v, w }), e[v].push_back({ u, w });
    }

    getrt(1, 0), solve(rt), write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 