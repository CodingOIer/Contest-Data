#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e5 + 10;

int n, m, cnt, ans;
int f[N], g[N], mu[N], pri[N];

bool vis[N];

void init() {
    mu[1] = 1;
    for(int i = 2; i <= n; i++) {
        if(!vis[i]) pri[++cnt] = i, mu[i] = mod - i;
        for(int j = 1; j <= cnt and pri[j] * i <= n; j++) {
            int to = i * pri[j]; vis[to] = 1;
            mu[to] = mod - 1ll * pri[j] * mu[i] % mod;
            if(!(i % pri[j])) { mu[to] = 0; break; }
        }
    }
}

void work() {
    for(int i = 1; i <= n; i++) {
        if(i & 1) f[i] = 1ll * i * q_pow(m, i / 2 + 1) % mod;
        else f[i] = 1ll * i / 2 * (q_pow(m, i / 2) + q_pow(m, i / 2 + 1)) % mod;
    }

    for(int i = 1; i <= n; i++)
        for(int j = i; j <= n; j += i)
            inc(g[j], 1ll * f[i] * mu[j / i] % mod);

    for(int i = 1; i <= n; i++) inc(ans, 1ll * n / i * g[i] % mod);
}

bool edmer;
signed main() {
	freopen("palindrome.in", "r", stdin);
	freopen("palindrome.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    
    init(), work();

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 