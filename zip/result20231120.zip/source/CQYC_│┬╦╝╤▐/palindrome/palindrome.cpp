#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5,mod=998244353;
int n,k,ans,a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int check(int m){
    for(int i=0;i<=m;i++){
        int bj=0;
        for(int j=1;j<=i/2;j++)
            if(a[j]!=a[i-j+1]){
                bj=1;
                break;
            }
        if(!bj){
            for(int j=i+1;j<=m;j++)
                if(a[j]!=a[m-(j-i)+1]){
                    bj=1;
                    break;
                }
            if(!bj)
                return 1;
        }
    }
    return 0;
}
void solve(int x){
    if(x>1){
        if(check(x-1))
            ++ans;
    }
    if(x>n)
        return;
    for(int i=1;i<=k;i++){
        a[x]=i;
        solve(x+1);
    }
}
signed main(){
    freopen("palindrome.in","r",stdin);
    freopen("palindrome.out","w",stdout);
    n=read(),k=read();
    solve(1);
    printf("%lld\n",ans);
    return 0;
}