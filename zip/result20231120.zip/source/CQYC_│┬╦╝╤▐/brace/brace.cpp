#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=3e3+5;
int t,n,a[maxn],b[maxn];
char c[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("brace.in","r",stdin);
    freopen("brace.out","w",stdout);
    t=read();
    while(t--){
        n=read();
        for(int i=1;i<=2*n;i++){
            a[i]=read(),b[i]=read();
            scanf("%s",&c[i]);
        }
        if(c[1]==c[2]){
            puts("NO");
            continue;
        }
        if(c[1]=='('&&c[2]==')'){
            if(a[1]<a[2]||b[1]<b[2])
                puts("YES");
            else
                if(a[1]==a[2]&&b[1]==b[2])
                    puts("YES");
                else
                    puts("NO");
        }
        else{
            if(a[1]>a[2]||b[1]>b[2])
                puts("YES");
            else
                if(a[1]==a[2]&&b[1]==b[2])
                    puts("YES");
                else
                    puts("NO");
        }
    }
    return 0;
}