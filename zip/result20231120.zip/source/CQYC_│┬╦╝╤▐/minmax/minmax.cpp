#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,k,u,v,w,ans,sum[maxn],in[maxn];
int he[maxn],ne[maxn<<1],to[maxn<<1],va[maxn<<1],tot;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int u,int v,int w){
    ne[++tot]=he[u],to[tot]=v,he[u]=tot,va[tot]=w;
    ne[++tot]=he[v],to[tot]=u,he[v]=tot,va[tot]=w;
}
void dfs(int u,int f,int ma,int mi){
    if(ma-mi==k)
        ++ans;
    if(ma-mi>k)
        return;
    for(int i=he[u];i;i=ne[i]){
        int v=to[i];
        if(v==f)
            continue;
        dfs(v,u,max(ma,va[i]),min(mi,va[i]));
    }
}
signed main(){
    freopen("minmax.in","r",stdin);
    freopen("minmax.out","w",stdout);
    n=read(),k=read();
    for(int i=1;i<n;i++){
        u=read(),v=read(),w=read();
        sum[w]++;
        add(u,v,w);
        in[u]++,in[v]++;
    }
    int bj=0;
    for(int i=1;i<=n;i++)
        if(in[i]>1)
            ++bj;
    if(bj==1){
        for(int i=1;i<=n&&k+i<=n;i++)
            if(sum[i]&&sum[k+i])
                ans+=sum[i]*sum[k+i];
        printf("%lld\n",ans);
        return 0;
    }
        for(int i=1;i<=n;i++)
            dfs(i,0,0,1e18);
        printf("%lld\n",ans/2);
    return 0;
}
