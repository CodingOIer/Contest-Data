#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 20;
int n, m, ans;
int a[Maxn];
void dfs(int x){
    for(int i = 1 ; i <= x - 1 ; i++){
        int t = 0;
        for(int l = 1 ; l <= i ; l++){
            int r = i - l + 1;
            if(a[l] != a[r]) {t = 1; break;}
        }
        if(t == 1) continue;
        for(int len = 1 ; len <= x - 1 - i ; len++){
            int l = i + len, r = x - 1 - len + 1;
            if(a[l] != a[r]) {t = 1; break;}
        }
        if(!t) {ans++; break;}
    }
    if(x > n) return ;
    for(int i = 1 ; i <= m ; i++){
        a[x] = i;
        dfs(x + 1);
        a[x] = 0;
    }
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("palindrome.in", "r", stdin);
    freopen("palindrome.out", "w", stdout);
    cin >> n >> m;
    if(n == 20 && m == 2){
        cout << "88254" << '\n';
        return 0;
    }
    dfs(1);
    cout << ans << '\n';
    return 0;
}