#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1510;
int T, n, TT;
int len, Max;
struct node{
    int a, b;
    char c;
}a[Maxn];
int x, y;
bool cmp(node q, node p){
    return x * q.a + y * q.b < x * p.a + y * p.b;
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("brace.in", "r", stdin);
    freopen("brace.out", "w", stdout);
    cin >> T;
    TT = T;
    while(T--){
        cin >> n;
        if(n == 1){
            int a1, b1, a2, b2;
            char c1, c2;
            cin >> a1 >> b1 >> c1;
            cin >> a2 >> b2 >> c2;
            if(c1 == '(') swap(a1, a2), swap(b1, b2);
            int t = 0;
            if((a1 < a2 && b1 < b2) || (a1 == a2 && b1 < b2) || (b1 == b2 && a1 < a2)){
                cout << "NO" << '\n';
                continue;
            }
            cout << "YES" << '\n';
            continue;
        }
        n *= 2;
        Max = 0;
        for(int i = 1 ; i <= n ; i++){
            cin >> a[i].a >> a[i].b >> a[i].c;
            Max = max(Max, max(a[i].a, a[i].b));
        }
        len = sqrt(200000000 / (n * n * TT * 10));
        int ops = 0;
        for(int i = 1 ; i <= len ; i++){
            if(ops) break;
            for(int j = 1 ; j <= len ; j++){
                x = i, y = j;
                sort(a + 1, a + n + 1, cmp);
                int t = 0;
                for(int k = 1 ; k <= n ; k++){
                    if(a[k].c == ')') t--;
                    else t++;
                    if(t < 0) break;
                }
                if(t >= 0){
                    ops = 1;
                    break;
                }
            }
        }
        for(int i = Max - len ; i <= Max ; i++){
            if(ops) break;
            for(int j = Max - len ; j <= Max ; j++){
                x = i, y = j;
                sort(a + 1, a + n + 1, cmp);
                int t = 0;
                for(int k = 1 ; k <= n ; k++){
                    if(a[k].c == ')') t--;
                    else t++;
                    if(t < 0) break;
                }
                if(t >= 0){
                    ops = 1;
                    break;
                }
            }
        }
        int mid = Max / 2;
        for(int i = mid - len / 2 ; i <= mid + len / 2 ; i++){
            if(ops) break;
            for(int j = mid - len / 2 ; j <= mid + len / 2 ; j++){
                x = i, y = j;
                sort(a + 1, a + n + 1, cmp);
                int t = 0;
                for(int k = 1 ; k <= n ; k++){
                    if(a[k].c == ')') t--;
                    else t++;
                    if(t < 0) break;
                }
                if(t >= 0){
                    ops = 1;
                    break;
                }
            }
        }
        if(ops) cout << "YES" << '\n';
        else cout << "NO" << '\n';
    }
    return 0;
}