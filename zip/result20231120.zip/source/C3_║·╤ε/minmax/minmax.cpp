#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 5010;
int n, K, ans;
struct Tree{
    int to, nxt, w;
}tree[Maxn << 1];
int head[Maxn], tot;
void add(int x, int y, int w){
    tree[++tot] = {y, head[x], w};
    head[x] = tot;
}
queue<int> q;
int Min[Maxn], Max[Maxn], vis[Maxn];
void bfs(int x){
    while(q.size()) q.pop();
    memset(Min, 0x3f, sizeof(Min));
    memset(Max, 0, sizeof(Max));
    memset(vis, 0, sizeof(vis));
    q.push(x);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        vis[u] = 1;
        for(int i = head[u] ; i ; i = tree[i].nxt){
            int to = tree[i].to, w = tree[i].w;
            if(vis[to]) continue;
            Max[to] = max(Max[u], w);
            Min[to] = min(Min[u], w);
            q.push(to);
        }
    }
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("minmax.in", "r", stdin);
    freopen("minmax.out", "w", stdout);
    cin >> n >> K;
    for(int i = 1 ; i < n ; i++){
        int x, y, w;
        cin >> x >> y >> w;
        add(x, y, w);
        add(y, x, w);
    }
    for(int i = 1 ; i <= n ; i++){
        bfs(i);
        for(int j = 1 ; j <= n ; j++)
            if(Max[j] - Min[j] == K) ans++;
    }
    cout << ans / 2 << '\n';
    return 0;
}