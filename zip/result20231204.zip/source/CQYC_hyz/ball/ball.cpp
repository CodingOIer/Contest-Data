#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 1e9 + 7;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

int n, cnt, tot, sum, ans = 1;
int fa[N], to[N], fac[N], inv[N];

vector<int> e[N], p;

bool vis[N], v1[N], flag;

int C(int x, int y) { return y > x ? 0 : 1ll * fac[x] * inv[y] % mod * inv[x - y] % mod; }

void init() {
    fac[0] = 1;
    for(int i = 1; i < N; i++) fac[i] = 1ll * fac[i - 1] * i % mod;
    inv[N - 1] = q_pow(fac[N - 1], mod - 2);
    for(int i = N - 1; i; i--) inv[i - 1] = 1ll * inv[i] * i % mod;
}

void dfs1(int x) {
    vis[x] = 1, to[x] = fa[x];
    cnt++, tot += e[x].size(), p.push_back(x);
    
    for(int v : e[x]) {
        if(!vis[v]) fa[v] = x, dfs1(v);
        else if(v != fa[x] and flag) {
            int u = v, lat = x; flag = 0;
            while(u) to[u] = lat, lat = u, u = fa[u];
        }
    }
}

void dfs2(int x) {
    for(int v : e[x]) {
        if(fa[v] == x) dfs2(v);
        else if(v != fa[x] and flag) {
            int u = x, lat = v; flag = 0;
            while(u ^ fa[v]) to[u] = lat, lat = u, u = fa[u];
        }
    }
}

void dfs(int x) {
    if(x == cnt) return tot++, void();
    for(int i = 0; i < cnt; i++) if(!v1[p[i]]) {
        int u = p[i]; bool f = 1;
        for(int v : e[u]) f &= (v >= to[u] or v1[v]);
        if(f) v1[u] = 1, dfs(x + 1), v1[u] = 0;
    }
}

int calc() {
    tot = 0, dfs(0);
    return tot;
}

int work(int x) {
    cnt = 0, tot = 0, p.clear(), flag = 1, dfs1(x);
    if(cnt ^ (tot >> 1)) puts("0"), exit(0);

    int res = calc();
    flag = 1, dfs2(x), inc(res, calc());

    return res;
}

bool edmer;
signed main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), init();
    for(int i = 1; i <= n << 1; i++) {
        int x = read() + n, y = read();
        e[x].push_back(y), e[y].push_back(x);
    }

    for(int i = 1; i <= n << 1; i++) if(!vis[i])
        mul(ans, work(i)), mul(ans, C(sum + cnt, cnt)), sum += cnt;

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 