#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 8010, inf = 1e16;

int n;
int a[N << 1];

void work(int x) {
    int p[2] = { 1, 2 }, f[2] = { 0, 0 }, sum = 0, res = inf;
    for(int i = 1; i < n; i++) f[0] += a[i + x];
    f[1] = f[0] - a[x + 1];

    for(int i = 0; i + 1 < n; i++) {
        int &pos = p[i & 1], &tot = f[i & 1]; sum += a[i + x]; 
        
        if(pos < i) tot -= a[x + pos] - a[x + pos + 1], pos += 2;
        else if(i > 1) tot += a[i + x] - a[i + x - 1];

        while(pos + 2 < n and sum + 2 * a[x + pos + 1] < tot) pos += 2, tot -= 2 * a[x + pos - 1];
        while(pos - 2 > i and sum - 2 * a[x + pos - 1] > tot) pos -= 2, tot += 2 * a[x + pos + 1];

        Min(res, abs(sum - tot));
        if(pos + 2 < n) Min(res, abs(sum - tot + 2 * a[x + pos + 1]));
        if(pos - 2 > i) Min(res, abs(sum - tot - 2 * a[x + pos - 1]));
    }

    write(res), putchar('\n');
}

bool edmer;
signed main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) a[i] = a[i + n] = read();

    for(int i = 1; i <= n; i++) work(i);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 