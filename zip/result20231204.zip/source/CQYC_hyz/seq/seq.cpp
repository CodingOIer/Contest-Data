#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e5 + 10;

int n, q;

char a[N];

struct node {
    vector<int> s;
    int get(int x) { 
        x %= n; if(x < 0) x += n;
        return x ? s[x] - s[x - 1] : s[x];
    }

    int query(int l, int r) {
        int res = 0;
        if(r - l >= n) {
            int p = (r - l) / n;
            res += p * query(0, n - 1), r -= p * n;
        }
        
        if(l < 0) {
            int p = (n - 1 - l) / n;
            l += p * n, r += p * n;
        }

        if(l / n != r / n) res += query(l, r / n * n - 1), res += query(r / n * n, r);
        else l %= n, r %= n, res += s[r] - (l ? s[l - 1] : 0);

        return res;
    }
} tmp;

vector<node> v;

void init(int x) {
    while(v.size() <= x) {
        tmp.s.clear();
        for(int i = 0; i < n; i++) 
            tmp.s.push_back(v.back().get(v.back().get(i) ? (i + 1) : (i - 1)));
        for(int i = 1; i < n; i++) tmp.s[i] += tmp.s[i - 1];
        v.push_back(tmp);
        // cout << v.size() - 1 << ":\n";
        // for(int i = 0; i < n; i++) cout << v.back().get(i) << ' '; cout << '\n';
    }
}


void solve() {
    scanf("%s", a), n = strlen(a), q = read();
    v.clear(), tmp.s.clear(), tmp.s.push_back(a[0] == '(');
    for(int i = 1; i < n; i++) tmp.s.push_back(tmp.s.back() + (a[i] == '('));

    v.push_back(tmp);

    while(q--) {
        int k = read(), l = read(), r = read();
        // if(k > n) k -= (k - n + 1) / 2 * 2;
        init(k), write(v[k].query(l, r)), putchar('\n');
    }
}

bool edmer;
signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read(); while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 