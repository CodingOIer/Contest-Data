#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 1e9 + 7;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 100;

int n, p[N], ans;
struct node { int x, y; bool o; }a[N];

bool check() {
    For(i, 1, 2 * n) a[i].o = 1;
    For(i, 1, 2 * n) { int x = p[i], pos = 0;
        if (x <= n) {
            For(j, 1, 2 * n) if (a[j].o) 
                if (a[j].x == x && a[j].y >= 0)
                    if (!pos || a[j].y < a[pos].y) pos = j;
        } else {
            For(j, 1, 2 * n) if (a[j].o) 
                if (a[j].y == x - n && a[j].x >= 0)
                    if (!pos || a[j].x < a[pos].x) pos = j;
        }
        if (!pos) return 0; a[pos].o = 0;
    }
    return 1;
}
signed main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
    n = read(); For(i, 1, 2 * n) a[i] = {read(), read(), 0};
    For(i, 1, 2 * n) p[i] = i;
    do { ans += check(); }
    while (next_permutation(p + 1, p + 2 * n + 1));
    cout << ans << '\n';
	return 0;
}
