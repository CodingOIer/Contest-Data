#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 8010;

int n, a[N << 1];
i64 f[N << 1], g[N << 1], total;

signed main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
    n = read(); 
    For(i, 1, n) a[i] = a[i + n] = read();
    For(i, 1, n + n) {
        f[i] = f[i - 1], g[i] = g[i - 1];
        if (i & 1) f[i] += a[i]; else g[i] += a[i];
    }
    For(i, 1, n) total += a[i];

    For(s, 1, n) {  
        i64 sum = 0, ans = 1e18;
        int r = s + n - 2, pos1 = 0, pos2 = 0;
        if (r & 1) pos1 = r, pos2 = r - 1;
        else pos1 = r - 1, pos2 = r;
        
        For(i, s, s + n - 1) { sum += a[i];

            if (sum >= total - sum) {
                ans = min(ans, 2 * sum - total);
                break;
            } 
            i64 val = sum;
            if (i & 1) {
                val -= f[i], val *= 2, val -= total, val = -val;
                while (pos1 >= s && 2 * f[pos1] > val) pos1 -= 2;
                if (pos1 >= s && pos1 <= r) ans = min(ans, abs(val - 2 * f[pos1]));
                if (pos1 + 2 >= s && pos1 + 2 <= r) ans = min(ans, abs(val - 2 * f[pos1 + 2]));
            } else {
                val -= g[i], val *= 2, val -= total, val = -val;
                while (pos2 >= s && 2 * g[pos2] > val) pos2 -= 2;
                if (pos2 >= s && pos2 <= r) ans = min(ans, abs(val - 2 * g[pos2]));
                if (pos2 + 2 >= s && pos2 + 2 <= r) ans = min(ans, abs(val - 2 * g[pos2 + 2]));
            }
        }

        cout << ans << '\n';
    }
	return 0;
}
