#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 1e5 + 100;

int n, m, ans[N]; 
char tmp[N]; bool a[N];

struct BIT {
    int t[N]; void init() { For(i, 0, n) t[i] = 0; }
    void modify(int x, int y) { for ( ++x; x <= n; x += x & -x) t[x] += y; }
    int ask(int l, int r) {
        int res = 0; ++r; while (l != r) 
        r > l ? (res += t[r], r -= r & -r) : (res -= t[l], l -= l & -l);
        return res;
    }
}tr;

struct node {
    int k, l, r, id;
    bool operator <(const node &b) const {
        return k < b.k;
    }
}q[N];

int ti, p;

vector<int> f, g; bool vis[N];
inline int lst(int x) { return !x ? n - 1 : x - 1; }
inline int nex(int x) { return x == n - 1 ? 0 : x + 1; }

bool flag; int tot;

void Push(int x) {
    if (a[x] && (a[lst(x)] ^ (a[nex(x)]))) 
        if (!vis[lst(x)]) f.push_back(lst(x)), vis[lst(x)] = 1;
}

void change() {
    swap(f, g), f.clear(); 
    for (auto x : g) vis[x] = 0, tr.modify(x, (a[x] ^ 1) - a[x]), a[x] ^= 1;
    for (auto x : g) Push(x), Push(lst(x)), Push(nex(x));
}

void work(int x) {
    int l = q[x].l - q[x].k, r = q[x].r - q[x].k, id = q[x].id, d = l / n; 

    if (l < 0) l += d * n, r += d * n; 
    else l -= d * n, r -= d * n;
    while (l < 0) l += n, r += n;    
    while (l >= n) l -= n, r -= n;   

    d = (r - l + 1) / n, ans[id] += d * tot, r -= d * n;

    if (l > r) return;

    if (r < n) ans[id] += tr.ask(l, r);
    else ans[id] += tr.ask(l, n - 1) + tr.ask(0, r - n);
}
void solve() {
    scanf("%s", tmp), n = strlen(tmp), tr.init();
    flag = 0, tot = 0;
    For(i, 0, n - 1) tot += a[i] = (tmp[i] == '(');
    
    if (tot * 2 > n) {
        flag = 1, tot = n - tot;
        For(i, 0, n - 1) a[i] ^= 1;
    }

    For(i, 0, n - 1) tr.modify(i, a[i]);

    f.clear(), g.clear();
    
    For(i, 0, n - 1) Push(i);
    
    m = read(); For(i, 1, m) {
        q[i] = {read(), read(), read(), i};
        if (flag) ans[i] = -(q[i].r - q[i].l + 1); else ans[i] = 0;
    }
    sort(q + 1, q + m + 1), ti = 0, p = 0;
    
    for ( ; ti <= n; ++ti, change()) 
        while (p < m && q[p + 1].k <= ti) work(++p);
    while (p < m) work(++p);

    For(i, 1, m) cout << abs(ans[i]) << "\n";
}

signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
    int T = read(); while (T--) solve();
	return 0;
}
