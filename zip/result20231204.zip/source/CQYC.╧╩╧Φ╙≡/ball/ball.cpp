#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=N<<1,mod=1e9+7;
int n,ans,a[M],tx[M],ty[M];
bool vis[M];
set<int>sx[N],sy[N];
set<int>::iterator it;
void check()
{
    for(int i=1;i<=n;i++)
        sx[i].clear(),sy[i].clear();
    for(int i=1;i<=n+n;i++)
        sx[tx[i]].insert(ty[i]),
        sy[ty[i]].insert(tx[i]);
    for(int i=1;i<=n+n;i++)
        if(a[i]>n)
        {
            if(sx[a[i]-n].empty()) return;
            it=sx[a[i]-n].begin();
            sy[*it].erase(a[i]-n);
            sx[a[i]-n].erase(it);
        }
        else
        {
            if(sy[a[i]].empty()) return;
            it=sy[a[i]].begin();
            sx[*it].erase(a[i]);
            sy[a[i]].erase(it);
        }
    ++ans;
}
void dfs(int x)
{
    if(x>n+n) return check();
    for(int i=1;i<=n+n;i++)
        if(!vis[i]) vis[a[x]=i]=1,dfs(x+1),vis[i]=0;
}
int main()
{
    freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n+n;i++)
        scanf("%d%d",tx+i,ty+i);
    dfs(1);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
