#include<bits/stdc++.h>
using namespace std;
int stk[10],tp;
inline void write(int x)
{
    if(!x) return puts("0"),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
    putchar('\n');
}
const int N=2.1e5+10,M=N>>1;
int T,n,q,tot[4][N];
char a[N],b[4][N];
void check()
{
    for(int i=0;i<n;i++)
    {
        for(int j=i;j+M>=0;j-=n) b[0][j+M]=a[i];
        for(int j=i;j+M<N;j+=n) b[0][j+M]=a[i];
    }
    for(int i=1;i<4;i++)
        for(int j=0;j<N;j++)
        {
            if(b[i-1][j]=='('&&j+1<N) b[i][j]=b[i-1][j+1];
            if(b[i-1][j]==')'&&j) b[i][j]=b[i-1][j-1];
        }
    
    for(int i=0;i<4;i++)
    {
        tot[i][0]=(b[i][0]=='(');
        for(int j=1;j<N;j++)
            tot[i][j]=tot[i][j-1]+(b[i][j]=='(');
    }
}
int main()
{
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    scanf("%d",&T);
    int k,l,r;
    while(T--)
    {
        scanf("%s%d",&a,&q);
        n=strlen(a);
        check();
        while(q--)
        {
            scanf("%d%d%d",&k,&l,&r);
            write(tot[k][r+M]-tot[k][l-1+M]);
        }
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
