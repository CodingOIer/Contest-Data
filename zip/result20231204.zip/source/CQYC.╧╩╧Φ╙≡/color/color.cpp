#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=16010;
int n,a[N];
ll S,ans,ned;
inline void Min(ll &x,ll y) {x=x>y?y:x;}
inline void cut() {Min(ans,abs(ned-S+ned));}
int main()
{
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",a+i),S+=a[i],a[i+n]=a[i];
    for(int i=1,T,k;i<=n;i++)
    {
        ans=1e18;
        ned=a[i];cut();
        for(k=i+2;k<i+n-1&&ned<S/2;k+=2) ned+=a[k],cut();
        k-=2;
        for(int j=i+1;j-i<n;j+=2)
        {
            ned+=a[j];cut();
            for(;j<k&&ned>=S/2;k-=2) ned-=a[k],cut();
            if(j>=k) break;
        }
        ned=a[i]+a[i+1];cut();
        for(k=i+3;k<i+n-1&&ned<S/2;k+=2) ned+=a[k],cut();
        k-=2;
        for(int j=i+2;j-i<n;j+=2)
        {
            ned+=a[j];cut();
            for(;j<k&&ned>=S/2;k-=2) ned-=a[k],cut();
            if(j>=k) break;
        }
        printf("%lld\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
