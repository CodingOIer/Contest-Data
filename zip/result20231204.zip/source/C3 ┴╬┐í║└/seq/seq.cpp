#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,m;
char s[100005][4];
int sum[100005][4];
inline int sol(int x,int k){
	if((x+1)%n)return sum[n-1][k]*((x+1)/n)+sum[(x+1)%n-1][k];
	else return sum[n-1][k]*((x+1)/n);	
}
int main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	int T;
	read(T);
	while(T--){
		n=0;
		while(1){
			s[n++][0]=getch();
			if(s[n-1][0]!='('&&s[n-1][0]!=')')break;
		}
		n--;
		for(int j=1;j<=3;j++){
			for(int i=0;i<n;i++){
				if(s[i][j-1]==')'){
					s[i][j]=s[(i-1+n)%n][j-1];	
				}else{
					s[i][j]=s[(i+1)%n][j-1];	
				}
			}
		}
		for(int j=0;j<=3;j++){
			sum[0][j]=(s[0][j]=='(');
			for(int i=1;i<n;i++)sum[i][j]=sum[i-1][j]+(s[i][j]=='(');
		}
		read(m);
		while(m--){
			int k,l,r;
			read(k,l,r);
			k%=4;
			int s=(abs(l)/n+1)*n;
			l+=s,r+=s;
			write(sol(r,k)-sol(l-1,k)),putch('\n');
		}
	}
	flush();
	return 0;
}

