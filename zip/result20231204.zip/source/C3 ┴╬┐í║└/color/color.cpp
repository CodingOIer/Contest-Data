#include<bits/stdc++.h>
#define int long long 
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n;
int a[16005];
int sum[16005];
int s[16005];
inline int Abs(int x){if(x<0)return -x;return x;} 
signed main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		read(a[i]);
		a[i+n]=a[i];	
	}
	for(int i=1;i<=2*n;i++)
		sum[i]=sum[i-1]+a[i];
	for(int i=1;i<=2*n;i++)
		s[i]=s[i-1]+pow(-1,i&1)*a[i];
	for(int l=1;l<=n;l++){
		int ans=1e18;
		int r=l+n-1;
		for(int m=l;m<=r;m++)ans=min(Abs((sum[m]-sum[l-1])-(sum[r]-sum[m])),ans);
		if(n>=4){
			for(int m1=l+1;m1<r;m1++)
				for(int m2=m1+1;m2<r;m2++)
					ans=min(ans,Abs((sum[m1-1]-sum[l-1])-(sum[r]-sum[m2])+(s[m2]-s[m1-1])*pow(-1,m1&1)));
		cout<<ans<<endl;
	}
	return 0;
}

