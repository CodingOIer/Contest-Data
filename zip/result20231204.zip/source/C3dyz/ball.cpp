#include<bits/stdc++.h>
#define int long long
const int mod=1e9+7;
using namespace std;
struct node {
    int x,y;
}a[200005];
int ans=0,vis[200005],f[200005],g[200005],n;
void dfs(int A,int B,int s) {
    if(s==0 && A==0 && B==0) {
        ans=(ans+1)%mod;
        return ;
    }
    if(A==0 && B==0) return ; 
    for(int i=1;i<=n;i++) {
        if(!g[i]) {
            int minn=1e9,k=0;
            for(int j=1;j<=2*n;j++) {
                if(!vis[j]) {
                    if(a[j].y==i) {
                        minn=min(minn,a[j].x);
                        if(minn==a[j].x) k=j;
                    }
                }
            }
            g[i]++;
            vis[k]++;
            dfs(A-1,B,s-(k!=0));
            vis[k]=0;
            g[i]=0;
        }
    }
    for(int i=1;i<=n;i++) {
        if(!f[i]) {
            int minn=1e9,k=0;
            for(int j=1;j<=2*n;j++) {
                if(!vis[j]) {
                    if(a[j].x==i) {
                        minn=min(minn,a[j].y);
                        if(minn==a[j].y) k=j;
                    }
                }
            }
            f[i]++;
            vis[k]++;
            dfs(A,B-1,s-(k!=0));
            vis[k]=0;
            f[i]=0;
        }
    }
}
signed main() {
    freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
    scanf("%lld",&n);
    for(int i=1;i<=2*n;i++) {
        scanf("%lld %lld",&a[i].x,&a[i].y);
    }
    dfs(n,n,2*n);
    printf("%lld\n",ans);
    return 0;
}

