#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int ans[105],t[105],a[205];
void print(int x) {
    for(int i=1;i<=n;i++) {
        if(x&(1<<(i-1))) printf("1");
        else printf("0");
    }
    printf("\n");
}
signed main() {
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    scanf("%lld",&n);
    for(int i=1;i<=n;i++) {
        scanf("%lld",&a[i]);
        a[i+n]=a[i];
    }
    memset(ans,0x3f,sizeof ans);
    for(int i=0;i<(1<<n);i++) {
        for(int j=1;j<=n;j++) {
            int tx=j-1;
            if(tx==0) tx=n;
            for(int k=1;k<=n;k++) t[k]=a[k+j-1];
            int maxn=1e9,minn=0,lastx=0,lasty=0;
            int w=(i>>(j-1))+((i&((1<<(j-1))-1))<<(n-j+1)),flag=0;
            if((w&1) || !(w&(1<<(n-1)))) continue;
            int sum=0;
            for(int k=1;k<=n;k++) {
                if((w&(1<<(k-1)))==0) {
                    sum+=t[k];
                    if(lastx) {
                        if(minn<=k-lastx) minn=k-lastx;
                        else {
                            flag=1;
                            break;
                        }
                    }
                    lastx=k;
                } else {
                    sum-=t[k];
                    if(lasty) {
                        if(maxn>=k-lasty) {
                            maxn=k-lasty;
                        }
                        else {
                            flag=1;
                            break;
                        }
                    }
                    lasty=k;
                }
            }
            if(!flag) {
                ans[j]=min(ans[j],abs(sum));
            }
        }
    }
    for(int i=1;i<=n;i++) {
        printf("%lld\n",ans[i]);
    }
    return 0;
}