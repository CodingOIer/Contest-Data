#include<bits/stdc++.h>
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace std;
using namespace IO;
char s[5][200005];
int sum[5][200005],n;
int W(int x) {
    if(x<0) return n+((x-1)%(n)+1);
    return (x)%n;
}
int main() {
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    int T;
    scanf("%d",&T);
    while(T--) {
        cin>>s[0];
        int q;
        cin>>q;
        n=strlen(s[0]);
        sum[0][0]=(s[0][0]=='(');
        for(int i=1;i<n;i++) sum[0][i]=sum[0][i-1]+(s[0][i]=='('); 
        for(int j=1;j<=3;j++) {
            for(int i=0;i<n;i++) {
                if(s[j-1][i]=='(') {
                    if(i==n-1) s[j][i]=s[j-1][0];
                    else s[j][i]=s[j-1][i+1];
                } else {
                    if(i==0) s[j][i]=s[j-1][n-1];
                    else s[j][i]=s[j-1][i-1];
                }
            }
            sum[j][0]=(s[j][0]=='(');
            for(int i=1;i<n;i++) sum[j][i]=sum[j][i-1]+(s[j][i]=='('); 
        }
        while(q--) {
            int l,r,k,ans=0;
            scanf("%d %d %d",&k,&l,&r);
            int lx=l,rx=r;
            if(lx<0) lx=(lx+1)/n*n-1;
            else lx=lx/n*n+n;
            if(rx<0) rx=(rx+1)/n*n-n;
            else rx=(rx/n)*n;
            if(rx<lx) {
                ans=(sum[k][W(r)]-sum[k][W(l)-1]);
                printf("%d\n",ans);
                continue;
            }
            ans=(ans+(sum[k][W(r)]+sum[k][n-1]-sum[k][W(l)-1])+(int)(rx-lx+n-2)/n*sum[k][n-1]);
            printf("%d\n",ans);
        }
    }


    return 0;
}
/*
1
(())))(()()()())(())
1
3 -54200 89718


2
(())
3
0 -3 2
1 -2 3
2 0 0
))()(
3
0 -3 4
2 1 3
3 -4 -1
*/