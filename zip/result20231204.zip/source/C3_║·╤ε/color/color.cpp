#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 8010;
int n;
int a[Maxn], b[Maxn];
struct node{
    int r, b;
}l[2010][2010];
int s_f[Maxn], s_l[Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("color.in", "r", stdin);
    freopen("color.out", "w", stdout);
    cin >> n;
    for(int i = 1 ; i <= n ; i++)
        cin >> a[i];
    for(int s = 1 ; s <= n ; s++){
        int ans = 1e18, s1 = 0, s2 = 0;
        for(int i = s, l = 1 ; l <= n ; i = i % n + 1, l++)
            b[l] = a[i];
        memset(s_f, 0, sizeof(s_f));
        memset(s_l, 0, sizeof(s_l));
        memset(l, 0, sizeof(l));
        // for(int i = 1 ; i <= n ; i++) cout << b[i] << " ";
        // cout << endl;
        if(n % 2 == 0){
            for(int i = 1 ; i <= n ; i++){
                if(i & 1) s1 += b[i];
                else s2 += b[i];
            }
            ans = abs(s1 - s2);
        }
        for(int i = 1 ; i <= n ; i++){
            for(int j = 2 ; j <= n ; j += 2){
                int s1 = 0, s2 = 0, op = 0;
                for(int k = i ; k <= i + j - 1 ; k++){
                    if(!op) s1 += b[k];
                    else s2 += b[k];
                    op ^= 1;
                }
                l[i][j] = {s1, s2};
            }
        }
        // for(int i = 1 ; i <= n ; i++){
        //     for(int j = 2 ; j <= n ; j+= 2)
        //         cout << "(" << l[i][j].r << " " << l[i][j].b << ") ";
        //     cout << endl;
        // }
        // cout << endl;
        for(int i = 1 ; i <= n ; i++)
            s_f[i] = s_f[i - 1] + b[i];
        for(int i = n ; i >= 1 ; i--)
            s_l[i] = s_l[i + 1] + b[i];
        for(int i = 1 ; i < n ; i++)
            ans = min(ans, abs(s_f[i] - s_l[i + 1]));
        for(int i = 1 ; i <= n - 1 ; i++){
            for(int len = 2 ; len + i - 1 <= n ; len += 2){
                int r = s_f[i - 1] + l[i][len].r;
                int b = s_l[i + len] + l[i][len].b;
                ans = min(ans, abs(r - b));
            }
        }
        cout << ans << '\n';
    }
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}