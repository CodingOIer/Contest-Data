#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1000010, N = 1000000;
int T, n, Q;
string s;
bool a[Maxn];
bool b[2][4][Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("seq.in", "r", stdin);
    freopen("seq.out", "w", stdout);
    cin >> T;
    while(T--){
        cin >> s;
        n = s.size();
        memset(a, 0, sizeof(a));
        memset(b, 0, sizeof(b));
        for(int i = 0 ; i <= n ; i++)
            if(s[i] == '(') a[i] = 1;
        for(int i = 0 ; i <= N ; i++)
            if(i < n) b[1][0][i] = a[i];
            else b[1][0][i] = b[1][0][i - n];
        b[0][0][0] = b[1][0][0];
        for(int i = 1 ; i <= N ; i++){
            if(i <= n) b[0][0][i] = a[n - i];
            else b[0][0][i] = b[0][0][i - n];
        }
        for(int k = 1 ; k <= 3 ; k++){
            for(int i = 1 ; i <= N ; i++){
                if(b[0][k - 1][i] == 1) b[0][k][i] = b[0][k - 1][i - 1];
                else b[0][k][i] = b[0][k - 1][i + 1];
            }
            for(int i = 0 ; i <= N ; i++){
                if(b[1][k - 1][i] == 1) b[1][k][i] = b[1][k - 1][i + 1];
                else{
                    if(i == 0) b[1][k][i] = b[0][k - 1][1];
                    else b[1][k][i] = b[1][k - 1][i - 1];
                } 
            }
            b[0][k][0] = b[1][k][0];
        }
        cin >> Q;
        // for(int k = 0 ; k <= 3 ; k++){
        //     for(int i = 10 ; i ; i--) cout << b[0][k][i];
        //     cout << " ";
        //     for(int i = 0 ; i <= 10 ; i++) cout << b[1][k][i];
        //     cout << '\n';
        // }
        while(Q--){
            int k, l, r, ans = 0;
            cin >> k >> l >> r;
            if(l < 0 && r < 0){
                for(int i = -r ; i <= -l ; i++) ans += b[0][k][i];
            }else if(l < 0 && r >= 0){
                for(int i = 1 ; i <= -l ; i++) ans += b[0][k][i];
                for(int i = 0 ; i <= r ; i++) ans += b[1][k][i];
            }else {
                for(int i = l ; i <= r ; i++) ans += b[1][k][i];
            }
            cout << ans << '\n';
        }
    }
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}
/*
2
(())
3
0 -3 2
1 -2 3
2 0 0
))()(
3
0 -3 4
2 1 3
3 -4 -1
*/