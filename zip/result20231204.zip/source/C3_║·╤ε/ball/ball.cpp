#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 20, mod = 1e9 + 7;
int n, ans;
int a[Maxn][Maxn], b[Maxn][Maxn];
int vis[Maxn], siz[Maxn];
void dfs(int x){
    if(x > 2 * n){
        // for(int i = 1 ; i <= 2 * n ; i++) cout << siz[i] << " ";
        // cout << endl;
        for(int i = 1 ; i <= n ; i++)
            for(int j = 1 ; j <= n ; j++)
                b[i][j] = a[i][j];
        int cnt = 2 * n;
        for(int i = 1 ; i <= 2 * n ; i++){
            if(siz[i] <= n){
                int id = siz[i];
                // cout << "A " << id << endl;
                for(int j = 1 ; j <= n ; j++){
                    if(b[j][id]){
                        cnt--;
                        b[j][id] = 0;
                        break;
                    }
                }
            }
            else{
                int id = siz[i] - n;
                // cout << "B " << id << endl;
                for(int j = 1 ; j <= n ; j++){
                    if(b[id][j]){
                        cnt--;
                        b[id][j] = 0;
                        break;
                    }
                }
            }
            // for(int ii = 1 ; ii <= n ; ii++){
            //     for(int jj = 1 ; jj <= n ; jj++)
            //         cout << b[ii][jj] << " ";
            //     cout << endl;
            // }
            // cout << endl;
        }
        if(cnt == 0) ans++;
        if(ans >= mod) ans--;
        return ;
    }
    for(int i = 1 ; i <= 2 * n ; i++){
        if(vis[i]) continue;
        vis[i] = 1;
        siz[x] = i;
        dfs(x + 1);
        vis[i] = 0;
    }
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("ball.in", "r", stdin);
    freopen("ball.out", "w", stdout);
    cin >> n;
    for(int i = 1 ; i <= 2 * n ; i++){
        int x, y;
        cin >> x >> y;
        a[x][y] = 1;
    }
    dfs(1);
    cout << ans << '\n';
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}
/*
5
1 5
3 5
2 4
3 1
4 2
1 3
2 3
5 2
5 3
3 2
*/