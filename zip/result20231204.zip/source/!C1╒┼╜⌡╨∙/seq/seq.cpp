#include <bits/stdc++.h>
using namespace std;

int t, n, q, k, x, y;
char s[4][300006];
int sum[4][300006];

void solve() {
	scanf("%s", s[0]);
	n = strlen(s[0]);
	const int tmpadd = ((-100000) / n - 1) * -n, yn = n;
	for (int i = n; i <= 300002; ++i) s[0][i] = s[0][i - n];
	n = 300002;
	for (int k = 0; k <= 3; ++k) for (int i = 0; i <= n; ++i)
		sum[k][i] = 0;
	for (int k = 1; k <= 3; ++k) {
		for (int i = 0; i < n; ++i) {
			if (s[k - 1][i] == '(') {
				s[k][i] = s[k - 1][(i + 1) % yn];
			} else {
				s[k][i] = s[k - 1][(i - 1 + yn) % yn];
			}
		}
	}
	for (int k = 0; k <= 3; ++k) for (int i = 0; i < n; ++i)
		sum[k][i] = (i != 0 ? sum[k][i - 1] : 0) + (s[k][i] == '(');
	scanf("%d", &q);
	while (q--) {
		scanf("%d%d%d", &k, &x, &y);
		x += tmpadd;
		y += tmpadd;
		printf("%d\n", sum[k][y] - sum[k][x - 1]);
	}
}

int main() {
	freopen("seq.in","r",stdin);
	freopen("seq.out", "w", stdout);
	scanf("%d", &t);
	while (t--) solve();
}
/*
Testcase1~6 AC
Testcase7~20 RE
30pts
*/
