#include <bits/stdc++.h>
using namespace std;

int n, bx[11], by[11];
bool a[11], b[11], points[11][11];
int ans;

void dfs(int i) {
	if (i == 2 * n + 1) {
		++ans;
		return;
	}
	for (int j = 1; j <= n; ++j) {
		if (!a[j]) {
			for (int k = 1; k <= n; ++k) {
				if (points[j][k]) {
					a[j] = 1;
					points[j][k] = 0;
					dfs(i + 1);
					a[j] = 0;
					points[j][k] = 1;
					break;
				}
			}
		}
	}
	for (int j = 1; j <= n; ++j) {
		if (!b[j]) {
			for (int k = 1; k <= n; ++k) {
				if (points[k][j]) {
					b[j] = 1;
					points[k][j] = 0;
					dfs(i + 1);
					b[j] = 0;
					points[k][j] = 1;
					break;
				}
			}
		}
	}
}

int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= 2 * n; ++i) {
		scanf("%d%d", &bx[i], &by[i]);
		points[bx[i]][by[i]] = 1;
	}
	if (n <= 5) {
		dfs(1);
		return printf("%d\n", ans), 0;
	} else return puts("0"), 0;
}
/*
Testcase1~4 : AC
Testcase5~20 :WA(or AC 1 testcases)
25~30pts
*/
