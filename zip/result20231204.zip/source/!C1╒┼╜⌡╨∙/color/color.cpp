#include <bits/stdc++.h>
using namespace std;

int n, a[1002], tot;
bitset<1024> ft[260001], f;

void dfs(int i, int lastred, int lastblack, int maxred, int minblack) {
	if (i == 1) {
		f[i] = 1;
		dfs(i + 1, 1, 0, 0, n);
	} else if (i == n) {
		if (i - lastblack > minblack) return;
		f[i] = 0;
		++tot;
		for (int j = 1; j <= n; ++j) {
			ft[tot][j] = f[j];
		}
	} else { 
		if (i - lastred >= maxred) {
			f[i] = 1;
			dfs(i + 1, i, lastblack, i - lastred, minblack);
		}
		if (i - lastblack <= minblack) {
			f[i] = 0;
			dfs(i + 1, lastred, i, maxred, i - lastblack);
		}
	}
}

long long lllabs(long long a) {
	return a > 0 ? a : -a;
}

int main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
	scanf("%d", &n);
	dfs(1, 0, 0, 0, n);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= n; ++i) {
		long long ans = 1ll << 60;
		for (int j = 1; j <= tot; ++j) {
			long long bs = 0, rs = 0;
			for (int k = 1; k <= n; ++k) {
				if (ft[j][k]) rs += a[k];
				else bs += a[k];
			}
			ans = min(ans, lllabs(bs - rs));
		}
		printf("%lld\n", ans);
		int tmp = a[1];
		for (int i = 1; i < n; ++i) {
			a[i] = a[i + 1];
		}
		a[n] = tmp;
	}
}
/*
Subtask1~3 : AC
Subtask4: TLE
Subtask5: RE
52pts
*/ 
