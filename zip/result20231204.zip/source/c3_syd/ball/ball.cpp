#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#define pii pair <int, int>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

#define fi first
#define se second


namespace Subtask1 {

const int N = 15;

array <array <int, N>, N> mp;
array <pii, N> isl;
array <int, N> idx;

int main(int n) {
	int m = n * 2;
	for (int i = 1; i <= m; i++) {
		isl[i].fi = read(), isl[i].se = read();
		mp[isl[i].fi][isl[i].se] = 1;
	}
	for (int i = 1; i <= m; i++)
		idx[i] = i;
	int ans = 0;
	do {
		for (int i = 1; i <= n; i++)
			mp[i].fill(0);
		for (int i = 1; i <= m; i++)
			mp[isl[i].fi][isl[i].se] = 1;
		bool _flg = false;
		for (int i = 1; i <= m; i++) {
			bool flg = false;
			if (idx[i] <= n) {
				for (int j = 0; j <= n; j++) {
					if (!mp[idx[i]][j]) continue;
					flg = true;
					mp[idx[i]][j] = 0;
					break;
				}
			}
			else {
				for (int j = 0; j <= n; j++) {
					if (!mp[j][idx[i] - n]) continue;
					flg = true;
					mp[j][idx[i] - n] = 0;
					break;
				}
			}
			if (!flg) _flg = true;
		}
		if (!_flg) ans++;
	} while(next_permutation(idx.begin() + 1, idx.begin() + 1 + m));
	write(ans), puts("");
	return 0;
}

}

namespace Subtask2 {

const int N = 1e5 + 5;

int main(int n) {
	puts("0");
	return 0;
}

}

int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	int n = read();
	if (n <= 5) return Subtask1::main(n);
	else return Subtask2::main(n);
}
