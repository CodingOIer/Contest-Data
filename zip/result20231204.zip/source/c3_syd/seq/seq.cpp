#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <string>
#include <vector>
using namespace std;
#ifdef ONLINE_JUDGE

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

#endif

vector <int> _;
vector <string> __;

int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	_.push_back(p * flg);
	return p * flg;
}
string read_() {
	string ans;
	char c = getchar();
	while (c != '(' && c != ')')
		c = getchar();
	while (c == '(' || c == ')') {
		ans += c;
		c = getchar();
	}
	__.push_back(ans);
	return ans;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}
const int N = 1e6 + 5;



namespace Subtask1 {

int ___ = 0, ____ = 0;
int read() { return _[___++]; }
string read_() { return __[____++]; }

array <string, 4> mp;
array <array <int, N>, 4> isl;

void solve() {
	string s = read_(), tp;
	tp = s;
	int n = s.size();
	int len = ((int)(1.2e5 - 1) / n) + 1;
	for (int i = 1; i <= len; i++) s = tp + s;
	s = s + s;
	mp[0] = s;
	isl[0][0] = (mp[0][0] == '(');
	for (int j = 1; j < (int)mp[0].size(); j++)
		isl[0][j] = isl[0][j - 1] + (mp[0][j] == '(');
	/* write(isl[0][1]), puts("@"); */
	for (int i = 1; i <= 3; i++) {
		mp[i] = mp[0];
		for (int j = 1; j < (int)mp[i - 1].size() - 1; j++) {
			if (mp[i - 1][j] == '(') mp[i][j] = mp[i - 1][j + 1];
			else mp[i][j] = mp[i - 1][j - 1];
		}
		isl[i][0] = (mp[i][0] == '(');
		for (int j = 1; j < (int)mp[i - 1].size(); j++)
			isl[i][j] = isl[i][j - 1] + (mp[i][j] == '(');
	}
	/* printf("%s\n", mp[1].c_str()); */
	int q = read();
	while (q--) {
		int k = read(), l = read(), r = read();
		l += len * n, r += len * n;
		write(isl[k][r] - isl[k][l - 1]), puts("");
	}
}
int main() {
	int T = read();
	while (T--) solve();
	return 0;
}

}

namespace Subtask2 {


void solve() {

}

int main() {
	int T = read();
	while (T--) solve();
	return 0;
}

}

bool flg = 0;

void solve() {
	string s = read_();
	int q = read();
	while (q--) {
		int k = read(); read(); read();
		if (k > 3) flg = 1;
	}
}

int main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
	int T = read();
	while (T--) solve();
	if (!flg) Subtask1::main();
	else Subtask2::main();
	return 0;
}
