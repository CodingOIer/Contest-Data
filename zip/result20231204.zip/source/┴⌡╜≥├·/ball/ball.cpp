#include<bits/stdc++.h>
#define int long long
#define N 110
using namespace std;
int n, ans;
int a[N][N], b[N][N], now[N], vis[N];
void dfs(int k) {
	if(k > 2 * n) {
		for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++) b[i][j] = a[i][j];
		for(int i = 1; i <= 2 * n; i++) {
			int x, y;
			if(now[i] <= n) {
				x = now[i], y = 0;
				bool flag = 1;
				while(1) {
					y++;
					if(b[x][y] == 1) {
						b[x][y] = 0;
						break;
					}
					if(y > n) {
						flag = 0;
						break;
					} 
				}
				if(!flag) return;
			} 
			else {
				bool flag = 1;
				x = 0, y = now[i] - n;
				while(1) {
				    x++;
				    if(b[x][y] == 1) {
					    b[x][y] = 0;
					    break;
			 	    }
				    if(x > n) {
					    flag = 0;
					    break;
				    }
			    }
				if(!flag) return;
			}
		}
		ans++;
		return;
	}
	for(int i = 1; i <= 2 * n; i++) {
		if(vis[i]) continue;
		now[k] = i;
		vis[i] = 1;
		dfs(k + 1);
		vis[i] = 0;
	}
}
signed main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
    cin >> n;
    for(int i = 1; i <= 2 * n; i++) {
    	int x, y;
    	cin >> x >> y;
		a[x][y] = 1; 
	}
	if(n <= 5) {
		dfs(1);
	    cout << ans;
	}
	else cout << 0;
	return 0; 
}

