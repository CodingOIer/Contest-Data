#include<bits/stdc++.h>
#define int long long
#define N 16010
using namespace std;
int n, ans;
int a[N], sum[N], sum1[N], sum0[N];
int Red, Black; 
void work(int x, int y, int A, int B) {
	Red = sum[y] - sum[x - 1], Black = sum[B] - sum[A - 1];
    int L = y + 1, R = A - 1;
    			//if(x == 2) cout << x << " " << y << " " << A << " " << B << " : ";
    if(L <= R) {
        if((R - L + 1) % 2 == 0) {
    	    if(R % 2 == 0) Red += sum0[R] - sum0[L - 1];
    	    else Red += sum1[R] - sum1[L - 1];
    	    if((R - 1) % 2 == 0) Black += sum0[R - 1] - sum0[L - 2];
    	    else Black += sum1[R - 1] - sum1[L - 2];
	    }
        else {
    	    if(R % 2 == 0) Red += sum0[R] - sum0[L - 2];
    	    else Red += sum1[R] - sum1[L - 2];
    	    if((R - 1) % 2 == 0) Black += sum0[R - 1] - sum0[L - 1];
    	    else Black += sum1[R - 1] - sum1[L - 1];
	    }
    }
}
signed main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
    scanf("%lld", &n);
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for(int i = n + 1; i <= 2 * n; i++) a[i] = a[i - n];
    for(int i = 1; i <= 2 * n; i++) sum[i] = sum[i - 1] + a[i];
    for(int i = 1; i <= 2 * n; i++) {
    	if(i % 2 == 1) {
    		sum1[i] = a[i];
    		if(i != 1) sum1[i] += sum1[i - 2];
		}
		else {
			sum0[i] = a[i] + sum0[i - 2];
		}
	}
    for(int x = 1; x <= n; x++) {
    	ans = 1e18;
    	int B = x + n - 1;
    	for(int y = x; y <= x + n - 2; y++) {
    		
			ans = min(ans, abs(sum[y] - sum[x - 1] - (sum[B] - sum[y])));
			int L = y + 1, R = B - 1;
			int l = 1, r = (R - L + 1) / 2, mid;
			while(l <= r) {
				mid = (l + r) / 2;
				int now = L - 1 + 2 * mid;
				work(x, y, now + 1, B);
				ans = min(ans, abs(Red - Black));
				if(Red >= Black) {
					r = mid - 1;
				}
				else l = mid + 1;
			}
			l = 1, r = (R - L + 1) / 2;
			while(l <= r) {
				mid = (l + r) / 2;
				int now = L - 1 + 2 * mid;
				work(x, y, now + 1, B);
				ans = min(ans, abs(Red - Black));
				if(Red <= Black) {
					l = mid + 1;
				}
				else r = mid - 1;
			}
		}
		printf("%lld\n", ans);
	}
	return 0;
}









