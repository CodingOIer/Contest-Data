#include<bits/stdc++.h>
#define int long long
#define N 300005
using namespace std;
int T, n, q, H = 100100;
char S[6][N + 1000]; 
int sum[6][N + 1000];
signed main() {
	freopen("seq.in", "r", stdin);
	freopen("seq.out", "w", stdout);
    scanf("%lld", &T);
    while(T--) {
    	string s;
    	cin >> s;
    	n = s.length();
    	for(int i = 0; i < n; i++) S[0][i + H] = s[i];
    	for(int i = n; i <= H; i++) S[0][i + H] = S[0][i + H - n];
    	for(int i = -1; i >= -H; i--) S[0][i + H] = S[0][i + H + n];
       
        for(int k = 1; k <= 3; k++) {
        	for(int i = -H; i <= H; i++) {
        		if(S[k - 1][i + H] == '(') S[k][i + H] = S[k - 1][i + 1 + H];
        		else S[k][i + H] = S[k - 1][i - 1 + H];
			}
		}
		for(int k = 0; k <= 3; k++)
		for(int i = -H; i <= H; i++) {
			sum[k][i + H] = sum[k][i + H - 1];
			if(S[k][i + H] == '(') sum[k][i + H]++;
		}
    	scanf("%lld", &q);
    	while(q--) {
    		int k, l, r;
    		scanf("%lld %lld %lld", &k, &l, &r);
    		printf("%lld\n", sum[k][r + H] - sum[k][l - 1 + H]);
		}
		
	}
	return 0;
}
/*
1
))()(
3
3 -4 -1
*/

/*
2
(())
3
0 -3 2
1 -2 3
2 0 0
))()(
3
0 -3 4
2 1 3
3 -4 -1


*/














