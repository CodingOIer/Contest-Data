#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 20010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,a[N],ans[N],sum1[N],sum2[N],b[N],c[N];
vector<int> V1[2];
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i) a[i]=a[i+n]=read();
    for(int i=1;i<=(n<<1);++i){
        sum1[i]=sum1[i-1]+a[i];
    }
    for(int i=1;i<=(n<<1);++i){
        sum2[i]=sum2[i-2>=0?i-2:0]+a[i];
    }
    memset(ans,0x3f,sizeof(ans));
    for(int i=1;i<=(n<<1);++i){
        b[i]=sum1[i-1]+sum2[i-1]-sum2[max(0ll,i-2)];
        c[i]=sum2[i-1]-sum2[i]+sum1[i];
    }
    for(int i=1;i<=n;++i) V1[i&1].pk(b[i]);
    sort(V1[0].begin(),V1[0].end());
    sort(V1[1].begin(),V1[1].end());
    for(int i=1;i<=n;++i){
        // for(int p=i;p<=i+n-1;++p){
        //     for(int q=i;q<=i+n-1;++q) if((p&1)!=(q&1)){
        //         ans[i]=min(ans[i],abs(b[p]+b[q]-sum1[i+n-1]-sum1[i-1]));
        //     }
        // }
        // ans[i]=min(ans[i],abs(a[i]-(sum1[i+n-1]-sum1[i])));
        // ans[i]=min(ans[i],abs(sum1[i+n-2]-sum1[i-1]-a[i+n-1]));
        int now=V1[0].size()-1;
        for(auto x:V1[1]){
            while(now>0&&V1[0][now-1]+x-sum1[i+n-1]-sum1[i-1]>=0) --now;
            ans[i]=min(ans[i],abs(V1[0][now]+x-sum1[i+n-1]-sum1[i-1]));
            --now;
            if(now>=0) ans[i]=min(ans[i],abs(x+V1[0][now]-sum1[i+n-1]-sum1[i-1]));
            ++now;
        }
        int l=i&1;
        for(int j=0;j<(int)V1[l].size();++j){
            if(V1[l][j]==b[i]){
                while(j<(int)V1[l].size()-1){
                    swap(V1[l][j],V1[l][j+1]);++j;
                }
                V1[l].pop_back();
            }
        }
        l=(i+n)&1;
        V1[l].pk(b[i+n]);
        int x=V1[l].size()-1;
        while(x>0&&V1[l][x]<V1[l][x-1]){
            swap(V1[l][x],V1[l][x-1]);--x;
        }
    }
    for(int i=1;i<=n;++i){
        write(ans[i]);putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}