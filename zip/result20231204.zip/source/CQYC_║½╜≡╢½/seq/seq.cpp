#include<bits/stdc++.h>
#define int long long
#define uint unsigned long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define inf (int)(1000000000000000000)
#define base 200003
using namespace std;
bool ppp;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
// char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,Q,sum[200][N],n,xhj;
map<uint,int> mp;
char S[200][N];
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
    T=read();
    while(T--){
        mp.clear();
        scanf(" %s",S[0]);
        n=strlen(S[0]);
        uint Hash=0;
        for(int j=0;j<n;++j) Hash=Hash*base+S[0][j];
        mp[Hash]=0;
        xhj=200;
        for(int k=1;k<200;++k){
            for(int j=0;j<n;++j)
                if(S[k-1][j]=='(') S[k][j]=S[k-1][(j+1)%n];
                else S[k][j]=S[k-1][(j-1+n)%n];
            Hash=0;
            for(int j=0;j<n;++j) Hash=Hash*base+S[k][j];
            if(mp.count(Hash)){
                xhj=k;break;
            }
        }
        // cerr<<xhj<<" ";
        for(int k=0;k<xhj;++k)
            for(int j=0;j<n;++j) sum[k][j]=(j?sum[k][j-1]:0)+(S[k][j]=='(');
        Q=read();
        while(Q--){
            int k=read()%xhj,l=read(),r=read();
            if(l<0){
                int tmp=l/n+1;
                l=l+tmp*n;r=r+tmp*n;
            }
            if((l/n)!=(r/n)){
                int ans=(r/n-l/n-1)*sum[k][n-1];
                ans+=sum[k][n-1]-sum[k][(l%n+n)%n-1];
                ans+=sum[k][(r%n+n)%n];
                write(ans);putchar('\n');
            }
            else{
                // cerr<<(l%n)<<" "<<(r%n)<<"\n";
                write(sum[k][(r%n+n)%n]-sum[k][(l%n+n)%n-1]);putchar('\n');
            }
        }
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}