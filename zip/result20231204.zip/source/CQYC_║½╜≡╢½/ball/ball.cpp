#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
#define mod 1000000007
using namespace std;
bool ppp;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,b[N],ans;
bool vis[N];
pii a[N];
set<int> Sx[N],Sy[N];
il bool check(){
    for(int i=1;i<=n;++i){
        Sx[i].clear();Sy[i].clear();
    }
    for(int i=1;i<=(n<<1);++i){
        Sx[a[i].fi].insert(a[i].se);
        Sy[a[i].se].insert(a[i].fi);
    }
    for(int i=1;i<=(n<<1);++i){
        if(b[i]>n){
            if(Sy[b[i]-n].empty()) return 0;
            b[i]-=n;
            int x=*Sy[b[i]].begin();
            Sy[b[i]].erase(Sy[b[i]].begin());
            Sx[x].erase(b[i]);
            b[i]+=n;
        }
        else{
            if(Sx[b[i]].empty()) return 0;
            int y=*Sx[b[i]].begin();
            Sx[b[i]].erase(Sx[b[i]].begin());
            Sy[y].erase(b[i]);
        }
    }
    return 1;
}
il void dfs(int x){
    if(x>(n<<1)){
        if(check()) ++ans;
        return;
    }
    for(int i=1;i<=(n<<1);++i) if(!vis[i]){
        b[x]=i;vis[i]=1;dfs(x+1);vis[i]=0;
    }
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
    n=read();
    for(int i=1;i<=(n<<1);++i){
        a[i].fi=read();a[i].se=read();
    }
    if(n<=5){
        dfs(1);write(ans);
    }
    else puts("0");
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}