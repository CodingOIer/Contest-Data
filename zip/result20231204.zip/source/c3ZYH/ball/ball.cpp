#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=2e5+5,Mod=1e9+7;
char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n;
int x[N],y[N]; 
int visx[N],visy[N];
bool vis[N];
bool bk[N];
int ans=0;
void dfs(int now){
	if(now==2*n+1){
		ans++;
		return;
	}
	for(int i=1;i<=n;i++){
		if(visx[i]&&!bk[i]){
			int gg=1e16,p=0;
			for(int j=1;j<=2*n;j++){
				if(vis[j]) continue;
				if(x[j]==i){
					if(gg>y[j]) {
						gg=y[j];
						p=j;
					}
				}
			} 
			if(!p) continue;
			vis[p]=1;
			visx[x[p]]--;
			visy[y[p]]--;
			bk[i]=1;
			dfs(now+1);
			bk[i]=0;
			vis[p]=0;
			visx[x[p]]++;
			visy[y[p]]++;
		}
	}
	for(int i=1;i<=n;i++){
		if(visy[i]&&!bk[i+n]){
			int gg=1e16,p;
			for(int j=1;j<=2*n;j++){
				if(vis[j]) continue;
				if(y[j]==i){
					if(gg>x[j]) {
						gg=x[j];
						p=j;
					}
				}
			} 
			if(!p) continue;
			vis[p]=1;
			visx[x[p]]--;
			visy[y[p]]--;
			bk[i+n]=1;
			dfs(now+1);
			bk[i+n]=0;
			vis[p]=0;
			visx[x[p]]++;
			visy[y[p]]++;
		}
	}
}
int fac[N];
inline int ksm(int aa,int bb){
	int res=1;
	while(bb){
		if(bb&1) res=res*aa%Mod;;
		aa=aa*aa%Mod;
		bb>>=1;
	}
	return res;
}
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=read();
	for(int i=1;i<=2*n;i++){
		x[i]=read(),y[i]=read();
		visx[x[i]]++;
		visy[y[i]]++;
	}
	int Il=0;
	for(int i=1;i<=n;i++){
		if(visx[i]==n){
			Il=i;
			break;
		}
	}
	if(n<=5){
		dfs(1);
		cout<<ans<<endl;
		return 0;
	}
	if(Il==0){
		cout<<0;
		return 0;
	}
	fac[0]=1;
	for(int i=1;i<=n;i++){
		fac[i]=fac[i-1]*i%Mod;
	}
	int js=0,p=0;
	for(int i=1;i<=2*n;i++){
		if(x[i]<Il) js++,p=i;
	}
	if(js>1){
		cout<<0<<endl;
		return 0;
	}
	if(js==1){
		bool flagzaa=0;
		for(int i=1;i<=n;i++){
			if(visx[i]>1&&visx[i]!=n) flagzaa=1;
		}
		if(flagzaa==1){
			cout<<0<<endl;
			return 0;
		}
		int ans=fac[y[p]-1]*fac[n-y[p]]%Mod;
		ans*=ksm(n+1,n)%Mod;
		ans%=Mod;
		cout<<ans<<endl;
		return 0;
	}
	else{
		int ans=0;
		ans+=fac[n]*ksm(n,n)%Mod;
		for(int i=1;i<=n;i++){
			int sum=fac[i-1]*fac[n-i]%Mod;
			sum*=ksm(n+1,n);
			ans+=sum%Mod;
			ans%=Mod;
		}
		cout<<ans<<endl;
		return 0; 
	}
	return 0;
}

