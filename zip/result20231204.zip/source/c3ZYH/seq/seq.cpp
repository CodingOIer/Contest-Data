#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=2e7+5;
char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,q;
char s[105][200005];
int sum[105];
int qzh[105][200005];
int hzh[105][200005];
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	int T=read();
	while(T--){
		scanf("%s",s[0]);
		n=strlen(s[0]);
		q=read();
		memset(sum,0,sizeof(sum)); 
		memset(qzh,0,sizeof(qzh)); 
		memset(hzh,0,sizeof(hzh)); 
		for(int i=1;i<=100;i++){
			for(int j=0;j<n;j++){	
				if(s[i-1][j]=='(') s[i][j]=s[i-1][(j+1)%n];
				else s[i][j]=s[i-1][(j-1+n)%n];
			}
		}
		for(int i=0;i<=100;i++){
			for(int j=0;j<n;j++){
				if(j>=1)qzh[i][j]=qzh[i][j-1];
				if(s[i][j]=='(')sum[i]++,qzh[i][j]++;
			}
			hzh[i][n]=0;
			for(int j=n-1;j>=0;j--){
				hzh[i][j]=hzh[i][j+1];
				if(s[i][j]=='(') hzh[i][j]++;
			}
		}
//		for(int i=1;i<=n;i++) cout<<qzh[2][i-1];
		while(q--){
			int k=read(),l=read(),r=read();
			if(k<=100){
				int ans=((r+1)/n)*sum[k]-(l/n)*sum[k];
				if((r+1)%n==0);
				else if(r<0) ans-=hzh[k][((r+1)%n+n)%n]; 
				else ans+=qzh[k][r%n]; 
				if(l%n==0);
				else if(l<0) ans+=hzh[k][(l%n+n)%n];
				else ans-=qzh[k][(l-1)%n];
				cout<<ans<<endl;
			}
		}
	} 
	return 0;
}

