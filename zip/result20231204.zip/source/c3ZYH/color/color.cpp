#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=2e5+5;
char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,a[N];
int b[N];
int se1[N],se2[N];
int S[N];
int tot,q[N][105];
int gg[205];
int ggb[205];
void dfs(int x,int sum,int lst){
	if(sum>=n) return;
	int qzh=0;
	memset(gg,0,sizeof(gg));
	memset(ggb,0,sizeof(ggb));
	for(int i=1;i<=x;i++){
		qzh+=S[i];
		gg[i]=qzh;
	}
	int l=1;
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(gg[l]==i&&l!=x+1){
			l++;
			continue;
		}
		ggb[++cnt]=i;
	}
	bool flag=0;
	for(int i=2;i<cnt;i++)
		if(ggb[i+1]-ggb[i]>ggb[i]-ggb[i-1]){
//			cout<<114514;
			return;
		}
	if(!flag){
		qzh=0;
		tot++;
		for(int i=1;i<=x;i++){
			qzh+=S[i];
			q[tot][i]=qzh;
		}
	}
	if(sum+lst>n) return;
	for(int i=lst;i<=n-sum;i++){
		S[x+1]=i;
		dfs(x+1,sum+i,i);
		S[x+1]=0;
	}
}
signed main(){
//	freopen("color_sample3.in","r",stdin);
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	if(n<=20){
		for(int i=0;i<n;i++){
			int ans=1e16;
			for(int j=1;j<=n;j++)
				b[(j-i+n-1)%n+1]=a[j];
			for(int s=1;s<(1<<(n-1));s+=2){
				int tota=0,totb=0;
				for(int j=1;j<=n;j++){
					if((s&(1<<(j-1)))) se1[++tota]=j;
					else se2[++totb]=j;
				}
//				cout<<endl;
				bool flag=0;
				for(int j=2;j<tota;j++)
					if(se1[j+1]-se1[j]<se1[j]-se1[j-1]){
						flag=1;
						break;
					}
				if(flag) continue;
				for(int j=2;j<totb;j++)
					if(se2[j+1]-se2[j]>se2[j]-se2[j-1]){
						flag=1;
						break;
					}
				if(flag) continue;
//				for(int j=1;j<=tota;j++){
//					cout<<b[se1[j]]<<" ";
//				}
//				cout<<endl;
//				for(int j=1;j<=totb;j++){
//					cout<<b[se2[j]]<<" ";
//				}
//				cout<<endl;
				int sum=0;
				for(int j=1;j<=n;j++){
					if((s&(1<<(j-1)))) sum+=b[j];
					else sum-=b[j];
				}
				ans=min(ans,abs(sum));
			}
//			cout<<tot<<endl;
			printf("%lld\n",ans);
		}
		return 0;
	}
	else{
		S[1]=1;
		dfs(1,1,1);
		S[1]=0;
//		for(int s=1;s<=tot;s++){
//			for(int j=1;j<=n;j++){
//				if(q[s][j]) cout<<q[s][j]<<" ";
//				else break;
//			}
//			cout<<endl;
//		}
//		cout<<tot<<endl;
		for(int i=0;i<n;i++){
			int ans=1e16;
			int sans=0;
			for(int j=1;j<=n;j++)
				b[(j-i+n-1)%n+1]=a[j],sans+=a[j];
//			for(int j=1;j<=n;j++) cout<<b[j]<<" ";
//			cout<<endl;
			for(int s=1;s<=tot;s++){
				int tota=0;
				int sum=0,l=1;
				for(int j=1;j<=n;j++){
					if(q[s][j])se1[++tota]=q[s][j],sum+=b[q[s][j]];
					else break;
				}
				ans=min(ans,abs(sum-(sans-sum)));
//				cout<<sum<<endl;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
