#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=15;
ll n; 
ll p[Maxn],ans;
ll b[Maxn][Maxn],c[Maxn][Maxn];

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=2*n;i++) p[i]=i;
	
	for(ll i=1;i<=2*n;i++){
		ll x,y;
		scanf("%lld%lld",&x,&y);
		b[x][y]=1;
	}
	
	do{
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=n;j++)
				c[i][j]=b[i][j];
		
		for(ll i=1;i<=2*n;i++){
			if(p[i]>n){
				ll x=p[i]-n,y=0;
				while(!c[x][y]&&y<=n) y++;
				c[x][y]=0;
			}
			else{
				ll x=0,y=p[i];
				while(!c[x][y]&&x<=n) x++;
				c[x][y]=0;
			}
		}
		bool flg=1;
		for(ll i=1;i<=n;i++)
			for(ll j=1;j<=n;j++)
				flg&=(c[i][j]==0);
		if(flg) ans++;
	} while(next_permutation(p+1,p+2*n+1));
	
	printf("%lld",ans);
	
	return 0;
}
/*
2
1 1
1 2
2 1
2 2

4
1 1
2 2
3 3
4 4
1 2
2 1
3 4
4 3
*/

