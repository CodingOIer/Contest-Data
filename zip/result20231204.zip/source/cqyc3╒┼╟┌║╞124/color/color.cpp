#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=8010,inf=1e15;
ll n,p[Maxn],cnt;

ll a[Maxn],t;
ll ans[Maxn],sum,lp[Maxn];

inline void doit(ll x){
	for(ll i=1;i<=n;i++) lp[i]+=x*p[a[t]+i-1];
}

void DFS(ll pg,ll qwq){
	
	if(pg>=n) return ;
	
	if(qwq==3){
		for(ll i=1;i<=n;i++){
			// ��ÿ�� i Ϊ�����һ��
			ans[i]=min(ans[i],abs(lp[i]*2-sum));
		}		
		return ;
	}	
	if(qwq<=2){
		a[++t]=pg+2;doit(1);
		DFS(pg+2,2);
		doit(-1);--t;
	}
	if(qwq<=1){
		a[++t]=pg+1;doit(1);
		DFS(pg+1,1);
		doit(-1);--t;
	}
	DFS(pg,3);
	
}

int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++) scanf("%lld",&p[i]),sum+=p[i],ans[i]=inf;
	for(ll i=1;i<=n;i++) p[i+n]=p[i];
	
	a[++t]=1;doit(1);
	DFS(1,1);
	
	for(ll i=1;i<=n;i++) printf("%lld\n",ans[i]);
	
//	cout<<cnt;
	return 0;
}
/*
6
14 2 10 13 10 9

20
70 99 37 60 17 12 34 77 85 59 34 8 91 94 26 93 16 52 93 10 
*/
 
