#include <bits/stdc++.h>
#define ll long long
using namespace std;

const ll Maxn=3e5+7;
const ll V=1e5+1;

ll T;
char s[Maxn];
ll Q,n;
char B[4][Maxn];
ll Sum[4][Maxn];

inline char Getpv(ll k,ll x){
	return B[k][(x%n+n)%n];
}
inline ll Getans(ll k,ll l,ll r){
	if(k>3){
		return 114514;
	}
	return Sum[k][r+V]-Sum[k][l+V-1];
}

int main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		memset(Sum,0,sizeof Sum);
		scanf("%s",s);
		n=strlen(s);
		for(ll i=0;i<n;i++) B[0][i]=s[i]; 
		
		for(ll i=1;i<=3;i++){
			for(ll j=0;j<n;j++){
				if(Getpv(i-1,j)=='(') B[i][j]=Getpv(i-1,j+1);
				else B[i][j]=Getpv(i-1,j-1);
			}
		} 
		for(ll i=0;i<=3;i++){
			Sum[0][0]=(Getpv(i,-V)=='(');
			for(ll j=1;j<=V*2;j++){
				Sum[i][j]=Sum[i][j-1]+(Getpv(i,j-V)=='(');
			}
		}
		
		scanf("%lld",&Q);
		while(Q--){
			ll l,r,k;
			scanf("%lld%lld%lld",&k,&l,&r);
			printf("%lld\n",Getans(k,l,r));
		}
	}
	return 0;
}

/*
3
(())
3
0 -3 2
1 -2 3
2 0 0
))()(
3
0 -3 4
2 1 3 
3 -4 -1
))()(()(
4
1234 -5678 9012
123 -456 789
12 -34 56
1 -2 3
*/

