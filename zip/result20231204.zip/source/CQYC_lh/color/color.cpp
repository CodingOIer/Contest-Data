#include<bits/stdc++.h>
using namespace std;
char ch;
int read(){
    int x=0;bool f=0;ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
long long ot[40],otp;
void write(long long x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');return ;
}
const int maxn=8e3+2;
const long long inf=1e18;
int n;
long long all;
long long ar[maxn],sum[maxn];
void upd(long long &x,long long v){x=min(x,v);}
long long solve(int st){
    long long sum1=0,sum2=0,sum3=0;
    long long ans=inf;
    vector<int>ve[2];
    for(int i=0;i<n;i++){
        sum[i]=((i>1)?sum[i-2]:0)+ar[(st+i)%n];
        ve[i&1].push_back(i);
    }
    int tp[2]={0,0},siz[2]={(int)ve[0].size(),(int)ve[1].size()},now[2]={0,0};
    tp[0]=siz[0]-1,tp[1]=siz[1]-1;
    for(int i=0;i<n-1;i++){
        now[i&1]++;
        sum1+=ar[(st+i)%n];
        upd(ans,abs(sum1-(all-sum1)));
        // if(st==2&&tp[i&1]<siz[i&1])printf("tp=%d %d %lld %lld\n",tp[i&1],siz[i&1],2*(sum1-sum[i]+sum[ve[i&1][tp[i&1]]]),all);
        while(tp[i&1]>=now[i&1]&&(2*(sum1-sum[i]+sum[ve[i&1][tp[i&1]]])>all))tp[i&1]--;
        // if(st==2&&tp[i&1]<siz[i&1])printf("tp=%d %d %lld %lld\n",tp[i&1],siz[i&1],2*(sum1-sum[i]+sum[ve[i&1][tp[i&1]]]),all);
        for(int j=-1,x;j<=1;j++){
            x=tp[i&1]+j;
            if(x>=0&&x<siz[i&1]&&ve[i&1][x]<n-1)upd(ans,abs(2*(sum1-sum[i]+sum[ve[i&1][x]])-all));
        }
    }
    // for(int i=1;i<n;i++){
    //     sum1+=ar[(st+i-1)%n];
    //     sum2=sum3=0;
    //     for(int j=2;j<n-i;j+=2){
    //         sum2+=ar[(st+i+j-1)%n];
    //         // sum2+=(ar[(st+i+j-1)%n]-ar[(st+i+j-1-1)%n]);
    //         // sum3+=(ar[(st+i+j-1)%n]+ar[(st+i+j-1-1)%n]);
    //         // ans=min(ans,abs(2*sum1+sum2+sum3-all));
    //         ans=min(ans,abs(2*(sum1+sum2)-all));
    //         // if(abs(2*(sum1+sum2)-all)==3&&st==2)printf("va %d %d\n",i,j);
    //     }
    // }
    return ans;
}
int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read();
    for(int i=0;i<n;i++)ar[i]=read(),all+=ar[i];
    for(int i=0;i<n;i++){
        write(solve(i)),putchar('\n');
    }
    return 0;
}