#include<bits/stdc++.h>
using namespace std;
char ch;
int read(){
    int x=0;bool f=0;ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=1e5+2;
const int mod=1e9+7;
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int n;
struct node{
    int x,y;
}p[maxn];
namespace brute1{
    bool vis[21],use[21];
    int pe[21];
    int nowx[21],nowy[21];
    vector<int>vex[21],vey[21];
    int ans;
    void dev(int x){
        if(x==2*n+1){
            for(int i=1;i<=2*n;i++)use[i]=0,nowx[i]=nowy[i]=0;
            // printf("P:\n");
            // for(int i=1;i<=2*n;i++)printf("%d ",pe[i]);putchar('\n');
            for(int i=1,v;i<=2*n;i++){
                v=pe[i];
                if(v<=n){
                    while(nowx[v]<vex[v].size()&&use[vex[v][nowx[v]]])nowx[v]++;
                    if(nowx[v]==vex[v].size())return ;
                    use[vex[v][nowx[v]]]=1;
                }
                else {
                    v-=n;
                    while(nowy[v]<vey[v].size()&&use[vey[v][nowy[v]]])nowy[v]++;
                    if(nowy[v]==vey[v].size())return ;
                    use[vey[v][nowy[v]]]=1;
                }
            }
            upd(ans,1);
            return ;
        }
        for(int i=1;i<=2*n;i++){
            if(vis[i])continue;
            vis[i]=1,pe[x]=i;
            dev(x+1);
            vis[i]=0;
        }
        return ;
    }
    bool cmpx(int A,int B){return p[A].x<p[B].x;}
    bool cmpy(int A,int B){return p[A].y<p[B].y;}
    void solve(){
        for(int i=1;i<=2*n;i++)vex[p[i].x].push_back(i),vey[p[i].y].push_back(i);
        for(int i=1;i<=n;i++){
            sort(vex[i].begin(),vex[i].end(),cmpy);
            sort(vey[i].begin(),vey[i].end(),cmpx);
        }
        dev(1);
        printf("%d\n",ans);
        return ;
    }
}
int main(){
    freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
    n=read();
    for(int i=1;i<=2*n;i++)p[i].x=read(),p[i].y=read();
    if(n<=5)brute1::solve();
    return 0;
}