#include<bits/stdc++.h>
using namespace std;
char ch;
int read(){
    int x=0;bool f=0;ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2;
int T;
int n,Q;
char s[maxn];
namespace brute1{
    int br[4][maxn],sum[4][maxn];
    void pre(int ty){
        for(int i=0;i<n;i++){
            if(!br[ty-1][i])br[ty][i]=br[ty-1][(i-1+n)%n];
            else br[ty][i]=br[ty-1][(i+1)%n];
        }
    }
    int query(int ty,int l,int r){
        if(l<0)r+=((-l)/n+((-l)%n>0))*n,l+=((-l)/n+((-l)%n>0))*n;
        // if(l<0)printf("chao!\n");
        // printf("query %d %d %d\n",ty,l,r);
        if(ty>3)return -1;
        int L=l/n+(l%n>0),R=r/n,ret=0;
        ret+=sum[ty][n-1]*(R-L);
        if(l%n)ret+=(sum[ty][n-1]-sum[ty][l%n-1]);
        if(r%n)ret+=sum[ty][r%n];
        return ret;
    }
    void solve(){
        for(int i=0;i<n;i++)br[0][i]=(s[i]==')');
        for(int i=1;i<=3;i++)pre(i);
        for(int ty=0;ty<=4;ty++){
            for(int i=0;i<n;i++)sum[ty][i]=sum[ty][i-1]+(br[ty][i]==0);
        }
        Q=read();
        int k,l,r;
        for(int i=1;i<=Q;i++){
            k=read(),l=read(),r=read();
            printf("%d\n",query(k,l,r));
        }
    }
}
int main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    T=read();
    while(T--){
        // printf("T=%d\n",T);
        scanf("%s",s);
        n=strlen(s);
        brute1::solve();
    }
    return 0;
}