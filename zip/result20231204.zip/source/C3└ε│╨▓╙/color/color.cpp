#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int sum;
int a[16005];
int s[16005];
signed main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		a[i+n]=a[i];
		sum+=a[i];
	}
	if(n<=1000){
		for(int i=1;i<=n;i++){
			int ans=1e18,suma=0,h=0;
			for(int j=i;j<i+n-1;j++){
				h+=a[j];
				ans=min(ans,abs(sum-h-h));
				suma=0;
				for(int k=j+2;k<i+n-1;k+=2){
					suma+=a[k];
					ans=min(ans,abs(sum-h-suma-h-suma));
				}
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
	s[1]=a[1];
	for(int i=2;i<=n*2;i++) s[i]=s[i-2]+a[i];
	for(int i=1;i<=n;i++){
		int ans=1e18,h=0,r;
		h=a[i];
		if(n&1) r=i+n-3;
		else r=i+n-2;
		int R=r;
		for(int j=i;j<=r;j+=2){
			if(j!=i) h+=a[j]+a[j-1];
			while(r>j&&s[r]-s[j]+h>sum-(s[r]-s[j]+h)) r-=2;
			ans=min(ans,abs(sum-(s[r]-s[j]+h)-(s[r]-s[j]+h)));
			if(r<R) ans=min(ans,abs(sum-(s[r+2]-s[j]+h)-(s[r+2]-s[j]+h)));
		}
		h=a[i]+a[i+1];
		if(n&1) r=i+n-2;
		else r=i+n-3;
		R=r;
		for(int j=i+1;j<=r;j+=2){
			if(j!=i+1) h+=a[j]+a[j-1];
			while(r>j&&s[r]-s[j]+h>sum-(s[r]-s[j]+h)) r-=2;
			ans=min(ans,abs(sum-(s[r]-s[j]+h)-(s[r]-s[j]+h)));
			if(r<R) ans=min(ans,abs(sum-(s[r+2]-s[j]+h)-(s[r+2]-s[j]+h)));
		}
		printf("%lld\n",ans);
	}
	return 0;
}
