#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
int a[105][105];
int ans;
bool vis1[105],vis2[105];
const int mod=1000000007;
void dfs(int x){
	if(x>2*n){
		ans++;
		if(ans>=mod) ans-=mod;
		return;
	}
	for(int i=1;i<=n;i++){
		if(vis1[i]) continue;
		for(int j=1;j<=n;j++){
			if(a[i][j]){
				a[i][j]--;
				vis1[i]=1;
				dfs(x+1);
				vis1[i]=0;
				a[i][j]++;
				break;
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(vis2[i]) continue;
		for(int j=1;j<=n;j++){
			if(a[j][i]){
				a[j][i]--;
				vis2[i]=1;
				dfs(x+1);
				vis2[i]=0;
				a[j][i]++;
				break;
			}
		}
	}
}
signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=2*n;i++){
		int x,y;
		scanf("%lld %lld",&x,&y);
		a[x][y]++;
	}
	dfs(1);
	printf("%lld",ans%mod);
	return 0;
}
