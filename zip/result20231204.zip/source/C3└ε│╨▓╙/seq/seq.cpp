#include<bits/stdc++.h>
#define int long long
using namespace std;
int T;
int q;
int sum[5][100005];
string t;
char s[5][100005];
int w(int x,int y){
	if(x<0) return x/y;
	return (x+y-1)/y;
}
int z(int x,int y){
	if(x<0){
		if(x%y==0) return x/y;
		return x/y-1;
	}
	return x/y;
}
signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		cin>>t;
		int n=t.size();
		for(int i=1;i<n;i++) s[0][i]=t[i];
		s[0][n]=t[0];
		scanf("%lld",&q);
		for(int i=1;i<=3;i++){
			for(int j=1;j<=n;j++){
				int o;
				if(s[i-1][j]==')'){
					o=j-1;
					if(o==0) o=n;
					s[i][j]=s[i-1][o];
				}
				else{
					o=j+1;
					if(o>n) o=1;
					s[i][j]=s[i-1][o];
				}
			}
		}
		for(int i=0;i<=3;i++){
			for(int j=1;j<=n;j++){
				sum[i][j]=sum[i][j-1]+(s[i][j]=='(');
			}
		}
		while(q--){
			int k,l,r,ans=0;
			scanf("%lld %lld %lld",&k,&l,&r);
			l--;
			if(z(r,n)-w(l,n)<0){
				ans=sum[k][(r%n+n)%n]-sum[k][(l%n+n)%n];
				printf("%lld\n",ans);
				continue;
			}
			ans+=(z(r,n)-w(l,n))*sum[k][n];		
			if(r%n!=0) ans+=sum[k][(r%n+n)%n];
			if(l%n!=0) ans+=sum[k][n]-sum[k][(l%n+n)%n];
			printf("%lld\n",ans);
		}
	}
	return 0;
}
