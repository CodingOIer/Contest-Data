#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define mp make_pair
#define ll long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(ll x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=8010;
int N,A[Maxn];
ll Sum[Maxn],Ans,Val[Maxn];

signed main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    N=read(); 
    For(i,1,N) A[i]=read(),Sum[i]=Sum[i-1]+A[i];
    For(i,1,N) Val[i]=Val[i-1]+((i&1)?A[i]:-A[i]);
    For(s,1,N){
        int t=(s-2+N)%N+1;
        Ans=Sum[N];
        For(i,1,N-1) For(j,1,N-i){
            if((N-i-j)&1) continue;
            ll ret=0;

            //mid
            if(i+j!=N){
                int l=(s+i-1)%N+1,r=(t-j-1+N)%N+1;
                ll tmp=0;
                if(l<=r){
                    tmp=Val[r]-Val[l-1];
                    if(l&1) tmp=-tmp;
                }
                else{
                    if(l&1) tmp=Val[l-1]-Val[N];
                    else tmp=Val[N]-Val[l-1];
                    if((N-l+1)&1) tmp+=Val[r];
                    else tmp-=Val[r];
                }
                ret=tmp;
            }
            
            //front
            int p1=(s+i-2)%N+1;
            if(p1>=s) ret+=Sum[p1]-Sum[s-1];
            else ret+=Sum[N]-Sum[s-1]+Sum[p1];

            //end
            int p2=(t-j+N)%N+1;
            if(p2<=t) ret-=(Sum[t]-Sum[p2-1]);
            else ret-=(Sum[t]+Sum[N]-Sum[p2-1]);

            Ans=min(Ans,abs(ret));
        }
        write(Ans),pc('\n');
    }
    // cerr<<"clock="<<clock()<<"\n";
    return 0;
}
/*
g++ color.cpp -o color -O2
./color
*/