#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=8e3+5;
int n,a[maxn],ans[maxn],sum;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int calc(int x,int y){
    x+=y;
    if(x>n)
        x-=n;
    return x;
}
signed main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        a[i]=read(),sum+=a[i],ans[i]=1e18;
    for(int i=1;i<=n;i++){
        int x=sum-a[calc(i,1)],y=a[calc(i,1)],res=abs(x-y),r=i;
        for(int j=calc(i,1);;){
            if(j==i)
                break;
            while(calc(r,1)!=j&&calc(r,2)!=j&&res>abs(x+a[calc(r,2)]*2-y)){
                r=calc(r,2);
                x+=a[r],y-=a[r];
                res=abs(x-y);
            }
            j=calc(j,1);
            ans[j]=min(ans[j],res);
            x-=a[j],y+=a[j];
            res=abs(x-y);
        }
    }
    for(int i=1;i<=n;i++)
        printf("%lld\n",ans[i]);
    return 0;
}