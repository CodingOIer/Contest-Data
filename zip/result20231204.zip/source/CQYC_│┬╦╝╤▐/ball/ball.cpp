#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,x,y,s[10][10],ans,visx[10],visy[10];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x){
    if(x>2*n){
        ++ans;
        return;
    }
    for(int i=1;i<=n;i++)
        if(!visx[i]){
            for(int j=1;j<=n;j++)
                if(s[i][j]){
                    visx[i]=1,s[i][j]=0;
                    solve(x+1);
                    visx[i]=0,s[i][j]=1;
                    break;
                }
        }
    for(int i=1;i<=n;i++)
        if(!visy[i]){
            for(int j=1;j<=n;j++)
                if(s[j][i]){
                    visy[i]=1,s[j][i]=0;
                    solve(x+1);
                    visy[i]=0,s[j][i]=1;
                    break;
                }
        }
}
signed main(){
    freopen("ball.in","r",stdin);
    freopen("ball.out","w",stdout);
    n=read();
    for(int i=1;i<=2*n;i++){
        x=read(),y=read();
        s[x][y]=1;
    }
    solve(1);
    printf("%lld\n",ans);
    return 0;
}