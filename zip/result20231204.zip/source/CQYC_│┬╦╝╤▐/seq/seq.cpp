#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=3e5+5,sum=1e5+110;
int t,q,k,l,r,ans[5][maxn];
char a[maxn],b[5][maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("seq.in","r",stdin);
    freopen("seq.out","w",stdout);
    t=read();
    while(t--){
        scanf("%s",a);
        int n=strlen(a);
        for(int i=0;i<=1e5+100;i++)
            if(i<n)
                b[0][i+sum]=a[i];
            else
                b[0][i+sum]=b[0][i+sum-n];
        for(int i=-1;i>=-1e5-100;i--)
            b[0][i+sum]=b[0][i+sum+n];
        for(int i=1;i<=3;i++)
            for(int j=-1e5-100+sum;j<=1e5+100+sum;j++)
                if(b[i-1][j]=='(')
                    b[i][j]=b[i-1][j+1];
                else
                    b[i][j]=b[i-1][j-1];
        for(int i=0;i<=3;i++)
            for(int j=-1e5+sum;j<=1e5+sum;j++){
                if(b[i][j]=='(')
                    ans[i][j]=1;
                else
                    ans[i][j]=0;
                ans[i][j]+=ans[i][j-1];
            }
        q=read();
        while(q--){
            k=read(),l=read()+sum,r=read()+sum;
            printf("%lld\n",ans[k][r]-ans[k][l-1]);
        }
    }
    return 0;
}