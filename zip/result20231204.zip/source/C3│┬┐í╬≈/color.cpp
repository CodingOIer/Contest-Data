#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=25;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int s,n,ans,a[N];

int R[N],B[N],tpr,tpb;

void dfs(int pos,int sumr,int sumb){
	int val=a[(pos-s+n)%n+(pos==s)*n];
	if(pos==1){
		R[++tpr]=1;
		dfs(pos+1,sumr+val,sumb);
		tpr--;
		return;
	}
	if(pos==n){
		sumb+=val;
		if(tpb>=2){
			if(pos-B[tpb]<=B[tpb]-B[tpb-1])
				ans=min(ans,abs(sumr-sumb));
			return;
		}
		else ans=min(ans,abs(sumr-sumb));
		return;
	}
	if(tpr>=2){
		if(pos-R[tpr]>=R[tpr]-R[tpr-1]){
			R[++tpr]=pos;
			dfs(pos+1,sumr+val,sumb);
			tpr--;
		}	
	}
	else{
		R[++tpr]=pos;
		dfs(pos+1,sumr+val,sumb);
		tpr--;		
	}
	
	if(tpb>=2){
		if(pos-B[tpb]<=B[tpb]-B[tpb-1]){
			B[++tpb]=pos;
			dfs(pos+1,sumr,sumb+val);
			tpb--;			
		}
	}
	else{
		B[++tpb]=pos;
		dfs(pos+1,sumr,sumb+val);
		tpb--;	
	}
}

signed main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=n;i>=1;i--){
		s=i,ans=1e9;
		dfs(1,0,0);
		printf("%lld\n",ans);
	}
	return 0;
}
