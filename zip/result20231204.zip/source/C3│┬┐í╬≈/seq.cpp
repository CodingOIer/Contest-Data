#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int T,n,Q,sum[N];
char s[2][N];
void pre(){
	int x=0,y=1;
	for(int i=0;i<n;i++){
		if(s[x][i]=='('){
			if(i==n-1) s[y][i]=s[x][0];
			else s[y][i]=s[x][i+1];
		}
		else{
			if(i==0) s[y][i]=s[x][n-1];
			else s[y][i]=s[x][i-1];
		}
	}
	for(int i=0;i<n;i++) s[x][i]=s[y][i];
	for(int i=1;i<=n;i++) sum[i]=sum[i-1]+(s[x][i-1]=='(');
}

int resl(int k,int x){
	int res=0;
	x=-x;
	res=res+(x/n)*sum[n];
	x%=n;
	res=res+sum[n]-sum[n-x];
	return res;
}

int resr(int k,int x){
	int res=0;
	x++;
	res=res+(x/n)*sum[n];
	x%=n;
	res=res+sum[x];
	return res;	
}

int solve(int k,int l,int r){
	if(l<0&&r<0) return resl(k,l)-resl(k,r+1);
	if(l>=0&&r>=0) return resr(k,r)-resr(k,l-1);
	return resl(k,l)+resr(k,r);
}

int mxk,ans[N];
struct Que{
	int k,l,r;
}q[N];
vector<int> que[N<<1];

signed main(){
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);	
	T=read();
	while(T--){
		cin>>s[0];
		n=strlen(s[0]);
		for(int i=1;i<=n;i++) 
			sum[i]=sum[i-1]+(s[0][i-1]=='(');
		
		int cntl=0,cntr=0;
		for(int i=0;i<n;i++)
			cntl+=(s[0][i]=='('),cntr+=(s[0][i]==')');
		
		
		for(int i=1;i<=Q;i++)
			que[q[i].k].clear();
		
		mxk=0,Q=read();
		for(int i=1;i<=Q;i++){
			q[i].k=read();
			
			if(q[i].k>max(cntl,cntr)||q[i].k<=3){
				q[i].k-=max(cntl,cntr);
				q[i].k%=n;
				q[i].k+=max(cntl,cntr);
			}
			
			mxk=max(mxk,q[i].k);
			q[i].l=read(),q[i].r=read();
			que[q[i].k].push_back(i);
		}
		
		for(int i=0;i<=mxk;i++){
			if(i) pre();
			for(int j=0;j<que[i].size();j++){
				int id=que[i][j];
				ans[id]=solve(i,q[id].l,q[id].r);
			}
		}
		for(int i=1;i<=Q;i++) printf("%lld\n",ans[i]);
	}
	return 0;
}
