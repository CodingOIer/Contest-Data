#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=25,mod=1e9+7;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,x[N],y[N],ans;

set<int> sx[N],sy[N];
bool visx[N],visy[N];

void dfs(int pos){
	if(pos==2*n+1){
		ans++;
		return;
	}
	for(int i=1;i<=n;i++){
		if(!visx[i]&&!sx[i].empty()){
			visx[i]=1;
			int wy=*sx[i].lower_bound(1);
			sx[i].erase(wy);
			sy[wy].erase(i);
			
			dfs(pos+1);
			
			visx[i]=0;
			sx[i].insert(wy);
			sy[wy].insert(i);			
		}
	}

	for(int i=1;i<=n;i++){
		if(!visy[i]&&!sy[i].empty()){
			visy[i]=1;
			int wx=*sy[i].lower_bound(1);
			sy[i].erase(wx);
			sx[wx].erase(i);
			
			dfs(pos+1);
			
			visy[i]=0;
			sy[i].insert(wx);
			sx[wx].insert(i);			
		}
	}
}

signed main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=read();
	for(int i=1;i<=2*n;i++){
		x[i]=read(),y[i]=read();
		sx[x[i]].insert(y[i]);
		sy[y[i]].insert(x[i]);
	}
	dfs(1);
	printf("%lld",ans%mod);
	return 0;
}
