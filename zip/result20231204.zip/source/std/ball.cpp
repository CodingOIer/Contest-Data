#include<algorithm>
#include<cstdio>
#include<vector>
#define ll long long
#define pb push_back
#define MaxN 200500
using namespace std;
const int mod=1000000007;
ll powM(ll a,int t=mod-2){
  ll ret=1;
  while(t){
    if (t&1)ret=ret*a%mod;
    a=a*a%mod;t>>=1;
  }return ret;
}
ll fac[MaxN],ifac[MaxN],inv[MaxN];
void Init(int n)
{
  fac[0]=1;
  for (int i=1;i<=n;i++)
    fac[i]=fac[i-1]*i%mod;
  ifac[n]=powM(fac[n]);
  for (int i=n;i;i--)
    ifac[i-1]=ifac[i]*i%mod;
  for (int i=1;i<=n;i++)
    inv[i]=ifac[i]*fac[i-1]%mod;
}
struct UFS{
  int f[MaxN];bool vis[MaxN];
  void Init(int n)
  {for (int i=1;i<=n;i++)f[i]=i;}
  int find(int u)
  {return f[u]==u ? u : f[u]=find(f[u]);}
  bool merge(int u,int v){
    u=find(u);v=find(v);
    if (u==v)return 0;
    vis[f[u]=v]|=vis[u];return 1;
  }
}T;
vector<int> g[MaxN],id[MaxN];
void adl(int u,int v,int p){
  g[u].pb(v);id[u].pb(p);
  g[v].pb(u);id[v].pb(p);
}
bool vis[MaxN],fl[MaxN];
int n,f[MaxN],tn,st[MaxN],tn2,st2[MaxN];
void dfs1(int u,int fa)
{
  f[u]=fa;
  for (int i=0;i<g[u].size();i++)
    if (g[u][i]!=fa){
      st2[++tn2]=id[u][i];
      dfs1(g[u][i],u);
    }
}
void dfs2(int u)
{
  vis[u]=1;
  for (int i=0,v;i<g[u].size();i++)
    if (!vis[v=g[u][i]]){
      fl[id[u][i]]=v>n;
      dfs2(v);
    }
}
vector<int> g2[MaxN];
int in[MaxN],siz[MaxN];
void dfs3(int u)
{
  siz[u]=1;
  for (int i=0;i<g2[u].size();i++){
    dfs3(g2[u][i]);
    siz[u]+=siz[g2[u][i]];
  }
}
struct Line{int u,v;bool fl;}l[MaxN];
void adl2(int u,int v){g2[v].pb(u);in[u]++;}
ll calc()
{
  for (int i=1;i<=tn2;i++){
    int u=st2[i];
    if (fl[u]){
      int v=l[u].v;
      for (int j=0;j<g[v].size();j++)
        if (g[v][j]<l[u].u)
          adl2(id[v][j],u);
    }else {
      int v=l[u].u;
      for (int j=0;j<g[v].size();j++)
        if (g[v][j]<l[u].v)
          adl2(id[v][j],u);
    }
  }
  for (int i=1;i<=tn2;i++)
    if (!in[st2[i]])dfs3(st2[i]);
  ll ans=fac[tn2];
  for (int i=1;i<=tn2;i++){
    ans=ans*inv[siz[st2[i]]]%mod;
    g2[st2[i]].clear();in[st2[i]]=0;
  }return ans;
}
int main()
{
  freopen("ball.in","r",stdin);
  freopen("ball.out","w",stdout);
  scanf("%d",&n);
  T.Init(n+n);Init(n+n);
	ll ans=1;
  for (int k=1;k<=n+n;k++){
    scanf("%d%d",&l[k].u,&l[k].v);l[k].v+=n;
    if (T.merge(l[k].u,l[k].v))
      adl(l[k].u,l[k].v,k);
    else {
      int t=T.find(l[k].u);
      if (T.vis[t]){puts("0");return 0;}
      else l[k].fl=T.vis[t]=1;
    }
  }
  for (int k=1;k<=n+n;k++)
    if (l[k].fl==1){
      tn=tn2=0;dfs1(l[k].u,0);
      for (int p=l[k].v;p;p=f[p])st[++tn]=p;
      adl(l[k].u,l[k].v,k);st2[++tn2]=k;
      for (int i=1;i<=tn;i++)vis[st[i]]=1;
      for (int i=1;i<=tn;i++)dfs2(st[i]);
      for (int i=1;i<=tn;i++){
        int u=st[i];
        for (int j=0;j<g[u].size();j++)
          if (g[u][j]==(i==tn ? st[1] : st[i+1]))
            fl[id[u][j]]=u>n;
      }
      ll sav=calc();
      for (int i=1;i<=tn;i++){
        int u=st[i];
        for (int j=0;j<g[u].size();j++)
          if (g[u][j]==(i==1 ? st[tn] : st[i-1]))
            fl[id[u][j]]=u>n;
      }
      sav=(sav+calc())%mod;
      ans=ans*sav%mod*ifac[tn2]%mod;
    }
  printf("%lld",ans*fac[n+n]%mod);
	return 0;
}
