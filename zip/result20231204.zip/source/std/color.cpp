#include<bits/stdc++.h>
using namespace std;
const int N=5+2e5;
typedef long long ll;
struct K{ ll sum; int cnt; }f[N];
int a[N],n;
int main(){
	freopen("color.in","r",stdin); 
	freopen("color.out","w",stdout);
	scanf("%d",&n); ll sum=0;
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]),a[i+n]=a[i],sum+=a[i];
	f[1]=(K){2*a[1]-sum,0};
	for(int i=2;i<=n;++i) f[i]=(K){f[i-1].sum+2*a[i],0};
	for(int s=1;s<=n;++s){
		if(s>1){
			for(int j=1;j<=n-1;++j){
				f[j]=f[j+1];
				f[j].sum-=2*a[s-1];
			}
		}
		ll ans=1e18; int cnt=0;
		for(int j=1;j<=n-1;++j){
			while(j+(f[j].cnt+1)*2<=n-1&&abs(f[j].sum+a[s+j+f[j].cnt*2+1]*2)<abs(f[j].sum)){
				f[j].sum+=a[s+j+f[j].cnt*2+1]*2;
				++f[j].cnt;
			}
//			printf("[%d %lld %d]",j,f[j].sum,f[j].cnt);
//			cerr<<f[j].cnt<<endl;
			if(abs(f[j].sum)<ans) cnt=f[j].cnt;
			ans=min(ans,abs(f[j].sum));
		}
		cerr<<cnt<<endl;
		printf("%lld\n",ans);
	}
	return 0;
}
