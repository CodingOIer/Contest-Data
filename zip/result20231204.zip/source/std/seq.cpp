#include <bits/stdc++.h>
#define MAXN ((int)1e5)
#define MAXP 20
using namespace std;

int n, m, q;
char s[MAXN + 10];

int lg[MAXN + 10], rmq[MAXP][MAXN * 2 + 10];

// RMQ Ԥ���� F(0) �� F(2m - 1)

void preRmq()
{
    m = 0;
    for (int i = 0; i < n; i++)
        if (s[i] == '(')
            rmq[0][m++] = i;
    for (int i = m; i < m * 2; i++)
        rmq[0][i] = rmq[0][i - m] + n;
    for (int i = 0; i < m * 2; i++)
        rmq[0][i] -= i * 2;

    for (int p = 1; p < MAXP; p++)
        for (int i = 0, ii = (1 << p) - 1; ii < m * 2; i++, ii++)
        {
            int j = i + (1 << (p - 1));
            rmq[p][i] = min(rmq[p - 1][i], rmq[p - 1][j]);
        }
}

long long calc(long long K, long long i)
{
    long long L, R;
    // ���� n - 2m ��ֵ�������䳤����С�� min(m, k)
    if (m * 2 <= n)
    {
        L = i;
        R = min(i + K, L + m - 1);
    }
    else
    {
        R = i + K;
        L = max(i, R - m + 1);
    }

    // ������ [L, R] ӳ�䵽 [L mod m, L mod m + R - L]������ RMQ ����Сֵ
    long long div = (L >= 0 ? L / m : (L + 1) / m - 1);
    int mod = (L % m + m) % m;
    long long delta = n * div - 2 * div * m;
    int len = R - L + 1, p = lg[len];
    return min(rmq[p][mod], rmq[p][mod + len - (1 << p)]) + delta + K + 2 * i;
}

// ������ g(K, lim) ��ֵ
long long query(long long K, long long lim)
{
    long long head = -3e9, tail = 3e9;
    while (head < tail)
    {
        long long mid = (head + tail + 1) >> 1;
        if (calc(K, mid) <= lim)
            head = mid;
        else
            tail = mid - 1;
    }
    return head;
}

void solve()
{
    scanf("%s", s);
    n = strlen(s);
    preRmq();

    scanf("%d", &q);
    while (q--)
    {
        long long K, l, r;
        scanf("%lld%lld%lld", &K, &l, &r);
        // ���������û��������
        if (m == 0)
            printf("0\n");
        else
            printf("%lld\n", query(K, r) - query(K, l - 1));
    }
}

int main()
{
    freopen("seq.in", "r", stdin);
    freopen("seq.out", "w", stdout);
    lg[1] = 0;
    for (int i = 2; i <= MAXN; i++)
        lg[i] = lg[i >> 1] + 1;

    int tcase;
    scanf("%d", &tcase);
    while (tcase--)
        solve();
    return 0;
}