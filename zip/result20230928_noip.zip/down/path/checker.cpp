#include <bits/stdc++.h>
#include "testlib.h"

#define eb emplace_back
#define ep emplace
#define fi first
#define se second
#define in read<int>()
#define lin read<ll>()
#define rep(i, x, y) for(int i = (x); i <= (y); i++)
#define per(i, x, y) for(int i = (x); i >= (y); i--)

using namespace std;

using ll = long long;
using db = double;
using pii = pair < int, int >;
using vec = vector < int >;
using veg = vector < pii >;

template < typename T > T read() {
	T x = 0; bool f = 0; char ch = getchar();
	while(!isdigit(ch)) f |= ch == '-', ch = getchar();
	while(isdigit(ch)) x = x * 10 + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

template < typename T > void chkmax(T &x, const T &y) { x = x > y ? x : y; }
template < typename T > void chkmin(T &x, const T &y) { x = x < y ? x : y; }

const int N = 1e6 + 10;

bool hav[N];
bool dis[514][2010];
int edge[2010][2010];

int main(int argc, char **argv) {
	registerTestlibCmd(argc, argv);

	int Q = inf.readInt(1, 2000, "Q");
	rep(i, 1, Q) {
		int x = inf.readInt(1, 2000, "x");
		hav[x] = true;
	} 
	
	int n = ouf.readInt(1, 100, "n must in [1, 100]"), m = ouf.readInt(0, 10000, "m must in [0, 10000]");
	rep(i, 1, n) rep(j, 1, n) edge[i][j] = -1;
	rep(i, 1, m) {
		int u = ouf.readInt(1, n, "u must in [1, n]");
		int v = ouf.readInt(1, n, "v must in [1, n]");
		int w = ouf.readInt();
		if(u >= v || edge[u][v] != -1) quitf(_wa, "input invalid!");
		edge[u][v] = w;
	}
	dis[1][0] = true;
	rep(i, 1, n) {
		rep(j, i + 1, n) if(edge[i][j] != -1) {
			rep(k, 0, 2000) if(dis[i][k]) {
				if(k + edge[i][j] > 2000) quitf(_wa, "some node's dist > 2000!");
				dis[j][k + edge[i][j]] = true;
			}
		}
	}
	rep(j, 0, 2000) if(hav[j] != dis[n][j]) quitf(_wa, "check failed!");
	if(n >= 71 && n <= 100) quitp(10, "ok! 10 points get!");
	if(n >= 66 && n <= 70) quitp(30, "ok! 30 points get!");
	if(n >= 61 && n <= 65) quitp(52, "ok! 50 points get!");
	if(n >= 54 && n <= 60) quitp(52 + (61 - n) * 6, "ok! get your special score!");
	if(n <= 53) quitf(_ok, "Congratulations!");
	return 0;
}
