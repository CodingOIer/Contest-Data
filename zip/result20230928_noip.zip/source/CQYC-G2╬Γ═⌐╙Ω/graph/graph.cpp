//1.0s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10;
int N,Num[Maxn<<1],M,T[Maxn<<1],Ans,Mx;
struct node{
    int x,y;
    bool operator <(const node &t)const{return (x^t.x)?x<t.x:y<t.y;}
}A[Maxn];
multiset<int> S;

void Find(int &x){ x=lower_bound(Num+1,Num+M+1,x)-Num; }
void Modify(int i,int v){for(;i;i-=(i&(-i))) T[i]+=v;}
int Query(int i,int r=0){for(;i<=M;i+=(i&(-i))) r+=T[i]; return r;}

signed main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    N=read(); Ans=N;
    For(i,1,N) A[i].x=Num[++M]=read(),A[i].y=Num[++M]=read();
    sort(Num+1,Num+M+1); sort(A+1,A+N+1); 
    M=unique(Num+1,Num+M+1)-Num-1;
    For(i,1,N) Find(A[i].x),Find(A[i].y);
    Rof(i,N,1){
        int c=Query(A[i].y);
        if(!c) Modify(A[i].y,1),S.insert(A[i].y),Mx=A[i].y;
        else{
            Ans-=c;
            set<int>::iterator it=S.lower_bound(A[i].y);
            int x=0;
            while(it!=S.end()&&(*it)!=Mx){
                x=(*it); ++it; S.erase(x);
                Modify(x,-1);
            }
        }
    }
    write(Ans);
    return 0;
}
/*
7
13 3
23 25
29 19
1 3
21 11
7 21
4 16
*/