//1.0s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2010;
int Q,P[Maxn],c;

int main(){
    freopen("path.in","r",stdin);
    freopen("path.out","w",stdout);
    Q=read(); For(i,1,Q) P[i]=read();
    int t=sqrt(Q),h=0;
    For(i,t,1) if(Q%i==0) t=i,h=Q/i;
    write(t+h+2),pc(' '),write(t+h+t*h),pc('\n');
    For(i,1,t) write(1),pc(' '),write(i+1),printf(" 0\n");
    For(i,1,h) write(t+1+i),pc(' '),write(t+h+2),printf(" 0\n");
    For(i,1,t) For(j,1,h)
        write(i+1),pc(' '),write(t+1+j),pc(' '),write(P[++c]),pc('\n');
    return 0;
}