//2.0s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int unsigned int
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int Q;
char T[Maxn];

void Solve(int l,int r){
    int ans=0,tm=0,ti=0,tl=0,tk=0;
    For(i,l,r){
        if(T[i]=='m') ++tm;
        else if(T[i]=='i') ti+=tm;
        else if(T[i]=='l') tl+=ti;
        else if(T[i]=='k') tk+=tl;
        else ans+=tk;
    }
    write(ans),pc('\n');
}

signed main(){
    freopen("milky.in","r",stdin);
    freopen("milky.out","w",stdout);
    scanf("%s",T+1); Q=read();
    while(Q--){
        int l=read(),r=read();
        Solve(l,r);
    }
    return 0;
}