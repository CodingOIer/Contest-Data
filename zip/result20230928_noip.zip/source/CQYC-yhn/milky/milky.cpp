#include<bits/stdc++.h>
#define int unsigned int
using namespace std;
char T[1000005];
int n,q,t1,t2,dp[1000005][5],F[5];
struct ok{
    int a[6][6];
    inline void clear(){
        memset(a,0,sizeof(a));
    }
    ok operator * (const ok &A) const{
        ok B;
        B.clear();
        for(int i=0;i<6;i++){
            for(int j=0;j<6;j++){
                for(int g=0;g<6;g++) B.a[i][j]+=(a[i][g]*A.a[g][j]);
            }
        }
        return B;
    }
}op[1000005],danwei,cs,t[400005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void write(int x){
    int tnt=0;char f[12];
    if(x<0) x=-x,putchar('-');
    if(!x) {putchar('0');return;}
    while(x) f[++tnt]=x%10,x/=10;
    while(tnt) putchar(f[tnt--]+'0');
}
inline void build(int k,int l,int r){
    if(l==r){
        t[k]=op[l];
        return;
    }
    int mid=(l+r)>>1;
    build(k<<1,l,mid);build((k<<1)^1,mid+1,r);
    t[k]=t[k<<1]*t[(k<<1)^1];
}
inline ok query(int k,int l,int r,int ll,int rr){
    if(ll<=l&&rr>=r) return t[k];
    int mid=(l+r)>>1;
    if(ll<=mid&&rr>mid) return query(k<<1,l,mid,ll,rr)*query((k<<1)^1,mid+1,r,ll,rr);
    else if(ll<=mid) return query(k<<1,l,mid,ll,rr);
    return query((k<<1)^1,mid+1,r,ll,rr);
}
signed main(){
    // cerr<<(double)(&st-&ed)/1024.0/1024.0<<"MB\n";
    // double st=clock();
    freopen("milky.in","r",stdin);
    freopen("milky.out","w",stdout);
    scanf("%s",T+1);
    n=strlen(T+1);
    danwei.clear();
    for(int i=0;i<6;i++) danwei.a[i][i]=1;
    for(int i=1;i<=n;i++){
        for(int j=0;j<5;j++) dp[i][j]=dp[i-1][j];
        int d;
        if(T[i]=='m') d=1;
        if(T[i]=='i') d=2;
        if(T[i]=='l') d=3;
        if(T[i]=='k') d=4;
        if(T[i]=='y') d=5;
        if(d>1) dp[i][d-1]+=dp[i][d-2];
        else dp[i][0]++;
        op[i]=danwei;
        if(d>1) op[i].a[d-1][d]=1;
    }
    if(n<=100000) build(1,1,n);
    q=read();
    cs.clear();
    for(int i=1;i<=q;i++){
        t1=read(),t2=read();
        if(n<=100000){
            cs.clear();
            cs.a[0][0]=1;
            for(int j=0;j<5;j++) cs.a[0][j+1]=dp[t1-1][j];
            cs=cs*query(1,1,n,t1,t2);
        }
        write(dp[t2][4]-cs.a[0][5]);
        putchar('\n');
    }
    // cerr<<((double)clock()-st)/1000.0<<"s\n";
    return 0;
}