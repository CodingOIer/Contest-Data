#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[100005],T[400005],tag[400005],sum[400005];
struct ok{
    int op,t1,t2,t3,t4;
}q[100005];
stack<int> Q;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void build(int k,int l,int r){
    tag[k]=0;sum[k]=0;
    if(l==r){
        T[k]=a[l];
        return;
    }
    int mid=(l+r)>>1;
    build(k<<1,l,mid);build((k<<1)^1,mid+1,r);
    T[k]=max(T[k<<1],T[(k<<1)^1]);
}
signed main(){
    freopen("easiest.in","r",stdin);
    freopen("easiest.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=m;i++){
        q[i].op=read(),q[i].t1=read(),q[i].t2=read(),q[i].t3=read(),q[i].t4=read();
    }
    for(int i=1;i<=m;i++){
        if(q[i].op==1){
            int ans=q[i].t3-q[i].t1;
            Q.push(a[q[i].t4]);
            for(int j=q[i].t4+1;j<=q[i].t2;j++){
                if(a[j]>Q.top()) Q.push(a[j]);
                else ans++;
            }
            cout<<ans<<"\n";
            while(!Q.empty()) Q.pop();
        }
        else{
            int ans=0;
            for(int j=q[i].t3;j<=q[i].t4;j++){
                bool flag=1;
                int mx=a[j];
                for(int g=j+1;g<=q[i].t4;g++){
                    if(flag||a[g]<a[g-1]||mx>a[g]) ans++;
                    mx=max(mx,a[g]);
                    if(a[g]>a[j]) flag=0;
                }
            }
            cout<<ans<<"\n";
        }
    }
    return 0;
}