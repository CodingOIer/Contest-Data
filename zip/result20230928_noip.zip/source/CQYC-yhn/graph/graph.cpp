#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,ans=0,q[1000005],cnt;
struct ok{
    int x,y;
    bool operator < (const ok &A) const{
        if(x==A.x) return y<A.y;
        return x<A.x;
    }
}a[1000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
    sort(a+1,a+1+n);
    int mx=-1e18;
    for(int i=n;i>=1;i--){
        if(a[i].y>mx) mx=a[i].y,q[++cnt]=mx;
        else{
            int l=1,r=cnt,mid,res=cnt;
            while(l<=r){
                mid=(l+r)>>1;
                if(a[i].y<=q[mid]) res=min(res,mid),r=mid-1;
                else l=mid+1;
            }
            cnt=res;
        }
        // cout<<i<<" "<<cnt<<" "<<mx<<" "<<a[i].y<<"\n";
    }
    cout<<cnt;
    return 0;
}
