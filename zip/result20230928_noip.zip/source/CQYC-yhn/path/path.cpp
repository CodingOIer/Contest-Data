#include<bits/stdc++.h>
#define int long long
using namespace std;
int q,p[2005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("path.in","r",stdin);
    freopen("path.out","w",stdout);
    q=read();
    for(int i=1;i<=q;i++) p[i]=read();
    
    return 0;
}