#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,t1,t2;
char w[15];
mt19937 rd(time(0));
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int Rd(int k){
    return rd()%k+1;
}
signed main(){
    freopen("milky.in","w",stdout);
    n=m=1000000;
    w[1]='m';w[2]='i';w[3]='l';w[4]='k';w[5]='y';
    for(int i=1;i<=n;i++){
        cout<<w[Rd(5)];
    }
    cout<<"\n";
    cout<<m<<"\n";
    for(int i=1;i<=m;i++){
        t1=Rd(n);t2=Rd(n);
        if(t1>t2) swap(t1,t2);
        cout<<t1<<" "<<t2<<"\n";
    }
    return 0;
}