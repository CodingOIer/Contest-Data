#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
struct ok{
	int x,y;
	void init() {scanf("%d%d",&x,&y);}
	bool operator <(const ok &A) const{return x==A.x?y>A.y:x>A.x;}
}a[N];
int n,ans,fa[N],num[N];
int Find(int x) {return x==fa[x]?x:fa[x]=Find(fa[x]);}
void merge(int x,int y)
{
	x=Find(x),y=Find(y);
	if(x==y) return;
	if(num[x]<num[y]) swap(x,y);
	num[x]+=num[y];fa[y]=x;
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i].init();
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++) fa[i]=i,num[i]=1;
	for(int i=2,Mx=1;i<=n;i++)
		if(a[Mx].y<a[i].y) Mx=i;
		else merge(i,Mx);
	for(int i=n-1,Mn=n;i;i--)
		if(a[Mn].y>a[i].y) Mn=i;
		else merge(i,Mn);
	for(int i=1;i<=n;i++) ans+=(i==Find(i));
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
