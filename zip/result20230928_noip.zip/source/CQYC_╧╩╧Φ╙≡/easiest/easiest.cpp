#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
const int N=1e5+10,maxj=17;
struct ok{
	int l,id;
};
int n,m,a[N],L[N],R[N],lg[N],Tr[N],f[18][N];
int cnt,stk[N];
long long ans[N];
vector<ok>ask[N];
inline void Max(int &x,int y) {x=x>y?x:y;}
void add(int x,int y) {for(;x<=n;x+=(x&-x)) Tr[x]+=y;}
int query(int x,int res=0) {for(;x;x-=(x&-x)) res+=Tr[x];return res;}
int Find(int l,int r)
{
	if(l>r) return 0;
	int k=lg[r-l+1];
	return max(f[k][l],f[k][r-(1<<k)+1]);
}
int main()
{
	freopen("easiest.in","r",stdin);
	freopen("easiest.out","w",stdout);
	for(int i=2;i<N;i++) lg[i]=lg[i>>1]+1;
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i]=f[0][i]=read();
	for(int i=1;i<=n;i++)
	{
		while(cnt&&a[stk[cnt]]<a[i]) --cnt;
		L[i]=stk[cnt];stk[++cnt]=i;
	}
	stk[0]=n+1;cnt=0;
	for(int i=n;i;i--)
	{
		while(cnt&&a[stk[cnt]]<a[i]) --cnt;
		R[i]=stk[cnt];stk[++cnt]=i;
	}
	for(int i=1;i<=maxj;i++)
		for(int j=1;j+(1<<i)-1<=n;j++)
			f[i][j]=max(f[i-1][j],f[i-1][j+(1<<(i-1))]);
	for(int i=1,op,l1,r1,l2,r2;i<=m;i++)
	{
		op=read(),l1=read(),r1=read(),l2=read(),r2=read();
		if(op==1)
		{
			ans[i]=r1-l1-r2+l2;
			if(R[r2]<=r1) ask[r1].push_back((ok){R[r2],i});
		}
		else
			for(int j=l2;j<=r2;j++)
			{
				ans[i]+=max(0,L[j]-l2+1);//mdûʱ�������������ô��ά��
				if(R[j]<=r2) ans[i]+=(a[j]>Find(j+1,R[j]-1));
			}
	}
	for(int i=1;i<=n;i++)
	{
		add(L[i]+1,1),add(i+1,-1);
		for(ok x:ask[i]) ans[x.id]-=query(x.l);
	}
	for(int i=1;i<=m;i++) cout<<ans[i]<<'\n';
	fclose(stdin);fclose(stdout);
	return 0;
}
