#include<bits/stdc++.h>
using namespace std;
typedef unsigned int ui;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
int stk[15],tp;
inline void write(ui x)
{
	if(!x) return puts("0"),void();
	tp=0;
	while(x) stk[++tp]=x%10,x/=10;
	while(tp) putchar(stk[tp--]^48);
	putchar('\n');
}
const int N=1e6+10,M=5;
struct ok{
	int l,id;
};
int n,q,a[N];
char s[N];
ui ans[N],now[M][M],P[N][M][M];
vector<ok>ask[N];
ui check(int l,int r)
{
	for(int i=M-1;~i;i--)
		for(int j=i;j<M;j++)
		{
			now[i][j]=P[r][i][j]-P[l-1][i][j];
			for(int k=i;k<j;k++)
				now[i][j]-=P[l-1][i][k]*now[k+1][j];
		}
	return now[0][4];
}
int main()
{
	freopen("milky.in","r",stdin);
	freopen("milky.out","w",stdout);
	scanf("%s%d",s+1,&q);
	n=strlen(s+1);
	for(int i=1;i<=n;i++)
		if(s[i]=='m') a[i]=0;
		else if(s[i]=='i') a[i]=1;
		else if(s[i]=='l') a[i]=2;
		else if(s[i]=='k') a[i]=3;
		else a[i]=4;
	for(int i=1,l,r;i<=q;i++)
		l=read(),r=read(),ask[r].push_back((ok){l,i});
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<M;j++)
			for(int k=j;k<M;k++) P[i][j][k]=P[i-1][j][k];
		for(int j=0;j<a[i];j++) P[i][j][a[i]]+=P[i-1][j][a[i]-1];
		++P[i][a[i]][a[i]];
		for(ok x:ask[i]) ans[x.id]=check(x.l,i);
	}
	for(int i=1;i<=q;i++) write(ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
