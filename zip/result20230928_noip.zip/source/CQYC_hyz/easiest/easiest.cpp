#include<bits/stdc++.h>
#define int long long 
#define ls (lr << 1)
#define rs (lr << 1 | 1)
#define mid ((l + r) >> 1)
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

struct qry {
	int ty, st, l, r, id;
	bool operator < (const qry &p) const { return r < p.r; }
} op[N];

int n, m;
int a[N], ans[N];

namespace sub1 {
	int tmp;

	vector<int> t[N << 2];

	void modify(int l, int r, int x, int k, int lr) {
		if(t[lr].empty() or t[lr].back() < k) t[lr].push_back(k);
		if(l ^ r) mid >= x ? modify(l, mid, x, k, ls) : modify(mid + 1, r, x, k, rs);
	}

	int query(int l, int r, int L, int R, int lr) {
		if(l >= L and r <= R) {
			int pos = lower_bound(t[lr].begin(), t[lr].end(), tmp) - t[lr].begin();
			if(pos < t[lr].size()) tmp = t[lr].back(); return t[lr].size() - pos;
		}
		int res = 0;
		if(mid >= L) res = query(l, mid, L, R, ls);
		if(mid < R) res += query(mid + 1, r, L, R, rs);
		return res;
	}

	void insert(int x) {
		modify(1, n, x, a[x], 1);
	}

	int ask(int l, int r, int st) {
		if(l > r) return 0; tmp = st;
		return query(1, n, l, r, 1);
	}
}

namespace sub2 {
	struct tree {
		int x, tag;
	} t[N << 2];

	int top;
	int stk[N];

	void update(int l, int r, int x, int lr) { t[lr].x += (r - l + 1) * x, t[lr].tag += x; }

	void pushdown(int l, int r, int lr) {
		if(!t[lr].tag) return;
		update(l, mid, t[lr].tag, ls);
		update(mid + 1, r, t[lr].tag, rs);
		t[lr].tag = 0;
	}

	void modify(int l, int r, int L, int R, int x, int lr) {
		if(l >= L and r <= R) return update(l, r, x, lr);
		pushdown(l, r, lr);
		if(mid >= L) modify(l, mid, L, R, x, ls);
		if(mid < R) modify(mid + 1, r, L, R, x, rs);
		t[lr].x = t[ls].x + t[rs].x;
	}

	int query(int l, int r, int L, int R, int lr) {
		if(l >= L and r <= R) return t[lr].x; pushdown(l, r, lr);
		if(mid >= L and mid < R) return query(l, mid, L, R, ls) + query(mid + 1, r, L, R, rs);
		return mid >= L ? query(l, mid, L, R, ls) : query(mid + 1, r, L, R, rs);
	}

	void insert(int x) {
		while(top and a[stk[top]] < a[x]) modify(1, n, stk[top], stk[top], 1, 1), top--;
		if(top) modify(1, n, 1, stk[top], 1, 1); stk[++top] = x;
	}
}

bool edmer;
signed main() {
	freopen("easiest.in", "r", stdin);
	freopen("easiest.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
	n = read(), m = read();
	for(int i = 1; i <= n; i++) a[i] = read();
	for(int i = 1; i <= m; i++) {
		int ty = read(), l1 = read(), r1 = read(), l2 = read(), r2 = read();
		if(ty == 1) ans[i] += l2 - l1 + r1 - r2, op[i] = { ty, a[r2], r2 + 1, r1, i };
		else op[i] = { ty, l1 == l2 ? n + 1 : a[l2 - 1], l2, r2, i };
	}

	sort(op + 1, op + m + 1);

	for(int i = 1, pos = 1; i <= m; i++) {
		int l = op[i].l, r = op[i].r, st = op[i].st;

		while(pos <= r) sub1 :: insert(pos), sub2 :: insert(pos++);

		if(op[i].ty == 1) ans[op[i].id] -= sub1 :: ask(l, r, st);
		else ans[op[i].id] += sub2 :: query(1, n, l, r, 1);
	}

	for(int i = 1; i <= m; i++) write(ans[i]), putchar('\n');

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 