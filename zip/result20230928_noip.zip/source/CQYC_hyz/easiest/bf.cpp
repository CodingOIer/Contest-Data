#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

int n, m;
int a[N];

bool edmer;
signed main() {
	freopen("easiest.in", "r", stdin);
	freopen("easiest.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    for(int i = 1; i <= n; i++) a[i] = read();

    while(m--) {
        int op = read(), l1 = read(), r1 = read(), l2 = read(), r2 = read(), ans = 0;
        if(op == 1) {
            ans = l2 - l1 + r1 - r2; int now = a[r2];
            for(int i = r2 + 1; i <= r1; i++) if(a[i] > now) ans--, now = a[i];
            write(ans), putchar('\n');
        }
        else {
            for(int i = l2; i <= r2; i++) {
                int mx = 0;
                for(int j = i + 1; j <= r2; j++) {
                    ans++;
                    if(a[i] < mx and mx < a[j]) ans--;
                    mx = max(mx, a[j]);
                }
            }
            write(ans), putchar('\n');
        }
    }


    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 