#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

int n = 1000, m = 1000;
int a[1000010], b[10];

mt19937 g(time(0));

bool edmer;
signed main() {
	// freopen("T.in", "r", stdin);
	freopen("easiest.in", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    cout << n << " " << m << '\n';

    for(int i = 1; i <= n; i++) a[i] = i;
    shuffle(a + 1, a + n + 1, g);

    for(int i = 1; i <= n; i++) cout << a[i] << " "; cout << '\n';

    for(int i = 1; i <= m; i++) {
        cout << g() % 2 + 1 << " ";
        for(int j = 0; j < 4; j++) b[j] = g() % n + 1;
        sort(b, b + 4), swap(b[1], b[3]), swap(b[2], b[3]);
        for(int j = 0; j < 4; j++) cout << b[j] << " "; cout << '\n';
    }

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 