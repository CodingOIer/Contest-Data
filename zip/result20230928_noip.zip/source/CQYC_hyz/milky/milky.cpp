#include<bits/stdc++.h>
#define int unsigned int
using namespace std;

char buf[1 << 23], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 and (p2 = (p1 = buf) + fread(buf, 1, 1 << 23, stdin), p1 == p2) ? EOF : *p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e6 + 10;

struct node {
    int l, r, id;
    bool operator < (const node &p) const { return r < p.r; }
} op[N];

int q;
int ans[N], f[N][6], g[6][6];

char t[N], s[6] = { 'm', 'i', 'l', 'k', 'y' };

void solve(int l, int r, int L, int R) {
    if(l > r or L > R) return; int mid = (l + r) >> 1;
    
    for(int i = 0; i < 6; i++)
        for(int j = 0; j < 6; j++) g[i][j] = (i == j);

    for(int i = 0; i < 6; i++) f[mid][i] = 0; f[mid][0] = 1;

    for(int i = mid - 1; i >= l; i--) {
        for(int j = 0; j < 5; j++) if(t[i] == s[j])
        for(int k = 0; k < 6; k++) g[j + 1][k] -= g[j][k];
        f[i][0] = 1;
        for(int j = 1; j < 6; j++) {
            int val = 0;
            for(int k = 0; k < j; k++) val -= f[i][k] * g[j][k];
            f[i][j] = val;
        }
    }
    
    for(int i = 0; i < 6; i++)
        for(int j = 0; j < 6; j++) g[i][j] = (i == j);

    int pos = L;
    while(pos <= R and op[pos].r < mid) pos++;
    int cnt = pos;

    for(int i = pos, now = mid; i <= R; i++) {
        if(op[i].l > mid) { op[cnt++] = op[i]; continue; }
        while(now <= op[i].r) {
            for(int j = 0; j < 5; j++) if(t[now] == s[j])
            for(int k = 0; k <= j; k++) g[j + 1][k] += g[j][k];
            now++;
        }
        int res = 0;
        for(int j = 0; j <= 5; j++) res += f[op[i].l][j] * g[5][j];
        ans[op[i].id] = res;
    }

    solve(l, mid - 1, L, pos - 1);
    solve(mid + 1, r, pos, cnt - 1);
}

bool edmer;
signed main() {
	freopen("milky.in", "r", stdin);
	freopen("milky.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    scanf("%s", t + 1), q = read();
    for(int i = 1; i <= q; i++) op[i] = { read(), read(), i };

    sort(op + 1, op + q + 1), solve(1, strlen(t + 1), 1, q);

    for(int i = 1; i <= q; i++) write(ans[i]), putchar('\n');

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 