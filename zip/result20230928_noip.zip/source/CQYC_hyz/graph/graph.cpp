#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

struct node {
    int x, y;
    bool operator < (const node &p) const {
        return x == p.x ? y < p.y : x < p.x;
    }
} a[N];

int n, top, ans;
int stk[N];

bool edmer;
signed main() {
	freopen("graph.in", "r", stdin);
	freopen("graph.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) a[i] = { read(), read() };

    sort(a + 1, a + n + 1);

    for(int i = 1; i <= n; i++) {
        int l = a[i].y, r;
        while(i < n and a[i + 1].x == a[i].x) i++;
        r = a[i].y;
        while(top and stk[top] <= r) l = min(l, stk[top--]);
        stk[++top] = l;
    }

    write(top);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 