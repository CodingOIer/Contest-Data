#include<bits/stdc++.h>
using namespace std;
const int NN=1e6+4;
char s[NN];
unsigned int f[NN][5][5],g[NN][5][5],cnt[NN];
int get(char c)
{
	if(c=='m')
		return 0;
	if(c=='i')
		return 1;
	if(c=='l')
		return 2;
	if(c=='k')
		return 3;
	return 4;
}
int main()
{
	freopen("milky.in","r",stdin);
	freopen("milky.out","w",stdout);
	scanf("%s",s+1);
	int n=strlen(s+1);
	for(int i=1;i<=n;i++)
		cnt[i]=cnt[i-1]+(s[i]=='m');
	for(int i=1;i<=n;i++)
		for(int j=0;j<5;j++)
		{
			for(int k=j;k<5;k++)
				f[i][j][k]=f[i-1][j][k];
			if(get(s[i])==j)
				f[i][j][j]++;
			else if(get(s[i])>j)
				f[i][j][get(s[i])]+=f[i-1][j][get(s[i])-1];
		}
	for(int i=n;i;i--)
		for(int j=0;j<5;j++)
		{
			for(int k=j;~k;k--)
				g[i][j][k]=g[i+1][j][k];
			if(get(s[i])==j)
				g[i][j][j]++;
			else if(get(s[i])<j)
				g[i][j][get(s[i])]+=g[i+1][j][get(s[i])+1];
		}
	int q;
	scanf("%d",&q);
	while(q--)
	{
		int l,r;
		scanf("%d%d",&l,&r);
		unsigned int t[5]={0};
		t[0]=cnt[r]-cnt[l-1];
		for(int i=1;i<5;i++)
		{
			t[i]=f[n][0][i]-f[l-1][0][i]-g[r+1][i][0];
			for(int j=0;j<i;j++)
				t[i]-=f[l-1][0][j]*g[l][i][j+1]+t[j]*g[r+1][i][j+1];
		}
		printf("%u\n",t[4]);
	}
	return 0;
}
