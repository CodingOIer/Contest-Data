#include<bits/stdc++.h>
using namespace std;
const int NN=2004;
int p[NN];
int main()
{
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	int q;
	scanf("%d",&q);
	for(int i=1;i<=q;i++)
		scanf("%d",&p[i]);
	printf("100 %d\n",98+q);
	for(int i=2;i<=50;i++)
		printf("1 %d 0\n",i);
	for(int i=51;i<100;i++)
		printf("%d 100 0\n",i);
	int cnt=0;
	for(int i=2;i<=50;i++)
		for(int j=51;j<100;j++)
			if(cnt<q)
				printf("%d %d %d\n",i,j,p[++cnt]);
	return 0;
}
