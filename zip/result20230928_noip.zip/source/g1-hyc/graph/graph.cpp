#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4;
struct node
{
    int x,y;
    bool operator<(const node&it)const
    {
    	if(x==it.x)
    		return y>it.y;
        return x>it.x;
    }
}a[NN];
int r[NN],fa[NN];
int find(int u)
{
    return fa[u]==u?u:fa[u]=find(fa[u]);
}
int main()
{
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d%d",&a[i].x,&a[i].y);
        fa[i]=i;
    }
    sort(a+1,a+1+n);
    for(int i=1;i<=n;i++)
        r[i]=a[i].y;
    stack<int>sta;
    for(int i=1;i<=n;i++)
    {
        int last=i;
        while(sta.size()&&r[find(sta.top())]>=a[i].y)
        {
            int fu=find(last),fv=find(sta.top());
            fa[fu]=fv;
            r[fv]=max(r[fv],r[fu]);
            last=sta.top();
            sta.pop();
        }
        sta.push(find(i));
    }
    int ans=0;
    for(int i=1;i<=n;i++)
    	if(find(i)==i)
			ans++; 
    printf("%d",ans);
    return 0;
}
