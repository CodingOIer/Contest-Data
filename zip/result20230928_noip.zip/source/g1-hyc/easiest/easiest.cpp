#include<bits/stdc++.h>
using namespace std;
const int NN=1e5+4;
int a[NN],res[NN],s[NN];
int main()
{
	freopen("easiest.in","r",stdin);
	freopen("easiest.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	stack<int>stk;
	for(int i=n;i>=1;i--)
	{
		while(stk.size()&&stk.top()<a[i])
		{
			s[i]++;
			stk.pop();
		}
		stk.push(a[i]);
		res[i]=stk.size();
	}
	for(int i=n;i;i--)
		s[i]+=s[i+1];
	while(m--)
	{
		int opt,l1,r1,l2,r2;
		scanf("%d%d%d%d%d",&opt,&l1,&r1,&l2,&r2);
		if(opt==1)
		{
			printf("%d\n",r1-r2+l2-l1-res[r2]+1+res[r1+1]-s[r2]+s[r1+1]);
		}
	}
	return 0;
}
