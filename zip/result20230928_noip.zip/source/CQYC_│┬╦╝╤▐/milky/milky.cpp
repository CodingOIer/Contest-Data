#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=4294967296,maxn=1e6+5;
int n,q,l,r,f[maxn][6];
char t[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int &a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
signed main(){
    freopen("milky.in","r",stdin);
    freopen("milky.out","w",stdout);
    scanf("%s",t+1);
    n=strlen(t+1);
    q=read();
    if(n>1e5){
        f[0][0]=1;
        for(int i=1;i<=n;i++){
            for(int j=0;j<6;j++)
                f[i][j]=f[i-1][j];
            if(t[i]=='m')
                add(f[i][1],f[i-1][0]);
            if(t[i]=='i')
                add(f[i][2],f[i-1][1]);
            if(t[i]=='l')
                add(f[i][3],f[i-1][2]);
            if(t[i]=='k')
                add(f[i][4],f[i-1][3]);
            if(t[i]=='y')
                add(f[i][5],f[i-1][4]);
        }
        while(q--){
            l=read(),r=read();
            if(l==1)
                printf("%lld\n",f[r][5]);
        }
        return 0;
    }
    while(q--){
        l=read(),r=read();
        for(int i=1;i<6;i++)
            f[l-1][i]=0;
        f[l-1][0]=1;
        for(int i=l;i<=r;i++){
            for(int j=0;j<6;j++)
                f[i][j]=f[i-1][j];
            if(t[i]=='m')
                add(f[i][1],f[i-1][0]);
            if(t[i]=='i')
                add(f[i][2],f[i-1][1]);
            if(t[i]=='l')
                add(f[i][3],f[i-1][2]);
            if(t[i]=='k')
                add(f[i][4],f[i-1][3]);
            if(t[i]=='y')
                add(f[i][5],f[i-1][4]);
        }
        printf("%lld\n",f[r][5]);
    }
    return 0;
}