#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
int n,b[maxn],tot;
struct node{
    int x,y;
}a[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int cmp(node a,node b){
    if(a.x==b.x)
        return a.y<b.y;
    return a.x<b.x;
}
signed main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        a[i].x=read(),a[i].y=read();
    sort(a+1,a+1+n,cmp);
    tot=n;
    b[tot]=a[1].y;
    for(int i=2;i<=n;i++){
        int c=upper_bound(b+tot,b+1+n,a[i].y)-b;
        if(c-1<tot)
            b[--tot]=a[i].y;
        else
            b[c-1]=b[tot],tot=c-1;
    }
    printf("%d\n",n-tot+1);
    return 0;
}