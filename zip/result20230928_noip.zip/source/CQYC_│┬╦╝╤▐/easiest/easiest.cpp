#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5;
int n,m,x[maxn],op,a,b,c,d,sum,vis[maxn],s[maxn],t[maxn],vis2[3005][3005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int solve1(int a,int b,int c,int d){
    int cnt=0,tot=0;
    for(int i=d+1;i<=b;i++){
        while(cnt&&x[i]>s[cnt])
            --cnt;
        if(!cnt)
            t[++tot]=x[i];
        s[++cnt]=x[i];
    }
    int k=lower_bound(t+1,t+1+tot,x[d])-t;
    k--;
    return c-a+b-d-tot+k;
}
void solve2(int a,int b,int c,int d,int la){
    int pr=1e9;
    for(int i=a;i<=b;i++){
        if(!vis[i]&&(i==a||x[i]<pr)){
            vis[i]=1;
            int u=la,v=i;
            if(u>v)
                swap(u,v);
            if(u>=c&&v<=d&&!vis2[u][v]){
                vis2[u][v]=1;
                ++sum;
            }
            solve2(a,b,c,d,i);
            vis[i]=0;
        }
        if(!vis[i])
            pr=x[i];
    }
}
signed main(){
    freopen("easiest.in","r",stdin);
    freopen("easiest.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)
        x[i]=read();
    while(m--){
        op=read(),a=read(),b=read(),c=read(),d=read();
        if(op==1)
            printf("%lld\n",solve1(a,b,c,d));
        else{
            sum=0;
            for(int i=c;i<d;i++)
                for(int j=c+1;j<=d;j++)
                    vis2[i][j]=0;
            solve2(a,b,c,d,-1);
            printf("%lld\n",sum);
        }
    }
    return 0;
}