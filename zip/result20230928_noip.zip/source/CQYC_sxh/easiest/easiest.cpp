#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }


const int N = 1e5 + 1000;
int n, m, a[N], R[21][N];
int stk[N], tp, root[N];

namespace SEG {
    #define ls(x) (t[x].ls)
    #define rs(x) (t[x].rs)
    #define mid ((l + r) >> 1)
    struct node { int ls, rs, cnt; i64 w; }t[N << 5];
    int num;
    int New(int x) { return t[++num] = t[x], num; }
    void insert(int &x, int p, int l = 0, int r = n) {
        x = New(x), ++t[x].cnt, t[x].w += p - 1; 
        if (l == r) return;
        if (mid >= p) insert(ls(x), p, l, mid);
        else insert(rs(x), p, mid + 1, r);
    }
    i64 ask1(int p, int q, int L, int R, int l = 0, int r = n) {
        if (l >= L && r <= R) return t[q].cnt - t[p].cnt; i64 ans = 0;
        if (mid >= L) ans += ask1(ls(p), ls(q), L, R, l, mid);
        if (mid < R) ans += ask1(rs(p), rs(q), L, R, mid + 1, r);
        return ans;
    }
    i64 ask2(int p, int q, int L, int R, int l = 0, int r = n) {
        if (l >= L && r <= R) return t[q].w - t[p].w; i64 ans = 0;
        if (mid >= L) ans += ask2(ls(p), ls(q), L, R, l, mid);
        if (mid < R) ans += ask2(rs(p), rs(q), L, R, mid + 1, r);
        return ans;
    }
}
signed main() {
	freopen("easiest.in", "r", stdin);
	freopen("easiest.out", "w", stdout);
    n = read(), m = read(); For(i, 1, n) a[i] = read();
    
    For(i, 1, n) {
        while (tp && a[stk[tp]] < a[i]) --tp;
        root[i] = root[i - 1]; int k = min(stk[tp], i - 2);
        SEG::insert(root[i], k + 1), stk[++tp] = i;
    }
    
    tp = 0, stk[0] = n + 1; Rof(i, n, 1) {
        while (tp && a[stk[tp]] < a[i]) --tp;
        R[0][i] = stk[tp], stk[++tp] = i;
    } For(i, 0, 20) R[i][n + 1] = n + 1;
    Rof(i, n, 1) For(j, 1, 20) R[j][i] = R[j - 1][R[j - 1][i]];
    while (m--) {
        int op = read(), l1 = read(), r1 = read(), l2 = read(), r2 = read();
        if (op & 1) { int ans = r2 - l2 + 1, p = r2;
            Rof(i, 20, 0) if (R[i][p] <= r1) 
                ans += 1 << i, p = R[i][p];
            cout << r1 - l1 + 1 - ans << '\n';
        } else { 
            i64 ans = (l2 + r2) * (r2 - l2 + 1ll) / 2;
            ans -= SEG::ask2(root[l2 - 1], root[r2], l2, n);
            ans -= SEG::ask1(root[l2 - 1], root[r2], 0, l2 - 1) * (l2 - 1);
            cout << (r2 - l2 + 1ll) * (r2 - l2) / 2 - ans + (r2 - l2 + 1) << '\n';
        }
    }
    return 0;
}