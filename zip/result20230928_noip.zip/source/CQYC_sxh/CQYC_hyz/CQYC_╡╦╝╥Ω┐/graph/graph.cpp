#include <bits/stdc++.h>
using namespace std;
int n;
pair<int, int> a[200000];
stack<int> p;
int main()
{
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d%d", &a[i].first, &a[i].second);
    sort(a, a + n);
    for (int i = 0; i < n; i++)
    {
        int x = a[i].second;
        while (p.size() && p.top() <= a[i].second)
            x = min(x, p.top()), p.pop();
        p.push(x);
    }
    printf("%zu\n", p.size());
    return 0;
}