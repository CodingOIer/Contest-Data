#include <bits/stdc++.h>
using namespace std;
int q;
int t[200];
unsigned int ans[5];
unsigned int f[2000000][5][5];
char s[2000000];
void read(int &x)
{
    char c = getchar();
    while (!isdigit(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
int main()
{
    freopen("milky.in", "r", stdin);
    freopen("milky.out", "w", stdout);
    for (int i = 0; i < 5; i++)
        t["milky"[i]] = i;
    scanf("%s%d", s + 1, &q);
    for (int i = 1; s[i]; i++)
    {
        memcpy(f[i], f[i - 1], sizeof(f[i]));
        for (int j = 0; j < t[s[i]]; j++)
            f[i][j][t[s[i]]] += f[i][j][t[s[i]] - 1];
        f[i][t[s[i]]][t[s[i]]]++;
    }
    for (int i = 1, l, r; i <= q; i++)
    {
        read(l);
        read(r);
        for (int j = 4; j >= 0; j--)
        {
            ans[j] = f[r][j][4] - f[l - 1][j][4];
            for (int k = 4; k > j; k--)
                ans[j] -= f[l - 1][j][k - 1] * ans[k];
        }
        printf("%u\n", ans[0]);
    }
    return 0;
}