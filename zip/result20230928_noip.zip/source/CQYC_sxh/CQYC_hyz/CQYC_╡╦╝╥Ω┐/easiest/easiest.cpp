#include <bits/stdc++.h>
using namespace std;
int n, m, p;
int a[400000], g[400000];
int f[20][400000];
long long ans[400000];
stack<int> s;
vector<int> k[400000];
struct Query
{
    int k, t, l, r, p, q;
} d[400000];
struct Tree
{
    int l, r;
    long long s, k, t;
} t[400000];
void read(int &x)
{
    char c = getchar();
    while (!isdigit(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
void build(int x, int l, int r)
{
    if ((t[x].l = l) != (t[x].r = r))
        build(x * 2, l, (l + r) / 2), build(x * 2 + 1, (l + r) / 2 + 1, r);
}
void refresh(int x)
{
    t[x].s += t[x].k + (t[x].r - t[x].l) * (t[x].r - t[x].l + 1ll) * t[x].t / 2;
    if (t[x].l != t[x].r)
    {
        t[x * 2].k += t[x].k + (t[x].r - t[x * 2].r) * t[x].t;
        t[x * 2 + 1].k += t[x].k;
        t[x * 2].t += t[x].t;
        t[x * 2 + 1].t += t[x].t;
    }
    t[x].k = t[x].t = 0;
}
void add(int x, int l, int r, int k)
{
    refresh(x);
    if (t[x].l > r || t[x].r < l)
        return;
    if (t[x].l >= l && t[x].r <= r)
    {
        t[x].k = k;
        if (k == INT_MAX)
            t[x].k = r - t[x].r + 1, t[x].t = 1;
        refresh(x);
        return;
    }
    add(x * 2, l, r, k);
    add(x * 2 + 1, l, r, k);
    t[x].s = t[x * 2].s + t[x * 2 + 1].s;
}
long long query(int x, int y)
{
    refresh(x);
    if (t[x].r < y || t[x].l > y)
        return 0;
    if (t[x].l == t[x].r)
        return t[x].s;
    return query(x * 2, y) + query(x * 2 + 1, y);
}
int main()
{
    freopen("easiest.in", "r", stdin);
    freopen("easiest.out", "w", stdout);
    read(n);
    read(m);
    for (int i = 1; i <= n; i++)
    {
        read(a[i]);
        while (s.size() && a[s.top()] < a[i])
            f[0][s.top()] = i, k[i].push_back(s.top()), s.pop();
        if (s.size())
            g[i] = s.top();
        s.push(i);
    }
    for (int i = 0; i < 19; i++)
        for (int j = 1; j <= n; j++)
            f[i + 1][j] = f[i][f[i][j]];
    for (int i = 1; i <= m; i++)
        d[i].k = i, read(d[i].t), read(d[i].l), read(d[i].r), read(d[i].p), read(d[i].q);
    sort(d + 1, d + m + 1, [](Query x, Query y)
         { return x.q < y.q; });
    build(1, 1, n);
    for (int i = 1; i <= m; i++)
    {
        if (d[i].t == 1)
        {
            ans[d[i].k] = d[i].r + d[i].p - d[i].l - d[i].q;
            for (int j = 19; j >= 0; j--)
                if (f[j][d[i].q] && f[j][d[i].q] <= d[i].r)
                    ans[d[i].k] -= 1 << j, d[i].q = f[j][d[i].q];
            continue;
        }
        while (p < d[i].q)
        {
            for (int x : k[++p])
                add(1, 1, x, -1);
            add(1, 1, g[p], p - g[p] - 1);
            add(1, g[p] + 1, p - 1, INT_MAX);
        }
        ans[d[i].k] = (d[i].q - d[i].p) * (d[i].q - d[i].p + 1ll) / 2 - query(1, d[i].p);
    }
    for (int i = 1; i <= m; i++)
        printf("%lld\n", ans[i]);
    return 0;
}