#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,Q,sq,L,R,bz[20][N],a[N],nxt[N],pre[N],ans,tot,res[N];
struct ques{
    int l,r,id;
    il bool operator<(ct ques &x)ct{
        return l/sq==x.l/sq?r<x.r:l<x.l;
    }
} qus[N];
struct Mu_tree{
    #define ls (son[w][0])
    #define rs (son[w][1])
    #define ls_ (son[w_][0])
    #define rs_ (son[w_][1])
    int sum[N*40],son[N*40][2],rt[N],id;
    il void build(int &w,int l,int r){
        w=++id;
        if(l==r) return;
        int mid=(l+r)>>1;
        build(ls,l,mid);build(rs,mid+1,r);
    }
    il void push_up(int w){
        sum[w]=sum[ls]+sum[rs];
    }
    il void update(int &w,int w_,int l,int r,int x,int k){
        w=++id;son[w][0]=son[w_][0];son[w][1]=son[w_][1];
        if(l==r){
            sum[w]=sum[w_]+k;
            return;
        }
        int mid=(l+r)>>1;
        if(x<=mid) update(ls,ls_,l,mid,x,k);
        else update(rs,rs_,mid+1,r,x,k);
        push_up(w);
    }
    il int query(int w,int w_,int l,int r,int L,int R){
        if(L>r||R<l) return 0;
        if(L<=l&&R>=r) return sum[w]-sum[w_];
        int mid=(l+r)>>1;
        return query(ls,ls_,l,mid,L,R)+query(rs,rs_,mid+1,r,L,R);
    }
} ST1,ST2;
il int calc(int x){
    return x*(x-1)/2;
}
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("easiest.in","r",stdin);
	freopen("easiest.out","w",stdout);
    n=read();Q=read();
    stack<int> S;
    for(int i=1;i<=n+1;++i) bz[0][i]=nxt[i]=n+1;
    for(int i=1;i<=n;++i){
        a[i]=read();
        while(!S.empty()&&a[S.top()]<a[i]){
            nxt[S.top()]=i;S.pop();
        }
        S.push(i);
    }
    while(!S.empty()) S.pop();
    for(int i=1;i<=n;++i){
        while(!S.empty()&&a[S.top()]<=a[i]){
            bz[0][S.top()]=i;S.pop();
        }
        S.push(i);
    }
    while(!S.empty()) S.pop();
    for(int i=1;i<=n;++i){
        while(!S.empty()&&a[S.top()]<=a[i]) S.pop();
        if(!S.empty()) pre[i]=S.top();
        S.push(i);
    }
    ST1.build(ST1.rt[0],0,n+1);ST2.build(ST2.rt[0],0,n+1);
    for(int i=1;i<=n;++i){
        // cerr<<pre[i]<<" ";
        ST1.update(ST1.rt[i],ST1.rt[i-1],0,n+1,nxt[i],1);
        ST2.update(ST2.rt[i],ST2.rt[i-1],0,n+1,pre[i],1);
    }
    for(int i=1;i<20;++i){
        for(int j=1;j<=n+1;++j) bz[i][j]=bz[i-1][bz[i-1][j]];
    }
    for(int i=1;i<=Q;++i){
        int op=read(),l1=read(),r1=read(),l2=read(),r2=read();
        if(op==1){
            ans=l2-l1+r1-r2;
            for(int i=19;i>=0;--i){
                if(bz[i][r2]<=r1){
                    r2=bz[i][r2];ans-=(1<<i);
                }
            }
            res[i]=ans;
        }
        else qus[++tot]=(ques){l2,r2,i};
    }
    if(tot){
        sq=n/sqrt(tot);sort(qus+1,qus+1+tot);
    }
    L=1,R=0;ans=0;
    for(int i=1;i<=tot;++i){
            // cerr<<"ERROR";
        while(qus[i].l<L){
            --L;
            // if(ST2.query(ST2.rt[R],ST2.rt[min(R,nxt[L])],0,n+1,0,L-1)) cerr<<"ERROR";
            ans+=ST2.query(ST2.rt[R],ST2.rt[min(R,nxt[L])],0,n+1,0,L-1);
        }
        while(qus[i].r>R){
            ++R;
            // cerr<<max(L-1,pre[R])<<" "<<R<<" "<<0<<" "<<R-1<<"\n";
            // cerr<<L<<" ";
            // cerr<<R-1<<" ";
            ans+=ST1.query(ST1.rt[R],ST1.rt[max(L-1,pre[R])],0,n+1,0,R-1);
            // cerr<<ans<<" ";
        }
        // cerr<<ans<<" ";
        while(qus[i].l>L){
            ans-=ST2.query(ST2.rt[R],ST2.rt[min(R,nxt[L])],0,n+1,0,L-1);
            ++L;
        }
        while(qus[i].r<R){
            ans-=ST1.query(ST1.rt[R],ST1.rt[max(L-1,pre[R])],0,n+1,0,R-1);
            --R;
        }
        // cerr<<ans<<" ";
        res[qus[i].id]=calc(qus[i].r-qus[i].l+1)-ans;
    }
    for(int i=1;i<=Q;++i){
        write(res[i]);putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}