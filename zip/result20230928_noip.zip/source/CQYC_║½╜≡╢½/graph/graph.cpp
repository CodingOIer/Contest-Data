#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 100010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n;
set<int> S;
pii a[N];
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("graph.in","r",stdin);
	freopen("graph.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i){
        a[i].fi=read();a[i].se=read();
    }
    sort(a+1,a+1+n);
    for(int l=1,r;l<=n;l=r+1){
        r=l;
        while(r<n&&a[r+1].fi==a[r].fi) ++r;
        if(!S.empty()){
            int tmp=*S.begin();
            if(tmp<=a[r].se){
                S.erase(S.begin());
                while(!S.empty()&&*S.begin()<=a[r].se) S.erase(S.begin());
                S.insert(tmp);
            }
            else S.insert(a[l].se);
        }
        else S.insert(a[l].se);
        // cerr<<l<<" "<<r<<" "<<(int)S.size()<<"\n";
    }
    write(S.size());
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}