#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 1000010
#define uint unsigned int
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(uint x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,Q;
char ch[6]={' ','m','i','l','k','y'};
unordered_map<char,int> mp;
uint dp[N][6][6];
char T[N];
il uint solve(int l,int r,int L,int R){
    if(l>r) return 0;
    uint res=dp[r][L][R]-dp[l-1][L][R];
    if(l!=1) for(int i=L;i<R;++i) res-=solve(1,l-1,L,i)*solve(l,r,i+1,R);
    return res;
}
bool pppp;
signed main(){
    // cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("milky.in","r",stdin);
	freopen("milky.out","w",stdout);
    scanf(" %s",T+1);n=strlen(T+1);
    for(int i=1;i<6;++i){
        mp[ch[i]]=i;dp[0][i][i-1]=1;
    }
    for(int i=1;i<=n;++i){
        int tmp=mp[T[i]];
        for(int j=1;j<6;++j){
            for(int k=j-1;k<6;++k) dp[i][j][k]+=dp[i-1][j][k];
            dp[i][j][tmp]+=dp[i-1][j][tmp-1];
        }
        // for(int j=1;j<6;++j) for(int k=j;k<6;++k) if(dp[i][j][k]) cerr<<i<<" "<<j<<" "<<k<<" "<<dp[i][j][k]<<"\n";
    }
    Q=read();
    while(Q--){
        int l=read(),r=read();
        // cerr<<solve(l,r,1,5)<<"\n";
        write(solve(l,r,1,5));putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}