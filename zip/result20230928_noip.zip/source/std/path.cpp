#include <bits/stdc++.h>

#define eb emplace_back
#define ep emplace
#define fi first
#define se second
#define in read<int>()
#define lin read<ll>()
#define rep(i, x, y) for(int i = (x); i <= (y); i++)
#define per(i, x, y) for(int i = (x); i >= (y); i--)

using namespace std;

using ll = long long;
using db = double;
using pii = pair < int, int >;
using vec = vector < int >;
using veg = vector < pii >;

template < typename T > T read() {
	T x = 0; bool f = 0; char ch = getchar();
	while(!isdigit(ch)) f |= ch == '-', ch = getchar();
	while(isdigit(ch)) x = x * 10 + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

template < typename T > void chkmax(T &x, const T &y) { x = x > y ? x : y; }
template < typename T > void chkmin(T &x, const T &y) { x = x < y ? x : y; }

const int T = 2000;
const int N = T + 10;
const int B = 23;

int Q;
bool hav[N];
vec pot[20];
int upid[20];
vector < tuple < int, int, int > > edge;

int main() {
	freopen("path.in", "r", stdin); freopen("path.out", "w", stdout);
	Q = in; rep(i, 1, Q) hav[in] = true;
	rep(i, 1, 2000) if(hav[i]) {
		int stu = 0;
		rep(j, i + 1, i + 3) if(hav[j]) stu |= 1 << (j - i - 1);
		pot[stu].eb(i); i += 3;
		//cerr << "!" << stu << endl;
	}
	int cnt = 1;
	rep(i, 0, 7) {
		upid[i] = cnt + 1;
		int tcnt = ((int)pot[i].size() - 1) / B + 1;
		rep(j, cnt + 2, cnt + tcnt) edge.eb(j - 1, j, 0);
		cnt += tcnt;
	}
	rep(i, 0, 7) {
		if(i == 0) {
			edge.eb(1, upid[i], 0);
			rep(j, i + 1, 7) edge.eb(upid[i], upid[j], 0);
			continue;
		}
		if(i == 1) edge.eb(1, upid[i], 1);
		if(i == 2) edge.eb(1, upid[i], 2);
		if(i == 4) edge.eb(1, upid[i], 3);
		rep(j, i + 1, 7) if((i & j) == i) edge.eb(upid[i], upid[j], 0);
	}
	rep(i, 0, 7) {
		int cur = upid[i], curt = 1;
		for(auto x : pot[i]) {
			edge.eb(cur, curt + cnt, x); curt++;
			if(curt == B + 1) curt = 1, cur++;
		}
	}
	rep(i, cnt + 1, cnt + B - 1) edge.eb(i, cnt + B, 0);
	printf("%d %d\n", cnt + B, int(edge.size()));
	for(auto v : edge) {
		int x, y, w; tie(x, y, w) = v;
		printf("%d %d %d\n", x, y, w);
	}
	return 0;
}
