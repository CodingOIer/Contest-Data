#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+2;
int n,Q;
char s[maxn],ty[5]={'y','k','l','i','m'};
struct node_Q{
    int l,r,id;
}q[maxn];
unsigned int va[5][maxn],pas[5][maxn],ans[maxn];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
void solve(int st){
    // printf("solve %d\n",st);
    for(int i=n;i;i--)va[st][i]=va[st][i+1]+(s[i]==ty[st]);
    for(int t=st+1;t<=4;t++){
        for(int i=n;i;i--){
            va[t][i]=va[t][i+1];
            if(s[i]==ty[t])va[t][i]+=va[t-1][i+1];
        }
    }
    // printf("boom\n");
    // for(int t=st;t<5;t++){
    //     for(int j=1;j<=n;j++)printf("%d ",va[t][j]);
    //     printf("\n");
    // }
    // printf("pa\n");
    for(int i=1;i<=Q;i++){
        pas[st][i]=va[4][q[i].l]-va[4][q[i].r+1];
        // printf("ppppas[%d][%d]=%d\n",st,i,pas[st][i]);
        for(int j=st+1;j<=4;j++)pas[st][i]-=pas[j][i]*va[j-1][q[i].r+1];
        // printf("pas[%d][%d]=%d\n",st,i,pas[st][i]);
    }
}
int main(){
    freopen("milky.in","r",stdin);
    freopen("milky.out","w",stdout);
    scanf("%s",s+1);
    n=strlen(s+1);
    Q=read();
    for(int i=1;i<=Q;i++)q[i].l=read(),q[i].r=read(),q[i].id=i;
    for(int t=4;t>=0;t--)solve(t);
    for(int i=1;i<=Q;i++)printf("%lld\n",(long long)pas[0][i]);
    return 0;
}