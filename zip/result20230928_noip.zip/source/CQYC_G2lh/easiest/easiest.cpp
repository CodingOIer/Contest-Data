#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+2;
int n,m;
int ar[maxn],top,sta[maxn],las[maxn],pos[maxn];
long long sum[maxn],sum2[maxn],ans[maxn];
vector<int>qu[maxn];
struct SEGTREE{
    struct node{
        int ls,rs,l,r;
        long long sum,tag,len;
    }t[maxn<<2];
    void pushup(int x){
        t[x].sum=t[t[x].ls].sum+t[t[x].rs].sum;
        t[x].len=t[t[x].ls].len+t[t[x].rs].len;
        return ;
    }
    void update(int x,long long v){
        t[x].sum+=1ll*t[x].len*v;
        t[x].tag+=v;
        return ;
    }
    void pushdown(int x){
        update(t[x].ls,t[x].tag);
        update(t[x].rs,t[x].tag);
        t[x].tag=0;
        return ;
    }
    void build(int x,int l,int r){
        t[x].l=l,t[x].r=r;
        t[x].tag=0;
        if(t[x].l==t[x].r){
            t[x].sum=0;
            t[x].ls=t[x].rs=0;
            t[x].len=1;
            return ;
        }
        int mid=(t[x].l+t[x].r)>>1;
        t[x].ls=(x<<1),t[x].rs=(x<<1|1);
        build(t[x].ls,l,mid);
        build(t[x].rs,mid+1,r);
        pushup(x);
    }
    void modify(int x,int l,int r,long long v){
        if(l>r)return ;
        if(t[x].l==l&&t[x].r==r){
            update(x,v);
            return ;
        }
        pushdown(x);
        int mid=(t[x].l+t[x].r)>>1;
        if(l>mid)modify(t[x].rs,l,r,v);
        else if(r<=mid)modify(t[x].ls,l,r,v);
        else {
            modify(t[x].ls,l,mid,v);modify(t[x].rs,mid+1,r,v);
        }
        pushup(x);
    }
    void del(int x,int p){
        if(t[x].l==t[x].r){
            t[x].len=0;
            return ;
        }
        pushdown(x);
        int mid=(t[x].l+t[x].r)>>1;
        if(p<=mid)del(t[x].ls,p);
        else del(t[x].rs,p);
        pushup(x);
        return ;
    }
    long long query(int x,int l,int r){
        if(t[x].l==l&&t[x].r==r){
            return t[x].sum;
        }
        pushdown(x);
        int mid=(t[x].l+t[x].r)>>1;
        if(l>mid)return query(t[x].rs,l,r);
        else if(r<=mid)return query(t[x].ls,l,r);
        else {
            return query(t[x].ls,l,mid)+query(t[x].rs,mid+1,r);
        }
    }
}segt1,segt2;
struct node{
    int op,l1,r1,l2,r2,id;
}q[maxn];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
// bool cmpr2(node A,node B){
//     return A.r2<B.r2;
// }
vector<long long>vec,val;
int main(){
    freopen("easiest.in","r",stdin);
    freopen("easiest.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++)ar[i]=read(),pos[ar[i]]=i;
    sta[top=0]=0;
    segt1.build(1,1,n);
    segt2.build(1,1,n);
    for(int i=1;i<=n;i++){
        if(i>1)sum[i]=sum[i-1]+(ar[i]>ar[i-1]);
        if(i>1)sum2[i]=sum2[i-1]+(ar[i]<ar[i-1]);
        while(top&&ar[sta[top]]<ar[i])top--;
        las[i]=sta[top];
        // printf("r[%d]=%d\n",i,sta[top]);
        sta[++top]=i;
    }
    for(int i=1;i<=m;i++){
        q[i].op=read(),q[i].l1=read(),q[i].r1=read(),q[i].l2=read(),q[i].r2=read();
        q[i].id=i;
        if(q[i].op==1)ans[i]=1ll*(q[i].l2-q[i].l1)+sum2[q[i].r1]-sum2[q[i].r2];
        else qu[q[i].r2].push_back(i);  
    }
    top=0;
    long long sum;
    for(int i=1;i<=n;i++){
        segt1.modify(1,1,las[i],1);
        segt2.modify(1,las[i]+1,i-1,1);
        // printf("modi1 %d %d\n",1,las[i]);
        // printf("modi2 %d %d\n",las[i]+1,i-1);
        // sum=0;
        while(top&&ar[sta[top]]<ar[i]){
            // segt1.modify(1,sta[top],sta[top],segt2.query(1,sta[top],sta[top]));
            // sum+=segt2.query(1,sta[top],sta[top]);
            vec.push_back(sta[top]);
            val.push_back(segt2.query(1,sta[top],sta[top]));
            // printf("del %d %lld\n",sta[top],segt2.query(1,sta[top],sta[top]));
            segt2.del(1,sta[top--]);
        }
        for(int i=0;i<vec.size();i++)segt1.modify(1,vec[i],vec[i],val[i]);
        sta[++top]=i;
        for(int j=0,whi;j<qu[i].size();j++){
            whi=qu[i][j];
            ans[whi]=segt1.query(1,q[whi].l2,q[whi].r2);
            // printf("%lld\n",segt1.query(1,q[whi].l2,q[whi].r2));
        }
        // for(int i=0;i<vec.size();i++)segt1.modify(1,vec[i],vec[i],-val[i]);
        vec.clear(),val.clear();
    }
    for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
    return 0;
}