#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+2;
int n;
int len,ve[maxn];
struct node{
    int u,v;
    bool operator < (const node &A)const{
        return (u!=A.u)?(u<A.u):(v<A.v);
    }
}q[maxn];
set<node>s;
set<node>::iterator it;
vector<node>lim;
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int main(){
    freopen("graph.in","r",stdin);
    freopen("graph.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)q[i].u=read(),q[i].v=read();
    sort(q+1,q+n+1);
    int mi=1e9+1;
    q[0].u=1e9+1;
    int ans=0;
    for(int i=1,pos;i<=n;i++){
        if(q[i].u==q[i-1].u&&q[i].v==q[i-1].v)continue;
        if(q[i].v<mi)len++,s.insert((node){q[i].v,len}),mi=q[i].v;
        else {
            it=s.upper_bound((node){q[i].v,len});it--;
            lim.push_back((node){it->v,len});
        }
    }
    int las=0;
    for(int i=0;i<lim.size();i++){
        if(lim[i].u>las)ans+=(lim[i].u-las);
        las=lim[i].v;
    }
    ans+=len-las;
    printf("%d\n",ans);
    return 0;
}