#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}

int n,T;
int a[200005];
int b[200005];
int dp[205][805][805]; 
bool flag[205];
signed main(){
	freopen("slauqe.in","r",stdin);
	freopen("slauqe.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		int sumsa=0,sumsb=0;
		for(int i=1;i<=n;i++) a[i]=read(),sumsa+=a[i];
		for(int i=1;i<=n;i++) b[i]=read(),sumsb+=b[i];
		if(sumsa%2==1||sumsb%2==1){
			printf("-1\n");
			continue;
		}
		if(n<=200){
			memset(dp,0,sizeof(dp));
			dp[0][400][400]=1;
			for(int i=1;i<=n;i++){
				for(int j=-2*n;j<=2*n;j++){
					for(int t=-2*n;t<=2*n;t++){
						if(dp[i-1][j+400][t+400])dp[i][j+400+a[i]][t+400+b[i]]=1;
						if(dp[i-1][j+400][t+400])dp[i][j+400-a[i]][t+400-b[i]]=1;
					}
				}
			}
			memset(flag,0,sizeof(flag));
			if(!dp[n][400][400]) printf("-1\n");
			else{
				int x=0,y=0;
				for(int i=n;i>=1;i--){
					if(dp[i-1][x+400+a[i]][y+400+b[i]]){
						flag[i]=1;
						x+=a[i];
						y+=b[i];
					}
					else if(dp[i-1][x+400-a[i]][y+400-b[i]]){
						flag[i]=0;
						x-=a[i];
						y-=b[i];
					}
				}
				for(int i=1;i<=n;i++) printf("%d ",flag[i]);
				putchar('\n');
			}
		}
		else{
			int t11=0,t12=0,t21=0,t22=0;
			int s11=0,s12=0,s21=0,s22=0;
			for(int i=1;i<=n;i++){
				if(a[i]==1&&b[i]==1) t11++;
				if(a[i]==1&&b[i]==2) t12++;
				if(a[i]==2&&b[i]==1) t21++;
				if(a[i]==2&&b[i]==2) t22++;
			}
			int gs=t11%2+t12%2+t21%2+t22%2;
			bool bk=0;
			if(gs==0){
				s11=t11/2;
				s12=t12/2;
				s21=t21/2;
				s22=t22/2;
			}
			else if(gs==4){
				s11=t11/2;
				s12=t12/2+1;
				s21=t21/2+1;
				s22=t22/2;
			}
			else if(gs==1){
				s11=t11/2;
				s12=t12/2;
				s21=t21/2;
				s22=t22/2;
				if(t11%2==1){
					bk=1;
				}
				else if(t12%2==1||t21%2==1){
					bk=1;
				}
				else{
					if(t11>=2){
						s22++;
						s11--;
					}
					else if(t12>=2&&t21>=2){
						s12--;
						s21--;
						s22++;
					}
					else bk=1;
				}
			}
			else if(gs==2){
				bk=1;
			}
			else if(gs==3){
				s11=t11/2;
				s12=t12/2;
				s21=t21/2;
				s22=t22/2;
				if(t11%2==0){
					bk=1;
				}
				else if(t12%2==0||t21%2==0){
					bk=1;
				}
				else{
					if(t22>=2){
						s22--;
						s11++;
						s12++;
						s21++;
					} 
					else bk=1;
				}
			}
			int tota=0,totb=0,totc=0,totd=0;
			if(bk==1){
				printf("-1\n");
				continue;
			}
			for(int i=1;i<=n;i++){
				if(a[i]==1&&b[i]==1){
					tota++;
					if(tota<=s11) printf("1 ");
					else printf("0 ");
				}
				if(a[i]==1&&b[i]==2){
					totb++;
					if(totb<=s12) printf("1 ");
					else printf("0 ");
				}
				if(a[i]==2&&b[i]==1){
					totc++;
					if(totc<=s21) printf("1 ");
					else printf("0 ");
				}
				if(a[i]==2&&b[i]==2){
					totd++;
					if(totd<=s22) printf("1 ");
					else printf("0 ");
				}
				
			}
			putchar('\n'); 
		}
	} 
	return 0;
}

