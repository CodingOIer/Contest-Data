#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,T,seed1,seed2,p;
int ans=0,res=0,tot,answer;
int c[2000005],d[200005];
int bj[2000005];
int maxx;
void dfs(int x){
	if(x>=tot){
		for(int i=1;i<=n;i++){
			if(bj[i]%2==0){
				answer=max(answer,i);
				return;
			}
		}
		ans=max(ans,tot+1);
		
		return;
	}
	bj[c[x+1]]++;
	dfs(x+1);
	bj[c[x+1]]--;
	bj[d[x+1]]++;
	dfs(x+1);
	bj[d[x+1]]--;
}
bool vis[10000005];
int s=1;
int Solve(int a,int b){
	c[++tot]=a,d[tot]=b;
	if(tot<=20){
		answer=0;
		dfs(0);
		return answer;
	}
	vis[a]=1;
	vis[b]=1;
	while(vis[s]) s++;
	return s;
}
signed main(){
	freopen("mex.in","r",stdin);
	freopen("mex.out","w",stdout);
	n=read(),T=read(),seed1=read(),seed2=read(),p=read(); 
	for (int i=1;i<=n;i++){
		int a,b; 
		if (i<=T) a=read(),b=read();
		else a=(1ll*ans*i^seed1)%p+1, b=(1ll*ans*i^seed2)%p+1;
		res=Solve(a,b);
		ans=(ans^(1ll*res*i));
	}
	printf("%lld",ans);
	return 0;
}
