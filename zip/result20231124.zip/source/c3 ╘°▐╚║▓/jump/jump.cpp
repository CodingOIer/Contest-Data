#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while('0'<=c&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return x*f;
}
int n,m;
int fa[200005];
int dep[2000005];
vector<int>q[200005];
void dfs(int x,int f){
	fa[x]=f;
	dep[x]=dep[f]+1;
	for(auto y:q[x]){
		if(y!=f) 
			dfs(y,x);
	}
}
set<int>st[8005];
int maxx[200005];
int minx[200005];
int ggb[200005];
struct XXX{
	int l,r,id;
}z[200005];
int tot;
bool cmp(XXX x,XXX y){
	if(x.l==y.l) return x.r<y.r;
	return x.l<y.l;
}
int dis[8005][8005];
signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	n=read(),m=read();
	bool flag=1;
	memset(dis,0x3f,sizeof(dis));
	for(int i=1;i<n;i++){
		int u=read(),v=read();
		q[u].push_back(v);
		q[v].push_back(u);
		st[u].insert(v);
		st[v].insert(u);
		if(v!=u+1) flag=0;
	}
	if(flag) for(int i=0;i<=n;i++) maxx[i]=i+1;
	dfs(1,0);
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		if(u>v) swap(u,v);
		if(!flag){
			int x=u,y=v;
//			st[u].insert();
			vector<int>gg;
			gg.push_back(x);
			gg.push_back(y);
			while(x!=y){
				if(dep[x]<dep[y]) swap(x,y);
				x=fa[x];
				gg.push_back(x);
			}
			for(auto i1:gg){
				for(auto i2:gg){
					if(i1==i2) continue;
					st[i1].insert(i2);
				}
			}
		}
		else{
			maxx[u]=max(maxx[u],v);
		}
	}
	if(flag){
		for(int i=1;i<=n;i++)
			maxx[i]=max(maxx[i],maxx[i-1]);
		int Q=read();
		for(int i=1;i<=Q;i++){
			int u=read(),v=read();
			if(u>v) swap(u,v);
			z[i]={u,v,i};
		}
		sort(z+1,z+Q+1,cmp);
		int r=0,ans=0;
		for(int i=1;i<=Q;i++){
			if(z[i].l!=z[i-1].l){
				r=z[i].l;
				ans=0;
			}
			while(r<z[i].r){
				r=maxx[r];
				ans++;
			}
//			cout<<z[i].l<<" "<<z[i].r<<" "<<r<<" "<<maxx[r]<<" "<<ans<<endl;
			ggb[z[i].id]=ans;
		}
		for(int i=1;i<=Q;i++){
			printf("%lld\n",ggb[i]);
		}
	}
	else{
		for(int i=1;i<=n;i++) dis[i][i]=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(st[i].count(j)){
					dis[i][j]=1;
				}
			}
		}
		for(int k=1;k<=n;k++){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					if(dis[i][j]>dis[i][k]+dis[k][j]){
						dis[i][j]=dis[i][k]+dis[k][j];
					} 
				}
			}
		} 
		int Q=read();
		while(Q--){
			int u=read(),v=read();
			printf("%lld\n",dis[u][v]);
		}
	}
	return 0;
}


