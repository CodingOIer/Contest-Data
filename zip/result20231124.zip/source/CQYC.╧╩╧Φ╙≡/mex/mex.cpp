#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;
int n,T,seed1,seed2,p,cnt;
int fa[N],Mx[N],num[N],edge[N];
ll ans;
set<int>s;
set<int>::iterator it;
inline void Max(int &x,int y) {x=x>y?x:y;}
inline void Min(int &x,int y) {x=x>y?y:x;}
inline bool check(int x) {return (num[x]&1)!=(edge[x]&1);}
int Find(int x) {return x==fa[x]?x:fa[x]=Find(fa[x]);}
inline void add(int x)
{
    if(num[x]) return;
    fa[x]=Mx[x]=x,num[x]=1;
    s.insert(x);
}
void merge(int x,int y)
{
    x=Find(x),y=Find(y);
    if(check(x)) s.erase(Mx[x]);
    if(check(y)) s.erase(Mx[y]);
    ++edge[x];
    if(x==y) goto L;
    if(num[x]<num[y]) swap(x,y);
    fa[y]=x;
    Max(Mx[x],Mx[y]);
    num[x]+=num[y];
    edge[x]+=edge[y];
L:  if(check(x)) s.insert(Mx[x]);
}
int solve(int x,int y)
{
    if(x>=N&&y>=N) return *s.begin();
    if(x>=N||y>=N)
    {
        if(x>y) swap(x,y);
        x=Find(x);
        if(check(x)) s.erase(Mx[x]);
        Mx[x]=y;
        ++edge[x];
        if(check(x)) s.insert(Mx[x]);
        return *s.begin();
    }
    add(x),add(y);
    merge(x,y);
    return *s.begin();
}
int main()
{
    freopen("mex.in","r",stdin);
    freopen("mex.out","w",stdout);
    scanf("%d%d%d%d%d",&n,&T,&seed1,&seed2,&p);
    add(1);
    for(int i=1,u,v;i<=n;i++)
    {
        if(i<=T) scanf("%d%d",&u,&v);
        else u=(1ll*ans*i^seed1)%p+1,v=(1ll*ans*i^seed2)%p+1;
        add(i+1);
        ans^=1ll*i*solve(u,v);
    }
    printf("%lld\n",ans);
    cerr<<"[Runtime]:"<<1.0*clock()/1e6<<"s\n";
    fclose(stdin);fclose(stdout);
    return 0;
}
