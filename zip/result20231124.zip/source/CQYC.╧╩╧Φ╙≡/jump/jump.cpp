#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=2e5+10,M=2e6+10,K=N<<2;
int n,m,q,dis[N],tot[N];
int T,stk[N];
int fa[N],dep[N],dfn[N],son[N],num[N],top[N];
int first[N],to[M],nxt[M],cnt;
bool flag,subtask=1,vis[N];
queue<int>Q;
vector<int>edge[N];
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void dfs(int x,int fr,int To)
{
    stk[++T]=x;
    if(x==To) return flag=1,void();
    for(int i=first[x],v;i&&!flag;i=nxt[i])
        if((v=to[i])!=fr) dfs(v,x,To);
    if(!flag) --T;
}
int bfs(int S,int To)
{
    if(S==To) return 0;
    while(!Q.empty()) Q.pop();
    for(int i=1;i<=n;i++) dis[i]=1e9;
    dis[S]=0,Q.push(S);
    while(!Q.empty())
    {
        int x=Q.front();
        Q.pop();
        for(int v:edge[x])
            if(dis[v]>dis[x]+1)
            {
                dis[v]=dis[x]+1;
                if(v==To) return dis[v];
                Q.push(v);
            }
    }
    return -1;
}
void dfs1(int x,int fr)
{
    tot[x]=tot[fr]+vis[x];
    fa[x]=fr;num[x]=1;
    dep[x]=dep[fr]+1;
    for(int i=first[x],v;i;i=nxt[i])
    {
        if((v=to[i])==fr) continue;
        dfs1(v,x);num[x]+=num[v];
        if(num[son[x]]<num[v]) son[x]=v;
    }
}
void dfs2(int x,int t)
{
    top[x]=t;
    dfn[x]=++cnt;
    if(!son[x]) return;
    dfs2(son[x],t);
    for(int i=first[x],v;i;i=nxt[i])
        if((v=to[i])!=fa[x]&&v!=son[x]) dfs2(v,v);
}
int LCA(int x,int y)
{
    for(;top[x]!=top[y];x=fa[top[x]])
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
    return dep[x]<dep[y]?x:y;
}
void solve2()
{
    int u,v,lca;
    u=read(),v=read();
    dfs(u,0,v);
    for(int i=1;i<=T;i++) vis[stk[i]]=1;
    dfs1(1,0);cnt=0;dfs2(1,0);
    q=read();
    while(q--)
    {
        u=read(),v=read();
        lca=LCA(u,v);
        int d1=dep[u]+dep[v]-2*dep[lca],d2=tot[u]+tot[v]-2*tot[lca]+vis[lca];
        d1-=max(0,d2-2);
        cout<<d1<<'\n';
    }
}
int main()
{
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    n=read(),m=read();
    int u,v;
    for(int i=1;i<n;i++)
    {
        u=read(),v=read(),inc(u,v),inc(v,u);
        if(u+1!=v) subtask=0;
    }
    if(m==1) return solve2(),0;
    for(int i=1;i<=m;i++)
    {
        u=read(),v=read();
        T=flag=0;dfs(u,0,v);
        for(int j=1;j<=T;j++)
            for(int k=j+1;k<=T;k++)
                edge[stk[j]].push_back(stk[k]),
                edge[stk[k]].push_back(stk[j]);
    }
    for(int i=1;i<=n;i++)
        for(int j=first[i];j;j=nxt[j]) edge[i].push_back(to[j]);
    q=read();
    while(q--)
    {
        u=read(),v=read();
        cout<<bfs(u,v)<<'\n';
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
