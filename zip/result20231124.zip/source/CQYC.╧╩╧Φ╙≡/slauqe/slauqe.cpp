#include<bits/stdc++.h>
#define fi first
#define se second
#define mk make_pair
#define pi pair<int,int>
using namespace std;
#define dIO_USE_BUFFER
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;
const int N=2e5+10,M=210,K=410;
int T,n,A[N],B[N],C[N];
int S1,S2,t[4];
map<pi,int>s;
void out(int a,int b,int c,int d)
{
    for(int i=1;a&&i<=n;i++)
        if(A[i]==1&&B[i]==1) C[i]=1,a--;
    for(int i=1;b&&i<=n;i++)
        if(A[i]==1&&B[i]==2) C[i]=1,b--;
    for(int i=1;c&&i<=n;i++)
        if(A[i]==2&&B[i]==1) C[i]=1,c--;
    for(int i=1;d&&i<=n;i++)
        if(A[i]==2&&B[i]==2) C[i]=1,d--;
    for(int i=1;i<=n;i++)
        putchar(C[i]^48),putchar(i==n?'\n':' ');
}
int main()
{
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
    io.read(T);
    s[mk(1,1)]=0;
    s[mk(1,2)]=1;
    s[mk(2,1)]=2;
    s[mk(2,2)]=3;
L:  while(T--)
    {
        io.read(n);
        for(int i=1;i<=n;i++) C[i]=0;
        S1=S2=0;
        for(int i=0;i<4;i++) t[i]=0;
        for(int i=1;i<=n;i++) io.read(A[i]),S1+=A[i];
        for(int i=1;i<=n;i++) io.read(B[i]),S2+=B[i];
        if((S1&1)||(S2&1)) {puts("-1");continue;}
        for(int i=1;i<=n;i++) ++t[s[mk(A[i],B[i])]];
        for(int a,b=0,c,d,a_2d;b<=t[1];b++)
        {
            if(S1/2-b<0) continue;
            if(S2/2-2*b<0) continue;
            c=(S1/2-b)-(S2/2-2*b);
            if(c<0||c>t[2]) continue;
            a_2d=(S1/2-b)-2*c;
            if(a_2d<0) continue;
            d=min(t[3],a_2d/2);
            a=a_2d-2*d;
            if(a<0||a>t[0]) continue;
            out(a,b,c,d);
            goto L;
        }
        puts("-1");
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
