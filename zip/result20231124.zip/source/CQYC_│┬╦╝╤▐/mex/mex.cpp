#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e6+5;
int x,n,t,se1,se2,p,a[maxn],b[maxn],ans;
map<int,int> ma;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void solve(int x,int y){
    if(x>y){
        int res=1;
        for(auto i:ma){
            int u=i.first,v=i.second;
            if(v%2){
                if(u>res){
                    ans=max(ans,res);
                    return;
                }
                ++res;
            }
        }
        ans=max(ans,res);
        return;
    }
    ma[a[x]]++;
    solve(x+1,y);
    ma[a[x]]--;
    if(!ma[a[x]])
        ma.erase(a[x]);
    ma[b[x]]++;
    solve(x+1,y);
    ma[b[x]]--;
    if(!ma[b[x]])
        ma.erase(b[x]);
}
signed main(){
    freopen("mex.in","r",stdin);
    freopen("mex.out","w",stdout);
    n=read(),t=read(),se1=read(),se2=read(),p=read();
    for(int i=1;i<=t;i++){
        a[i]=read(),b[i]=read();
        ma.clear();
        ans=0;
        solve(1,i);
        x^=(ans*i);
    }
    for(int i=t+1;i<=n;i++){
        a[i]=(x*i^se1)%p+1,b[i]=(x*i^se2)%p+1;
        ma.clear();
        ans=0;
        solve(1,i);
        x^=(ans*i);
    }
    printf("%lld\n",x);
    return 0;
}
