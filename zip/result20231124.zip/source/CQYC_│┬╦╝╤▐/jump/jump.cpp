#include <bits/stdc++.h>
using namespace std;
const int maxn=2e5+5;
int n,m,u,v,q,p[maxn],cnt,dis[maxn],vis[maxn];
vector<int> to[maxn],ve[maxn];
struct node{
    int u,v;
}e[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int dfs(int u,int f,int x){
    if(u==x)
        return 1;
    p[++cnt]=u;
    for(auto v:ve[u])
        if(v!=f){
            if(dfs(v,u,x)){
                for(int i=1;i<=cnt;i++){
                    to[p[i]].push_back(v);
                    to[v].push_back(p[i]);
                }
                --cnt;
                return 1;
            }
        }
    --cnt;
    return 0;
}
int sol(int x,int y){
    for(int i=1;i<=n;i++)
        vis[i]=0,dis[i]=1e9;
    priority_queue<pair<int,int> > q;
    dis[x]=0;
    q.push({0,x});
    while(!q.empty()){
        int u=q.top().second;
        q.pop();
        if(vis[u])
            continue;
        vis[u]=1;
        if(u==y)
            break;
        for(auto v:to[u])
            if(!vis[v]&&dis[v]>dis[u]+1){
                dis[v]=dis[u]+1;
                q.push({-dis[v],v});
            }
    }
    return dis[y];
}
int cmp(node a,node b){
    return a.v>b.v;
}
signed main(){
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    n=read(),m=read();
    int bj=0;
    for(int i=1;i<n;i++){
        u=read(),v=read();
        to[u].push_back(v);
        to[v].push_back(u);
        ve[u].push_back(v);
        ve[v].push_back(u);
        if(v!=u+1)
            bj=1;
    }
    if(!bj){
        for(int i=1;i<=m;i++){
            e[i].u=read(),e[i].v=read();
            if(e[i].u>e[i].v)
                swap(e[i].u,e[i].v);
        }
        sort(e+1,e+1+m,cmp);
        int r=n+1;
        for(int i=1;i<=n;i++)
            dis[i]=i+1;
        for(int i=1;i<=m;i++){
            if(e[i].u<r){
                for(int j=e[i].u;j<r&&j<e[i].v;j++)
                    dis[j]=e[i].v;
                r=e[i].u;
            }
        }
        q=read();
        while(q--){
            u=read(),v=read();
            if(u>v)
                swap(u,v);
            int ans=0;
            while(u<v){
                ++ans;
                u=dis[u];
            }
            printf("%d\n",ans);
        }
        return 0;
    }
    for(int i=1;i<=m;i++){
        u=read(),v=read();
        cnt=0;
        dfs(u,0,v);
    }
    q=read();
    while(q--){
        u=read(),v=read();
        printf("%d\n",sol(u,v));
    }
    return 0;
}