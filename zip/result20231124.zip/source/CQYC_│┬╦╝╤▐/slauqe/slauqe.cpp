#include <bits/stdc++.h>
using namespace std;
const int maxn=2e5+5;
int t,n,a[maxn],b[maxn],c[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int solve(int k,int ux,int vx,int uy,int vy){
    if(k>n){
        if(ux==vx&&uy==vy)
            return 1;
        return 0;
    }
    c[k]=1;
    if(solve(k+1,ux+a[k],vx,uy+b[k],vy))
        return 1;
    c[k]=0;
    if(solve(k+1,ux,vx+a[k],uy,vy+b[k]))
        return 1;
    return 0;
}
signed main(){
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
    t=read();
    while(t--){
        n=read();
        for(int i=1;i<=n;i++)
            a[i]=read();
        for(int i=1;i<=n;i++)
            b[i]=read();
        if(!solve(1,0,0,0,0))
            puts("-1");
        else{
            for(int i=1;i<=n;i++)
                printf("%d ",c[i]);
            putchar('\n');
        }
    }
    return 0;
}