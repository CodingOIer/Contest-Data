#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*P1=buff,*P2=buff;
    char getch(){
        return P1==P2&&(P2=((P1=buff)+fread(buff,1,1<<21,stdin)),P1==P2)?EOF:*P1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n;
int b[4],a[200005];
int AAA[200005],BBB[200005];
signed main(){
	freopen("slauqe.in","r",stdin);
	freopen("slauqe.out","w",stdout);
	int T;
	read(T);
	while(T--){
//		cout<<T<<":"<<endl;
		memset(b,0,sizeof b);
		read(n);
		for(int i=1;i<=n;i++)read(AAA[i]);
		for(int i=1;i<=n;i++)read(BBB[i]);
		for(int i=1;i<=n;i++){
			a[i]=((AAA[i]-1)<<1)+(BBB[i]-1);
			b[a[i]]++;
		}
		if(abs(b[1]-b[2])&1){
			write(-1),putch('\n');
			continue;
		}
		int s0=-1,s1=-1,s2=-1,s3=-1;
		for(int i=0;i<=b[1];i++){
			int j=i-((b[1]-b[2])/2);
			if(j<0||j>b[2])continue;
			int s=((b[1]-i)+2*(b[2]-j))-i-2*j;
			int y=s/2;
			if(y>b[3])y=b[3];
			else if(y<-b[3])y=b[3];
			int x=s-2*y;
			if(x<-b[0]||x>b[0])continue;
			int A=(b[0]+x)/2,B=(b[3]+y)/2;
			s0=A,s1=i,s2=j,s3=B;
			break;
		}
//		cout<<s0<<'-'<<s1<<'-'<<s2<<'-'<<s3<<endl;
		if(s0==-1){
			write(-1),putch('\n');
			continue;
		} 
//		int S0=s0,S1=s1,S2=s2,S3=s3;
		for(int i=1;i<=n;i++){
			if(a[i]==0){
				if(s0){
					putch('1');
					s0--;
				}else{
					putch('0');
				}
			}else if(a[i]==1){
				if(s1){
					putch('1');
					s1--;
				}else{
					putch('0');
				}
			}else if(a[i]==2){
				if(s2){
					putch('1');
					s2--;
				}else{
					putch('0');
				}
			}else{
				if(s3){
					putch('1');
					s3--;
				}else{
					putch('0');
				}
			}
			putch(' '); 
		}
//		putch('{');
//		write(S0+S1+S2*2+S3*2-(b[0]-S0)-(b[1]-S1)-2*(b[2]-S2)-2*(b[3]-S3));
//		putch('|');
//		write(S0+2*S1+S2+2*S3-(b[0]-S0)-2*(b[1]-S1)-(b[2]-S2)-2*(b[3]-S3));
		putch('\n');
	}
	flush();
	return 0;
}/*
1
4
1 1 2 2
1 2 1 2
*/
