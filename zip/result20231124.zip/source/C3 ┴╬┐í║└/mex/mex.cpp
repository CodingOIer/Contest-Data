#include <bits/stdc++.h>
using namespace std;
int N;
struct node{
	int a,b;
}p[25];
map<int,int>m;
unsigned long long
Solve(int a,int b){
	int ans=0;
	p[++N]=(node){a,b};
	for(int s=0;s<(1<<N);s++){
		m.clear();
		for(int i=1;i<=N;i++){
			if((s>>(i-1))&1){
				m[p[i].b]^=1;
//				cout<<p[i].b<<'{'<<m[p[i].b]<<endl;
			}else{
				m[p[i].a]^=1;
//				cout<<p[i].a<<'{'<<m[p[i].a]<<endl;
			}
		}
		int now=1;
		while(1){
			if(m[now]){
				now++;
			}else{
				break;
			}
		}
//		cout<<N<<':'<<now<<endl;
		ans=max(ans,now);
	}
	
	return ans;
}

int main(){
	freopen("mex.in","r",stdin);
	freopen("mex.out","w",stdout);
	int n,T,seed1,seed2,p;
	unsigned long long ans=0,res=0;
	scanf("%d %d %d %d %d",&n,&T,&seed1,&seed2,&p);
	for (int i=1;i<=n;i++){
		int a,b; 
		if (i<=T) scanf("%d %d",&a,&b);
		else a=(1ll*ans*i^seed1)%p+1, b=(1ll*ans*i^seed2)%p+1;
		res=Solve(a,b);
		ans=(ans^(1ll*res*i));
	}
	printf("%llu",ans);
	return 0;
}
