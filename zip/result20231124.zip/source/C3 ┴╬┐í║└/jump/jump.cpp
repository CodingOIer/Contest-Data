#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*P1=buff,*P2=buff;
    char getch(){
        return P1==P2&&(P2=((P1=buff)+fread(buff,1,1<<21,stdin)),P1==P2)?EOF:*P1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,m,N,T;
int fa[200005],dep[200005],f[200005][20];
struct Edge{
	int to,w;
};
vector<Edge>to[200005];
int vis[200005],dis[16005];
void Init(int x,int p){
	fa[x]=p;
	f[x][0]=p;
	dep[x]=dep[p]+1;
	for(auto E:to[x]){
		int y=E.to;
		if(y==p)continue;
		Init(y,x);
	}
}
int st[8005];
void w(int a,int b){
	if(a==b)return;
	int tot=0;
	st[++tot]=a;
	st[++tot]=b;
	while(1){
		if(dep[a]<dep[b])swap(a,b);
		if(fa[a]==b)break;
		a=fa[a];
		st[++tot]=a;
	}
	N++;
	for(int i=1;i<=tot;i++){
		int x=st[i];
//		cout<<N<<'/'<<x<<endl;
		to[N].push_back((Edge){x,1});
		to[x].push_back((Edge){N,0});
	}
}
void bfs(int S){
	deque<int>q;
	q.push_back(S);
	memset(vis,0,sizeof vis);
	vis[S]=1;
	dis[S]=0;
	while(!q.empty()){
		int x=q.front();
//		cout<<S<<":"<<dis[x]<<"/"<<x<<endl;
		q.pop_front();
		for(auto E:to[x]){
			int y=E.to;
			if(vis[y])continue;
//			if(x>n)cout<<x<<'/'<<y<<':'<<E.w<<"-----------------------"<<endl;
			vis[y]=1;
			dis[y]=dis[x]+E.w;
			if(E.w)q.push_back(y);
			else q.push_front(y);
		}
	}
}
struct NODE{
	int u,v,id,ans;
}Q[8005];
bool cmp(NODE A,NODE B){
	return A.u<B.u;
}
bool CMP(NODE A,NODE B){
	return A.id<B.id;
}
void C(){
	queue<int>q;
	for(int i=1;i<=n;i++)
		if(vis[i]==0)q.push(i);
	while(!q.empty()){
		int x=q.front();
		q.pop();
		for(auto E:to[x]){
			int y=E.to;
			if(vis[y]==-1){
				vis[y]=vis[x]+1;
				q.push(y);
			}
		}
	}
}
int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	for(int i=19;i>=0;i--)
		if(dep[f[x][i]]>=dep[y])x=f[x][i];
	if(x==y)return x;
	for(int i=19;i>=0;i--)
		if(f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
	return f[x][0];
}
void sub_2(){
	for(int i=1;i<=19;i++)
		for(int j=1;j<=n;j++)
			f[j][i]=f[f[j][i-1]][i-1];
	memset(vis,-1,sizeof vis);
	for(int i=1;i<=m;i++){
		int u,v;
		read(u,v);
		if(u==v)continue;
		vis[u]=vis[v]=0;
		while(1){
			if(dep[u]<dep[v])swap(u,v);
			if(fa[u]==v)break;
			u=fa[u];
			vis[u]=0;
		}
	}
	C();
	read(T);
	while(T--){
		int u,v;
		read(u,v);
		write(min(dep[u]+dep[v]-2*dep[lca(u,v)],vis[u]+vis[v]+1)),putch('\n');
	}
	flush();
}
signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	read(n,m);N=n;
	for(int i=1;i<n;i++){
		int u,v;
		read(u,v);
		to[u].push_back((Edge){v,1});
		to[v].push_back((Edge){u,1});
	}
	Init(1,0);
	if(m==1){
		sub_2();
		return 0;
	}
	for(int i=1;i<=m;i++){
		int u,v;
		read(u,v);
		w(u,v);
	}
	read(T);
	for(int i=1;i<=T;i++){
		int u,v;
		read(Q[i].u,Q[i].v);
		if(Q[i].u>Q[i].v)swap(Q[i].u,Q[i].v);
		Q[i].id=i;
	}
	sort(Q+1,Q+T+1,cmp);
	for(int i=1;i<=T;i++){
		if(Q[i].u!=Q[i-1].u)bfs(Q[i].u);
		Q[i].ans=dis[Q[i].v];
	}
	sort(Q+1,Q+T+1,CMP);
	for(int i=1;i<=T;i++){
		write(Q[i].ans),putch('\n');
	}
	flush();
	return 0;
}
