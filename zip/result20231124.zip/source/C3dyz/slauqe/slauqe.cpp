#include<bits/stdc++.h>
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace std;
using namespace IO;
struct node {
    int a,b,id;
}w[200005];
int main() {
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
    int T;
    read(T);
    while(T--) {
        int n,sum1=0,sum2=0;
        read(n);
        for(int i=1;i<=n;i++){
            read(w[i].a);
            sum1+=w[i].a;
        } 
        for(int i=1;i<=n;i++) {
            read(w[i].b);
            sum2+=w[i].b;
        }
        if(sum1%2==1 || sum2%2==1) {
            putch('-');
            putch('1');
            putch('\n');
            continue;
        }
        int s11=0,s12=0,s21=0,s22=0;
        int n11=0,n12=0,n21=0,n22=0;
        for(int i=1;i<=n;i++) {
            if(w[i].a==1 && w[i].b==1) s11++;
            if(w[i].a==1 && w[i].b==2) s12++;
            if(w[i].a==2 && w[i].b==1) s21++;
            if(w[i].a==2 && w[i].b==2) s22++;
        }
        sum1/=2;
        sum2/=2;
        if(sum1>sum2) {
            int c=sum1-sum2;
            if(s21<c) {
                putch('-');
                putch('1');
                putch('\n');
                continue;
            }
            sum1-=2*c;
            sum2-=c;
            s21-=c;
            n21+=c;
        }
        if(sum1<sum2) {
            int c=sum2-sum1;
            if(s12<c) {
                putch('-');
                putch('1');
                putch('\n');
                continue;
            }
            sum1-=c;
            sum2-=2*c;
            s12-=c;
            n12+=c;
        }
        int s33=min(s12,s21);
        int flag=0;
        if(sum1) {
            int c=min(s33,sum1/3);
            if(sum1) {
                int c1=min(s22,(sum1-c*3)/2);
                if(s11>=(sum1-c*3-c1*2)) {
                    n21+=c;
                    n12+=c;
                    n22+=c1;
                    n11+=(sum1-c*3-c1*2);
                    flag=1;
                } 
            }
            if(sum1 && c>0 && flag==0) {
                c--;
                int c1=min(s22,(sum1-c*3)/2);
                if(s11>=(sum1-c*3-c1*2)) {
                    n21+=c;
                    n12+=c;
                    n22+=c1;
                    n11+=(sum1-c*3-c1*2);
                    flag=1;
                } 
            }
        }
        if(flag==0 && sum1>0) {
            putch('-');
            putch('1');
            putch('\n');
            continue;
        }
        for(int i=1;i<=n;i++) {
            if(w[i].a==1 && w[i].b==1 && n11) {
                putch('1');
                n11--;
            }
            else if(w[i].a==1 && w[i].b==2 && n12) {
                putch('1');
                n12--;
            }
            else if(w[i].a==2 && w[i].b==1 && n21) {
                putch('1');
                n21--;
            }
            else if(w[i].a==2 && w[i].b==2 && n22) {
                putch('1');
                n22--;
            } else putch('0');
        }
        putch('\n');
    }
    flush();
    return 0;
}