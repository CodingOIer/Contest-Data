#include<bits/stdc++.h>
using namespace std;
int id[200005],top[200005],siz[200005],dep[200005],son[200005],f[200005],cnt;
int stk[200005],tot,dis[105],vis[105];
vector<int> q[200005],w[200005];
void dfs1(int x,int fa) {
    f[x]=fa;
    dep[x]=dep[fa]+1;
    siz[x]=1;
    for(int i=0;i<q[x].size();i++) {
        int to=q[x][i];
        if(to==fa) continue;
        dfs1(to,x);
        siz[x]+=siz[to];
        if(siz[son[x]]<siz[to]) son[x]=to;
    }
}
void dfs2(int x,int topf) { 
    id[x]=++cnt;
    top[x]=topf;
    if(!son[x]) return ;
    dfs2(son[x],topf);
    for(int i=0;i<q[x].size();i++) {
        int to=q[x][i];
        if(to==f[x] || to==son[x]) continue;
        dfs2(to,to);
    }
}
int lca(int x,int y) {
    while(top[x]!=top[y]) {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        x=f[top[x]];
    }
    if(dep[x]>dep[y]) swap(x,y);
    return x;
}
void solve(int x,int fa) {
    int flag=(tot>0);
    while(1) {
        stk[++tot]=x;
        if(flag && f[x]==fa) return ;
        if(!flag && x==fa) return ;
        x=f[x];
    }
}
void bfs(int x) {
    queue<int> Q;
    memset(vis,0,sizeof vis);
    memset(dis,0x3f,sizeof dis);
    dis[x]=0;
    Q.push(x);
    while(!Q.empty()) {
        int u=Q.front();
        Q.pop();
        vis[u]=1;
        for(int i=0;i<w[u].size();i++) {
            int v=w[u][i];
            dis[v]=min(dis[v],dis[u]+1);
            if(!vis[v]) Q.push(v);
        }
    }
}
int main() {
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    int n,m;
    scanf("%d %d",&n,&m);
    for(int i=1;i<n;i++) {
        int x,y;
        scanf("%d %d",&x,&y);
        q[x].push_back(y);
        q[y].push_back(x);
        w[x].push_back(y);
        w[y].push_back(x);
    }
    dfs1(1,0);
    dfs2(1,1);
    for(int i=1;i<=m;i++) {
        int x,y;
        scanf("%d %d",&x,&y);
        tot=0;
        solve(x,lca(x,y));
        solve(y,lca(x,y));
        for(int j=1;j<=tot;j++) {
            for(int k=1;k<=tot;k++) {
                w[stk[j]].push_back(stk[k]);
            }
        }
    }
    int Q;
    scanf("%d",&Q);
    while(Q--) {
       int x,y;
       scanf("%d %d",&x,&y);
       bfs(x);
       printf("%d\n",dis[y]); 
    }
    return 0;
}
/*
10 2
2 1
3 2
4 1
5 1
6 1
7 6
8 5
9 7
10 1
1 9
1 9
10
7 2
10 8
4 8
5 10
7 9
2 1
9 7
9 1
7 3
4 10

*/