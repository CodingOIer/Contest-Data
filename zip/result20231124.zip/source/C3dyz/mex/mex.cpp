#include <bits/stdc++.h>
#define int long long
using namespace std;
int a[200005],b[200005];
int ans=0,res=0;
int Solve(int num){
	// hello :)
    int maxn=0;
    for(int i=0;i<(1<<num);i++) {
        int stk[21];
        memset(stk,0,sizeof stk);
        for(int j=1;j<=num;j++) {
            if(i&(1<<(j-1))) stk[b[j]]++;
            else stk[a[j]]++;
        }
        int tmp=1;
        for(int j=1;j<=num;j++) {
            if(stk[j]%2==1) tmp++;
            else break;
        }
        maxn=max(maxn,tmp);
    }
	return maxn;
}

signed main(){
    freopen("mex.in","r",stdin);
    freopen("mex.out","w",stdout);
	int n,T,seed1,seed2,p;
	scanf("%lld %lld %lld %lld %lld",&n,&T,&seed1,&seed2,&p);
	for (int i=1;i<=n;i++){
		if (i<=T) scanf("%d %d",&a[i],&b[i]);
		else a[i]=(1ll*ans*i^seed1)%p+1, b[i]=(1ll*ans*i^seed2)%p+1;
		res=Solve(i);
		ans=(ans^(1ll*res*i));
	}
	printf("%lld\n",ans);
	return 0;
}
