#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct Query {
    int n, flag;
    vector<int> a, b;

    void init() {
        n = read(), a.resize(n), b.resize(n);
        for(int i = 0; i < n; i++) a[i] = read();
        for(int i = 0; i < n; i++) b[i] = read();
    }

    void inputans() {
        int x = read();
        if(x == -1) flag = 1;
        else for(int i = 1; i < n; i++) read();
    }

    bool check() {
        int s[2][2] = { { 0, 0 }, { 0, 0 }}, x = read();
        if(x == -1) return flag; 
        s[x][0] += a[0], s[x][1] += b[0];
        for(int i = 1; i < n; i++) {
            x = read();
            s[x][0] += a[i], s[x][1] += b[i];
        }
        if(s[0][0] != s[1][0] or s[0][1] != s[1][1]) return 0;
        return 1;
    }
} op[N];

bool edmer;
bool check() {
	freopen("slauqe.in", "r", stdin);
	// freopen("slauqe.out", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    int T = read();
    for(int i = 1; i <= T; i++) op[i].init();

	freopen("slauqe.ans", "r", stdin);

    for(int i = 1; i <= T; i++) op[i].inputans();

	freopen("slauqe.out", "r", stdin);

    for(int i = 1; i <= T; i++) if(!op[i].check()) {
        printf("Wrong on test #%d\n", i);
        return 0;
    }

    return 1;

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
} 