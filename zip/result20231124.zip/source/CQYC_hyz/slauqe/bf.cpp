#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

int n, s1, s2;
int a[N], b[N];

void solve() {
    n = read(), s1 = 0, s2 = 0;
    for(int i = 0; i < n; i++) a[i] = read(), s1 += a[i];
    for(int i = 0; i < n; i++) b[i] = read(), s2 += b[i];

    if((s1 & 1) or (s2 & 1)) return puts("-1"), void();

    s1 >>= 1, s2 >>= 1;

    for(int i = 0; i < (1 << n); i++) {
        int f = 0, g = 0;
        for(int j = 0; j < n; j++) if(i >> j & 1) f += a[j], g += b[j];
        if(f != s1 or g != s2) continue;
        for(int j = 0; j < n; j++) write(i >> j & 1), putchar(' ');
        return putchar('\n'), void();
    }

    puts("-1");
}

bool edmer;
signed main() {
	freopen("slauqe.in", "r", stdin);
	freopen("slauqe.ans", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 