#include<bits/stdc++.h>
using namespace std;

bool check();

int T = 0;
signed main() {
    system("g++ -O2 -Wall -std=c++14 maker.cpp -o maker");
    system("g++ -O2 -Wall -std=c++14 checker.cpp -o checker");
    system("g++ -O2 -Wall -std=c++14 bf.cpp -o bf");
    system("g++ -O2 -Wall -std=c++14 slauqe.cpp -o slauqe");

	while(++T) {
		system("./maker");
		double st = clock();
		system("./slauqe");
		double ed = clock();
		system("./bf");

		if(!check()) {
			puts("Wrong Answer");
			return 0;
		} 
		else printf("Accepted, test #%d, time %0.lfms\n", T, ed - st);

	}
    return 0;
}