#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

int n, A, B, C, D, sum;
int a[N], b[N], c[4];

void solve() {
    n = read(), A = B = C = D = sum = 0;
    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= n; i++) b[i] = read();

    for(int i = 1; i <= n; i++) {
        if(a[i] == 1 and b[i] == 2) A++;
        if(a[i] == 2 and b[i] == 1) B++;
        if(a[i] == 1 and b[i] == 1) C++;
        if(a[i] == 2 and b[i] == 2) D++;
        sum += b[i];
    }

    if(((A - B) & 1) or (sum & 1)) return puts("-1"), void();

    bool flag = 0;

    for(int i = 0; i <= A; i++) {
        int j = i - (A - B) / 2;
        if(j < 0 or j > B) continue;
        int rest = sum / 2 - 2 * i - j;
        int k = rest & 1, l = rest / 2;
        if(l > D) k += (l - D) * 2, l = D;
        if(k > C or rest < 0) continue;
        flag = 1, c[0] = i, c[1] = j, c[2] = k, c[3] = l;
        break;
    }

    if(!flag) return puts("-1"), void();

    for(int i = 1; i <= n; i++) {
        if(a[i] == 1 and b[i] == 2) c[0] ? c[0]--, putchar('1') : putchar('0');
        if(a[i] == 2 and b[i] == 1) c[1] ? c[1]--, putchar('1') : putchar('0');
        if(a[i] == 1 and b[i] == 1) c[2] ? c[2]--, putchar('1') : putchar('0');
        if(a[i] == 2 and b[i] == 2) c[3] ? c[3]--, putchar('1') : putchar('0');
        putchar(' ');
    }
    putchar('\n');
}

bool edmer;
signed main() {
	freopen("slauqe.in", "r", stdin);
	freopen("slauqe.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 