#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e6 + 10;

int n, T, seed1, seed2, p, ans;
int fa[N], mx[N];

bool v1[N], v2[N];

set<int> s;

int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }

void update(int x, int y) {
    if(x > y) swap(x, y);
    if(x >= N) return;

    if(y >= N) {
        x = find(x);
        if(!v1[x]) s.erase(mx[x]);
        v2[x] = v1[x] = 1; 
        return;
    }

    x = find(x), y = find(y);
    if(x == y) {
        if(!v1[x]) s.erase(mx[x]);
        v1[x] = (v1[x] ^ 1) | v2[x];
        if(!v1[x]) s.insert(mx[x]);
        return;
    }

    if(!v1[x] and !v1[y]) s.erase(min(mx[x], mx[y]));
    else if(v2[x] or v2[y]) {
        if(!v1[x]) s.erase(mx[x]);
        if(!v1[y]) s.erase(mx[y]);
    }
    else if(v1[x] and !v1[y]) s.erase(mx[y]);
    else if(!v1[x] and v1[y]) s.erase(mx[x]);
    else s.insert(max(mx[x], mx[y]));

    fa[y] = x, Max(mx[x], mx[y]), v2[x] |= v2[y];
    v1[x] = (v1[x] ^ v1[y]) | v2[x];
}

bool edmer;
signed main() {
	freopen("mex.in", "r", stdin);
	freopen("mex.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), T = read(), seed1 = read(), seed2 = read(), p = read();

    for(int i = 1; i < N; i++) fa[i] = mx[i] = i, s.insert(i);

    for(int i = 1; i <= T; i++) update(read(), read()), ans ^= (i * *s.begin());

    for(int i = T + 1; i <= n; i++) {
        int x = ((ans * i) ^ seed1) % p + 1;
        int y = ((ans * i) ^ seed2) % p + 1;
        update(x, y), ans ^= (i * *s.begin());
    }

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 