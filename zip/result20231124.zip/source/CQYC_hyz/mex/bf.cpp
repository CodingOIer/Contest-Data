#include <bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e6 + 10;

struct node {
    int x, y;
} a[N];

int n, T, seed1, seed2, p, ans, m;
int c[N];

int update(int x, int y) {
    int res = 1;
    a[m++] = { x, y };
    for(int i = 0; i < (1 << m); i++) {
        int x = 1;
        for(int j = 1; j <= m + 6; j++) c[j] = 0;
        for(int j = 0; j < m; j++) (i >> j & 1) ? c[min(N - 1, a[j].x)]++ : c[min(N - 1, a[j].y)]++;
        while(c[x] & 1) x++; Max(res, x);
    }
    return res;
}

bool edmer;
signed main() {
	freopen("mex.in", "r", stdin);
	freopen("mex.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), T = read(), seed1 = read(), seed2 = read(), p = read();

    for(int i = 1; i <= T; i++) ans ^= i * update(read(), read());

    for(int i = T + 1; i <= n; i++) {
        int x = ((ans * i) ^ seed1) % p + 1;
        int y = ((ans * i) ^ seed2) % p + 1;
        ans ^= i * update(x, y);
    }

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 