#include<bits/stdc++.h>
using namespace std;
int T = 0;
signed main() {
    system("g++ -O2 -Wall -std=c++14 maker.cpp -o maker");
    system("g++ -O2 -Wall -std=c++14 bf.cpp -o bf");
    system("g++ -O2 -Wall -std=c++14 jump.cpp -o jump");

	while(++T) {
		system("./maker");
		double st = clock();
		system("./jump");
		double ed = clock();
		system("./bf");

		if(system("diff -Z -s jump.out jump.ans")) {
			puts("Wrong Answer");
			return 0;
		} 
		else printf("Accepted, test #%d, time %0.lfms\n", T, ed - st);

	}
    return 0;
}