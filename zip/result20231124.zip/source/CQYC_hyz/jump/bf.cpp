#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 4e5 + 10;

int n, m, q;

vector<int> e[N];

namespace sub1 {
    const int M = 20;

    int cnt, top, tot;
    int dfn[N], low[N], stk[N], dep[N], d[N], st[N][M];

    vector<int> E[N];

    void tarjan(int x) {
        dfn[x] = low[x] = ++cnt, stk[++top] = x;
        for(int v : e[x]) {
            if(!dfn[v]) {
                tarjan(v), Min(low[x], low[v]);
                if(low[v] >= dfn[x]) {
                    E[x].push_back(++tot);
                    while(stk[top] ^ x) E[tot].push_back(stk[top--]);
                }
            }
            else Min(low[x], dfn[v]);
        }
    }

    void dfs(int x, int fa) {
        d[x] = d[fa] + (x <= n), st[x][0] = fa, dep[x] = dep[fa] + 1;
        for(int i = 1; i < M; i++) st[x][i] = st[st[x][i - 1]][i - 1];

        for(int v : E[x]) dfs(v, x);
    }

    int lca(int x, int y) {
        if(dep[x] < dep[y]) swap(x, y);
        for(int i = M - 1; i + 1; i--) if(dep[st[x][i]] >= dep[y]) x = st[x][i];
        if(x == y) return x;
        for(int i = M - 1; i + 1; i--) if(st[x][i] ^ st[y][i]) x = st[x][i], y = st[y][i];
        return st[x][0];
    }

    void main() {
        for(int i = 1; i <= m; i++) {
            int u = read(), v = read();
            e[u].push_back(v), e[v].push_back(u);
        }

        tot = n, tarjan(1), dfs(1, 0), q = read();

        while(q--) {
            int x = read(), y = read(), lc = lca(x, y);
            write(d[x] + d[y] - d[lc] - d[lc]), putchar('\n');
        }
    }
}

namespace sub2 {
    const int M = 1010;

    int dep[N], fa[N], d[M][M];

    vector<int> p;

    void dfs(int x) {
        dep[x] = dep[fa[x]] + 1, d[x][x] = 0;
        for(int v : e[x]) {
            d[x][v] = 1;
            if(v ^ fa[x]) fa[v] = x, dfs(v);
        }
    }

    void main() {
        memset(d, 0x3f, sizeof(d)), dfs(1);
        for(int i = 1; i <= m; i++) {
            int u = read(), v = read();
            p.clear();
            while(u ^ v) {
                if(dep[u] < dep[v]) swap(u, v);
                p.push_back(u), u = fa[u];
            }
            p.push_back(u);

            for(int x : p) for(int y : p) if(x ^ y) d[x][y] = 1;
        }

        for(int k = 1; k <= n; k++) for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++) Min(d[i][j], d[i][k] + d[k][j]);

        q = read();

        while(q--) {
            int u = read(), v = read();
            write(d[u][v]), putchar('\n');
        }
    }
}

namespace sub3 {

    const int M = 20;

    int R[N], st[N][M];

    bool check() {
        for(int i = 1; i <= n; i++) for(int x : e[i]) if(abs(i - x) > 1) return 0;
        return 1;
    }

    void main() {
        for(int i = 1; i <= n; i++) R[i] = i + 1;

        for(int i = 1; i <= m; i++) {
            int l = read(), r = read();
            if(l > r) swap(l, r);
            Max(R[l], r);
        }

        for(int i = 1; i <= n; i++) Max(R[i], R[i - 1]), st[i][0] = R[i];

        for(int j = 1; j < M; j++)
            for(int i = 1; i <= n; i++)
                st[i][j] = st[min(n, st[i][j - 1])][j - 1];

        q = read();

        while(q--) {
            int l = read(), r = read(), ans = 0;
            if(l > r) swap(l, r);
            if(l == r) puts("0");
            else {
                for(int i = M - 1; i + 1; i--) if(st[l][i] < r) ans |= (1 << i), l = st[l][i];
                write(ans + 1), putchar('\n');
            }
        }
    }
}

namespace sub4 {
    struct node {
        int x, y, lc;
    } a[N];

    struct Query {
        int x, id;
    };

    int fa[N], ans[N], f[N], dep[N];

    vector<Query> op[N];

    vector<int> h[N];

    int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }

    void dfs1(int x, int fr) {
        dep[x] = dep[fr] + 1, f[x] = fr;
        for(int v : h[x]) {
            if(fa[v + n]) a[v].lc = find(v + n);
            else fa[v + n] = x;
        }
        for(int v : e[x]) if(v ^ fr) dfs1(v, x), fa[v] = x;
    }

    void dfs2(int x, int fr) {
        for(int v : e[x]) if(v ^ fr) {
            dfs2(v, x);
            if(dep[f[v]] < dep[f[x]]) f[x] = f[v];
        }
    }

    void work(int x) {
        for(int i = 1; i <= n; i++) fa[i] = i;
        for(int i = 1; i <= m; i++) fa[n + i] = 0;

        dfs1(x, 0);

        for(int i = 1; i <= m; i++) {
            int x = a[i].x, y = a[i].y, lc = a[i].lc;
            if(dep[lc] < dep[f[x]]) f[x] = lc;
            if(dep[lc] < dep[f[y]]) f[y] = lc;
        }

        dfs2(x, 0);

        for(Query l : op[x]) {
            int p = l.x, res = 0;
            while(p ^ x) res++, p = f[p];
            ans[l.id] = res;
        }
    }

    void main() {
        for(int i = 1; i <= m; i++) {
            int x = read(), y = read();
            h[x].push_back(i), h[y].push_back(i), a[i] = { x, y, 0 };
        }
        
        q = read();
        for(int i = 1; i <= q; i++) {
            int x = read(), y = read();
            op[x].push_back({ y, i });
        }

        for(int i = 1; i <= n; i++) work(i);

        for(int i = 1; i <= q; i++) write(ans[i]), putchar('\n');
    }
}

bool edmer;
signed main() {
	freopen("jump.in", "r", stdin);
	freopen("jump.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    
    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    if(m <= 1) sub1 :: main();
    else if(sub3 :: check()) sub3 :: main();
    else if(max(n, m) <= 100) sub2 :: main();
    else if(max({ n, m, q }) <= 8000) sub4 :: main();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 