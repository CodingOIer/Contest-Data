#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10,INF=1e9+10;
int N,M,fa[Maxn],Son[Maxn],Siz[Maxn],Dep[Maxn];
int Top[Maxn],hed[Maxn],cnt,Dis[Maxn],Q,Len[Maxn];
vector<int> E[Maxn];
struct node{int nxt,to,w;}G[Maxn<<1];
bool Vis[Maxn];
struct DATA{
    int x,d;
    bool operator <(const DATA &t)const{return d>t.d;}
};
priority_queue<DATA> Qu;

void Addedge(int x,int y,int w){G[++cnt]=(node){hed[x],y,w}; hed[x]=cnt;}

void DFS1(int x,int p){
    fa[x]=p,Siz[x]=1,Dep[x]=Dep[p]+1;
    for(auto y:E[x]){
        if(y==p) continue;
        DFS1(y,x); Siz[x]+=Siz[y];
        if(Siz[y]>Siz[Son[x]]) Son[x]=y;
    }
}

void DFS2(int x,int t){
    Top[x]=t; if(!Son[x]) return;
    DFS2(Son[x],t);
    for(auto y:E[x]){
        if(y==Son[x]||y==fa[x]) continue;
        DFS2(y,y);
    }
}

int Get_lca(int x,int y){
    while(Top[x]!=Top[y]){
        if(Dep[Top[x]]<Dep[Top[y]]) swap(x,y);
        x=fa[Top[x]];
    }
    return Dep[x]<Dep[y]?x:y;
}

void Dij(int S){
    For(i,1,N) Vis[i]=0,Dis[i]=INF;
    Qu.push((DATA){S,0}); Dis[S]=0;
    while(!Qu.empty()){
        int x=Qu.top().x; Qu.pop();
        Vis[x]=1;
        for(int y,i=hed[x];i;i=G[i].nxt){
            if(Dis[y=G[i].to]>Dis[x]+G[i].w){
                Dis[y]=Dis[x]+G[i].w;
                if(!Vis[y]) Qu.push((DATA){y,Dis[y]});
            }
        }
    }
}

void DFS3(int x,int p){
    fa[x]=p,Siz[x]=1,Dep[x]=Dep[p]+1,Son[x]=0;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        Len[y]=Len[x]+G[i].w; DFS3(y,x);
        Siz[x]+=Siz[y];
        if(Siz[y]>Siz[Son[x]]) Son[x]=y;
    }
}

void DFS4(int x,int t){
    Top[x]=t; if(!Son[x]) return;
    DFS4(Son[x],t);
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==fa[x]||y==Son[x]) continue;
        DFS4(y,y);
    }
}

void Solve1(){
    For(i,1,M){
        int x=read(),y=read(),lca=Get_lca(x,y);
        while(x!=lca) Addedge(x,N+i,1),Addedge(N+i,x,1),Vis[x]=1,x=fa[x];
        while(y!=lca) Addedge(y,N+i,1),Addedge(N+i,y,1),Vis[y]=1,y=fa[y];
        Addedge(lca,N+i,1),Addedge(N+i,lca,1),Vis[lca]=1;
    }
    For(i,1,N) for(auto j:E[i]) if(!Vis[i]||!Vis[j]) Addedge(i,j,2);
    For(i,1,N+1) Dep[i]=fa[i]=Son[i]=Siz[i]=Top[i]=0;
    DFS3(1,0); DFS4(1,1);
    Q=read();
    while(Q--){
        int x=read(),y=read(),lca=Get_lca(x,y);
        write((Len[x]+Len[y]-Len[lca]*2)>>1),pc('\n');
    }
}

int main(){
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    N=read(),M=read();
    For(i,1,N-1){
        int u=read(),v=read();
        E[u].pb(v),E[v].pb(u);
    }
    DFS1(1,0); DFS2(1,1);
    if(M==1) Solve1(),exit(0);
    For(i,1,M){
        int x=read(),y=read(),lca=Get_lca(x,y);
        while(x!=lca) Addedge(x,N+i,1),Addedge(N+i,x,1),x=fa[x];
        while(y!=lca) Addedge(y,N+i,1),Addedge(N+i,y,1),y=fa[y];
        Addedge(lca,N+i,1),Addedge(N+i,lca,1);
    }
    For(i,1,N) for(auto j:E[i]) Addedge(i,j,2);
    Q=read();
    while(Q--){
        int x=read(),y=read();
        Dij(x); write(Dis[y]>>1),pc('\n');
    }
    return 0;
}
/*
g++ jump.cpp -o jump -O2
./jump
*/