#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10;
int T,N,A[Maxn],B[Maxn],f[210][210][210],S1,S2,C[Maxn],pre[210][210][210];
bool Vis[Maxn];

void Solve(){
    N=read(),S1=S2=0; 
    memset(Vis,0,sizeof Vis),memset(C,0,sizeof C),memset(f,0,sizeof f);
    For(i,1,N) A[i]=read(),S1+=A[i]; 
    For(i,1,N) B[i]=read(),S2+=B[i];
    if((S1&1)||S2&1) return puts("-1"),void();
    S1>>=1,S2>>=1; Vis[0]=1; f[0][0][0]=1;
    For(i,1,N){
        For(a,0,S1) if(Vis[a]) For(b,0,S2) if(f[i-1][a][b]){
            f[i][a][b]|=1;
            f[i][a+A[i]][b+B[i]]|=1;
            pre[i][a+A[i]][b+B[i]]=i;
            Vis[a+A[i]]=1;
        }
        For(a,0,S1) For(b,0,S2) if(!pre[i][a][b]) pre[i][a][b]=pre[i-1][a][b];
    }
    if(!f[N][S1][S2]) return puts("-1"),void();
    int t1=S1,t2=S2,x=pre[N][t1][t2];
    while(t1&&t2){
        C[x]=1;
        t1-=A[x],t2-=B[x];
        x=pre[x-1][t1][t2];
    }
    For(i,1,N) write(C[i]),pc(' ');
    pc('\n');
}

int main(){
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
    T=read(); while(T--) Solve();
    return 0;
}
/*
g++ slauqe.cpp -o slauqe -O2
./slauqe
*/