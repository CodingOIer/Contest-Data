#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int N,T,S1,S2,P,lst,A[Maxn],B[Maxn],cnt[Maxn],tmp;
bool Vis[Maxn],Use[Maxn];

void Max(int &x,int y){if(y>x) x=y;}

void DFS(int x,int n){
    if(x>n){
        For(i,1,n){
            if(Vis[i]) ++cnt[A[i]];
            else ++cnt[B[i]];
        }
        For(i,1,n){
            if(cnt[A[i]]&1) Use[A[i]]=1;
            if(cnt[B[i]]&1) Use[B[i]]=1;
        }
        For(i,1,n+1) if(!Use[i]){ Max(tmp,i); break; }
        For(i,1,n){
            if(Vis[i]) --cnt[A[i]];
            else --cnt[B[i]];
        }
        For(i,1,n+1) Use[i]=0;
        return;
    }
    Vis[x]=1; DFS(x+1,n); Vis[x]=0; DFS(x+1,n);
}

int Solve(int n){
    tmp=0,DFS(1,n); return tmp;
}

signed main(){
    freopen("mex.in","r",stdin);
    freopen("mex.out","w",stdout);
    N=read(),T=read(),S1=read(),S2=read(),P=read();
    For(i,1,N){
        if(i<=T) A[i]=read(),B[i]=read();
        else A[i]=(lst*i^S1)%P+1,B[i]=(lst*i^S2)%P+1;
        int cur=Solve(i);
        lst^=(cur*i);
    }
    write(lst);
    return 0;
}
/*
g++ mex.cpp -o mex -O2
./mex
*/