#include<bits/stdc++.h>
#define fi first
#define sd second
using namespace std;
const int N=2e5+5;
#define dIO_USE_BUFFER
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;
int T,n,a[N],b[N],suma1,suma2,sumb1,sumb2;
int cnt12,cnt11,cnt22,cnt21,tot;
pair<int,int> sol[N];
signed main(){
	freopen("slauqe.in","r",stdin);
	freopen("slauqe.out","w",stdout);
	io.read(T);
	while(T--){
		io.read(n);
		suma1=suma2=sumb1=sumb2=0;
		cnt12=cnt11=cnt21=cnt22=0;
		for(int i=1;i<=n;i++){
			io.read(a[i]);	
			suma1+=(a[i]==1);
			suma2+=(a[i]==2);
		} 
		for(int i=1;i<=n;i++){
			io.read(b[i]);
			sumb1+=(b[i]==1);
			sumb2+=(b[i]==2);
		}
		for(int i=1;i<=n;i++){
			cnt12+=(a[i]==1&&b[i]==2);
			cnt11+=(a[i]==1&&b[i]==1);
			cnt21+=(a[i]==2&&b[i]==1);
			cnt22+=(a[i]==2&&b[i]==2);
		}
		if((suma1&1)||(sumb1&1)){
			io.writeln(-1);
			continue;
		}
		int sm=suma1/2+suma2;
		tot=0;
		for(int i=1;i<=suma1;i++){
			if(sm-i<0) break;
			if((sm-i)%2) continue;
			sol[++tot]={i,(sm-i)/2};
		}
		bool win=0;
		int c11=0,c12=0,c22=0,c21=0;
		for(int i=1;i<=tot;i++){
			int ax=sol[i].fi,ay=sol[i].sd;
			int by=sumb1/2+sumb2-(ax+ay),bx=(ax+ay)-by;
			if(by<0||by>sumb2||bx<0||bx>sumb1) continue;
			int ca11=min(cnt11,min(ax,bx)),ca12=min(cnt12,min(ax,by));
			int ca22=min(cnt22,min(ay,by)),ca21=min(cnt21,min(ay,bx));
			if(n<=2000){
				for(int cs11=0;cs11<=ca11;cs11++){
					int a1=ax,a2=ay,b1=bx,b2=by;
					a1-=cs11;
					b1-=cs11;
					c11=cs11;
					if(ca12<a1) continue;
					b2-=a1;
					c12=a1;
					a1=0;
					if(ca21<b1) continue;
					if(ca22<b2) continue;
					c21=b1;
					c22=b2;
					win=1;
					break;
				}				
			}
			else{
				int cs11=ca11;
				int a1=ax,a2=ay,b1=bx,b2=by;
				a1-=cs11;
				b1-=cs11;
				c11=cs11;
				if(ca12<a1) continue;
				b2-=a1;
				c12=a1;
				a1=0;
				if(ca21<b1) continue;
				if(ca22<b2) continue;
				c21=b1;
				c22=b2;
				win=1;
				break;			
			}
		}
		if(!win) io.writeln(-1);
		else{
			for(int i=1;i<=n;i++){
				if(a[i]==1&&b[i]==1&&c11){
					if(i<n) io.writeSp(1);
					else io.writeln(1);
					c11--;
				}
				else if(a[i]==1&&b[i]==2&&c12){
					if(i<n) io.writeSp(1);
					else io.writeln(1);
					c12--;
				}
				else if(a[i]==2&&b[i]==1&&c21){
					if(i<n) io.writeSp(1);
					else io.writeln(1);
					c21--;
				}
				else if(a[i]==2&&b[i]==2&&c22){
					if(i<n) io.writeSp(1);
					else io.writeln(1);
					c22--;
				}
				else{
					if(i<n) io.writeSp(0);
					else io.writeln(0);
				}
			}
		}
	}
	return 0;
}
