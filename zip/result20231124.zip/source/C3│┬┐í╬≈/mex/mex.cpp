#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=25;
#define dIO_USE_BUFFER
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;

int n,T,seed1,seed2,p;
int a[N],b[N],m,ans,res;
int t[N];

int Solve(){
	int rs=0;
	for(int i=0;i<(1<<m);i++){
		for(int j=1;j<=m+1;j++) t[j]=0;
		for(int j=1;j<=m;j++){
			if(i&(1<<(j-1))&&a[j]<=m) t[a[j]]++;
			else if(b[j]<=m) t[b[j]]++;
		}
		for(int j=1;j<=m+1;j++){
			if(!(t[j]&1)){
				rs=max(rs,j);
				break;
			}
		}
	}
	return rs;
}

signed main(){
	freopen("mex.in","r",stdin);
	freopen("mex.out","w",stdout);
	io.read(n),io.read(T),io.read(seed1),io.read(seed2),io.read(p);
	for(int i=1;i<=n;i++){
		m=i;
		if(i<=T) io.read(a[i]),io.read(b[i]);
		else a[i]=(1ll*ans*i^seed1)%p+1,b[i]=(1ll*ans*i^seed2)%p+1;
		res=Solve();
		ans=(ans^(1ll*res*i));
	}
	io.write(ans);
	return 0;
}
