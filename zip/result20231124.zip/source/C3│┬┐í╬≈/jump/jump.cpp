#include<bits/stdc++.h>
#define int long long
#define ls (x<<1)
#define rs (x<<1|1)
#define mid (l+r>>1)
using namespace std;
const int N=2e5+5,BN=105;
#define dIO_USE_BUFFER
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;

int n,m,q;

//create G
int head[N],nxt[N<<1],to[N<<1],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}

//tree-cut
int siz[N],son[N],top[N],fa[N],dep[N],id[N],rnk[N],idx;
void dfs1(int u,int f){
	fa[u]=f;
	dep[u]=dep[f]+1;
	siz[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==f) continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]]) son[u]=v;
	}
}
void dfs2(int u,int tp){
	top[u]=tp;
	id[u]=++idx;
	rnk[idx]=u;
	if(son[u]) dfs2(son[u],tp);
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(top[v]) continue;
		dfs2(v,v);
	}
}
int Lca(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) return x;
	return y;
}
int tr[N<<2],lazy[N<<2];
void down(int x,int l,int r,int k){
	tr[x]+=(r-l+1)*k;
	lazy[x]+=k;
}
void pushdown(int x,int l,int r){
	if(!lazy[x]) return;
	down(ls,l,mid,lazy[x]);
	down(rs,mid+1,r,lazy[x]);
	lazy[x]=0;
}
void pushup(int x){tr[x]=tr[ls]+tr[rs];}
void update(int x,int l,int r,int L,int R,int k){
	if(l>=L&&r<=R){
		down(x,l,r,k);
		return;
	}
	if(l>R||r<L) return;
	pushdown(x,l,r);
	update(ls,l,mid,L,R,k),update(rs,mid+1,r,L,R,k);
	pushup(x);
}
int query(int x,int l,int r,int L,int R){
	if(l>=L&&r<=R) return tr[x];
	if(l>R||r<L) return 0;
	pushdown(x,l,r);
	return query(ls,l,mid,L,R)+query(rs,mid+1,r,L,R);
}

//////////////////////opt1////////////////////////
int fyd[BN][BN],s[BN],tp;
void ex_update(int x,int y){
	tp=0;
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		for(int i=id[top[x]];i<=id[x];i++) s[++tp]=rnk[i]; 
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=id[y];i<=id[x];i++) s[++tp]=rnk[i];
	
	for(int i=1;i<=tp;i++)
		for(int j=1;j<=tp;j++)
			if(i!=j) fyd[s[i]][s[j]]=fyd[s[j]][s[i]]=1;
}
void solve1(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(i!=j) fyd[i][j]=n+1;
	
	for(int i=1;i<n;i++){
		int u,v;
		io.read(u),io.read(v);
		add(u,v),add(v,u);
		fyd[u][v]=fyd[v][u]=1;
	}	
	dfs1(1,0);
	dfs2(1,1);
	for(int i=1;i<=m;i++){
		int u,v;
		io.read(u),io.read(v);
		ex_update(u,v);
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				fyd[i][j]=min(fyd[i][j],fyd[i][k]+fyd[k][j]);
	
	io.read(q);
	while(q--){
		int u,v;
		io.read(u),io.read(v);
		io.writeln(fyd[u][v]);
	}
	return;
}

//////////////////////opt2////////////////////////
void update_way(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		update(1,1,n,id[top[x]],id[x],1);
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	update(1,1,n,id[y],id[x],1);
}
int query_way(int x,int y){
	int res=0;
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		res+=(id[x]-id[top[x]]+1);
		res-=(max(0ll,query(1,1,n,id[top[x]],id[x])-2));
		x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	res+=(id[x]-id[y]+1);
	res-=(max(0ll,query(1,1,n,id[y],id[x])-2));
	return res-1;
}
void solve2(){
	for(int i=1;i<n;i++){
		int u,v;
		io.read(u),io.read(v);
		add(u,v),add(v,u);
	}	
	dfs1(1,0);
	dfs2(1,1);
	for(int i=1;i<=m;i++){
		int u,v;
		io.read(u),io.read(v);
		update_way(u,v);		
	}
	io.read(q);	
	while(q--){
		int u,v;
		io.read(u),io.read(v);
		io.writeln(query_way(u,v));	
	}
	return;
}

signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	io.read(n),io.read(m);
	
	if(n<=100&&m<=100) solve1();
	else if(m==1) solve2();
	
	return 0;
}
