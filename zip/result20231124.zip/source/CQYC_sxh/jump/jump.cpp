#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) { 
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 100;

int n, m, ans[N];
int head[N], nxt[N << 1], to[N << 1], cnt;
void Add(int u, int v) {
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt;
} 
vector<int> ve[N];
struct node{ int u, v, id; };
vector<node> q[N];
vector<pii> Del[N];

namespace BL{
    int fa[20][N], f[20][N], dep[N];

    void dfs1(int u) {
        dep[u] = dep[fa[0][u]] + 1;
        Eor(u) if (to[i] != fa[0][u]) 
            fa[0][to[i]] = u, dfs1(to[i]);
    } 
    int LCA(int x, int y) {
        if (dep[x] < dep[y]) swap(x, y);
        Rof(i, 18, 0) if (dep[fa[i][x]] >= dep[y]) x = fa[i][x];
        if (x == y) return x;
        Rof(i, 18, 0) if (fa[i][x] != fa[i][y]) x = fa[i][x], y = fa[i][y];
        return fa[0][x];
    }
    void dfs2(int u) {
        f[0][u] = fa[0][u];
        for (auto x : ve[u]) { int l = LCA(u, x);
            if (dep[l] < dep[f[0][u]]) f[0][u] = l;
        }
        Eor(u) if (to[i] != fa[0][u]) { dfs2(to[i]);
            if (dep[f[0][to[i]]] < dep[f[0][u]])
                f[0][u] = f[0][to[i]];
        }
    }
    void solve() {
        For(u, 1, n) {

            fa[0][u] = 0, dfs1(u); 
            For(i, 1, 18) For(j, 1, n) fa[i][j] = fa[i - 1][fa[i - 1][j]];
       
            dfs2(u);
            For(i, 1, 18) For(j, 1, n) f[i][j] = f[i - 1][f[i - 1][j]];

            For(i, 0, m - 1) if (q[0][i].u == u) { 
                int v = q[0][i].v;
                Rof(j, 18, 0) if (f[j][v]) 
                    v = f[j][v], ans[q[0][i].id] += 1 << j;
            }
        }
        For(i, 1, m) cout << ans[i] << "\n";
    }
}


int siz[N], maxp[N], root;
bool vis[N]; int bl[N];

void get_root(int u, int fa, int total) {
    siz[u] = 1, maxp[u] = 0;
    Eor(u) if (!vis[to[i]] && to[i] != fa) {
        get_root(to[i], u, total), siz[u] += siz[to[i]];
        if (siz[to[i]] > maxp[u]) maxp[u] = siz[to[i]];
    }
    maxp[u] = max(maxp[u], total - siz[u]);
    if (maxp[u] < maxp[root]) root = u;
}


int Fa[20][N], f[20][N], dep[N];
bool in[N]; int ID[N], tp, ed[N];

void dfs1(int u) {
    dep[u] = dep[Fa[0][u]] + 1;
    ID[++tp] = u, in[u] = 1;
    Eor(u) if (to[i] != Fa[0][u] && !vis[to[i]]) 
        ed[to[i]] = i, Fa[0][to[i]] = u, dfs1(to[i]);
} 
int LCA(int x, int y) {
    if (dep[x] < dep[y]) swap(x, y);
    Rof(i, 18, 0) if (dep[Fa[i][x]] >= dep[y]) x = Fa[i][x];
    if (x == y) return x;
    Rof(i, 18, 0) if (Fa[i][x] != Fa[i][y]) x = Fa[i][x], y = Fa[i][y];
    return Fa[0][x];
}

void dfs2(int u) {
    f[0][u] = Fa[0][u];
    for (auto x : ve[u]) { 
        if (!in[x]) continue;;int l = LCA(u, x);
        if (dep[l] < dep[f[0][u]]) f[0][u] = l;
    }
    Eor(u) if (to[i] != Fa[0][u] && !vis[to[i]]) { 
        dfs2(to[i]);
        if (dep[f[0][to[i]]] < dep[f[0][u]])
            f[0][u] = f[0][to[i]];
    }
}

void calc(int u) {

    cout << "Error:"<<u<<'\n';
    // cout << u << '\n';
    for (auto op : q[u]) {
        cout << op.u <<" "<<op.v<<" "<<op.id <<'\n';
    }

    Fa[0][u] = 0, dfs1(u);
    For(i, 1, 18) For(j, 1, tp) Fa[i][ID[j]] = Fa[i - 1][Fa[i - 1][ID[j]]];
    dfs2(u);
    For(i, 1, 18) For(j, 1, n) f[i][ID[j]] = f[i - 1][f[i - 1][ID[j]]];


    for (auto op : q[u]) {
        if (bl[op.u] == bl[op.v]) { q[bl[op.u]].push_back(op); continue; }
        
        int x = op.u, y = op.v;
        Rof(i, 18, 0) {
            if (f[i][x] && f[i][x] != u) 
                x = f[i][x], ans[op.id] += 1 << i;
            if (f[i][y] && f[i][y] != u) 
                y = f[i][y], ans[op.id] += 1 << i;
        }
        
        ans[op.id] += x != u;
        ans[op.id] += y != u;

        if (x == u || y == u) continue;
        bool flag = 0;
        For(i, 1, tp) if (LCA(ID[i], x) == x) { 
            if (flag) break;
            for (auto ver : ve[ID[i]]) if (in[ver] && LCA(in[ver], y) == y)
                { flag = 1; break; }
        }
        ans[op.id] -= flag;
    }
    
    while (tp) vis[ID[tp--]] = 0;
}
void dfs(int u, int fa, int from) {
    bl[u] = from;
    Eor(u) if (to[i] != fa && !vis[to[i]])
        dfs(to[i], u, from);
}

void solve(int u) {
    Eor(u) if (!vis[to[i]]) dfs(to[i], u, to[i]);
    bl[u] = u, calc(u), vis[u] = 1;
    Eor(u) if (!vis[to[i]]) {
        root = 0, get_root(to[i], u, siz[to[i]]);
        swap(q[to[i]], q[root]), solve(root);
    }
}

signed main() {
	freopen("jump.in", "r", stdin);
	freopen("jump.out", "w", stdout);
    n = read(), m = read();
    For(i, 2, n) Add(read(), read());

    For(i, 1, m) {
        int x = read(), y = read();
        ve[x].pb(y), ve[y].pb(x);
    }

    m = read(); For(i, 1, m) q[0].pb({read(), read(), i});
    
    BL::solve(), exit(0);

    // maxp[0] = n + 1, root = 0, get_root(1, 0, n);
    // swap(q[0], q[root]), solve(root);
    // // cout << '\n';
    // For(i, 1, m) cout << ans[i] <<"\n";
	return 0;
}
