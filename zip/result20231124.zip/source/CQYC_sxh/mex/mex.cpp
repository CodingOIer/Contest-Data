#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 1e6 + 10000;
int n, T, seed1, seed2, p;
int fa[N], ma[N], mex;
bool val[N], vis[N];
set<int> s;
unsigned long long ans;

int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }
void calc(int x) { x = find(x); if (val[x] ^= 1) s.insert(ma[x]); else s.erase(ma[x]); }

void Add(int x, int y) {
    vis[x] = vis[y] = 1; while (vis[mex]) ++mex;
    x = find(x), y = find(y); if (x == y) calc(x);
    else {
        if (val[x]) s.erase(ma[x]); if (val[y]) s.erase(ma[y]);
        fa[y] = x, ma[x] = max(ma[x], ma[y]), val[x] ^= val[y], calc(x);
    }
}
signed main() {
	freopen("mex.in", "r", stdin);
	freopen("mex.out", "w", stdout);
    n = read(), T = read(), seed1 = read(), seed2 = read(), p = read(); 
	For(i, 1, 1000100) fa[i] = i, ma[i] = i, calc(i); mex = 1;
    For(i, 1, n) { int x, y;
        if (i <= T) x = read(), y = read();
        else {
            x = (1ll * ans * i ^ seed1) % p + 1;
            y = (1ll * ans * i ^ seed2) % p + 1;
        }
        Add(min(x, 1000100), min(y, 1000100));
        ans ^= 1ll * min(mex, *s.begin()) * i;
    }   
    cout << ans;
	return 0;
}
