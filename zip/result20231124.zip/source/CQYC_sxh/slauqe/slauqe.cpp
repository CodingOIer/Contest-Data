#include <bits/stdc++.h>

#define For(x, y, z) for (int x = y, x##E = z; x <= x##E; ++x)
#define Rof(x, y, z) for (int x = y, x##E = z; x >= x##E; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}

const int N = 2e5 + 100;
int n, a[N], cnt[4], c[4];

map<vector<int>, int> mp; 
int q[N], len;
void check() {
    len = 0; For(i, 0, 3) For(j, 1, cnt[i]) q[len++] = i;
    int o = (1 << len) - 1; while (o--) {
        int sa = 0, sb = 0;
        For(j, 0, len - 1) {
            if ((o >> j) & 1) {
                sa += (q[j] >> 1) + 1;
                sb += (q[j] & 1) + 1;
            } else {
                sa -= (q[j] >> 1) + 1;
                sb -= (q[j] & 1) + 1;
            }
        }
        if (sa == 0 && sb == 0) {
            vector<int> ve; ve.clear();
            For(i, 0, 3) ve.pb(cnt[i]);
            return mp[ve] = o, void();
        }
    }
}
void dfs(int x) {
    if (x == 4) return check();
    For(i, 0, 2) cnt[x] = i, dfs(x + 1);
}

void solve() {
    n = read(); 
    For(i, 0, 3) cnt[i] = c[i] = 0;
    For(i, 1, n) a[i] = (read() - 1) * 2;
    For(i, 1, n) a[i] += read() - 1;
    For(i, 1, n) ++cnt[a[i]];
    For(i, 0, 3) while (cnt[i] > 2) ++c[i], cnt[i] -= 2;
    
    // For(i, 0, 3) cout << cnt[i] <<" "; cout << '\n';

    vector<int> ve; ve.clear(); For(i, 0, 3) ve.pb(cnt[i]);
    if (mp.find(ve) == mp.end()) { puts("-1"); return; }

    len = 0; For(i, 0, 3) For(j, 1, cnt[i]) q[len++] = i; int o = mp[ve];
    For(j, 0, len - 1) c[q[j]] += (o >> j) & 1;
           
    // int suma = 0, sumb = 0;
    // int suma2 = 0, sumb2 = 0;
    // For(i, 0, 3) {
    //     suma += c[i] * ((i >> 1) + 1);
    //     sumb += c[i] * ((i & 1) + 1);
    // }
    // For(i, 1, n) {
    //     suma2 += ((a[i] >> 1) + 1);
    //     sumb2 += ((a[i] & 1) + 1);
    // }
    // assert(suma + suma == suma2 && sumb + sumb == sumb2);

    For(i, 1, n) {
        if (c[a[i]]) putchar('1'), --c[a[i]];
        else putchar('0');  ;   putchar(' ');
    } putchar('\n');
    // puts("YES");
}
signed main() {
	freopen("slauqe.in", "r", stdin);
	freopen("slauqe.out", "w", stdout);
    dfs(0); int T = read(); while (T--) solve();
	return 0;
}
