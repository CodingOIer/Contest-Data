#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;

const int Maxn=1e6+7;
int n,T,seed1,seed2,p;

unordered_map<int,int>hsh,suki;
int fk=1;

int _cnt;
struct node{
	int a,b;
}c[Maxn];

const double eps=1e-9,del=0.95;

int fms,pb[Maxn];
mt19937 rnd(19260817);

inline int doit(int id){
	int jms=0;
	hsh.clear();
	for(int i=1;i<=id;i++){
		for(int j=1;j<=i;j++){
			hsh[c[pb[j]].a]^=1;
		}
		for(int j=i+1;j<=id;j++){
			hsh[c[pb[j]].b]^=1;
		}
		int mx=1;
		while(hsh[mx]) mx++;
		jms=max(jms,mx);
	}
	return jms;
}
inline void SA(int id){

	for(int i=1;i<=id;i++) 
		pb[i]=i;
	double T=1919.810;
	while(T>eps){
		int x=rnd()%id+1,y=rnd()%id+1;
		swap(pb[x],pb[y]);
		
		int res=doit(id);
		
//		cout<<"hel "<<res<<" "<<fms<<endl;
		
		if(res>fms) fms=res;
		else if(exp(res-fms)/T<=(double)rand()/RAND_MAX) swap(pb[x],pb[y]);
		
		T*=del;
	}
}
inline int Solve_pm(int id){
	int mx=0;
	for(int i=0;i<(1<<id);i++){
		hsh.clear();
		for(int j=0;j<id;j++) 
			if(i>>j&1) hsh[c[j+1].b]^=1;
			else hsh[c[j+1].a]^=1;
		int Mx=1;
		while(hsh[Mx]) ++Mx;
		mx=max(mx,Mx);
	}
	return mx;
}
inline int Solve_promax(int id){
	fms=0;
	
	if(clock()>=900) return fk;
	
	SA(id);SA(id);
	SA(id);SA(id);
	
//	cout<<"je "<<fms<<endl;
	return fms;
}

int main(){

	freopen("mex.in","r",stdin);
	freopen("mex.out","w",stdout);

	ull ans=0,res=0;
	scanf("%d%d%d%d%d",&n,&T,&seed1,&seed2,&p);
	for (int i=1;i<=n;i++){
		int a,b; 
		if (i<=T) scanf("%d%d",&a,&b);
		else a=(1ll*ans*i^seed1)%p+1, b=(1ll*ans*i^seed2)%p+1;
		
		c[++_cnt]=(node){a,b};
		
		//res=Solve(i);
		//ans=(ans^(1ll*res*i));
	}
	
	
	if(n<=20){
		for(int i=1;i<=n;i++) ans=(ans^(1ll*Solve_pm(i)*i));
		printf("%llu",ans);
		return 0;
	}
	else{
		
		for(int i=1;i<=n;i++){
			suki[c[i].a]=1;
			suki[c[i].b]=1;
			while(suki[fk]) ++fk;
			ans=(ans^(1ll*Solve_promax(i)*i));
		}
		printf("%llu",ans);
		return 0;
	}
	
	return 0;
}

/*
5 5 0 0 1
1 2
1 3
2 3
4 5
1 2
*/
