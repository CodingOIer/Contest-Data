#include <bits/stdc++.h>
#define ll long long
using namespace std;

#define dIO_USE_BUFFER 
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;

const int Maxn=210,V=410;
int T,n;
int a[Maxn],b[Maxn],f[Maxn][V][V],ans[Maxn];


int main(){
	freopen("slauqe.in","r",stdin);
	freopen("slauqe.out","w",stdout);
	
	io.read(T);
	
	while(T--){
		io.read(n);
		int sma=0,smb=0;
		for(int i=1;i<=n;i++) io.read(a[i]),sma+=a[i];
		for(int i=1;i<=n;i++) io.read(b[i]),smb+=b[i];
		
		if(sma&1 or smb&1) {
			printf("-1\n");
			continue;
		}
		if(n>200){
			printf("-1\n");
			continue; 
		}
		memset(f,0,sizeof f);
		memset(ans,0,sizeof ans);
		
		f[0][0][0]=1;
		for(int i=1;i<=n;i++){
			for(int j=0;j<=sma/2;j++){
				for(int k=0;k<=smb/2;k++){
					f[i][j+a[i]][k+b[i]]|=f[i-1][j][k];
					f[i][j][k]|=f[i-1][j][k];
				}
			}
		}
		
		if(!f[n][sma/2][smb/2]){
			printf("-1\n");
			continue;
		}
		int SmA=sma/2,SmB=smb/2;
		for(int i=n;i;i--){
			if(SmA>=a[i]&&SmB>=b[i]&&f[i-1][SmA-a[i]][SmB-b[i]]){
				SmA-=a[i],SmB-=b[i];
				ans[i]=1;
			}
			else{
				ans[i]=0;
			}
		}
		
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		puts("");
		
		
	}
	
	
	return 0;
}

/*
4
4
1 1 2 2
1 2 1 2
6
1 2 1 1 2 1
2 1 2 1 2 2
3
1 1 2
2 1 1
13
1 1 2 1 1 2 2 1 1 1 1 1 1
2 1 2 2 2 1 2 1 2 2 1 2 2
*/

