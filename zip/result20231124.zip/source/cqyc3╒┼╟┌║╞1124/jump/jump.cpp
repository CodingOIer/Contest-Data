#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=2e5+7;

const int inf=1e9;

int n,m,Q;
vector<int>e[Maxn];
vector<int>hel[Maxn];
bool mdp[2000][2000];
int dis[Maxn];

int f[Maxn][20];

bool Tid=1;

int dep[Maxn],fa[Maxn];
void DFS(int u,int ft){
	fa[u]=ft;
	dep[u]=dep[ft]+1;
	for(auto v:e[u]) if(v!=ft) DFS(v,u);
}
int wsg[Maxn],_cnt;

inline void LCA_boli(int u,int v){
	_cnt=0;
	if(dep[u]<dep[v]) swap(u,v);
	while(dep[u]!=dep[v]) wsg[++_cnt]=u,u=fa[u];
	if(u==v){
		wsg[++_cnt]=u;
		for(int i=1;i<=_cnt;i++)
			for(int j=1;j<=_cnt;j++)
				if(i!=j){
					if(!mdp[wsg[i]][wsg[j]]) hel[wsg[i]].emplace_back(wsg[j]),
					mdp[wsg[i]][wsg[j]]=1;
				}
		return ;
	} 
	while(u!=v){
		wsg[++_cnt]=u,wsg[++_cnt]=v;
		u=fa[u],v=fa[v];		
	}
	wsg[++_cnt]=u;
	for(int i=1;i<=_cnt;i++)
		for(int j=1;j<=_cnt;j++){
			if(i!=j){
				if(!mdp[wsg[i]][wsg[j]]) hel[wsg[i]].emplace_back(wsg[j]),
				mdp[wsg[i]][wsg[j]]=1;	
			}
		}
}

int col[Maxn],ds[Maxn];

void DFS_222(int u,int ft){
	dep[u]=dep[ft]+1;
	fa[u]=ft;
	f[u][0]=ft;
//	cout<<"sda "<<u<<' '<<ft<<" "<<f[u][0]<<endl;
	for(int i=1;i<=19;i++)
		f[u][i]=f[f[u][i-1]][i-1];
	for(auto v:e[u]){
		if(v!=ft) DFS_222(v,u);
	}
}

void DFS_cha(int u){
	if(col[u]) ds[u]=0;
	ds[u]=min(ds[u],ds[fa[u]]+1);
	for(auto v:e[u]){
		if(v==fa[u]) continue;
		DFS_cha(v);
	}
}

inline void LCA_ccf(int u,int v){
	_cnt=0;
	if(dep[u]<dep[v]) swap(u,v);
	while(dep[u]!=dep[v]) wsg[++_cnt]=u,u=fa[u];
	if(u==v){
		wsg[++_cnt]=u;
		for(int i=1;i<=_cnt;i++) col[wsg[i]]=1;
		return ;
	} 
	while(u!=v){
		wsg[++_cnt]=u,wsg[++_cnt]=v;
		u=fa[u],v=fa[v];		
	}
	wsg[++_cnt]=u;
	for(int i=1;i<=_cnt;i++) col[wsg[i]]=1;
}

inline int GetLCA(int u,int v){
	if(dep[u]<dep[v]) swap(u,v);
	for(int i=19;~i;i--) if(dep[f[u][i]]>=dep[v]) u=f[u][i];
//	cout<<"pl "<<u<<" "<<v<<" "<<dep[u]<<" "<<f[u][0]<<endl;
	if(u==v) return u;
	for(int i=19;~i;i--) if(f[u][i]!=f[v][i]) u=f[u][i],v=f[v][i];
	return f[u][0];
}


bool vis[Maxn];

struct node{
	int u,stp;
};

inline void BFS(int s,int t){
	queue<node>q;
	q.push((node){s,0});
	memset(vis,0,sizeof vis);
	while(!q.empty()){
		node tp=q.front();q.pop();
		if(tp.u==t){
			printf("%d\n",tp.stp);
			return ;
		}
		if(vis[tp.u]) continue;
		vis[tp.u]=1;
		for(auto v:hel[tp.u]){
			if(!vis[v]){
				q.push((node){v,tp.stp+1});
			}
		}
	}
	
}

int fw[Maxn][20];

int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<n;i++){
		scanf("%d%d",&u,&v);
		e[u].emplace_back(v);
		e[v].emplace_back(u);
		if(u<=200&&v<=200)mdp[u][v]=mdp[v][u]=1;
		Tid&=(v==u+1);
	}
	
	if(m==1){
		int u,v;
		scanf("%d%d",&u,&v);
		DFS_222(u,0);
		for(int i=1;i<=n;i++) ds[i]=inf;
		LCA_ccf(u,v);
		DFS_cha(u);
		scanf("%d",&Q);
		while(Q--){
			int x,y;
			scanf("%d%d",&x,&y);
			
			if(x==y){
				printf("0\n");
				continue;
			}
			if(x==fa[y]||fa[x]==y){
				cout<<"1\n";
				continue;
			}
			if(col[x]&&col[y]){
				printf("1\n");
				continue;
			}		
			int lca=GetLCA(x,y);
			if(col[lca]==0) printf("%d\n",ds[x]+ds[y]-ds[lca]*2);
			else if(dep[x]-1==ds[x]&&dep[y]-1==ds[y]) printf("%d\n",ds[x]+ds[y]);		
			else printf("%d\n",ds[x]+ds[y]+1);		
		}	
		return 0;
	}
	if(Tid){
//		cout<<"test\n";
		for(int i=1;i<=m;i++){
			int u,v;
			scanf("%d%d",&u,&v);
			if(u>v) swap(u,v);
			fw[u][0]=max(fw[u][0],v);
		}
		for(int i=1;i<=Maxn-7;i++)
			fw[i][0]=max(fw[i][0],i+1);
		for(int i=1;i<=Maxn-7;i++){
			fw[i][0]=max(fw[i][0],fw[i-1][0]);
		}
		for(int j=1;j<=17;j++)
		for(int i=1;i<=Maxn-7;i++){
			
				fw[i][j]=max(fw[i][j],fw[fw[i][j-1]][j-1]);
		}
		
//		for(int i=1;i<=n;i++ ) cout<<"sd "<<i<<" "<<fw[i][18]<<endl;
		
		scanf("%d",&Q);
		while(Q--){
			int u,v;
			scanf("%d%d",&u,&v);
			if(u>v) swap(u,v);
			bool flg=0;
			int ans=0;
			for(int i=17;~i;i--){
				if(fw[u][i]<v){
//				cout<<Q<<" "<<fw[u][i]<<" "<<v<<endl;
					ans+=(1<<i);
					u=fw[u][i];
					
				}
			}
			printf("%d\n",ans+1);
		}
		
		return 0;
	}
	DFS(1,0);
	
	for(int i=1;i<=200;i++)
		for(int j=1;j<=200;j++)
			if(mdp[i][j])
				hel[i].emplace_back(j);
	
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		LCA_boli(u,v);
	}
	scanf("%d",&Q);
	while(Q--){
		int u,v;
		scanf("%d%d",&u,&v);
		
		BFS(u,v);
	}
	return 0;
}


/*
10 2
2 1
3 2
4 1
5 1
6 1
7 6
8 5
9 7
10 1
1 9
1 9
10
7 2
10 8
4 8
5 10
7 9
2 1
9 7
9 1
7 3
4 10




10 1
2 1
3 2
4 1
5 1
6 1
7 6
8 5
9 7
10 1
1 9
10
7 2
10 8
4 8
5 10
7 9
2 1
9 7
9 1
7 3
4 10

5 2
1 2
2 3
3 4
4 5

1 3
4 5

3
1 2
3 5
1 5

*/
