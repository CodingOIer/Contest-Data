#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n,m,q;
int tot,head[N],nxt[N<<1],to[N<<1];
int dep[N],fa[N];
int cnt;
int s[N];
int d[N];
bool vis[N];
map<int,map<int,int> > p;
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
void dfs(int x,int f){
	dep[x]=dep[f]+1;
	fa[x]=f;
	for(int i=head[x];i;i=nxt[i]){
		if(to[i]==f) continue;
		dfs(to[i],x);
	}
}
void sol(int x,int y){
	cnt=0;
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]>dep[y]){
		s[++cnt]=x;
		x=fa[x];
	}
	while(x!=y){
		s[++cnt]=x;
		s[++cnt]=y;
		x=fa[x];
		y=fa[y];
	}
	s[++cnt]=x;
	for(int i=1;i<=cnt;i++){
		for(int j=i+1;j<=cnt;j++){
			if(p[s[i]][s[j]]) continue;
			p[s[i]][s[j]]=p[s[j]][s[i]]=1;
			add(s[i],s[j]);
			add(s[j],s[i]);
		}
	}
}
int bfs(int u,int v){
	for(int i=1;i<=n;i++) d[i]=1e16,vis[i]=0;
	d[u]=0;
	queue<int> e;
	e.push(u);
	while(!e.empty()){
		int x=e.front();
		e.pop();
		if(x==v) return d[v];
		for(int i=head[x];i;i=nxt[i]){
			if(!vis[to[i]]){
				vis[to[i]]=1;
				d[to[i]]=d[x]+1;
				if(to[i]==v) return d[v];
				e.push(to[i]);
			}
		}
	}
	return d[v];
}
signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1,u,v;i<n;i++){
		scanf("%lld %lld",&u,&v);
		add(u,v);
		add(v,u);
		p[u][v]=p[v][u]=1;
	}
	dfs(1,0);
	for(int i=1,u,v;i<=m;i++){
		scanf("%lld %lld",&u,&v);
		sol(u,v);
	}
	scanf("%lld",&q);
	while(q--){
		int u,v;
		scanf("%lld %lld",&u,&v);
		printf("%lld\n",bfs(u,v));
	}
	return 0;
}


