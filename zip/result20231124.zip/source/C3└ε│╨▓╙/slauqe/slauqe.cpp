#include <iostream>
using namespace std;

/* d0j1a_1701 FastIO Lite ver. 5.0 */
#define dIO_USE_BUFFER // ע����ʹ�ü��̶��루����ʱ��ȡ��ע�ͣ�
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;

int T;
int n;
int a[200005],b[200005];
int w[5][5];
int f[5][5];
int suma,sumb;
int o=-1,o1=1,o0=0;
void Work(){
	for(int i=1;i<n;i++){
		if(f[a[i]][b[i]]){
			f[a[i]][b[i]]--;
			io.writeSp(o1);
		}
		else io.writeSp(o0);
	}
	if(f[a[n]][b[n]]){
		f[a[n]][b[n]]--;
		io.writeln(o1);
	}
	else io.writeln(o0);
}
int main(){
	freopen("slauqe.in","r",stdin);
	freopen("slauqe.out","w",stdout);
	io.read(T);
	while(T--){
		w[1][1]=w[1][2]=w[2][1]=w[2][2]=0;
		f[1][1]=f[1][2]=f[2][1]=f[2][2]=0;
		suma=sumb=0;
		io.read(n);
		for(int i=1;i<=n;i++){
			io.read(a[i]);
			suma+=a[i];
		}
		for(int i=1;i<=n;i++){
			io.read(b[i]);
			w[a[i]][b[i]]++;
			sumb+=b[i];
		}
		if((suma&1)||(sumb&1)){
			io.writeln(o);
			continue;
		}
		suma/=2;
		sumb/=2;
		if(suma>=sumb){
			if(w[2][1]<suma-sumb){
				io.writeln(o);
				continue;
			}
			int k=suma-sumb;
			w[2][1]-=k;
			f[2][1]+=k;
			suma-=k*2;
			sumb-=k;
			if(suma<0||sumb<0){
				io.writeln(o);
				continue;
			}
			k=min(w[2][1],w[1][2]);
			k=min(k,suma/3);
			suma-=k*3;
			w[2][1]-=k;f[2][1]+=k;
			w[1][2]-=k;f[1][2]+=k;
			if(suma==0){
				Work();
				continue;
			}
			k=min(w[2][2],suma/2);
			suma-=k*2;
			w[2][2]-=k;
			f[2][2]+=k;
			if(suma==0){
				Work();
				continue;
			}
			k=min(w[1][1],suma);
			suma-=k;
			w[1][1]-=k;
			f[1][1]+=k;
			if(suma==0){
				Work();
				continue;
			}
			if(f[1][2]>0&&f[2][1]>0){
				f[1][2]--;
				f[2][1]--;
				k=min(w[2][2],suma/2);
				suma-=k*2;
				w[2][2]-=k;
				f[2][2]+=k;
				if(suma==0){
					Work();
					continue;
				}
			}
			io.writeln(o);
			continue;
		}
		if(w[1][2]<sumb-suma){
			io.writeln(o);
			continue;
		}
		int k=sumb-suma;
		w[1][2]-=k;
		f[1][2]+=k;
		suma-=k;
		sumb-=k*2;
		if(suma<0||sumb<0){
			io.writeln(o);
			continue;
		}
		k=min(w[2][1],w[1][2]);
		k=min(k,suma/3);
		suma-=k*3;
		w[2][1]-=k;f[2][1]+=k;
		w[1][2]-=k;f[1][2]+=k;
		if(suma==0){
			Work();
			continue;
		}
		k=min(w[2][2],suma/2);
		suma-=k*2;
		w[2][2]-=k;
		f[2][2]+=k;
		if(suma==0){
			Work();
			continue;
		}
		k=min(w[1][1],suma);
		suma-=k;
		w[1][1]-=k;
		f[1][1]+=k;
		if(suma==0){
			Work();
			continue;
		}
		if(f[1][2]>0&&f[2][1]>0){
			f[1][2]--;
			f[2][1]--;
			k=min(w[2][2],suma/2);
			suma-=k*2;
			w[2][2]-=k;
			f[2][2]+=k;
			if(suma==0){
				Work();
				continue;
			}
		}
		io.writeln(o);
	}
	return 0;
} 
