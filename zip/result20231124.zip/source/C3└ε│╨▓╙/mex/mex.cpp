#include<bits/stdc++.h>
#define int long long
#define N 1000005
using namespace std;
int n,T,seed1,seed2,p;
int ans=0,res=0;
bool vis[N];
vector<pair<int,int> > h[N];
inline void dfs(int x,int k,int s){
	if(k==h[x].size()){
		if(s&1) dfs(x+1,0,0);
		res=max(res,x);
		return;
	}
	int id=h[x][k].first,w=h[x][k].second;
	if(vis[id]) dfs(x,k+1,s);
	else if(w<x){
		vis[id]=1;
		dfs(x,k+1,s+1);
		vis[id]=0;
	}
	else{
		dfs(x,k+1,s);
		vis[id]=1;
		dfs(x,k+1,s+1);
		vis[id]=0;
	}
}
signed main(){
	freopen("mex.in","r",stdin);
	freopen("mex.out","w",stdout);
	scanf("%lld %lld %lld %lld %lld",&n,&T,&seed1,&seed2,&p);
	for (int i=1;i<=n;i++){
		int a,b; 
		if(i<=T) scanf("%lld %lld",&a,&b);
		else a=(1ll*ans*i^seed1)%p+1,b=(1ll*ans*i^seed2)%p+1;
		h[a].push_back({i,b});
		h[b].push_back({i,a});
		res=1;
		dfs(1,0,0);
		ans=(ans^(1ll*res*i));
	}
	printf("%lld",ans);
	return 0;
}


