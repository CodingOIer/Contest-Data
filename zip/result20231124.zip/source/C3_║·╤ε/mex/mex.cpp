#include<bits/stdc++.h>
#define int long long
#define fir first
#define sec second
using namespace std;
const int Maxn = 100;
int n, T, seed1, seed2, p, cnt, ans;
vector<pair<int, int>> a;
int c[Maxn], b[Maxn];
void dfs(int x){
    if(x > cnt){
        memset(b, 0, sizeof(b));
        for(int i = 1 ; i <= cnt ; i++){
            if(c[i] && a[i - 1].fir <= cnt){
                b[a[i - 1].fir] ^= 1;
            } 
            else if(a[i - 1].sec <= cnt) b[a[i - 1].sec] ^= 1;
        }
        int s = cnt + 1;
        for(int i = 1 ; i <= cnt ; i++){
            if(!b[i]){
                s = i;
                break;
            }
        }
        ans = max(ans, s);
        return ;
    }
    c[x] = 1;
    dfs(x + 1);
    c[x] = 0;
    dfs(x + 1);
}
int X;
signed main(){
    ios::sync_with_stdio(false);
    freopen("mex.in", "r", stdin);
    freopen("mex.out", "w" ,stdout);
    cin >> n >> T >> seed1 >> seed2 >> p;
    if(T == 0){
        cout << 0 << '\n';
        return 0;
    }
    for(int i = 1 ; i <= T ; i++){
        int x, y;
        cnt++;
        cin >> x >> y;
        a.push_back({x, y});
        ans = 0;
        dfs(1);
        X = X ^ (ans * i);
    }
    for(int i = T + 1 ; i <= n ; i++){
        int x = (X * i ^ seed1) % p + 1;
        int y = (X * i ^ seed2) % p + 1;
        a.push_back({x, y});
        cnt++;
        ans = 0;
        dfs(1);
        X = X ^ (ans * i);
    }
    cout << X << '\n';
    return 0;
}