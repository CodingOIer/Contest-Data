#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 200010;
int n, m, Q;
vector<int> Tree[Maxn];
int p[Maxn], cnt;
int fa[Maxn], dep[Maxn];
void dfs(int x){
    dep[x] = dep[fa[x]] + 1;
    for(auto to : Tree[x]){
        if(to == fa[x]) continue;
        fa[to] = x;
        dfs(to);
    }
}
int dis[8010][8010], vis[Maxn];
queue<int> q;
void bfs(int x){
    memset(dis[x], 0x3f, sizeof(dis[x]));
    for(int i = 1 ; i <= n ; i++) vis[i] = 0;
    dis[x][x] = 0;
    vis[x] = 1;
    q.push(x);
    while(!q.empty()){
        int u = q.front();
        // cout << u << " ";
        q.pop();
        for(auto to : Tree[u]){
            if(vis[to]) continue;
            q.push(to);
            vis[to] = 1;
            dis[x][to] = dis[x][u] + 1;
        }
    }
    // cout << endl;
}
int ops, r[Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("jump.in", "r", stdin);
    freopen("jump.out", "w", stdout);
    cin >> n >> m;
    for(int i = 1 ; i < n ; i++){
        int x, y;
        cin >> x >> y;
        Tree[x].push_back(y);
        Tree[y].push_back(x);
        if(abs(x - y) != 1) ops = 1;
    }
    if(ops == 0){
        for(int i = 1 ; i <= n ; i++) r[i] = i + 1;
        for(int i = 1 ; i <= m ; i++){
            int x, y;
            cin >> x >> y;
            if(x > y) swap(x, y);
            for(int j = x ; j <= y ; j++) r[j] = max(r[j], y);
        }
        cin >> Q;
        while(Q--){
            int x, y;
            cin >> x >> y;
            int ans = 0;
            if(x > y) swap(x, y);
            if(x == y){
                cout << 0 << '\n';
                continue;
            }
            for(;;){
                ans++;
                x = r[x];
                if(x >= y) break;
            }
            cout << ans << '\n';
        }
        cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
        return 0;
    }
    dfs(1);
    for(int i = 1 ; i <= m ; i++){
        int x, y;
        cin >> x >> y;
        cnt = 0;
        if(dep[x] < dep[y]) swap(x, y);
        for(;;){
            p[++cnt] = x;
            x = fa[x];
            if(dep[x] == dep[y]) break;
        } 
        p[++cnt] = x;
        while(fa[x] != fa[y]){
            p[++cnt] = x;
            p[++cnt] = y;
            x = fa[x];
            y = fa[y];
        }
        for(int j = 1 ; j <= cnt ; j++){
            for(int k = 1 ; k <= cnt ; k++){
                if(p[j] == p[k]) continue;
                Tree[p[j]].push_back(p[k]);
                Tree[p[k]].push_back(p[j]);
            }
        }
    }
    for(int i = 1 ; i <= n ; i++){
        sort(Tree[i].begin(), Tree[i].end());
        unique(Tree[i].begin(), Tree[i].end());
    }
    cin >> Q;
    for(int i = 1 ; i <= n ; i++) bfs(i);
    while(Q--){
        int x, y;
        cin >> x >> y;
        cout << dis[x][y] << '\n';
    }
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}