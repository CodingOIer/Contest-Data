#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2;
int T;
int n;
int ar[maxn],br[maxn];
int num[4],L[3],R[3];
int main(){
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
    T=read();
    while(T--){
        n=read();
        int suma=0,sumb=0;
        for(int i=0;i<4;i++)num[i]=0;
        for(int i=1;i<=n;i++)suma+=(ar[i]=read());
        for(int i=1;i<=n;i++){
            sumb+=(br[i]=read());
            num[(ar[i]-1)*2+(br[i]-1)]++;
        }
        if(suma&1||sumb&1){puts("-1");continue;}
        bool f=0;
        int a,b,c,d,va;
        int l,r,mid;
        for(a=0;a<=num[0];a++){
            L[0]=0,R[0]=num[1];
            L[1]=R[1]=L[2]=R[2]-1;
            l=0,r=num[1],va=(suma>>1)-(sumb>>1);
            while(l<=r){
                mid=(l+r)>>1;
                if(mid+va>=0)L[1]=mid,r=mid-1;
                else l=mid+1;
            }
            if(L[1]==-1)continue;
            l=0,r=num[1];
            while(l<=r){
                mid=(l+r)>>1;
                if(mid+va<=num[2])R[1]=mid,l=mid+1;
                else r=mid-1;
            }
            if(R[1]==-1)continue;
            l=0,r=num[1],va=sumb-(suma>>1)-a;
            while(l<=r){
                mid=(l+r)>>1;
                if(va-3*mid<=num[3])L[2]=mid,r=mid-1;
                else l=mid+1;
            }
            if(R[2]==-1)continue;
            l=0,r=num[1];
            while(l<=r){
                mid=(l+r)>>1;
                if(va-3*mid>=0)R[2]=mid,l=mid+1;
                else r=mid-1;
            }
            if(L[2]==-1)continue;
            bool ty=(sumb-(suma>>1)-a)&1;
            b=-1;
            for(int i=max(L[0],max(L[1],L[2]));i<=min(R[0],min(R[1],R[2]));i++){
                if((i&1)==ty){b=i;break;}
            }
            if(b==-1)continue;
            c=(suma>>1)-(sumb>>1)+b;
            d=(sumb-(suma>>1)-a-3*b)>>1;
            f=1;
            break;
            // for(b=0;b<=num[1];b++){
            //     c=b+suma/2-sumb/2;
            //     if(c<0||c>num[2])continue;
            //     if((sumb-suma/2-a-3*b)&1)continue;
            //     d=(sumb-suma/2-a-3*b)/2;
            //     if(d<0||d>num[3])continue;
            //     f=1;break;
            // }
        }
        if(!f)puts("-1");
        else {
            int sum1=0,sum2=0;
            for(int i=1,ty;i<=n;i++){
                ty=(ar[i]-1)*2+(br[i]-1);
                if(ty==0)putchar((a)?(sum1+=1,sum2+=1,a--,'1'):'0');
                if(ty==1)putchar((b)?(sum1+=1,sum2+=2,b--,'1'):'0');
                if(ty==2)putchar((c)?(sum1+=2,sum2+=1,c--,'1'):'0');
                if(ty==3)putchar((d)?(sum1+=2,sum2+=2,d--,'1'):'0');
            }
            putchar('\n');
            // printf("sum: %d %d %d %d\n",sum1,suma/2,sum2,sumb/2);
        }
    }
}