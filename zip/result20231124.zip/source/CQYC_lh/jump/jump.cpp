#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],otp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');return ;
}
const int maxn=2e5+2,logn=19;
int n,m,Q;
struct node_m{
    int u,v;
}M[maxn];
namespace brute1{
    int cnt;
    int hed[maxn*2],fa[maxn*2],dep[maxn*2],dis[300][300];
    struct node_edge{
        int nxt,to,val;
    }G[maxn*6];
    struct node_d{
        int x,d;
        bool operator < (const node_d &A)const{
            return d>A.d;
        }
    };
    priority_queue<node_d>q;
    void add(int u,int v,int w){
        G[++cnt]=(node_edge){hed[u],v,w};
        hed[u]=cnt;
        return ;
    }
    void dfs(int x,int f){
        fa[x]=f,dep[x]=dep[f]+1;
        for(int i=hed[x],v;i;i=G[i].nxt){
            v=G[i].to;
            if(v==f)continue;
            dfs(v,x);
        }
        return ;
    }
    // void dijkstra(int S){
    //     q.push((node_d){S,dis[S][S]=0});
    //     for(int x;!q.empty();q.pop()){
    //         x=q.top().x;
    //         q.pop();
    //         for(int i=hed[x],v;i;i=G[i].nxt){
    //             v=G[i].to;
    //             if(dis[v]>dis[x]+G[i].val){
    //                 q.push((node_d){v,dis[S][v]=dis[S][x]+G[i].val});
    //             }   
    //         }
    //     }
    // }
    void Floyd(){
        for(int k=1;k<=n+m;k++){
            for(int i=1;i<=n+m;i++){
                for(int j=1;j<=n+m;j++)dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
            }
        }
        return ;
    }
    void solve(){
        memset(dis,0x3f,sizeof(dis));
        for(int i=1,u,v;i<n;i++){
            u=M[i].u,v=M[i].v;
            add(u,v,2);
            add(v,u,2);
            dis[u][v]=dis[v][u]=2;
        }
        dfs(1,0);
        for(int i=1,u,v;i<=m;i++){
            u=read(),v=read();
            while(u!=v){
                if(dep[u]<dep[v])swap(u,v);
                dis[n+i][u]=dis[u][n+i]=1;
                // add(n+i,u,1);
                // add(u,n+i,1);
                u=fa[u];
            }
            dis[n+i][u]=dis[u][n+i]=1;
        }
        // for(int i=1;i<=n;i++)dijkstra(i);
        Floyd();
        Q=read();
        for(int i=1,u,v;i<=Q;i++){
            u=read(),v=read();
            printf("%d\n",dis[u][v]/2);
        }
    }
}
namespace brute2{
    int tfa[maxn],dep[maxn],bel[maxn],p[logn][maxn],d[logn][maxn];
    struct UFS{
        int fa[maxn],siz[maxn];
        void init(int mx){
            for(int i=1;i<=n;i++)fa[i]=i;
            return ;
        }
        int find(int x){
            return (fa[x]==x)?x:(fa[x]=find(fa[x]));
        }
        void merge(int u,int v){
            u=find(u),v=find(v);
            if(u==v)return ;
            fa[u]=v;
        }
    }ufs;
    int cnt;
    int hed[maxn];
    struct node_edge{
        int nxt,to;
    }G[maxn*2];
    void add(int u,int v){
        G[++cnt]=(node_edge){hed[u],v};
        hed[u]=cnt;
        return ;
    }
    vector<int>dfn;
    void dfs(int x,int f){
        tfa[x]=f,dfn.push_back(x),dep[x]=dep[f]+1;
        for(int i=hed[x],v;i;i=G[i].nxt){
            v=G[i].to;
            if(v==f)continue;
            dfs(v,x);
        }
        return ;
    }
    void Mer(int u,int v){
        u=ufs.find(u),v=ufs.find(v);
        vector<int>fix;
        while(u!=v){
            if(dep[u]<dep[v])swap(u,v);
            fix.push_back(u);
            u=ufs.find(tfa[u]);
        }
        for(int i=0;i<fix.size();i++)ufs.merge(fix[i],u);
        return ;
    }
    void pre(){
        for(int i=1;i<logn;i++){
            for(int j=1;j<=n;j++){
                p[i][j]=p[i-1][p[i-1][j]];
                d[i][j]=d[i-1][j]+d[i-1][p[i-1][j]];
            }
        }
    }
    int query(int u,int v){
        if(bel[u]==bel[v])return (u!=v);
        if(dep[bel[u]]<dep[bel[v]])swap(u,v);
        int ret=(u!=bel[u]);
        u=bel[u];
        for(int i=logn-1;i>=0;i--){
            if(dep[p[i][u]]>dep[bel[v]]){
                ret+=d[i][u];
                u=p[i][u];
            }
        }
        if(dep[u]>dep[bel[v]]){
            if(bel[tfa[u]]==bel[v])return ret+(v!=tfa[u])+1;
            else ret+=(d[0][u]+(v!=bel[v])),u=p[0][u],v=bel[v];
        }
        for(int i=logn-1;i>=0;i--){
            if(p[i][u]!=p[i][v]){
                ret+=(d[i][u]+d[i][v]);
                u=p[i][u],v=p[i][v];
            }
        }
        ret+=2,u=tfa[u],v=tfa[v];
        ret+=(u!=v);
        return ret;
    }
    void solve(){
        for(int i=1,u,v;i<n;i++){
            u=M[i].u,v=M[i].v;
            add(u,v);
            add(v,u);
        }
        dfs(1,0);
        ufs.init(n);
        for(int i=1,u,v;i<=m;i++){
            u=read(),v=read();
            Mer(u,v);
        }
        for(int i=0,x;i<n;i++){
            x=dfn[i];
            bel[x]=ufs.find(x);
            if(bel[x]==x){
                p[0][x]=bel[tfa[x]];
                dep[x]=dep[p[0][x]]+1;
                d[0][x]=(tfa[x]==bel[tfa[x]])?1:2;
            }
        }
        pre();
        Q=read();
        for(int i=1,u,v;i<=Q;i++){
            u=read(),v=read();
            write(query(u,v)),putchar('\n');
        }
    }
}
namespace brute3{
    struct node_op{
        int u,v;
    }q[maxn];
    int L[logn][maxn];
    vector<int>ve[maxn],de[maxn];
    multiset<int>s;
    void pre(){
        for(int i=1;i<logn;i++)
            for(int j=1;j<=n;j++)
                L[i][j]=L[i-1][L[i-1][j]];
        return ;
    }
    int query(int u,int v){
        if(u==v)return 0;
        if(u>v)swap(u,v);
        int ret=0;
        for(int i=logn-1;i>=0;i--){
            if(L[i][v]>u)ret+=(1<<i),v=L[i][v];
        }
        return ret+1;
    }
    void solve(){
        for(int i=1,u,v;i<n;i++)u=M[i].u,v=M[i].v,L[0][i+1]=i;
        for(int i=1;i<=m;i++){
            q[i].u=read(),q[i].v=read();
            if(q[i].u>q[i].v)swap(q[i].u,q[i].v);
            ve[q[i].u].push_back(q[i].u);
            de[q[i].v].push_back(q[i].u);
        }
        for(int i=1;i<=n;i++){
            for(int j=0;j<ve[i].size();j++)s.insert(ve[i][j]);
            if(s.begin()!=s.end())L[0][i]=min(L[0][i],*s.begin());
            for(int j=0;j<de[i].size();j++)s.erase(s.find(de[i][j]));
            // printf("L[0][%d]=%d\n",i,L[0][i]);
        }
        pre();
        Q=read();
        for(int i=1,u,v;i<=Q;i++){
            u=read(),v=read();
            write(query(u,v)),putchar('\n');
        }
    }
}
namespace correct{
    int cnt;
    int hed[maxn],id[maxn];
    int fa[logn][maxn],p[logn][maxn],dep[maxn];
    int ans[maxn];
    struct node_edge{
        int nxt,to;
    }G[maxn*2];
    struct node_qu{
        int u,v,lca;
    }o[maxn],q[maxn];
    struct node_se{
        int x;
        bool operator < (const node_se &A)const{
            return dep[x]<dep[A.x];
        }
    };
    vector<int>ve[maxn],de[maxn];
    multiset<node_se>s[maxn];
    multiset<node_se>::iterator it;
    void add(int u,int v){
        G[++cnt]=(node_edge){hed[u],v};
        hed[u]=cnt;
        return ;
    }
    int Mi(int u,int v){
        return (dep[u]>dep[v])?v:u;}
    void dfs(int x,int f){
        fa[0][x]=p[0][x]=f,dep[x]=dep[f]+1;
        for(int i=hed[x],v;i;i=G[i].nxt){
            v=G[i].to;
            if(v==f)continue;
            dfs(v,x);
        }
        return ;
    }
    void pre(){
        for(int i=1;i<logn;i++){
            for(int j=1;j<=n;j++)fa[i][j]=fa[i-1][fa[i-1][j]];
        }
        return ;
    }
    void pre2(){
        for(int i=1;i<logn;i++){
            for(int j=1;j<=n;j++)p[i][j]=p[i-1][p[i-1][j]];
        }
        return ;
    }
    int LCA(int u,int v){
        if(dep[u]<dep[v])swap(u,v);
        for(int i=logn-1;i>=0;i--){
            if(dep[fa[i][u]]>=dep[v])u=fa[i][u];
        }
        if(u==v)return u;
        for(int i=logn-1;i>=0;i--){
            if(fa[i][u]!=fa[i][v])u=fa[i][u],v=fa[i][v];
        }
        return fa[0][u];
    }
    void dfs2(int x,int f){
        id[x]=x;
        for(int i=hed[x],v;i;i=G[i].nxt){
            v=G[i].to;
            if(v==f)continue;
            dfs2(v,x);
            if(((int)s[id[x]].size())<((int)s[id[v]].size())){
                for(it=s[id[x]].begin();it!=s[id[x]].end();it++)s[id[v]].insert({*it});
                id[x]=id[v];
            }
            else for(it=s[id[v]].begin();it!=s[id[v]].end();it++)s[id[x]].insert({*it});
        }
        for(int i=0;i<ve[x].size();i++)s[id[x]].insert({ve[x][i]});
        if(s[id[x]].begin()!=s[id[x]].end())p[0][x]=Mi(p[0][x],s[id[x]].begin()->x);
        for(int i=0;i<de[x].size();i++)s[id[x]].erase(s[id[x]].find({de[x][i]}));
        return ;
    }
    void SOL(int u,int v,int id){
        int lca=LCA(u,v),ret=0;
        for(int i=logn-1;i>=0;i--){
            if(dep[p[i][u]]>dep[lca])ret+=(1<<i),u=p[i][u];
            if(dep[p[i][v]]>dep[lca])ret+=(1<<i),v=p[i][v];
        }
        q[id]=(node_qu){u,v,lca};
        ans[id]=ret;
        return ;
    }
    void solve(){
        for(int i=1,u,v;i<n;i++){
            u=M[i].u,v=M[i].v;
            add(u,v);
            add(v,u);
        }
        dfs(1,0);
        pre();
        for(int i=1;i<=m;i++){
            o[i].u=read(),o[i].v=read();
            o[i].lca=LCA(o[i].u,o[i].v);
            ve[o[i].u].push_back(o[i].lca);
            ve[o[i].v].push_back(o[i].lca);
            de[o[i].lca].push_back(o[i].lca);
            de[o[i].lca].push_back(o[i].lca);
        }
        dfs2(1,0);
        pre2();
        Q=read();
        for(int i=1,u,v;i<=Q;i++){
            u=read(),v=read();
            SOL(u,v,i);
            printf("%d\n",ans[i]+1);
        }
        return ;
    }
}
int main(){
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    n=read(),m=read();
    bool ff=1;
    for(int i=1;i<n;i++)M[i].u=read(),M[i].v=read(),ff&=(M[i].u+1==M[i].v);
    if(m==1)brute2::solve();
    else if(n<=100)brute1::solve();
    else if(ff)brute3::solve();
    else correct::solve();
    return 0;
}