#include<bits/stdc++.h>
#define N 16002
using namespace std;
bool stemer;
int n, m, tot;
vector<int>p[N];
unordered_map<int, int>dis[N];
//int dis[10002][10002];
bool vis[N];
struct node{
	int to, w;
};
vector<node>G[N];
void add(int u, int v, int w) {
	G[u].push_back((node){v, w});
	G[v].push_back((node){u, w});
}
int dep[N], fa[N];
bool fin[N];
void dfs(int x, int father) {
	//cout << x << endl;
	fa[x] = father;
	dep[x] = dep[father] + 1;
	for(int i = 0; i < p[x].size(); i++) {
		int y = p[x][i];
		if(y == father) continue;
		dfs(y, x); 
	}
}
struct ljm{
	int v, w;
	friend bool operator < (ljm x, ljm y) {
		return x.w > y.w;
	}
};
priority_queue<ljm>Q;
void dij(int s) {
	for(int i = 1; i <= tot; i++) {
		dis[s][i] = 1e9;
		vis[i] = 0;
	}
	dis[s][s] = 0;
	Q.push((ljm){s, 0});
	while(!Q.empty()) {
		int x = Q.top().v;
		Q.pop();
		if(vis[x]) continue; 
		vis[x] = 1;
		for(int i = 0; i < G[x].size(); i++) {
			int y = G[x][i].to;
			if(dis[s][y] > dis[s][x] + G[x][i].w) {
				dis[s][y] = dis[s][x] + G[x][i].w;
				Q.push((ljm){y, dis[s][y]}); 
			}
		}
	}
}
bool edmer;
signed main() {
	freopen("jump.in", "r", stdin);
	freopen("jump.out", "w", stdout);
	//cerr << (double)(&stemer - &edmer) / 1024 / 1024 << "MB";
    scanf("%d %d", &n, &m);
    int u, v;
    for(int i = 1; i <= n - 1; i++) {
    	scanf("%d %d", &u, &v);
    	p[u].push_back(v);
		p[v].push_back(u); 
		add(u, v, 2);
	}
	tot = n;
	dfs(1, 0);
	while(m--) {
		scanf("%d %d", &u, &v);
		tot++;
		if(dep[u] < dep[v]) swap(u, v);
		//cout << "e";
	    if(dep[u] != dep[v]) {
	    	while(1) {
	    		if(dep[u] != dep[v]) {
	    			add(tot, u, 1);
	    			//cout << u << " ";
	    			u = fa[u]; 
	    			
				}
				else break;
			}
		}

			while(1) {
				if(u != v) {
					add(tot, u, 1);
					add(tot, v, 1);
					//cout << u << " " << v << " ";
					u = fa[u], v = fa[v];
					
				}
				else {
					add(tot, u, 1);
					//cout << u << " ";
					break;
				}
			}

	
		//cout << endl;
	}
	int q;
	scanf("%d", &q);
	while(q--) {
		scanf("%d %d", &u, &v);
		if(u > v) swap(u, v);
		if(!fin[u]) dij(u), fin[u] = 1;
		//dij(u);
		printf("%d\n", dis[u][v] / 2);
	}
	return 0;
}

