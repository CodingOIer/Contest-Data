#include <bits/stdc++.h>
#define N 1000006
#define int long long
using namespace std;

int A[N], B[N], tot;
int now[N], res;
unordered_map<int, int>f, G;
void dfs(int x) {
	if(x > tot) {
		for(int i = 1; i <= tot; i++) f[now[i]]++;
		int len = 0;
		for(int i = 1; i <= tot; i++) {
			
			if(f[now[i]] % 2 == 1) {
				
				G[now[i]] = 1;
			}
		}
		int t = 0;
		for(int i = 1; ; i++) {
			if(!G[i]) {
				t = i;
				/*for(int i = 1; i <= tot; i++) {	
			        if(f[now[i]] % 2 == 1) {
				        G[now[i]] = 0;
			        }
		        }
		        for(int i = 1; i <= tot; i++) f[now[i]]--;
				return;*/
				break;
			}
		}
		res = max(res, t);
		for(int i = 1; i <= tot; i++) {	
			if(f[now[i]] % 2 == 1) {
				G[now[i]] = 0;
			}
		}
		for(int i = 1; i <= tot; i++) f[now[i]]--;
		return;
	} 
	now[x] = A[x];
	dfs(x + 1);
	now[x] = B[x];
	dfs(x + 1); 
}
signed main(){
	freopen("mex.in", "r", stdin);
	freopen("mex.out", "w", stdout);
	int n,T,seed1,seed2,p;
	int ans=0;
	scanf("%lld %lld %lld %lld %lld",&n,&T,&seed1,&seed2,&p);
	for (int i=1;i<=n;i++){
		int a,b; 
		if (i<=T) scanf("%lld %lld",&a,&b);
		else a=(1ll*ans*i^seed1)%p+1, b=(1ll*ans*i^seed2)%p+1;
		//res=Solve(a,b);
		A[++tot] = a;
		B[tot] = b;
		res = 0;
		dfs(1);
		ans=(ans^(1ll*res*i));
	}
	printf("%lld",ans);
	return 0;
}
