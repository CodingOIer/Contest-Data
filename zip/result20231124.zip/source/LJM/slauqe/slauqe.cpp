#include <bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
/* d0j1a_1701 FastIO Lite ver. 5.0 */
#define dIO_USE_BUFFER // ע����ʹ�ü��̶��루����ʱ��ȡ��ע�ͣ�
struct IO{
#ifdef dIO_USE_BUFFER
	const static int BUFSIZE=1<<20;
	char ibuf[BUFSIZE], obuf[BUFSIZE], *p1, *p2, *pp;
	inline int getchar(){return(p1 == p2&&(p2=(p1=ibuf)+fread(ibuf,1,BUFSIZE,stdin),p1==p2)?EOF:*p1++);}
	inline int putchar(char x){return((pp-obuf==BUFSIZE&&(fwrite(obuf,1,BUFSIZE,stdout),pp=obuf)),*pp=x,pp++),x;}
	IO(){p1=p2=ibuf,pp=obuf;}
	~IO(){fwrite(obuf,1,pp-obuf,stdout),pp=obuf,fflush(stdout);}
#else
	int (*getchar)()=&::getchar,(*putchar)(int)=&::putchar;
	inline IO &flush(){return fflush(stdout),*this;}
#endif
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void read(Tp &s){
		int f=1,ch=getchar();s=0;
		while(!isdigit(ch))f=(ch=='-'?-1:1),ch=getchar();
		while(ch == '0')ch = getchar();
		while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
		s*=f;
	}
	template<typename Tp,typename enable_if<is_integral<Tp>::value>::type * =nullptr>
	inline void write(Tp x){
		if(x<0)putchar('-'),x=-x;
		static char sta[41];
		int top=0;
		do sta[top++]=x%10^48,x/=10;while(x);
		while(top)putchar(sta[--top]);
	}
	template<typename Tp>
	inline void writeln(const Tp &x){write(x);putchar('\n');}
	template<typename Tp>
	inline void writeSp(const Tp &x){write(x);putchar(' ');}
}io;

/* ʹ��˵�� */
// ����ʱ��� #define ��ע��ȥ������ø��õ����� 

int T, n;
int a[N], b[N];
void Sol1() {
	int ha = 0, hb = 0;
	for(int i = 1; i <= n; i++) {
		io.read(a[i]);
		if(a[i] == 1) ha++;
		else hb++;
	} 
	int HA = 0, HB = 0;
	for(int i = 1; i <= n; i++) {
		io.read(b[i]);
		if(b[i] == 1) HA++;
		else HB++;
	}
	if(ha % 2 == 1 || HA % 2 == 1) {
		io.writeln(-1);
		return;
	}
	int Maxa = 0, Maxb = 0, Maxc = 0, Maxd = 0;
	for(int i = 1; i <= n; i++) {
		if(a[i] == 1 && b[i] == 1) Maxa++;
		else if(a[i] == 1 && b[i] == 2) Maxb++;
		else if(a[i] == 2 && b[i] == 1) Maxc++;
		else Maxd++;
	}
	int z = (ha - HA) / 2 + hb - HB;
	int nn = n;
	for(int n = 0; n <= nn; n++) {
	    for(int B = 0; B <= Maxb && B + z <= Maxc && ha / 2 + hb - n - (B + z) >= 0; B++) {
		int C = B + z;
		int D = ha / 2 + hb - n - C;
		int A = n - B - C - D;
		if(C < 0 || C > Maxc || D < 0 || D > Maxd || B < 0 || B > Maxb || A < 0 || A > Maxa) continue;
		//cout << "e" << n << endl;
		for(int i = 1; i <= nn; i++) {
			if(a[i] == 1 && b[i] == 1 && A > 0) {
				A--;
				if(i == nn) io.writeln(1);
				else io.writeSp(1);
			}
		    else if(a[i] == 1 && b[i] == 2 && B > 0) {
		    	B--;
		    	if(i == nn) io.writeln(1);
				else io.writeSp(1);
			} 
	     	else if(a[i] == 2 && b[i] == 1 && C > 0) {
	     		C--;
	     		if(i == nn) io.writeln(1);
				else io.writeSp(1);
			 } 
		    else if(a[i] == 2 && b[i] == 2 && D > 0) {
		    	D--;
		    	if(i == nn) io.writeln(1);
				else io.writeSp(1);
			}
			else {
				if(i == nn) io.writeln(0);
				else io.writeSp(0);
			}
		}
		return;
	}	
	}
	io.writeln(-1);
	return;
}
void Sol2() {
	//cerr << "e";
	int ha = 0, hb = 0;
	for(int i = 1; i <= n; i++) {
		io.read(a[i]);
		if(a[i] == 1) ha++;
		else hb++;
	} 
	int HA = 0, HB = 0;
	for(int i = 1; i <= n; i++) {
		io.read(b[i]);
		if(b[i] == 1) HA++;
		else HB++;
	}
	if(ha % 2 == 1 || HA % 2 == 1) {
		io.writeln(-1);
		return;
	}
	int Maxa = 0, Maxb = 0, Maxc = 0, Maxd = 0;
	for(int i = 1; i <= n; i++) {
		if(a[i] == 1 && b[i] == 1) Maxa++;
		else if(a[i] == 1 && b[i] == 2) Maxb++;
		else if(a[i] == 2 && b[i] == 1) Maxc++;
		else Maxd++;
	}
	int z = (ha - HA) / 2 + hb - HB;
	int nn = n;
	//for(int n = nn / 3; n <= min(nn, nn - nn / 3 + 1); n++) {
	for(int n = max(1ll, nn / 2 - 1000); n <= min(nn, nn / 2 + 1000); n++) {
	    for(int B = 0; B <= Maxb && B + z <= Maxc && ha / 2 + hb - n - (B + z) >= 0; B++) {
		int C = B + z;
		int D = ha / 2 + hb - n - C;
		int A = n - B - C - D;
		if(C < 0 || C > Maxc || D < 0 || D > Maxd || B < 0 || B > Maxb || A < 0 || A > Maxa) continue;
		//cout << "e" << n << endl;
		for(int i = 1; i <= nn; i++) {
			if(a[i] == 1 && b[i] == 1 && A > 0) {
				A--;
				if(i == nn) io.writeln(1);
				else io.writeSp(1);
			}
		    else if(a[i] == 1 && b[i] == 2 && B > 0) {
		    	B--;
		    	if(i == nn) io.writeln(1);
				else io.writeSp(1);
			} 
	     	else if(a[i] == 2 && b[i] == 1 && C > 0) {
	     		C--;
	     		if(i == nn) io.writeln(1);
				else io.writeSp(1);
			 } 
		    else if(a[i] == 2 && b[i] == 2 && D > 0) {
		    	D--;
		    	if(i == nn) io.writeln(1);
				else io.writeSp(1);
			}
			else {
				if(i == nn) io.writeln(0);
				else io.writeSp(0);
			}
		}
		return;
	}	
	}
	io.writeln(-1);
	return;
}
signed main(){
	freopen("slauqe.in", "r", stdin);
	freopen("slauqe.out", "w", stdout); //LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOKKKKKKKKKKKKKKKKKK
	io.read(T);
	while(T--) {
		io.read(n);
		if(n <= 2000) Sol1();
		else Sol2();
	}
	
    
	/*int x;
	io.read(x); // cin >> x;
	long long y;
	io.read(y);
	
	io.write(x); // cout << x;
	io.writeSp(y); // cout << y << '  ';
	io.writeln(x+y); // cout << x+y << endl;*/
	return 0;
} 
