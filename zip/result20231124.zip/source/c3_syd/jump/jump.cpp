#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <queue>
#include <vector>
#include <bitset>
#include <ctime>
#include <map>
#define pii pair <int, int>
using namespace std;
/* #ifdef ONLINE_JUDGE */

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

/* #endif */
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

#define fi first
#define se second

const int N = 2e5 + 5, M = 4e5 + 5;

namespace Subtask1 {

namespace G {

array <int, N> fir;
array <int, M> nex, to;
int cnt;
void add(int x, int y) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;
}

}

namespace T {

array <int, N * 15> fir;
array <int, M * 30> nex, to;
int cnt;
void add(int x, int y) {
	/* write(x), putchar(32); */
	/* write(y), puts("&&"); */
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;
}

}

const int inf = 1e9;

queue <int> q;
array <int, N * 15> dis;
bitset <N * 15> vis;

void bfs(int x) {
	q.push(x);
	dis[x] = 0;
	while (!q.empty()) {
		int u = q.front();
		/* write(u), puts("@"); */
		q.pop();
		if (vis[u]) continue;
		vis[u] = 1;
		for (int i = T::fir[u]; i; i = T::nex[i]) {
			if (dis[T::to[i]] <= dis[u] + 1) continue;
			dis[T::to[i]] = dis[u] + 1;
			q.push(T::to[i]);
		}
	}
}

array <pii, N> prl;
vector <int> isl;
map <pii, bool> mp;

bool dfs(int x, int fa, int ed) {
	bool ans = x == ed;
	for (int i = G::fir[x]; i; i = G::nex[i]) {
		if (G::to[i] == fa) continue;
		bool now = false;
		ans |= now = dfs(G::to[i], x, ed);
		if (now) mp[make_pair(x, G::to[i])] = mp[make_pair(G::to[i], x)] = 1;
	}
	if (ans) isl.push_back(x);
	return ans;
}
int main(int n, int m) {
	int cnt = n;
	for (int i = 2; i <= n; i++) {
		int x = read(), y = read();
		G::add(x, y), G::add(y, x);
		prl[i] = make_pair(x, y);
	}
	/* write(cnt), puts("#"); */
	for (int i = 1; i <= m; i++) {
		int st = read(), ed = read();
		isl.clear();
		dfs(st, 0, ed);
		cnt++;
		for (auto x : isl)
			T::add(x, cnt), T::add(cnt, x);
	}
	for (int i = 2; i <= n; i++) {
		if (mp[prl[i]]) continue;
		cnt++;
		T::add(prl[i].fi, cnt), T::add(cnt, prl[i].fi);
		T::add(cnt, prl[i].se), T::add(prl[i].se, cnt);
	}

	int q = read();
	/* return 0; */
	while (q--) {
		int x = read(), y = read();
		for (int i = 1; i <= cnt; i++)
			dis[i] = inf, vis[i] = 0;
		bfs(x);
		/* write(dis[20]), puts("&"); */
		write(dis[y] / 2), puts("");
	}
	return 0;
}

}

namespace Subtask2 {

namespace G {

array <int, N> fir;
array <int, M> nex, to;
int cnt;
void add(int x, int y) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;
}

}

namespace T {

array <int, 4 * N> fir;
array <int, 8 * M> nex, to;
int cnt;
void add(int x, int y) {
	cnt++;
	nex[cnt] = fir[x];
	to[cnt] = y;
	fir[x] = cnt;
}

}

namespace Hpt {

using T::fir; using T::nex; using T::to;

array <int, 4 * N> siz, son, dep, fa;

void dfs1(int x) {
	siz[x] = 1;
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x]) continue;
		fa[to[i]] = x;
		dep[to[i]] = dep[x] + 1;
		dfs1(to[i]);
		siz[x] += siz[to[i]];
		if (siz[to[i]] > siz[son[x]]) son[x] = to[i];
	}
}

array <int, 4 * N> dfn, top, idx;
int cnt;

void dfs2(int x, int Mgn) {
	cnt++;
	dfn[x] = cnt;
	idx[cnt] = x;
	top[x] = Mgn;
	if (son[x]) dfs2(son[x], Mgn);
	for (int i = fir[x]; i; i = nex[i]) {
		if (to[i] == fa[x] || to[i] == son[x]) continue;
		dfs2(to[i], to[i]);
	}
}

int lca(int x, int y) {
	while (top[x] != top[y]) {
		if (dep[top[x]] < dep[top[y]]) swap(x, y);
		x = fa[top[x]];
	}
	if (dfn[x] > dfn[y]) swap(x, y);
	return x;
}

}

array <pii, N> prl;
vector <int> isl;
map <pii, bool> mp;

bool dfs(int x, int fa, int ed) {
	bool ans = x == ed;
	for (int i = G::fir[x]; i; i = G::nex[i]) {
		if (G::to[i] == fa) continue;
		bool now = false;
		ans |= now = dfs(G::to[i], x, ed);
		if (now) mp[make_pair(x, G::to[i])] = mp[make_pair(G::to[i], x)] = 1;
	}
	if (ans) isl.push_back(x);
	return ans;
}

int main(int n) {
	for (int i = 2; i <= n; i++) {
		int x = read(), y = read();
		G::add(x, y), G::add(y, x);
		prl[i] = make_pair(x, y);
	}
	int x = read(), y = read();
	dfs(x, 0, y);
	int cnt = n + 1;
	for (auto x : isl)
		T::add(x, cnt), T::add(cnt, x);
	for (int i = 2; i <= n; i++) {
		if (mp[prl[i]]) continue;
		cnt++;
		T::add(prl[i].fi, cnt), T::add(cnt, prl[i].fi);
		T::add(prl[i].se, cnt), T::add(cnt, prl[i].se);
	}
	Hpt::dfs1(1), Hpt::dfs2(1, 0);
	int q = read();
	while (q--) {
		int x = read(), y = read();
		int lcA = Hpt::lca(x, y);
		write((Hpt::dep[x] + Hpt::dep[y] - 2 * Hpt::dep[lcA]) / 2), puts("");
	}
	return 0;
}


}


int main() {
	freopen("jump.in", "r", stdin);
	freopen("jump.out", "w", stdout);
	int n = read(), m = read();
	if (m == 1) return Subtask2::main(n);
	if (n <= 8000 && m <= 8000) return Subtask1::main(n, m);
	return 0;
}
