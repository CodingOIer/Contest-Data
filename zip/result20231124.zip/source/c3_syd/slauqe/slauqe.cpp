#include <iostream>
#include <algorithm>
#include <cstdio>
#include <array>
#include <cstring>
#include <vector>
#include <tuple>
#include <map>
using namespace std;
/* #ifdef ONLINE_JUDGE */

#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1++)
char buf[1 << 23], *p1 = buf, *p2 = buf, ubuf[1 << 23], *u = ubuf;

/* #endif */
int read() {
	int p = 0, flg = 1;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') flg = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		p = p * 10 + c - '0';
		c = getchar();
	}
	return p * flg;
}
void write(int x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

namespace Subtask1 {

const int N = 405;

int f[N][N][N];
array <int, N> s, h;

int main(int n) {
	memset(f, 0, sizeof(f));
	f[0][0][0] = 1;
	int tp1 = 0, tp2 = 0;
	s.fill(0), h.fill(0);
	for (int i = 1; i <= n; i++)
		s[i] = read(), tp1 += s[i];
	for (int i = 1; i <= n; i++)
		h[i] = read(), tp2 += h[i];
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j <= 2 * n; j++)
			for (int k = 0; k <= 2 * n; k++)
				f[i][j][k] |= f[i - 1][j][k];
		for (int j = s[i]; j <= 2 * n; j++)
			for (int k = h[i]; k <= 2 * n; k++)
				f[i][j][k] |= f[i - 1][j - s[i]][k - h[i]];
	}
	if (!f[n][tp1 / 2][tp2 / 2] || (tp1 & 1) || (tp2 & 1))
		return puts("-1"), 0;
	int x = n, l = tp1 / 2, r = tp2 / 2;
	vector <int> ans;
	while (x) {
		/* write(x), putchar(32); */
		/* write(l), putchar(32); */
		/* write(r), puts(""); */
		if (x && f[x - 1][l][r]) {
			x--, ans.push_back(0);
			continue;
		}
		if (!x) break;
		l -= s[x], r -= h[x], x--;
		ans.push_back(1);
	}
	reverse(ans.begin(), ans.end());
	for (auto x : ans) write(x), putchar(32);
	return puts(""), 0;
}

}

namespace Subtask2 {

const int N = 2005;
map <tuple <int, int, int>, int> f, pre;
array <int, N> s, h;

void dfs(int x, int l, int r, int n) {
	if (x > n) return;
	if (f[make_tuple(x, l, r)]) return;
	f[make_tuple(x, l, r)] = 1;
	pre[make_tuple(x + 1, l, r)] = -1;
	pre[make_tuple(x + 1, l + s[x], r + h[x])] = 1;
	dfs(x + 1, l, r, n), dfs(x + 1, l + s[x], r + h[x], n);
}

int main(int n) {
	f.clear(), pre.clear();
	int tp1 = 0, tp2 = 0;
	s.fill(0), h.fill(0);
	for (int i = 1; i <= n; i++)
		s[i] = read(), tp1 += s[i];
	for (int i = 1; i <= n; i++)
		h[i] = read(), tp2 += h[i];
	dfs(1, 0, 0, n);
	int x = n + 1, l = tp1 / 2, r = tp2 / 2;
	if (!pre[make_tuple(x, l, r)] || (tp1 & 1) || (tp2 & 1))
		return puts("-1"), 0;
	vector <int> ans;
	while (x > 1) {
		if (~pre[make_tuple(x, l, r)]){
			l -= s[x - 1], r -= h[x - 1], x--;
			ans.push_back(1);
		}
		else x--, ans.push_back(0);
	}
	reverse(ans.begin(), ans.end());
	for (auto x : ans) write(x), putchar(32);
	return puts(""), 0;
}

}


int solve() {
	int n = read();
	if (n <= 200) return Subtask1::main(n);
	else return Subtask2::main(n);
	return 0;
}
int main() {
	freopen("slauqe.in", "r", stdin);
	freopen("slauqe.out", "w", stdout);
	int T = read();
	while (T--) solve();
	return 0;
}
