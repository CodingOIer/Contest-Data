#include<bits/stdc++.h>
using namespace std;
const int N=5+2e5;
struct Graph{
	struct Edge{ int to,nxt; }edge[N*2];
	int head[N],top;
	Graph(){memset(head,-1,sizeof(head)),top=-1; }
	inline void add(int x,int y){
		edge[++top]=(Edge){y,head[x]};
		head[x]=top;
	}
}G;
int fa[23][N],dep[N],dfn[N],e[N],ti=0;
void dfs(int x,int pre){
	dep[x]=dep[pre]+1; dfn[x]=++ti;
	fa[0][x]=pre;
	for(int l=1;l<=18;++l)
		fa[l][x]=fa[l-1][fa[l-1][x]];
	for(int j=G.head[x];~j;j=G.edge[j].nxt){
		int y=G.edge[j].to;
		if(y!=pre){
			dfs(y,x);
		}
	}
	e[x]=ti;
}
int lca(int x,int y){
	if(dep[x]<dep[y]) swap(x,y);
	for(int l=18;l>=0;--l)
		if(dep[fa[l][x]]>=dep[y])
			  x=fa[l][x];
	for(int l=18;l>=0;--l)
		if(fa[l][x]!=fa[l][y]){
			x=fa[l][x];
			y=fa[l][y];
		}
	if(x==y) return x;
	else return fa[0][x];
}
bool is_an(int x,int y){ //test if x is an ancestor of y
	return dfn[x]<=dfn[y]&&e[y]<=e[x];
}
int fa2[23][N],lg[N];
void dfs2(int x,int pre){
	for(int j=G.head[x];~j;j=G.edge[j].nxt){
		int y=G.edge[j].to;
		if(y!=pre){
			dfs2(y,x);
			if(dep[fa2[0][y]]<dep[fa2[0][x]])
				fa2[0][x]=fa2[0][y];
		}
	}
}
pair<int,int> get_dis2(int x,int y){ //y is an ancestor of x
	int ret=0;
	for(int l=18;l>=0;--l)
		if(dep[fa2[l][x]]>dep[y]){
			x=fa2[l][x];
			ret+=1<<l;
		}
	return make_pair(ret,x);
}
struct Q{ int x,y,id,sgn; };
struct Path{ int x,y; };
vector<Q> qLCA[N],qVertex[N];
vector<Path> p[N]; 
int ans[N],ans2[N];
bool cmpQx(Q a,Q b){ return a.x<b.x; }
bool cmpQy(Q a,Q b){ return a.y<b.y; }
bool cmpPx(Path a,Path b){ return a.x<b.x; }
bool cmpPy(Path a,Path b){ return a.y<b.y; }
void solve(vector<Q>& q,vector<Path>& d){
	if(q.empty()||d.empty()) return;
	sort(d.begin(),d.end(),cmpPx);
	int m=(d.size()+1)/2;
	vector<Q> q1,q2;
	vector<Path> d1(d.begin(),d.begin()+m),d2(d.begin()+m,d.end());
	for(auto k:q){
		if(k.x<d[0].x);
		else if(k.x<d1.back().x) q1.push_back(k);
		else q2.push_back(k);
	}
	solve(q1,d1);
	solve(q2,d2);
	sort(d1.begin(),d1.end(),cmpPy);
	for(auto k:q2){
		ans2[k.id]+=k.sgn*(upper_bound(d1.begin(),d1.end(),(Path){0,k.y},cmpPy)-d1.begin());
	}
}
int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	int n,m; scanf("%d%d",&n,&m);
	lg[1]=0; for(int i=2;i<=n;++i) lg[i]=lg[i>>1]+1;
	for(int i=1;i<n;++i){
		int x,y; scanf("%d%d",&x,&y);
		G.add(x,y); G.add(y,x);
	}
	memset(dep,0,sizeof(dep));
	dfs(1,0);
	for(int x=1;x<=n;++x) fa2[0][x]=fa[0][x];
	for(int i=1;i<=m;++i){
		int x,y; scanf("%d%d",&x,&y);
		int d=lca(x,y);
		p[d].push_back((Path){dfn[x],dfn[y]});
		p[d].push_back((Path){dfn[y],dfn[x]});
		if(dep[d]<dep[fa2[0][x]]) fa2[0][x]=d;
		if(dep[d]<dep[fa2[0][y]]) fa2[0][y]=d;
	}
	dfs2(1,0);
//	for(int x=1;x<=n;++x) printf("<%d %d>",x,dep[x]); puts("");
	for(int l=1;l<=18;++l)
		for(int x=1;x<=n;++x)
			fa2[l][x]=fa2[l-1][fa2[l-1][x]];
	int q; scanf("%d",&q);
	for(int i=1;i<=q;++i){
		int x,y; scanf("%d%d",&x,&y);
		int d=lca(x,y); //printf("[%d %d %d]",x,y,d);
//		cerr<<"A"<<endl;
		pair<int,int> x1=get_dis2(x,d),y1=get_dis2(y,d);
//		cerr<<"B"<<endl;
		ans[i]=x1.first+y1.first;
//		cerr<<"("<<x<<" "<<y<<" "<<x1.second<<" "<<y1.second<<endl;
	//	printf("<%d %d(%d %d)(%d %d)>",x,y,x1.first,x1.second,y1.first,y1.second);
		if(x1.second==y1.second) ans[i]-=2; //ans2[i]==0
		else if(x1.second==d||y1.second==d) ans[i]-=1;
		else{
			qLCA[d].push_back((Q){e[x1.second],e[y1.second],i,1});
			qLCA[d].push_back((Q){dfn[x1.second]-1,e[y1.second],i,-1});
			qLCA[d].push_back((Q){e[x1.second],dfn[y1.second]-1,i,-1});
			qLCA[d].push_back((Q){dfn[x1.second]-1,dfn[y1.second]-1,i,1});	
		}
	}
//	exit(0);
	for(int d=1;d<=n;++d){
//		for(auto k:p[d]) printf("<%d %d>",k.x,k.y);
//		for(auto k:qLCA[d]) printf("<%d %d %d %d>",k.x,k.y,k.id,k.sgn);
		solve(qLCA[d],p[d]);
//		for(int i=1;i<=n;++i) printf("<%d %d>",i,ans2[i]); puts("");
	}
	for(int i=1;i<=q;++i){
		if(ans2[i]>0) ans[i]+=1;
		else ans[i]+=2;
		printf("%d\n",ans[i]);
	}
	return 0;
}	
