#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int du[N],f[N],sz[N],b[N];
pii a[N];
bool fl[N];
vector<int> V[N];
il int find(int x){
    return f[x]==x?x:f[x]=find(f[x]);
}
set<pii> S;
il bool check1(int n,int m){
    // cerr<<m<<" ";
    for(int i=0;i<1<<n;++i){
        for(int i=1;i<=m;++i) du[i]=0;
        for(int j=1;j<=n;++j)
            if((1<<(j-1))&i){
                if(a[j].fi<=m) ++du[a[j].fi];
            }
            else{
                // cerr<<"ERROR";
                if(a[j].se<=m){
                    ++du[a[j].se];
                    // if(a[j].se==1) cerr<<"ERROR";
                }
            }
        int flag=1;
        for(int i=1;i<=m;++i) if(!(du[i]&1)){
            flag=0;break;
        }
        if(flag) return 1;
    }
    return 0;
}
il bool check2(int n,int m){
    if(n<=20) return check1(n,m);
    for(int i=1;i<=m;++i){
        fl[i]=du[i]=b[i]=0;
        V[i].clear();
        f[i]=i;sz[i]=1;
    }
    for(int i=1;i<=n;++i){
        if(a[i].fi<=m&&a[i].se>m) fl[a[i].fi]=1;
        if(a[i].fi>m&&a[i].se<=m) fl[a[i].se]=1;
        if(a[i].fi<=m) ++du[a[i].fi];
        if(a[i].se<=m) ++du[a[i].se];
    }
    for(int i=1;i<=n;++i){
        if(a[i].fi<=m&&a[i].se<=m){
            V[a[i].fi].pk(a[i].se);V[a[i].se].pk(a[i].fi);
            if(find(a[i].fi)!=find(a[i].se)){
                fl[find(a[i].fi)]|=fl[find(a[i].se)];
                f[find(a[i].se)]=find(a[i].fi);
            }
        }
    }
    S.clear();
    for(int i=1;i<=m;++i) if(!fl[find(i)]) S.insert(pii(du[i],i));
    for(int i=1;i<=m;++i) fl[i]=0;
    while(!S.empty()){
        int x=S.begin()->se;S.erase(S.begin());
        fl[x]=1;
        int mx=-1;
        for(auto v:V[x]) if(!fl[v]) mx=max(mx,du[v]);
        for(int i=0;i<(int)V[x].size();++i){
            int v=V[x][i];
            if(!fl[v]&&mx==du[v]){
                mx=i;break;
            }
        }
        // cerr<<x<<" "<<mn<<"\n";
        if(mx==-1&&!(b[x]&1)) return 0;
        // cerr<<x<<" "<<mn<<" "<<b[x]<<" "<<du[x]<<"\n";
        if(b[x]&1) mx=-1;
        for(int i=0;i<(int)V[x].size();++i){
            int v=V[x][i];
            if(!fl[v]){
                S.erase(pii(du[v],v));--du[v];S.insert(pii(du[v],v));
                if(mx!=i) ++b[v];
            }
        }
    }
    return 1;
}
il int solve(int n){
    int l=1,r=n;
    while(l<=r){
        int mid=(l+r)>>1;
        // if(n==5) cerr<<mid<<" "<<check(n,mid)<<"\n";
        if(check2(n,mid)) l=mid+1;
        else r=mid-1;
    }
    // write(l);putchar('\n');
    return l;
}
bool pppp;
signed main(){
    freopen("mex.in","r",stdin);
    freopen("mex.out","w",stdout);
    int n=read(),T=read(),seed1=read(),seed2=read(),p=read(),X=0;
    // for(int i=1;i<=5;++i) a[i]=pii(read(),read());
    // check(5,3);return 0;
    for(int i=1;i<=T;++i){
        a[i]=pii(read(),read());
        X=X^(solve(i)*i);
    }
    for(int i=T+1;i<=n;++i){
        a[i]=pii((X*i^seed1)%p+1,(X*i^seed2)%p+1);
        X^=(solve(i)*i);
    }
    write(X);
	return 0;
}
