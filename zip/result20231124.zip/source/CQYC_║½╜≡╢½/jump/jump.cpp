#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
using namespace std;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
vector<int> e[N],V[N];
il void add(int u,int v){
    e[u].pk(v);e[v].pk(u);
    V[u].pk(v);V[v].pk(u);
}
int n,m,rt[N],dfn[N],f[N][20],g[N][20],id,dep[N],Q,sz[N];
struct Mu_tree{
    #define ls (son[w][0])
    #define rs (son[w][1])
    #define ls_ (son[w_][0])
    #define rs_ (son[w_][1])
    #define M (N*350)
    int son[M][2],cnt[M],id;
    il void push_up(int w){
        cnt[w]=cnt[ls]+cnt[rs];
    }
    il void update(int &w,int w_,int l,int r,int x,int k){
        w=++id;ls=ls_;rs=rs_;cnt[w]=cnt[w_];
        if(l==r){
            cnt[w]+=k;return;
        }
        int mid=(l+r)>>1;
        if(x<=mid) update(ls,ls_,l,mid,x,k);
        else update(rs,rs_,mid+1,r,x,k);
        push_up(w);
    }
    il int query(int w,int l,int r,int L,int R){
        if(L>r||R<l||!w) return 0;
        if(L<=l&&R>=r) return cnt[w];
        int mid=(l+r)>>1,tmp=query(ls,l,mid,L,R);
        if(tmp) return 1;
        return query(rs,mid+1,r,L,R);
    }
} ST;
il bool cmp(int u,int v){
    return V[u].size()<V[v].size();
}
il void dfs1(int x,int fa){
    f[x][0]=fa;dep[x]=dep[fa]+1;dfn[x]=++id;sz[x]=1;
    for(int i=1;i<=17;++i) f[x][i]=f[f[x][i-1]][i-1];
    for(vector<int>::iterator it=e[x].begin();it!=e[x].end();++it) if(*it==fa){
        e[x].erase(it);break;
    }
    for(auto v:e[x]){
        dfs1(v,x);sz[x]+=sz[v];
    }
}
il int LCA(int a,int b){
    if(dep[a]<dep[b]) swap(a,b);
    for(int i=17;i>=0;--i) if(dep[f[a][i]]>=dep[b]) a=f[a][i];
    if(a==b) return a;
    for(int i=17;i>=0;--i) if(f[a][i]!=f[b][i]){
        a=f[a][i];b=f[b][i];
    }
    return f[a][0];
}
il int jump1(int a,int d){
    for(int i=17;i>=0;--i) if(dep[f[a][i]]>=d) a=f[a][i];
    return a;
}
il void dfs2(int x){
    vector<int> tmp;swap(tmp,V[x]);
    g[x][0]=dep[x]-1;
    if(!e[x].empty()){
        for(auto v:e[x]) dfs2(v);
        sort(e[x].begin(),e[x].end(),cmp);
        rt[x]=rt[e[x].back()];swap(V[x],V[e[x].back()]);
        g[x][0]=min(g[x][0],dep[g[e[x].back()][0]]);
    }
    for(auto v:tmp){
        ST.update(rt[x],rt[x],1,n,dfn[v],1);V[x].pk(v);
        g[x][0]=min(g[x][0],dep[LCA(x,v)]);
    }
    for(auto v:e[x]) if(v!=e[x].back()){
        for(auto y:V[v]){
            V[x].pk(y);ST.update(rt[x],rt[x],1,n,dfn[y],1);
            g[x][0]=min(g[x][0],dep[LCA(x,y)]);
        }
        V[v].clear();
    }
    // int mn=dep[x]-1;
    // for(auto v:V[x]){
    //     // if(x==7) cerr<<v<<" "<<LCA(x,v)<<"\n";
    //     mn=min(mn,dep[LCA(x,v)]);
    // }
    // if(x==7) cerr<<mn<<" ";
    g[x][0]=jump1(x,g[x][0]);
}
il void dfs3(int x){
    for(int i=1;i<=17;++i) g[x][i]=g[g[x][i-1]][i-1];
    for(auto v:e[x]) dfs3(v);
}
il int jump2(int a,int d){
    int res=0;
    for(int i=17;i>=0;--i) if(dep[g[a][i]]>=d){
        a=g[a][i];res+=(1<<i);
    }
    return res+(dep[a]>d);
}
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<n;++i) add(read(),read());
    for(int i=1;i<=m;++i){
        int u=read(),v=read();
        V[u].pk(v);V[v].pk(u);
    }
    dfs1(1,0);dfs2(1);dfs3(1);
    Q=read();
    // Q=0;
    while(Q--){
        int u=read(),v=read(),res=0;
        // cerr<<u<<" "<<v<<"\n";
        if(dep[u]<dep[v]) swap(u,v);
        int lca=LCA(u,v);
        if(lca==v){
            write(jump2(u,dep[v]));putchar('\n');continue;
        }
        int vv=jump1(v,dep[lca]+1);
        // cerr<<u<<" "<<v<<" "<<lca<<" "<<jump1(u,dep[lca]+1)<<" "<<vv<<"\n";
        // cerr<<u<<" "<<v<<"\n";
        // cerr<<g[7][0]<<" ";
        for(int i=17;i>=0;--i)
        if(g[u][i]&&dep[g[u][i]]>dep[lca]
        &&!ST.query(rt[g[u][i]],1,n,dfn[vv],dfn[vv]+sz[vv]-1)){
            // cerr<<i<<" ";
            u=g[u][i];res+=(1<<i);
        }
        // cerr<<lca<<"\n";
        // cerr<<u<<" "<<res<<"\n";
        if(dep[u]>dep[lca]
        &&!ST.query(rt[u],1,n,dfn[vv],dfn[vv]+sz[vv]-1)){
            if(dep[g[u][0]]<dep[lca]) u=lca;
            else u=g[u][0];
            ++res;
        }
        // cerr<<u<<" "<<res<<"\n";
        if(u==lca||!ST.query(rt[u],1,n,dfn[vv],dfn[vv]+sz[vv]-1)){
            u=lca;
            // cerr<<"ERROR";
        }
        else{
            int l=dep[vv],r=dep[v],now=0;
            // cerr<<ST.query(rt[u],1,n,dfn[3],dfn[3])<<" ";
            while(l<=r){
                int mid=(l+r)>>1,x=jump1(v,mid);
                if(ST.query(rt[u],1,n,dfn[x],dfn[x]+sz[x]-1)){
                    // cerr<<x<<" ";
                    now=x;l=mid+1;
                }
                else r=mid-1;
            }
            u=now;++res;
        }
        // cerr<<u<<" "<<v<<" "<<res<<"\n";
        write(res+jump2(v,dep[u]));putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}
