#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
using namespace std;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,a[N],b[N],lim=10;
bool dp[N][11][11],ans[N];
bool pppp;
signed main(){
	cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
    freopen("slauqe.in","r",stdin);
    freopen("slauqe.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		for(int i=1;i<=n;++i) a[i]=read();
		for(int i=1;i<=n;++i) b[i]=read();
		dp[0][lim>>1][lim>>1]=1;
		for(int i=1;i<=n;++i){
			for(int j=0;j<=lim;++j){
				for(int k=0;k<=lim;++k){
					dp[i][j][k]=0;
					if(j-a[i]>=0&&k-b[i]>=0) dp[i][j][k]=dp[i-1][j-a[i]][k-b[i]];
					if(j+a[i]<=lim&&k+b[i]<=lim) dp[i][j][k]|=dp[i-1][j+a[i]][k+b[i]];
				}
			}
		}
		if(!dp[n][lim>>1][lim>>1]) puts("-1");
		else{
			int nowx=lim>>1,nowy=lim>>1;
			for(int i=n;i;--i){
				if(nowx-a[i]>=0&&nowy-b[i]>=0&&dp[i-1][nowx-a[i]][nowy-b[i]]){
					ans[i]=1;nowx-=a[i];nowy-=b[i];continue;
				}
				if(nowx+a[i]<=lim&&nowy+b[i]<=lim&&dp[i-1][nowx+a[i]][nowy+b[i]]){
					ans[i]=0;nowx+=a[i];nowy+=b[i];continue;
				}
			}
			for(int i=1;i<=n;++i){
				putchar(ans[i]?'1':'0');putchar(' ');
			}
			putchar('\n');
		}
	}
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}
