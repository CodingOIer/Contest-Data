#include<bits/stdc++.h>
#define Mp make_pair
//#define int long long
using namespace std;
const int maxn = 400010;
int n, Q;
struct Tree{
	int to, nxt, co;
}tree[maxn];
int head[maxn], tot = 1;
map<pair<int, int> , int> mp;
void add(int x, int y, int co){
	tree[++tot].to = y, tree[tot].nxt = head[x], tree[tot].co = co;
	mp[Mp(x, y)] = tot;
	head[x] = tot;
}
void change(int x, int y, int co){
	int id = mp[Mp(x, y)];
	tree[id].co = co;
}
int vis[maxn];
void dfs(int x, int co){
//	cout << x << " ";
	for(int i = head[x] ; i ; i = tree[i].nxt){
		int to = tree[i].to;
//		cout << to << " " << tree[i].co << " " << co << " " << vis[i] << " " << vis[i ^ 1] << endl;
		if(tree[i].co == co && !vis[i] && !vis[i ^ 1]){
			vis[i] = vis[i ^ 1] = 1;
			dfs(to, co);
		}
	}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
	cin >> n >> Q;
	for(int i = 1 ; i <= n ; i++){
		int x, y, co;
		cin >> x >> y >> co;
		add(x, y, co);
		add(y, x, co);
	}
	while(Q--){
		int x, y, co;
//		cout << endl;
		cin >> x >> y >> co;
		change(x, y, co);
		change(y, x, co);
		for(int i = 1 ; i <= 2 * n ; i++) vis[i] = 0;
		int ans = 0;
		for(int i = 1 ; i <= n ; i++){
			for(int j = head[i] ; j ; j = tree[j].nxt){
				int to = tree[j].to;
				if(!vis[j]){
					ans++;
//					vis[j] = vis[j ^ 1] = 1;
//					cout << i << " " <<  tree[j].co << endl;
					dfs(to, tree[j].co);
//					cout << endl << endl;
				}
			}
		}
		cout << ans << '\n';
	}
	return 0;
}
/*
4 3
4 2 4
2 3 3
3 4 2
1 4 1
3 4 2
2 3 4
3 4 3
*/
