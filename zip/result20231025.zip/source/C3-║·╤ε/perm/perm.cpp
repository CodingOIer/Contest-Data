#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 3010;
int T;
int n, m, ans;
int a[maxn], vis[maxn], b[maxn];
void dfs(int x){
	if(x > n){
		int x = 1;
		for(int i = 1 ; i <= n ; i++){
			if(b[i] == a[x]) x++;
		}
		if(x <= m) return ;
		x = 1;
		for(int i = 1 ; i <= n ; i++){
			if(b[i] != a[x]) continue;
			for(int j = i - 1 ; j ; j--){
				if(b[j] < b[i]){
					int t = 0;
					for(int k = 1 ; k <= x ; k++)
						if(a[k] == b[j]) t = 1, k = x + 1;
					if(t) break;
//					if(!t){
//						cout << "a" << endl;
//						for(int x = 1 ; x <= n ; x++) cout << b[x] <<" ";
//						cout << endl;
//						cout << b[i] << " " << b[j] << endl;
//					} 
					if(!t) return;
				}
			}
			for(int j = i ; j <= n - m + 2 ; j++){
//				cout << "c ";
				if(b[j] < b[i]){
					int t = 0;
//					cout << "b  ";
					for(int k = x + 1 ; k <= m ; k++)
						if(a[k] == b[j]) t = 1, k = m + 1;
//					cout << t << endl;
					if(t > 0) break;
//					if(!t){
//						cout << "b" << endl;
//						for(int x = 1 ; x <= n ; x++) cout << b[x] << " ";
//						cout << endl;
//						cout << b[i] << " " << b[j] << endl;
//					} 
					if(!t) return;
				}
			}
			x++;
		}
		ans++;
//		for(int i = 1 ; i <= n ; i++) cout << b[i] <<" ";
//		cout << endl;
		return ;
	}
	for(int i = 1 ; i <= n ; i++)
		if(!vis[i]){
			b[x] = i;
			vis[i] = 1;
			dfs(x + 1);
			vis[i] = 0;
		}
}
signed main(){
	ios::sync_with_stdio(false);
	freopen("perm.in", "r", stdin);
	freopen("perm.out", "w", stdout);
	cin >> T;
	while(T--){
		cin >> n >> m;
		for(int i = 1 ; i <= m ; i++) cin >> a[i];
		int t = 0;
		for(int i = 2 ; i <= m ; i++) if(a[i] < a[i - 1]) t = 1, i = m + 1;
		if(t && m != n){
			cout << 0;
			continue;
		}
		for(int i = 1 ; i <= n ; i++) vis[i] = 0;
		dfs(1);
		cout << ans << '\n';
	}
	return 0;
}
/*
1
5 3
5 1 3
*/
