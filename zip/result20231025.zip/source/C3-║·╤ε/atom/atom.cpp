#include<bits/stdc++.h>
//#define int long long
using namespace std; 
const int maxn = 2000010;
int n, tot;
int fir[maxn], len[maxn], la[maxn], l[maxn];
signed main(){
	ios::sync_with_stdio(false);
	freopen("atom.in", "r", stdin);
	freopen("atom.out", "w", stdout);
	cin >> n;
	for(int i = 1 ; i < n ; i++){
		for(int j = 1 ; j <= i ; j++){
			if(!((n - j) / i)) continue;
			tot++;
			l[tot] = i;
			fir[tot] = j - 1;
			len[tot] = (n - j) / i;
			la[tot] = n - j - len[tot] * i;
//			cout << i << " " << j << " " << l[tot] <<" " << fir[tot] << " " << len[tot] << " " << la[tot] << '\n';
		}
	}
	cout << tot << endl;
	for(int i = 1 ; i <= tot ; i++){
		int s = len[i];
		if(fir[i]) s++;
		if(la[i]) s++;
		cout << s <<" ";
		if(fir[i]) cout << fir[i] << " ";
		for(int j = 1 ; j <= len[i] ; j++) cout << l[i] <<" ";
		if(la[i]) cout << la[i];
		cout << '\n';
	}
	return 0;
}
// 2000
