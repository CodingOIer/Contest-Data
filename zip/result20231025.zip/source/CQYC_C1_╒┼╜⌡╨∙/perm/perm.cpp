#include <bits/stdc++.h>
using namespace std;

int t, n, m, a[11], ans;
int tmp[11];
long long ahsh;
bool used[11];

inline long long hsh(int pos, int sel) {
	if (pos == 0) return 0;
	else if (pos == m - sel) return hsh(pos - 1, sel + 1) * 12 + tmp[pos];
	else if (sel == m) return hsh(pos - 1, sel);
	else return min(hsh(pos - 1, sel), hsh(pos - 1, sel + 1) * 12 + tmp[pos]);
}

inline void dfs(int i, int pos) {
	if (i == n + 1) {
		if (ahsh == hsh(n, 0)) {
			++ans;
		}
		return;
	}
	if (n - i + 1 == m - pos + 1) {
		if (!used[a[pos]]) {
			used[a[pos]] = 1;
			tmp[i] = a[pos];
			dfs(i + 1, pos + 1);
			used[a[pos]] = 0;
		}
	} else {
		for (register int j = 1; j <= n; ++j) {
			if (!used[j]) {
				used[j] = 1;
				tmp[i] = j;
				if (j == a[pos]) dfs(i + 1, pos + 1);
				else dfs(i + 1, pos);
				used[j] = 0;
			}
		}
	}
	
}

void sl() {
	freopen("perm.in", "r", stdin);
	freopen("perm.out", "w", stdout);
	scanf("%d", &t);
	while (t--) {
		ans = ahsh = 0;
		scanf("%d%d", &n, &m);
		for (register int i = 1; i <= m; ++i) scanf("%d", &a[i]), ahsh = ahsh * 12 + a[i];
		dfs(1, 1);
		printf("%d\n", ans);
	}
}

int main() {sl();}

