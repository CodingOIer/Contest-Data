#include <bits/stdc++.h>
using namespace std;

int n, p[200001], c[200001];
long long ans;

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 2; i <= n; ++i) {
		scanf("%d", &p[i]);
	}
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &c[i]);
	}
	for (int i = 2; i <= n; ++i) {
		ans += 1ll * c[i] * c[p[i]];
	}
	printf("%lld\n", ans);
	return 0;
}
/*
    1(2)
  /   \
 2(1)  3(3)
 |
 4(2)
*/
