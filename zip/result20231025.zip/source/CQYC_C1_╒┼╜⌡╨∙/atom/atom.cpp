#include <bits/stdc++.h>
using namespace std;

int t, top = 0;
vector<int> atom[2000001];
char buf[1ll << 24];

void flush() {
	fputs(buf + 1, stdout);
	top = 0;
	buf[top + 1] = 0;
}

void write(int i) { // �ǳ�ӷ�׵Ļ�������д 
	if (top > 16000000) {
		flush();
	}
	char st[15];
	int tt = 0;
	while (i) {
		st[++tt] = (i % 10) + '0';
		i /= 10;
	}
	while (tt) {
		buf[++top] = st[tt--];
		buf[top + 1] = 0;
	}
}

void solve() {
	freopen("atom.in", "r", stdin);
	freopen("atom.out", "w", stdout);
	scanf("%d", &t);
	int tot = 0;
	for (int i = t; i > (t / 2) + (t & 1); --i) {  //  �� i �ڵ������ʼ��
		for (int d = t - i + 1; i > d; ++d) {
			if (i != t) atom[++tot].push_back(t - i);
			else ++tot;
			for (int j = t - i + d; j < t; j += d) {
				atom[tot].push_back(d);
			} 
		}
	} 
	write(tot);
	buf[++top] = '\n';
	for (int i = 1; i <= tot; ++i) {
		int len = atom[i].size();
		write(len); buf[++top] = ' ';
		for (auto j : atom[i]) {
			write(j); buf[++top] = ' ';
		} buf[++top] = 10;
	}
	flush();
}

int main() {
	solve();
}
