#include <bits/stdc++.h>
using namespace std;

bool vis[2001][2001];
int n;

int main() {
	freopen("atom.in", "r", stdin);
	scanf("%d", &n);
	freopen("atom.out", "r", stdin);
	int tot;
	scanf("%d", &tot);
	for (int i = 1; i <= tot; ++i) {
		int len, c = n;
		scanf("%d", &len);
		for (int j = 1; j <= len; ++j) {
			int x;
			scanf("%d", &x);
			if (c - x >= 1)
				vis[c][c - x] = 1, c -= x;
			else {
				puts("Wonderful Answer: Invaild output.");
				return 1;
			}
		}
	}
	for (int i = 2; i <= n; ++i) {
		for (int j = 1; j < i; ++j) {
			if (!vis[i][j]) {
				printf("Wonderful Answer: No macth: %d %d\n", i, j);
				return 1;
			}
		}
	}
	puts("Your answer is right.");
}
