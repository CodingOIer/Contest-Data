#include <bits/stdc++.h>
using namespace std;

int n, m, x, y, z;
struct Edge {
	int x, l;
};
vector<Edge> edges[200001];
int color[200001];
unordered_map<int, bool> mp;
vector<Edge> bedge[200001];
int main() {
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		scanf("%d%d%d", &x, &y, &z);
		edges[x].push_back({y, z});
		edges[y].push_back({x, z});
	} 
	for (int i = 1; i <= n; ++i) {
		
	}
	return 0;
}
/*




*/
