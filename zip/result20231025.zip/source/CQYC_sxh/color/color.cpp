#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 1000;

int n, m, s, t, d[N];
vector<int> ve[N];
map<int, int> cnt[N], col[N];
multiset<int> in;

struct DSU{
    int fa[N];
    int find(int x) { return x == fa[x] ? x : fa[x] = find(fa[x]); }
    bool merge(int x, int y) {
        x = find(x), y = find(y);
        if (x == y) return 0;
        return fa[x] = y, 1;
    }
}F;
int ans;
void Add(int x, int y, int c) {
    if (!cnt[x][c] && !cnt[y][c]) ++ans;
    if (cnt[x][c] && cnt[y][c]) --ans;
    ++cnt[x][c], ++cnt[y][c];
}
void Del(int x, int y, int c) {
    --cnt[x][c], --cnt[y][c];
    if (!cnt[x][c] && !cnt[y][c]) --ans;
    if (cnt[x][c] && cnt[y][c]) ++ans;
}

void out() { int c = col[s][t];
    if (!cnt[s][c] && !cnt[t][c]) cout << ans + 1 << '\n';
    else if (cnt[s][c] && cnt[t][c] && (*in.begin() == *(--in.end())) == 1) 
    cout << ans - 1 << '\n'; else cout << ans << '\n';
}
queue<int> q;

signed main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);    
    n = read(), m = read(); For(i, 1, n) F.fa[i] = i;
    For(i, 1, n) { 
        int x = read(), y = read(); if (x > y) swap(x, y);
        col[x][y] = read(), ve[x].pb(y), ve[y].pb(x);
        if (!F.merge(x, y)) { s = x, t = y; continue; }
        Add(x, y, col[x][y]);
    }
    For(i, 1, n) if ((d[i] = SZ(ve[i])) == 1) q.push(i);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : ve[u]) if ((--d[v]) == 1) q.push(v);
    }
    For(u, 1, n) if (d[u]) for (int v : ve[u]) 
        if (d[v] && v > u) in.insert(col[u][v]);
    while (m--) { int x = read(), y = read(), c = read(); if (x > y) swap(x, y); 
        if (d[x] && d[y]) in.erase(in.find(col[x][y])), in.insert(c);
        if (x == s && y == t) col[s][t] = c;
        else Del(x, y, col[x][y]), col[x][y] = c, Add(x, y, c); ; out();
    }
	return 0;
}
