#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int Maxn=1e6+5;
int T,n,m,a[Maxn],ans;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int f[111],g[111],pd[111];
void dfs(int x){
	if(x==n+1){
		int cnt=0,mn1=1e9,mn2=1e9;
		for(int i=1;i<=n;i++){
			if(mn1>f[i]){
				mn1=f[i];mn2=1e9;
			}
			else mn2=min(mn2,f[i]);
			if(i==n-m+cnt+1){
				g[++cnt]=mn1;
				mn1=mn2;mn2=1e9;
			}
		}int op=1;
		//for(int i=1;i<=n;i++)printf("%d ",f[i]);
		//printf(":");
		//for(int i=1;i<=m;i++)printf("%d ",g[i]);
		//puts("");
		for(int i=1;i<=m;i++)
			if(g[i]!=a[i])op=0;
		ans+=op;
	}
	for(int i=1;i<=n;i++){
		if(!pd[i]){
			f[x]=i;
			pd[i]=1;
			dfs(x+1);
			pd[i]=0;
		}
	}
}
int main(){
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	T=read();
	while(T--){
		n=read();m=read();
		for(int i=1;i<=m;i++)a[i]=read();
		ans=0;dfs(1);
		printf("%d\n",ans);
	}
	return 0;
}


