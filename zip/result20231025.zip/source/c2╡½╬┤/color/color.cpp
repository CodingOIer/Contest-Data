#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
const int Maxn=2e5+5;
int n,m;
int head[Maxn],to[Maxn<<1],nxt[Maxn<<1],w[Maxn<<1],cnt1=1;
inline void add(int u,int v,int w1){
	to[++cnt1]=v;
	nxt[cnt1]=head[u];
	w[cnt1]=w1;
	head[u]=cnt1;
}
int f[Maxn][3],dep[Maxn][3],a[Maxn][3];
int vis[Maxn];
int son[Maxn];
int ooo=0;
void Dfs(int u,int v){
	f[u][0]=v;dep[u][0]=dep[v][0]+1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v)continue;
		if(f[y][0]){
			if(!ooo)son[v]=u,son[u]=v;
			ooo=1;
		}
		else Dfs(y,u),a[y][0]=i;
	}
}
void Dfs2(int u,int v){
	f[u][0]=v;dep[u][0]=dep[v][0]+1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v)continue;
		if(f[y][0]){
			if(!ooo)son[f[v][0]]=v,son[v]=f[v][0];
			ooo=1;
		}
		else Dfs2(y,u);//,a[y][0]=w[i];
	}
}
void Dfs1(int u,int v){//printf("%d %d\n",u,v);
	f[u][1]=v;dep[u][1]=dep[v][1]+1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v||y==son[u])continue;
		Dfs1(y,u);a[y][1]=i;
	}
}
void Dfs3(int u,int v){
	f[u][2]=v;dep[u][2]=dep[v][2]+1;
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(y==v||y==son[u])continue;
		Dfs3(y,u);a[y][2]=i;
	}
}
int cnt;
void dfs(int id,int u,int v,int ww){
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(vis[i])continue;
		if(w[i]==ww){
			vis[i]=vis[i^1]=vis[id];
			dfs(i,u,y,w[i]);
		}
		else{
			vis[i]=vis[i^1]=++cnt;
			dfs(i,u,y,w[i]);
		}
	}
	swap(u,v);
	for(int i=head[u];i;i=nxt[i]){
		int y=to[i];
		if(vis[i])continue;
		if(w[i]==ww){
			vis[i]=vis[i^1]=vis[id];
			dfs(i,u,y,w[i]);
		}
		else{
			vis[i]=vis[i^1]=++cnt;
			dfs(i,u,y,w[i]);
		}
	}
}
int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++){
		int u=read(),v=read(),w1=read();
		add(u,v,w1);add(v,u,w1);
	}
	Dfs(1,0);Dfs1(1,0);
	ooo=0;
	for(int i=1;i<=n;i++)f[i][0]=0;
	memset(son,0,sizeof son);
	Dfs2(1,0);Dfs3(1,0);
//	for(int i=1;i<=n;i++)
//		for(int j=0;j<2;j++)
//			printf("f[%d][%d]=%d\n",i,j,f[i][j]);
//	for(int i=1;i<=n;i++)
//		for(int j=0;j<2;j++)
//			printf("dep[%d][%d]=%d\n",i,j,dep[i][j]);
	//for(int i=1;i<=n;i++)printf("son[%d]=%d\n",i,son[i]);
	//for(int i=2;i<=cnt1;i++)printf("to[%d]=%d w[%d]=%d\n",i,to[i],i,w[i]);
	while(m--){
		int u=read(),v=read(),c=read();
		for(int i=head[u];i;i=nxt[i]){
			int y=to[i];
			if(y==v)w[i]=w[i^1]=c;
		}
		swap(u,v);
		for(int i=head[u];i;i=nxt[i]){
			int y=to[i];
			if(y==v)w[i]=w[i^1]=c;
		}
//		for(int i=1;i<=n;i++)
//			for(int j=0;j<3;j++)
//				printf("a[%d][%d]=%d\n",i,j,a[i][j]);
		cnt=0;
		for(int i=1;i<=cnt1;i++)vis[i]=0;
		//for(int i=2;i<=cnt1;i++)printf("to[%d]=%d w[%d]=%d\n",i,to[i],i,w[i]);
		vis[head[1]]=vis[head[1]^1]=++cnt;
		dfs(head[1],1,to[head[1]],w[head[1]]);
		printf("%d\n",cnt);
		
	}
	return 0;
}


