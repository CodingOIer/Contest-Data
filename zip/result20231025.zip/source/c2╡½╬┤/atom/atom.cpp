#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while('0'<=ch&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
inline void write(int x){
	if(x>9)write(x/10);
	putchar(x%10+48);
}
const int Maxn=6e6+6;
int n;
int cnt;
vector<int>a[Maxn];
int w[2005];
int vis[2005][2005];
int main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)w[i]=i-1;
	for(int i=n;i;i--){
		for(int j=w[i];j;j--){
			if(!vis[i][j]){
				++cnt;
				if(i!=n)a[cnt].push_back(n-i);
				a[cnt].push_back(i-j);
				int x=j;
				while(w[x]>0){
					a[cnt].push_back(x-w[x]);
					vis[x][w[x]]=1;
					int ff=w[x];
					w[x]--;
					x=ff;
				}
			}
		}
	}
	write(cnt);putchar('\n');
	for(int i=1;i<=cnt;i++){
		write(a[i].size());putchar(' ');
		for(int j=0;j<a[i].size();j++)write(a[i][j]),putchar(' ');
		putchar('\n');
	}
	return 0;
}


