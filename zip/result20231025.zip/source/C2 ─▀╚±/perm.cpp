#include<bits/stdc++.h>
#define re register
// #define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
/*
 * If you didn't clear in many testcases, you may got 0pts.
 * Duo ce bu qing kong, bao ling 2 hang lei.
 */
int n,m,a[1000001],per[101],T,ans,isai[101];
signed main()
{
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n,m);
		ans=0;
		rep(i,1,m) read(a[i]);
		int Not0=1;
		rep(i,1,m-1) if(a[i]>a[i+1]) {Not0=0;break;}
		if(!Not0){puts("0");continue;}
		iota(per+1,per+n+1,1);
		do
		{
			memset(isai,0,sizeof isai);
			int pos=0,can=1;
			rep(i,1,m)
			{
				++pos;
				while(per[pos]!=a[i]&&pos<=n) ++pos;
				if(pos>n) {can=0;break;}
				isai[pos]=1;
			}
			if(can)
			{
				pos=0;
				can=1;
				rep(i,1,m)
				{
					++pos;
					while(per[pos]!=a[i]&&pos<=n) ++pos;
					rep(j,1,pos-1) if(!isai[j]&&per[j]<a[i]) {can=0;break;}
					if(!can) break;
				}
				ans+=can;
			}
		} while(next_permutation(per+1,per+n+1));
		writeln(ans);
	}
	return 0; 
}
