#include<bits/stdc++.h>
#define re register
// #define int long long
#define rep(i,a,b) for(int i(a);i<=(b);++i)
#define req(i,a,b) for(int i(a);i>=(b);--i)
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,ubuf[1<<23],*u=ubuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
template<typename TP> inline TP read(TP &num)
{
	re TP x=0;re int f=0;re char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
template<typename ...Args> inline void read(Args &...args)
{
	(read(args),...);
}
template<typename TP> inline void write(TP x)
{
	(x<0)?(putchar('-'),x=-x):0;
    (x>9)?(write(x/10),0):0;
	putchar((x%10)^48);
}
template<typename TP> inline void writeln(TP x)
{
	write<TP>(x);
	puts("");
}
int n,m,x,y,z,ans,col[200001];
vector<int> g[200001];
pair<int,int> ver[200001];
map<pair<int,int>,int> vet;
bitset<200001> vis;
pair<int,int> cl(int lef,int rig)
{
	if(vet[{lef,rig}]) return {lef,rig};
	return {rig,lef};
}
#define isecondL col[vet[cl(ver[now].first,i)]]
#define isecondR col[vet[cl(ver[now].second,i)]]
int dfs(int now,int pre)
{
	int lw=0,rw=0;
	vis.set(now);
	for(re auto i:g[ver[now].first])
		if((i^now)
		 &&(i^ver[now].second)
		 &&!vis.test(vet[cl(ver[now].first,i)])
		 &&(isecondL==pre))
			lw=1,dfs(vet[cl(ver[now].first,i)],isecondL);
	for(re auto i:g[ver[now].second])
		if((i^now)
		 &&(i^ver[now].first)
		 &&!vis.test(vet[cl(ver[now].second,i)])
		 &&(isecondR==pre))
			rw=1,dfs(vet[cl(ver[now].second,i)],isecondR);
	return lw+rw;
}
signed main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n,m);
	rep(i,1,n) read(x,y,z),g[x].emplace_back(y),g[y].emplace_back(x),
			   ver[i]={x,y},vet[{x,y}]=i,col[i]=z;
	rep(i,1,n) if(!vis.test(i)) dfs(i,col[i]),++ans;
//	write(ans); // no change answer
	while(m--)
	{
		read(x,y,z);
		if(z^col[vet[cl(x,y)]])
		{
			vis.reset();
			int fans=dfs(vet[cl(x,y)],col[vet[cl(x,y)]]);
			col[vet[cl(x,y)]]=z;
			if(fans==2) ans+=2;
			else 
			{
				vis.reset();
				if(fans==1) ans+=!dfs(vet[cl(x,y)],z);
				else ans-=dfs(vet[cl(x,y)],z);
			}
		}
		writeln(ans);
	}
	return 0;
}
