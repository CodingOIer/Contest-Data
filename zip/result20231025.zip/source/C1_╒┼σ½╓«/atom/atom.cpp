#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("atom.in", "r", stdin);
	freopen("atom.out", "w", stdout);
	printf("1\n0");
	return 0;
}
