#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 2e5+5;
int n,m,head[N],nxt[N<<1],to[N<<1],col[N<<1],cnt = 1;
void add(int u,int v,int c)
{
	nxt[++cnt] = head[u];
	head[u] = cnt;
	to[cnt] = v,col[cnt] = c;
}
int f[N];
int find(int x)
{
	if(f[x]==x) return x;
	return f[x] = find(f[x]);
}
int p[10],tot;
int get(int x,int y)//x->y�ıߵı��
{
	for(int i = head[x];i;i = nxt[i])
		if(to[i]==y)
			return i;
	return -1;
}
inline int sz(int x,int y,int id)
{
	int res = 3;
	for(int i = head[x];i;i = nxt[i])
		if(to[i]!=y&&col[i]==col[id])
		{
			res--;
			break;
		}
	for(int i = head[y];i;i = nxt[i])
		if(to[i]!=x&&col[i]==col[id])
		{
			res--;
			break;
		}
	return res;
}
inline sub1()
{
	while(m--)
	{
		int x,y,z;
		read(x),read(y),read(z);
		int id = get(x,y);
		col[id] = col[id^1] = z;
		iota(f+1,f+n+1,1);
		for(int i = 1;i<=n;i++)
		{
			tot = 0;
			for(int j = head[i];j;j = nxt[j])
				p[++tot] = j;
			for(int j = 1;j<tot;j++)
				for(int k = j+1;k<=tot;k++)
					if(col[p[j]]==col[p[k]])
						f[find(p[j]/2)] = find(p[k]/2);
		}
		int ans = 0;
		for(int i = 1;i<=n;i++)
			if(find(i)==i)
				ans++;
		writen(ans);
	}
	exit(0);
}
signed main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n),read(m);
	for(int i = 1,u,v,w;i<=n;i++)
		read(u),read(v),read(w),add(u,v,w),add(v,u,w);
	if(n*m<=4e6) sub1();
	iota(f+1,f+n+1,1);
	for(int i = 1;i<=n;i++)
	{
		tot = 0;
		for(int j = head[i];j;j = nxt[j])
			p[++tot] = j;
		for(int j = 1;j<tot;j++)
			for(int k = j+1;k<=tot;k++)
				if(col[p[j]]==col[p[k]])
					f[find(p[j]/2)] = find(p[k]/2);
	}
	int ans = 0;
	for(int i = 1;i<=n;i++)
		if(find(i)==i)
			ans++;
	while(m--)
	{
		int x,y,z;
		read(x),read(y),read(z);
		int id = get(x,y);
		int las = sz(x,y,id);
		col[id] = col[id^1] = z;
		int now = sz(x,y,id);
		ans = ans-las+now;
		writen(ans);
	}
	return 0;
}

