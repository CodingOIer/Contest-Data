#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 15;
int n,m,a[N],ans,T,b[N];
bool vis[N],v[N];
void get()
{
	int now = 0;
	for(int i = 1;i<=m;i++)
	{
		int mn = now+1;
		for(int j = now+2;j<=n-m+i;j++)
			if(b[j]<b[mn])
				mn = j;
		if(b[mn]!=a[i]) return;
		now = mn;
	}
	ans++;
}
void dfs(int x)
{
	if(x>n) return get();
	if(v[x]) return dfs(x+1);
	for(int i = 1;i<=n;i++)
		if(!vis[i])
			vis[i] = 1,b[x] = i,dfs(x+1),vis[i] = 0,b[x] = 0;
}
void dfs(int x,int las)
{
	if(x>m)	return dfs(1);
	for(int i = las+1;i<=n;i++)
		b[i] = a[x],v[i] = 1,dfs(x+1,i),b[i] = 0,v[i] = 0;
}
void solve()
{
	read(n),read(m);
	for(int i = 1;i<=n;i++)
		vis[i] = v[i] = 0;
	ans = 0;
	for(int i = 1;i<=m;i++)
		read(a[i]),vis[a[i]] = 1;
	dfs(1,0);
	writen(ans);
}
signed main()
{
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	read(T);
	while(T--) solve();
	return 0;
}

