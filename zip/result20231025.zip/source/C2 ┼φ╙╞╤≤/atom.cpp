#include <bits/stdc++.h>
using namespace std;

template<typename T> inline void read(T &x)
{
	x = 0;
	T f = 1;char ch = getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		{
			f = -1,ch = getchar();
			break;
		}
		ch = getchar();
	}
	while(ch>='0'&&ch<='9')
		x = (x<<3)+(x<<1)+ch-48,ch = getchar();
	x*=f;
}
template<typename T> inline T read()
{
	T x;read(x);return x;
}
template<typename T> inline void write(T x)
{
    if(x<0) x = -x,putchar('-');
    if(x<=9) return putchar(x+48),void();
    write(x/10);
    putchar(x%10+48);
}
template<typename T> inline void writen(T x)
{
    write(x);
    puts("");
}
const int N = 2e3+5;
int n,ans;
vector<int> a[4000005];
signed main()
{
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	read(n);
	int d = 1,t = 0,now = n*(n-1)/2;
	while(d<n)
	{
		if(t>=d) t = 0,d++;
		if(d>=n) break;
		int z = n-t;
		if(z-d<1)
		{
			d++,t = 0;
			continue;
		}
		ans++;
		if(t) a[ans].push_back(t);
		for(;z-d>=1;z-=d)
			a[ans].push_back(d);
		t++;
	}
	writen(ans);
	for(int i = 1;i<=ans;i++)
	{
		write(a[i].size());
		for(auto j:a[i])
			putchar(32),write(j);
		puts("");
	}
	return 0;
}

