#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4;
vector<int>g[NN];
int du[NN],cnt[NN];
map<int,int>mp[NN];
bool vis[NN];
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	map<pair<int,int>,int>edge;
	for(int i=1;i<=n;i++)
	{
		int u,v,c;
		scanf("%d%d%d",&u,&v,&c);
		if(u>v)
			swap(u,v);
		edge[{u,v}]=c;
		mp[u][c]++,mp[v][c]++;
		g[u].push_back(v);
		g[v].push_back(u);
		du[u]++,du[v]++;
	}
	queue<int>q;
	for(int i=1;i<=n;i++)
		if(du[i]==1)
			q.push(i);
	while(q.size())
	{
		int u=q.front();
		vis[u]=true;
		q.pop();
		for(int i=0;i<g[u].size();i++)
		{
			int v=g[u][i];
			du[v]--;
			if(du[v]==1)
				q.push(v);
		}
	}
	int flag=0;
	for(int i=1;i<=n;i++)
		if(!vis[i])
			flag++;
	int last=0;
	for(auto i:edge)
		if(!vis[i.first.first]&&!vis[i.first.second])
		{
			cnt[i.second]++;
			last=i.second;
		}
	int ans=n;
	for(int i=1;i<=n;i++)
		for(auto j:mp[i])
			ans-=max(0,j.second-1);
	while(m--)
	{
		int u,v,c;
		scanf("%d%d%d",&u,&v,&c);
		if(u>v)
			swap(u,v);
		int lc=edge[{u,v}];
		edge[{u,v}]=c;
		if(mp[u][lc]>1)
			ans++;
		if(mp[v][lc]>1)
			ans++;
		mp[u][lc]--,mp[v][lc]--;
		mp[u][c]++,mp[v][c]++;
		if(mp[u][c]>1)
			ans--;
		if(mp[v][c]>1)
			ans--;
		if(!vis[u]&&!vis[v])
		{
			cnt[lc]--;
			cnt[c]++;
			last=c;
		}
		printf("%d\n",ans+(cnt[last]==flag));
	}
	return 0;
}
