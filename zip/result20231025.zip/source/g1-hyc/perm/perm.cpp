#include<bits/stdc++.h>
using namespace std;
const int NN=1e6+4,P=998244353;
int minn[NN];
bool vis[NN];
void solve()
{
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		minn[i]=1,vis[i]=false;
	bool flag1=false,flag2=false;
	int last=0;
	for(int i=1;i<=m;i++)
	{
		int x;
		scanf("%d",&x);
		vis[x]=true;
		if(x>m)
			flag1=true;
		if(x<last)
			flag2=true;
		last=x;
	}
	if(flag2)
	{
		int ans=1;
		for(int i=1;i<=n-m;i++)
			ans=1ll*ans*i%P;
		printf("%d\n",flag1?0:ans);
		return;
	}
	int ans=1;
	for(int i=1,j=0;i<=n;i++)
		if(!vis[i])
			ans=1ll*ans*(j<m?i-1:i)%P;
		else
			j++;
	printf("%d\n",ans);
}
int main()
{
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--)
		solve();
	return 0;
}
