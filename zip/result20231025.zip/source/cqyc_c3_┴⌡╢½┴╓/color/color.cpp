#include <iostream>
#include <queue>
#include <map>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 200005,M = 400005;
int h[N],ne[M],e[M],w[M],idx;
int n,m;

void add(int a,int b,int c){w[idx] = c,e[idx] = b,ne[idx] = h[a],h[a] = idx++;}

map<int,int> c[N];
int c_w,c_x,c_y;
int dep[N],ec[N],fa[N];
int ans;

int query(int x,int y,int w){
    int cnt = 1;
    if(c[y][w])
        cnt--;
    if(c[x][w]+(ec[x]==w))
        cnt--;
    return cnt;
}

int inn[N];
void topsort(){
    queue<int> q;
    for(int k=1;k<=n;k++)
        if(!(--inn[k]))
            q.push(k);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(int k=h[u];~k;k=ne[k]){
            int v = e[k];
            if(!(--inn[v]))
                q.push(v);
        }
    }
}

int c_v[N],c_cnt;
void del(int v){
    c_v[v]--;
    if(!c_v[v])
        c_cnt--;
}
void add(int v){
    if(!c_v[v])
        c_cnt++;
    c_v[v]++;
}

void dfs(int u){
    dep[u] = dep[fa[u]]+1;
    for(int k=h[u];~k;k=ne[k]){
        int v = e[k];
        if(v==fa[u])
            continue;
        if(dep[v]){
            if(!c_w){
                c_w = w[k];
                c_x = u,c_y = v;
            }
            continue;
        }
        fa[v] = u;
        ec[v] = w[k];
        ans += query(u,v,w[k]);
        dfs(v);
        c[u][w[k]]++;
        if(inn[u]>0&&inn[v]>0)
            add(w[k]);
    }
}

int queryc(){
    int cnt = 1;
    if(c[c_y][c_w]+(ec[c_y]==c_w))
        cnt--;
    if(c[c_x][c_w]+(ec[c_x]==c_w))
        cnt--;
    return cnt+(c_cnt==1?1:0);
}

int modify(int x,int y,int w){
    if(dep[x]>dep[y])
        swap(x,y);
    if(x==c_x&&y==c_y){
        del(c_w);
        add(w);
        c_w = w;
        return ans;
    }
    else{
        if(inn[x]>0&&inn[y]>0){
            del(ec[y]);
            add(w);
        }
        c[x][ec[y]]--;
        ans -= query(x,y,ec[y]);
        ec[y] = w;
        ans += query(x,y,w);
        c[x][w]++;
    }
    return ans;
}

int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    memset(h,-1,sizeof(h));
    n = in,m = in;
    for(int k=1;k<=n;k++){
        int a = in,b = in,c = in;
        add(a,b,c);
        add(b,a,c);
        inn[a]++,inn[b]++;
    }
    topsort();
    dfs(1);
    if(dep[c_x]>dep[c_y])
        swap(c_x,c_y);
    add(c_w);
    while(m--){
        int x = in,y = in,c = in;
        out(modify(x,y,c)+queryc(),'\n');
    }
    return 0;
}