#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	int n;
	cin >> n;
	cout << n/2*((n+1)/2);
	return 0;
}