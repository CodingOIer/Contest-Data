#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N=1e5+5,mod=998244353;
int a[N],t[N];
int n,m;

int main(){
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    int T = in;
    while(T--){
        n = in,m = in;
        for(int k=1;k<=n;k++)
            t[k] = 0;
        for(int k=1;k<=m;k++)
            t[a[k]=in]++;
        if(a[1]!=1){
            puts("0");
            continue;
        }
        int ans = 1;
        for(int k=2,x=1;k<=n;k++){
            while(x<=m&&k>=a[x])
                x++;
            if(t[k])
                continue;
            ans = (long long)ans*(k-(x<=m))%mod;
        }
        out(ans,'\n');
    }
    return 0;
}