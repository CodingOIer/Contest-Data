#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout); 
	int n;
	cin >> n;
	int ans=0;
	for ( int i = 1 ; i < n ; i++ )
	{
		for ( int j = 1 ; j <= i ; j++ )
		{
			if(n-j-i<=0&&j<i)
			{
				continue;
			}
			ans++;
		}
	}
	cout << ans << endl;
	for ( int i = 1 ; i < n ; i++ )
	{
		int k=n;
		int cnt=0;
		for ( int j = 1 ; j <= i ; j++ )
		{
			k=n;
			if(k-j-i<=0&&j<i)
			{
				continue;
			}
			cnt=0;
			cnt++;
			k-=j;
			while(k-i>0)
			{
				cnt++;
				k-=i;
			}
			cout << cnt << " ";
			
			
			k=n;
			cout << j <<" ";
			k-=j;
			while(k-i>0)
			{
				cout <<i<<" ";
				k-=i;
			}
			cout << endl;
		}
	}
	return 0;
} 
