#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin >> n;
	for ( int i = 1 ; i < n ; i++ )
	{
		int x;
		cin >> x;
	}
	int i1;
	cin >> i1;
	int x;
	for ( int i = 1 ; i < n ; i++ )
	{
		cin >> x;
	}
	cout << i1*x;
	return 0;
} 
