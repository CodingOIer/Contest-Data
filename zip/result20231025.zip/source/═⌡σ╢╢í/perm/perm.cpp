#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	int T;
	cin >> T;
	while(T--)
	{
		puts("0");
	}
	return 0;
} 
