#include<bits/stdc++.h>
using namespace std;
#define int long long
int e[110][110];
bool vis[110][110];
int n,m;
void dfs(int u,int v)
{
	vis[u][v]=1;
	for ( int i = 1 ; i <= n ; i++ )
	{
		if(vis[v][i])
		{
			continue;
		}
		if(e[v][i]!=e[u][v])
		{
			continue;
		}
		dfs(v,i);
	}
}
signed main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	cin >> n >> m;
	for ( int i = 1 ; i <= n ; i++ )
	{
		int u,v,val;
		cin >> u >> v >> val;
		e[u][v]=e[v][u]=val;
	}
	while(m--){
		int u,v,val;
		cin >> u >> v >>val;
		e[u][v]=e[v][u]=val;
		int ans=0;
		for ( int i = 1 ; i <= n ; i++ )
		{
			for ( int j = 1 ; j <= n ; j++ )
			{
				if(vis[i][j]||i==j)
				{
					continue;
				}
				if(e[i][j]==0)
				{
					continue;
				}
				dfs(i,j);
				dfs(j,i);
				ans++;
			}
		}
		cout << ans << endl;
		memset(vis,0,sizeof(vis));
	}
	return 0;
} 
