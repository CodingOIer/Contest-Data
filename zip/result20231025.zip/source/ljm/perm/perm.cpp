#include<bits/stdc++.h>
#define N 1000006
using namespace std;
int T, ans, n, m; 
int a[N], vis[N], now[N];
void dfs(int k) {
	if(k > n) {
		int j = 0;
		for(int i = 1; i <= n; i++) {
			if(now[i] == a[j + 1] && j < m) j++;
		}
		if(j < m) return;
	    for(int i = 1; i <= m; i++) {
	    	int get = 0;
	    	for(int j = 1; j <= n; j++) 
			    if(a[i - 1] == now[j]) {
			    	get = j;
			    	break;
				}
	    	for(int j = get + 1; j < n - (m - i) + 1; j++) {
	    		if(now[j] < a[i]) return;
			}
		}
		ans++;
		return;
	}
	for(int i = 1; i <= n; i++) {
		if(vis[i]) continue;
		vis[i] = 1;
		now[k] = i;
		dfs(k + 1);
		vis[i] = 0; 
	}
}
signed main(){
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	cin >> T;
	while(T--) {
		cin >> n >> m;
		for(int i = 1; i <= m; i++) cin >> a[i];
		ans = 0;
		dfs(1);
		cout << ans << endl;
	}
	return 0;
}


