#include<bits/stdc++.h>
#define N 4010
using namespace std;
int n, ans = 0;
int dis[N][N];
int A[1000006], len[1000006], D[1000006];
void write(int x) {
	if(x < 0) putchar('-'), x = -x;
	if(x > 9) write(x / 10);
	putchar('0' + x % 10); 
}
signed main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	cin >> n;
	for(int d = 1; d <= n; d++) {
		for(int l = 1; l <= n; l++) {
			if(l + d > n) continue;
			if(dis[l][l + d]) continue;
			ans++;
			if(l != 1) {
				A[ans] = l - 1;
				len[ans]++;
			}
			D[ans] = d;
			for(int now = l; now <= n; now += d) {
				len[ans]++;
				if(now + d <= n) {
					dis[now][now + d] = 1;
				}
			}
			len[ans]--;
		}
	}
	write(ans);
	cout << "\n";
	
	for(int i = 1; i <= ans; i++) {
	    write(len[i]);
	    cout << " ";
	    if(A[i] != 0) {
	    	write(A[i]);
	    	cout << " ";
	    	for(int j = 1; j < len[i]; j++) {
	    		write(D[i]);
	    		cout << " ";
			} 
		}
		else {
			for(int j = 1; j <= len[i]; j++) {
	    		write(D[i]);
	    		cout << " ";
			}
		}
		cout << "\n";
		
	}
	return 0;
}


