#include<bits/stdc++.h>
#define int long long
#define N 200005
using namespace std;
int n;
int P[N], C[N];
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%lld", &n);
	for(int i = 1; i < n; i++) scanf("%lld", &P[i]);
	for(int i = 1; i <= n; i++) scanf("%lld", &C[i]);
	printf("%lld", C[1] * C[n]);
	return 0;
}


