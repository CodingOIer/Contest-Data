#include<bits/stdc++.h>
#define N 200005
using namespace std;
int n, m, fa[N], vis[N];
int col[N];
struct node{
	int to, v;
};
vector<node>p[N];
map<int, map<int, int> >h;
int find(int x) {
	if(x == fa[x]) return x;
	return fa[x] = find(fa[x]);
}
void join(int x, int y) {
	fa[find(x)] = find(y);
}
signed main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++) {
		int u, v;
		scanf("%d %d %d", &u, &v, &col[i]);
		p[u].push_back((node){v, i});
		p[v].push_back((node){u, i});
		h[u][v] = h[v][u] = i;
	}
	while(m--) {
		int u, v, c;
		scanf("%d %d %d", &u, &v, &c);
		col[h[u][v]] = c;
		for(int i = 1; i <= n; i++) fa[i] = i;
		for(int i = 1; i <= n; i++) {
			for(int x = 0; x < p[i].size(); x++) {
				for(int y = x + 1; y < p[i].size(); y++) {
					int j1 = p[i][x].to, j2 = p[i][y].to;
					int b1 = h[i][j1], b2 = h[i][j2];
					if(col[b1] != col[b2]) continue;
					join(b1, b2); 
				}
			}
		}
		int ans = 0;
		for(int i = 1; i <= n; i++) vis[i] = 0;
		for(int i = 1; i <= n; i++) {
			int fx = find(i);
			if(vis[fx]) continue;
			vis[fx] = 1;
			ans++;
		}
		printf("%d\n", ans);
	}
	return 0;
}


