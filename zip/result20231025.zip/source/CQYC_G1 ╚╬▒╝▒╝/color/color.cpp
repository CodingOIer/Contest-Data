#include <bits/stdc++.h>
#define pii pair<int,int>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; //space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2e5+5 ;
int n,m,ans,top,idx ;
pii st[N*30] ;
int col[N],las[N],U[N],V[N],fa[N*30],sz[N*30] ;
vector<pii>vec[N<<2] ;
map<pii,int>id ;
unordered_map<int,int>t[N] ;
void Cover(int x ,int L,int R,int pos,int le = 1,int ri = m)
{
    if(R < L) return ;
    if(le >= L && ri <= R) {vec[x].pb({pos,col[pos]}) ; return ; } int mid = le+ri>>1 ;
    if(L <= mid) Cover(x<<1,L,R,pos,le,mid) ; if(mid < R) Cover(x<<1|1,L,R,pos,mid+1,ri) ;
}
int get(int x) {return fa[x] == x ? x : get(fa[x]) ;}
void Insert(int pos,int cor)
{
    int u = U[pos],v = V[pos] ;
    if(t[cor].find(u) == t[cor].end()) t[cor][u] = ++idx,fa[idx] = idx,sz[idx] = 1 ;//,cerr<<"!",print(idx,cor,u,v),cerr<<"!\n" ;
    if(t[cor].find(v) == t[cor].end()) t[cor][v] = ++idx,fa[idx] = idx,sz[idx] = 1 ;//,cerr<<"!",print(idx,cor,u,v),cerr<<"!\n" ;
    u = get(t[cor][u]),v = get(t[cor][v]) ; if(u == v) return ; 
    if(sz[u] == 1) ++ans ; if(sz[v] == 1) ++ans ; if(sz[u] > sz[v]) swap(u,v) ; fa[u] = v,sz[v] += sz[u],st[++top] = {u,v},--ans ;
}
void Delete(int now)
{
    while(top != now)
    {
        auto [u,v] = st[top] ;
        fa[u] = u,sz[v] -= sz[u],--top,++ans ;
        if(sz[u] == 1) --ans ; if(sz[v] == 1) --ans ;
    }
}
void P()
{enter ;
    FOR(i,1,top,1) print(st[i].first,st[i].second),enter ;
}
void Solve(int x = 1,int le = 1,int ri = m)
{
    int las = top ; for(auto [pos,cor]:vec[x]) Insert(pos,cor) ; int mid = le+ri>>1 ;// puts("---------------------") ;
    if(le == ri) print(ans),enter ; else Solve(x<<1,le,mid),Solve(x<<1|1,mid+1,ri) ; Delete(las) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("color.in","r",stdin) ;
	freopen("color.out","w",stdout) ;
    read(n,m) ;
    FOR(i,1,n,1) las[i] = 1 ;
    FOR(i,1,n,1)
    {
        int u,v,w ; read(u,v,w) ; U[i] = u,V[i] = v ;
        if(u > v) swap(u,v) ; id[{u,v}] = i,col[i] = w ;
    }
    FOR(i,1,m,1)
    {
        int u,v,w ; read(u,v,w) ;
        if(u > v) swap(u,v) ; int p = id[{u,v}] ;
        Cover(1,las[p],i-1,p),col[p] = w,las[p] = i ;
    }
    FOR(i,1,n,1) Cover(1,las[i],m,i) ; Solve() ;
    return 0 ;
}