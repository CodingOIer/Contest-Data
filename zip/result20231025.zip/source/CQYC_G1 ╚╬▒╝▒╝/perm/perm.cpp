#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 15 ;
int n,m,ans,T ;
int a[N],p[N],vis[N],vvs[N] ;
void Check()
{
    vector<int>l ;
    FOR(i,1,n,1) if(vis[p[i]]) l.pb(p[i]) ;
    FOR(i,0,m-1,1) if(l[i] != a[i+1]) return ;
    FOR(i,1,n,1)  if(vis[p[i]])
    {
        int mi = 1e9,chk = 0 ;
        ROF(j,i-1,1,1) 
        {
            if(vis[p[j]]) break ;
            mi = min(mi,p[j]),chk = 1 ;
        }
        FOR(j,i+1,n,1)
        {
            if(vis[p[j]]) break ;
            mi = min(mi,p[j]),chk = 1 ;
        }
        if(chk && mi < p[i]) return ;
    }
    ++ans ;
}
void Dfs(int x)
{
    if(x == n+1) {Check() ; return ;}
    FOR(i,1,n,1) if(!vvs[i]) vvs[i] = 1,p[x] = i,Dfs(x+1),vvs[i] = 0 ;
}
void Solve()
{ 
    read(n,m),me(vis,0),ans = 0 ;
    FOR(i,1,m,1) read(a[i]),vis[a[i]] = 1 ;
    Dfs(1),print(ans),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("perm.in","r",stdin) ;
	freopen("perm.out","w",stdout) ;
    read(T) ; while(T--) Solve() ;
    return 0 ;
}