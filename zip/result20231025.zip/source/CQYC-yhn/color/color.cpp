#include<bits/stdc++.h>
using namespace std;
int n,m,t1,t2,t3,pre[1000005],a[1000005],f[1000005],rt[1000005],b[1000005],cnt,ans[1000005],tot;
map<pair<int,int>,int> mp;
map<pair<int,int>,int>::iterator it;
struct ok{
    int x,y,z;
};
struct node{
    int w1,w2,w3;
};
stack<node> q;
vector<ok> T[2000005];
vector<int> e[2000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int find(int k){
    if(k==f[k]) return k;
    return find(f[k]);
}
inline void merge(int x,int y){
    int d1=find(x),d2=find(y);
    if(d1==d2){
        if(rt[d1]>2) tot--;
        q.push((node){d1,-1,-1});
        return;
    }
    int s2=max(rt[d1]-2,(int)0)+max(rt[d2]-2,(int)0);
    if(rt[d2]>=rt[d1]) q.push((node){d1,d2,f[d1]}),f[d1]=f[d2],rt[d2]+=rt[d1];
    else q.push((node){d2,d1,f[d2]}),f[d2]=f[d1],rt[d1]+=rt[d2];
    int s1=max(max(rt[d1],rt[d2])-2,(int)0);
    tot-=(s1-s2);
}
inline void add(int k,int l,int r,int ll,int rr,ok g){
    if(ll>rr) return;
    if(ll<=l&&rr>=r){
        T[k].push_back(g);
        return;
    }
    int mid=(l+r)>>1;
    if(ll<=mid) add(k<<1,l,mid,ll,rr,g);
    if(rr>mid) add((k<<1)^1,mid+1,r,ll,rr,g);
}
inline void solve(int k,int l,int r){
    for(int i=0;i<(int)T[k].size();i++){
        ok w=T[k][i];
        int d1=mp[make_pair(w.x,w.z)],d2=mp[make_pair(w.y,w.z)];
        merge(d1,d2);
    }
    if(l!=r){
        int mid=(l+r)>>1;
        solve(k<<1,l,mid);solve((k<<1)^1,mid+1,r);
    }
    else ans[l]=tot;
    for(int i=(int)T[k].size()-1;i>=0;i--){
        node w=q.top();q.pop();
        if(w.w2==-1){
            if(rt[w.w1]>2) tot++;
            continue;
        }
        int s1=max((int)0,rt[w.w2]-2);
        f[w.w1]=w.w3;
        rt[w.w2]-=rt[w.w1];
        int s2=max((int)0,rt[w.w2]-2)+max((int)0,rt[w.w1]-2);
        tot+=(s1-s2);
    }
}
signed main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++){
        t1=read(),t2=read(),t3=read();
        mp[make_pair(min(t1,t2),max(t1,t2))]=i;
        pre[i]=0;b[i]=t3;
        e[t1].push_back(t3);
        e[t2].push_back(t3);
    }
    for(int i=1;i<=m;i++){
        t1=read(),t2=read(),t3=read();
        int d=mp[make_pair(min(t1,t2),max(t1,t2))];
        add(1,0,m,pre[d],i-1,(ok){min(t1,t2),max(t1,t2),b[d]});
        pre[d]=i;b[d]=t3;
        e[t1].push_back(t3);
        e[t2].push_back(t3);
    }
    for(it=mp.begin();it!=mp.end();it++){
        pair<int,int> d=(it->first);
        int z=(it->second);
        add(1,0,m,pre[z],m,(ok){d.first,d.second,b[z]});
    }
    mp.clear();
    for(int i=1;i<=n;i++){
        sort(e[i].begin(),e[i].end());
        e[i].resize(unique(e[i].begin(),e[i].end())-e[i].begin());
        for(int j=0;j<(int)e[i].size();j++) mp[make_pair(i,e[i][j])]=++cnt;
    }
    for(int i=1;i<=cnt;i++) f[i]=i,rt[i]=1;
    tot=n;
    solve(1,0,m);
    for(int i=1;i<=m;i++) cout<<ans[i]<<"\n";
    return 0;
}