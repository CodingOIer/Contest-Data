#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int T,n,m,a[1000005],b[1000005],ans,c[1000005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline bool check(){
    int t=1;
    for(int i=1;i<=m;i++){
        int d=t;
        if(d>n) return 0;
        for(int j=t;j<=(n-m+i);j++) if(b[j]<b[d]) d=j;
        c[i]=b[d];
        t=d+1;
    }
    for(int i=1;i<=m;i++) if(c[i]!=a[i]) return 0;
    return 1;
}
signed main(){
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
    while(T--){
        n=read(),m=read();
        ans=0;
        for(int i=1;i<=m;i++) a[i]=read();
        for(int i=1;i<=n;i++) b[i]=i;
        ans+=check();
        while(next_permutation(b+1,b+1+n)) ans+=check();
        cout<<ans<<"\n";
    }
    return 0;
}