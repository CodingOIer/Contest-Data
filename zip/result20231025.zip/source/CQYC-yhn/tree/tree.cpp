#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,f[200005],ans,sum[200005],c[200005];
bool v[200005];
struct ok{
    int id,z;
    bool operator < (const ok &A) const{
        return z<A.z;
    }
};
vector<ok> e;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    n=read();
    for(int i=2;i<=n;i++) f[i]=read(),sum[f[i]]++;
    for(int i=1;i<=n;i++) c[i]=read();
    for(int i=1;i<=n;i++) if(sum[i]==0) e.push_back((ok){i,c[i]});
    sort(e.begin(),e.end());
    v[1]=1;
    for(int i=0;i<(int)e.size();i++){
        int t=e[i].id;
        while(!v[t]){
            v[t]=1;
            t=f[t];
        }
        ans+=(e[i].z*c[t]);
    }
    cout<<ans;
    return 0;
}