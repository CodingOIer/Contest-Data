#include<bits/stdc++.h>
using namespace std;
int n;
vector<int> e;
vector<vector<int>> ans;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++){
        for(int j=0;j<i;j++){
            int d=n-j;
            if((d-i)>0){
                e.clear();
                if(j) e.push_back(j);
                while((d-i)>0) e.push_back(i),d-=i;
                ans.push_back(e);
            }
        }
    }
    cout<<(int)ans.size()<<"\n";
    for(int i=0;i<(int)ans.size();i++){
        cout<<(int)ans[i].size()<<" ";
        for(int j=0;j<(int)ans[i].size();j++) cout<<ans[i][j]<<" ";
        cout<<"\n";
    }
    return 0;
}