#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
int n,m;
int T;
int s[1000011];
bool b[1000011],ap[1000011];
int a[1000011];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    cin >> T;
    while(T--)
    {
        cin >> n >> m;
        for(int i = 1;i <= n;i++) ap[i] = b[i] = 0;
        bool flag = 0;
        int mx = 0;
        for(int i = 1;i <= m;i++)
        {
            cin >> a[i];
            ap[a[i]] = 1;
            if(a[i] < a[i - 1]) flag = 1;
            if(flag) b[a[i]] = 1;
            else mx = i;
        }
        a[++mx] = 0;
        for(int i = 1;i <= n;i++) s[i] = s[i - 1] + b[i];
        if(a[1] - s[a[1]] != 1)
        {
            cout << 0 << "\n";
            continue;
        }
        int cnt = 1,j = 1;
        long long ans = 1;
        for(int i = 1;i <= n;i++) if(!ap[i])
        {
            while(j < mx && a[j + 1] < i) j++,cnt++;
            (ans *= cnt) %= mod;
            cnt++;
        }
        cout << ans << "\n";
    }
    return 0;
}