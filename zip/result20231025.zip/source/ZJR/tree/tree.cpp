#include<bits/stdc++.h>
using namespace std;
vector<int> v[200011];
int fa[200011];
long long f[200011],c[200011],sum[200011];
void DFS(int root,int p,long long uval)
{
    if(uval >= f[root]) return;
    f[root] = min(f[root],uval + c[root] * c[p] + f[p]);
    for(auto i:v[p])
        DFS(root,i,uval + (sum[p] - (f[i] + c[p] * c[i])));
}
void Solve(int p)
{
    if(!v[p].size())
        return f[p] = 0,void();
    for(auto i:v[p])
    {
        Solve(i);
        f[p] = LLONG_MAX;
        DFS(p,i,0);
        sum[p] += f[p];
    }
    f[p] = sum[p];
}
int n;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    cin >> n;
    for(int i = 2;i <= n;i++) cin >> fa[i];
    for(int i = 2;i <= n;i++) v[fa[i]].push_back(i);
    for(int i = 1;i <= n;i++) cin >> c[i];
    Solve(1);
    cout << f[1];
    return 0;
}
//Now is 11:04,I have not enough time for it.I found it is Tree including Tree(SGT and LCT)