#include<bits/stdc++.h>
using namespace std;
int n;
vector<int> ans[6000011];
queue<int> q[2011];
int idx;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    cin >> n;
    for(int i = n;i > 1;i--)
    {
        for(int j = 1;j < i;j++)
        {
            if(q[i].empty())
            {
                idx++;
                if(i < n)
                    ans[idx].push_back(n - i);
                ans[idx].push_back(i - j);
                q[j].push(idx);
            }else{
                ans[q[i].front()].push_back(i - j);
                q[j].push(q[i].front());
                q[i].pop();
            }
        }
    }
    cout << idx << "\n";
    for(int i = 1;i <= idx;i++)
    {
        cout << ans[i].size() << " ";
        for(auto j:ans[i]) cout << j << " ";
        cout << "\n";
    }
    return 0;
}