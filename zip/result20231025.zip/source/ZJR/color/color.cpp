#include<bits/stdc++.h>
#include<bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;
int fa[200011];
int find(int x) {return (x == fa[x]) ? x : (fa[x] = find(fa[x]));}
int ans;
inline int Merge(int x,int y)
{
    x = find(x),y = find(y);
    if(!x || !y) return (x^y);
    if(x != y)
        ans--,fa[x] = y;
    return y;
}
typedef struct{
    int x,y,c;
}Edge;
Edge e[200011];
gp_hash_table<int,int> dui[200011],bcj[200011];//bcj[place][color]
int n,m;
inline void Solve()
{
    for(int i = 1;i <= n;i++) fa[i]= i;
    ans = n;
    for(int i = 1;i <= n;i++)
        bcj[e[i].x][e[i].c] = Merge(bcj[e[i].x][e[i].c],i),bcj[e[i].y][e[i].c] = Merge(bcj[e[i].y][e[i].c],i);
    cout << ans << "\n";
    for(int i = 1;i <= n;i++) bcj[e[i].x][e[i].c] = bcj[e[i].y][e[i].c] = 0;
}
int x,y,c;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    cin >> n >> m;
    for(int i = 1;i <= n;i++)
    {
        cin >> e[i].x >> e[i].y >> e[i].c;
        if(e[i].x > e[i].y) swap(e[i].x,e[i].y);
        dui[e[i].x][e[i].y] = i;
    }
    while(m--)
    {
        cin >> x >> y >> c;
        if(x > y) swap(x,y);
        e[dui[x][y]].c = c;
        Solve();
    }
    return 0;
}