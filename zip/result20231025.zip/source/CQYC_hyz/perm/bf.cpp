#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 1e6 + 10;

int n, m, ans;
int a[N], b[N];

bool vis[N];

bool check() {
    int now = 0;
    for(int i = 1; i <= m; i++) {
        int mx = now + 1, r = n - (m - i);
        for(int j = now + 1; j <= r; j++) if(b[j] < b[mx]) mx = j;
        if(a[i] != b[mx]) return 0; now = mx;
    }
    return 1;
}

void dfs(int x) {
    if(x == n + 1) return ans += check(), void();
    for(int i = 1; i <= n; i++) if(!vis[i])
        vis[i] = 1, b[x] = i, dfs(x + 1), vis[i] = 0;
}

void solve() {
    n = read(), m = read(), ans = 0;
    for(int i = 1; i <= m; i++) a[i] = read();
    dfs(1), write(ans), putchar('\n');
}

bool edmer;
signed main() {
	freopen("perm.in", "r", stdin);
	freopen("perm.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    int T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 