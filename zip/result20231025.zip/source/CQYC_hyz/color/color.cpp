#include <bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10;

struct edge {
    int v, w;
};

int n, m, Ex, Ey, Ec, ans, tot;
int w[N], fa[N];

bool vis[N];

vector<edge> e[N];

map<int, int> mp[N], C;

int calc(int x, int c) {
    if(w[x] == c) return 0;
    if(mp[x][c]) return 1;
    return 0;
}

int check() {
    bool f1 = 0, f2 = 0;
    if(!mp[Ex][Ec] and w[Ex] != Ec) f1 = 1;
    if(!mp[Ey][Ec] and w[Ey] != Ec) f2 = 1;
    if(f1 and f2) return -1;
    return C[Ec] != tot and !f1 and !f2;
}

bool ind(int x) {
    return vis[x] or x == Ex or x == Ey;
}

void dfs(int x) {
    for(edge l : e[x]) if(l.v ^ fa[x]) {
        if(fa[l.v] or l.v == 1) {
            Ex = l.v, Ey = x, Ec = l.w;
            continue;
        }
        fa[l.v] = x, w[l.v] = l.w, dfs(l.v);
    }

    if(w[x]) {
        ans -= calc(fa[x], w[x]);
        mp[fa[x]][w[x]]++;
        ans += calc(fa[x], w[x]);
    }
}

void work() {
    dfs(1);

    int lx = Ex;

    while(fa[lx] != Ey) C[w[lx]]++, vis[lx] = 1, lx = fa[lx], tot++;
    
    ans -= check();

    while(m--) {
        int x = read(), y = read(), c = read();
        if(fa[y] == x) swap(x, y);
        if(fa[x] == y) {
            int tmp = w[x];
            ans -= calc(y, w[x]) + calc(x, c) + calc(y, c);

            if(ind(x) or ind(y)) ans += check();
            if(vis[x]) C[w[x]]--, C[c]++;

            mp[y][w[x]]--, mp[y][c]++, w[x] = c; 
            ans += calc(y, c) + calc(x, tmp) + calc(y, tmp);

            if(ind(x) or ind(y)) ans -= check();
        }
        else ans += check(), Ec = c, ans -= check();

        write(ans), putchar('\n');
    }
}

bool edmer;
signed main() {
	freopen("color.in", "r", stdin);
	freopen("color.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    n = read(), m = read();
    for(int i = 1; i <= n; i++) {
        int u = read(), v = read(), c = read();
        e[u].push_back({ v, c }), e[v].push_back({ u, c });
    }

    work();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 