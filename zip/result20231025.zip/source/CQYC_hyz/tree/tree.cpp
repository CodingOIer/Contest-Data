#include <bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}

const int mod = 998244353;

void Min(int &x, int y) { y < x and (x = y); }
void Max(int &x, int y) { y > x and (x = y); }

void inc(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = 1ll * x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

bool stmer;

const int N = 2e5 + 10, inf = 1e18;

int n;
int fa[N], c[N];

vector<int> e[N];

namespace sub1 {
    const int M = 2010;

    int f[M][M];
    
    void dfs(int x) {
        if(e[x].empty()) {
            for(int i = 1; i <= n; i++) f[x][i] = c[x] * c[i];
            return;
        }
        
        int sum = 0;
        for(int v : e[x]) dfs(v), sum += f[v][x];
        for(int i = 1; i <= n; i++) {
            f[x][i] = inf;
            for(int v : e[x]) Min(f[x][i], sum - f[v][x] + f[v][i]);
        }
    }

    void solve() {
        dfs(1), write(f[1][1]);
    }
}

namespace sub2 {
    void solve() {
        write(c[1] * c[n]);
    }
}

bool edmer;
signed main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    n = read();
    for(int i = 2; i <= n; i++) e[fa[i] = read()].push_back(i);

    for(int i = 1; i <= n; i++) c[i] = read();

    if(n <= 2e3) sub1 :: solve();
    else sub2 :: solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
	return 0;
} 