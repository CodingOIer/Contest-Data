#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
inline void read(int &x){
	x=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int head[N],nxt[N<<1],c[N<<1],tot;
inline void add(int x,int z){
	nxt[++tot]=head[x];
	c[tot]=z;
	head[x]=tot;
}
int n,m,x,y,k,id,p[N],vis[N],vis2[N],f[N],ans;
map<pair<int,int>,int> Id;
int find(int x){return f[x]==x?x:f[x]=find(f[x]);}
int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;++i){
		read(x),read(y),read(k);
		if(x>y) swap(x,y);
		Id[{x,y}]=i;
		add(x,k);
		add(y,k);
	}
	while(m){
		read(x),read(y),read(k);
		if(x>y) swap(x,y);
		id=Id[{x,y}];
		c[(id-1)<<1|1]=c[id<<1]=k;
		for(int i=1;i<=n;++i) f[i]=i;
		for(int i=1;i<=n;++i)
			for(int o=head[i];o;o=nxt[o]){
				k=c[o];
				if(vis[k]==m&&vis2[k]==i){
					if(!p[k]) p[k]=find((o+1)>>1);
					else f[find((o+1)>>1)]=p[k];
				}else{
					vis[k]=m,vis2[k]=i;
					p[k]=find((o+1)>>1);
				}
			}
		ans=0;
		for(int i=1;i<=n;++i)
			ans+=(find(i)==i);
		printf("%d\n",ans);
		--m;
	}
	return 0;
}
