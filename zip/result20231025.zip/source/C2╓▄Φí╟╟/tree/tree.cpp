#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,x,c[N];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=2;i<=n;++i) scanf("%d",&x);
	for(int i=1;i<=n;++i) scanf("%d",&c[i]);
	printf("%lld",1ll*c[1]*c[n]);
	return 0;
}

