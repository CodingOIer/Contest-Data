#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5,mod=998244353;
inline void read(int &x){
	x=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while('0'<=c&&c<='9') x=(x<<1)+(x<<3)+(c^48),c=getchar();
}
int T,n,m,a[N],cnt,id[N],ans,s[N];
bool no[N],down;
void print(int x){
	if(x>9) print(x/10);
	putchar(48+x%10);
}
int main(){
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	read(T);
	while(T--){
		read(n),read(m);
		cnt=1;
		for(int i=1;i<=m;++i){
			read(a[i]);
			if(a[i]<a[i-1]) down=1;
			no[i]=down;
			cnt+=!down;
			id[a[i]]=i;
		}
		for(int i=n;i;--i){
			s[i]=cnt;
			if(id[i]&&!no[id[i]-1]) no[id[i]-1]=1,--cnt;
			if(id[i]&&!no[id[i]]) no[id[i]]=1,--cnt;
		}
		ans=1;cnt=0;
		for(int i=1;i<=n;++i)
			if(!id[i]) ans=1ll*ans*(cnt+s[i])%mod,++cnt;
		print(ans);
		putchar('\n');
		for(int i=1;i<=n;++i) no[i]=s[i]=id[i]=0;
		no[0]=down=0;
	}
	return 0;
}
