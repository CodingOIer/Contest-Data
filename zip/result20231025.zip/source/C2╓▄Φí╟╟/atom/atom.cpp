#include<bits/stdc++.h>
using namespace std;
const int N=2005;
int n,pre,u,d,top;
char stk[20];
inline void print(int x){
	if(!x){
		putchar('0');
		putchar(' ');
		return;
	}
	top=0;
	while(x) stk[++top]=x%10+48,x/=10;
	while(top) putchar(stk[top--]);
	putchar(' ');
}
int st2[N],top2;
queue<int> to[N];
int main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		u=n-i;
		d=pre+i-1;
		for(int j=pre;j;--j) to[i].push(i-1);
		for(int j=i-1;j;--j) to[i].push(j);
		pre=max(0,d-u);
	}
	print(to[n].size()),putchar('\n');
	while(!to[n].empty()){
		top2=0;
		for(int i=n,tmp;;){
			st2[++top2]=i;
			if(to[i].empty()) break;
			tmp=i;
			i=to[i].front(),to[tmp].pop();
		}
		print(top2-1);
		for(int i=2;i<=top2;++i) print(st2[i-1]-st2[i]);
		putchar('\n');
	}
	return 0;
} 

