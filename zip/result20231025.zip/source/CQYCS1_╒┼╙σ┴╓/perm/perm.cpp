#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(int x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e6+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int T,n,m,a[N],b[N];
ll mul[N],inv[N];
inline ll qp(ll a,ll b){
    if(!b)return 1;
    ll c=qp(a,b>>1);
    c=c*c%mod;
    if(b&1)c=c*a%mod;
    return c;
}
inline void prep(){
    mul[0]=inv[0]=1;
    rep(i,1,N-5)mul[i]=mul[i-1]*i%mod;
    inv[N-5]=qp(mul[N-5],mod-2);
    per(i,N-6,1)inv[i]=inv[i+1]*(i+1)%mod;
}
inline ll c(int x,int y){
    if(x<0||y<0||x<y)return 0;
    return mul[x]*inv[y]%mod*inv[x-y]%mod;
}
int suf[N],ct[N],tot;
ll ans;
inline void dfs(int pos){
    if(pos==b[tot]+1){
        ll k=1;
        rep(i,1,tot)k=k*mul[ct[i]]%mod;
        (ans+=k)%=mod;
        return;
    }
    rep(i,1,tot)if(pos<=b[i])ct[i]++,dfs(pos+1),ct[i]--;
}
int main(){
	freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
	T=read(),prep();
    while(T--){
        n=read(),m=read(),ans=tot=0;
        rep(i,1,n+1)suf[i]=0;
        rep(i,1,m)a[i]=read(),suf[a[i]]++;
        a[m+1]=0;
        per(i,n,1)suf[i]+=suf[i+1];
        if(n==m){
            pf(1),putchar('\n');
            continue;
        }
        if(m==1){
            if(a[1]==1)pf(mul[n]),putchar('\n');
            else pf(0),putchar('\n');
            continue;
        }
        rep(i,1,m+1){
            b[i]=n-max(a[i-1],a[i]),ct[i]=0;
            if(a[i]<a[i-1]){
                tot=i;
                break;
            }
        }
        rep(i,1,tot)b[i]-=suf[n-b[i]+1];
        sort(b+1,b+tot+1);
        if(b[tot]+m<n){
            pf(0),putchar('\n');
            continue;
        }
        dfs(1),pf(ans),putchar('\n');
    }
    return 0;
}