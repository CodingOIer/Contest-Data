#include<bits/stdc++.h>
#define ll long long
#define mid (l+r>>1)
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(int x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e5+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int n,m,h[N],to[N<<1],nxt[N<<1],w[N<<1],cnt=1;
inline void add(int a,int b,int c){
    to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,w[cnt]=c;
}
struct edge{
    int x,y,c;
}e[N];
bool vis[N];
int inc[N],st[N],tp;
inline int search(int x,int fr){
    vis[x]=1;
    e(x)if(vis[y]){
        if(i^fr^1)return st[++tp]=x,inc[x]=tp,y;
    }else {
        int k=search(y,i);
        if(!k)continue;
        if(k==-1)return -1;
        st[++tp]=x,inc[x]=tp;
        if(x==k)return -1;
        return k;
    }
    return 0;
}
int fc[N],lc[N],rc[N],dep[N];
inline void dfs(int x,int fa){
    dep[x]=dep[fa]+1;
    e(x)if(y^fa&&!inc[y])fc[y]=w[i],dfs(y,x);
}
inline void change(int x,int y,int c){
    if(inc[x]&&inc[y]){
        if(inc[x]>inc[y])swap(x,y);
        if(inc[x]==1&&inc[y]==tp)lc[x]=rc[y]=c;
        else rc[x]=lc[y]=c;
        return;
    }
    if(dep[x]<dep[y])swap(x,y);
    fc[x]=c;
}
int s[N],top,dp[N];
bool fl[N],fr[N];
void clear(){
    while(top)vis[s[top--]]=0;
}
void addin(int x){
    if(!vis[x])s[++top]=x,vis[x]=1;
}
inline void Dfs(int x,int fa){
    dp[x]=fl[x]=fr[x]=0;
    e(x)if(y^fa&&!inc[y])Dfs(y,x),clear();
    if(!inc[x])addin(fc[x]),dp[x]++;
    e(x)if(y^fa&&!inc[y]){
        if(!inc[x]){
            dp[x]+=dp[y];
            if(vis[fc[y]])dp[x]--;
            addin(fc[y]);
        }else {
            dp[x]+=dp[y];
            if(vis[fc[y]])dp[x]--;
            addin(fc[y]);
            if(fc[y]==lc[x])fl[x]=1;
            if(fc[y]==rc[x])fr[x]=1;
        }
    }
}
inline int solve(){
    int ans=0;
    rep(i,1,tp){
        Dfs(st[i],0),clear(),ans+=dp[st[i]];
        ans-=fl[st[i]]+fr[st[i]];
        if(lc[st[i]]==rc[st[i]])ans+=fl[st[i]];
    }
    int ct=1;
    rep(i,2,tp)ct+=(lc[st[i]]!=lc[st[i-1]]);
    if(ct>1&&lc[st[1]]==lc[st[tp]])ct--;
    ans+=ct;
    return ans;
}
int main(){
	freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
	n=read(),m=read();
    for(int i=1,x,y,z;i<=n;i++)x=read(),y=read(),z=read(),add(x,y,z),add(y,x,z),e[i]={x,y,z};
    if(search(1,0)&0)return 0;
    rep(i,1,n){
        int x=e[i].x,y=e[i].y;
        if(inc[x]&&inc[y]){
            if(inc[x]>inc[y])swap(x,y);
            if(inc[x]==1&&inc[y]==tp)lc[x]=rc[y]=e[i].c;
            else rc[x]=lc[y]=e[i].c;
        }
    }
    memset(vis,0,sizeof(vis));
    rep(i,1,tp)dfs(st[i],0);
    for(int i=1,x,y,c;i<=m;i++)x=read(),y=read(),c=read(),change(x,y,c),pf(solve()),putchar('\n');
    return 0;
}