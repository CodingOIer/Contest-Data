#include<bits/stdc++.h>
#define ll long long
#define L xd[x].l
#define R xd[x].r
#define mid (l+r>>1)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(int x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e3+5,M=5e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
const double eps=1e-9;
using namespace std;
int n,nk;
int pre[N];
int main(){
	freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
	nk=n=read();
    int nw=1,ans=0;
    while(nw<n)ans+=n-nw,nw+=2;
    pf(ans),putchar('\n');
    rep(i,1,ans){
        vector<int>p;
        int nw=nk;
        if(nw!=n)p.pb(n-nw);
        while(nw>1){
            if(pre[nw]==nw-1)break;
            p.pb(++pre[nw]),nw-=pre[nw];
        }
        while(pre[nk]==nk-1&&nk>1)nk--;
        pf(p.size()),putchar(' ');
        for(auto y:p)pf(y),putchar(' ');
        putchar('\n');
    }
    return 0;
}