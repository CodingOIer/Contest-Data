#include<bits/stdc++.h>
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n,m;
signed main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	read(n);
	for(int i=1;i<n;i++)m+=min(n-i,i);
	write(m),putch('\n');
	for(int i=1;i<n;i++){
		for(int j=0;j<i&&j<min(n-i,i);j++){
			write((j>0)+(n-j-1)/i),putch(' ');
			if(j>0)write(j),putch(' ');
			for(int k=1;k<=(n-j-1)/i;k++)write(i),putch(' ');
			putch('\n');
		}
	}
	flush();
}/*
4

4
3 1 1 1
2 2 1
2 1 2
1 3

*/
