#include<bits/stdc++.h>
using namespace std;
int n;
long long nw=1,len=0,cnt=0;
vector<int> ans[2000200];
int main()
{
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n;
	if(n<=100)
	{
		for(int i=2;i<=n;i++) 
		{
			for(int j=1;j<=nw;j++) ans[j].push_back(1);
			for(int j=2;j<=i-1;j++) ans[nw+j-1].push_back(j);
			nw+=(i-2);
		}
	}
	else for(int i=2;i<=n;i++) nw+=(i-2);
	cout<<nw<<'\n';
	if(n<=100)
	{
		for(int i=1;i<=nw;i++)
		{
			cout<<ans[i].size()<<" ";
			for(int j=ans[i].size()-1;j>=0;j--) cout<<ans[i][j]<<" ";
			cout<<"\n";
		}
	}
	else for(int i=1;i<=nw;i++) cout<<0<<"\n";
	return 0;
}
