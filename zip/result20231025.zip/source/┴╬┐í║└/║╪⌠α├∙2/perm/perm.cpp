#include<bits/stdc++.h>
using namespace std;
long long ans=1;
int n,t,f[1001000],m,tf=1;
bool v[1001000],vis[1001000];
int mod=998244353,jie[1001000];
int tp[15];
bool cheak()
{
	int nw=1;
	for(int i=2;i<=n;i++) if(tp[i]==f[nw]) nw++;
	if(nw<=m) return false;
	nw=1;
	for(int i=1;i<=n;i++)
	{
		if(tp[i]==f[nw]&&nw<m) {nw++;continue;}
		if(tp[i]>f[nw]) return false;
	}
	return true;
}
void dfs(int nw)
{
	if(nw==n+1)
	{
		if(cheak()) ans++;
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]==false) vis[i]=true,tp[nw]=i,dfs(nw+1),vis[i]=false;
	}
}
int main()
{
	freopen("perm.in","r",stdin);
	freopen("perm.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m),ans=1;
		for(int i=1;i<=n;i++) v[i]=0;
		for(int i=1;i<=m;i++) scanf("%d",&f[i]),v[f[i]]=1;
		for(int i=1;i<m;i++) if(f[i]>f[i+1]) {tf=0;break;}
//		jie[0]=1;
//		for(int i=1;i<=n;i++) jie[i]=jie[i-1]*i;
		if(tf==1)
		{
			for(int i=1;i<=n;i++) 
			{
				if(v[i]==0&&i<=f[m]) ans*=(i-1),ans%=mod;
				else if(v[i]==0&&i>f[m]) ans*=i,ans%=mod;
			}
			printf("%lld\n",ans);
		}
		else if(n<=10)
		{
			ans=0;
			dfs(1);
			printf("%lld\n",ans);
		}
		else printf("0\n");
	}
	return 0;
}
//1
//6 2
//1 4

