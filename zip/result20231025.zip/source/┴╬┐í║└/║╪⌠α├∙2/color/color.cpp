#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c,vis[200200],ans=0,ru[200200],r[200200],temp[3],uu,vv,ww,tf=0,len=0;
vector<int> to[200200];
vector<int> w[200200];
map<int,bool> mp[200200];
void dfs(int u,int last)
{
	if(vis[u]==true) return ;
	vis[u]=1;
	for(int i=0;i<to[u].size();i++)
	{
		int v=to[u][i],ww=w[u][i];
		if(vis[v]==true&&(uu!=u||vv!=v)) continue;
		if(mp[u][ww]==false&&mp[v][ww]==false) ans++;
		mp[v][ww]=mp[u][ww]=true;
		//cout<<"  "<<u<<" "<<v<<" "<<ww<<" "<<ans<<'\n';
		r[u]--,r[v]--;
		dfs(v,ww);
	}
}
void change()
{
	for(int i=0;i<to[a].size();i++) if(to[a][i]==b) w[a][i]=c;
	for(int i=0;i<to[b].size();i++) if(to[b][i]==a) w[b][i]=c;
	return ; 
}
int main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>a>>b>>c,to[a].push_back(b),w[a].push_back(c),to[b].push_back(a),w[b].push_back(c),ru[a]++,ru[b]++;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b>>c,uu=ww=vv=-1;
		change();
		for(int j=0;j<=n;j++) vis[j]=0,r[j]=ru[j],mp[j].clear();
		ans=0,dfs(1,-1);
		for(int j=1;j<=n;j++) if(r[j]>0) temp[++len]=j;
		uu=temp[1],vv=temp[2],tf=1;
		for(int j=0;j<to[uu].size();j++) if(to[uu][j]==vv) {ww=w[uu][j];break;}
		//cout<<uu<<" "<<vv<<" "<<ww<<"\n";
		for(int j=0;j<=n;j++) vis[j]=0,r[j]=ru[j],mp[j].clear();
		ans=0,dfs(1,-1);
		cout<<ans<<"\n";
	}
	return 0;
}
