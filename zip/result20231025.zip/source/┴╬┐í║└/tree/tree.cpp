#include<bits/stdc++.h>
#define int long long 
using namespace std;
namespace IO{
    char buff[1<<21],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<21],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
int n;
int c[200005];
vector<int>to[200005];
int f[200005],g[200005];
void dfs(int x,int fa,int A){
	if(to[x].size()==0){
		g[x]=c[x];
		return;
	}
	int maxn=1e9;
	if(A-c[x]<0)maxn=0;
	for(auto y:to[x]){
		if(y==fa)continue;
		dfs(y,x,c[x]);
		f[x]+=g[y]*c[x]+f[y];
		if(A-c[x]>=0){
			if(g[y]<maxn)maxn=g[y];
		}else{
			if(g[y]>maxn)maxn=g[y];
		}
	}
	if(x!=1){
		g[x]=maxn;
		f[x]-=maxn*c[x];
	}
}
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(int i=2;i<=n;i++){
		int x;
		read(x);
		to[x].push_back(i);
	}
	for(int i=1;i<=n;i++)read(c[i]);
	dfs(1,0,0);
	write(f[1]);
	flush(); 
	return 0;
}/*
4
1 1 2
2 1 3 2
*/ 
