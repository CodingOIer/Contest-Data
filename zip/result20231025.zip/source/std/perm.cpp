#include<bits/stdc++.h>
#define LL long long
#define LLL __int128
#define uint unsigned
#define ldb long double
using namespace std;
int plen,ptop,pstk[40];
char rdc[1<<20],out[1<<20],*rS,*rT;
#define gc() (rS==rT?rT=(rS=rdc)+fread(rdc,1,1<<20,stdin),(rS==rT?EOF:*rS++):*rS++)
#define pc(x) out[plen++]=(x)
#define flush() fwrite(out,1,plen,stdout),plen=0
template<class T=int>inline T read(){
    T x=0;char ch;bool f=1;
    while(!isdigit(ch=gc()))if(ch=='-')f^=1;
    do x=(x<<1)+(x<<3)+(ch^48);while(isdigit(ch=gc()));
    return f?x:-x;
}
inline int read(char*const s){
	char *t=s,ch;
    while(!isgraph(ch=gc()));
	do(*(t++))=ch;while(isgraph(ch=gc()));
	return (*t)='\000',t-s;
}
template<class T=int>inline void write(T x){
	if(plen>=1000000)flush();
	if(!x)return pc('0'),void();
	if(x<0)pc('-'),x=-x;
	for(;x;x/=10)pstk[++ptop]=x%10;
	while(ptop)pc(pstk[ptop--]+'0');
}
inline void write(const char*s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
inline void write(char*const s){
	if(plen>=1000000)flush();
	for(int i=0;(*(s+i))!='\000';pc(*(s+(i++))));
}
typedef pair<int,int> PII;
const int N=1e6+5,Mod=998244353;
int n,m,tr,ans;
int a[N],b[N];
inline void MAIN(){
    n=read(),m=tr=read(),ans=1;
    fill(b+1,b+n+1,0);
	for(int i=1;i<=m;++i)b[a[i]=read()]=1;
	for(int i=1;i<=m;++i)if(a[i]<a[i-1]){tr=i-1;break;}
    for(int i=1,j=1,k=0;i<=n;++i)if(!b[i]){
        if(i<a[1]){ans=0;break;}
        for(;j<tr&&i>a[j+1];++j);
        if(j==tr)++j;
        ans=(LL)ans*(j+(k++))%Mod;
    }
    write(ans),pc('\n');
}
signed main(){
//#define mytest
#ifndef mytest
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
#endif
    for(int T=read();T--;MAIN());
	return flush(),0;
}
/*

*/