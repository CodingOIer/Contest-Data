#include<bits/stdc++.h>
#define int long long 
using namespace std;
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(int x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)
        write(x/10);
    putchar(x%10+'0');
    return;
}
const int MAXN=2e5+10; 
int n,c[MAXN];
vector<int>to[MAXN];
int f[MAXN],g[MAXN];
void dfs(int x,int fa,int A)
{
	if(to[x].size()==0)
	{
		g[x]=c[x];
		return;
	}
	int maxn=1e9;
	if(A-c[x]<0)
		maxn=0;
	for(auto y:to[x])
	{
		if(y==fa)
			continue;
		dfs(y,x,c[x]);
		f[x]+=g[y]*c[x]+f[y];
		if(A-c[x]>=0)
		{
			if(g[y]<maxn)
				maxn=g[y];
		}
		else
		{
			if(g[y]>maxn)
				maxn=g[y];
		}
	}
	if(x!=1)
	{
		g[x]=maxn;
		f[x]-=maxn*c[x];
	}
}
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read();
	for(int i=2;i<=n;i++)
	{
		int x;
		x=read();
		to[x].push_back(i);
	}
	for(int i=1;i<=n;i++)
		c[i]=read();
	dfs(1,0,0);
	write(f[1]);
	putchar('\n');
	return 0;
}
