#include<bits/stdc++.h>
using namespace std;

const int MAXN=1e5+5,MOD=998244353;
int T,n,m;
int a[MAXN],ans;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}
void write(int x)
{
    if(x<0)
        putchar('-'),x=-x;
    if(x>9)
        write(x/10);
    putchar(x%10+'0');
    return;
}

signed main()
{
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
    while(T--)
    {
        ans=1;
        n=read(),m=read();
        for(int i=1;i<=m;i++)
            a[i]=read();
        if(a[1]!=1)
        {
            puts("0");
            return 0;
        }
        for(int i=2,dq=2;i<=n;i++)
        {
            if(a[dq]==i)
            {
                dq++;
                continue;
            }
            ans=1ll*ans*(i-(dq<=m))%MOD;
        }
        write(ans);
        putchar('\n');
    }
    return 0;
}
