#include<bits/stdc++.h>
//#define int long long
using namespace std;

namespace IOR
{
	char ib[1<<22],ob[1<<20],*p1=ib,*p2=ib,*po=ob;
	void flush(){fwrite(ob,sizeof(char),po-ob,stdout);po=ob;}struct OC{~OC(){flush();};}Oc;
	char gc(){return p1==p2&&(p2=(p1=ib)+fread(ib,sizeof(char),sizeof(ib),stdin),p1==p2)?EOF:*p1++;}
	void pc(const char c){*po++=c;if(po-ob==sizeof(ob))flush();}
	void pt(const char *s){while(*s!='\0'){pc(*s);s++;}pc('\n');}
}
#define getchar IOR::gc
#define putchar IOR::pc
#define puts IOR::pt
namespace fastio
{
	struct{template<typename T>operator T()
	{
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0)
	{
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;

signed main()
{
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
	int n;
	n=in;
	out(n/2*((n+1)/2),'\n');
	for(int i=1;i<=n/2*((n+1)/2);++i)puts("0");
	return 0;
}
