#include<bits/stdc++.h>
// #define int long long
using namespace std;

const int MAXN=2e5+10;
int n,m;
bool vis[MAXN];
int du[MAXN],sum[MAXN];
map<int,int>tu[MAXN];
vector<int>g[MAXN];
map<pair<int,int>,int>node;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}

void write(int x)
{
    if(x<0)
    {
        putchar('-');
        x=-x;
    }
    if(x>9)
        write(x/10);
    putchar(x%10+'0');
    return;
}
void add()
{
	queue<int>q;
	for(int i=1;i<=n;i++)
	{
		if(du[i]==1)
		{
			q.push(i);
		}
	}
	while(q.size())
	{
		int u=q.front();
		vis[u]=true;
		q.pop();
		for(int i=0;i<g[u].size();i++)
		{
			int v=g[u][i];
			du[v]--;
			if(du[v]==1)
			{
				q.push(v);
			}
		}
	}
}

signed main()
{
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	{
		int u,v,c;
		u=read(),v=read(),c=read();
		if(u>v)
		{
			swap(u,v);
		}
		node[{u,v}]=c;
		tu[u][c]++;
		tu[v][c]++;
		g[u].push_back(v);
		g[v].push_back(u);
		du[u]++;
		du[v]++;
	}
	
	add();
	
	int bj=0;
	for(int i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			bj++;
		}
	}
	
	int End=0;
	for(auto i:node)
	{
		if(!vis[i.first.first]&&!vis[i.first.second])
		{
			sum[i.second]++;
			End=i.second;
		}
	}
	
	int ans=n;
	for(int i=1;i<=n;i++)
	{
		for(auto j:tu[i])
		{
			ans-=max(0,j.second-1);
		}
	}
	
	while(m--)
	{
		int u,v,c;
		u=read(),v=read(),c=read();
		if(u>v)
		{
			swap(u,v);
		}
		int lc=node[{u,v}];
		node[{u,v}]=c;
		if(tu[u][lc]>1)
		{
			ans++;
		}
		if(tu[v][lc]>1)
		{
			ans++;
		}
		tu[u][lc]--;
		tu[v][lc]--;
		tu[u][c]++;
		tu[v][c]++;
		if(tu[u][c]>1)
		{
			ans--;
		}
		if(tu[v][c]>1)
		{
			ans--;
		}
		if(!vis[u]&&!vis[v])
		{
			sum[lc]--;
			sum[c]++;
			End=c;
		}
		write(ans-(sum[End]==bj));
		putchar('\n');
	}
	return 0;
}
