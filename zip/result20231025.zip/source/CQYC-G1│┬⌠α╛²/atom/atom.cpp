#include <bits/stdc++.h>
using namespace std;
int n;
int main(){
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    cin>>n;
    if(n==1){
        cout<<"0\n";
        return 0;
    }
    if(n==2){
        cout<<"1\n1 1";
        return 0;
    }
    if(n==3){
        cout<<"2\n2 1 1\n1 2\n";
        return 0;
    }
    if(n==4){
        cout<<"4\n3 1 1 1\n2 2 1\n2 1 2\n1 3\n";
        return 0;
    }
    if(n==5){
        cout<<"6\n1 4\n2 1 3\n2 3 1\n2 2 2\n3 1 2 1\n4 1 1 1 1\n";
        return 0;
    }
    if(n==6){
        cout<<"9\n1 5\n2 1 4\n2 4 1\n2 3 2\n2 2 3\n3 1 3 1\n4 1 2 2 1\n3 2 2 2\n5 1 1 1 1 1\n";
        return 0;
    }
    if(n==7){
        cout<<"12\n1 6\n2 1 5\n2 5 1\n2 4 2\n3 1 4 1\n2 2 4\n2 3 3\n4 1 3 1 1\n4 1 1 3 1\n4 1 2 2 1\n3 2 2 2\n6 1 1 1 1 1 1\n";
        return 0;
    }
    if(n==8){
        cout<<"15\n1 7\n2 1 6\n2 6 1\n2 2 5\n2 5 2\n3 1 5 1\n2 3 4\n2 4 3\n3 1 4 2\n3 2 4 1\n3 2 3 2\n3 1 3 2 1\n3 1 2 3 1\n6 1 1 2 1 1 1\n6 1 1 1 2 1 1\n";
        return 0;
    }
    if(n==9){
        cout<<"19\n1 8\n2 1 7\n2 7 1\n3 1 6 1\n2 2 6\n2 6 2\n2 3 5\n2 5 3\n3 1 5 2\n3 2 5 1\n2 4 4\n3 3 4 1\n3 1 4 3\n3 2 4 2\n4 1 3 2 1\n4 1 2 3 1\n6 1 1 2 2 1 1\n7 1 1 1 2 1 1 1\n8 1 1 1 1 1 1 1 1";
        return 0;
    }
    if(n==10){
        cout<<"25\n1 9\n2 1 8\n2 8 1\n2 7 2\n2 2 7\n3 1 7 1\n2 3 6\n2 6 3\n3 1 6 1 1\n4 1 1 6 1\n3 1 3 5\n3 5 3 1\n4 1 2 5 1\n4 1 5 2 1\n3 2 5 2\n3 1 4 4\n3 4 4 1\n3 2 4 3\n3 3 4 2\n4 2 3 2 2\n 4 2 2 3 2\n3 3 3 3\n3 4 2 3\n3 3 2 4\n9 1 1 1 1 1 1 1 1 1";
        return 0;
    }
    return 0;
}