#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2e5+5,mod=1e9+7;
int n,m,cnt[N],ans,has,h[N];
struct edge{
    int to,v;
}fa[N];
vector<edge> g[N];
map<int,int> t[N];
map<pair<int,int> ,int> bj;
int vis[N];
struct ee{
    int x,y,z;
}b;
int checkb(){
    int res=0,res1=0;
    if(t[b.x][b.z]||fa[b.x].v==b.z) res++;
    if(t[b.y][b.z]||fa[b.y].v==b.z) res1++;
    if(res&&res1){
        if(has==h[b.z]||has==0) return 0;
        return -1;
    }
    else if(res||res1) return 0;
    else return 1;
}
int check(int x){
    int res=0;
    res+=cnt[x];
    if(t[x][fa[x].v]) res--;
    return res;
}
void dfs(int x){
    vis[x]=1;
    for(auto y:g[x]){
        if(y.to==fa[x].to) continue;
        if(vis[y.to]){
            b={x,y.to,y.v};
            continue;
        }
        fa[y.to]={x,y.v};
        if(!t[x][y.v]) cnt[x]++;
        t[x][y.v]++;
        dfs(y.to);
    }
    ans+=check(x);
}
int rd(){
    return ((int)RAND_MAX*RAND_MAX*RAND_MAX*rand()+
           (int)RAND_MAX*RAND_MAX*rand()+
           (int)RAND_MAX*rand()+
           (int)rand()+mod)%mod+mod;
}
int main(){
    srand(19920725);
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++){
        int x=read(),y=read(),z=read();
        if(!h[z]) h[z]=rd();
        g[x].push_back({y,z});
        g[y].push_back({x,z});
    }
    dfs(1);
    int x=b.y;
    while(x!=b.x){
        // cout<<fa[x].v<<"!\n";
        has^=h[fa[x].v],bj[{x,fa[x].to}]=fa[x].v,x=fa[x].to;
    }
    ans+=checkb();
    // for(int i=1;i<=n;i++) cout<<fa[i].to<<" ";
    for(int i=1;i<=m;i++){
        ans-=checkb();
        int x=read(),y=read(),z=read();
        if(fa[y].to==x) swap(x,y);
        if(!h[z]) h[z]=rd();
        if(bj[{x,y}]){
            has^=h[bj[{x,y}]]^h[z];
            // cout<<bj[{x,y}]<<" "<<z<<"!\n";
            bj[{x,y}]=z;
        }
        // cout<<b.x<<" "<<b.y<<" "<<b.z<<" "<<ans<<" "<<has<<endl;
        if(y==fa[x].to) swap(x,y);
        if(x!=fa[y].to) b.z=z;
        else{
            ans-=check(x);
            ans-=check(y);
            ans-=check(fa[x].to);
            t[x][fa[y].v]--;
            if(t[x][fa[y].v]==0) cnt[x]--;
            fa[y].v=z;
            if(t[x][fa[y].v]==0) cnt[x]++;
            t[x][fa[y].v]++;
            ans+=check(x);
            ans+=check(y);
            ans+=check(fa[x].to);
        }
        ans+=checkb();
        cout<<ans<<"\n";
    }
    return 0;
}