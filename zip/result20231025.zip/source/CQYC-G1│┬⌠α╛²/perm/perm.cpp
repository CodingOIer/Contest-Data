#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=1e5+5,mod=998244353;
int T,n,m,a[N],ans,t[N];
void solve(){
    ans=1;
    n=read(),m=read();
    for(int i=1;i<=n;i++) t[i]=0;
    for(int i=1;i<=m;i++) a[i]=read(),t[a[i]]++;
    int l=1;
    while(!t[l]) ans=1ll*ans*l%mod;
    l++;
    for(int i=l,x=1;i<=n;i++){
        while(x<=m&&i>=a[x]) x++;
        if(t[i]) continue;
        ans=1ll*ans*(i-(x<=m))%mod;
    }
    cout<<ans;
}
int main(){
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
    while(T--) solve();
    return 0;
}