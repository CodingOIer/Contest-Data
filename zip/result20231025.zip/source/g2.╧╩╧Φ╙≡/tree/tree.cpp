#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e5+10;
int n,a[N];
long long dp[N],To[N],del[N],tot[N];
vector<int>edge[N];
multiset<ll>s[N];
multiset<ll>::iterator it;
inline void Min(ll &x,ll y) {x=x>y?y:x;}
ll Find(int x,ll sum,int k)
{
    ll res=1ll*a[x]*k+sum+tot[x],c;
    for(int v:edge[x])
    {
        it=s[x].find(To[v]);
        s[x].erase(it);
        if(s[x].empty()) c=0;
        else c=*s[x].begin();
        Min(res,Find(v,sum+tot[x]-dp[v]+c,k));
        s[x].insert(To[v]);
    }
    return res;
}
void dfs(int x)
{
    for(int v:edge[x])
        dfs(v),tot[x]+=dp[v];
    dp[x]=1e18;
    if(edge[x].empty()) dp[x]=0;
    for(int v:edge[x])
    {
        To[v]=Find(v,0,a[x])-dp[v];
        Min(dp[x],tot[x]+To[v]);
        s[x].insert(To[v]);
    }
}
int main()
{
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    scanf("%d",&n);
    for(int i=2,x;i<=n;i++)
        scanf("%d",&x),edge[x].push_back(i);
    for(int i=1;i<=n;i++) scanf("%d",a+i);
    dfs(1);
    printf("%lld\n",dp[1]);
    fclose(stdin);fclose(stdout);
    return 0;
}
