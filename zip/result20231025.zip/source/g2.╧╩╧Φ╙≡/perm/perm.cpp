#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=1e6+10,mod=998244353;
int T,n,m,ans,a[N],b[N],c[N],Mn[N];
bool vis[N],biao[N];
inline void Max(int &x,int y) {x=x>y?x:y;}
inline void Min(int &x,int y) {x=x>y?y:x;}
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
void check()
{
    int T=0;
    for(int i=1;i<=n;i++)
        if(biao[b[i]]) c[++T]=b[i];
    for(int i=1;i<=T;i++)
        if(a[i]!=c[i]) return;
    for(int i=1,Mn;i<=n;i++)
    {
        T=i;Mn=n;
        while(!biao[b[T]]) Min(Mn,b[T++]);
        if(Mn<min(b[i-1],b[T])) return;
        i=T;
    }
    for(int i=1;i<=n;i++)
        cout<<b[i]<<" \n"[i==n];
    ++ans;
}
void dfs(int x)
{
    if(x>n) return check();
    for(int i=1;i<=n;i++)
        if(!vis[i]) vis[b[x]=i]=1,dfs(x+1),vis[i]=0;
}
int main()
{
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
L:  while(T--)
    {
        n=read(),m=read();
        for(int i=1;i<=m;i++)
            a[i]=read(),biao[a[i]]=1;
        ans=a[n+1]=0;b[0]=b[n+1]=n+1;biao[n+1]=1;
        dfs(1);
        biao[n+1]=0;
        for(int i=1;i<=m;i++) biao[a[i]]=0;
        printf("%d\n",ans);
        return 0;
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
