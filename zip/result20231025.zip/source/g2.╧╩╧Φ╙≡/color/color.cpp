#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10,M=N<<1;
int n,m,T,ans,in[N];
int first[N],to[M],nxt[M],lth[M],cnt;
bool flag;
queue<int>q;
map<int,int>loop,a[N],col[N];
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
void topu()
{
    for(int i=1;i<=n;i++)
        if(in[i]==1) q.push(i);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();in[x]=0;
        for(int i=first[x],v;i;i=nxt[i])
            if(!--in[v=to[i]]) q.push(v);
    }
    for(int i=1;i<=n;i++) if(in[i]) ++T;
}
void solve(int u,int v,int w)
{
    int x;
    if(!in[u]||!in[v])
    {
        x=col[u][v];
        --a[u][x],--a[v][x];
        if(a[u][x]&&a[v][x]) ++ans;
        else if(!a[u][x]&&!a[v][x]) --ans;
        col[u][v]=col[v][u]=w;
        if(a[u][w]&&a[v][w]) --ans;
        else if(!a[u][w]&&!a[v][w]) ++ans;
        ++a[u][w],++a[v][w];
    }
    else
    {
        x=col[u][v];
        --a[u][x],--a[v][x];
        --loop[x];
        if(!flag)
        {
            if(a[u][x]&&a[v][x]) ++ans;
            else if(!a[u][x]&&!a[v][x]) --ans;
        }
        else flag=0;
        col[u][v]=col[v][u]=w;
        if((++loop[w])==T) flag=1;
        if(!flag)
            if(a[u][w]&&a[v][w]) --ans;
            else if(!a[u][w]&&!a[v][w]) ++ans;
        ++a[u][w],++a[v][w];
    }
}
int main()
{
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    scanf("%d%d",&n,&m);
    int u,v,w;
    for(int i=1;i<=n;i++)
        scanf("%d%d%d",&u,&v,&w),
        ++in[u],++in[v],++a[u][0],++a[v][0],
        inc(u,v,w),inc(v,u,w);
    topu();
    ans=1;
    flag=1,loop[0]=T;
    for(int i=1;i<=n;i++)
        for(int j=first[i];j;j=nxt[j])
            if(i<to[j]) solve(i,to[j],lth[j]);
    while(m--)
    {
        scanf("%d%d%d",&u,&v,&w);
        solve(u,v,w);
        printf("%d\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
