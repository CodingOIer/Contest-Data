#include<bits/stdc++.h>
using namespace std;
int stk[10],tp;
inline void write(int x)
{
    if(!x) return putchar('0'),void();
    tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) putchar(stk[tp--]^48);
}
int n,ans;
int main()
{
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        for(int j=n;j>i&&j>n-i;j--) ++ans;
    write(ans),putchar('\n');
    for(int i=1;i<=n;i++)
        for(int j=n;j>i&&j>n-i;j--)
        {
            int T=j;
            write((j-1)/i+(j!=n));
            if(j!=n) putchar(' '),write(n-j);
            for(int k=(j-1)/i;k;k--) putchar(' '),write(i);
            putchar('\n');
        }
    fclose(stdin);fclose(stdout);
    return 0;
}