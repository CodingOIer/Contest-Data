#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int N,M,A[Maxn],T,Ans,B[Maxn],Pos[Maxn];
bool Vis[Maxn];

bool check(){
    int lst=1;
    For(i,1,M){
        if(Pos[i]<Pos[i-1]) return 0;
        For(j,lst,Pos[i]-1)
            if(B[j]<A[i]||B[j]<A[i-1]) return 0;
        lst=Pos[i]+1;
    }
    For(i,2,M){
        int pp=0;
        For(j,1,i-1) if(A[i]<A[j]) {pp=j; break;}
        if(!pp) continue;
        if((N-Pos[i]-(M-i))>=(i-pp)) return 0;
    }
    return 1;
}

void DFS(int x){
    if(x>N){
        if(check()) ++Ans;
        return;
    }
    For(i,1,N) if(!Vis[i]){
        Vis[i]=1,B[x]=i,Pos[i]=x;
        DFS(x+1);
        Vis[i]=0;
    }
}

void Solve(){
    N=read(),M=read(),Ans=0;
    For(i,1,M) A[i]=read(),Vis[A[i]]=1;
    DFS(1);
    write(Ans),pc('\n');
    For(i,1,N) Vis[i]=0;
}

int main(){
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
    while(T--) Solve();
    return 0;
}
/*
g++ perm.cpp -o perm -O2
*/