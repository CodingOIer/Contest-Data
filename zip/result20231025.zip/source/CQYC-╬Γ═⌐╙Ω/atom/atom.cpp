#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int N,K;
pair<int,int> T[Maxn];

int main(){
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    N=read();
    For(i,1,N-1) For(j,0,min(i-1,N-1-i)) T[++K]=mp(i,j);
    write(K),pc('\n');
    For(i,1,K){
        int s=T[i].second,l=T[i].first;
        int f=(s!=0);
        write((N-s-1)/l+f),pc(' ');
        if(s) write(s),pc(' ');
        int res=N-1-s;
        while(res>=l) write(l),pc(' '),res-=l;
        pc('\n');
    }
    return 0;
}