#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10;
int N,M,Num,fa[Maxn];
map<pair<int,int>,int> Col;
vector<int> E[Maxn];
struct Line{int u,v,c;}L[Maxn];

int find(int x){return fa[x]=(fa[x]==x?x:find(fa[x]));}
bool cmp(int x,int y){return L[x].c<=L[y].c;}

int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    N=read(),M=read();
    For(i,1,N){
        int u=read(),v=read(),w=read();
        E[u].pb(i),E[v].pb(i);
        L[i]=(Line){u,v,w};
        Col[mp(u,v)]=Col[mp(v,u)]=i;
    }
    For(i,1,N) sort(E[i].begin(),E[i].end(),cmp);
    while(M--){
        int u=read(),v=read(),w=read();
        int id=Col[mp(u,v)];
        L[id].c=w;
        Num=0; For(i,1,N) fa[i]=i;
        For(i,1,N){
            For(j,1,(int)E[i].size()-1){
                int x=E[i][j],y=E[i][j-1];
                if(L[x].c!=L[y].c) continue;
                int fx=find(x),fy=find(y);
                if(fx!=fy) fa[fx]=fy;
            }
        }
        For(i,1,N) if(find(i)==i) ++Num;
        write(Num),pc('\n');
    }
    return 0;
}
/*
g++ color.cpp -o color -O2
./color
4 3
4 2 4
2 3 3
3 4 2
1 4 1
3 4 2
2 3 4
3 4 3
*/