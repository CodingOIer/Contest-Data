#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 2010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,now[N];
vector<vector<int>> V;
vector<int> tmp;
bool pppp;
signed main(){
	freopen("atom.in","r",stdin);
	freopen("atom.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i) now[i]=i-1;
    for(int i=1;;++i){
        tmp.clear();
        tmp.pk(n);
        for(int j=n;j;){
            if(!now[j]) --j;
            else{
                if(tmp.back()!=j) tmp.pk(j);
                tmp.pk(now[j]);--now[j];j=now[j]+1;
            }
        }
        if((int)tmp.size()==1) break;
        V.pk(tmp);
    }
    write(V.size());putchar('\n');
    for(auto x:V){
        write(x.size()-1);putchar(' ');
        int lst=n;
        for(int i=1;i<(int)x.size();++i){
            write(lst-x[i]);putchar(' ');lst=x[i];
        }
        putchar('\n');
    }
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}