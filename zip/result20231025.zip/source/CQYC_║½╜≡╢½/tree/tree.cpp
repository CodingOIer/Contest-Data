#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N],to[N],w[N],t;
il void add1(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;
}
vector<int> e[N];
il void add2(int u,int v){
	e[u].pk(v);
}
// struct SEG{
//     #define ls (w<<1)
//     #define rs (w<<1|1)
//     pii mn[N<<2];
//     il void push_up(int w){
//         mn[w]=min(mn[ls],mn[rs]);
//     }
//     il void update(int w,int l,int r,int x,int k){
//         if(l==r){
//             mn[w]=pii(k,x);return;
//         }
//         int mid=(l+r)>>1;
//         if(x<=mid) update(ls,l,mid,x,k);
//         else update(rs,mid+1,r,x,k);
//         push_up(w);
//     }
//     il pii query(int w,int l,int r,int L,int R){
//         if(L>r||R<l) return pii(inf,0);
//         if(L<=l&&R>=r) return mn[w];
//         int mid=(l+r)>>1;
//         return 
//     }
// } ST;
int n,c[N],dp[2010][2010],g[N],d[N],tot;
il void dfs1(int x){
	if(!head[x]){
		dp[x][lower_bound(d+1,d+1+tot,c[x])-d]=0;return;
	}
	int sum=0;
	for(int i=head[x];i;i=nxt[i]){
		dfs1(to[i]);
		g[to[i]]=inf;
		for(int j=1;j<=tot;++j) g[to[i]]=min(g[to[i]],dp[to[i]][j]+c[x]*d[j]);
		sum+=g[to[i]];
	}
	for(int i=head[x];i;i=nxt[i])
		for(int j=1;j<=tot;++j) dp[x][j]=min(dp[x][j],sum-g[to[i]]+dp[to[i]][j]);
}
il void solve1(){
    write(c[1]*c[n]);
}
il void solve2(){
	for(int i=1;i<=n;++i) d[i]=c[i];
	sort(d+1,d+1+n);
	tot=unique(d+1,d+1+n)-d-1;
	memset(dp,0x3f,sizeof(dp));
    dfs1(1);
	int ans=inf;
	for(int i=1;i<=tot;++i) ans=min(ans,dp[1][i]+c[1]*d[i]);
	write(ans);
}
bool pppp;
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
    n=read();
    int flag=1;
    for(int i=2;i<=n;++i){
        int x=read();
        if(x!=i-1) flag=0;
        add1(x,i);
    }
    for(int i=1;i<=n;++i) c[i]=read();
    if(flag) solve1();
    else solve2();
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}