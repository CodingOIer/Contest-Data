#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 400010
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,m,f[N],dep[N];
struct edge{
    int u,v,c;
} e[N];
map<pii,pii> mp;
map<int,int> col[N];
vector<pii> _op[100],op_[100];
vector<int> V[N<<2],op[100];
#define ls (w<<1)
#define rs (w<<1|1)
// int cnt=0;
il void Modify(int w,int l,int r,int L,int R,int k){
    if(L>r||R<l) return;
    if(L<=l&&R>=r){
        // ++cnt;
        V[w].pk(k);return;
    }
    int mid=(l+r)>>1;
    Modify(ls,l,mid,L,R,k);Modify(rs,mid+1,r,L,R,k);
}
// int MX;
il int merge(int w,int u,int v){
    // return 0;
    // int cnt=0;
    while(f[u]!=u){
        f[u]=u;
        // ++cnt;
    }
    // MX=max(MX,cnt);
    // cnt=0;
    while(f[v]!=v){
        f[v]=v;
        // ++cnt;
    }
    // MX=max(MX,cnt);
    if(u==v) return 0;
    if(dep[u]<dep[v]) swap(u,v);
    op[w].pk(v);_op[w].pk(pii(u,dep[u]));
    f[v]=u;dep[u]=max(dep[u],dep[v]+1);
    // MX=max(MX,dep[u]);
    return 1;
}
il void Query(int w,int dd,int l,int r,int res){
    for(auto x:V[w]){
        if(col[e[x].u].count(e[x].c)) res-=merge(dd,x,col[e[x].u][e[x].c]);
        else{
            col[e[x].u][e[x].c]=x;op_[dd].pk(pii(e[x].u,e[x].c));
        }
        if(col[e[x].v].count(e[x].c)) res-=merge(dd,x,col[e[x].v][e[x].c]);
        else{
            col[e[x].v][e[x].c]=x;op_[dd].pk(pii(e[x].v,e[x].c));
        }
    }
    // MX=max(MX,(int)col.size());
    if(l!=r){
        int mid=(l+r)>>1;
        Query(ls,dd+1,l,mid,res);Query(rs,dd+1,mid+1,r,res);
    }
    else{
        write(res);putchar('\n');
    }
    for(auto x:op[dd]) f[x]=x;
    for(auto x:op_[dd]) col[x.fi].erase(x.se);
    for(auto x:_op[dd]) dep[x.fi]=x.se;
    op[dd].clear();op_[dd].clear();_op[dd].clear();
}
bool pppp;
signed main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<=n;++i){
        e[i].u=read();e[i].v=read();e[i].c=read();
        mp[pii(e[i].u,e[i].v)]=mp[pii(e[i].v,e[i].u)]=pii(1,i);
    }
    for(int i=1;i<=m;++i){
        e[n+i].u=read();e[n+i].v=read();e[n+i].c=read();
        Modify(1,1,m,mp[pii(e[n+i].u,e[n+i].v)].fi,i-1,mp[pii(e[n+i].u,e[n+i].v)].se);
        mp[pii(e[n+i].u,e[n+i].v)]=mp[pii(e[n+i].v,e[n+i].u)]=pii(i,n+i);
    }
    for(int i=1;i<=n+m;++i) f[i]=i;
    for(int i=1;i<=n;++i) Modify(1,1,m,mp[pii(e[i].u,e[i].v)].fi,m,mp[pii(e[i].u,e[i].v)].se);
    Query(1,0,1,m,n);
    // while(1);
    // cerr<<MX<<"\n";
	cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}