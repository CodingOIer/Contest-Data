/*
    Program: tree.cpp
    Author: 1l6suj7
    DateTime: 2023-10-25 08:09:38
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) ((x) << 1)
#define rc(x) (((x) << 1) ^ 1)
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' '
#define cod(x) cout << (x) << endl

using namespace std;

const int N = 200010;

namespace Gra {
    struct edge { int v, nxt; } E[N];
    int en, hd[N];

    void add(int u, int v) { E[++en] = {v, hd[u]}, hd[u] = en; }
}
using namespace Gra;

int n;
__int128 c[N], f[N], dis[N];

namespace SgTr {
    struct line { int fl, lc, rc; __int128 k, b; } tr[N << 5];
    int rt[N], trn;

    __int128 gety(line le, int x) { return le.k * c[x] + le.b; }

    void mdf(int & now, int l, int r, line v) {
        // co(now), co(l), co(r), cod("");
        if(!now) now = ++trn;
        if(tr[now].fl && gety(v, l) >= gety(tr[now], l) && gety(v, r) >= gety(tr[now], r)) return;
        if(!tr[now].fl || gety(v, l) < gety(tr[now], l) && gety(v, r) < gety(tr[now], r)) return tr[now] = v, void();
        if(l == r) return;
        int mid = l + r >> 1;
        if(gety(v, mid) < gety(tr[now], mid)) swap(tr[now], v);
        if(gety(v, l) < gety(tr[now], l)) mdf(tr[now].lc, l, mid, v);
        else mdf(tr[now].rc, mid + 1, r, v);
    }

    __int128 qry(int now, int l, int r, int p) {
        if(!now) return 1e28;
        if(l == r) return tr[now].fl? gety(tr[now], p) : 1e28;
        int mid = l + r >> 1; __int128 res = tr[now].fl? gety(tr[now], p) : 1e28;
        if(p <= mid) res = min(res, qry(tr[now].lc, l, mid, p));
        else res = min(res, qry(tr[now].rc, mid + 1, r, p));
        return res;
    }

    int mer(int x, int y, int l, int r) {
        if(!x || !y) return x | y;
        int mid = l + r >> 1;
        if(gety(tr[x], mid) > gety(tr[y], mid)) swap(x, y);
        mdf(x, l, r, tr[y]);
        if(l == r) return x;
        tr[x].lc = mer(tr[x].lc, tr[y].lc, l, mid);
        tr[x].rc = mer(tr[x].rc, tr[y].rc, mid + 1, r);
        return x;
    }
}
using namespace SgTr;

__int128 res;
void dfs(int now, int fa, int x) {
    // cod(now);
    res = min(res, c[x] * c[now] - dis[now]);
    for(int i = hd[now]; i; i = E[i].nxt) {
        int v = E[i].v;
        if(v == fa) continue;
        dfs(v, now, x);
    }
}
// res = min { c[u] * c[v] - dis[v] }
// res = c[v] * c[u] - dis[v]

void solve(int now, int fa) {
    // cod(now);
    for(int i = hd[now]; i; i = E[i].nxt) {
        int v = E[i].v;
        if(v == fa) continue;
        solve(v, now);
        // res = 1e28;
        // dfs(v, now, now);
        f[now] += qry(rt[v], 1, n, now) + f[v] + c[now] * c[v] + dis[now];
        // f[now] += res + f[v] + c[now] * c[v] + dis[now];
    }
    mdf(rt[now], 1, n, {1, 0, 0, c[now], -dis[now]});
    for(int i = hd[now]; i; i = E[i].nxt) {
        int v = E[i].v;
        if(v == fa) continue;
        rt[now] = mer(rt[now], rt[v], 1, n);
    }
    // co(now), cod((ll)f[now]);
}

void init(int now, int fa) {
    for(int i = hd[now]; i; i = E[i].nxt) {
        int v = E[i].v;
        if(v == fa) continue;
        dis[v] = dis[now] + c[now] * c[v], init(v, now);
    }
}

#define READ
ll read() {
    ll x = 0;
    char c;
    ll f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

signed main() {
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read();
    int u;
    lp(i, 2, n) u = read(), add(u, i);
    lp(i, 1, n) c[i] = read();
    init(1, 0), solve(1, 0);
    printf("%lld\n", (ll)f[1]);
    return 0;
}
/*
f[i] = min { f[j] + c[i] * c[j] }
*/