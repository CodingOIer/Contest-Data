/*
    Program: color.cpp
    Author: 1l6suj7
    DateTime: 2023-10-25 10:11:50
    Description: 
*/

#include <bits/stdc++.h>
#define ll long long
#define lp(i, j, n) for(int i = j; i <= n; ++i)
#define dlp(i, n, j) for(int i = n; i >= j; --i)
#define mst(n, v) memset(n, v, sizeof(n))
#define mcy(n, v) memcpy(n, v, sizeof(v))
#define INF 1e18
#define MAX4 0x3f3f3f3f
#define MAX8 0x3f3f3f3f3f3f3f3f
#define lc(x) ((x) << 1)
#define rc(x) (((x) << 1) ^ 1)
#define mkp(a, b) make_pair(a, b)
#define pii pair<int, int>
#define pll pair<ll, ll>
#define co(x) cout << (x) << ' '
#define cod(x) cout << (x) << endl

using namespace std;

const int N = 200010;

int n, m, col[N], b[N];

namespace Tr {
    struct edge { int v, c, nxt; } E[N << 1];
    int en, hd[N], p1, p2, pc;

    void add(int u, int v, int c) { E[++en] = {v, c, hd[u]}, hd[u] = en; }

    int fa[N], dfn[N], sz[N], son[N], dep[N], grd[N], dfc;
    bool vis[N];
    void dfs1(int now) {
        sz[now] = 1, vis[now] = 1;
        for(int i = hd[now]; i; i = E[i].nxt) {
            int v = E[i].v;
            if(v == fa[now]) continue;
            if(vis[v]) { p1 = now, p2 = v, pc = E[i].c; continue; }
            fa[v] = now, dep[v] = dep[now] + 1, col[v] = E[i].c, dfs1(v), sz[now] += sz[v];
            if(sz[v] > sz[son[now]]) son[now] = v;
        }
    }
    
    void dfs2(int now, int pre) {
        dfn[now] = ++dfc, grd[now] = pre, b[dfc] = col[now];
        if(son[now]) dfs2(son[now], pre);
        for(int i = hd[now]; i; i = E[i].nxt) {
            int v = E[i].v;
            if(v == fa[now] || v == son[now] || now == p1 && v == p2 || now == p2 && v == p1) continue;
            dfs2(v, v);
        }
    }
}
using namespace Tr;

namespace SgTr {
    struct sgtr { int lcol, rcol, col, cnt; } tr[N << 2];

    void pushup(int x) { tr[x].cnt = tr[lc(x)].cnt + tr[rc(x)].cnt - (tr[lc(x)].rcol == tr[rc(x)].lcol); }

    void pls(int x, int c) { tr[x].col = tr[x].lcol = tr[x].rcol = c, tr[x].cnt = 1; }

    void mdf(int now, int l, int r, int p, int c) {
        if(l == r) return pls(now, c), void();
        int mid = l + r >> 1;
        if(p <= mid) mdf(lc(now), l, mid, p, c);
        else mdf(rc(now), mid + 1, r, p, c);
        pushup(now);
    }

    int qry(int now, int l, int r, int ql, int qr) {
        if(ql <= l && qr >= r) return tr[now].cnt;
        int mid = l + r >> 1, res = 0;
        if(ql <= mid) res += qry(lc(now), l, mid, ql, qr);
        if(qr > mid) res += qry(rc(now), mid + 1, r, ql, qr);
        if(ql <= mid && qr > mid) res -= (tr[lc(now)].rcol == tr[rc(now)].lcol);
        return res;
    }

    bool qry_line(int u, int v) {
        int res = 0;
        while(grd[u] != grd[v]) {
            if(dep[grd[u]] < dep[grd[v]]) swap(u, v);
            res += qry(1, 1, n, dfn[grd[u]], dfn[u]) - (col[grd[u]] == col[fa[grd[u]]]);
            if(res > 1) return false;
            u = fa[grd[u]];
        }
        if(u == v) return res == 1;
        if(dep[u] < dep[v]) swap(u, v);
        res += qry(1, 1, n, dfn[v] + 1, dfn[u]);
        return res == 1;
    }

    void build(int now, int l, int r) {
        if(l == r) return pls(now, b[now]), void();
        int mid = l + r >> 1;
        build(lc(now), l, mid), build(rc(now), mid + 1, r);
        pushup(now);
    }
}
using namespace SgTr;

#define READ
int read() {
    int x = 0;
    char c;
    int f = 1;
    c = getchar();
    while((c < '0' || c > '9') && c != '-') c = getchar();
    if(c == '-') f = -f, c = getchar();
    while(c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}

int f[N];
multiset<int> s[N];

bool vis2[N];
void dfs(int now) {
    int cnt = 0;
    if(now != 1) s[now].insert(col[now]);
    for(int i = hd[now]; i; i = E[i].nxt) {
        int v = E[i].v;
        if(v == fa[now] || now == p1 && v == p2 || now == p2 && v == p1) continue;
        s[now].insert(col[v]);
        dfs(v), f[now] += f[v];
    }
    ++f[now];
    for(auto t : s[now]) {
        if(!vis2[t]) f[now] -= s[now].count(t) - 1, vis2[t] = 1;
    }
    for(auto t : s[now]) vis2[t] = 0;
}

int solve() {
    auto t1 = s[p1].find(pc), t2 = s[p2].find(pc);
    if(t1 == s[p1].end() && t2 == s[p2].end()) return f[1] + 1; 
    if(t1 != s[p1].end() && t2 != s[p2].end()) {
        if(qry_line(p1, p2)) return f[1];
        return f[1] - 1;
    }
    return f[1];
}

void change(int u, int fa, int c, int op) {
    auto t1 = s[u].find(c), t2 = s[fa].find(c);
    if(t1 != s[u].end() && t2 != s[fa].end()) f[1] += op;
    else if(t1 == s[u].end() && t2 == s[fa].end()) f[1] -= op;
}

signed main() {
    freopen("color.in", "r", stdin);
    freopen("color.out", "w", stdout);
    #ifndef READ
        ios::sync_with_stdio(false);
        cin.tie(0);
    #endif
    n = read(), m = read();
    int u, v, c;
    lp(i, 1, n) u = read(), v = read(), c = read(), add(u, v, c), add(v, u, c);
    dfs1(1), dfs2(1, 1), build(1, 1, n), dfs(1);
    // co(p1), cod(p2);
    --f[1];
    lp(i, 1, m) {
        u = read(), v = read(), c = read();
        if(u == p1 && v == p2 || u == p2 && v == p1) pc = c;
        else {
            if(v != fa[u]) swap(u, v);
            auto t1 = s[u].find(col[u]), t2 = s[v].find(col[u]);
            s[u].erase(t1), s[v].erase(t2);
            change(u, v, col[u], 1);
            change(u, v, c, -1);
            s[u].insert(c), s[v].insert(c);
            mdf(1, 1, n, dfn[u], c);
            col[u] = c;
        }
        printf("%d\n", solve());
    }
    return 0;
}