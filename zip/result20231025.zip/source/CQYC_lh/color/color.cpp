#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=4e5+2,maxm=4e5+2;
int n,m;
int cnt;
int hed[maxn],fa[maxn],vaf[maxn],nxt[maxn],nev[maxn];
bool vis[maxn],is[maxn];
int siz,oc[maxn];
int ans;
vector<int>cir;
map<int,int>num[maxn];
struct node_edge{
    int nxt,to,val;
}G[maxm*2];
struct node_e{
    int u,v,c;
}e[maxm];
void add(int u,int v,int w){
    G[++cnt]=(node_edge){hed[u],v,w};
    hed[u]=cnt;
    return ;
}
void dfs(int x,int whi){
    vis[x]=1;
    for(int i=hed[x],v;i;i=G[i].nxt){
        if(i==(whi^1))continue;
        v=G[i].to;
        if(vis[v]){
            if(!is[x]){
                for(int j=x;j!=v;j=fa[j])is[j]=1,cir.push_back(j);
                is[v]=1,cir.push_back(v);
            }
            continue;
        }
        fa[v]=x;
        dfs(v,i);
    }
    return ;
}
void dfs2(int x,int f){
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==f||is[v])continue;
        dfs2(v,x);
        vaf[v]=G[i].val;
        if(num[v][G[i].val])ans--;
        if(num[x][G[i].val])ans--;
        num[v][G[i].val]++,num[x][G[i].val]++;
    }
    return ;
}
void modify(int u,int v,int c,int nc,int ty){
    if(!ty){
        if(num[u][c]>1)ans++;
        if(num[v][c]>1)ans++;
        num[u][c]--,num[v][c]--;
        if(num[u][nc]>0)ans--;
        if(num[v][nc]>0)ans--;
        num[u][nc]++,num[v][nc]++;
    }
    else {
        if(oc[c]==siz){
            num[u][c]--,num[v][c]--;
            ans++,oc[c]--;
            oc[nc]++;
            if(num[u][nc]>0)ans--;
            if(num[v][nc]>0)ans--;
            num[u][nc]++,num[v][nc]++;
        }
        else {
            if(num[u][c]>1)ans++;
            if(num[v][c]>1)ans++;
            num[u][c]--,num[v][c]--;
            oc[c]--;
            if(num[u][nc]>0)ans--;
            if(num[v][nc]>0)ans--;
            num[u][nc]++,num[v][nc]++;
            oc[nc]++;
        }
    }
}
int main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read(),m=read();
    cnt=1;
    for(int i=1;i<=n;i++){
        e[i].u=read(),e[i].v=read(),e[i].c=read();
        add(e[i].u,e[i].v,e[i].c);
        add(e[i].v,e[i].u,e[i].c);
    }
    dfs(1,0);
    siz=cir.size();
    ans=n;
    // printf("cir:\n");
    // for(int i=0;i<siz;i++)printf("%d ",cir[i]);
    // printf("\n");
    // printf("fa:\n");
    // for(int i=1;i<=n;i++)printf("%d ",fa[i]);
    // printf("\n");
    // printf("pang\n");
    for(int i=0,x;i<siz;i++)dfs2(cir[i],0);
    for(int i=0,va,x;i<siz;i++){
        x=cir[i],nxt[x]=cir[(i+1)%siz];
        for(int j=hed[x];j;j=G[j].nxt){
            if(G[j].to==nxt[x])nev[x]=G[j].val;
        }
        if(num[x][nev[x]]>0)ans--;
        if(num[nxt[x]][nev[x]]>0)ans--;
        oc[nev[x]]++;
        if(oc[nev[x]]==siz)ans++;
        num[x][nev[x]]++,num[nxt[x]][nev[x]]++;
    }
    int u,v,w;
    for(int i=1;i<=m;i++){
        u=read(),v=read(),w=read();
        if(is[u]&&is[v]){
            if(nxt[v]==u)swap(u,v);
            modify(u,v,nev[u],w,1);
            nev[u]=w;
        }
        else {
            if(fa[u]==v)swap(u,v);
            modify(u,v,vaf[v],w,0);
            vaf[v]=w;
        }
        printf("%d\n",ans);
    }
    return 0;
}