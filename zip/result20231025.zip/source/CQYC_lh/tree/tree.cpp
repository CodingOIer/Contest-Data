#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2;
const long long inf=1e18;
int n;
int fa[maxn],num[maxn],L[maxn];
long long cr[maxn],gx[maxn];
long long ans;
vector<long long>f[maxn];
vector<int>son[maxn],leaf[maxn];
namespace brute1{
    void dfs(int x){
        int siz=son[x].size();
        if(!siz){
            leaf[x].push_back(x),f[x].push_back(0);
            return ;
        }
        long long sum=0;
        for(int i=0,v,now=0;i<siz;i++){
            v=son[x][i];
            dfs(v);
            L[v]=now,gx[v]=inf;
            for(int j=0;j<leaf[v].size();j++)leaf[x].push_back(leaf[v][j]),gx[v]=min(gx[v],f[v][j]+cr[x]*cr[leaf[v][j]]);
            now+=((int)leaf[v].size());
            sum+=gx[v];
        }
        for(int j=0;j<leaf[x].size();j++)f[x].push_back(inf);
        for(int i=0,v;i<siz;i++){
            v=son[x][i];
            for(int j=0;j<leaf[v].size();j++)f[x][L[v]+j]=f[v][j]+sum-gx[v]+f[v][j];
        }
        // for(int j=0;j<leaf[x].size();j++)printf("f[%d][%d]=%lld\n",x,j,f[x][j]);
        return ;
    }
    void solve(){
        dfs(1);
        ans=inf;
        for(int i=0;i<leaf[1].size();i++)ans=min(ans,f[1][i]+cr[1]*cr[leaf[1][i]]);
        printf("%lld\n",ans);
        return ;
    }
}
namespace brute2{
    void solve(){
        printf("%lld\n",cr[1]*cr[n]);
        return ;
    }
}
int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    n=read();
    bool f=1;
    for(int i=2;i<=n;i++)fa[i]=read(),son[fa[i]].push_back(i),f&=(fa[i]==i-1);
    for(int i=1;i<=n;i++)cr[i]=read();
    if(f)brute2::solve();
    else brute1::solve();
    return 0;
}