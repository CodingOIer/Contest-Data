#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int otp,ot[40];
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=2e3+2;
int n;
vector<vector<int>>ans;
bool vis[maxn][maxn];
int main(){
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    n=read();
    vector<int>ve;
    for(int i=2;i<=n;i++){
        for(int y=i;y<=n;y++){
            if(!vis[1+y-i][y]){
                // printf("whi %d %d\n",1+y-i,y);
                ve.clear();
                if(y!=i)ve.push_back(y-i);
                for(int j=0;y+j*(i-1)<=n;j++){
                    vis[1+y-i+j*(i-1)][y+j*(i-1)]=1;
                    ve.push_back(i-1);
                }
                ans.push_back(ve);
            }
        }
    }
    int siz=ans.size();
    write(siz);putchar('\n');
    for(int i=0;i<siz;i++){
        int nsiz=ans[i].size();
        write(nsiz);putchar(' ');
        for(int j=0;j<nsiz;j++){
            write(ans[i][j]);putchar(' ');
        }
        putchar('\n');
    }
    return 0;
}