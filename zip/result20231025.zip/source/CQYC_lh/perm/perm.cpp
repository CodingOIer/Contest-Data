#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int otp,ot[40];
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++otp]=x%10,x/=10;
    while(otp)putchar(ot[otp--]+'0');
    return ;
}
const int maxn=1e6+4;
const int mod=998244353;
int T;
int n,m;
int ar[maxn];
int num[maxn];
int fac[maxn],inv_fac[maxn];
int f_pow(int x,int p){
    int ret=1;
    while(p){
        if(p&1)ret=1ll*ret*x%mod;
        x=1ll*x*x%mod;
        p>>=1;
    }
    return ret;
}
void pre_calc(){
    fac[0]=1;for(int i=1;i<=maxn-1;i++)fac[i]=1ll*fac[i-1]*i%mod;
    inv_fac[maxn-1]=f_pow(fac[maxn-1],mod-2);
    for(int i=maxn-1;i;i--)inv_fac[i-1]=1ll*inv_fac[i]*i%mod;
    return ;
}
int calc_C(int a,int b){
    if(a<0||b<0||a<b)return 0;
    return 1ll*fac[a]*inv_fac[b]%mod*inv_fac[a-b]%mod;
}
int main(){
    freopen("perm.in","r",stdin);
    freopen("perm.out","w",stdout);
    T=read();
    pre_calc();
    while(T--){
        n=read(),m=read();
        for(int i=1;i<=n;i++)num[i]=1;
        int tp=m+1;
        for(int i=1;i<=m;i++){
            ar[i]=read();
            if(i>1&&ar[i]<ar[i-1]&&tp==m+1)tp=i;
        }
        // printf("n=%d m=%d\n",n,m);
        for(int i=tp;i<=m;i++)num[ar[i]]--;
        for(int i=1;i<=n;i++)num[i]+=num[i-1];
        int ans=1,now=1;
        // printf("Num\n");
        // for(int i=1;i<=n;i++)printf("%d ",num[i]);printf("\n");
        if(num[ar[1]]>1){putchar('0'),putchar('\n');continue;}
        for(int i=2,va;i<tp;i++){
            va=num[ar[i]]-num[ar[i-1]]-1;
            ans=1ll*ans*calc_C(now-1+va,va)%mod*fac[va]%mod;
            now=now+va+1;
        }
        int va=num[n]-num[ar[tp-1]];
        ans=1ll*ans*calc_C(now+va,va)%mod*fac[va]%mod;
        // printf("%d\n",ans);
        write(ans);putchar('\n');
    }
    return 0;
}