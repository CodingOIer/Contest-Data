#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
int n,m,cnt[2005];
vector<int> ans[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void write(int x){
    if(!x)
        putchar('0');
    if(x<0)
        putchar('-'),x*=-1;
    int cnt=0;
    char f[1000];
    while(x)
        f[++cnt]=x%10,x/=10;
    while(cnt)
        putchar(f[cnt--]+'0');
    putchar(' ');
}
void solve(int x){
    if(!cnt[x])
        return;
    ++ans[m][0];
    ans[m].push_back(x-cnt[x]);
    solve(cnt[x]);
    --cnt[x];
}
signed main(){
    freopen("atom.in","r",stdin);
    freopen("atom.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        cnt[i]=i-1;
    for(int i=n;i;i--)
        while(cnt[i]){
            ++m;
            ans[m].push_back(0);
            if(i!=n){
                ++ans[m][0];
                ans[m].push_back(n-i);
            }
            solve(i);
        }
    write(m);
    putchar('\n');
    for(int i=1;i<=m;i++){
        printf("%d ",ans[i][0]);
        for(int j=1;j<=ans[i][0];j++)
            write(ans[i][j]);
        putchar('\n');
    }
    return 0;
}