#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,p,c[maxn],va[maxn],sum[maxn],num[maxn],vis[maxn],ans,res;
vector<int> to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
// void f(int u){
//     sum[u]=0;
//     for(auto v:to[u]){
//         f(v);
//         sum[u]+=sum[v]+c[v];
//     }
//     ans+=c[u]*sum[u];
// }
// void dfs(int u,int f,int x,int y){
//     sum[u]=sum[f]+c[u];
//     x+=c[u]*sum[f];
//     for(auto v:to[u]){
//         if(vis[v])
//             continue;
//         dfs(v,u,x,y);
//     }
//     if(!to[u].size())
//         res=max(res,x+c[y]*c[u]);
// }
// void dfs2(int u){
//     if(!vis[u]){
//         res=0;
//         dfs(u,0,0,u);

//         vis[u]=1;
//     }
//     for(auto v:to[u]){
//         if(vis[v])
//             continue;
//         dfs2(v);
//     }
// }
signed main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    n=read();
    int bj=0;
    for(int i=2;i<=n;i++){
        p=read();
        to[p].push_back(i);
        if(p!=i-1)
            bj=1;
    }
    for(int i=1;i<=n;i++)
        c[i]=read();
    if(!bj){
        printf("%lld\n",c[1]*c[n]);
        return 0;
    }
    // f(1);
    // dfs2(1);
    // printf("%lld\n",ans);
    return 0;
}