#include <bits/stdc++.h>
using namespace std;
const int maxn=2e5+5;
int n,m,x,y,c,vis[maxn],fa[maxn],ans,vis2[maxn];
int he[maxn],to[maxn<<1],ne[maxn<<1],va[maxn<<1],tot;
map<int,int> ma[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int x,int y,int c){
    ne[++tot]=he[x],to[tot]=y,he[x]=tot,va[tot]=c;
    ma[x][y]=tot;
    ne[++tot]=he[y],to[tot]=x,he[y]=tot,va[tot]=c;
    ma[y][x]=tot;
}
int find(int x){
    if(fa[x]==x)
        return x;
    return fa[x]=find(fa[x]);
}
void dfs(int u,int x){
    vis[u]=1;
    for(int i=he[u];i;i=ne[i]){
        if(va[x]==va[i]){
            find((x-1)/2+1),find((i-1)/2+1);
            fa[fa[(x-1)/2+1]]=fa[(i-1)/2+1];
        }
        int v=to[i];
        if(vis[v])
            continue;
        dfs(v,i);
    }
}
signed main(){
    freopen("color.in","r",stdin);
    freopen("color.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=n;i++){
        x=read(),y=read(),c=read();
        add(x,y,c);
    }
    for(int i=1;i<=m;i++){
        x=read(),y=read(),c=read();
        int k=ma[x][y];
        va[k]=c,va[k%2?k+1:k-1]=c;
        for(int j=1;j<=n;j++)
            fa[j]=j,vis[j]=0,vis2[j]=0;
        for(int j=1;j<=n;j++)
            if(!vis[j])
                dfs(j,0);
        ans=0;
        for(int j=1;j<=n;j++){
            find(j);
            if(!vis2[fa[j]])
                ++ans,vis2[fa[j]]=1;
        }
        printf("%d\n",ans);
    }
    return 0;
}