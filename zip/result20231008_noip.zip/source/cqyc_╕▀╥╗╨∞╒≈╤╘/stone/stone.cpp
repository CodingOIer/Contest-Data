#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=105,M=4005,mo=1e9+7;
int n,k,dp[N][M],dp2[N][M],h,ans;
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
    scanf("%d%d",&n,&k);
    dp[n+1][0]=1;
    for(int a=n+1;a>=2;a--)
    {
    	for(int b=0;b<=4000;b++)
    	{
    		for(int c=0;c<=k;c++)
    		{
    			if(c>a-1)
    			{
    				dp[a-1][b]=(dp[a-1][b]+dp[a][b])%mo;
    				dp2[a-1][b]=((ll)dp2[a-1][b]+dp2[a][b]+(ll)dp[a][b]*c)%mo;
				}
				else if(b+(b+c)/(a-1)<=4000)
				{
					h=b+(b+c)/(a-1);
					dp[a-1][h]=(dp[a-1][h]+dp[a][b])%mo;
					dp2[a-1][h]=((ll)dp2[a-1][h]+dp2[a][b]+(ll)dp[a][b]*c)%mo;
				}
			}
		}
	}
	for(int a=0;a<=4000;a++) ans=((ll)ans+dp2[1][a]-(ll)dp[1][a]*a%mo+mo)%mo;
	printf("%d",ans);
}
