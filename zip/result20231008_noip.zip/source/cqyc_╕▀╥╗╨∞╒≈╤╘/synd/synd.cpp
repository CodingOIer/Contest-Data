#include<bits/stdc++.h>
#define ll long long
#define i128 __int128
using namespace std;
const int N=2e5+5;
int n,x[N],y[N],mxx,mnx,mxy,mny,A[N],B[N];
ll calc(ll X,ll Y)
{
	ll tot=0;
	for(int a=1;a<=n;a++)
	{
		tot+=abs((X-x[a])*(Y-y[a]));
	}
	return tot;
}
void solve1()
{
	int ansx=-1,ansy=-1;
	ll ans=1e18;
	for(int a=mnx;a<=mxx;a++)
	{
		for(int b=mny;b<=mxy;b++)
		{
			ll h=calc(a,b);
			if(h<ans) ansx=a,ansy=b,ans=h;
		}
	}
	printf("%d %d",ansx,ansy);
}
i128 calc2(i128 X,i128 Y)
{
	i128 tot=0;
	for(int a=1;a<=n;a++)
	{
		if((X-x[a])*(Y-y[a])<0) tot-=(X-x[a])*(Y-y[a]);
		else tot+=(X-x[a])*(Y-y[a]);
	}
	return tot;
}
int main()
{
    freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
	scanf("%d",&n);
	mxx=mxy=-1e9;
	mnx=mny=1e9;
	for(int a=1;a<=n;a++)
	{
		scanf("%d%d",&x[a],&y[a]);
		mxx=max(mxx,x[a]);
		mnx=min(mnx,x[a]);
		mxy=max(mxy,y[a]);
		mny=min(mny,y[a]);
		A[a]=x[a],B[a]=y[a];
	}
	if((ll)(mxx-mnx+1)*(mxy-mny+1)<=5e8&&(ll)(mxx-mnx+1)*(mxy-mny+1)*n<=5e8)
	{
		solve1();
		return 0;
	}
	sort(A+1,A+1+n);
	sort(B+1,B+1+n);
	i128 ans;
	int ansx=A[(n+1)/2],ansy=B[(n+1)/2];
	ans=calc2(ansx,ansy);
	mt19937 rd(time(0));
	for(int a=1;a<=200;a++)
	{
		int h1=rd()%n+1,h2=rd()%n+1;
		i128 hh=calc2(A[h1],B[h2]);
		if(hh<ans) ans=hh,ansx=h1,ansy=h2;
	}
	printf("%d %d",ansx,ansy);
}
