#include<bits/stdc++.h>
#define ll long long
template<typename T> inline T read(T &num)
{
	register T x=0,f=0;
	register char ch=getchar();
	while(ch<48||ch>57) f|=ch=='-',ch=getchar();
	while(48<=ch&&ch<=57) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return num=f?-x:x;
}
using namespace std;
const int N=1e6+5,M=2e6+5,inf=0x3f3f3f3f;
int n,q,e,head[N],to[M],nxt[M],cnt,mn=inf,dep[N],mnv,in[N],out[N],dfn,h[N],fa[N][21],up_mn[N][21];
bool u[N];
void add_edge(int x,int y)
{
	to[++e]=y;
	nxt[e]=head[x];
	head[x]=e;
}
void dfs1(int p,int f)
{
	in[p]=++dfn;
	dep[p]=dep[f]+1;
	fa[p][0]=f;
	up_mn[p][0]=p;
	for(int a=1;a<=20;a++) fa[p][a]=fa[fa[p][a-1]][a-1],up_mn[p][a]=min(up_mn[p][a-1],up_mn[fa[p][a-1]][a-1]);
	for(int a=head[p];a>0;a=nxt[a])
	{
		int s=to[a];
		if(s==f) continue;
		dfs1(s,p);
	}
	out[p]=dfn;
}
struct Tree
{
	int l,r,mx;
}t[4*N+1];
void maketree(int p,int l,int r)
{
	t[p].l=l,t[p].r=r;
	t[p].mx=-1;
	if(l==r) return;
	int mid=(l+r)/2;
	maketree(p*2,l,mid);
	maketree(p*2+1,mid+1,r);
}
void pd(int p,int x)
{
	if(t[p].mx==-1)
	{
		t[p].mx=x;
	}
	else
	{
		if(dep[t[p].mx]<dep[x]) t[p].mx=x;
	}
}
void spread(int p)
{
	if(t[p].mx!=-1)
	{
		pd(p*2,t[p].mx);
		pd(p*2+1,t[p].mx);
	}
}
void Insert(int p,int l,int r,int x)
{
	if(t[p].l>=l&&t[p].r<=r)
	{
		pd(p,x);
		return;
	}
	spread(p);
	int mid=(t[p].l+t[p].r)/2;
	if(l<=mid) Insert(p*2,l,r,x);
	if(r>mid) Insert(p*2+1,l,r,x);
}
int get_mx(int p,int x)
{
	if(t[p].l==t[p].r) return t[p].mx;
	spread(p);
	int mid=(t[p].l+t[p].r)/2;
	if(x<=mid) return get_mx(p*2,x);
	return get_mx(p*2+1,x);
}
void add_v(int x)
{
	if(u[x]==1) return;
	u[x]=1;
	cnt++;
	mn=min(mn,x);
	if(mnv==0||dep[x]<dep[mnv]) mnv=x;
	Insert(1,in[x],out[x],x);
}
int find_v(int x)
{
	if(u[x]==1) return x;
	if(in[x]<=in[mnv]&&out[x]>=in[mnv]) return mnv;
	int h=get_mx(1,in[x]);
	if(h!=-1) return h;
	return mnv;
}
int query_lca(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	int ans=inf;
	for(int a=20;a>=0;a--)
	{
		if(dep[fa[x][a]]>=dep[y]) ans=min(ans,up_mn[x][a]),x=fa[x][a];
	}
	if(x==y)
	{
		return min(y,ans);
	}
	for(int a=20;a>=0;a--)
	{
		if(fa[x][a]!=fa[y][a]) ans=min(ans,min(up_mn[x][a],up_mn[y][a])),x=fa[x][a],y=fa[y][a];
	}
	return min(fa[x][0],ans);
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	read(n),read(q);
	for(int a=1;a<n;a++)
	{
		int x,y;
		read(x),read(y);
	//	x=1,y=a+1;
		add_edge(x,y);
		add_edge(y,x);
	}
	memset(up_mn,0x3f,sizeof(up_mn));
	dfs1(1,0);
	maketree(1,1,n);
	while(q--)
	{
		char op[7];
		int x;
		scanf("%s",op);
		read(x);
	//	op[0]='J';
	//	x=q+1;
		if(op[0]=='J')
		{
			if(cnt==0)
			{
				add_v(x);
				continue;
			}
			int y=find_v(x);
			add_v(x),add_v(y);
			while(x!=y)
			{
				if(dep[x]<dep[y]) swap(x,y);
				x=fa[x][0];
				add_v(x);
			}
		}
		else
		{
			
			printf("%d\n",min(mn,query_lca(x,find_v(x))));
		}
	}
}
