#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=5005,M=1e5+5,mo=998244353;
int n,m,A[M],dp[N][N],ans,pre[N][N],pre2[N],cnt[N],ny[M];
int mod(int a)
{
	if(a>=mo) a-=mo;
	return a;
}
int ksm(int a,int b,int c)
{
	int ans=1;
	while(b>0)
	{
		if(b%2==1) ans=(ll)ans*a%c;
		a=(ll)a*a%c;
		b/=2;
	}
	return ans;
}
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int a=1;a<=m;a++) scanf("%d",&A[a]),cnt[A[a]]++;
	for(int a=1;a<=m;a++)
	{
		ny[a]=ksm(a,mo-2,mo);
	}
    dp[0][0]=pre[0][0]=pre2[0]=1;
    for(int a=1;a<=n;a++)
    {
    	pre2[a]=pre2[a-1];
    	for(int b=0;b<=n;b++)
    	{
    		if(a-b-1>=0) dp[a][b]=((ll)mod(pre2[a-1]-(ll)pre[a-1][b]*ny[cnt[b]]%mo+mo)-mod(pre2[a-b-1]-(ll)pre[a-b-1][b]*ny[cnt[b]]%mo+mo)+mo)%mo*cnt[b]%mo;
    		else dp[a][b]=(ll)mod(pre2[a-1]-(ll)pre[a-1][b]*ny[cnt[b]]%mo+mo)*cnt[b]%mo;
			pre[a][b]=mod(pre[a-1][b]+dp[a][b]);
			pre2[a]=mod(pre2[a]+dp[a][b]);
		}
	}
	for(int a=1;a<=n;a++) ans=(ans+dp[n][a])%mo;
	printf("%d",ans);
}
