#include<bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=5005,mod=998244353;
int n,m,cnt[N],dp[N][N],ans;
signed main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
    n=read(),m=read();
	for(int i=1;i<=m;i++) cnt[read()]++;
	for(int i=1;i<=n;i++) dp[0][i]=1;
	for(int i=1;i<=n;i++){
        ans=0;
		for(int j=1;j<=n;j++) ans=(ans+(dp[i-1][j]-((i>j)?dp[i-j-1][j]:0)+mod)%mod*cnt[j]%mod)%mod;
		for(int j=1;j<=n;j++) dp[i][j]=(dp[i-1][j]+ans-(dp[i-1][j]-(i>j?dp[i-j-1][j]:0)+mod)%mod*((bool)cnt[j])+mod)%mod;
	}
    cout<<ans<<"\n";
	return 0;
}
