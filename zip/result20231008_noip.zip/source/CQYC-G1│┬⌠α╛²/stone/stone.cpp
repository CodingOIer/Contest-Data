#include <bits/stdc++.h>
using namespace std;
#define int long long
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=105,mod=1e9+7;
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=ans*x%mod;
        x=x*x%mod;
        base>>=1;
    }
    return ans;
}
int n,m,dp[N][N*N],ans;
signed main(){
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=read(),m=read();
    dp[n+1][0]=1;
    for(int i=n+1;i>1;i--){
        for(int j=0;j<=m;j++){
            for(int k=0;k<=n*n;k++){
                if(j>i-1) dp[i-1][k]=(dp[i-1][k]+dp[i][k])%mod;
                else dp[i-1][k+(k+j)/(i-1)]=(dp[i-1][k+(k+j)/(i-1)]+dp[i][k])%mod;
            }
        }
    }
    ans=n*pow(m+1,n-1)%mod*(m*(m+1)/2%mod)%mod;
    // cout<<ans<<"\n";
    for(int i=1;i<=n*n;i++) ans=(ans-i*dp[1][i]%mod+mod)%mod;
    cout<<ans;
    return 0;
}