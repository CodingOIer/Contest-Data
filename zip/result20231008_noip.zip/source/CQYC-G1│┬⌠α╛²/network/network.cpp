#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){
        if(ch=='J') return 1;
        if(ch=='Q') return 2;
        if(ch=='-') f=-1;ch=getchar();
    }
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=1e6+6,K=20;
int n,q,fa[N][K+5],val[N][K+5],ans,now,d[N];
vector<int> g[N];
void dfs1(int x){
    for(auto y:g[x]){
        if(y==fa[x][0]) continue;
        d[y]=d[x]+1;
        fa[y][0]=x;
        val[y][0]=min(y,x);
        dfs1(y);
    }
}
void init(){
    for(int k=1;k<=K;k++){
        for(int i=1;i<=n;i++){
            fa[i][k]=fa[fa[i][k-1]][k-1];
            val[i][k]=min(val[i][k-1],val[fa[i][k-1]][k-1]);
        }
    }
}
pair<int,int> lca(int x,int y){
    if(d[x]<d[y]) swap(x,y);
    int ans=N;
    for(int k=K;~k;k--)
        if(d[fa[x][k]]>=d[y]) ans=min(ans,val[x][k]),x=fa[x][k];
    if(x==y) return {x,ans};
    for(int k=K;~k;k--)
        if(fa[x][k]!=fa[y][k]) ans=min(ans,min(val[x][k],val[y][k])),x=fa[x][k],y=fa[y][k];
    return {fa[x][0],min(ans,val[x][0])};
}
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        g[y].push_back(x);
    }
    memset(val,0x7f,sizeof(val));
    d[1]=1;
    dfs1(1);
    init();
    while(q--){
        int op=read(),x=read();
        if(op==1){
            if(!now) now=x,ans=x;
            else{
                pair<int,int> y=lca(now,x);
                ans=min(ans,y.second);
            }
        }
        else cout<<min(ans,lca(now,x).second)<<"\n";
    }
    return 0;
}