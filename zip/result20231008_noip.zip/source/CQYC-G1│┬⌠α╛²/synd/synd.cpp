#include <bits/stdc++.h>
using namespace std;
const int N=2e5+5;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
int n;
int x[N],y[N],xx,yy,tx[N],ty[N];
long long dis(int x,int y,int x1,int y1){
    return 1ll*abs(x-x1)*abs(y-y1);
}
__int128 solve(int x1,int y1){
    __int128 ans=0;
    for(int i=1;i<=n;i++) ans+=dis(x1,y1,x[i],y[i]);
    return ans;
}
namespace nlog{
    int x1[N],y1[N],m1,m2;
    struct name{
        int v,num;
    }xxx[N],yyy[N];
    bool cmp(name a,name b){
        return a.num>b.num;
    }
    int mian(){
        __int128 ans=1e22;
        int xx,yy;
        int k=sqrt(1.9920725e8/n);
        memcpy(tx,x,sizeof(x));
        memcpy(ty,y,sizeof(y));
        sort(tx+1,tx+n+1);
        sort(ty+1,ty+n+1);
        tx[0]=ty[0]=-1e9;
        int cntx=1,cnty=1;
        for(int i=1;i<=n;i++){
            if(tx[i]!=tx[i-1]){
                x1[++m1]=tx[i];
                xxx[m1]={tx[i-1],cntx};
                cntx=1;
            }
            else cntx++;
            if(ty[i]!=ty[i-1]){
                y1[++m2]=ty[i];
                yyy[m1]={ty[i-1],cnty};
                cnty=1;
            }
            else cnty++;
        }
        for(int i=max(1,m1/2-k/2);i<=m1/2+k/2;i++){
            for(int j=max(1,m2/2-k/2);j<=m2/2+k/2;j++){
                __int128 aa=solve(x1[i],y1[j]);
                if(aa<ans) ans=aa,xx=x1[i],yy=y1[j];
            }
        }
        sort(xxx+1,xxx+m1+1,cmp);
        sort(yyy+1,yyy+m2+1,cmp);
        for(int i=1;i<=k;i++){
            for(int j=1;j<=k;j++){
                __int128 aa=solve(xxx[i].v,yyy[j].v);
                if(aa<ans) ans=aa,xx=x1[i],yy=y1[j];
            }
        }
        cout<<xx<<" "<<yy<<"\n";
        return 0;
    }
}
namespace n3{
    int mian(){
        __int128 ans=1e22;
        int xx,yy;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                __int128 aa=solve(x[i],y[j]);
                if(aa<ans) ans=aa,xx=x[i],yy=y[i];
            }
        }
        cout<<xx<<" "<<yy<<"\n";
        return 0;
    }
}
namespace nv2{
    int mian(int ix,int iy,int ax,int ay){
        __int128 ans=1e22;
        int xx,yy;
        for(int x=ix;x<=ax;x++){
            for(int y=iy;y<=ay;y++){
                __int128 aa=solve(x,y);
                if(aa<ans) ans=aa,xx=x,yy=y;
            }
        }
        cout<<xx<<" "<<yy<<"\n";
        return 0;
    }
}
signed main(){
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    n=read();
    int ix=1e9,iy=1e9,ax=0,ay=0;
    for(int i=1;i<=n;i++){
        x[i]=read(),y[i]=read();
        ix=min(ix,x[i]);
        ax=max(ax,x[i]);
        iy=min(iy,y[i]);
        ay=max(ay,y[i]);
    }
    if(1ll*n*abs(ax-ix)*abs(ay-iy)<=4e8) nv2::mian(ix,iy,ay,ay);
    else if(1ll*n*n*n<=4e8) n3::mian();
    else nlog::mian();
    return 0;
}