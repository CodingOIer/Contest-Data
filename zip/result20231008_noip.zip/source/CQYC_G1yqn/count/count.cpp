#include<bits/stdc++.h>
using namespace std;

const int MOD = 998244353;

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}
void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
int main() {
	freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    int n, m;
    n=read(),m=read();
    vector<int> a(m+1);
    for(int i = 1; i <= m; i++) {
        a[i]=read();
    }

    vector<vector<vector<int>>> dp(n+1, vector<vector<int>>(m+1, vector<int>(101, 0)));

    for(int j = 1; j <= m; j++) {
        dp[1][j][1] = 1;
    }

    for(int i = 1; i < n; i++) {
        for(int j = 1; j <= m; j++) {
            for(int k = 1; k <= a[j]; k++) {
                if(dp[i][j][k]) {
                    if(k+1 <= a[j]) {
                        dp[i+1][j][k+1] += dp[i][j][k];
                        dp[i+1][j][k+1] %= MOD;
                    }
                    for(int p = 1; p <= m; p++) {
                        if(p != j) {
                            dp[i+1][p][1] += dp[i][j][k];
                            dp[i+1][p][1] %= MOD;
                        }
                    }
                }
            }
        }
    }

    int ans = 0;
    for(int j = 1; j <= m; j++) {
        for(int k = 1; k <= a[j]; k++) {
            ans += dp[n][j][k];
            ans %= MOD;
        }
    }

    write(ans);
    putchar('\n');

    return 0;
}

