#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int N=2e5+5,INF=0x3f3f3f3f;
int dx[4]={0,1,0,-1};
int dy[4]={1,0,-1,0};

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}
void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}

struct node
{
    int x;
    int y;
}a[N];
int x[N],y[N];
int minn,plan;
int cnt1=0,cnt2=0;
int X[5],Y[5];
int Xans,Yans;
signed main()
{
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    int n;
    n=read();
    for(int i=1;i<=n;i++)
    {
        a[i].x=read(),a[i].y=read();
        x[i]=a[i].x;
        y[i]=a[i].y;
    }
    sort(x+1,x+n+1);
    sort(y+1,y+n+1);
    if(n%2)
    {
        int temp=(n/2)+1;
        for(int i=1;i<=n;i++)
        {
            if(a[i].x==x[temp]&&a[i].y==y[temp])
            {
                int Min=INF;
                for(int l=0;l<4;l++)
                {
                    int xx=x[temp]+dx[l];
                    int yy=y[temp]+dy[l];
                    int sum=0;
                    for(int i=1;i<=n;i++)
                        sum+=abs(a[i].x-xx)+abs(a[i].y-yy);
                    if(sum<Min)
                    {
                        Min=sum;
                        plan=1;
                    }
                    else if(sum==Min)
                        plan++;
                    // printf("%d %d\n",x[temp]+dx[l],y[temp]+dy[l]);
                    // if(x[temp]+dx[l]==x[temp]+dx[l+1])
                    // cnt1+=x[temp]+dx[l];
                    // if(y[temp]+dy[l]==y[temp]+dy[+1])
                    // cnt2+=y[temp]+dy[l];
                    X[l]=xx,Y[l]=yy;

                    // printf("%d %d\n",xx,yy);
                    
                }
                sort(X,X+4);
                sort(Y,Y+4);
                int XX,YY;
                XX=unique(X,X+4)-X-1;
                YY=unique(Y,Y+4)-Y-1;
                Xans=X[(XX+1)/2];
                Yans=Y[(YY+1)/2];
                write(Xans);
				putchar(' ');
				write(Yans);
				putchar('\n'); 
//                printf("%d %d\n",Xans,Yans);
                // printf("%d %d\n",x[temp]+dx[2],y[temp]+dy[2]);
                // printf("%d %d\n",Min,plan);
                // printf("%d\n",Min);
                return 0;
            }
            else
            {
                minn+=abs(a[i].x-x[temp])+abs(a[i].y-y[temp]);
                plan=1;
            }
        }
        // printf("%d %d\n",minn,plan);
        write(x[temp]);
        putchar(' ');
        write(y[temp]);
        putchar('\n');
//        printf("%d %d\n",x[temp],y[temp]);
//        printf("%d\n",minn);
    }
    else
    {
        int temp1=n/2,temp2=n/2+1;
        plan=(x[temp2]-x[temp1]+1)*(y[temp2]-y[temp1]+1);
        for(int i=1;i<=n;i++)
        {
            minn+=abs(a[i].x-x[temp1])+abs(a[i].y-y[temp1]);
            int x0=a[i].x,y0=a[i].y;
            if(x[temp1]<=x0&&0<=x[temp2]&&y[temp1]<=y0&&y0<=y[temp2])
                plan--;
        }
        // printf("%d %d\n",minn,plan);
        write(x[temp1]);
        putchar(' ');
        write(y[temp1]);
        putchar('\n');
//        printf("%d %d\n",x[temp1],y[temp1]);
        // printf("%d\n",minn);
    }
    return 0;
}
