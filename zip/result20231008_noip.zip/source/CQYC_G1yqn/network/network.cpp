#include<bits/stdc++.h>
using namespace std;

const int maxn = 100005;
vector<int> g[maxn];
bool jc[maxn];
int depth[maxn], parent[maxn][20];

inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0',ch=getchar();}
    return x*f;
}
void write(int x)
{
    if(x<0){putchar('-'),x=-x;}
    if(x>9)write(x/10);
    putchar(x%10+'0');
    return;
}
void dfs(int v, int p) {
    parent[v][0] = p;
    depth[v] = p == 0 ? 0 : depth[p] + 1;
    for (int u : g[v]) {
        if (u != p) {
            dfs(u, v);
        }
    }
}

int LCA(int u, int v) {
    if (depth[u] < depth[v]) swap(u, v);
    int diff = depth[u] - depth[v];

    for (int i = 0; i < 20; ++i) {
        if ((diff >> i) & 1) {
            u = parent[u][i];
        }
    }
    if (u == v) return u;

    for (int i = 19; i >= 0; --i) {
        if (parent[u][i] != parent[v][i]) {
            u = parent[u][i];
            v = parent[v][i];
        }
    }
    return parent[u][0];
}

int main() 
{
	    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);

    int n, q;
    n=read(),q=read();
    for (int i = 1; i < n; ++i) {
        int u, v;
        u=read(),v=read();
        g[u].push_back(v);
        g[v].push_back(u);
    }

    dfs(1, 0);

    for (int i = 1; i < 20; ++i) {
        for (int v = 1; v <= n; ++v) {
            parent[v][i] = parent[parent[v][i - 1]][i - 1];
        }
    }

    vector<int> jc_nodes;
    while (q--) 
	{
        string s;
        int x;
        cin>>s;
        x=read();
        if (s == "JC") {
            jc[x] = true;
            jc_nodes.push_back(x);
        } else {
            int min_diff = x;
            for (int j : jc_nodes) {
                int lca = LCA(j, x);
                min_diff = min(min_diff, lca);
                int tmp = j;
                while (tmp != lca) {
                    min_diff = min(min_diff, tmp);
                    tmp = parent[tmp][0];
                }
                tmp = x;
                while (tmp != lca) {
                    min_diff = min(min_diff, tmp);
                    tmp = parent[tmp][0];
                }
            }
            write(min_diff);
            putchar('\n');
        }
    }
    return 0;
}

