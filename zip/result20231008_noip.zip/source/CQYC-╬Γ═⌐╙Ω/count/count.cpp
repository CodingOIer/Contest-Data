//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,Mod=998244353;
int N,M,A[Maxn],f[510][510][510],Sum,Sol,B[Maxn];

int Power(int x,int d,int r=1){
    while(d){if(d&1) (r*=x)%=Mod; (x*=x)%=Mod,d>>=1;}
    return r;
}

bool check(){
    // For(i,1,N) cout<<B[i]<<" ";puts("");
    For(i,1,N){
        int len=0;
        Rof(j,i,max(i-A[B[i]],1)){
            if(B[j]!=B[i]) break;
            ++len;
        }
        if(len>A[B[i]]) return 0;
    }
    return 1;
}

void DFS(int x){
    if(x>N){
        if(check()) ++Sol;
        return;
    }
    For(i,1,M) B[x]=i,DFS(x+1),B[x]=0;
}

int main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    N=read(),M=read();
    For(i,1,M) A[i]=read();
    DFS(1); write(Sol);
    // For(i,1,M) ++A[i];
    // For(i,1,M) f[0][i][0]=1;
    // For(i,1,N){
    //     For(j,1,M){
    //         For(k,1,A[j]) f[i][j][k]+=f[i-1][j][k-1];
    //         int cur=0;
    //         For(k,1,A[j]-1) cur+=f[i-1][j][k];
    //         f[i][j][0]=Sum-cur;
    //         (Sol+=f[i][j][A[j]]*Power(M,N-i)%Mod)%=Mod;
    //         f[i][j][A[j]]=0;
    //     }
    //     Sum=0;
    //     For(j,1,M) For(k,1,A[j]-1) Sum+=f[i][j][k];
    // }
    // cout<<"Sol="<<Sol<<"\n";
    // write((Power(M,N)-Sol+Mod)%Mod);
    return 0;
}