//2s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e6+10;
int N,Q,hed[Maxn],cnt,fa[Maxn],Siz[Maxn],T[Maxn<<2],Val;
int dfn[Maxn],tot,ID[Maxn],Mn,dep[Maxn],Son[Maxn],top[Maxn];
struct node{int nxt,to;}G[Maxn<<1];
string op;
bool Vis[Maxn];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

void DFS1(int x,int p){
    fa[x]=p,Siz[x]=1,dep[x]=dep[p]+1;
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==p) continue;
        DFS1(y,x),Siz[x]+=Siz[y];
        if(Siz[Son[x]]<Siz[y]) Son[x]=y;
    }
}

void DFS2(int x,int t){
    top[x]=t,dfn[x]=++tot,ID[tot]=x;
    if(!Son[x]) return;
    DFS2(Son[x],t);
    for(int y,i=hed[x];i;i=G[i].nxt){
        if((y=G[i].to)==Son[x]||y==fa[x]) continue;
        DFS2(y,y);
    }
}

void Build(int id,int l,int r){
    if(l==r) return T[id]=ID[l],void();
    Build(ls,l,mid),Build(rs,mid+1,r);
    T[id]=min(T[ls],T[rs]);
}

int Query(int id,int l,int r,int L,int R){
    if(L<=l&&r<=R) return T[id];
    int ret=N+1;
    if(L<=mid) ret=min(ret,Query(ls,l,mid,L,R));
    if(R>mid) ret=min(ret,Query(rs,mid+1,r,L,R));
    return ret;
}

int Get_lca(int x,int y){
    int ret=0;
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        x=fa[top[x]];
    }
    return dep[x]<dep[y]?x:y;
}

void Add(int x){
    if(Vis[x]) return;
    if(!Mn) return Val=x,Vis[x]=1,Mn=x,void();
    int dMn=dfn[Mn];
    if(dMn>dfn[x]&&dMn<=dfn[x]+Siz[x]-1){
        while(Mn!=x) Mn=fa[Mn],Val=min(Val,Mn),Vis[Mn]=1;
    }else{
        int lca=Get_lca(Mn,x);
        while(x!=lca) Val=min(Val,x),Vis[x]=1,x=fa[x];
        while(Mn!=lca) Val=min(Val,Mn),Vis[Mn]=1,Mn=fa[Mn];
    }
}

int Ask(int x,int y){
    int ret=N+1;
    while(top[x]!=top[y]){
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        ret=min(ret,Query(1,1,N,dfn[top[x]],dfn[x]));
        x=fa[top[x]];
    }
    if(dfn[x]>dfn[y]) swap(x,y);
    ret=min(ret,Query(1,1,N,dfn[x],dfn[y]));
    return ret;
}

int Get(int x){
    int ret=Val,dMn=dfn[Mn];
    ret=min(ret,Ask(Mn,x));
    return ret;
}

int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    N=read(),Q=read();
    For(i,1,N-1){
        int u=read(),v=read();
        Addedge(u,v),Addedge(v,u);
    }
    DFS1(1,0); DFS2(1,1); Build(1,1,N);
    while(Q--){
        cin>>op; int x=read();
        if(op=="JC") Add(x);
        else write(Get(x)),pc('\n');
    }
    // cerr<<"[Clock]="<<clock();
    return 0;
}