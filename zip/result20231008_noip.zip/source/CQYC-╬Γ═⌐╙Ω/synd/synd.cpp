//1s 512M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=2e5+10,INF=1e18;
int N,X[Maxn],Y[Maxn],S1,S2,Mx=INF,Ax,Ay;
int Mnx=INF,Mxx,Mny=INF,Mxy;

signed main(){
    freopen("synd.in","r",stdin);
    freopen("synd.ans","w",stdout);
    N=read();
    For(i,1,N){
        X[i]=read(),Y[i]=read();
        Mnx=min(Mnx,X[i]),Mxx=max(Mxx,X[i]);
        Mny=min(Mny,Y[i]),Mxy=max(Mxy,Y[i]);
    }
    if(N<=300){
        For(i,1,N) For(j,1,N){
            int ret=0;
            For(k,1,N) ret+=abs((X[i]-X[k])*(Y[j]-Y[k]));
            if(ret<Mx) Ax=X[i],Ay=Y[j],Mx=ret;
        }
        write(Ax),pc(' '),write(Ay);
        return 0;
    }
    For(i,Mnx,Mxx) For(j,Mny,Mxy){
        int ret=0;
        For(k,1,N) ret+=abs((i-X[k])*(j-Y[k]));
        if(ret<Mx) Ax=i,Ay=j,Mx=ret;
    }
    write(Ax),pc(' '),write(Ay);
    return 0;
} 