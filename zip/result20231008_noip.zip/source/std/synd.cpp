//#include<bits/stdc++.h>
//#define bint __int128
//using namespace std;
//const int maxn=2e5+5;
//int x[maxn],y[maxn],xx[maxn],yy[maxn],n;
//bint calc(double a,double b){
//	bint res=0;
//	for(int i=1;i<=n;i++)res+=fabs((a-x[i])*(b-y[i]));
//	return res;
//}
//double Min(double x){
//	double l=-19260817,r=20080427,eps=1e-2;
//	while(r-l>eps){
//		bint fl=calc(x,l+(r-l)/3),fr=calc(x,r-(r-l)/3);
//		if(fl>fr)l=l+(r-l)/3;
//		else r=r-(r-l)/3;
//	}
//	return calc(x,l);
//} 
//double Min_get(double x){
//	double l=-19260817,r=20080427,eps=1e-2;
//	while(r-l>eps){
//		double mid=(l+r)/2;
//		bint fl=calc(x,l+(r-l)/3),fr=calc(x,r-(r-l)/3);
//		if(fl>fr)l=l+(r-l)/3;
//		else r=r-(r-l)/3;
//	}
//	return l;
//} 
//signed main(){
//	freopen("synd.in","r",stdin);
//	freopen("synd.out","w",stdout);
//	ios::sync_with_stdio(0); 
//	cin.tie(0);
//	cin>>n;
//	for(int i=1;i<=n;i++){
//		cin>>x[i]>>y[i];
//		xx[i]=x[i],yy[i]=y[i];
//	}
//	sort(xx+1,xx+n+1);
//	sort(yy+1,yy+n+1);
//	double l=-19260817,r=20080427,eps=1e-2;
//	while(r-l>eps){
//		double mid=(l+r)/2;
//		bint fl=Min(l+(r-l)/3),fr=Min(r-(r-l)/3);
//		if(fl>fr)l=l+(r-l)/3;
//		else r=r-(r-l)/3;
//	}
//	int L=round(l);int R=round(Min_get(l));
//	cout<<L<<" "<<R<<endl;
//	return 0;
//}
//
////#include<bits/stdc++.h>
////#define ll long long
////using namespace std;
////int n;
////ll x[200010],y[200010],s1[4]={0,0,1,-1},s2[4]={-1,1,0,0};
////ll fun(ll a,ll b){
////	ll ans=0;
////	for(int i=1;i<=n;i++){
////		ans+=abs((a-x[i])*(b-y[i]));
////	}
////	return ans;
////}
////int main(){
////	freopen("synd.in","r",stdin);
////	freopen("synd.out","w",stdout);
////	ll xx=0,yy=0,sum,now,c,d,ff=2e7;
////	int summ=0;
////	scanf("%d",&n);
////	for(int i=1;i<=n;i++){
////		scanf("%lld%lld",&x[i],&y[i]);
////	}
////	now=fun(xx,yy);
////	while(1){
////		int p=0;
////		for(int i=0;i<=3;i++){
////			c=xx+s1[i]*ff;
////			d=yy+s2[i]*ff;
////			sum=fun(c,d);
////			if(sum<now){
////				xx=c;
////				yy=d;
////				now=sum;
////				p=1;
////			}
////		}
////		if(!p&&ff==1){
////			break;
////		}
////		if(!p&&ff>=2){
////			ff/=2;
////		}
////		summ++;
////	}
////	printf("%lld %lld",xx,yy);
////}


#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n;
ll x[200010],y[200010],s1[4]={0,0,1,-1},s2[4]={-1,1,0,0};
ll fun(ll a,ll b){
	ll ans=0;
	for(int i=1;i<=n;i++){
		ans+=abs((a-x[i])*(b-y[i]));
	}
	return ans;
}
int main(){
	freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
	ll xx=0,yy=0,sum,now,c,d,ff=2e7;
	int summ=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld%lld",&x[i],&y[i]);
	}
	now=fun(xx,yy);
	while(1){
		int p=0;
		for(int i=0;i<=3;i++){
			c=xx+s1[i]*ff;
			d=yy+s2[i]*ff;
			sum=fun(c,d);
			if(sum<now){
				xx=c;
				yy=d;
				now=sum;
				p=1;
			}
		}
		if(!p&&ff==1){
			break;
		}
		if(!p&&ff>=2){
			ff/=2;
		}
		summ++;
	}
	printf("%lld %lld",xx,yy);
}
