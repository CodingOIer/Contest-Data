#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e5+5,M=1e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int n,m,dp[505][505][2],a[N],s[N];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	n=read(),m=read();
	rep(i,1,m)a[i]=read()+1;
	int w=1;
	if(n<=500&&m<=500){
		rep(i,1,m)if(a[i]>1)dp[i][1][w]=1;
		rep(i,2,n){
			w^=1;
			int sum=0;
			rep(j,1,m){
				s[j]=0;
				rep(k,1,min(i-1,a[j]-1))(sum+=dp[j][k][w^1])%=mod,(s[j]+=dp[j][k][w^1])%=mod;
			}
			rep(j,1,m){
				if(a[j]>1)dp[j][1][w]=(sum-s[j]+mod)%mod;
				rep(k,2,min(i,a[j]-1))dp[j][k][w]=dp[j][k-1][w^1];
			}
		}
		ll ans=0;
		rep(i,1,m)rep(j,1,a[i]-1)(ans+=dp[i][j][w])%=mod;
		cout <<ans;
		return 0; 
	}
	return 0;
}
