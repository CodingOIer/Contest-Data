#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,n
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =2e5+5,M=1e5+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=1e9+7,bas=131;
const ui base=13331;
using namespace std;
int n,mxx=-inf,mnx=inf,mxy=-inf,mny=inf;
struct node{
	int x,y;
}a[N];
inline ll dis(int x,int y){
	ll ans=0;
	rep(i,1,n)ans+=abs((x-a[i].x)*(y-a[i].y));
	return ans;
}
inline ll ds(int x,int y){
	ll ans=0;
	rep(i,1,n)ans+=abs(1LL*(x-a[i].x)*(y-a[i].y));
	return ans;
}
ll mn=llf;
int ansx,ansy;
const int dx[4]={0,1,0,-1},dy[4]={1,0,-1,0};
int main(){
	freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
	n=read();
	rep(i,1,n)a[i].x=read(),a[i].y=read(),mxx=max(mxx,a[i].x),mnx=min(mnx,a[i].x),mxy=max(mxy,a[i].y),mny=min(mny,a[i].y);
	if(n<=10000&&mxx<=200&&mny>=-200&&mxy<=200&&mny>=-200)rep(i,mnx,mxx)rep(j,mny,mxy){
		ll d=dis(i,j);
		if(d<mn)mn=d,ansx=i,ansy=j;
	}
	else {
		ansx=mxx+mnx>>1,ansy=mxy+mny>>1;
		ll d=ds(ansx,ansy);
		while(clock()*1.0/1000.0<=0.92){
			rep(i,0,3){
				int X=ansx+dx[i],Y=ansy+dy[i];
				ll di=ds(X,Y);
				if(di<d){
					ansx=X,ansy=Y,d=di;
					break;
				}
			}
		}
	}
	pf(ansx),putchar(' '),pf(ansy);
	return 0;
}
