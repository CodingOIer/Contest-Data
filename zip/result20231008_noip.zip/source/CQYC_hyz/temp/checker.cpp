#include<bits/stdc++.h>
#define int __int128 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 2e5 + 10, inf = 1e18;

struct node {
    int x, y;
    bool operator < (const node &p) const { return y < p.y; }
} a[N], b[N];

int n, ans = inf, sx, sy;
int s[N];

int Abs(int x) { return x > 0 ? x : -x; }

void work(int x) {
    int res = 0;
    for(int i = 1; i <= n; i++) s[i] = Abs(a[i].x - x), res += s[i] * (a[i].y - a[1].y), s[i] += s[i - 1];
    if(res < ans) ans = res, sx = x, sy = a[1].y;
    for(int i = 1; i < n; i++) {
        if(s[i] + s[i] > s[n]) break;
        int d = a[i + 1].y - a[i].y;
        res -= (s[n] - s[i] - s[i]) * d;
        if(res < ans) ans = res, sx = x, sy = a[i + 1].y;
    }
}

bool edmer;
signed main() {
	freopen("synd.in", "r", stdin);
	// freopen("synd.out", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) a[i] = { read(), read() };

    sort(a + 1, a + n + 1);

    for(int i = 1; i <= n; i++) ans = inf, work(a[i].x), b[i] = { ans, a[i].x };

    sort(b + 1, b + n + 1);

    // for(int i = 1; i <= n; i++) write(b[i].x), putchar('\n');

    int l = 1, r = n;
    while(l < n and b[l].x >= b[l + 1].x) l++;
    while(r - 1 and b[r].x >= b[r - 1].x) r--;

    if(l >= r) puts("True"); else {
        puts("False");
        while(1);
    }
    // write(sx), putchar(' '), write(sy), putchar('\n');

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 