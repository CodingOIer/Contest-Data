#include<bits/stdc++.h>
using namespace std;
int T = 0;
signed main() {
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 maker.cpp -o maker");
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 bf.cpp -o bf");
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 synd.cpp -o synd");
    system("g++ -O2 -Wall -Wl,--stack=53670912 -std=c++14 checker.cpp -o checker");

	while(++T) {
		system("maker.exe");
		double st = clock();
		system("synd.exe");
		double ed = clock();
		system("bf.exe");
		// system("checker.exe");

		if(system("fc synd.out synd.ans")) {
			puts("Wrong Answer");
			return 0;
		} 
		else printf("Accepted, test #%d, time %0.lfms\n", T, ed - st);

	}
    return 0;
}