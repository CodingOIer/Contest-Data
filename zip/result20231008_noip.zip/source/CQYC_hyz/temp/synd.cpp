#include<bits/stdc++.h>
#define int __int128 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 2e5 + 10, inf = 1e22;

struct node {
    int x, y;
    bool operator < (const node &p) const { return y < p.y; }
} a[N];

int n, m, ans = inf, sx, sy;
int s[N];

int Abs(int x) { return x > 0 ? x : -x; }

int work(int x) {
    int res = 0, sum = inf;
    for(int i = 1; i <= n; i++) s[i] = Abs(a[i].x - x), res += s[i] * (a[i].y - a[1].y), s[i] += s[i - 1];
    if(res < ans) ans = res, sx = x, sy = a[1].y; sum = res;
    for(int i = 1; i < n; i++) {
        if(s[i] + s[i] > s[n]) break;
        int d = a[i + 1].y - a[i].y;
        res -= (s[n] - s[i] - s[i]) * d, sum = min(res, sum);
        if(res < ans) ans = res, sx = x, sy = a[i + 1].y;
    }
    return sum;
}

namespace sub1 {
    void solve() {
        for(int i = 1; i <= n; i++) work(a[i].x);
        
        write(sx), putchar(' '), write(sy), putchar('\n');
    }
}

namespace sub2 {
    int b[N];

    void solve() {
        for(int i = 1; i <= n; i++) b[i] = a[i].x;
        sort(b + 1, b + n + 1), m = unique(b + 1, b + n + 1) - b - 1;
        int l = 1, r = m;
        
        while(l + 5 <= r) {
            int mid1 = (l + l + r) / 3, mid2 = (l + r + r) / 3;
            int res1 = work(b[mid1]), res2 = work(b[mid2]);
            if(res1 > res2) l = mid1 + 1; else r = mid2 - 1;
        }

        for(int i = l; i <= r; i++) work(b[i]);
        write(ans);
        // write(sx), putchar(' '), write(sy), putchar('\n');
    }
}

bool edmer;
signed main() {
	freopen("synd.in", "r", stdin);
	freopen("synd.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read();
    for(int i = 1; i <= n; i++) a[i] = { read(), read() };
    sort(a + 1, a + n + 1);

    // if(n <= 1e4) sub1 :: solve();
    // else sub2 :: solve();

    sub2 :: solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 