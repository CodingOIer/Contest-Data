#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

int n = 2e5, V = 2e7;

mt19937 g(time(0));

bool edmer;
signed main() {
	// freopen("synd.in", "r", stdin);
	freopen("synd.in", "w", stdout);
	// cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    cout << n << '\n';

    for(int i = 1; i <= n; i++) {
        int x = g() % (2 * V) - V, y = g() % (2 * V) - V;
        cout << x << " " << y << '\n';
    }

    // cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 