#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 5e3 + 10, M = 1e5 + 10, mod = 998244353;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = x * y % mod; }

int n, m, ans;
int f[N][N], a[N];

bool edmer;
signed main() {
	freopen("count.in", "r", stdin);
	freopen("count.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();
    for(int i = 1; i <= m; i++) {
        int x = read();
        f[1][x]++, add(f[x + 1][x], mod - 1), a[x]++;
    }
    for(int i = 1; i <= n; i++) {
        int sum = 0;
        for(int j = 1; j <= n; j++) add(f[i][j], f[i - 1][j]), add(sum, f[i][j]);
        for(int j = 1; j <= n; j++) {
            int val = (sum * a[j] % mod + mod - f[i][j]) % mod;
            add(f[i + 1][j], val), add(f[min(n, i + j) + 1][j], mod - val);
        }
    }

    for(int i = 1; i <= n; i++) add(ans, f[n][i]);

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 