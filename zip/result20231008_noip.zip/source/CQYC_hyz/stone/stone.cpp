#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 5e3, mod = 1e9 + 7;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

int n, m, ans;
int f[N], g[N];

bool edmer;
signed main() {
	freopen("stone.in", "r", stdin);
	freopen("stone.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();

    // f[0] = 1, g[0] = 0;

    ans = (m * (m + 1) / 2) * n * q_pow(m + 1, n - 1) % mod, f[0] = 1;

    for(int i = n; i; i--) {
        for(int j = N - 2; j + 1; j--) {
            int cnt = 0;
            if(!f[j]) continue;
            
            for(int k = 0; k <= m; k++) {
                if(k > i or k + j < i) cnt++;
                else add(f[j + (k + j) / i], f[j]);
            }

            mul(f[j], cnt);
        }
    }

    for(int i = 1; i < N; i++) add(ans, mod - f[i] * i % mod);

    write(ans);

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 