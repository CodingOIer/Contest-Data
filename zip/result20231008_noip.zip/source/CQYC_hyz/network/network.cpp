#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e6 + 10, M = 20;

int n, q, cnt, lc, ans;
int siz[N], fa[N], dep[N], son[N], dfn[N], rnk[N], top[N];
int lg[N], st[M][N];

char ch[M];

vector<int> e[N];

void dfs1(int x) {
    siz[x] = 1, dep[x] = dep[fa[x]] + 1;
    for(int v : e[x]) if(v ^ fa[x]) {
        fa[v] = x, dfs1(v), siz[x] += siz[v];
        if(siz[v] > siz[son[x]]) son[x] = v;
    }
}

void dfs2(int x, int t) {
    dfn[x] = ++cnt, rnk[cnt] = x, top[x] = t;
    if(!son[x]) return; dfs2(son[x], t);
    for(int v : e[x]) if(!dfn[v]) dfs2(v, v);
}

int query(int l, int r) {
    int h = lg[r - l + 1];
    return min(st[h][l], st[h][r - (1 << h) + 1]);
}

int lca(int x, int y) {
    while(top[x] ^ top[y]) dep[top[x]] > dep[top[y]] ? x = fa[top[x]] : y = fa[top[y]];
    return dep[x] > dep[y] ? y : x;
}

int sol(int x, int y) {
    int res = n; 
    while(top[x] ^ top[y]) res = min(res, query(dfn[top[x]], dfn[x])), x = fa[top[x]];
    return min(res, query(dfn[y], dfn[x]));
}

void init() {
    dfs1(1), dfs2(1, 1), lg[0] = -1;
    for(int i = 1; i <= n; i++) lg[i] = lg[i >> 1] + 1, st[0][i] = rnk[i];

    for(int i = 1, k = 1; i < M; i++, k <<= 1) for(int j = 1; j <= n; j++) st[i][j] = min(st[i - 1][j], st[i - 1][j + k]);
}

void work() {
    while(q--) {
        // scanf("%s", ch);
        ch[0] = '0';
        while(ch[0] != 'J' and ch[0] != 'Q') ch[0] = getchar();
        int x = read();
        
        if(ch[0] == 'J') {
            if(!lc) ans = x, lc = x;
            else {
                int tmp = lca(lc, x);
                ans = min({ ans, sol(lc, tmp), sol(x, tmp) }), lc = tmp;
            }
        }
        else {
            if(!lc) write(x), putchar('\n');
            else {
                int tmp = lca(lc, x);
                write(min({ ans, sol(lc, tmp), sol(x, tmp) })), putchar('\n');
            }
        }
    }
}

bool edmer;
signed main() {
	freopen("network.in", "r", stdin);
	freopen("network.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    n = read(), q = read();
    for(int i = 1; i < n; i++) {
        int u = read(), v = read();
        e[u].push_back(v), e[v].push_back(u);
    }

    init(), work();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 