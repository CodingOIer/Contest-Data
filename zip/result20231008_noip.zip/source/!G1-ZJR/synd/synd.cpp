#include<bits/stdc++.h>
using namespace std;
int x[200011],y[200011];
double mxx,mxy,mnx,mny;
int ansx,ansy,nx,ny;
long long ansv,nval;
int n;
inline double P()
{
	return (rand() & 1 ? rand() : -rand()) * 1.0 / RAND_MAX;
}
inline void Clac()
{
	nval = 0;
	for(int i = 1;i <= n;i++)
		nval += abs((long long)(nx - x[i]) * (ny - y[i]));
	if(nval < ansv)
		ansv = nval,ansx = nx,ansy = ny;
}
inline void Force()
{
	nx = 0,ny = 0;
	long long lval = LLONG_MAX;
	for(double T = 20000000;T >= 0.1;T *= 0.98)
	{
		int lx = nx,ly = ny;
		nx = max(mnx,min(T * P() + nx,mxx)),ny = max(mny,min(T * P() + ny,mxy));
		Clac();
		if(nval < lval || exp((lval - nval) / T) * rand() >= RAND_MAX)
			lval = nval;
		else
			nx = lx,ny = ly;
	}
}
const int MX = 0.5 * CLOCKS_PER_SEC;
signed main()
{
	srand(time(0));rand();
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
	cin >> n;
	mxx = mxy = -1e8,mnx = mny = 1e8;
	for(int i = 1;i <= n;i++)
	{
		cin >> x[i] >> y[i];
		mxx = max((int)mxx,x[i]),mxy = max((int)mxy,y[i]);
		mnx = min((int)mnx,x[i]),mny = min((int)mny,y[i]);
	}
	ansv = LLONG_MAX;
	while(clock() < MX)
		Force();
	cout << ansx << " " << ansy << "\n";
	return 0;
}
