#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
inline long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1) (res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}
long long ans;
int f[111][10011],mx[111];
int ys[111][10011],cnt[111][10011];
int n,k;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	cin >> n >> k;
	f[n + 1][0] = 1;
	for(int i = n;i >= 1;i--)
	{
		for(int j = 0;j <= k;j++)
		{
			int p = 0,cnt = j - 1;
			for(int t = 0;t <= mx[i + 1];t++)
			{
				if(j > i)
				{
					f[i][t] += f[i + 1][t];
					if(f[i][t] >= mod) f[i][t] -= mod;
					mx[i] = max(mx[i],t);
				}else{
					if((++cnt) == i) cnt = 0,p++;
					f[i][t + p] += f[i + 1][t];
					if(f[i][t + p] >= mod) f[i][t + p] -= mod;
					mx[i] = max(mx[i],t + p);
				}
			}
		}
	}
	ans = (1 + k) * k / 2 * qmi(k + 1,n - 1) % mod * n % mod;
	for(int i = 1;i <= mx[1];i++) ans += (mod - (long long)f[1][i] * i % mod);
	cout << ans % mod;
	return 0;
}

