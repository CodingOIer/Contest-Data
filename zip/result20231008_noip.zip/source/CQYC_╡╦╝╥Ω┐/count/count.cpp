#include <bits/stdc++.h>
using namespace std;
const int P = 998244353;
int n, m, s;
int a[5005];
int f[5005][5005];
int main()
{
    freopen("count.in", "r", stdin);
    freopen("count.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1, x; i <= m; i++)
        scanf("%d", &x), a[x]++;
    for (int i = 0; i <= n; i++)
    {
        s = !i;
        for (int j = 1; j <= n; j++)
            s = (s + 1ll * a[j] * f[i][j]) % P;
        for (int j = 1; j <= n; j++)
            f[i + 1][j] = (f[i + 1][j] + s) % P, f[min(i + j, n) + 1][j] = (1ll * f[min(i + j, n) + 1][j] + f[i][j] - s + P) % P;
    }
    printf("%d\n", s);
    return 0;
}