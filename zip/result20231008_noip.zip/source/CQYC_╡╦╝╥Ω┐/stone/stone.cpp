#include <bits/stdc++.h>
using namespace std;
const int P = 1e9 + 7;
int n, m, ans;
int f[200][10000];
int main()
{
    freopen("stone.in", "r", stdin);
    freopen("stone.out", "w", stdout);
    scanf("%d%d", &n, &m);
    f[n][0] = 1;
    ans = (P + 1ll) / 2 * n % P * m % P;
    for (int i = n; i; i--, ans = ans * (m + 1ll) % P)
        for (int j = 0; j < 4000; j++)
            for (int k = 0; k <= m; k++)
                f[i - 1][j + (k <= i) * (j + k) / i] = (f[i - 1][j + (k <= i) * (j + k) / i] + f[i][j]) % P;
    for (int i = 0; i < 4000; i++)
        ans = (ans - 1ll * i * f[0][i] % P + P) % P;
    printf("%d\n", ans);
    return 0;
}