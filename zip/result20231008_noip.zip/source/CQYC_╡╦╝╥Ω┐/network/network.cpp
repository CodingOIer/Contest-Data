#include <bits/stdc++.h>
using namespace std;
int n, q, k;
int d[1000005];
int f[1000005][20], g[1000005][20];
vector<int> e[1000005];
void read(int &x)
{
    char c = getchar();
    while (!isdigit(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
void dfs(int x)
{
    g[x][0] = x;
    for (int i = 0; i < 19; i++)
        f[x][i + 1] = f[f[x][i]][i], g[x][i + 1] = min(g[x][i], g[f[x][i]][i]);
    for (int y : e[x])
        if (y != f[x][0])
            f[y][0] = x, d[y] = d[x] + 1, dfs(y);
}
int lca(int x, int y)
{
    int res = INT_MAX;
    if (d[x] < d[y])
        swap(x, y);
    for (int i = 19; i >= 0; i--)
        if (d[x] - d[y] >= 1 << i)
            res = min(res, g[x][i]), x = f[x][i];
    for (int i = 19; i >= 0; i--)
        if (f[x][i] != f[y][i])
            res = min({res, g[x][i], g[y][i]}), x = f[x][i], y = f[y][i];
    return min({res, x, y, x == y ? INT_MAX : f[x][0]});
}
int main()
{
    freopen("network.in", "r", stdin);
    freopen("network.out", "w", stdout);
    read(n);
    read(q);
    for (int i = 1, x, y; i < n; i++)
        read(x), read(y), e[x].push_back(y), e[y].push_back(x);
    dfs(1);
    read(k);
    for (int i = 1, x; i < q; i++)
    {
        char c = getchar();
        while (isspace(c))
            c = getchar();
        read(x);
        if (c == 'Q')
            printf("%d\n", lca(k, x));
        else
            k = lca(k, x);
    }
    return 0;
}