#include<bits/stdc++.h>
#define int __int128
using namespace std;
int n,ans,ansx,ansy,A[200005],B[200005],t1,t2,t3=0,t4=0;
struct ok{
    int x,y;
}a[200005];
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void write(int x){
    int tnt=0;char f[40];
    if(x<0) x=-x,putchar('-');
    if(!x) {putchar('0');return;}
    while(x) f[++tnt]=x%10,x/=10;
    while(tnt) putchar(f[tnt--]+'0');
}
inline int AA(int x){
	if(x<0) return -x;
	return x;
}
inline int dis(int x,int y,int X,int Y){
    return AA((x-X)*(y-Y));
}
signed main(){
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    ans=1;
    for(int i=1;i<=25;i++) ans*=(int)10;
    n=read();
    for(int i=1;i<=n;i++){
        a[i].x=read(),a[i].y=read();
        A[i]=a[i].x;B[i]=a[i].y;
    }
    sort(A+1,A+1+n);
    sort(B+1,B+1+n);
    t1=unique(A+1,A+1+n)-(A+1);
    t2=unique(B+1,B+1+n)-(B+1);
    if(n<=10000){
        for(int i=-100;i<=100;i++){
            for(int j=-100;j<=100;j++){
                int d=0;
                for(int g=1;g<=n;g++){
                    d+=dis(i,j,a[g].x,a[g].y);
                    if(d>=ans) break; 
                }
                if(d<ans) ans=d,ansx=i,ansy=j;
            }
        }  
    }
    if(n<=300){
        for(int i=1;i<=t1;i++){
            for(int j=1;j<=t2;j++){
                int d=0;
                for(int g=1;g<=n;g++){
                    d+=dis(A[i],B[j],a[g].x,a[g].y);
                    if(d>=ans) break; 
                }
                if(d<ans) ans=d,ansx=A[i],ansy=B[j];
            }
        }
    }
    for(int i=1;i<=t1;i++) t3+=A[i];
    for(int i=1;i<=t2;i++) t4+=B[i];
    t3/=t1;t4/=t2;
    int d1=lower_bound(A+1,A+1+t1,t3)-A;
    int d2=lower_bound(B+1,B+1+t2,t4)-B;
    for(int i=max((int)1,d1-10);i<=min(t1,d1+10);i++){
        for(int j=max((int)1,d2-10);j<=min(t2,d2+10);j++){
            int d=0;
            for(int g=1;g<=n;g++){
                d+=dis(A[i],B[j],a[g].x,a[g].y);
                if(d>=ans) break; 
            }
            if(d<ans) ans=d,ansx=A[i],ansy=B[j];
        }
    }
    d1=t1/2;d2=t2/2;
    for(int i=max((int)1,d1-10);i<=min(t1,d1+10);i++){
        for(int j=max((int)1,d2-10);j<=min(t2,d2+10);j++){
            int d=0;
            for(int g=1;g<=n;g++){
                d+=dis(A[i],B[j],a[g].x,a[g].y);
                if(d>=ans) break; 
            }
            if(d<ans) ans=d,ansx=A[i],ansy=B[j];
        }
    }
    write(ansx),putchar(' '),write(ansy),putchar('\n');
    return 0;
}
