#include<bits/stdc++.h>
using namespace std;
int n,q,t1,t2,cnt,head[1000005],nxt[2000005],txt[2000005],F[21][1000005],G[21][1000005],dep[1000005];
char s[10];
pair<int,int> o;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void write(int x){
    int tnt=0;char f[20];
    if(x<0) x=-x,putchar('-');
    if(!x) {putchar('0');return;}
    while(x) f[++tnt]=x%10,x/=10;
    while(tnt) putchar(f[tnt--]+'0');
}
inline void dfs(int k,int f){
    F[0][k]=f;G[0][k]=f;dep[k]=dep[f]+1;
    for(int i=head[k];i;i=nxt[i]){
        if(txt[i]==f) continue;
        dfs(txt[i],k);
    }
}
inline pair<int,int> LCA(int x,int y){
    if(dep[x]<dep[y]) swap(x,y);
    int t=20,in=min(x,y);
    while(dep[x]>dep[y]){
        if(dep[F[t][x]]<dep[y]) t--;
        else in=min(in,G[t][x]),x=F[t][x];
    }
    if(x==y) return make_pair(x,in);
    t=20;
    while(x!=y){
        if(F[t][x]==F[t][y]) t--;
        else{
            in=min(in,min(G[t][x],G[t][y]));
            x=F[t][x];y=F[t][y];
        }
        if(t<0) break;
    }
    return make_pair(F[0][x],min(in,min(G[0][x],G[0][y])));
}
signed main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        t1=read(),t2=read();
        nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
        nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
    }
    dfs(1,0);
    for(int i=1;i<=20;i++){
        for(int j=1;j<=n;j++){
            F[i][j]=F[i-1][F[i-1][j]];
            G[i][j]=min(G[i-1][j],G[i-1][F[i-1][j]]);
        }
    }
    o.first=o.second=0;
    for(int i=1;i<=q;i++){
        scanf("%s",s+1);
        t1=read();
        if(s[1]=='J'){
            if(o.first==0) o=make_pair(t1,t1);
            else{
                pair<int,int> w=LCA(o.first,t1);
                o.first=w.first;o.second=min(o.second,w.second);
            }
        }
        else{
            pair<int,int> w=LCA(o.first,t1);
            write(min(o.second,w.second));
            putchar('\n');
        }
    }
    return 0;
}