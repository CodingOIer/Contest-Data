#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,m,dp[5005][5005],a[100005],sum[5005],ans;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
inline void del(int &x,int y){
    if(x<y) x=x-y+M;
    else x-=y;
}
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++) a[i]=read(),sum[a[i]]++;
    for(int i=1;i<=n;i++) add(dp[1][i],sum[i]),del(dp[i+1][i],sum[i]);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            add(dp[i+1][j],dp[i][j]);
            for(int g=1;g<=n;g++){
                if(!sum[g]) continue;
                int d=min(i+g+1,n+1);
                if(j==g) add(dp[i+1][g],dp[i][j]*(sum[g]-1)%M),del(dp[d][g],dp[i][j]*(sum[g]-1)%M);
                else add(dp[i+1][g],dp[i][j]*sum[g]%M),del(dp[d][g],dp[i][j]*sum[g]%M);
            }
        }
    }
    for(int i=1;i<=n;i++) add(ans,dp[n][i]);
    cout<<ans;
    return 0;
}