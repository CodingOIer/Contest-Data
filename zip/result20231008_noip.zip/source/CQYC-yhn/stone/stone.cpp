#include<bits/stdc++.h>
#define int long long
#define M 1000000007
using namespace std;
int n,K,f[105][4005],G[105][4005],ans=0;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
signed main(){
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=read(),K=read();
    G[n+1][0]=1;
    for(int i=n+1;i>=2;i--){
        for(int g=0;g<=3500;g++){
            if(f[i][g]==0&&G[i][g]==0) continue;
            for(int h=0;h<=K;h++){
                if(h>(i-1)){
                    add(f[i-1][g],(f[i][g]+(G[i][g]*(h+g)%M))%M);
                    add(G[i-1][g],G[i][g]);
                }
                else{
                    int d=(h+g)%(i-1),D=(h+g)/(i-1);
                    add(f[i-1][g+D],(f[i][g]+(G[i][g]*d%M))%M);
                    add(G[i-1][g+D],G[i][g]);
                }
            }
        }
    }
    for(int j=0;j<=3500;j++) add(ans,f[1][j]);
    cout<<ans;
    return 0;
}