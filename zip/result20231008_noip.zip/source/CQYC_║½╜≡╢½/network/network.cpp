#include<bits/stdc++.h>
// #define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define inf (int)(1000000000)
#define N 1000010
#define sit set<int>::iterator
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int head[N],nxt[N<<1],to[N<<1],t;
il void add(int u,int v){
    nxt[++t]=head[u];head[u]=t;to[t]=v;
    nxt[++t]=head[v];head[v]=t;to[t]=u;
}
int n,Q,dfn[N],id,dep[N],f[N][20],g[N][20],nowans=inf,lg[N],nfd[N];
il void dfs1(int x,int fa){
    dfn[x]=++id;f[x][0]=fa;g[x][0]=x;dep[x]=dep[fa]+1;nfd[id]=x;
    for(int i=1;i<20;++i){
        f[x][i]=f[f[x][i-1]][i-1];
        g[x][i]=min(g[x][i-1],g[f[x][i-1]][i-1]);
    }
    for(int i=head[x];i;i=nxt[i]) if(to[i]!=fa) dfs1(to[i],x);
}
il int lowbit(int x){
    return x&-x;
}
il int LCA(int a,int b){
    int res=inf;
    if(dep[a]<dep[b]) swap(a,b);
        // cerr<<len<<" ";
    for(int len=dep[a]-dep[b],tmp;len;len-=tmp){
        tmp=lowbit(len);
        res=min(res,g[a][lg[tmp]]);a=f[a][lg[tmp]];
    }
    if(a==b) return min(res,a);
    for(int i=19;i>=0;--i) if(f[a][i]!=f[b][i]){
        res=min(res,min(g[a][i],g[b][i]));
        a=f[a][i];b=f[b][i];
    }
    res=min(res,min(a,b));
    return min(res,f[a][0]);
}
set<int> S;
il int calc(int x,int y){
    // return 0;
    return LCA(x,y);
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
    n=read();Q=read();
    for(int i=2;i<=n;++i) lg[i]=lg[i>>1]+1;
    for(int i=1;i<n;++i) add(read(),read());
    dfs1(1,0);
    char op;
    while(Q--){
        cin>>op;int x=read();
        if(op=='J'){
            if(!S.empty()){
                sit it=S.lower_bound(dfn[x]);
                if(it==S.end()) nowans=min(nowans,calc(x,nfd[*S.begin()]));
                else nowans=min(nowans,calc(x,nfd[*it]));
                if(it==S.begin()) nowans=min(nowans,calc(x,nfd[*(--S.end())]));
                else nowans=min(nowans,calc(x,nfd[*(--it)]));
            }
            else nowans=x;
            S.insert(dfn[x]);
        }
        else{
            int ans=nowans;
            sit it=S.lower_bound(dfn[x]);
            if(it==S.end()) ans=min(ans,calc(x,nfd[*S.begin()]));
            else ans=min(ans,calc(x,nfd[*it]));
            if(it==S.begin()) ans=min(ans,calc(x,nfd[*(--S.end())]));
            else ans=min(ans,calc(x,nfd[*(--it)]));
            write(ans);putchar('\n');
        }
    }
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}