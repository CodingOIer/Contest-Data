#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 5010
#define inf (int)(1000000000000000000)
#define mod 998244353
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il int Pow(int a,int b){
    int res=1;
    while(b){
        if(b&1) res=res*a%mod;
        a=a*a%mod;b>>=1;
    }
    return res;
}
il void Del(int &a,int b){
    Add(a,mod-b);
}
int n,m,a[N],dp[N][N],ans,cnt[N],t,sum2[N][N],sum1[N];
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	n=read();m=read();
    for(int i=1;i<=m;++i) ++cnt[read()];
    for(int i=1;i<=n;++i) if(cnt[i]) a[++t]=i;
    dp[0][0]=1;
    sum1[0]=1;sum2[1][0]=1;
    for(int i=1;i<=n;++i){
        for(int h=1;h<=t;++h){
            dp[i][h]=((sum1[i-1]-sum2[i-1][h]+mod)*cnt[a[h]]%mod+sum2[i-1][h]*(cnt[a[h]]-1)%mod)%mod;
            if(a[h]<i){
                int j=i-a[h]-1;
                Del(dp[i][h],((sum1[j]-sum2[j][h]+mod)*cnt[a[h]]%mod+sum2[j][h]*(cnt[a[h]]-1)%mod)%mod);
            }
        }
        sum1[i]=sum1[i-1];
        for(int j=1;j<=t;++j) Add(sum1[i],dp[i][j]);
        for(int j=1;j<=t;++j) sum2[i][j]=(sum2[i-1][j]+dp[i][j])%mod;
    }
    for(int i=1;i<=t;++i) Add(ans,dp[n][i]);
    write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}