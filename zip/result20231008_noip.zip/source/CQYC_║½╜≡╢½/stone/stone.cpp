#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define inf (int)(1000000000000000000)
#define N 110
#define mod 1000000007
#define sit set<pii>::iterator
using namespace std;
bool ppp;
il int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il void Add(int &a,int b){
	a=a+b>=mod?a+b-mod:a+b;
}
int n,K,f[N][N*N],g[N][N*N],ans;
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
    n=read();K=read();
	f[n+1][0]=1;g[n+1][0]=0;
	for(int i=n;i;--i){
		for(int k=0;k<=n*K;++k) if(f[i+1][k]){
			for(int h=0;h<=K;++h){
				if(h>i){
					Add(g[i][k],(g[i+1][k]+f[i+1][k]*h)%mod);
					Add(f[i][k],f[i+1][k]);
				}
				else{
					int j=k+(k+h)/i;
					Add(g[i][j],(g[i+1][k]+(i-1)*(j-k)%mod*f[i+1][k]+h*f[i+1][k]-(j-k)*i%mod*f[i+1][k]%mod+mod)%mod);
					Add(f[i][j],f[i+1][k]);
				}
			}
		}
		// for(int j=0;j<=n-i+1;++j) cerr<<i<<" "<<j<<" "<<f[i][j]<<" "<<g[i][j]<<"\n";
	}
	for(int i=0;i<=n*K;++i) Add(ans,g[1][i]);
	write(ans);
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}