#include<bits/stdc++.h>
#define it128 __int128
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define inf (int)(1000000000000000000)
#define N 200010
#define sit set<int>::iterator
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
il it128 abs(it128 x){
	return x<0?-x:x;
}
struct node{
	int x,y;
} a[N];
int n;
il void solve1(){
	int ans1=inf;pii ans2;
    for(int X=-100;X<=100;++X){
        for(int Y=-100;Y<=100;++Y){
            int res=0;
            for(int i=1;i<=n;++i) res+=abs((X-a[i].x)*(Y-a[i].y));
            if(ans1>res){
                ans1=res;ans2=pii(X,Y);
            }
        }
    }
    write(ans2.fi);putchar(' ');write(ans2.se);
}
int x_[N],y_[N],totx,toty;
il void solve2(){
	it128 ans1=(it128)(100000000000000000000);pii ans2;
	for(int i=1;i<=totx;++i){
		for(int j=1;j<=toty;++j){
			int X=x_[i],Y=y_[j];
            int res=0;
            for(int i=1;i<=n;++i) res+=abs((X-a[i].x)*(Y-a[i].y));
            if(ans1>res){
                ans1=res;ans2=pii(X,Y);
            }
		}
	}
    write(ans2.fi);putchar(' ');write(ans2.se);
}
// il void solve3(){
// 	#define down 0.996
// 	dl t=3000;
// 	while(t>1e-8){

// 	}
// }
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
    n=read();
	int flag=1;
    for(int i=1;i<=n;++i){
        a[i].x=read();a[i].y=read();
		if(a[i].x<-100||a[i].x>100||a[i].y<-100||a[i].y>100) flag=0;
    }
	// flag=0;
	if(flag&&n<=10000) solve1();
	else{
		for(int i=1;i<=n;++i){
			x_[i]=a[i].x;y_[i]=a[i].y;
		}
		sort(x_+1,x_+1+n);sort(y_+1,y_+1+n);
		totx=unique(x_+1,x_+1+n)-x_-1;toty=unique(y_+1,y_+1+n)-y_-1;
		// solve2();
		solve2();
		// else solve3();
	}
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	// cerr<<"ERROR";
	return 0;
}