#include<bits/stdc++.h>
using namespace std;
const int NN=104,P=1e9+7;
int f[NN][NN*NN];
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	f[n+1][0]=1;
	for(int i=n;i;i--)
		for(int j=0;j<=n*n;j++)
			for(int k=0;k<=m;k++)
				if(k<=i)
					f[i][j+(k+j)/i]=(f[i][j+(k+j)/i]+f[i+1][j])%P;
				else
					f[i][j]=(f[i][j]+f[i+1][j])%P;
	int res=0,t=1;
	for(int i=1;i<n;i++)
		t=1ll*t*(m+1)%P;
	for(int i=1;i<=m;i++)
		res=(res+1ll*i*n%P*t%P)%P;
	for(int i=0;i<=n*n;i++)
		res=(res-1ll*i*f[1][i]%P+P)%P;
	printf("%d",res);
	return 0;
}
