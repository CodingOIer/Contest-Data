#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4;
int x[NN],y[NN];
int main()
{
	freopen("synd.in","r",stdin);
	freopen("synd.out","w",stdout);
	int n;
	scanf("%d",&n);
    for(int i=1;i<=n;i++)
    	scanf("%d%d",&x[i],&y[i]);
    if(n<=300)
    {
        __int128 minn=1e36;
		pair<int,int>ans;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
			{
                __int128 res=0;
                for(int k=1;k<=n;k++)
                    res+=abs((x[i]-x[k])*(y[j]-y[k]));
                if(res<minn)
				{
                    minn=res;
                    ans={x[i],y[j]};
                }
            }
    	printf("%d %d",ans.first,ans.second);
	}
	else
    {
        __int128 minn=1e36;
		pair<int,int>ans;
        for(int i=-100;i<=100;i++)
            for(int j=-100;j<=100;j++)
			{
                __int128 res=0;
                for(int k=1;k<=n;k++)
                    res+=abs((i-x[k])*(j-y[k]));
                if(res<minn)
				{
                    minn=res;
                    ans={i,j};
                }
            }
    	printf("%d %d",ans.first,ans.second);
	}
	return 0;
}
