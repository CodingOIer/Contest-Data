#include<bits/stdc++.h>
using namespace std;
namespace IOR{
	char ib[1<<22],ob[1<<20],*p1=ib,*p2=ib,*po=ob;
	void flush(){fwrite(ob,sizeof(char),po-ob,stdout);po=ob;}struct OC{~OC(){flush();};}Oc;
	char gc(){return p1==p2&&(p2=(p1=ib)+fread(ib,sizeof(char),sizeof(ib),stdin),p1==p2)?EOF:*p1++;}
	void pc(const char c){*po++=c;if(po-ob==sizeof(ob))flush();}
	void pt(const char *s){while(*s!='\0'){pc(*s);s++;}pc('\n');}
}
#define getchar IOR::gc
#define putchar IOR::pc
#define puts IOR::pt
namespace fastio{
	struct{template<typename T>operator T(){
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0){
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;
const int NN=1e6+4;
vector<int>g[NN];
int d[NN],up[NN][24],minn[NN][24];
void before_lca(int u,int fa)
{
	up[u][0]=fa;
	minn[u][0]=u;
	d[u]=d[fa]+1;
	for(int i=1;i<=20;i++)
	{
		up[u][i]=up[up[u][i-1]][i-1];
		minn[u][i]=min(minn[u][i-1],minn[up[u][i-1]][i-1]);
	}
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];
		if(v==fa)
			continue;
		before_lca(v,u);
	}
}
pair<int,int>lca(int u,int v)
{
	if(d[u]<d[v])
		swap(u,v);
	int res=1e9;
	for(int i=20;~i;i--)
		if(d[up[u][i]]>=d[v])
		{
			res=min(res,minn[u][i]);
			u=up[u][i];
		}
	if(u==v)
		return {u,min(res,u)};
	for(int i=20;~i;i--)
		if(up[u][i]!=up[v][i])
		{
			res=min(res,min(minn[u][i],minn[v][i]));
			u=up[u][i],v=up[v][i];
		}
	res=min(res,min(minn[u][0],minn[v][0]));
	u=up[u][0];
	return {u,min(res,u)};
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	int n=in,q=in;
	for(int i=1;i<n;i++)
	{
		int u=in,v=in;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	before_lca(1,0);
	int l=in,minn;
	minn=l;
	q--;
	while(q--)
	{
		char c=getchar();
		while(c!='J'&&c!='Q')
			c=getchar();
		int p=in;
		if(c=='J')
		{
			pair<int,int>t=lca(l,p);
			l=t.first;
			minn=min(minn,t.second);
		}
		else
			out(min(minn,lca(l,p).second),'\n');
	}
	return 0;
}
