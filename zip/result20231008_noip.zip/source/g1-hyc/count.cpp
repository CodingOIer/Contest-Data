#include<bits/stdc++.h>
using namespace std;
const int NN=5004,P=998244353;
int s[NN][NN],cnt[NN];
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x;
		scanf("%d",&x);
		cnt[x]++;
	}
	for(int i=1;i<=n;i++)
		s[0][i]=1;
	for(int i=1;i<=n;i++)
	{
		int res=0;
		for(int j=1;j<=n;j++)
			if(j>=i)
				res=(res+1ll*s[i-1][j]*cnt[j]%P)%P;
			else
				res=(res+1ll*(s[i-1][j]-s[i-j-1][j]+P)%P*cnt[j]%P)%P;
		for(int j=1;j<=n;j++)
			if(j>=i)
				s[i][j]=(0ll+s[i-1][j]+res-s[i-1][j]*(cnt[j]>0)+P)%P;
			else
				s[i][j]=(0ll+s[i-1][j]+res-(s[i-1][j]-s[i-j-1][j]+P)%P*(cnt[j]>0)+P)%P;
		if(i==n)
			printf("%d",res);
	}
	return 0;
}
