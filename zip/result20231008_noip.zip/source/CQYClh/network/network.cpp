#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+2,logn=23;
const int inf=1e9;
int n,Q;
int cnt,idx,rt;
int ans;
int hed[maxn],dfn[maxn],siz[maxn],dep[maxn],fa[logn][maxn],d[logn][maxn];
bool vis[maxn];
struct node_edge{
    int nxt,to;
}G[maxn*2];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int ot[40],tp;
void write(int x){
    if(!x){putchar('0');return ;}
    while(x)ot[++tp]=x%10,x/=10;
    while(tp)putchar(ot[tp--]+'0');
    return ;
}
void add(int u,int v){
    G[++cnt]=(node_edge){hed[u],v};
    hed[u]=cnt;
    return ;
}
void dfs(int x,int f){
    dep[x]=dep[f]+1,dfn[x]=++idx,siz[x]=1;
    for(int i=hed[x],v;i;i=G[i].nxt){
        v=G[i].to;
        if(v==f)continue;
        fa[0][v]=x,d[0][v]=v;
        dfs(v,x);
        siz[x]+=siz[v];
    }
    return ;
}
void pre(){
    for(int i=1;i<logn;i++){
        for(int j=1;j<=n;j++){
            fa[i][j]=fa[i-1][fa[i-1][j]];
            d[i][j]=min(d[i-1][j],d[i-1][fa[i-1][j]]);
        }
    }
}
int lca(int u,int v){
    if(dep[u]<dep[v])swap(u,v);
    for(int i=logn-1;i>=0;i--){
        if(dep[fa[i][u]]>=dep[v])u=fa[i][u];
    }
    if(u==v)return u;
    for(int i=logn-1;i>=0;i--){
        if(fa[i][u]!=fa[i][v])u=fa[i][u],v=fa[i][v];
    }
    return fa[0][u];
}
void modify(int x){
    if(!rt){rt=x,ans=x;return ;}
    if(dfn[x]<=dfn[rt]&&dfn[x]+siz[x]-1>=dfn[rt]){
        for(int v=rt;v!=x;v=fa[0][v])vis[fa[0][v]]=1,ans=min(ans,fa[0][v]);
        rt=x;
        return ;
    }
    int lc=lca(rt,x);
    if(lc!=rt){
        for(int v=rt;v!=lc;v=fa[0][v])vis[fa[0][v]]=1,ans=min(ans,fa[0][v]);
        for(int v=x;v!=lc;v=fa[0][v])vis[v]=1,ans=min(ans,v);
        rt=lc;
    }
    else for(int v=x;v!=rt;v=fa[0][v])vis[v]=1,ans=min(ans,v);
}
int ge(int u,int ff){
    int ret=inf;
    // if(!ff)printf("boom\n");
    for(int i=logn-1;i>=0;i--){
        if(dep[fa[i][u]]>=dep[ff])ret=min(ret,d[i][u]),u=fa[i][u];
    }
    return min(ret,ff);
}
int query(int x){
    if(vis[x])return ans;
    int lc=lca(rt,x);
    return min(min(ge(rt,lc),ge(x,lc)),ans);
}
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    n=read(),Q=read();
    for(int i=1,u,v;i<n;i++){
        u=read(),v=read();
        add(u,v);
        add(v,u);
    }
    dfs(1,0);
    // for(int i=1;i<=n;i++)if(!dfn[i])printf("chao\n");
    pre();
    char ch=' ';
    int x;
    for(int i=1;i<=Q;i++){
        ch=' ';
        while(ch<'A'||ch>'Z')ch=getchar();
        if(ch=='J')x=read(),modify(x);
        // else x=read(),x=query(x);
        else x=read(),write(query(x)),putchar('\n');
        // else x=read(),printf("%d\n",query(x));
    }
    cerr<<clock()<<'\n';
    return 0;
}