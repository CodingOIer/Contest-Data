#include<bits/stdc++.h>
using namespace std;
const int maxn=1e3+2,maxm=1e5+2;
const int mod=998244353;
int n,m;
int num[maxn],ar[maxn],inv[maxn];
int dp[maxn][maxn],sum[maxn];
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++)ar[i]=read(),num[ar[i]]++;
    inv[1]=1;
    for(int i=2;i<=n;i++)inv[i]=1ll*inv[mod%i]*(mod-mod/i)%mod;
    dp[0][0]=1,sum[0]=1;
    for(int i=1;i<=n;i++){
        // for(int j=1;j<=n;j++)upd(dp[i][j],1ll*(sum[i-1]-1ll*dp[i-1][j]*inv[num[j]]%mod+mod)*num[j]%mod);
        for(int j=1;j<=n;j++)upd(dp[i][j],1ll*sum[i-1]*num[j]%mod);
        for(int j=1;j<i;j++){
            // if(i==3&&j==1)printf("ad %d \n",1ll*(mod-1)*(sum[i-j-1]-1ll*dp[i-j-1][j]*inv[num[j]]%mod+mod)%mod*num[j]%mod);
            // if(i==3&&j==2)printf("ad %d \n",1ll*(mod-1)*(sum[i-j-1]-1ll*dp[i-j-1][j]*inv[num[j]]%mod+mod)%mod*num[j]%mod);
            upd(dp[i][j],1ll*(mod-1)*(sum[i-j-1]-1ll*dp[i-j-1][j]*inv[num[j]]%mod+mod)%mod*num[j]%mod);
        }
        for(int j=1;j<=n;j++)upd(sum[i],dp[i][j]);
    }
    printf("%d\n",sum[n]);
    return 0;
}