#include<bits/stdc++.h>
using namespace std;
const int maxn=102,maxs=4000;
const int mod=1e9+7;
int n,k;
int f[maxn][maxs],g[maxn][maxs];
int ans;
int read(){
    int x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
void upd(int &x,int v){((x+=v)>=mod)?(x-=mod):x;}
int calc(int s,int i,int j){
    if(j>i)return 0;
    return (s+j)/i;
}
int va(int s,int i,int j){
    if(j>i)return s+j;
    return (s+j)%i;
}
int main(){
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=read(),k=read();
    f[n+1][0]=0,g[n+1][0]=1;
    for(int i=n;i;i--){
        for(int s=0;s<maxs;s++){
            for(int j=0;j<=k;j++){
                if(s+calc(s,i,j)<maxs){
                    upd(f[i][s+calc(s,i,j)],(f[i+1][s]+1ll*va(s,i,j)*g[i+1][s]%mod)%mod);
                    upd(g[i][s+calc(s,i,j)],g[i+1][s]);
                }
            }
        }
    }
    for(int i=0;i<maxs;i++)upd(ans,f[1][i]);
    printf("%d\n",ans);
    return 0;
}