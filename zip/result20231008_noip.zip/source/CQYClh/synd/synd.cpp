#include<bits/stdc++.h>
using namespace std;
const __int128 inf=1e36;
const int maxn=2e5+3;
int n;
int cntx,cnty;
__int128 vax[maxn],vay[maxn],pre[maxn],suf[maxn],pr[maxn],su[maxn];
__int128 ansva,ansx,ansy;
vector<int>qu[maxn];
__int128 ot[40],tp;
void write(__int128 x){
    if(!x){putchar('0');return ;}
    if(x<0)putchar('-'),x=-x;
    while(x)ot[++tp]=x%10,x/=10;
    while(tp)putchar(ot[tp--]+'0');
    return ;
}
__int128 read(){
    __int128 x=0;
    bool f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=x*10+ch-'0',ch=getchar();
    return (f)?-x:x;
}
struct node{
    long long x,y;
}p[maxn],q[maxn];
__int128 calc(__int128 ax,__int128 ay,__int128 bx,bool ty,bool ty2){
    if(ax>=bx){
        if(ty2)return (!ty)?((ax-bx)*ay):(bx-ax);
        else return (!ty)?((bx-ax)*ay):(ax-bx);
    }
    else {
        if(ty2)return (!ty)?((bx-ax)*ay):(ax-bx);
        else return (!ty)?((ax-bx)*ay):(bx-ax);
    }
}
namespace fake{
    __int128 ab(__int128 x){
        return (x<0)?(-x):x;
    }
    __int128 solve(__int128 bx,__int128 by){
        __int128 ret=0;
        for(int i=1;i<=n;i++)ret+=ab((bx-p[i].x)*(by-p[i].y));
        return ret;
    }
    void sol(){
        sort(vax+1,vax+cntx+1);
        sort(vay+1,vay+cnty+1);
        // cntx=unique(vax+1,vax+cntx+1)-vax-1;
        // cnty=unique(vay+1,vay+cnty+1)-vay-1;
        for(int i=1;i<=n;i++){
            q[i].x=lower_bound(vax+1,vax+cntx+1,p[i].x)-vax;
            q[i].y=lower_bound(vay+1,vay+cnty+1,p[i].y)-vay;
            qu[q[i].y].push_back(i);
            // printf("q[%d]=(%d %d)\n",i,q[i].x,q[i].y);
        }
        ansva=inf;
        __int128 vv;
        for(int i=max(1,cntx/2-4);i<=min(cntx/2+4,cntx);i++){
            for(int j=max(1,cnty/2-4);j<=min(cnty/2+4,cnty);j++){
                vv=solve(vax[i],vay[j]);
                if(ansva>vv)ansx=vax[i],ansy=vay[j],ansva=vv;
            }
        }
        // printf("%lld %lld\n",(long long)ansx,(long long)ansy);
        write(ansx),putchar(' '),write(ansy);
    }
}
int main(){
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)p[i].x=read(),p[i].y=read(),vax[++cntx]=p[i].x,vay[++cnty]=p[i].y;
    if(n>10000){fake::sol();return 0;}
    // if(1){fake::sol();return 0;}
    sort(vax+1,vax+cntx+1);
    sort(vay+1,vay+cnty+1);
    cntx=unique(vax+1,vax+cntx+1)-vax-1;
    cnty=unique(vay+1,vay+cnty+1)-vay-1;
    for(int i=1;i<=n;i++){
        q[i].x=lower_bound(vax+1,vax+cntx+1,p[i].x)-vax;
        q[i].y=lower_bound(vay+1,vay+cnty+1,p[i].y)-vay;
        qu[q[i].y].push_back(i);
        // printf("q[%d]=(%d %d)\n",i,q[i].x,q[i].y);
    }
    ansva=inf;
    for(int i=1;i<=cntx;i++){
        for(int j=1;j<=cnty;j++){
            pre[j]=pre[j-1],pr[j]=pr[j-1];
            for(int k=0;k<qu[j].size();k++)pre[j]+=calc(p[qu[j][k]].x,p[qu[j][k]].y,vax[i],0,0),pr[j]+=calc(p[qu[j][k]].x,p[qu[j][k]].y,vax[i],1,0);
        }
        for(int j=cnty;j;j--){
            suf[j]=suf[j+1],su[j]=su[j+1];
            for(int k=0;k<qu[j].size();k++)suf[j]+=calc(p[qu[j][k]].x,p[qu[j][k]].y,vax[i],0,1),su[j]+=calc(p[qu[j][k]].x,p[qu[j][k]].y,vax[i],1,1);
        }
        for(int j=1;j<=cnty;j++){
            // if(vax[i]==0)printf("qy=%d: %lld %lld %lld %lld\n",j,(long long)pre[j],(long long)suf[j+1],(long long)pr[j],(long long)su[j+1]);
            if(pre[j]+suf[j+1]+vay[j]*(pr[j]+su[j+1])<ansva)ansva=pre[j]+suf[j+1]+vay[j]*(pr[j]+su[j+1]),ansx=vax[i],ansy=vay[j];
        }
    }
    // printf("%lld %lld\n",(long long)ansx,(long long)ansy);
    write(ansx),putchar(' '),write(ansy);
    // putchar('\n'),write(ansva);
    return 0;
}