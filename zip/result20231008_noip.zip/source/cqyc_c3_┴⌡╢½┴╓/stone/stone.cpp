#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
	struct{template<typename T>operator T(){
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0){
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;

const int N = 105,mod = 1000000007;
int f[N][N*N];
int n,m;

signed main(){
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	n = in,m = in;
	f[n+1][0] = 1;
	for(int k=n;k;k--)
		for(int j=0;j<=n*n;j++)
			for(int i=0;i<=m;i++)
				if(i<=k)
					f[k][j+(i+j)/k] = (f[k][j+(i+j)/k]+f[k+1][j])%mod;
				else
					f[k][j] = (f[k][j]+f[k+1][j])%mod;
	int ans = 0,w = 1;
	for(int k=1;k<n;k++)
		w = w*(m+1)%mod;
	for(int k=1;k<=m;k++)
		ans = (ans+k*n%mod*w)%mod;
	for(int k=0;k<=n*n;k++)
		ans = (ans-k*f[1][k]%mod+mod)%mod;
	out(ans);
	return 0;
}
