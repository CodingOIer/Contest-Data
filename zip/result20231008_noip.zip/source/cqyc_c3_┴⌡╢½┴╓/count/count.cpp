#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 5005,mod = 998244353;
int s[N][N],c[N];
int n,m;

signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    n = in,m = in;
    for(int k=1;k<=m;k++){
        int x = in;
        c[x]++;
    }
    for(int k=1;k<=n;k++)
        s[0][k] = 1;
    for(int k=1;k<=n;k++){
        int ans = 0;
        for(int j=1;j<=n;j++)
            if(j>=k)
                ans = (ans+s[k-1][j]*c[j])%mod;
            else
                ans = (ans+(s[k-1][j]-s[k-j-1][j]+mod)%mod*c[j])%mod;
        for(int j=1;j<=n;j++)
            if(j>=k)
                s[k][j] = (s[k-1][j]+ans-(c[j]>0?s[k-1][j]:0)+mod)%mod;
            else
                s[k][j] = (s[k-1][j]+ans-(c[j]>0?(s[k-1][j]-s[k-j-1][j]+mod)%mod:0)+mod)%mod;
        if(k==n)
            out(ans);
    }
    return 0;
}