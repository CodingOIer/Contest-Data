#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace IOR{
	char ib[1<<22],ob[1<<20],*p1=ib,*p2=ib,*po=ob;
	void flush(){fwrite(ob,sizeof(char),po-ob,stdout);po=ob;}struct OC{~OC(){flush();};}Oc;
	char gc(){return p1==p2&&(p2=(p1=ib)+fread(ib,sizeof(char),sizeof(ib),stdin),p1==p2)?EOF:*p1++;}
	void pc(const char c){*po++=c;if(po-ob==sizeof(ob))flush();}
	void pt(const char *s){while(*s!='\0'){pc(*s);s++;}pc('\n');}
}
#define getchar IOR::gc
#define putchar IOR::pc
#define puts IOR::pt

namespace fastio{
	struct{template<typename T>operator T(){
		T x=0;char f=0,c=getchar();
		while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
		while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
		return f?-x:x;
	}}in;int stk[40],tp;
	template<typename T>void out(T x,char c=0){
		if(x<0)putchar('-'),x=-x;
		do stk[++tp]=x%10,x/=10;while(x);
		while(tp)putchar(stk[tp--]^48);
		if(c)putchar(c);
	}
}using fastio::in;using fastio::out;

const int N = 1000005,M = 22;
int d[N],fa[N][M],w[N][M];
vector<int> g[N];
int n,q;

void dfs(int u){
	w[u][0] = u;
	for(int k=1;fa[u][k-1];k++){
		fa[u][k] = fa[fa[u][k-1]][k-1];
		w[u][k] = min(w[u][k-1],w[fa[u][k-1]][k-1]);
	}
	for(int v:g[u]){
		if(v==fa[u][0])
			continue;
		fa[v][0] = u;
		d[v] = d[u]+1;
		dfs(v);
	}
}

pair<int,int> lca(int x,int y){
	if(d[x]<d[y])
		swap(x,y);
	int ans = 1e9;
	for(int k=M-1;~k;k--)
		if(d[x]-(1<<k)>=d[y]){
			ans = min(ans,w[x][k]);
			x = fa[x][k];
		}
	if(x==y)
		return {x,min(ans,x)};
	for(int k=M-1;~k;k--)
		if(fa[x][k]!=fa[y][k]){
			ans = min(ans,min(w[x][k],w[y][k]));
			x = fa[x][k];
			y = fa[y][k];
		}
	ans = min(ans,min(w[x][0],w[y][0]));
	x = fa[x][0];
	return {x,min(ans,x)};
}

int main(){
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	n = in,q = in;
	for(int k=1;k<n;k++){
		int a = in,b = in;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	dfs(1);
	int x = in;
	int y = x;
	q--;
	while(q--){
		char op = getchar();
		while(op!='J'&&op!='Q')
			op = getchar();
		int p = in;
		if(op=='J'){
			pair<int,int> z = lca(x,p);
			x = z.first;
			y = min(y,z.second);
		}
		else
			out(min(y,lca(x,p).second),'\n');
	}
	return 0;
}