#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 400005;
int x[N],y[N];
int n;

namespace nV2{
    signed main(){
        int lx = 1e18,rx = -1e18,ly = 1e18,ry = -1e18;
        for(int k=1;k<=n;k++){
            x[k] = in,y[k] = in;
            lx = min(lx,x[k]);
            rx = max(rx,x[k]);
            ly = min(ly,y[k]);
            ry = max(ry,y[k]);
        }
        int ans = 1e18,ax,ay;
        for(int x=lx;x<=rx;x++)
            for(int y=ly;y<=ry;y++){
                int res = 0;
                for(int k=1;k<=n;k++)
                    res += abs((x-::x[k])*(y-::y[k]));
                if(res<ans){
                    ans = res;
                    ax = x,ay = y;
                }
            }
        out(ax,' ');
        out(ay);
        return 0;
    }
}

namespace n3{
    signed main(){
        for(int k=1;k<=n;k++)
            x[k] = in,y[k] = in;
        int ans = 1e18,ax,ay;
        for(int k=1;k<=n;k++)
            for(int j=1;j<=n;j++){
                int res = 0;
                for(int i=1;i<=n;i++)
                    res += abs((x[k]-x[i])*(y[j]-y[i]));
                if(res<ans){
                    ans = res;
                    ax = x[k],ay = y[j];
                }
            }
        out(ax,' ');
        out(ay);
        return 0;
    }
}

signed main(){
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    n = in;
    if(n<=300)
        return n3::main();
    return nV2::main();
}