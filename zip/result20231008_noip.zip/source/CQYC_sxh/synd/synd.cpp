#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 1000;
int n;
struct node {
    int x, y; 
    bool operator <(const node &b) const {
        return x != b.x ? x < b.x : y < b.y;
    }
}a[N];

int b[N], c[N], bn, cn;

signed main() {
	freopen("synd.in", "r", stdin);
	freopen("synd.out", "w", stdout);
    n = read(); For(i, 1, n) a[i] = {read(), read()};

    sort(a + 1, a + n + 1); 
    For(i, 1, n) b[i] = a[i].x; For(i, 1, n) c[i] = a[i].y;

    sort(b + 1, b + n + 1), bn = unique(b + 1, b + n + 1) - b - 1;
    sort(c + 1, c + n + 1), cn = unique(c + 1, c + n + 1) - c - 1;

    if (1ll * bn * cn * n <= 5e8) {
        __int128_t ans = 1e36; int sx = 0, sy = 0;
        For(i, 1, bn) For(j, 1, cn) { __int128_t res = 0;
            For(k, 1, n) res += abs(1ll * (a[k].x - b[i]) * (a[k].y - c[j]));
            if (res < ans) sx = b[i], sy = c[j], ans = res;
        } 
        cout << sx <<" "<<sy; return 0;
    }
    
    __int128_t ans = 1e36; mt19937 R(114514); int sx,sy;
    For(i, 1, 1000) {
        i64 x = b[R() % bn + 1], y = c[R() % cn + 1]; __int128_t res = 0;
        For(k, 1, n) res += abs(1ll * (a[k].x - x) * (a[k].y - y));
        if (res < ans) sx = x, sy = y, ans = res;
    } cout << sx <<" "<<sy;
	return 0;
}