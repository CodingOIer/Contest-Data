#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

char buf[(1<<21)+5],*p1,*p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

char qqq;

const int N = 1e6 + 100;

int n, q, ans, lg[N];
int head[N], nxt[N << 1], to[N << 1], cnt;

void Add(int u, int v) {
    to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, nxt[cnt] = head[v], head[v] = cnt;
}

int fa[21][N], val[21][N], dep[N], dfn[N], id[N], num;
void dfs(int u) {
    dfn[u] = ++num, id[num] = u;
    dep[u] = dep[fa[0][u]] + 1, val[0][u] = u;
    For(i, 1, lg[dep[u]]) {
        fa[i][u] = fa[i - 1][fa[i - 1][u]];
        val[i][u] = min(val[i - 1][u], val[i - 1][fa[i - 1][u]]);
    } Eor(u) if (to[i] != fa[0][u]) fa[0][to[i]] = u, dfs(to[i]);
}

int ask(int u, int v) {  int res = n;
    if (dep[u] < dep[v]) swap(u, v);
    Rof(i, lg[dep[u] - dep[v]], 0) if (dep[fa[i][u]] >= dep[v]) 
        Min(res, val[i][u]), u = fa[i][u];
    if (u == v) return min(res, u);
    Rof(i, lg[dep[u]], 0) if (fa[i][u] ^ fa[i][v]) {
        Min(res, val[i][u]), u = fa[i][u];
        Min(res, val[i][v]), v = fa[i][v];
    }  return min({res, fa[0][u], u, v});
}

set<int> s;

char qqqq;

signed main() {
	freopen("network.in", "r", stdin);
	freopen("network.out", "w", stdout);
    cerr << (&qqq- &qqqq) / 1024.0 / 1024.0<<'\n';
    n = read(), q = read(), ans = n + 1;
    For(i, 2, n) lg[i] = lg[i >> 1] + 1;
    For(i, 2, n) Add(read(), read());
    dfs(1); while (q--) {  char ch = getchar(); 
        while (ch != 'J' && ch != 'Q') ch = getchar();
        int x = read(); if (ch == 'J') {
            auto y = s.insert(dfn[x]); auto it = y.first;
            if (!y.second) continue;
            if (it != s.begin()) 
                ans = min(ans, ask(id[*prev(it)], x));
            else ans = min(ans, ask(id[*--s.end()], x));
            if (next(it) != s.end()) 
                ans = min(ans, ask(id[*next(it)], x));
            else ans = min(ans, ask(id[*s.begin()], x));
        } else { int res = ans;
            auto y = s.insert(dfn[x]); auto it = y.first; 
            if (!y.second) { cout << ans << '\n'; continue; }
            if (it != s.begin()) 
                res = min(res, ask(id[*prev(it)], x));
            else res = min(res, ask(id[*--s.end()], x));
            if (next(it) != s.end()) 
                res = min(res, ask(id[*next(it)], x));
            else res = min(res, ask(id[*s.begin()], x));
            if (y.second) s.erase(it);
            cout << res << '\n';
        }
    }
    cerr << clock() / 1000.0 << '\n';
	return 0;
}