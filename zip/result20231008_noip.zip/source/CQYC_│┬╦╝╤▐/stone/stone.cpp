#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int n,k,a[105],ans;
priority_queue<int> q;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int &a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
void solve(){
    while(!q.empty())
        q.pop();
    for(int i=1;i<=n;i++)
        if(a[i]==i)
            q.push(-i);
    while(!q.empty()){
        int x=-q.top();
        q.pop();
        a[x]=0;
        for(int i=1;i<x;i++){
            a[i]++;
            if(a[i]==i)
                q.push(-i);
        }
    }
    for(int i=1;i<=n;i++)
        add(ans,a[i]);
}
void f(int x){
    if(x>n){
        solve();
        return;
    }
    for(int i=0;i<=k;i++){
        a[x]=i;
        f(x+1);
    }
}
signed main(){
    freopen("stone.in","r",stdin);
    freopen("stone.out","w",stdout);
    n=read(),k=read();
    f(1);
    printf("%lld\n",ans);
    return 0;
}
