#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353,maxn=1e5+5;
int n,m,a[maxn],f[2][5005][5005],op,ans,b[5005];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void add(int &a,int b){
    a+=b;
    if(a>=mod)
        a-=mod;
}
signed main(){
    freopen("count.in","r",stdin);
    freopen("count.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        a[i]=read();
    }
    f[op][1][0]=1;
    for(int i=1;i<=n;i++){
        int res=0;
        for(int j=1;j<=m;j++){
            b[j]=0;
            for(int l=0;l<=a[j];l++){
                f[op^1][j][l]=0;
                add(b[j],f[op][j][l]);
            }
            add(res,b[j]);
        }
        for(int j=1;j<=m;j++){
            add(f[op^1][j][1],(res+mod-b[j])%mod);
            for(int l=0;l<a[j];l++)
               add(f[op^1][j][l+1],f[op][j][l]);
        }
        op^=1;
    }
    for(int i=1;i<=m;i++)
        for(int j=0;j<=a[i];j++)
            ans=(ans+=f[op][i][j])%mod;
    printf("%lld\n",ans);
    return 0;
}