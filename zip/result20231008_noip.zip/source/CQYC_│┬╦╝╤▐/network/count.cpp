#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
int n,q,u,v,x,mi=1e9,la=0,vis[maxn],t[maxn<<2];
int fa[maxn],de[maxn],si[maxn],son[maxn],top[maxn],dfn[maxn],id[maxn],cnt;
char s[10];
vector<int> to[maxn];
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
void write(int x){
    int cnt=0;
    char f[100];
    while(x)
        f[++cnt]=x%10,x/=10;
    while(cnt)
        putchar(f[cnt--]+'0');
    putchar('\n');
}
void dfs1(int u,int f,int dep){
    fa[u]=f,de[u]=dep,si[u]=1;
    for(auto v:to[u])
        if(v!=f){
            dfs1(v,u,dep+1);
            si[u]+=si[v];
            if(si[v]>si[son[u]])
                son[u]=v;
        }
}
void dfs2(int u,int topp){
    top[u]=topp,dfn[u]=++cnt,id[cnt]=u;
    if(son[u])
        dfs2(son[u],topp);
    for(auto v:to[u])
        if(!top[v])
            dfs2(v,v);
}
void pushup(int k){
    t[k]=min((t[k<<1]?t[k<<1]:1e9),(t[k<<1|1]?t[k<<1|1]:1e9));
}
void build(int k,int l,int r){
    if(l==r){
        t[k]=id[l];
        return;
    }
    int mid=(l+r)>>1;
    build(k<<1,l,mid);
    build(k<<1|1,mid+1,r);
    pushup(k);
}
int qu(int k,int l,int r,int L,int R){
    if(l>=L&&r<=R)
        return t[k];
    int res=1e9;
    int mid=(l+r)>>1;
    if(mid>=L)
        res=min(res,qu(k<<1,l,mid,L,R));
    if(mid<R)
        res=min(res,qu(k<<1|1,mid+1,r,L,R));
    return res;
}
int query(int x,int y){
	if(!y)
		return x;
    int res=1e9;
    while(top[x]!=top[y]){
        if(de[top[x]]<de[top[y]])
            swap(x,y);
        res=min(res,qu(1,1,n,dfn[top[x]],dfn[x]));
        x=fa[top[x]];
    }
    if(de[x]>de[y])
        swap(x,y);
    res=min(res,qu(1,1,n,dfn[x],dfn[y]));
    return res;
}
signed main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    n=read(),q=read();
    for(int i=1;i<n;i++){
        u=read(),v=read();
        to[u].push_back(v);
        to[v].push_back(u);
    }
    dfs1(1,0,1);
    dfs2(1,1);
    build(1,1,n);
    while(q--){
        scanf("%s",s+1);
        x=read();
        if(s[1]=='J'){
            if(!vis[x]){
                mi=min(query(x,la),mi);
                la=x,vis[x]=1;
            }
        }
        else
            write(min(query(x,la),mi));
    }
    return 0;
}
