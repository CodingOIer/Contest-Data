#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int n,x[maxn],y[maxn],mi=1e18,ansx,ansy;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
signed main(){
    freopen("synd.in","r",stdin);
    freopen("synd.out","w",stdout);
    n=read();
    for(int i=1;i<=n;i++)
        x[i]=read(),y[i]=read();
    for(int i=-100;i<=100;i++)
        for(int j=-100;j<=100;j++){
            int res=0;
            for(int l=1;l<=n;l++)
                res+=abs((i-x[l])*(j-y[l]));
            if(res<mi)
                ansx=i,ansy=j,mi=res;
        }
    printf("%lld %lld\n",ansx,ansy);
    return 0;
}