#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e5+5;
int N,M,Ans,A[Mxn],B[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
bool Check() {
	For(i,1,N) {
		int c=1;
		while(B[i+1]==B[i]) ++i,++c;
		if(c>A[B[i]]) return 0;
	} 
	return 1;
}
void DFS(int x) {
	if(x>N) {Ans+=Check();return ;}
	For(i,1,M) B[x]=i,DFS(x+1);
}
signed main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	N=_(),M=_();
	For(i,1,M) A[i]=_();
	DFS(1);
	__(Ans);
	return 0;
}
