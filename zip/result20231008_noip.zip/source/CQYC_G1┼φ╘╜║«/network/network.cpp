#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define For(i,a,b) for(int i=a;i<=b;++i)
#define Rof(i,a,b) for(int i=a;i>=b;--i)
using namespace std;
const int Mxn=1e6+5; 
int N,Q,Rt,Ans,Tot,Fa[Mxn],Sz[Mxn],Sn[Mxn],Dp[Mxn],Tp[Mxn],Df[Mxn],Id[Mxn],Mn[Mxn];
int Sm[Mxn<<2];
int Ct,Nt[Mxn<<1],To[Mxn<<1],Hd[Mxn];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Merge(int x,int y) {
	Nt[++Ct]=Hd[x],To[Ct]=y,Hd[x]=Ct;
	Nt[++Ct]=Hd[y],To[Ct]=x,Hd[y]=Ct;
}
#define Md ((l+r)>>1)
#define Ls (x<<1)
#define Rs (Ls|1)
void Build(int x,int l,int r) {
	if(l==r) {Sm[x]=Id[l];return ;}
	Build(Ls,l,Md),Build(Rs,Md+1,r);
	Sm[x]=min(Sm[Ls],Sm[Rs]);
}
int Query(int x,int l,int r,int L,int R) {
//	pt("Query(%d %d %d) %d %d\n",x,l,r,L,R);
	if(L<=l&&r<=R) return Sm[x];
	int Res=N+1;
	if(L<=Md) Res=min(Res,Query(Ls,l,Md,L,R));
	if(R>Md) Res=min(Res,Query(Rs,Md+1,r,L,R));
	return Res;
}
void DFS(int x) {
//	pt("DFS(%d)\n",x);
	Sz[x]=1;
	for(int v,i=Hd[x];i;i=Nt[i]) {
		if((v=To[i])!=Fa[x]) {
			Fa[v]=x,Dp[v]=Dp[x]+1,DFS(v),Sz[x]+=Sz[v];
			Sn[x]=Sz[v]>Sz[Sn[x]]?v:Sn[x];
		}
	}
}
void Top(int x,int t,int s) {
//	pt("Top(%d %d %d)\n",x,t,s);
	Tp[x]=t,Df[x]=++Tot,Mn[x]=s,Id[Tot]=x;
	if(Sn[x]) Top(Sn[x],t,min(s,Sn[x]));
	for(int v,i=Hd[x];i;i=Nt[i]) {
		if((v=To[i])!=Fa[x]&&v!=Sn[x]) {
			Top(v,v,v);
		} 
	}
}
int GetMin(int x,int y,bool f) {
//	pt("GetMin:%d %d\n",x,y);
	int Res=N+1;
	while(Tp[x]!=Tp[y]) {
//		pt("<%d %d> %d %d\n",x,y,Tp[x],Tp[y]);
		if(Dp[Tp[x]]>Dp[Tp[y]]) Res=min(Res,Mn[x]),x=Fa[Tp[x]];
		else Res=min(Res,Mn[y]),y=Fa[Tp[y]];
	}
//	pt("[%d %d]\n",x,y);
	if(Dp[x]>Dp[y]) swap(x,y);
	if(f) Rt=x;
//	assert(Df[x]<=Df[y]);
	return min(Res,Query(1,1,N,Df[x],Df[y]));
}
signed main() {
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	N=_(),Q=_();
	For(i,2,N) Merge(_(),_());
	DFS(1);
	Top(1,1,1);
	Build(1,1,N);
//	For(i,1,N) pt("%d ",Sn[i]);pc('\n');
//	For(i,1,N) pt("%d ",Tp[i]);pc('\n');
//	For(i,1,N) pt("%d ",Mn[i]);pc('\n');
	while(Q--) {
		char Str[10];
//		pt("!!!\n");
		scanf("%s",Str+1);
//		pt("%s",Str+1);
		int x=_();
//		pt("Rt=%d\n",Rt);
		if(Str[1]=='J') {
//			pt("!!!\n");
			if(!Ans) Ans=Rt=x;
			else Ans=GetMin(Rt,x,1);
		}
		else {
//			pt("______________________________");
			__(min(Ans,GetMin(Rt,x,0))),pc('\n');
//	pt("Here!\n");
		}
	}
	return 0;
}
