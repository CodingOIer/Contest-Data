#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
int stk[10],tp;
inline void write(int x)
{
	if(!x) return puts("0"),void();
	tp=0;
	while(x) stk[++tp]=x%10,x/=10;
	while(tp) putchar(stk[tp--]^48);
	putchar('\n');
}
const int N=1e6+10,M=N<<1,maxj=20;
int n,q,dmn,dmx,lg[N],Tr1[N],Tr2[N],f[21][N];
int fa[N],ID[N],dep[N],dfn[N],num[N],son[N],top[N];
int first[N],to[M],nxt[M],cnt;
char a[N];
inline void Max(int &x,int y) {x=x>y?x:y;}
inline void Min(int &x,int y) {x=x>y?y:x;}
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void addMx(int x,int y) {for(;x<=n;x+=(x&-x)) Max(Tr1[x],y);}
int queryMx(int x,int res=0) {for(;x;x-=(x&-x)) Max(res,Tr1[x]);return res;}
void addMn(int x,int y) {for(;x;x-=(x&-x)) Min(Tr2[x],y);}
int queryMn(int x,int res=1e9) {for(;x<=n;x+=(x&-x)) Min(res,Tr2[x]);return res;}
void dfs1(int x,int fr)
{
	fa[x]=fr;num[x]=1;
	dep[x]=dep[fr]+1;
	for(int i=first[x],v;i;i=nxt[i])
	{
		if((v=to[i])==fr) continue;
		dfs1(v,x);num[x]+=num[v];
		if(num[son[x]]<num[v]) son[x]=v;
	}
}
void dfs2(int x,int t)
{
	top[x]=t;
	ID[dfn[x]=++cnt]=x;
	if(!son[x]) return;
	dfs2(son[x],t);
	for(int i=first[x],v;i;i=nxt[i])
		if((v=to[i])!=fa[x]&&v!=son[x]) dfs2(v,v);
}
int query(int l,int r)
{
	int k=lg[r-l+1];
	return min(f[k][l],f[k][r-(1<<k)+1]);
}
int Query(int x,int y)
{
	int res=n;
	while(top[x]!=top[y])
	{
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		Min(res,query(dfn[top[x]],dfn[x])),x=fa[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);
	Min(res,query(dfn[y],dfn[x]));
	return res;
}
void solve(int &res,int x)
{
	if(res==1) return;
	Min(res,x);
	int p=queryMn(dfn[x]);
	if(p<=n)
	{
		if(dfn[x]==p) return;
		Min(res,Query(x,ID[p]));
	}
	else if(dmn<=n) Min(res,Query(x,ID[dmn]));
	p=queryMx(dfn[x]);
	if(p) Min(res,Query(x,ID[p]));
	else if(dmx) Min(res,Query(x,ID[dmx]));
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	for(int i=2;i<N;i++) lg[i]=lg[i>>1]+1;
	memset(Tr2,0x3f,sizeof(Tr2));
	n=read(),q=read();
	dmn=n+1;
	for(int i=1,u,v;i<n;i++)
		u=read(),v=read(),inc(u,v),inc(v,u);
	dfs1(1,0);cnt=0;dfs2(1,1);
	for(int i=1;i<=n;i++) f[0][i]=ID[i];
	for(int i=1;i<=maxj;i++)
		for(int j=1;j+(1<<i)-1<=n;j++)
			f[i][j]=min(f[i-1][j],f[i-1][j+(1<<(i-1))]);
	int x,ans,res=n;
	while(q--)
	{
		scanf("%s",a+1);x=read();
		if(a[1]=='J')
			solve(res,x),
			Min(dmn,dfn[x]),Max(dmx,dfn[x]),
			addMn(dfn[x],dfn[x]),addMx(dfn[x],dfn[x]);
		else ans=res,solve(ans,x),write(ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
