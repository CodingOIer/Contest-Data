#include<bits/stdc++.h>
using namespace std;
const int N=110,mod=1e9+7;
int n,k,ans,pw[N],dp[N*N],cpy[N*N];
inline void Max(int &x,int y) {x=x>y?x:y;}
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int main()
{
	freopen("stone.in","r",stdin);
	freopen("stone.out","w",stdout);
	cin>>n>>k;
	pw[0]=1;
	for(int i=1;i<=n;i++) pw[i]=1ll*(k+1)*pw[i-1]%mod;
	int Mx=0;
	cpy[0]=1;
	for(int i=n,rec;i;i--)
	{
		rec=Mx;
		for(int j=0;j<=k;j++)
			for(int p=rec;~p;p--)
				if(i<j) upd(ans,1ll*(j+p)*cpy[p]%mod*pw[i-1]%mod),upd(dp[p],cpy[p]);
				else upd(ans,1ll*((j+p)%i)*cpy[p]%mod*pw[i-1]%mod),upd(dp[p+(j+p)/i],cpy[p]),Max(Mx,p+(j+p)/i);
		for(int j=0;j<=Mx;j++) cpy[j]=dp[j],dp[j]=0;
	}
	cout<<ans<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}

