#include<bits/stdc++.h>
using namespace std;
const int N=5010,mod=998244353;
int n,m,ans,dp1[N],dp2[N],pw[N],tot[N],he[N],num[N],INV[N];
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
	}
	return res;
}
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,x;i<=m;i++)
		scanf("%d",&x),++he[x+1];
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j+=i) num[j]+=he[i];
	pw[0]=1;
	for(int i=1;i<=n;i++) pw[i]=1ll*m*pw[i-1]%mod;
	for(int i=1;i<=n;i++) INV[i]=ksm(pw[i],mod-2);
	ans=pw[n];
	for(int i=1;i<=n;i++)
	{
		upd(tot[i],tot[i-1]);
		dp1[i]=dp2[i];
		upd(dp1[i],1ll*tot[i]*pw[i]%mod);
		for(int j=i+1,T;j<=n;j++)
		{
			if(i==1) T=1;
			else
			{
				if(m==1) continue;
				T=pw[i-1],upd(T,mod-dp1[i-1]);
			}
			upd(dp2[j],1ll*T*num[j-i+1]%mod);
			upd(tot[j+1],1ll*T*num[j-i+1]%mod*(m-1)%mod*INV[j+1]%mod);
		}
	}
	upd(ans,mod-dp1[n]);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
