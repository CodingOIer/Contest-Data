#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 105 ;
const int MOD = 1e9+7 ;
const int M = 4005 ;
int n,k,ans ;
int a[N],b[N],f[N][M],g[N][M] ;
// map<ull,int>f ;
void Check()
{
    FOR(i,1,n,1) b[i] = a[i] ;
    FOR(i,1,n,1)
    {
        if(b[i] == i)
        {
            b[i] = 0 ;
            FOR(j,1,i-1,1) b[j]++ ;
            i = 0 ;
        }
    }
    FOR(i,1,n,1) ans += b[i] ;
    // FOR(i,1,n,1) print(b[i]),h = h*233+b[i] ; enter ;
}
void Dfs(int x)
{
    if(x == n+1) {Check() ; return ;}
    FOR(i,0,k,1) a[x] = i,Dfs(x+1) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("stone.in","r",stdin) ;
	freopen("stone.out","w",stdout) ;
    read(n,k) ; //Dfs(1),print(ans) ; enter ;
    FOR(j,0,M-5,1) g[0][j] = 1 ;
    FOR(i,1,n,1)
    {
        FOR(j,0,M-5,1) 
        {
            FOR(l,0,k,1)
            {
                if(l > i)  f[i][j] += g[i-1][j]*(l+j)%MOD+f[i-1][j],f[i][j] %= MOD,g[i][j] += g[i-1][j],g[i][j] %= MOD ;
                else f[i][j] += ((j+l)%i)*g[i-1][j+(j+l)/i]%MOD+f[i-1][j+(j+l)/i],f[i][j] %= MOD,g[i][j] += g[i-1][j+(j+l)/i],g[i][j] %= MOD ; 
            }
        }
    }
    print(f[n][0]) ; 
    return 0 ;
}