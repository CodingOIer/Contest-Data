#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
namespace superio{
    #define getchar my_getchar
    #define putchar my_putchar
    #define puts my_puts
    const int Isize = 1<<22,Osize = 1<<20;
    char ibuf[Isize],obuf[Osize];
    char *p1=ibuf,*p2=ibuf;
    int otop;
    class Oclear{
        public:
            inline void clear() {fwrite(obuf,sizeof(char),otop,stdout);otop=0;}
            ~Oclear() {clear();}
    }oclear;
    inline char getchar() {return p1==p2&&(p2=(p1=ibuf)+fread(ibuf,sizeof(char),sizeof(ibuf),stdin),p1==p2)?EOF:*p1++;}
    inline void putchar(const char c) {obuf[otop++]=c;if(otop==Osize)oclear.clear();}
    inline void puts(const char *s) {while(*s!='\0'){putchar(*s);s++;}putchar('\n');}
    int stk[30],tp;

    inline void read(int &x){
        x =  0 ; int r=0,f=1;char c=getchar();
        while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
        while(isdigit(c))x=x*10+(c^48),c=getchar();
        x *= f ;
    }
    inline void print(int x){
        if(x<0){
            putchar('-');
            x = -x;
        }
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
    }
}
using superio::read;
using superio::print;
using superio::puts;
using superio::getchar;
using superio::putchar;
bool S_GND ;
const int N = 6e5+5 ;
const int INF = 1e9+7 ;
int n,q,top,idx,cnt,ttp,mi,mii,mxx,mx,rs = INF ;
int pe[N],son[N],dep[N],gs[N] ;
int a[N],fa[N],val[N],dfn[N],pos[N],sz[N],fk[N] ;
int FK[N],DFN[N],SZ[N],DEP[N],FA[N],SON[N],PE[N] ,vis[N];
struct Node{int v,w ;} ;
struct Edge{int u,v,w ;}E[N] ;
vector<int>e[N],g[N] ;
int cmp(Edge x,Edge y)
{
    return x.w > y.w ;
}
int get(int x) {return fa[x]==x?x:fa[x]=get(fa[x]) ;}
void Merge(int x,int y,int w)
{
    x = get(x),y = get(y) ; if(x == y) return ;
    val[++top] = w,fa[x] = top,fa[y] = top,e[top].pb(x),e[top].pb(y) ;// print(top,x,w),enter,print(top,y,w),enter ;
}
void Dfs1(int x)
{
    sz[x] = 1 ;
    for(auto v:e[x]) fa[v] = x,dep[v] = dep[x]+1,Dfs1(v),sz[x] += sz[v],son[x] = sz[son[x]]<sz[v]?v:son[x] ;
}
void Dfs2(int x,int tops)
{
    dfn[x] = ++idx,pos[idx] = x,pe[x] = tops ;
    if(!son[x]) return ; Dfs2(son[x],tops) ; for(auto v:e[x]) if(v != son[x]) Dfs2(v,v) ; 
}
int Lca(int u,int v)
{
    while(pe[u] != pe[v])
    {
        if(dep[pe[u]] < dep[pe[v]]) swap(u,v) ;
        u = fa[pe[u]] ;
    }
    return dep[v]>dep[u]?u:v ;
    // while(u != v)
    // {
    //     if(dep[u] > dep[v]) u = fa[u] ;
    //     else if(dep[u] < dep[v]) v = fa[v] ;
    //     else if(dep[u] == dep[v]) u = fa[u],v = fa[v] ;
    // } return u ;
}
int LCA(int u,int v)
{
    while(PE[u] != PE[v])
    {
        if(DEP[PE[u]] < DEP[PE[v]]) swap(u,v) ;
        u = FA[PE[u]] ;
    }
    return DEP[v]>DEP[u]?u:v ;
    // while(u != v)
    // {
    //     if(DEP[u] > DEP[v]) u = FA[u] ;
    //     else if(DEP[u] < DEP[v]) v = FA[v] ;
    //     else if(DEP[u] == DEP[v]) u = FA[u],v = FA[v] ;
    // } return u ;
}
void Dfss1(int x)
{
    SZ[x] = 1,DEP[x] = DEP[FA[x]]+1 ;
    for(auto v:g[x]) if(v != FA[x])
    {
        E[++cnt] = {x,v,v},FA[v] = x,Dfss1(v) ;
        SZ[x] += SZ[v] ; if(SZ[v] > SZ[SON[x]]) SON[x] = v ;
    }
}
void Dfss2(int x,int tops)
{
    PE[x] = tops,DFN[x] = ++ttp ;
    if(!SON[x]) return ; Dfss2(SON[x],tops) ;
    for(auto v:g[x]) if(v != FA[x] && v != SON[x]) Dfss2(v,v) ;
}
void Dfs(int x)
{
    vis[x] = 1,sz[x] = gs[x] ;
    for(auto v:g[x]) if(!vis[v])
        Dfs(v),sz[x] += sz[v] ;
}
void Solve(int x)
{
    // int lca = Lca(Lca(mi,mx),x) ;
    // me(vis,0),me(sz,0),Dfs(x) ; int res = INF ;
    // FOR(i,1,n,1) if(sz[i] && i != lca) res = min(res,i) ; print(res),enter ;
    int lca = Lca(Lca(mii,mxx),x) ;
    print(min(lca<=n?INF:val[lca],LCA(LCA(mi,mx),x))),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("network.in","r",stdin) ;
	freopen("network.out","w",stdout) ;
    read(n),read(q) ;
    FOR(i,2,n,1)
    {
        int u,v,w ; read(u),read(v) ;
        g[u].pb(v),g[v].pb(u) ;
    }
    Dfss1(1),Dfss2(1,1),cnt = 0 ;
    FOR(i,1,2*n,1) fa[i] = i ;
    sort(E+1,E+n,cmp),top = n ;
    FOR(i,1,n-1,1) Merge(E[i].u,E[i].v,E[i].w) ;
    me(fa,0),Dfs1(top),Dfs2(top,top),mi = mx = 0 ;
    while(q--)
    {
        char s[10] ; int x ;
        scanf("%s",s),read(x) ;
        if(s[0] == 'J')
        {
            // rs = min(rs,x),gs[x] = 1 ;
            if(!mi) mi = x ;
            if(!mx) mx = x ;
            if(DFN[x] < DFN[mi]) mi = x ;
            if(DFN[x] > DFN[mx]) mx = x ;
            if(!mii) mii = x ;
            if(!mxx) mxx = x ;
            if(dfn[x] < dfn[mii]) mii = x ;
            if(dfn[x] > dfn[mxx]) mxx = x ;
        }
        else Solve(x) ;
    }//cerr<<clock()/1000.0 ;
    // FOR(i,n+1,2*n,1) if(val[i] == 141) cerr<<i<<"\n" ;
    return 0 ;
}