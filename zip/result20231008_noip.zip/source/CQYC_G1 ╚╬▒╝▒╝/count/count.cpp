#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 5e3+5 ;
const int MOD = 998244353 ;
int n,m,ans,top ;
int a[N],f[N][N],sum[N],b[N],tot[N] ;
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("count.in","r",stdin) ;
	freopen("count.out","w",stdout) ;
    read(n,m),sum[1] = m ;
    FOR(i,1,m,1) read(a[i]),b[i] = a[i],tot[a[i]]++ ;
    sort(b+1,b+1+m),top = unique(b+1,b+1+m)-b-1 ;
    FOR(i,1,top,1) f[1][i] = tot[b[i]] ;
    FOR(i,2,n,1)
    {
        sum[i] = sum[i-1] ;
        FOR(j,1,top,1) 
        {
            f[i][j] = (i<=b[j])*tot[b[j]] ;
            f[i][j] += (sum[i-1]-sum[max(0ll,i-b[j]-1)])*tot[b[j]]-f[i-1][j]+f[max(0ll,i-b[j]-1)][j]+MOD,f[i][j] %= MOD ;
            sum[i] += f[i][j],f[i][j] += f[i-1][j],f[i][j] %= MOD,sum[i] %= MOD ;
        }
    }
    FOR(i,1,m,1) ans = (ans+f[n][i]-f[n-1][i]+MOD)%MOD ; print(ans) ;
    return 0 ;
}