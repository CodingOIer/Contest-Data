#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 2e5+5 ;
int n,sumx,sumy,mi = 1e9,mx = -1e9 ;
int a[N],b[N],X[N],Y[N] ;
int get(int A,int B,int C,int D)
{
    return abs((A-C)*(B-D)) ;
}
void Solve1()
{
    int ans1 = 0,ans2 = 0,res = 1e18 ;
    FOR(x,-100,100,1) FOR(y,-100,100,1)
    {
        int now = 0 ;
        FOR(i,1,n,1) now += get(x,y,a[i],b[i]) ;
        if(now < res) res = now,ans1 = x,ans2 = y ;
    }
    print(ans1,ans2) ;
}
mt19937 rd(time(0)) ;
int calc(int x,int y)
{
    int res = 0 ;
    FOR(i,1,n,1) res += get(x,y,a[i],b[i]) ;
    return res ;
}
void Solve2()
{
    int rx = sumx/n,ry = sumy/n,now = calc(rx,ry) ;
    while(clock()/1000.0 <= 0.9)
    {
        int px = rx,py = ry ;
        int op1 = rd()&1,op2 = rd()&1,w = rd()%3 ;
        if(op1) px += w ;
        else px -= w ;
        if(op2) py += w ;
        else py -= w ;
        int res = calc(px,py) ; //print(px,py),enter ;
        if(res < now) rx = px,ry = py,now = res ;
    }
    print(calc(rx,ry)) ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("synd.in","r",stdin) ;
	freopen("synd.out","w",stdout) ;
    read(n) ;
    FOR(i,1,n,1) read(a[i],b[i]),sumx += a[i],sumy += b[i],mi = min({mi,a[i],b[i]}),mx = max({mx,a[i],b[i]}) ;
    if(mi >= -100 && mx <= 100) Solve1() ;
    else Solve2() ;
    return 0 ;
}