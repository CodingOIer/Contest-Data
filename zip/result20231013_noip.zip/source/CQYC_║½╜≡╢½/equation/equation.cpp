#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define dl double
#define pk push_back
#define fi first
#define se second
#define pii pair<int,int>
#define N 10000010
#define inf (int)(1000000000000000000)
// #define mod 998244353
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);ch=getchar();
	}
	return x*f;
}
char f__[40];
il void write(int x){
	int cnt=0;
	if(x<0){
		putchar('-');x=-x;
	}
	if(!x) putchar('0');
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,mod,fac[N],inv[N];
il int Pow(int a,int b){
    // cerr<<a<<
	int res=1;
	while(b){
		if(b&1) res=res*a%mod;
		a=a*a%mod;b>>=1;
	}
	return res;
}
il void Add(int &a,int b){
    a=a+b>=mod?a+b-mod:a+b;
}
il void init(){
    fac[0]=1;
    for(int i=1;i<mod;++i) fac[i]=fac[i-1]*i%mod;
    // cerr<<fac[N-1]<<" ";
    inv[mod-1]=Pow(fac[mod-1],mod-2);
    // cerr<<inv[N-1]<<" ";
    for(int i=mod-1;i;--i) inv[i-1]=inv[i]*i%mod;
    // exit(0);
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	T=read();mod=read();init();
    while(T--){
        int a=read(),d=read(),n=read();
        int tmp=a;
        a=a*Pow(d,mod-2)%mod;
        // cerr<<Pow(d,mod-2)<<" ";
        // cerr<<(n-1+a)/mod<<" "<<a/mod<<"\n";
        if((n-1+a)/mod!=a/mod){
            // cerr<<"ERROR";
            puts("0");continue;
        }
        int l=a,r=(n-1+a)%mod;
        // cerr<<l<<" "<<r<<"\n";
        // if(l>r) cerr<<"ERROR";
        // cerr<<fac[r]<<" ";
        // cerr<<(l?inv[l-1]:1)%mod<<"\n";
        write(Pow(d,n-1)*fac[r]%mod*inv[l]%mod*tmp%mod);putchar('\n');
    }
    // cerr<<inv[1]<<" "<<inv[2]<<"\n";
    cerr<<"\n"<<(dl)clock()/CLOCKS_PER_SEC;
	return 0;
}