//1s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,INF=1e9+10,Lim=1000010;
int N,M,hed[Maxn],cnt,tot;
struct node{int nxt,to;}G[Maxn<<1];

void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}

int DFS(int x,int d){
    ++tot; if(tot>Lim) return x;
    int tt=(d?INF:0);
    for(int y,i=hed[x];i;i=G[i].nxt){
        int c=DFS(y=G[i].to,d^1);
        if(!d) tt=max(tt,c); else tt=min(tt,c);
    }
    if(tt==INF) return x;
    return max(x,tt);
}

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    N=read(),M=read();
    For(i,1,M){
        int x=read(),y=read();
        Addedge(x,y);
    }
    For(i,1,N) tot=0,write(DFS(i,0)),pc(' ');
    // cerr<<"[Clock]="<<clock()<<"\n";
    return 0;
}
