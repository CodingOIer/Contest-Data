//1s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

const int Maxn=1e5+10,Mod=998244353;
int N,S,V[Maxn],hed[Maxn],cnt,Vis[Maxn];
int A[Maxn],Sum,Ans;
struct node{int nxt,to;}G[Maxn<<1];
bool f;

void MOD(int &x){if(x>=Mod) x-=Mod;}
void Addedge(int x,int y){G[++cnt]=(node){hed[x],y}; hed[x]=cnt;}
int Power(int x,int d,int r=1){
    while(d){if(d&1) (r*=x)%=Mod; (x*=x)%=Mod,d>>=1;}
    return r;
}

void DFS(int x){
    ++Vis[x]; int c=0;
    for(int y,i=hed[x];i;i=G[i].nxt) {
        if(Vis[y=G[i].to]==2) continue;
        DFS(y); ++c;
    }
    if(!c) MOD(++A[x]),MOD(++Sum);
    --Vis[x];
}

signed main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    N=read(),S=read();
    For(i,1,N) V[i]=read();
    For(i,1,N-1){
        int x=read(),y=read();
        Addedge(x,y),Addedge(y,x);
        if(x!=S&&y!=S) f=1;
    }
    if(!f){ For(i,1,N) if(i!=S) A[i]=N-1,Sum+=N-1; }
    else DFS(S);
    // For(i,1,N) cout<<A[i]<<" ";puts("");
    For(i,1,N) (Ans+=V[i]*A[i]%Mod)%=Mod;
    write(Ans*Power(Sum,Mod-2)%Mod);
    return 0;
}
/*
3 3
1 2 3
1 2
2 3

1 0 2
2 0 2

4 4
1 1 1 1
1 2
2 3
3 4
2 0 0 3
3 0 0 3

5 4
1 1 1 1 1
1 2
2 3
3 4
4 5
3 0 1 0 5
4 0 1 0 5
4 0 0 0 4

6 4
1 1 1 1 1 1
1 2
2 3
3 4
4 5
5 6
4 0 2 1 0 8
5 0 2 1 0 8
5 0 0 2 0 7
*/