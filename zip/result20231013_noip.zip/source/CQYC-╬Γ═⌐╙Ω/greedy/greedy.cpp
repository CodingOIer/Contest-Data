//2s 1024M
#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define ls (id<<1)
#define rs ((id<<1)|1)
#define mid ((l+r)>>1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int stk[30],tp=0;
    while(x) stk[++tp]=x%10,x/=10;
    while(tp) pc('0'+stk[tp--]);
    return;
}

bool ttt;
const int Maxn=610,Maxm=2e7+10,base=1e7;
int M,L,A[Maxn],f[3][Maxm],c;
bool flg;
bool ppp;

void Max(int &x,int y){if(x<y) x=y;}

void Solve0(){
    if(abs(L)>base) puts("impossible"),exit(0);
    memset(f,-1,sizeof f);
    f[1][base]=0;
    For(i,1,(M<<1)+1){
        int t=i-M-1; c^=1;
        For(j,0,base+L) if(f[c][j]!=-1){
            For(k,0,A[i]) Max(f[c^1][j+t*k],f[c][j]+k);
            f[c][j]=-1;
        }
    }
    if(f[c^1][L+base]==-1) puts("impossible");
    else write(f[c^1][L+base]);
}

int main(){
    freopen("greedy.in","r",stdin);
    freopen("greedy.out","w",stdout);
    // cerr<<"[Memory]="<<((&ppp)-(&ttt))/1024.0/1024.0<<"\n";
    M=read(),L=read(); 
    For(i,1,(M<<1)+1){
        A[i]=read();
        if(A[i]>100) flg=1;
    }
    if(!flg) Solve0(),exit(0);
    return 0;
}