#include <bits/stdc++.h>
using namespace std;
int n, m;
int c[2][200000], f[2][200000];
vector<int> e[200000];
int dfs(bool b, int x)
{
    if (c[b][x] == -1)
        return f[b][x];
    if (++c[b][x] > 16)
        return x;
    f[b][x] = b ? INT_MAX : x;
    for (int y : e[x])
        f[b][x] = b ? min(f[1][x], dfs(0, y)) : max(f[0][x], dfs(1, y));
    c[b][x] = -1;
    if (b)
        f[1][x] = max((f[1][x] != INT_MAX) * f[1][x], x);
    return f[b][x];
}
int main()
{
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1, x, y; i <= m; i++)
        scanf("%d%d", &x, &y), e[x].push_back(y);
    for (int i = 1; i <= n; i++)
        printf("%d ", dfs(0, i));
    puts("");
    return 0;
}