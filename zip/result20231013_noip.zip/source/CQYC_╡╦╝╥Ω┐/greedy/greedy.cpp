#include <bits/stdc++.h>
using namespace std;
long long m, l, ans;
long long a[800];
int main()
{
    freopen("greedy.in", "r", stdin);
    freopen("greedy.out", "w", stdout);
    scanf("%lld%lld", &m, &l);
    for (long long i = 0; i <= m * 2; i++)
        scanf("%lld", &a[i]), l -= a[i] * (i - m), ans += a[i];
    if (l < 0)
        l = -l, reverse(a, a + m * 2 + 1);
    for (long long i = 0; i < m; i++)
    {
        long long x = min(a[i], l / (m - i));
        l += x * (i - m);
        a[i] -= x;
        ans -= x;
        if (a[i])
            break;
    }
    for (long long i = 0; l && i <= m * 2; i++)
        if (a[i] && l == m - i)
            l = 0, ans--;
    for (long long i = 0; l && i <= m * 2; i++)
        for (long long j = 0; a[i] && j <= m * 2; j++)
            if (a[j] && l == m * 2 - i - j && (i != j || a[i] > 1))
                l = 0, ans -= 2;
    for (long long i = 0; l && i <= m * 2; i++)
        for (long long j = 0; a[i] && j <= m * 2; j++)
            for (long long k = 0; a[j] && k <= m * 2; k++)
                if (a[k] && l == m * 3 - i - j - k && ((i != j && i != k && j != k) || (i == j && i != k && a[i] > 1) || (i == k && i != j && a[i] > 1) || (j == k && i != j && a[j] > 1) || (i == j && j == k && a[i] > 2)))
                    l = 0, ans -= 3;
    for (long long i = 0; i < m; i++)
    {
        long long x = min(a[i], l / (m - i));
        l += x * (i - m);
        ans -= x;
    }
    if (l)
        puts("impossible");
    else
        printf("%lld\n", ans);
    return 0;
}