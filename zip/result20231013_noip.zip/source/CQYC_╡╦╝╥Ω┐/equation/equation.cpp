#include <bits/stdc++.h>
using namespace std;
int t, p, a, d, n, x;
int fac[20000000];
void read(int &x)
{
    char c = getchar();
    while (!isdigit(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
int power(int x, int y)
{
    int res = 1;
    while (y)
    {
        if (y % 2)
            res = 1ll * res * x % p;
        x = 1ll * x * x % p;
        y /= 2;
    }
    return res;
}
int main()
{
    freopen("equation.in", "r", stdin);
    freopen("equation.out", "w", stdout);
    read(t);
    read(p);
    for (int i = fac[0] = 1; i < p; i++)
        fac[i] = 1ll * fac[i - 1] * i % p;
    while (t--)
        read(a), read(d), read(n), x = 1ll * (a - d + p) * power(d, p - 2) % p, printf("%lld\n", 1ll * fac[n + x] * power(fac[x], p - 2) % p * power(d, n) % p);
    return 0;
}