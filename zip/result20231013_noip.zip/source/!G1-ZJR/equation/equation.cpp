#include<bits/stdc++.h>
using namespace std;
int p;
inline long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1) (res *= a) %= p;
		(a *= a) %= p;
		b >>= 1;
	}
	return res;
}
int T,a,d,n;
long long res[10000011];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	cin >> T >> p;
	for(int k = 1;k <= T;k++)
	{
		cin >> a >> d >> n;
		res[0] = 1;
		int cnt = 0,ed = (a + p - d) % p;
		for(int i = 1,nans = a;i <= n;i++)
		{
			res[i] = res[i - 1] * nans % p;
			if(nans == ed)
			{
				cnt = i;
				break;
			}
			nans += d;
			if(nans >= p) nans -= p;
		}
		if(!cnt)
		{
			cout << res[n] << "\n";
		}else{
			cout << qmi(res[cnt],n / cnt) * res[n % cnt] % p << "\n";
		}
	}
	return 0;
}
