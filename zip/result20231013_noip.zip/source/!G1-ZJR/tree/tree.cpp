#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
inline long long qmi(long long a,int b)
{
	long long res = 1;
	while(b)
	{
		if(b & 1) (res *= a) %= mod;
		(a *= a) %= mod;
		b >>= 1;
	}
	return res;
}
long long f[100011][2],Bk[100011],nSn[100011],nSz[100011],Rt[100011];//Bk:u->v->...(or none)->u->fa[u] Rt:return to father in anyway
int Sn[100011];
vector<int> v[100011];
int fa[100011];
long long a[100011];
inline void Clac(int p)
{
	Sn[p] = v[p].size() - (fa[p] ? 1 : 0);
	nSn[p] = qmi(Sn[p],mod - 2),nSz[p] = qmi(v[p].size(),mod - 2);
	for(auto i:v[p]) if(i != fa[p])
	{
		fa[i] = p;
		Clac(i);
		Bk[p] += nSz[p] * Bk[i] % mod * qmi(v[p].size() - 1,mod - 2) + nSz[p] * nSz[i] % mod * nSz[p];
		Bk[p] %= mod;
	}
	Rt[p] = nSz[p];
	for(auto i:v[p]) if(i != fa[p])
	{
		Rt[p] += nSz[p] * (Rt[i] + mod - Bk[i]) % mod * nSz[p] + nSz[p] * Bk[i] % mod * qmi(v[p].size() - 1,mod - 2);
		Rt[p] %= mod;
	}
}
long long ans;
inline void DFS(int p)
{
	long long Sbk = 0,Srt = 0;
	for(auto i:v[p]) if(i != fa[p])
	{
		f[i][1] = f[p][0] * nSn[p] % mod * nSz[i] % mod * nSn[p] % mod;
		(Sbk += nSn[p] * Bk[i]) %= mod;
		(Srt += nSn[p] * (Rt[i] + mod - Bk[i])) %= mod;
	}
	for(auto i:v[p]) if(i != fa[p])
		f[i][0] = ((nSn[p] * (Srt + mod - nSn[p] * (Rt[i] + mod - Bk[i]) % mod) + qmi(Sn[p] - 1,mod - 2) * (Sbk + mod - nSn[p] * Bk[i] % mod)) % mod * f[p][0] + nSn[p] * (mod + 1 - Rt[i]) % mod * f[p][0] + nSn[p] * f[p][1]) % mod;
	if(Sn[p] <= 1)
	{
		long long res = 0;
		if(!Sn[p]) res = f[p][0] + f[p][1];
		else
			for(auto i:v[p]) if(i != fa[p])
				res = Bk[i] * (f[p][0] + f[p][1]) % mod;
		ans += res * a[p];
		ans %= mod;
	}
	for(auto i:v[p]) if(i != fa[p])
		DFS(i);
}
int n,S;
int x,y;
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> n >> S;
	for(int i = 1;i <= n;i++) cin >> a[i];
	for(int i = 1;i < n;i++)
	{
		cin >> x >> y;
		v[x].push_back(y),v[y].push_back(x);
	}
	Clac(S);
	f[S][0] = 1;
	DFS(S);
	cout << ans;
	return 0;
}
