#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=605;
int n,m,li,w[N],f[N*N];
ll a[N],d,s,as;
struct thing{int v,w;}b[N<<4];
inline void add(ll u,int v,int w){
    u=min(u,(ll)n<<1);
    for(int i=1;i<=u;i<<=1) b[++m]=(thing){i*v,i*w},u-=i;
    if(u) b[++m]=(thing){(int)u*v,(int)u*w};
}
inline void gmx(int &u,int v){u=u>v?u:v;}
int main(){
    freopen("greedy.in","r",stdin);
    freopen("greedy.out","w",stdout);
    cin>>n>>d;
    for(int i=0,u=-n;i<=(n<<1);i++,u++) scanf("%lld",&a[i]),s+=a[i]*(w[i]=u);
    if(s<d) reverse(a,a+(n<<1|1)),d=-d;s=0;
    for(int i=0;i<=n;i++) s+=a[i]*w[i],as+=a[i],add(a[i],-w[i],-1);
    if(s>d) puts("impossible"),exit(0);
    for(int i=n+1;i<=(n<<1);i++){
        if(s+a[i]*w[i]<=d) s+=a[i]*w[i],as+=a[i],add(a[i],-w[i],-1);
        else{
            ll u=(d-s)/w[i];s+=u*w[i];
            add(u,-w[i],-1);as+=u;
            reverse(b+1,b+m+1);
            add(a[i]-u,w[i],1);
            for(int j=i+1;j<=(n<<1);j++) add(a[j],w[j],1);
            break;
        }
    }
    memset(f,200,sizeof f);f[0]=0;
    reverse(b+1,b+m+1);li=n*n<<1;
    for(int i=1;i<=m;i++){
        if(b[i].v<0) for(int j=0;j<=b[i].v+li;j++) gmx(f[j],f[j-b[i].v]+b[i].w);
        else for(int j=li;j>=b[i].v;j--) gmx(f[j],f[j-b[i].v]+b[i].w);
    } 
    if(f[d-s]<=f[li+1]) puts("impossible"),exit(0);
    cout<<as+f[d-s];
}