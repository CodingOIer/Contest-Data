#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N = 1e7 + 3;
int T, mod, fac[N], rfac[N];
int ksm(int a, int b){
    int res = 1;
    for(;b;b >>= 1, a = (LL)a * a % mod)
        if(b & 1) res = (LL)res * a % mod;
    return res;
}
int main(){
    ios::sync_with_stdio(0);
    freopen("equation.in", "r", stdin);
    freopen("equation.out", "w", stdout);
    cin >> T >> mod; *fac = 1;
    for(int i = 1;i < mod;++ i) fac[i] = (LL)fac[i - 1] * i % mod;
    rfac[mod - 1] = ksm(fac[mod - 1], mod - 2);
    for(int i = mod - 1;i;-- i) rfac[i - 1] = (LL)rfac[i] * i % mod;
    while(T --){
        int a, d, n;
        cin >> a >> d >> n;
        if(!d) printf("%d\n", ksm(a, n));
        else {
            a = (LL)a * rfac[d] % mod * fac[d - 1] % mod;
            printf("%d\n", (!a || a + n > mod) ? 0 : (LL)fac[a + n - 1] * rfac[a - 1] % mod * ksm(d, n) % mod);
        }
    }
}