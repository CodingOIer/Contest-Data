#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5,INF=1e9;
int n,m;
vector <int> G[N];
int in[N],f[N];
bool vis[N];

queue <int> q;

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++) f[i+n]=INF;
    for(int i=1;i<=m;i++){
        int u,v; scanf("%d%d",&u,&v);
        in[u+n]++,in[u]++;
        G[v].push_back(u+n),G[v+n].push_back(u);
    }
    for(int t=n;t>=1;t--){
//      cout<<t<<": "<<'\n';
        if(!vis[t]) q.push(t),f[t]=t,vis[t]=1;
        if(!vis[t+n]) q.push(t+n),f[t+n]=t,vis[t+n]=1;
        while(q.size()){
            int u=q.front(); q.pop();
            for(int v: G[u]){
                if(v<=n) f[v]=max(f[v],f[u]);
                else f[v]=min(f[v],max(v-n,f[u]));
                in[v]--;
//              cout<<" "<<v<<": "<<f[v]<<'\n';
                if(!vis[v] && (!in[v] || (v<=n && f[v]>=t))){
                    vis[v]=1;
                    q.push(v);
                }
            }
        }
        
    }
    for(int i=1;i<=n;i++) cout<<f[i]<<" "; //cout<<'\n';
//  for(int i=1;i<=n;i++) cout<<f[i+n]<<" "; cout<<'\n';
}