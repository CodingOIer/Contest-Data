#include<bits/stdc++.h>
#define reg register
#define maxn 100010
#define mod 998244353
#define A(x,y) x=(x+y)%mod
#define getchar() (_S==_T&&(_T=(_S=_B)+fread(_B,1,1<<15,stdin),_S==_T)?EOF:*_S++)
char _B[1<<15],*_S=_B,*_T=_B;
int read() {
	reg int s=0,f=1; reg char ch;
	for(;(ch=getchar())<'0'||ch>'9';ch=='-'?f=-f:0);
	for(;ch>='0'&&ch<='9';s=s*10+ch-'0',ch=getchar());
	return s*f;
}
int n,S,v[maxn],d[maxn],inv[maxn],f0[maxn],f1[maxn],f2[maxn],p[maxn];
struct edge{edge*nxt; int to;}e[maxn*2],*num=e,*first[maxn];
void adde(reg int a,reg int b) {*++num=(edge){first[a],b},first[a]=num,++d[b];}
void dfs(reg int x,reg int fa) {
	reg int D=d[x]-(fa>0);
	for(reg edge*i=first[x];i;i=i->nxt) if(i->to!=fa) dfs(i->to,x),A(f1[x],f0[i->to]);
	for(reg edge*i=first[x];i;i=i->nxt) if(i->to!=fa)
		A(f0[x],f2[i->to]+1ll*inv[d[i->to]]*inv[D]%mod*(0ll+f1[i->to]+f1[x]-f0[i->to])),
		D==1?A(f0[x],1ll*p[i->to]%mod*v[x]):A(f0[x],1ll*p[i->to]%mod*inv[D-1]%mod*(f1[x]-f0[i->to])),
		A(f2[x],f2[i->to]+1ll*inv[d[i->to]]*inv[d[x]]%mod*(0ll+f1[i->to]+f1[x]-f0[i->to])),
		A(f2[x],1ll*p[i->to]*inv[D]%mod*(f1[x]-f0[i->to])),
		A(p[x],1ll*p[i->to]*inv[D]+1ll*inv[d[i->to]]*inv[d[x]]);
	if(D) f0[x]=1ll*inv[D]*f0[x]%mod,f1[x]=1ll*inv[D]*f1[x]%mod,
		f2[x]=1ll*inv[d[x]]*f2[x]%mod,p[x]=1ll*inv[d[x]]*p[x]%mod;
	else f0[x]=f1[x]=v[x];
}
int main() {
	freopen("tree.in","r",stdin) ;
	freopen("tree.out","w",stdout);
	n=read(),S=read(),inv[0]=inv[1]=1;
	for(reg int i=1;i<=n;++i) v[i]=read();
	for(reg int i=2,x,y;i<=n;++i)
		x=read(),y=read(),adde(x,y),adde(y,x),inv[i]=1ll*-mod/i*inv[mod%i]%mod;
	dfs(S,0),printf("%d",(f0[S]+mod)%mod);
	return 0;
}
