#include <bits/stdc++.h>
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 205 ;
int T = N*N ;
int n,m,L ;
int a[N] ;
int f[N][2*N*N] ;
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
//	freopen(".in","r",stdin) ;
//	freopen(".out","w",stdout) ;
    read(n,L),m = n/2 ;
    FOR(i,1,n,1) read(a[i]) ;
    f[0][0] = 0,me(f,-1) ;
    FOR(i,1,n,1)
    {
        int p = i-m ;
        FOR(j,-N*N+5,N*N,1) FOR(k,0,a[i],1)
            f[i][j+k*p+T] = max(f[i][j+k*p+T],f[i][j+T]+k) ;
    }
    if(~f[n][T+L]) puts("impossible") ;
    else print(f[n][T+L]) ;
    return 0 ;
}