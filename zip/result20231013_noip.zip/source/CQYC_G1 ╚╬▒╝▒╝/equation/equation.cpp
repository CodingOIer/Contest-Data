#include <bits/stdc++.h>
#define int long long
#define rg register
#define pc putchar
#define gc getchar
#define pf printf
#define space pc(' ')
#define enter pc('\n')
#define me(x,y) memset(x,y,sizeof(x))
#define pb push_back
#define FOR(i,k,t,p) for(rg int i(k) ; i <= t ; i += p)
#define ROF(i,k,t,p) for(rg int i(k) ; i >= t ; i -= p)
using namespace std ;
bool s_gnd ;
inline void read(){}
template<typename T,typename ...T_>
inline void read(T &x,T_&...p)
{
    x = 0 ;rg int f(0) ; rg char c(gc()) ;
    while(!isdigit(c)) f |= (c=='-'),c = gc() ;
    while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
    x = (f?-x:x) ;
    read(p...);
}
int stk[30],tp ;
inline void print(){}
template<typename T,typename ...T_>
inline void print(T x,T_...p)
{
    if(x < 0) pc('-'),x = -x ;
    do stk[++tp] = x%10,x /= 10 ; while(x) ;
    while(tp) pc(stk[tp--]^48) ; space ;
    print(p...) ;
}
bool S_GND ;
const int N = 1e7+5 ;
const int M = 105 ;
int n,T,a,d,MOD ;
int fac[N],inv[N],f[M][M] ;
inline int Pow(int x,int p)
{
    int res = 1 ; while(p)
    {
        if(p&1) res = res*x%MOD ;
        x = x*x%MOD,p >>= 1 ;
    } return res ;
}
inline int C(int x,int y)
{
    if(x < y) return 0 ;
    return fac[x]*inv[y]%MOD*inv[x-y]%MOD ;
}
void Init()
{
    fac[0] = inv[0] = inv[1] = 1 ;
    FOR(i,1,N-5,1) fac[i] = fac[i-1]*i%MOD ;
    FOR(i,2,N-5,1) inv[i] = (MOD-MOD/i)*inv[MOD%i]%MOD ;
    FOR(i,2,N-5,1) inv[i] = inv[i-1]*inv[i]%MOD ;
    f[0][0] = 1 ;
    FOR(i,1,10,1)
    {
        f[i][0] = fac[i] ;
        FOR(j,1,i,1) f[i][j] = f[i-1][j]*i+f[i-1][j-1] ;//,print(i,j,f[i][j],C(i,j)),enter
    }
}
void exgcd(int a,int b,int &x,int &y)
{
	if(!b) x = 1,y = 0 ;
	else exgcd(b,a%b,y,x),y -= x*(a/b) ;
}
void Solve()
{
    // int k = min(n-1,)
    // int S =
     read(a,d,n),--n ; int res = a ;
    if(!a) {print(0),enter ; return ;} int x,y ; exgcd(d,MOD,x,y) ;
    if((d*x%MOD-MOD*y%MOD+MOD)%MOD != 1) x *= -1,y *= -1 ; x *= MOD-a,x %= MOD ;
    if(x < 0) x += -x/MOD*MOD ;
    if(x < 0) x += MOD ;// print(x),enter ;
    if(n > x) {print(0),enter ; return ;}
    FOR(i,1,n,1) res = res*(a+i*d%MOD)%MOD ; print(res),enter ;
    // FOR(i,0,n,1) res = (res+Pow(a,i)*Pow(d,n-i)%MOD*f[n][i]%MOD)%MOD ;
    // print(Pow(a+d,n)*a,res*a%MOD),enter ;
}
signed main()
{
//cerr<<(double)(&s_gnd-&S_GND)/1024.0/1024.0 ;
	freopen("equation.in","r",stdin) ;
	freopen("equation.out","w",stdout) ;
    // MOD = 1e9+7 ;
    read(T,MOD) ;
    // Init() ; 
    while(T--) Solve() ;

    return 0 ;
}