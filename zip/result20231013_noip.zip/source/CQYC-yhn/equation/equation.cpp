#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,M,a,d,n,s[10000005],inv[10000005];
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
inline void add(int &x,int y){
    if((x+y)>=M) x=x+y-M;
    else x+=y;
}
signed main(){
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    s[0]=1;
    T=read(),M=read();
    for(int i=1;i<M;i++) s[i]=(s[i-1]*i)%M;
    inv[M-1]=ksm(M-1,M-2);
    for(int i=M-2;i>=0;i--) inv[i]=(inv[i+1]*(i+1))%M;
    while(T--){
        a=read(),d=read(),n=read();
        if(n==0){
            cout<<a<<"\n";
            continue;
        }
        if(d==0){
            cout<<ksm(a,n)<<"\n";
            continue;
        }
        a=(a*ksm(d,M-2))%M;
        int l=a,r=(a+n-1)%M;
        if(l>0&&l<=r&&n<M){
            int ans=s[r]*inv[l-1]%M;
            ans=(ans*ksm(d,n))%M;
            cout<<ans<<"\n";
        }
        else puts("0");
    }
	return 0;
}
