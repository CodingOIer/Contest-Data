#include<bits/stdc++.h>
#define int long long
using namespace std;
int m,L,a[1005],b[1005],dp[305][100005];
bool flag=0;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void solve(){
    int t=0;
    for(int i=1;i<=m;i++) t+=(i*a[m+1+i]),b[m+1+i]=a[m+1+i];
    if(t<L) cout<<"impossible";
    else{
        for(int i=m;i>=1;i--){
            int d=(t-L)/i;
            d=min(d,a[m+1+i]);
            b[m+1+i]-=d;
            t-=(d*i);
        }
        if(t!=L) cout<<"impossible";
        else{
            int tot=0;
            for(int i=1;i<=m;i++) tot+=b[m+1+i];
            cout<<tot+a[m+1];
        }        
    }
}
signed main(){
    freopen("greedy.in","r",stdin);
    freopen("greedy.out","w",stdout);
    m=read(),L=read();
    for(int i=1;i<=(m*2+1);i++) a[i]=read();
    for(int i=1;i<=m;i++) if(a[i]>0) flag=1;
    if(flag){
        int t1=0,t2=0;
        for(int i=m+2;i<=(m*2+1);i++) t2+=a[i];
        for(int i=1;i<=m;i++) t1+=a[i];
        if(t2<L) cout<<"impossible";
        else{
            t1=t2=(t1+t2);
            for(int i=0;i<=m;i++){
                for(int j=0;j<=(t1+t2);j++) dp[i][j]=-1e18;
            }
            dp[0][t1]=0;
            for(int i=0;i<m;i++){
                for(int j=0;j<=(t1+t2);j++){
                    for(int g=-a[i+1];g<=a[m+2+i];g++){
                        int d=j+g*(i+1);
                        if(d<0||d>(t1+t2)) continue;
                        int d1,d2;
                        if(g>0) d2=a[m+2+i],d1=a[m+2+i]-g;
                        else d1=a[i+1],d2=a[i+1]+g;
                        if(d1<0||d2<0) continue;
                        dp[i+1][d]=max(dp[i+1][d],dp[i][j]+d1+d2);
                    }
                }
            }
            if(dp[m][L+t1]<0) cout<<"impossible";
            else cout<<dp[m][L+t1]+a[m+1];
        }
    }
    else solve();
	return 0;
}
