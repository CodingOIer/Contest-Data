#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,t1,t2,id[100005],tnt,tot,dfn[100005],low[100005],cnt,head[100005],nxt[100005],txt[100005],dp[100005][2];
bool v[100005],vis[100005],V[100005];
vector<int> e[100005];
stack<int> q;
queue<int> Q;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void dfs(int k){
	dfn[k]=low[k]=++tnt;
	v[k]=1;V[k]=1;
	q.push(k);
	for(int i=head[k];i;i=nxt[i]){
		if(v[txt[i]]) low[k]=min(low[k],dfn[txt[i]]);
		else if(!dfn[txt[i]]){
			dfs(txt[i]);
			low[k]=min(low[k],low[txt[i]]);
		}
	}
	if(dfn[k]==low[k]){
		tot++;
		while(!q.empty()){
			int t=q.top();q.pop();
			id[t]=tot;v[t]=0;
			e[tot].push_back(t);
			if(t==k) break;
		}
	}
}
inline int dfs2(int k,int op){
    if(dp[k][op]!=-1) return dp[k][op];
    dp[k][op]=k;int w;
    if(!op) w=-1e18;
    else w=1e18;
    for(int i=head[k];i;i=nxt[i]){
        if(!op) w=max(w,dfs2(txt[i],op^1));
        else w=min(w,dfs2(txt[i],op^1));
    }
    if(abs(w)<=n) dp[k][op]=max(dp[k][op],w);
    return dp[k][op];
}
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++){
		t1=read(),t2=read();
		nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
	}
    if(n<=500&&m<=100000){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++) dp[j][0]=dp[j][1]=-1;
            cout<<dfs2(i,0)<<" ";
        }
    }
    else{
        for(int i=1;i<=n;i++) dp[i][0]=dp[i][1]=-1;
        for(int i=1;i<=n;i++) cout<<dfs2(i,0)<<" ";
    }
	return 0;
}