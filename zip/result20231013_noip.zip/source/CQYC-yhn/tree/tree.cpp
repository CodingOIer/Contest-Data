#include<bits/stdc++.h>
#define int long long
#define M 998244353
using namespace std;
int n,s,t1,t2,a[100005],sum[100005],ans,b[100005];
bool F1=1;
vector<int> e[100005];
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline int ksm(int k,int c){
    int a=1,b=k;
    while(c){
        if(c&1) a=(a*b)%M;
        b=(b*b)%M;
        c>>=1;
    }
    return a;
}
inline void dfs(int k,int g){
    sum[k]++;
    int t=0;
    for(int i=0;i<(int)e[k].size();i++){
        int d=e[k][i];
        if(sum[d]==2) continue;
        t++;
    }
    // cout<<k<<" "<<g<<" "<<t<<"\n";
    if(t==0){
        ans=(ans+((a[k]*g)%M))%M;
        b[k]=(b[k]+g)%M;
        sum[k]--;
        return;
    }
    t=ksm(t,M-2);
    for(int i=0;i<(int)e[k].size();i++){
        int d=e[k][i];
        if(sum[d]==2) continue;
        dfs(d,g*t%M);
    }
    sum[k]--;
}
inline void solve1(){
    int t=ksm(n-1,M-2);
    for(int i=1;i<=n;i++){
        if(i==s) continue;
        ans=(ans+((t*a[i])%M))%M;
    }
    cout<<ans;
}
signed main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    n=read(),s=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<n;i++){
        t1=read(),t2=read();
        if(t1!=s&&t2!=s) F1=0;
        e[t1].push_back(t2);
        e[t2].push_back(t1);
    }
    if(F1) solve1();
    else{
        dfs(s,1);
        // for(int i=1;i<=n;i++) cerr<<i<<" "<<b[i]<<"\n";
        cout<<ans;
    }
	return 0;
}
