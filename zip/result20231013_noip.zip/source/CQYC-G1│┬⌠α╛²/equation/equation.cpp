#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2e7+5;
int t,p,jc[N],ijc[N];
#define pow Pow
int pow(int x,int base){
    int ans=1;
    while(base){
        if(base&1) ans=1ll*ans*x%p;
        x=1ll*x*x%p;
        base>>=1;
    }
    return ans;
}
int inv(int x){
    return pow(x,p-2);
}
int query(int l,int r){
    if((l<=p&&r>=p)||(r==2*p)) return 0;
    return 1ll*jc[r]*ijc[l-1]%p;
}
int main(){
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    t=read(),p=read();
    jc[0]=1;
    for(int i=1;i<=p*2;i++){
        if(i%p==0) jc[i]=jc[i-1];
        else jc[i]=1ll*jc[i-1]*i%p;
    }
    ijc[p*2]=inv(jc[p*2]);
    for(int i=p*2-1;~i;i--){
        if((i+1)%p==0) ijc[i]=ijc[i+1];
        else ijc[i]=1ll*ijc[i+1]*(i+1)%p;
    }
    while(t--){
        int a=read(),d=read(),n=read();
        a%=p,d%=p;
        if(n>=p) cout<<"0\n";
        else{
            a=1ll*a*inv(d)%p;
            cout<<1ll*query(a,a+n-1)*pow(d,n)%p<<"\n";
        }
        // else{
        //     int ans=1;
        //     for(int i=0;i<n;i++) ans=1ll*(a+1ll*i*d%p)%p*ans%p;
        //     cout<<ans<<"\n";
        // }
    }
    return 0;
}