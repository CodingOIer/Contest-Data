#include <bits/stdc++.h>
using namespace std;
char buf[1<<23],*p1=buf,*p2=buf,obuf[1<<23],*O=obuf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
    while(isdigit(ch)) x=x*10+(ch^48),ch=getchar();
    return x*f;
}
const int N=2e6+5;
int n,m,d[N],in[N],dp[N][2];
vector<int> g[N],f[N];
queue<int> q;
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    n=read(),m=read();
    for(int i=1;i<=m;i++){
        int x=read(),y=read();
        g[x].push_back(y);
        f[y].push_back(x);
        d[x]++;
        in[y]++;
    }
    for(int i=1;i<=n;i++) dp[i][1]=N;
    for(int i=1;i<=n;i++)
        if(d[i]==0) q.push(i),dp[i][0]=dp[i][1]=i;
    while(!q.empty()){
        int x=q.front();
        cout<<x<<"\n";
        q.pop();
        for(auto y:f[x]){
            d[y]--;
            dp[y][0]=max(dp[y][0],dp[x][1]);
            dp[y][1]=min(dp[y][1],dp[x][0]);
            if(d[y]==0) q.push(y);
        }
    }
    for(int i=1;i<=n;i++) cout<<dp[i][0]<<" ";
    return 0;
}