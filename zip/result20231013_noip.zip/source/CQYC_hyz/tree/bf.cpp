#include<bits/stdc++.h>
#define int long long 
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10, mod = 998244353;

void add(int &x, int y) { (x += y) >= mod and (x -= mod); }
void mul(int &x, int y) { x = x * y % mod; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

int n, rt, ans;
int v[N], inv[N];

vector<int> e[N];

void init() {
	inv[0] = inv[1] = 1;
	for(int i = 2; i <= n; i++) inv[i] = (mod - mod / i) * inv[mod % i] % mod;
}

namespace sub1 {
	bool check() {
		return e[rt].size() == n - 1;
	}

	void solve() {
		for(int i = 1; i <= n; i++) if(i ^ rt) add(ans, v[i]);
		write(ans * inv[n - 1] % mod);
	}
}

namespace sub2 {
	int d[N], f[N];

	void dfs(int x, int w) {
		int cnt = 0;
		for(int v : e[x]) if(d[v] < 2) cnt++;
		// if(!cnt) cout << x << " " << w << '\n';
		if(!cnt) add(ans, w * v[x] % mod);
		d[x]++;
		for(int v : e[x]) if(d[v] < 2) dfs(v, w * inv[cnt] % mod);
		d[x]--;
	}

	void solve() { 
		dfs(rt, 1);
		write(ans);
		// for(int i = 1; i <= n; i++) cout << f[i] << " "; cout << '\n';
	}
}

namespace sub3 {
	bool check() {
		for(int i = 1; i <= n; i++) for(int v : e[i])
			if(v != i - 1 and v != i + 1) return 0;

		return 1;
	}
	
	void solve() {

	}
}

bool edmer;
signed main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), rt = read(), init();
    for(int i = 1; i <= n; i++) v[i] = read();
    for(int i = 1; i < n; i++) {
        int x = read(), y = read();
        e[x].push_back(y), e[y].push_back(x);
    }

	// if(sub1 :: check()) sub1 :: solve();
	// else 
    sub2 :: solve();
	// else if(sub3 :: check()) sub3 :: solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 