#include<bits/stdc++.h>
#define int long long 
using namespace std;

char buf[1 << 23], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 and (p2 = (p1 = buf) + fread(buf, 1, 1 << 23, stdin), p1 == p2) ? EOF : *p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e7 + 100;

int T, p, a, d, n;
int fac[N], inv[N];

void add(int &x, int y) { (x += y) >= p and (x -= p); }
void mul(int &x, int y) { x = x * y % p; }

int q_pow(int x, int k) { int res = 1; for(; k; k >>= 1, mul(x, x)) if(k & 1) mul(res, x); return res; }

void init() {
    fac[0] = 1;
    for(int i = 1; i < p; i++) fac[i] = fac[i - 1] * i % p;
    inv[p - 1] = q_pow(fac[p - 1], p - 2);
    for(int i = p - 1; i; i--) inv[i - 1] = inv[i] * i % p;
}

void solve() {
    a = read(), d = read(), n = read(), a = (a + p - d) % p;
    int ans = 1;
    for(int i = 0; i < n; i++) add(a, d), mul(ans, a);
    write(ans), putchar('\n');
}

bool edmer;
signed main() {
	freopen("equation.in", "r", stdin);
	freopen("equation.ans", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    T = read(), p = read(), init();

    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 