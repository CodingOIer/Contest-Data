#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
	while(ch >= '0' and ch <= '9') x = (x << 1) + (x << 3) + (ch ^ 48), ch = getchar();
	return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
	do { __stk[++__top] = x % 10, x /= 10; } while(x);
	while (__top) putchar(__stk[__top--] + '0');
}
bool stmer;

const int N = 1e5 + 10;

int n, m;
int f[N][2], d[N], ans[N];

bool vis[N][2];

vector<int> e[N];

void update(int x, int op, int res) {
    if(vis[x][op]) return;
    vis[x][op] = 1;
    if(op) ans[x] = res;

    for(int v : e[x]) {
        if(!op) update(v, 1, res);
        else if(!(--d[v])) update(v, 0, res);
    }
}

bool edmer;
signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cerr << "[Memory] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";
	
    n = read(), m = read();

    for(int i = 1; i <= m; i++) {
        int x = read(), y = read();
        d[x]++, e[y].push_back(x);
    }

    for(int i = n; i; i--) update(i, 0, i), update(i, 1, i);

    for(int i = 1; i <= n; i++) write(ans[i]), putchar(' ');

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds";
	return 0;
} 