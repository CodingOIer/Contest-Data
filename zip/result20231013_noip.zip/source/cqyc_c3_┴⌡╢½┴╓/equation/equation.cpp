#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[40],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[++tp]=x%10,x/=10;while(x);
        while(tp)putchar(stk[tp--]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 10000005;
int s[N];
int t,mod;

int ksm(int a,int b){
    int ans = 1;
    while(b){
        if(b&1)
            ans = ans*a%mod;
        a = a*a%mod;
        b >>= 1;
    }
    return ans;
}

signed main(){
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    t = in,mod = in;
    s[0] = 1;
    for(int k=1;k<=mod;k++)
        s[k] = s[k-1]*k%mod;
    while(t--){
        int a = in,d = in,n = in;
        a = a*ksm(d,mod-2)%mod;
        if(n>mod||!a){
            puts("0");
            continue;
        }
        int ans = s[min(mod,a+n-1)]*ksm(s[a-1],mod-2)%mod*s[max(0ll,a+n-mod)]%mod*ksm(d,n)%mod;
        out(ans,'\n');
    }
    return 0;
}