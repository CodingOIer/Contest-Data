#include <bits/stdc++.h>

//#pragma GCC optimize(2)
#define For(x, y, z) for (int x = y; x <= z; ++x)
#define Rof(x, y, z) for (int x = y; x >= z; --x)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define SZ(x) (int(x.size()))
#define pb push_back

using namespace std;
using i64 = long long;
using ull = unsigned long long;
using pii = pair<int, int>;

// char buf[(1<<21)+5],*p1,*p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)

inline int read() {
	int x = 0, f = 0; char ch = getchar();
	while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
	return f ? -x : x;
}
int __stk[128], __tp;
inline void put(i64 x) {
	if (x < 0) putchar('-'), x = -x;
	do { __stk[++__tp] = x % 10, x /= 10; } while (x);
	while (__tp) putchar(__stk[__tp--] + '0');
}

const int mod = 998244353;
inline int ksm(int x, int y, int res = 1) {
	for ( ; y; y >>= 1, x = 1ll * x * x % mod)
		(y & 1) && (res = 1ll * res * x % mod);
	return res;
}
inline int inv(int x) { return ksm(x, mod - 2); }
inline int gcd(int a, int b) { if (b) while ((a %= b) && (b %= a)); return a | b; }
inline void add(int &x, int y) { (x += y) >= mod && (x -= mod); }
inline void Min(int &x, int y) { (y < x) && (x = y); }
inline void Max(int &x, int y) { (y > x) && (x = y); }

const int N = 2e5 + 1000;
int n, m, vis[N], d[N], ti;
int head[N], nxt[N << 1], to[N << 1], cnt;
void Add(int u, int v) {  to[++cnt] = v, nxt[cnt] = head[u], head[u] = cnt, ++d[v];  }
queue<int> q; void Push(int x) { vis[x] = ti, q.push(x);  }

signed main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
    n = read(), m = read();
    For(i, 1, m) { 
        int u = read(), v = read(); 
        Add(v, u + n), Add(v + n, u); 
    }
	for (ti = n; ti >= 1; --ti) {
        if (!vis[ti]) Push(ti); if (!vis[ti + n]) Push(ti + n);
        while (!q.empty()) { int u = q.front(); q.pop();
            if (u > n) { Eor(u) if (!vis[to[i]]) Push(to[i]); }
            else {Eor(u) if ((!vis[to[i]]) && (!(--d[to[i]]))) Push(to[i]); }
        }
    } For(i, 1, n) cout << vis[i] <<" ";
	return 0;
}