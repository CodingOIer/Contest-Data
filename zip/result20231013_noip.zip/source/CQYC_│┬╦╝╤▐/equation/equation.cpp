#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e7+5;
int t,p,a,d,n,sum[maxn],cnt,vis[maxn],ans;
int read(){
    int s=0;
    char ch=getchar(),last=' ';
    while(ch<'0'||ch>'9')
        last=ch,ch=getchar();
    while(ch>='0'&&ch<='9')
        s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return last=='-'?-s:s;
}
int power(int a,int b){
    int res=1;
    while(b){
        if(b&1)
            res=res*a%p;
        a=a*a%p;
        b>>=1;
    }
    return res;
}
signed main(){
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    t=read(),p=read();
    while(t--){
        ans=1,cnt=0;
        a=read(),d=read(),n=read();
        int k=a,bj=0;
        while(1){
            if(vis[k]==t+1)
                break;
            if(!k){
                bj=1;
                break;
            }
            sum[++cnt]=k,vis[k]=t+1,k+=d;
            if(k>=p)
                k-=p;
            if(cnt==n)
                break;
        }
        if(bj){
            puts("0");
            continue;
        }
        int x=n/cnt,y=n%cnt;
        for(int i=1;i<=cnt;i++)
            if(i<=y)
                ans=ans*power(sum[i],x+1)%p;
            else
                ans=ans*power(sum[i],x)%p;
        printf("%lld\n",ans);
    }
    return 0;
}
