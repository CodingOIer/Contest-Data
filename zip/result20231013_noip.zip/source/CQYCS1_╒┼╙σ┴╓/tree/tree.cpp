#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,k
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =1e5+5,M=1e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
inline ll qp(ll a,ll b){
	if(!b)return 1;
	ll c=qp(a,b>>1);
	c=c*c%mod;
	if(b&1)c=c*a%mod;
	return c;
}
int n,rt,h[N],to[N<<1],nxt[N<<1],cnt,val[N],d[N];
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,d[a]++;
}
ll iv[N];
inline void prep(){
	rep(i,1,n)iv[i]=qp(i,mod-2);
}
ll g[N][2],dp[N][2],son[N],sg[N],w[N];
inline void dfs(int x,int fa){
	e(x)if(y^fa)son[x]++,dfs(y,x);
}
inline void Dfs(int x,int fa){
	ll sd=0,s1=0,sd1=0,s11=0;
	if(!son[x]){
		sg[x]=g[x][1]=val[x];
		return;
	}
	e(x)if(y^fa){
		Dfs(y,x);
		(sd+=iv[d[x]]*iv[d[y]]%mod)%=mod;
		(s1+=iv[d[x]]*w[y]%mod)%=mod;
		(sd1+=iv[son[x]]*iv[d[y]]%mod)%=mod;
		(s11+=iv[son[x]]*w[y]%mod)%=mod;
		(sg[x]+=iv[son[x]]*g[y][1]%mod)%=mod;
	}
	e(x)if(y^fa){
		(g[x][0]+=iv[d[x]]*((g[y][0]+(sd-iv[d[x]]*iv[d[y]]%mod+mod)%mod*g[y][1]%mod)%mod)%mod)%=mod;
		(g[x][0]+=sg[y]*iv[d[x]]%mod*iv[d[x]]%mod*iv[d[y]]%mod)%=mod;
		(g[x][0]+=(s1-iv[d[x]]*w[y]%mod+mod)%mod*((iv[d[x]-1]+mod)%mod)%mod*g[y][1]%mod)%=mod;
		(g[x][1]+=iv[son[x]]*((g[y][0]+(sd1-iv[son[x]]*iv[d[y]]%mod+mod)%mod*g[y][1]%mod)%mod)%mod)%=mod;
		(g[x][1]+=sg[y]*iv[son[x]]%mod*iv[son[x]]%mod*iv[d[y]]%mod)%=mod;
		(g[x][1]+=(s11-iv[son[x]]*w[y]%mod+mod)%mod*((iv[son[x]-1]+mod)%mod)%mod*g[y][1]%mod)%=mod;
		if(son[x]==1)(g[x][1]+=val[x]*w[y]%mod)%=mod;
		//if(x==1)cout <<y<<"*"<<g[x][1]<<endl;
	}
	//if(x==1)cerr<<sd1<<" "<<s11<<" "<<w[2]<<endl;
	dp[x][0]=sd,dp[x][1]=s1;
	w[x]=(dp[x][0]*iv[d[x]]%mod+dp[x][1]*((iv[d[x]-1]+mod)%mod)%mod)%mod;
}
int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
  	n=read(),rt=read(),prep();
  	rep(i,1,n)val[i]=read();
  	for(int i=1,x,y;i^n;i++)x=read(),y=read(),add(x,y),add(y,x);
  	dfs(rt,0),Dfs(rt,0);
  	//rep(i,1,n)cerr<<sg[i]<<endl;
  	//cerr<<2LL*qp(3,mod-2)%mod<<endl;
  	pf(g[rt][1]);
  	//cerr<<"[Runtime]"<<clock()*1.0/1000.0<<" seconds.";
	return 0;
}
/*
5 1
1 1 1 1 1
1 2
1 3
2 4 
2 5
*/
