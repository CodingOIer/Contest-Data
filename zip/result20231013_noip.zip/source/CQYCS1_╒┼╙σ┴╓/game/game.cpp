#include<bits/stdc++.h>
#define ll long long
#define L x<<1
#define R x<<1|1
#define mid (l+r>>1LL)
#define lc L,l,mid
#define rc R,mid+1,r
#define Root 1,1,k
#define OK l>=Ll&&r<=Rr
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define pb push_back
#define ull unsigned ll
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define E(x) for(auto y:p[x])
#define Pi pair<int,int>
#define ui unsigned ll
inline ll read(){ll s=0,w=1;char c=getchar();while(c<48||c>57) {if(c=='-') w=-1;c=getchar();}while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();return s*w;}
inline void pf(ll x){if(x<0) putchar('-'),x=-x;if(x>9)pf(x/10);putchar(x%10+48);}
const int N =3e2+5,M=1e6+5,inf=(1LL<<31)-1;
const ll llf=1e18,mod=998244353,bas=131;
const ui base=13331;
using namespace std;
int n,m,h[N],to[N],nxt[N],cnt,cd[N],rd[N],dp[N][2];
inline void add(int a,int b){
	to[++cnt]=b,nxt[cnt]=h[a],h[a]=cnt,cd[a]++,rd[b]++;
}
inline int solve(int x,bool ty){
	if(dp[x][ty])return dp[x][ty];
	if(cd[x]==0)return dp[x][ty]=x;
	dp[x][ty]=x;
	if(ty==1)e(x)dp[x][ty]=max(dp[x][ty],solve(y,ty^1));
	else e(x)dp[x][ty]=min(dp[x][ty],solve(y,ty^1));
	return dp[x][ty];
}
int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
  	n=read(),m=read();
  	for(int i=1,x,y;i<=m;i++)x=read(),y=read(),add(x,y);
  	rep(i,1,n)if(!dp[i][1])dp[i][1]=solve(i,1);
  	rep(i,1,n)pf(solve(i,1)),putchar(' '); 
	return 0;
}
