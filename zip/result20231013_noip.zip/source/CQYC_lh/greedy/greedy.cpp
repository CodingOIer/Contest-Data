#include<bits/stdc++.h>
using namespace std;
const int maxn=6e2+2;
const long long inf=1e18;
int m;
long long L,ar[maxn];
long long ans;
long long read(){
    long long x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch))f=((ch=='-')?1:0),ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int main(){
    // freopen("greedy.in","r",stdin);
    // freopen("greedy.out","w",stdout);
    m=read(),L=read();
    ans=inf;
    long long sum=0,nsum=0;
    bool f=1;
    for(int i=-m;i<=m;i++)ar[i+m]=read(),sum+=ar[i+m];
    ans=min(ans,sum);
    // printf("ans=%lld\n",ans);
    nsum=0,sum=0;
    for(int i=-m;i<=0;i++)nsum+=1ll*(-i)*ar[i+m],sum+=ar[i+m];
    if(nsum+L<0){
        printf("0\n");
        return 0;
    }
    else ans=min(ans,sum+nsum+L);
    // printf("ans=%lld %lld\n",ans,nsum);
    nsum=0,sum=0;
    for(int i=0;i<=m;i++)nsum+=1ll*i*ar[i+m],sum+=ar[i+m];
    if(nsum-L<0){
        printf("0\n");
        return 0;
    }
    else ans=min(ans,sum+nsum-L);
    // printf("%lld %lld\n",ans,nsum);
    printf("%lld\n",ans);
    return 0;
}