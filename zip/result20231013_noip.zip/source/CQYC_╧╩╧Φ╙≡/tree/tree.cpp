#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=N<<1,mod=998244353;
int n,S,ans,a[N],f[N],num[N];
int first[N],to[M],nxt[M],cnt;
bool subtask1=1;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
int ksm(int x,int y)
{
	int res=1;
	for(;y;y>>=1)
	{
		if(y&1) res=1ll*res*x%mod;
		x=1ll*x*x%mod;
	}
	return res;
}
inline void upd(int &x,int y) {x+=y;if(x>=mod) x-=mod;}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&S);
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	for(int i=1,u,v;i<n;i++)
	{
		scanf("%d%d",&u,&v),inc(u,v),inc(v,u);
		if(u!=v-1) subtask1=0;
	}
	if(subtask1)
		ans=1ll*ksm(2,mod-2)*(a[1]+a[n])%mod;
	else
	{
		for(int i=1;i<=n;i++)
			if(i!=S) upd(ans,a[i]);
		ans=1ll*ans*ksm(n-1,mod-2)%mod;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
