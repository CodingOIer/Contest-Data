#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,m,in[N],f[N][2];
int first[N],to[N],nxt[N],cnt;
queue<int>q;
inline void Max(int &x,int y) {x=x>y?x:y;}
inline void Min(int &x,int y) {x=x>y?y:x;}
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void topu()
{
	for(int i=1;i<=n;i++)
		if(!in[i]) q.push(i),f[i][0]=f[i][1]=i;
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		for(int i=first[x],v;i;i=nxt[i])
		{
			if(!--in[v=to[i]]) q.push(v);
			Max(f[v][0],f[x][1]);
			Min(f[v][1],f[x][0]);
		}
	}
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) f[i][1]=1e9;
	int x,y;
	while(m--)
		scanf("%d%d",&x,&y),inc(y,x),++in[x];
	topu();
	for(int i=1;i<=n;i++)
		printf("%d%c",f[i][0]," \n"[i==n]);
	fclose(stdin);fclose(stdout);
	return 0;
}
