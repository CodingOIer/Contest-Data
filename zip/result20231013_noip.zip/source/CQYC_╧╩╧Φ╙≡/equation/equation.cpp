#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
const int N=1e7+10;
int T,a,d,n,ans,mod,b[N];
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	T=read(),mod=read();
L:	while(T--)
	{
		a=read(),d=read(),n=read();
		b[0]=a;
		for(int i=1;i<n;i++)
		{
			b[i]=1ll*b[i-1]*(a+1ll*i*d%mod)%mod;
			if(!b[i]) {puts("0");goto L;}
		}
		printf("%d\n",b[n-1]);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
