#include<bits/stdc++.h>
using namespace std ;
long long k , n , m , num=1 , i=1 , j=1 , f=0 , temp , f1=0 , f2=0 , f3=1 , f4=1 ;
int main() {
	freopen("matrix.in","r",stdin) ;
	freopen("matrix.out","w",stdout) ;
	cin >> k >> n >> m ;
	temp = k*k ;
	while(temp--) {
		if(i==n&&m==j) {
			cout << num ;
			return 0 ;
		}
		if(f%4==0) {
			j++ ;
			if(j==k-f1) f++ , f4++ ;
		} else if(f%4==1) {
			i++ ;
			if(i==k-f2) f++ , f1++ ;
		} else if(f%4==2) {
			j-- ;
			if(j==f3) f++ , f2++ ;
		} else if(f%4==3) {
			i-- ;
			if(i==f4) f++ , f3++ ;
		}
		num++ ;
	}
	return 0 ;
}
