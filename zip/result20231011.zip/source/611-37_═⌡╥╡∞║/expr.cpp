#include<bits/stdc++.h>
using namespace std ;
const long long mod = 10000 ;
long long num , sum=0 ;
stack<long long> q ;
char a ;
int main() {
	freopen("expr.in","r",stdin) ;
	freopen("expr.out","w",stdout) ;
	cin >> num ;
	q.push(num) ;
	while(cin >> a >> num) {
		long long top = q.top() ;
		q.pop() ;
		if(a=='*')
			q.push(top*num%mod) ;
		else if(a=='+')
			q.push((top+num)%mod) ;
		else if(a=='-')
			q.push((top-num)%mod) ;
	}
	while(q.size()) {
		sum += q.top() ;
		q.pop() ;
	}
	cout << sum ;
	return 0 ;
}
