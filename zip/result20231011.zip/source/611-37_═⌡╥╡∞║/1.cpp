#include<bits/stdc++.h>
using namespace std ;
const long long mod = 998244353 ;
long long t , id , sum[1005][1005] , n , m , c=0 , f=0 , ans[1005] ;
char a[1005][1005] ;
int main() {
//	freopen("plant.in","r",stdin) ;
//	freopen("plant.out","w",stdout) ;
	cin >> t >> id ;
	while(t--) {
		c = f = 0 ;
		long long C , F ;
		scanf("%lld%lld%lld%lld",&n,&m,&C,&F) ;
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				scanf("%c",&a[i][j]) ;
				if(a[i][j]=='1') sum[i][j] = 1 ;
				else sum[i][j] = 0 ;
				sum[i][j] += sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1] ;
//				sum[i][j] += sum[i][j-1] ;
				if(!(sum[i][j]-sum[i-1][j])&&j>1) ans[i]++ ;
			}
		}
		// C
		for(int i=1; i<=n; i++) {
			for(int j=i+2; j<=n; j++) {
				if(sum[i][j]-sum[i][j-1]) break ;
				c += ans[i]*ans[j] ;
				c %= mod ;
			}
		}
		// F
//		for(int i=1;i<=n;i++){
//			for(int )
//		}
		cout << c*C%mod << endl ;
	}
	return 0 ;
}
