#include<bits/stdc++.h>
using namespace std ;
short t[105][1005] ;
int n , m , dp[105][1005] ;
void dfs(int x,int y,int sum,bool ant) {
	if((dp[x][y]<=sum&&dp[x][y]!=-1)||x>n||y>n||!x||!y) return ;
	dp[x][y] = sum ;
	// 1
	if(t[x][y+1]==t[x][y]) dfs(x,y+1,sum,0) ;
	else if(t[x][y+1]!=-1) dfs(x,y+1,sum+1,0) ;
	else if(!ant) {
		if(t[x][y]) {
			t[x][y+1] = 1 ;
			dfs(x,y+1,sum+2,1) ;
			t[x][y+1] = 0 ;
			dfs(x,y+1,sum+3,1) ;
			t[x][y+1] = -1 ;
		} else {
			t[x][y+1] = 1 ;
			dfs(x,y+1,sum+3,1) ;
			t[x][y+1] = 0 ;
			dfs(x,y+1,sum+2,1) ;
			t[x][y+1] = -1 ;
		}
	}
	// 2
	if(t[x+1][y]==t[x][y]) dfs(x+1,y,sum,0) ;
	else if(t[x+1][y]!=-1) dfs(x+1,y,sum+1,0) ;
	else if(!ant) {
		if(t[x][y]) {
			t[x+1][y] = 1 ;
			dfs(x+1,y,sum+2,1) ;
			t[x+1][y] = 0 ;
			dfs(x+1,y,sum+3,1) ;
			t[x+1][y] = -1 ;
		} else {
			t[x+1][y] = 1 ;
			dfs(x+1,y,sum+3,1) ;
			t[x+1][y] = 0 ;
			dfs(x+1,y,sum+2,1) ;
			t[x+1][y] = -1 ;
		}
	}
	//3
	if(t[x-1][y]==t[x][y]) dfs(x-1,y,sum,0) ;
	else if(t[x-1][y]!=-1) dfs(x-1,y,sum+1,0) ;
	else if(!ant) {
		if(t[x][y]) {
			t[x-1][y] = 1 ;
			dfs(x-1,y,sum+2,1) ;
			t[x-1][y] = 0 ;
			dfs(x-1,y,sum+3,1) ;
			t[x-1][y] = -1 ;
		} else {
			t[x-1][y] = 1 ;
			dfs(x-1,y,sum+3,1) ;
			t[x-1][y] = 0 ;
			dfs(x-1,y,sum+2,1) ;
			t[x-1][y] = -1 ;
		}
	}
	//4
	if(t[x][y-1]==t[x][y]) dfs(x,y-1,sum,0) ;
	else if(t[x][y-1]!=-1) dfs(x,y-1,sum+1,0) ;
	else if(!ant) {
		if(t[x][y]) {
			t[x][y-1] = 1 ;
			dfs(x,y-1,sum+2,1) ;
			t[x][y-1] = 0 ;
			dfs(x,y-1,sum+3,1) ;
			t[x][y-1] = -1 ;
		} else {
			t[x][y-1] = 1 ;
			dfs(x,y-1,sum+3,1) ;
			t[x][y-1] = 0 ;
			dfs(x,y-1,sum+2,1) ;
			t[x][y-1] = -1 ;
		}
	}
}
int main() {
	freopen("chess.in","r",stdin) ;
	freopen("chess.out","w",stdout) ;
	memset(t,-1,sizeof(t)) ;
	memset(dp,-1,sizeof(t)) ;
	cin >> n >> m ;
	for(int i=0; i<m; i++) {
		int x , y , c ;
		scanf("%d%d%d",&x,&y,&c) ;
		t[x][y] = c ;
	}
	dfs(1,1,0,0) ;
	cout << dp[n][n] ;
	return 0 ;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
*/
