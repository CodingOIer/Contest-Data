#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cout<<-1; 
	return 0;
} 
