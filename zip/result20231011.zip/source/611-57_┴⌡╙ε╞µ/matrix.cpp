#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ll n,inf;
	cin>>n;
	ll a,b;
	cin>>a>>b;
	inf=min(min(abs(n-a),abs(1-a)),min(abs(n-b),abs(1-b)))+n%2;
	for(int i=n*n-(n-(inf-1)*2)*(n-(inf-1)*2)+1; i<=n*n-(n-inf*2)*(n-inf*2); i++) {
		ll num = i-(n*n-(n-(inf-1)*2)*(n-(inf-1)*2)) ;
		if(num<=(n-2*inf+2-1)*1) {
			if(a==inf&&b-inf+1==num) {
				cout<<i;
				return 0;
			}
		} else {
			if(num<=(n-2*inf+2-1)*2) {
				if(b==n-inf+1&&a-inf+1==num-(n-2*inf+2-1)) {
					cout<<i;
					return 0;
				}
			} else {
				if(num<=(n-2*inf+2-1)*3) {
					if(a==n-inf+1&&b-inf+1==3*(n-2*inf+2-1)-num+2) {
						cout<<i;
						return 0;
					}
				} else {
					if(num<=(n-2*inf+2-1)*4) {
						if(b==inf&&a-inf+1==4*(n-2*inf+2-1)-num+2) {
							cout<<i;
							return 0;
						}
					}
				}
			}
		}
	}
	return 0;
}

