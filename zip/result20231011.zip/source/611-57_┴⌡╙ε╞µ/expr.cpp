#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ll temp,ans=0;
	cin>>temp;
	while(1) {
		char c=getchar();
		if(c=='\r'||c=='\n')
			break;
		ll temp2;
		if(c=='+')
			ans+=temp,temp=1;
		if(c=='-')
			ans+=temp,temp=-1;
		cin>>temp2;
		temp2%=10000;
		temp*=temp2;
		temp%10000;
		ans%=10000;
	}
	ans+=temp;
	cout<<ans%10000;
	return 0;
}

