#include<bits/stdc++.h>
using namespace std;
long long a,b,c,ans=1,l,q;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>a>>b>>c;
	l=a*4-4;
	ans=1;
	q=min(min(b,c),a-max(b,c)+1);
	for(int k=2;k<=q;k++)
		ans+=l,l-=8;
	ans+=b+c-q*2;
	if(b>c)
		ans+=2*(a*2-b-c-q*2+2);
	cout<<ans;
}

