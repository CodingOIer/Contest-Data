#include<bits/stdc++.h>
using namespace std;
long long m,n,a[105][105],vis[105][105]; 
void dfs(int x,int y,int f,int mon)
{
	vis[x][y]=mon;
	if(a[x][y]==a[x+1][y]&&a[x+1][y]!=0&&vis[x+1][y]>mon)
	{	
		if(f==0)
			a[x][y]=0;
		dfs(x+1,y,1,mon);
	}
	if(a[x][y]==a[x][y+1]&&a[x][y+1]!=0&&vis[x][y+1]>mon)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x,y+1,1,mon);
	}
	if(a[x][y]==a[x-1][y]&&a[x-1][y]!=0&&vis[x-1][y]>mon)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x-1,y,1,mon);
	}
	if(a[x][y]==a[x][y-1]&&a[x][y-1]!=0&&vis[x][y-1]>mon)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x,y-1,1,mon);
	}
	if(a[x][y]!=a[x+1][y]&&a[x+1][y]!=0&&vis[x+1][y]>mon+1)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x+1,y,1,mon+1);
	}
	if(a[x][y]=a[x][y+1]&&a[x][y+1]!=0&&vis[x][y+1]>mon+1)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x,y+1,1,mon+1);
	}
	if(a[x][y]!=a[x-1][y]&&a[x-1][y]!=0&&vis[x-1][y]>mon+1)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x-1,y,1,mon+1);
	}
	if(a[x][y]!=a[x][y-1]&&a[x][y-1]!=0&&vis[x][y-1]>mon+1)
	{
		if(f==0)
			a[x][y]=0;
		dfs(x,y-1,1,mon+1);
	}
	if(a[x+1][y]==0&&vis[x+1][y]>mon+2&&f)
	{
		a[x+1][y]=1;
			dfs(x+1,y,0,mon+2);
		a[x+1][y]=2;
			dfs(x+1,y,0,mon+2);
	}
	if(a[x-1][y]==0&&vis[x-1][y]>mon+2&&f)
	{
		a[x-1][y]=1;
			dfs(x-1,y,0,mon+2);
		a[x-1][y]=2;
			dfs(x-1,y,0,mon+2);
	}
	if(a[x][y+1]==0&&vis[x][y+1]>mon+2&&f)
	{
		a[x][y+1]=1;
			dfs(x,y+1,0,mon+2);
		a[x][y+1]=2;
			dfs(x,y+1,0,mon+2);
	}
	if(a[x][y-1]==0&&vis[x][y-1]>mon+2&&f)
	{
		a[x][y-1]=1;
			dfs(x,y-1,0,mon+2);
		a[x][y-1]=2;
			dfs(x,y-1,0,mon+2);
	}
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=n;i++)
	{
		int x,y,z;
		cin>>x>>y>>z;
		a[x][y]=z+1;
	}
	for(int i=1;i<=m;i++)
		for(int j=1;j<=m;j++)
			vis[i][j]=1145141919810;
	dfs(1,1,1,0);
	if(vis[m][m]==1145141919810)
		cout<<-1;
	else
		cout<<vis[m][m];
	/*
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cout<<setw(3)<<vis[i][j]%100;
		}
		cout<<'\n';
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cout<<setw(3)<<a[i][j];
		}
		cout<<'\n';
	}
	*/
}
