#include<bits/stdc++.h>
using namespace std;
stack<__int128>a;
stack<char>b;
//2147483647*5-1073741824*10 ^_^
//2147483647-1147483648 ^_^
//1000000000*1000000000*1000000000-1 WA
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	long long c;
	char d;
	cin>>c;
	a.push(c);
	while(cin>>d>>c)
	{
		b.push(d);
		a.push(c);
		if(b.top()=='*')
		{
			long long e=a.top();
			a.pop();
			long long f=a.top();
			a.pop();
			a.push(e*f%10000000000);
			b.pop();
		}
	}
	while(!b.empty())
	{	char y=' ';
		char z=b.top();
		b.pop();
		long long e=a.top();
		a.pop();
		long long f=a.top();
		a.pop();
		if(!b.empty())
			y=b.top();
		if(z==y||y==' '&&z=='+')
			a.push((e+f)%10000000000);
		else if(z!=y||y==' '&&z=='-')
			a.push((f-e)%10000000000);
	}
	cout<<(long long)a.top()%10000;
} 
