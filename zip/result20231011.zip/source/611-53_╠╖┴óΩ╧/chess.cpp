#include<bits/stdc++.h>

using namespace std;
int n,m,s=INT_MAX;
int chess[105][105];
bool vis[105][105];
int xy[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
void dfs(int x,int y,int monny,bool mf){
	if(x==m&&y==m){
		s=min(s,monny);
		return ;
	}
	if(monny>=s) return ;
	for(int i=0;i<4;i++){
		int xx=x+xy[i][0];
		int yy=y+xy[i][1];
		if(xx>=1&&xx<=m&&yy>=1&&yy<=m&&!vis[xx][yy]&&chess[xx][yy]){
			vis[xx][yy]=true;
			if(chess[xx][yy]==chess[x][y]){
				if(mf) chess[x][y]=0;
				dfs(xx,yy,monny,false);
			}
			else{
				if(mf) chess[x][y]=0;
				dfs(xx,yy,monny+1,false);
			}
			vis[xx][yy]=false;
		}
	}
	if(!mf){
		for(int i=0;i<4;i++){
			int xx=x+xy[i][0];
			int yy=y+xy[i][1];
			if(xx>=1&&xx<=m&&yy>=1&&yy<=m&&!vis[xx][yy]){
				chess[xx][yy]=chess[x][y];
				dfs(xx,yy,monny+2,true);
				chess[xx][yy]=0;
			}
		}
	}
}
signed main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>m>>n;
	for(int i=1;i<=n;i++){
		int x,y,c;cin>>x>>y>>c;
		chess[x][y]=c+1;
	}
	vis[1][1]=true;
	dfs(1,1,0,false);
	if(s==INT_MAX) cout<<-1;
	else cout<<s;
	return 0;
}
