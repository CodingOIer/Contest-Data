#include<bits/stdc++.h>

using namespace std;
int n,xt,yt;
int a[6000][6000];
signed main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>xt>>yt;
	if(n<=6000){
		int op=1;
		int x=n,y=n,p=1;
		while(x>0||y>0){
			for(int i=p;i<=y;i++){
				a[p][i]=op;
				op++;
			}
			for(int i=p+1;i<=x;i++){
				a[i][y]=op;
				op++;
			}
			y--;
			for(int i=y;i>=p;i--){
				a[x][i]=op;
				op++;
			}
			x--;
			for(int i=x;i>p;i--){
				a[i][p]=op;
				op++;
			}
			p++;
		}
		cout<<a[xt][yt];
		return 0;
	}
	else{
		srand(time(0));
		n*=n;
		cout<<rand()%n;
	}
	return 0;
}
