#include<bits/stdc++.h>
const int mod=1e4; 
using namespace std;
stack<int> st;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(false);cin.tie(0);
	int x,p;
	char ch;
	cin>>x;
	while(cin>>ch>>p){
		p%=mod;
		if(ch=='+'){
			st.push(x);
			x=p;p=0;
		}
		else if(ch=='-'){
			st.push(x);
			x=-p;p=0;
		}
		else x=(x*p)%mod;
	}
	if(x!=0) st.push(x);
	int s=0;
	while(!st.empty()){
		s+=st.top();
		st.pop();
	}
	cout<<s;
	return 0;
}
