#include<bits/stdc++.h>
using namespace std;
int a[10001][10001];
int main(){
	int n,i,j;
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>i>>j;
	int fx=0;
	int gz=1;
	int zs=n*n;
	int mt=1;
	int b=1,c=1,d=1,e=1;
	while(zs){
		for(int i=1;i<=n;i++){
			if(a[b][i]==0){
				a[b][i]=mt;
				mt++;
				zs--;
			}
		}
		b++;
		for(int i=1;i<=n;i++){
			if(a[i][n-c+1]==0){
				a[i][n-c+1]=mt;
				mt++;
				zs--;
			}
		}
		c++;
		for(int i=n;i>=1;i--){
			if(a[n-d+1][i]==0){
				a[n-d+1][i]=mt;
				mt++;
				zs--;
			}
		}
		d++;
		for(int i=n;i>=1;i--){
			if(a[i][e]==0){
				a[i][e]=mt;
				mt++;
				zs--;
			}
		}
		e++;
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=n;j++){
//				cout<<a[i][j]<<" "; 
//			}
//			cout<<endl;
//		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<a[i][j]<<" "; 
//		}
//		cout<<endl;
//	}
	cout<<a[i][j];
	return 0;
}
