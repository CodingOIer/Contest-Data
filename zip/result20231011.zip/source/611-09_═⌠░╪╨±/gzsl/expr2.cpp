#include <bits/stdc++.h>
using namespace std;
long long m;
int a[10000001]={};
int b[10000001]={};
string s;
long long ans=0;
int f(int n){
	int x=0;
	long long sum=0;
	for(int i=n-1;i<m;i++){
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'){
			break;
		}
		else{
			x++;
//			cout<<s[i]<<" "<<x<<endl;
		}
	}
	int y=1;
	for(int i=n+x-2;i>=n-1;i--){
		sum+=y*int(s[i]-48);
//		cout<<s[i]<<" "<<int(s[i]-48)<<" "<<y<<endl;
		y*=10;
	}
	return sum;
}
int main(){
//	cin>>s;
	freopen("expr.in","r",stdin);
	freopen("espr.out","w",stdout);
	cin>>s;
	m=s.length();
	int e=1;
	a[e]=f(1);
	for(int i=0;i<m;i++){
		if(s[i]=='*'||s[i]=='+'||s[i]=='-'){
			e++;
//			cout<<i<<endl;
			a[e]=f(i+2);
			if(s[i]=='*'){
				b[e-1]=1;
			}
			if(s[i]=='+'){
				b[e-1]=2;
			}
			if(s[i]=='-'){
				b[e-1]=3;
			}
		}
	}
	ans=0;
	int u=0;
	int x=1;
	for(int i=1;i<=e;i++){
		if(b[i]==1){
			x*=a[i];
			a[i]=0;
//			cout<<x<<"**"<<endl;
			if(b[i+1]!=1){
//				cout<<a[i+1]<<"***"<<endl;
				x*=a[i+1];
//				cout<<x<<endl;
				ans+=x;
				x=1;
			}
//			a[i+1]=0;
		}
	}
	if(b[1]!=1){
		ans+=a[1];
	}
	for(int i=2;i<=e;i++){
		if(b[i-1]==2){
			ans+=a[i];
		}
		if(b[i-1]==3){
			ans-=a[i];
		}
	} 
	cout<<ans;
//	for(int i=1;i<=e;i++){
//		cout<<a[i]<<" ";
//	}
//	cout<<endl;
//	for(int i=1;i<=e;i++){
//		cout<<b[i]<<" ";
//	}
	return 0;
}
