#include<bits/stdc++.h>
using namespace std;
int a[10001][10001];
int main(){
	int n,i,j;
	cin>>n>>i>>j;
	int fx=0;
	int gz=1;
	int zs=n*n;
	int mt=1;
	while(zs){
//		if(fx==3){
//			
//		}		
//		if(fx==2){
//			
//		}
		if(fx==1){
			cout<<gz<<endl;
			for(int i=1;i<=n;i++){
				if(a[i][gz]==0){
					a[i][gz]=mt;
					mt++;
					zs--;				
				}
			}
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					cout<<a[i][j]<<" ";
				}
				cout<<endl;
			}
			return 0;
		}
		if(fx==0){
			int o=0;
			for(int i=1;i<=n;i++){
				if(a[gz][i]==0){
					a[gz][i]=mt;
					mt++;
					zs--;
					o++;					
				}
			}
			gz+=o-1;
			fx++;
		}
//		cout<<zs<<endl;;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cout<<a[i][j]<<" ";
			}
			cout<<endl;
		}
	}
	return 0;
} 
