#include <bits/stdc++.h>
using namespace std;
long long ans=0;
signed main(){
	int x,a;
	char b;
	scanf("%d",&x);
	while(scanf("%c",&b)){
		cout<<x<<" "<<b;
//		if(int(b-42)!=1||int(b-42)!=2){
//			cout<<int(b-42)<<"endl";
////			cout<<ans;
//			return 0;	
//		}
		scanf("%d",&a);
		if(b=='+'){
			ans+=x+a;
			cout<<x<<"+"<<a<<endl;
		}
		if(b=='*'){
			ans+=x*a;
			cout<<x<<"*"<<a<<endl;
		}
		cout<<ans<<"****"<<endl;
		x=a;
	}
//	cout<<ans;
	return 0;
}
