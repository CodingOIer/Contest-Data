#include <bits/stdc++.h>
using namespace std;
long long m;
string s;
long long ans=0;
int f(int n){
	int x=0;
	long long sum=0;
	for(int i=n-1;i<m;i++){
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'){
			break;
		}
		else{
			x++;
//			cout<<s[i]<<" "<<x<<endl;
		}
	}
	int y=1;
	for(int i=n+x-2;i>=n-1;i--){
		sum+=y*int(s[i]-48);
//		cout<<s[i]<<" "<<int(s[i]-48)<<" "<<y<<endl;
		y*=10;
	}
	return sum;
}
int main(){
	cin>>s;
	m=s.length();
//	ans+=f(1);
	for(int i=0;i<=s.length();i++){
		if(s[i]=='*'){
			for(int j=i-1;j>=0;j--){
				cout<<j<<endl;
				if(s[j]=='+'||s[j]=='-'||s[j]=='*'||j==0){
					int z=f(j+1)*f(i+1);
//					cout<<i<<" "<<j<<endl;
//					cout<<f(i+2)<<" "<<f(j+1)<<endl;
					ans+=f(j+1)*f(i+2);
					break; 
				}
			}
		}
	}
//	cout<<f(1)<<endl;
	cout<<ans;
	return 0;
}
