#include <bits/stdc++.h>
using namespace std;
int a[1001][1001];
int main(){
	int n,m;
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	int x,y,c;
	int o=0;
	for(int i=1;i<=n;i++){
		cin>>x>>y>>c;
		a[x][y]=c+1;
		if(max(x,y)>o){
			o=max(x,y);
		}
	}
	cout<<-1;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<a[i][j]<<" ";
//		}
//		cout<<endl;
//	}
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
*/
