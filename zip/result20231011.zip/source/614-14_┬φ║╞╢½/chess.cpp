#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e2+5;
int m,n,ans=2e9;
bool v[Max][Max];
int a[Max][Max],f[Max][Max][2],dx[]={-1,1,0,0},dy[]={0,0,-1,1};
void dfs(int x,int y,int sum,bool flag){
	if(x==m&&y==m){
		ans=min(ans,sum);
		return ;
	}
	if(!a[x][y]||v[x][y]||x<1||y<1||x>m||y>m||sum>=ans||f[x][y][flag]<=sum) return ;
	f[x][y][flag]=sum;
	v[x][y]=1;
	for(int i=0;i<4;i++){
		int fx=x+dx[i],fy=y+dy[i];
		if(a[x][y]==a[fx][fy]) dfs(fx,fy,sum,0);
		else if(!a[fx][fy]&&!flag){
			a[fx][fy]=a[x][y];
			dfs(fx,fy,sum+2,1);
			a[fx][fy]=0;
		}
		else dfs(fx,fy,sum+1,0);
	}
	v[x][y]=0;
}
signed main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	while(n--){
		int x,y,c;
		cin>>x>>y>>c;
		a[x][y]=c+1;
	}
	memset(f,0x3f,sizeof(f));
	dfs(1,1,0,0);
	if(ans==2e9) ans=-1;
	cout<<ans;
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

5 5
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0
*/
