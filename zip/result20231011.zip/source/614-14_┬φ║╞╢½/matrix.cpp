#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e5+5;
int n,x,y,k,i=1,j=1;
int a[105][105];
void build() {
	a[1][1]=++k;
	while(k!=n*n) {
		while(!a[i][j+1]&&j+1<=n){
			a[i][++j]=++k;
			if(i==x&&j==y) return ;
		} 
		while(!a[i+1][j]&&i+1<=n){
			a[++i][j]=++k;
			if(i==x&&j==y) return ;
		} 
		while(!a[i][j-1]&&j-1>=1){
			a[i][--j]=++k;
			if(i==x&&j==y) return ;
		} 
		while(!a[i-1][j]&&i-1>=1){
			a[--i][j]=++k;
			if(i==x&&j==y) return ;
		} 
	}
}
signed main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	build();
	cout<<a[x][y];
	return 0;
}

