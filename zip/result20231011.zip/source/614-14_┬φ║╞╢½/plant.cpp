#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e3+5,mod=998244353;
int T,id,n,m,c,f,ansc,ansf;
char ch;
int a[Max][Max];
void C() {
	for(int x1=1; x1<=n; x1++){
		for(int x2=x1+2; x2<=n; x2++){
			for(int y0=1; y0<=m; y0++){
				for(int y1=y0+1; y1<=m; y1++){
					for(int y2=y0+1; y2<=m; y2++) {
						bool flag=0;
						for(int k=y0; k<=y1; k++)
							if(a[x1][k]) {
								flag=1;
								break;
							}
						if(flag) break;
						for(int k=y0; k<=y2; k++)
							if(a[x2][k]) {
								flag=1;
								break;
							}
						if(flag) break;
						for(int k=x1;k<=x2;k++)
							if(a[k][y0]){
								flag=1;
								break;
							}
						if(flag) break;
						ansc=(ansc+1)%mod;
					}
				}
			}
		} 
	} 				
}
void F() {
	for(int x1=1; x1<=n; x1++){
		for(int x2=x1+2; x2<=n; x2++){
			for(int x3=x2+1; x3<=n; x3++){
				for(int y0=1; y0<=m; y0++){
					for(int y1=y0+1; y1<=m; y1++){
						for(int y2=y0+1; y2<=m; y2++) {
							bool flag=0;
							for(int k=y0;k<=y1;k++)
								if(a[x1][k]){
									flag=1;
									break;
								}
							if(flag) break;
							for(int k=y0;k<=y2;k++)
								if(a[x2][k]){
									flag=1;
									break;
								}	
							if(flag) break;
							for(int k=x1;k<=x3;k++)
								if(a[k][y0]){
									flag=1;
									break;
								}	
							if(flag) break;
							ansf=(ansf+1)%mod;	
						}
					}
				}
			}
		}
	} 	
}
signed main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%lld%lld",&T,&id);
	while(T--) {
		scanf("%lld%lld%lld%lld",&n,&m,&c,&f);
		ansc=ansf=0;
		for(int i=1;i<=n;i++)	
			for(int j=1;j<=m;j++)
				cin>>ch,a[i][j]=ch-'0';
		if(c) C();
		if(f) F();
		printf("%lld %lld\n",ansc*c%mod,ansf*f%mod);
	}
	return 0;
}
/*
1 0
4 3 1 1
001
010
000
000

1 0
6 6 1 1
000010
011000
000110
010000
011000
000000

1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

*/
