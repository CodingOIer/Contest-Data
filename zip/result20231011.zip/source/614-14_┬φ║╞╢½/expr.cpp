#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Max=1e6+5,mod=10000;
int n,i2,top,ans;
string s;
int stk[Max];
int f(int i){
	int t=0;
	bool f=0;
	if(s[i]=='-') f=1;
	while(s[i+1]>='0'&&s[i+1]<='9'&&i+1<n) t=(10*t+(s[++i]-'0'))%mod;
	i2=i;
	if(f) t=-t;
	return t;
}
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	n=s.size();
	if(s[0]!='-') stk[++top]=f(-1);
	int i=i2;
	for(i;i<n;i++){
		if(s[i]=='+'||s[i]=='-') stk[++top]=f(i),i=i2;
		if(s[i]=='*') stk[top]=(f(i)*stk[top])%mod,i=i2;
	}
	for(int i=1;i<=top;i++) ans=(ans+stk[i])%mod;
	cout<<ans;
	return 0;
}
