#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("chess.in","r",stdin);
	freopne("chess.out","w",stdout);
	cout << -1;
	return 0;
}
