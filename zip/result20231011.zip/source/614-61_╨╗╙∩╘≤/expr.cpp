#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("expr.in", "r", stdin);
    freopen("expr.out", "w", stdout);
    int a, num, sum = 0;
    char f;
    cin >> a;
    while (scanf("%c%d", &f, &num) == 2)
    {
        if (f == '*')
            a = a * num % 10000;
        else
        {
        	if(f == '+') sum = (sum + a) % 10000, a = num;
        	else sum = (sum + a) % 10000, a = -num;
		}
    }
	if(f == '+') sum = (sum + a) % 10000, a = num;
	else sum = (sum + a) % 10000, a = -num;
    cout << sum << endl;
    return 0;
}
