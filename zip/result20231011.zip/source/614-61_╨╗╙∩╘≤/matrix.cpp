#include <bits/stdc++.h>
using namespace std;
int n,i,j;
void build()
{
	int f1 = 1,f2 = n-1,f3 = 0,f4 = n-1,x = 0,y = 0,f = 0;
	for(int k = 1;k <= n*n;k++)
	{
		if(x == i-1 && y == j-1)
		{
			cout << k;
			exit(0);
		}
		if(f == 0)
		{
			if(y == f2) {f = 1,x++,f2--;continue;}
			else y++;
		}
		if(f == 1)
		{
			if(x == f4) {f = 2,y--,f4--;continue;}
			else x++;
		}
		if(f == 2)
		{
			if(y == f3) {f = 3,x--,f3++;continue;}
			else y--;
		}
		if(f == 3)
		{
			if(x == f1) {f = 0,y++,f1++;continue;}
			else x--;
		}
	}
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin >> n >> i >> j;
	build();
	return 0;
}
