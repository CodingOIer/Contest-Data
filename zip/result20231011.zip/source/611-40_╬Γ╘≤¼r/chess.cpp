#include<bits/stdc++.h>
using namespace std;

int n,m,ci,cj,cc,qdp[110][110][2];

int dg(int i,int j,int b,int c,bool f){
	if(qdp[i][j][1]>b+f+qdp[i][j][0]!=c){
		qdp[i][j][1]=b+f+qdp[i][j][0]!=c;
		if(i==m && j==m){
			return 0;
		}
		if(i<m && !(f && qdp[i+1][j][0]==0)){
			dg(i+1,j,qdp[i][j][1],qdp[i+1][j][0],qdp[i+1][j][0]==0);
		}
		if(j<m && !(f && qdp[i][j+1][0]==0)){
			dg(i,j+1,qdp[i][j][1],qdp[i+1][j][0],qdp[i][j+1][0]==0);
		}
		if(i>1 && !(f && qdp[i-1][j][0]==0)){
			dg(i-1,j,qdp[i][j][1],qdp[i+1][j][0],qdp[i-1][j][0]==0);
		}
		if(j>1 && !(f && qdp[i][j-1][0]==0)){
			dg(i,j-1,qdp[i][j][1],qdp[i+1][j][0],qdp[i][j-1][0]==0);
		}
	}
	return 0;
}

int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	for(int i=1;i<=110;i++){
		for(int j=1;j<=110;j++){
			qdp[i][j][1]=25000;
		}
	}
	cin>>m>>n;
	for(int i=1;i<=n;i++){
		cin>>ci>>cj>>cc;
		qdp[ci][cj][0]=cc+1;
	}
	dg(1,1,0,qdp[1][1][0],0);
	if(qdp[m][m][1]==25000){
		cout<<-1;
	}else{
		cout<<qdp[m][m][1];
	}
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
*/
