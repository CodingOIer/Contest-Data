#include<bits/stdc++.h>
using namespace std;

string s;
int sl,h,js[500001],ji,bj=1;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	sl=s.size();
	for(int i=0;i<sl;i++){
		if(s[i]>='0' && s[i]<='9'){
			h=(h*10+s[i]-'0')%10000;
		}else{
			if(bj==0){
				js[ji]=js[ji]*h%10000;
			}else{
				ji++;
				js[ji]=bj*h;
			}
			h=0;
			if(s[i]=='+'){
				bj=1;
			}else if(s[i]=='-'){
				bj=-1;
			}else{
				bj=0;
			}
		}
	}
	if(bj==0){
		js[ji]=js[ji]*h%10000;
	}else{
		ji++;
		js[ji]=bj*h;
	}
	h=0;
	for(int i=0;i<=ji;i++){
		h=(h+js[i])%10000;
	}
	cout<<h;
	return 0;
}
