#include<bits/stdc++.h>
using namespace std;

int n,ni,nj,z,h,i;

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>ni>>nj;
	for(i=1;ni!=i && nj!=i && ni!=n-i+1 && nj!=n-i+1 && i<n/2;i++){
		h=h+(n-i)*4;
	}
	for(int j=i;j<n-i+1;j++){
		h++;
		if(ni==i && nj==j){
			cout<<h;
			return 0;
		}
	}
	for(int j=i;j<n-i+1;j++){
		h++;
		if(ni==j && nj==n-i+1){
			cout<<h;
			return 0;
		}
	}
	for(int j=n-i+1;j>i;j--){
		h++;
		if(ni==n-i+1 && nj==j){
			cout<<h;
			return 0;
		}
	}
	for(int j=n-i+1;j>i;j--){
		h++;
		if(ni==j && nj==i){
			cout<<h;
			return 0;
		}
	}
	return 0;
}
