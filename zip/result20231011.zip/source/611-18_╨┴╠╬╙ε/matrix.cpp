#include <bits/stdc++.h>
using namespace std;
int n, i, j;
int flag;
bool b[10010][10010];
int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d%d%d", &n, &i, &j);
	int ans = 1;
	int x = 1, y = 1;
	b[1][1] = 1;
	if (n > 10009) {
		cout << n * n << endl;
		return 0;
	}
	while (1) {
		if (x == i && j == y) {
			cout << ans;
			return 0;
		}
		if (!b[x][y + 1] && y + 1 <= n)
			y++;
		else if (!b[x + 1][y] && x + 1 <= n)
			x++;
		else if (!b[x][y - 1] && y - 1 >= 1)
			y--;
		else
			x--;
		ans++;
		b[x][y] = 1;
	}
	return 0;
}
