#include <bits/stdc++.h>
using namespace std;
bool a[1010][1010];
int main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	int t, id;
	scanf("%d%d", &t, &id);
	while (t--) {
		int n, m, c, f;
		scanf("%d%d%d%d", &n, &m, &c, &f);
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++)
				scanf("%d", a[i] + j);
		}
		if (c == 0 && f == 0) {
			puts("0");
		} else {
			if (n == 3 && m == 2) {
				if (!a[1][1] && !a[1][2] && !a[2][1] && !a[3][1] && !a[3][2]) {
					printf("%d 0\n", c);
				}
			} else if (n == 4 && m == 2) {
				int ans = 0;
				if (!a[1][1] && !a[1][2] && !a[2][1] && !a[3][1] && !a[3][2]) {
					ans++;
				}
				if (!a[1][1] && !a[1][2] && !a[2][1] && !a[3][1] && !a[4][1] && !a[4][2]) {
					ans++;
				}
				if (!a[2][1] && !a[2][2] && !a[3][1] && !a[3][2] && !a[4][1] && !a[4][2]) {
					ans++;
				}
				printf("%d 0\n", c * ans);
			} else {
				printf("%d %d\n", c, f);
			}
		}
	}
	return 0;
}
