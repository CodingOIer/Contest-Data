#include <bits/stdc++.h>
using namespace std;
int m, n; //m��m��
int a[110][110];
int b[110][110];
bool c[110][110][2];
struct node {
	int x, y;
	bool mofa, color;
};
queue<node> q1;
int dx[] = {0, 0, -1, 1};
int dy[] = {-1, 1, 0, 0};
void bfs(int x, int y) {
	q1.push({x, y, 1, a[1][1]});
	b[x][y] = 0;
	c[x][y][0] = 1;
	while (!q1.empty()) {
		node t = q1.front();
		q1.pop();
		for (int i = 0; i < 4; i++) {
			int xx = t.x + dx[i];
			int yy = t.y + dy[i];
			if (xx >= 1 && xx <= m && yy >= 1 && yy <= m) {
				int ans = 0;
				bool k = t.mofa;
				bool g = a[xx][yy];
				if (a[xx][yy] == -1) { //����ɫ
					if (k == 0)
						continue;
					ans = 2;
					k = 0;
					g = t.color;
				} else if (a[xx][yy] != t.color) {
					ans = 1;
					k = 1;
				} else
					k = 1;
				if (b[xx][yy] > b[t.x][t.y] + ans) {
					b[xx][yy] = b[t.x][t.y] + ans;
					if (!c[xx][yy][k])
						q1.push({xx, yy, k, g}), c[xx][yy][k] = 1;
				}
			}
		}
	}
}
int main() {
	freopen("chess.in", "r", stdin);
	freopen("chess.out", "w", stdout);
	memset(a, -1, sizeof(a));
	for (int i = 1; i <= 100; i++)
		for (int j = 1; j <= 100; j++)
			b[i][j] = 1919811451;
	scanf("%d%d", &m, &n);
	for (int i = 1; i <= n; i++) {
		int x, y, c;
		scanf("%d%d%d", &x, &y, &c);
		a[x][y] = c;
	}
	bfs(1, 1);
	if (b[m][m] == 1919811451)
		puts("-1");
	else {
		printf("%d\n", b[m][m]);
	}
//	for (int i = 1; i <= m; i++) {
//		for (int j = 1; j <= m; j++) {
//			cout << setw(10) << b[i][j] << ' ';
//		}
//		puts("");
//	}
	return 0;
}
