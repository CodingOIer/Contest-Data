#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
stack<ll> si;
stack<char> sc;
int main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	string a;
	cin >> a;
	a += '/';
	ll n = 0;
	for (int i = 0; i < a.size(); i++) {
		if (isdigit(a[i]))
			n = n * 10 + (a[i] - '0');
		else if (a[i] == '*') {
			n %= 100000;
			si.push(n);
			n = 0;
			sc.push(a[i]);
		} else if (a[i] == '+' || a[i] == '-') {
			//������Ӱ�졣
			n %= 100000;
			si.push(n);
			while (!sc.empty() && sc.top() == '*') {
				sc.pop();
				ll k = si.top();
				si.pop();
				ll t = si.top();
				si.pop();
				si.push(k * t % 100000);
			}
			n = 0;
			sc.push(a[i]);
		} else {
			n %= 100000;
			si.push(n);
			n = 0;
		}
	}
	while (!sc.empty()) {
		bool flag = true;
		char f = sc.top();
		sc.pop();
		ll c = si.top();
		si.pop();
		ll k = si.top();
		if (c > k)
			flag = false;
		si.pop();
		if (f == '+')
			si.push((c + k) % 100000);
		else if (f == '-')
			si.push((k - c) % 100000);
		else
			si.push(c * k % 100000);
	}
	cout << si.top() % 10000;
	si.pop();
	return 0;
}
