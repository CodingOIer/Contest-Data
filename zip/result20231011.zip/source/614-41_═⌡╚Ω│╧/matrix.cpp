#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,i,j;
	cin>>n>>i>>j;
	int sum=1,time=1,c=n-1;
	int x=1,y=1;
	while(1){
		if(time==1){
			for(int k=1;k<=3;k++){
				if(x==i){
					sum=sum+abs(j-y);
					cout<<sum;
					return 0;
				}
				if(y==j&&x!=1&&y!=1){
					sum=sum+abs(i-x);
					cout<<sum;
					return 0;
				}
				if(time%4==1)	y+=c;
				if(time%4==2)	x+=c;
				if(time%4==3)	y-=c;
				sum+=c;
				time++;
			}
			c--;
		}
		for(int k=1;k<=2;k++){
				if(x==i){
					sum=sum+abs(j-y);
					cout<<sum;
					return 0;
				}
				if(y==j){
					sum=sum+abs(i-x);
					cout<<sum;
					return 0;
				}
				if(time%4==1)	y+=c;
				if(time%4==2)	x+=c;
				if(time%4==3)	y-=c;
				if(time%4==0)	x-=c;
				sum+=c;
				time++;
		}
		c--;
	}
	return 0;
}

