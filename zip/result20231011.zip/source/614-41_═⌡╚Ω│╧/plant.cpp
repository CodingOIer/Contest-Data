#include<bits/stdc++.h>
using namespace std;
const long long mod=998244353;
int t,id,n,m,c,f;
bool a[1005][1005];long long sum[1005][1005];
long long ansc,ansf;
void cg(){
	for(int j=1;j<=m;j++){
		for(int i=1;i<=n;i++){
			if(a[i][j]){
				i++;continue;
			}
			for(int k=i+1;k<=n;k++){
				if(a[k][j])	break;
				if(k-i>=2)	ansc=(ansc+(sum[i][j]-1)*(sum[k][j]-1))%mod;
			}
		}
	}
}
void fg(){
	for(int j=1;j<=m;j++){
		for(int i=1;i<=n;i++){
			if(a[i][j]){
				i++;continue;
			}
			for(int k=i+1;k<=n;k++){
				if(a[k][j])	break;
				if(k-i>=2){
					for(int s=i+1;s<k;s++)	ansf=(ansf+(sum[i][j]-1)*(sum[s][j]-1))%mod;
				}
			}
		}
	}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	scanf("%d%d",&t,&id);
	while(t--){
		scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				char x=getchar();
				while(x<'0'||c>'1')	x=getchar();
				a[i][j]=x-'0';
			}
		}
		for(int i=n;i>=1;i--)
			for(int j=m;j>=1;j--)
				if(!a[i][j])	sum[i][j]=sum[i][j+1]+1;
		cg();fg();
		cout<<(ansc*c)%mod<<" "<<(ansf*f)%mod;
	}
	return 0;
}

