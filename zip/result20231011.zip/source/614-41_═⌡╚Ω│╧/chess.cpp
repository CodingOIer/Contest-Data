#include<bits/stdc++.h>
using namespace std;
int m,n;
const int N=1e9;
bool a[105][105],b[105][105];
int c[105][105];
int ans=N;
void dfs(int x,int y){
	int sum=0,flag=0;
	cout<<x<<" "<<y<<endl;
	if(x==m&&y==m){
		ans=min(ans,sum);
		return;
	}
	if(x<m&&b[x+1][y]==0&&(flag==0||a[x+1][y]!=-1))
		if(a[x+1][y]==-1){
			flag=1;
			sum+=2;
			a[x+1][y]=a[x][y];
			b[x+1][y]=1;
			dfs(x+1,y);
			sum-=2;
			b[x+1][y]=0;
			a[x+1][y]=-1;
			flag=0;
		}
		else{
			flag=0;
			int q=0;
			if(a[x][y]!=a[x+1][y]){
				sum++,q=1;
			}
			b[x+1][y]=1;
			dfs(x+1,y);
			b[x+1][y]=0;
			if(q==1)	sum--;
		}
	if(x>1&&b[x-1][y]==0&&(flag==0||a[x-1][y]!=-1))
		if(a[x-1][y]==-1){
			flag=1;
			sum+=2;
			a[x-1][y]=a[x][y];
			b[x-1][y]=1;
			dfs(x-1,y);
			sum-=2;
			b[x-1][y]=0;
			a[x-1][y]=-1;
			flag=0;
		}
		else{
			flag=0;
			int q=0;
			if(a[x][y]!=a[x-1][y]){
				sum++;q=1;
			}
			b[x-1][y]=1;
			dfs(x-1,y);
			b[x-1][y]=0;
			if(q==1)	sum--;
		}
	if(y<m&&b[x][y+1]==0&&(flag==0||a[x][y+1]!=-1))
		if(a[x][y+1]==-1){
			flag=1;
			sum+=2;
			a[x][y+1]=a[x][y];
			b[x][y+1]=1;
			dfs(x,y+1);
			sum-=2;
			b[x+1][y]=0;
			a[x+1][y]=-1;
			flag=0;
		}
		else{
			flag=0;
			int q=0;
			if(a[x][y]!=a[x][y+1]){
				sum++;q=1;
			}
			b[x][y+1]=1;
			dfs(x,y+1);
			b[x][y+1]=0;
			if(q==1)	sum--;
		}
	if(y>1&&b[x][y-1]==0&&(flag==0||a[x][y-1]!=-1))
		if(a[x][y-1]==-1){
			flag=1;
			sum+=2;
			a[x][y-1]=a[x][y];
			b[x][y-1]=1;
			dfs(x,y-1);
			sum-=2;
			b[x][y-1]=0;
			a[x][y-1]=-1;
			flag=0;
		}
		else{
			flag=0;
			int q=0;
			if(a[x][y]!=a[x][y-1]){
				sum++;q=1;
			}
			b[x][y-1]=1;
			dfs(x,y-1);
			b[x][y-1]=0;
			if(q==1)	sum--;
		}
	return;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d",&m,&n);
	b[1][1]=1;
	for(int i=1;i<=m;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=-1;
	for(int i=1;i<=n;i++){
		int x,y,color;
		scanf("%d%d%d",&x,&y,&color);
		a[x][y]=color;
	}
	cout<<-1;
	return 0;
	dfs(1,1);
	if(ans==N){
		cout<<-1;
		return 0;
	}
	cout<<ans;
	return 0;
}
