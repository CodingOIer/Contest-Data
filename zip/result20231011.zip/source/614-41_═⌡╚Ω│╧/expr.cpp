#include<bits/stdc++.h>
using namespace std;
int a[100005];
bool b[100005];
int ans,sum1,sum2;
void read(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int x=0;
	char c,q;
	while(c!='\n'){
		c=getchar();
		if(c>='0'&&c<='9'){
			x=x*10+c-'0';
		}
		if(c<'0'||c>'9'){
			x%=10000;
			sum1++;
			a[sum1]=x;
			x=0;
			if(c=='*'){
				a[sum1-1]=(a[sum1]*a[sum1-1])%10000;
				sum1--;
			}
			if(c=='+'){
				sum2++;
				b[sum2]=1;
			}
			if(c=='-'){
				sum2++;
				b[sum2]=0;
			}
		}
		q=c;
	}
}
int main(){
	read();
	int flag=0;
	if(sum1>sum2){
		ans+=a[1];
		flag=1;
	}
	for(int i=1,j=1;i<=sum1,j<=sum2;i++,j++){
		if(flag==1){
			i++;
			flag=0;
		}
		if(b[j]==1)ans=(ans+a[i])%10000;
		if(b[j]==0)ans=ans-a[i];
	}	
	cout<<ans;
	return 0;
}
