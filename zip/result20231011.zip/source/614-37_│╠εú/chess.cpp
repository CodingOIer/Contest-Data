#include<bits/stdc++.h>
using namespace std;
long long m,n,a[102][200],p[102][102],sum=1e9;
void in() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
}
void dfs(int i,int j,int zt,long long ans) {
//	cout<<i<<" "<<j<<" "<<zt<<" "<<a[i][j]<<" "<<ans<<endl;
	if(a[i][j]!=0&&zt==1) zt=0;
	if(i==m&&j==m) {
		sum=min(ans,sum);
		return ;
	}
	if(zt==2) return ;
	if(i+1<=m&&p[i+1][j]==0) {
		long long y=ans;
		int o=zt;
		if(a[i+1][j]==0&&zt==1) return ;
		if(a[i+1][j]==0&&zt==0)   o++;
		if(a[i][j]!=a[i+1][j])  y++;
		if(a[i+1][j]==0)  y++;
		p[i+1][j]=1;
		dfs(i+1,j,o,y);
		p[i+1][j]=0;
	}
	if(j+1<=m&&p[i][j+1]==0) {
		long long y=ans;
		int o=zt;
		if(a[i][j+1]==0&&zt==1) return ;
		if(a[i][j+1]==0&&zt==0)  o++;
		if(a[i][j]!=a[i][j+1]) y++;
		if(a[i][j+1]==0) y++;
		p[i][j+1]=1;
		dfs(i,j+1,o,y);
		p[i][j+1]=0;
	}
	if(j-1<=m&&p[i][j-1]==0) {
		long long y=ans;
		int o=zt;
		if(a[i][j-1]==0&&zt==1) return ;
		if(a[i][j-1]==0&&zt==0)  o++;
		if(a[i][j]!=a[i][j-1]) y++;
		if(a[i][j-1]==0) y++;
		p[i][j-1]=1;
		dfs(i,j-1,o,y);
		p[i][j-1]=0;
	}
	if(i+1<=m&&p[i-1][j]==0) {
		long long y=ans;
		int o=zt;
		if(a[i-1][j]==0&&zt==1) return ;
		if(a[i-1][j]==0&&zt==0)   o++;
		if(a[i][j]!=a[i-1][j])  y++;
		if(a[i-1][j]==0)  y++;
		p[i-1][j]=1;
		dfs(i-1,j,o,y);
		p[i-1][j]=0;
	}
}

int main() {
	in();
	cin>>m>>n;

	for(int i=1; i<=n; i++) {
		int x,y,z;
		cin>>x>>y>>z;
		a[x][y]=z+1;
	}
	if(m>20){
		cout<<"-1";
		return 0;
	}
//	cout<<endl;
/*	for(int i=1; i<=m; i++) {
		for(int j=1; j<=m; j++) cout<<a[i][j]<<" ";
		cout<<endl;
	}//*/
//	cout<<sum;
	dfs(1,1,0,0);
	if(sum==1e9) cout<<"-1";
	else cout<<sum-1;
}

