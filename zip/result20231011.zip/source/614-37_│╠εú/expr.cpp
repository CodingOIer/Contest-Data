#include<bits/stdc++.h>
using namespace std;
long long ans,id=1,a[100009],pd,mod=10000,p;
string s;
void in(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
}
int main() {
	in();
	cin>>s;
	long long n=s.size();
	for(long long  i=0; i<=n; i++) {
		if(s[i]>='0'&&s[i]<='9') {
			a[id]=a[id]*10;
			a[id]+=(s[i]-'0');
		}
	    else {
		if(pd==1){
	    	a[id-1]=(a[id-1]*a[id])%mod;
	    	a[id]=0;
	    	id--;
	    	pd=0;
		}
		if(p==1){
			a[id]*=-1;
			p=0;
		}
	    id++;
		if(s[i]=='*'){
			pd=1;
		}	
		if(s[i]=='-'){
			p=1;
		}
		}
	}
//	cout<<id;
	for(int i=1; i<=id-1; i++){
		//cout<<a[i]<<" ";
		ans=a[i]+ans;
		//if(ans>=0)
		ans%=mod;
	} 
//	cout<<endl;
	cout<<ans;
}
