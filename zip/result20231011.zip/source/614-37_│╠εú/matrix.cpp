#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a[1002][1000],i=1,j=1,z,x,p;
void in() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}
int main() {
	in();
	cin>>n>>m>>k;
//	if(n<=100) {
		for(int o=1; o<=n*n; o++) {
			a[i][j]=o;
			if(p==0) j++;
			if(p==1) i++;
			if(p==2) j--;
			if(p==3) i--;
			if(a[i][j]>0||j==n+1||j==0||i==n+1||i==0) {
				if(p==0) j--;
				if(p==1) i--;
				if(p==2) j++;
				if(p==3) i++;
				p++;
				p%=4;
				if(p==0) j++;
				if(p==1) i++;
				if(p==2) j--;
				if(p==3) i--;
			}
		}
		cout<<a[m][k];
		return 0;
	
	if(m==1){
		cout<<k;
		return 0;
	}
		
}
