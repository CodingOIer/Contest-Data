#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,c,d,e,mn=INT_MAX;
short t[101][101],f[4][2]={{1,0},{0,1},{0,-1},{-1,0}};
bool bj[101][101];
inline void dfs(ll x,ll y,ll m)
{
	if(x==a&&y==a)
	{
		mn=min(mn,m);
		return;
	}
	for(int i=0;i<4;i++)
	{
		if(x+f[i][0]<=a&&y+f[i][1]<=a&&x+f[i][0]>=1&&y+f[i][1]>=1)
		{
			if(t[x+f[i][0]][y+f[i][1]]!=-1&&!bj[x+f[i][0]][y+f[i][1]])
			{
				if(t[x+f[i][0]][y+f[i][1]]==t[x][y])
				{
					bj[x+f[i][0]][y+f[i][1]]=1;
					dfs(x+f[i][0],y+f[i][1],m);
					bj[x+f[i][0]][y+f[i][1]]=0;
				}
				else
				{
					bj[x+f[i][0]][y+f[i][1]]=1;
					dfs(x+f[i][0],y+f[i][1],m+1);
					bj[x+f[i][0]][y+f[i][1]]=0;
				}
			}
			else
			{
				for(int j=0;j<4;j++)
				{
					if(x+f[i][0]+f[j][0]<=a&&y+f[i][1]+f[j][1]<=a&&x+f[i][0]+f[j][0]>=1&&y+f[i][1]+f[j][1]>=1)
					{
						if(t[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]!=-1&&!bj[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]])
						{
							if(t[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]==t[x][y])
							{
								bj[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]=1;
								dfs(x+f[i][0]+f[j][0],y+f[i][1]+f[j][1],m+2);
								bj[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]=0;
							}
							else
							{
								bj[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]=1;
								dfs(x+f[i][0]+f[j][0],y+f[i][1]+f[j][1],m+3);
								bj[x+f[i][0]+f[j][0]][y+f[i][1]+f[j][1]]=0;
							}
						}
					}
				} 
			}
		}
	}
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%lld %lld",&a,&b);
	for(int i=1;i<=a;i++)
	{
		for(int j=1;j<=a;j++)
		{
			t[i][j]=-1;
		}
	}
	for(int i=1;i<=b;i++)
	{
		scanf("%lld %lld %lld",&c,&d,&e);
		t[c][d]=e;
	}
	dfs(1,1,0);
	if(mn==INT_MAX)
	{
		cout<<-1;
		return 0;
	}
	cout<<mn;
	return 0;
}
