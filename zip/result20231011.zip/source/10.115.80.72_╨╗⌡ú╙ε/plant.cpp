#include<bits/stdc++.h>
#define ll long long
using namespace std;
int a,b,x,y,z,h,f;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=a;i++)
	{
		scanf("%d %d %d %d",&x,&y,&z,&h);
		for(int j=1;j<=x;j++)
		{
			for(int j2=1;j2<=y;j2++)
			{
				scanf("%d",&f);
			}
		}
	}
	if(b==1)
	{
		for(int i=1;i<=a;i++)
		{
			cout<<0<<" "<<0<<endl;
		}
	}
	else
	{
		cout<<1145141919810;
	}
	return 0;
}
