#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,x,y,f=0,t;
bool x3=1,y3=0;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>a>>x>>y;
	t=a;
	for(int i=1;i<=a/2;i++)
	{
		if(x==i||x==(a-i+1)||y==i||y==(a-i+1))
		{
			int x2=i,y2=i;
			f++;
			while(1)
			{
				if(x2==x&&y2==y)
				{
					cout<<f;
					return 0;
				}
				if(x3)
				{
					if(!y3)
					{
						if(y2+1>a-i+1)
						{
							x3=0,x2++;
						}
						else
						{
							y2++;
						}
					}
					else
					{
						if(y2-1<i)
						{
							x3=0,x2--;
						}
						else
						{
							y2--;
						}
					}
				}
				else
				{
					if(!y3)
					{
						if(x2+1>a-i+1)
						{
							x3=1,y3=1,y2--;
						}
						else
						{
							x2++;
						}
					}
					else
					{
						if(x2-1<i)
						{
							x3=1,y3=0,y2++;
						}
						else
						{
							x2--;
						}
					}
				}
				f++;
			}
		}
		f+=t*4-4;
		t-=2;
	}
	ll f2=a*a;
	cout<<f2;
	return 0;
}
