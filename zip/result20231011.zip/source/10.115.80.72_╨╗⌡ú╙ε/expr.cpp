#include<bits/stdc++.h>
#define ll long long
using namespace std;
char c[100001];
string s;
ll i,f=0,t=1,a[100005],b=0,sum,t2=1;
bool bj=0;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	i=s.size()-1;
	while(i>=0)
	{
		if(s[i]=='-'||s[i]=='+')
		{
			c[t2]=s[i];
			t2++,f=0;
			if(bj)
			{
				b%=10000;
				a[t]*=b;
				a[t]%=10000;
				bj=0,b=0;
			}
			t++;
		}
		else
		{
			if(s[i]=='*')
			{
				if(bj)
				{
					a[t]*=b;
					b=0;
				}
				f=0;
				bj=1;
			}
			else
			{
				if(bj)
				{
					int f3=s[i]-'0';
					b+=f3*pow(10,f);
					f++;
				}
				else
				{
					int f3=s[i]-'0';
					a[t]+=f3*pow(10,f);
					f++;
				}
			}
		}
		i--;
	}
	if(b!=0)
	{
		a[t]*=b;
	}
	sum=a[t];
	for(int i=t-1;i>=1;i--)
	{
		if(c[i]=='+')
		{
			sum+=a[i]%10000;
		}
		else
		{
			sum-=a[i]%10000;
		}
		sum%=10000;
	}
	cout<<sum%10000;
	return 0;
}
