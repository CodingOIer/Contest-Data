#include <cstdio>
#include <queue>
const int MaxM = 1e2 + 5;
class runner
{
  public:
    int x, y;
    int money;
    int color;
    bool magic;
    bool operator>(const runner &__x) const
    {
        return (*this).money < __x.money;
    }
    bool operator<(const runner &__x) const
    {
        return (*this).money > __x.money;
    }
};
int m, n;
int x, y, c;
int move_x[] = {-1, 1, 0, 0};
int move_y[] = {0, 0, -1, 1};
int color[MaxM][MaxM];
bool vis[2][2][MaxM][MaxM];
std::priority_queue<runner> bfs;
int main()
{
    freopen("chess.in", "r", stdin);
    freopen("chess.out", "w", stdout);
    scanf("%d%d", &m, &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d%d%d", &x, &y, &c);
        color[x][y] = c + 1;
    }
    runner t;
    t.x = 1;
    t.y = 1;
    t.money = 0;
    t.magic = true;
    vis[color[1][1]][0][1][1] = true;
    bfs.push(t);
    for (; !bfs.empty();)
    {
        t = bfs.top();
        bfs.pop();
        runner k;
        if (t.x == m && t.y == m)
        {
            printf("%d\n", t.money);
            return 0;
        }
        for (int move = 0; move < 4; move++)
        {
            k.x = t.x + move_x[move];
            k.y = t.y + move_y[move];
            if (!(1 <= k.x && k.x <= m && 1 <= k.y && k.y <= m))
            {
                continue;
            }
            if (color[k.x][k.y] != 0)
            {
                k.magic = true;
                if (color[k.x][k.y] == (color[t.x][t.y] == 0 ? t.color : color[t.x][t.y]) &&
                    !vis[color[k.x][k.y]][false][k.x][k.y])
                {
                    k.money = t.money;
                    vis[color[k.x][k.y]][false][k.x][k.y] = true;
                    bfs.push(k);
                }
                else if (color[k.x][k.y] != (color[t.x][t.y] == 0 ? t.color : color[t.x][t.y]) &&
                         !vis[color[k.x][k.y]][false][k.x][k.y])
                {
                    k.money = t.money + 1;
                    vis[color[k.x][k.y]][false][k.x][k.y] = true;
                    bfs.push(k);
                }
            }
            else if (color[k.x][k.y] == 0 && t.magic)
            {
                k.magic = false;
                if (!vis[color[t.x][t.y]][true][k.x][k.y])
                {
                    k.money = t.money + 2;
                    k.color = color[t.x][t.y];
                    vis[color[k.x][k.y]][true][k.x][k.y] = true;
                    bfs.push(k);
                }
                if (!vis[3 - color[t.x][t.y]][true][k.x][k.y])
                {
                    k.money = t.money + 3;
                    k.color = 3 - color[t.x][t.y];
                    vis[color[k.x][k.y]][true][k.x][k.y] = true;
                    bfs.push(k);
                }
            }
        }
    }
    printf("-1\n");
    return 0;
}