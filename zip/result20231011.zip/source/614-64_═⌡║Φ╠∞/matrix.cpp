#include <cstdio>
int n;
int x, y;
int answer;
int main()
{
    freopen("matrix.in", "r", stdin);
    freopen("matrix.out", "w", stdout);
    scanf("%d%d%d", &n, &x, &y);
    answer = 0;
    for (;;)
    {
        if (x == 1)
        {
            answer += y;
            break;
        }
        else if (x == n)
        {
            answer += n + n - 1 + (n - y);
            break;
        }
        else if (y == n)
        {
            answer += n + (x - 1);
            break;
        }
        else if (y == 1)
        {
            answer += n + n + n - 2 + (n - x);
            break;
        }
        else
        {
            answer += 4 * n - 4;
            n -= 2;
            x--;
            y--;
        }
    }
    printf("%d\n", answer);
    return 0;
}