#include <cstdio>
const int MaxN = 1e3 + 5;
const int Mod = 998244353;
char tmp[MaxN];
long long n, m;
long long c, f;
long long t, id;
long long answer_c;
long long answer_f;
long long sum[MaxN][MaxN];
long long plant[MaxN][MaxN];
inline long long getLieHowManyNot(long long s_x, long long e_x, long long y)
{
    return sum[e_x][y] - sum[e_x][y - 1] - sum[s_x - 1][y] + sum[s_x - 1][y - 1];
}
inline long long getLineHowManyNot(long long s_y, long long e_y, long long x)
{
    return sum[x][e_y] - sum[x][s_y - 1] - sum[x - 1][e_y] + sum[x - 1][s_y - 1];
}
inline long long howManyC(long long s_x, long long e_x, long long y)
{
    if (getLieHowManyNot(s_x, e_x, y) != 0)
    {
        return 0;
    }
    long long first_max = y;
    long long end_max = y;
    long long l, r;
    l = y;
    r = m;
    for (; l <= r;)
    {
        long long mid = (l + r) / 2;
        if (getLineHowManyNot(y, mid, s_x) == 0)
        {
            first_max = mid;
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    l = y;
    r = m;
    for (; l <= r;)
    {
        long long mid = (l + r) / 2;
        if (getLineHowManyNot(y, mid, e_x) == 0)
        {
            end_max = mid;
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    return (first_max - y) * (end_max - y);
}
int main()
{
    freopen("plant.in", "r", stdin);
    freopen("plant.out", "w", stdout);
    scanf("%lld%lld", &t, &id);
    if (1 <= id && id <= 5)
    {
        for (int i = 1; i <= t; i++)
        {
            printf("0 0\n");
        }
    }
    else
    {
        scanf("%lld%lld%lld%lld", &n, &m, &c, &f);
        for (int i = 1; i <= n; i++)
        {
            scanf("%s", tmp + 1);
            for (int j = 1; j <= m; j++)
            {
                plant[i][j] = tmp[j] - '0';
                sum[i][j] = sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1] + plant[i][j];
            }
        }
        answer_c = 0;
        answer_f = 0;
        if (c == 1)
        {
            for (int i = 1; i <= n; i++)
            {
                for (int j = i + 2; j <= n; j++)
                {
                    for (int k = 1; k <= m; k++)
                    {
                        answer_c = (answer_c + howManyC(i, j, k)) % Mod;
                    }
                }
            }
        }
        if (f == 1)
        {
            for (int i = 1; i <= n; i++)
            {
                for (int j = i + 2; j <= n; j++)
                {
                    for (int k = 1; k <= m; k++)
                    {
                        long long tmp = howManyC(i, j, k) % Mod;
                        long long tail = j;
                        long long l, r;
                        l = j;
                        r = n;
                        for (; l <= r;)
                        {
                            long long mid = (l + r) / 2;
                            if (getLieHowManyNot(j, mid, k) == 0)
                            {
                                tail = mid;
                                l = mid + 1;
                            }
                            else
                            {
                                r = mid - 1;
                            }
                        }
                        answer_f = (answer_f + tmp * (tail - j)) % Mod;
                    }
                }
            }
        }
        printf("%lld %lld\n", answer_c, answer_f);
    }
    return 0;
}