#include <cstdio>
#include <stack>
const int Mod = 10000;
char op;
long long x;
long long sum;
long long mod;
std::stack<long long> stack;
int main()
{
    freopen("expr.in", "r", stdin);
    freopen("expr.out", "w", stdout);
    scanf("%d", &x);
    mod += x / Mod;
    x %= Mod;
    stack.push(x);
    for (; scanf("%c%d", &op, &x) == 2 && (op == '+' || op == '-' || op == '*');)
    {
        if (op == '+')
        {
            mod += x / Mod;
            x %= Mod;
            stack.push(x);
        }
        else if (op == '-')
        {
            mod -= x / Mod;
            x %= Mod;
            stack.push(-x);
        }
        else if (op == '*')
        {
            int last = stack.top();
            stack.pop();
            mod -= last / Mod;
            mod += (x * last) / Mod;
            x %= Mod;
            stack.push((x * last) % Mod);
        }
    }
    for (; !stack.empty();)
    {
        sum += stack.top();
        for (; sum < 0 && mod > 0;)
        {
            sum += Mod;
        }
        for (; sum > 0 && mod < 0;)
        {
            sum -= Mod;
        }
        sum %= Mod;
        stack.pop();
    }
    printf("%d\n", sum);
    return 0;
}