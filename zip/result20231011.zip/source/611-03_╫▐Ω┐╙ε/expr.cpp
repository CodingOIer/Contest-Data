#include<bits/stdc++.h>
const long long N=10000;
using namespace std;
long long ans[100001],sum,l=1;
long long vis[100001];
char s[100001];
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	for(long long i=0; i<strlen(s); ++i) {
		if(s[i]>='0'&&s[i]<='9') {
			ans[l]=(ans[l]*10+(s[i]-48))%N;
		}
		if(s[i]=='+') {
			vis[l++]=1;
		}
		if(s[i]=='*') {
			long long tmp=0,tot=0;
			i++;
			for(; i<strlen(s); ++i) {
				tot=tmp;
				tmp=(tmp*10+(s[i]-48))%N;
				if(i==(strlen(s)-1)) {
					ans[l]*=tmp;
				}
				if(s[i]=='*'||s[i]=='+'||s[i]=='-') {
					i--;
					ans[l]=(ans[l]*tot)%N;
					break;
				}
			}
		}
		if(s[i]=='-') {
			vis[l++]=-1;
		}
	}
	sum=ans[1];
	for(long long i=2; i<=l; ++i) {
		sum=(sum+ans[i]*vis[i-1])%N;
	}
	printf("%lld ",sum);
	return 0;
}
