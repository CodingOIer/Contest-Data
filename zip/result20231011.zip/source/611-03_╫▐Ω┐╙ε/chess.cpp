#include<bits/stdc++.h>
const long long N=101,inf=-1;
using namespace std;
long long n,m,vis[N][N],dp[N][N];
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%lld%lld",&m,&n);
	for(long long i=1; i<=n; ++i) {
		long long u,v,w;
		scanf("%lld%lld%lld",&u,&v,&w);
		vis[u][v]=w+1;
	}
	dp[1][1]=0;
	for(long long i=1; i<=m; ++i) {
		for(long long j=2; j<=m; ++j) {
//			printf("%lld ",vis[i][j]);
			dp[i][j]=inf;
			if(vis[i][j]) {
				if(vis[i][j]==vis[i][j-1]&&dp[i][j-1]!=inf) {
					if(dp[i][j]!=inf) dp[i][j]=min(dp[i][j],dp[i][j-1]);
					else dp[i][j]=dp[i][j-1];
				} else if(vis[i][j-1]&&dp[i][j-1]!=inf) {
					if(dp[i][j]!=-1) dp[i][j]=min(dp[i][j],dp[i][j-1]+1);
					else dp[i][j]=dp[i][j-1]+1;
				}
				if(vis[i][j]==vis[i-1][j]&&dp[i-1][j]!=inf) {
					if(dp[i][j]!=inf) dp[i][j]=min(dp[i][j],dp[i-1][j]);
					else dp[i][j]=dp[i-1][j];
				} else if(vis[i-1][j]&&dp[i-1][j]!=inf) {
					if(dp[i][j]!=inf) dp[i][j]=min(dp[i][j],dp[i-1][j]+1);
					else dp[i][j]=dp[i-1][j]+1;
				}
				if(dp[i-1][j-1]!=inf) {
					if(vis[i-1][j-1]==vis[i][j]) {
						if(dp[i][j]!=inf) dp[i][j]=min(dp[i][j],dp[i-1][j-1]+2);
						else dp[i][j]=dp[i-1][j-1]+2;
					}else {
						if(dp[i][j]!=inf) dp[i][j]=min(dp[i][j],dp[i-1][j-1]+3);
						else dp[i][j]=dp[i-1][j-1]+3;
					}
				}
			}
		}
	}
//	for(long long i=1;i<=m;++i) {
//		for(long long j=1;j<=m;++j) {
//			printf("%lld ",dp[i][j]);
//		}
//		printf("\n");
//	}
	if(dp[m][m]!=inf) {
		printf("%lld",dp[m][m]);
	}else printf("-1");
	return 0;
}
/*
5 8
1 1 1
2 2 0
3 2 1
3 3 1
4 3 1
4 4 0
5 4 1
5 5 1
*/
