#include<bits/stdc++.h>
const long long N=101;
using namespace std;
long long dx[10]= {0,1,0,-1},dy[10]= {1,0,-1,0};
long long n,s[N][N],cnt=1,cnt1,cnt2;
bool vis[N][N];
inline void dfs(long long i,long long j,long long l) {
	s[i][j]=cnt++;
	if(i==cnt1&&j==cnt2) {
		printf("%lld",s[i][j]);
		return ;
	}
	long long x=i+dx[l],y=j+dy[l];
	if(s[x][y]||x==n+1||y==n+1||y==0||x==0) {
		l=(l+1)%4;
	}
	x=i+dx[l],y=j+dy[l];
//	vis[x][y]=true;
	dfs(x,y,l);
}
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%lld%lld%lld",&n,&cnt1,&cnt2);
	dfs(1,1,0);
	return 0;
}

