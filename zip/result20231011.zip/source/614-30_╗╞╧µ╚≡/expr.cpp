#include<bits/stdc++.h>
using namespace std;
long long ans,sum,temp;
char ch;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%lld",&sum);
	while(scanf("%c",&ch)!=EOF){
		if(ch=='\n')break;
		scanf("%lld",&temp);
		if(ch=='+')ans=(ans+sum)%10000,sum=temp;
		if(ch=='*')sum=(sum*temp)%10000;
	}
	ans=(ans+sum)%10000;
	printf("%lld",ans);
	return 0;
}
