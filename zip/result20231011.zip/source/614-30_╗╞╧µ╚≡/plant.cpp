#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const LL MOD=998244353;
LL N,M,c,f,ans1,ans2,T,id;
LL a[1005][1005],R[1005][1005],D[1005][1005];
void solve(){
	ans1=ans2=0;
	for(int i=1;i<=N;i++){
		for(int j=1;j<=M;j++){
			if(R[i][j]<2||D[i][j]<3)continue;
			LL temp=0;
			for(int k=i+2;k<=i+D[i][j]-1;k++)
				temp=(temp+((R[i][j]-1)*(R[k][j]-1)%MOD))%MOD;
			ans1=(ans1+temp)%MOD;
		}
	}
	for(int i=1;i<=N;i++){
		for(int j=1;j<=M;j++){
			if(R[i][j]<2||D[i][j]<4)continue;
			LL temp=0;
			for(int k=i+2;k<=i+D[i][j]-2;k++)
				temp=(temp+((((R[i][j]-1)*(R[k][j]-1)%MOD)*(i+D[i][j]-1-k))%MOD))%MOD;
			ans2=(ans2+temp)%MOD;
		}
	}
	ans1*=c;ans2*=f;
	printf("%lld %lld\n",ans1,ans2);
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld%lld%lld%lld%lld",&id,&N,&M,&c,&f);
		if(id==1){puts("0 0");continue;}
		for(int i=1;i<=N;i++){
			char ch[1145];
			scanf("%s",ch);
			for(int j=0;j<M;j++)
				a[i][j+1]=(ch[j]=='1');
		}	
		for(int i=1;i<=N;i++)
			for(int j=M;j>=1;j--)
				if(a[i][j]==0)R[i][j]=R[i][j+1]+1;
				else R[i][j]=0;
		for(int i=N;i>=1;i--)
			for(int j=1;j<=M;j++)
				if(a[i][j]==0)D[i][j]=D[i+1][j]+1;
				else D[i][j]=0;
		solve();
	}
	return 0;
}
