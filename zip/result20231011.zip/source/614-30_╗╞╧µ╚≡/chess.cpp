#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
LL N,M,e[105][105],f[105][105],ls[105][105];
LL nxt[4][2]= {{ 1, 0},{ 0, 1},
  {-1, 0},{ 0,-1}
};
int main() {
  freopen("chess.in","r",stdin);
  freopen("chess.out","w",stdout);
  memset(e,-1,sizeof(e));
  memset(ls,-1,sizeof(ls));
  memset(f,1145141919810,sizeof(f));
  cin>>N>>M;
  for(int i=1; i<=M; i++) {
    LL a,b,col;
    cin>>a>>b>>col;
    e[a][b]=col;
  }
  f[1][1]=0;
  for(int i=1; i<=N; i++) {
    for(int j=1; j<=N; j++) {
      for(int k=0; k<=3; k++) {
        LL dx=i+nxt[k][0],dy=j+nxt[k][1];
        if(dx<1||dx>N||dy<1||dy>N)continue;
        if(e[i][j]==-1&&e[dx][dy]==-1)continue;
        if(e[i][j]==-1) {
          if(f[dx][dy]+2<f[i][j])
            f[i][j]=f[dx][dy]+2,ls[i][j]=e[dx][dy];
        } else if(e[dx][dy]==-1&&ls[dx][dy]!=-1) {
          if(e[i][j]==ls[dx][dy])f[i][j]=min(f[i][j],f[dx][dy]);
          else if(e[i][j]!=ls[dx][dy])f[i][j]=min(f[i][j],f[dx][dy]+1);
        } else {
          if(e[i][j]==e[dx][dy])f[i][j]=min(f[i][j],f[dx][dy]);
          else if(e[i][j]!=e[dx][dy])f[i][j]=min(f[i][j],f[dx][dy]+1);
        }
      }
    }
  }
  cout<<(f[N][N]<1145141919810?f[N][N]:-1);
  return 0;
}
