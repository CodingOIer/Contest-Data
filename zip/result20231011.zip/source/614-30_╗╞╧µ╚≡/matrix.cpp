#include<bits/stdc++.h>
using namespace std;
long long N,A,B;
long long dfs(long long Len,long long X,long long Y,long long Begin){
	if(Len==1)return Begin;
	if(X==1&&Y==1)return Begin;
	if(X==Len&&Y==Len)return Begin+Len*2-2;
	if(X==1)return Begin+Y-1;
	if(Y==1)return Begin+(Len*4-4)-1-(X-1)+1;
	if(X==Len)return Begin+(Len*4-4)-1-(X-1)+1-(Y-1);
	if(Y==Len)return Begin+Y-1+(X-1);
	return dfs(Len-2,X-1,Y-1,Begin+(Len*4-4));	
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>N>>A>>B;
	cout<<dfs(N,A,B,1);
	return 0;
}
