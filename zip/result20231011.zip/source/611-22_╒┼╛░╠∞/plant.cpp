#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	srand((unsigned long long)time(0));
	cout<<rand()<<" "<<rand();
	return 0;
 }

