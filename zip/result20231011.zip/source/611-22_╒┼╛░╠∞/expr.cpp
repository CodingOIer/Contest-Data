#include <bits/stdc++.h>
using namespace std;
long long len,ans=0,p=10000,num=0,a[200005],x=0,x2=0,j,i=1,d=0;
string s;
char u;
int f(int x)
{
	return x-x-x;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	len=s.size();
	for(long long i=0;i<=len;i++)
	{
		u=s[i];
		if(isdigit(s[i]))
		{
			x=(x*10+(s[i]-'0'))%p;
		}
		else if(u=='+')
		{
			num++;
			a[num]=x%p;
			x=0;
		}
		else if(u=='-')
		{
			num++;
			a[num]=x; 
			x=0;
			j=i+1;
			while(isdigit(s[j]))
			{
				x=(x*10+(s[j]-'0'))%p;
				j++;
			}
			if(s[j]=='*')
			{
				d=0;
				j++;
				while(isdigit(s[j]))
				{
					x2=(x2*10+s[j]-'0')%p;
					j++;
				}
				d=(x2*x)%p;
				x=0;
				x2=0;
				a[++num]=f(d);
				d=0;
				i++;
				continue;
			}
			else
			{
				a[++num]=f(x);
				x=0;
				i++;
				continue;
			}
		}
		if(u=='*')
		{
			j=i+1;
			num++;
			while(isdigit(s[j]))
			{
				x2=(x2*10+s[j]-'0')%p;
				j++;
			}
			a[num]=(x2*x)%p;
			x=0;
			x2=0;
			i=j;
		}
		if(u!='*'&&u!='+'&&u!='-'&&!isdigit(u))
		{
			num++;
			a[num]=x%p;
			x=0;
		}
	}
	for(long long i=1;i<=num;i++)
	{
		cout<<a[i]<<" ";
		ans=(ans+a[i])%p;
	}
	cout<<ans;
	return 0;
}
