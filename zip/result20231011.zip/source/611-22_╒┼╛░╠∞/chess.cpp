#include <bits/stdc++.h>
using namespace std;
int n,m,dp[105][105]={-1},s[105][105],x,y,k;
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m;
	dp[1][1]=0;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y>>k;
		s[x][y]=k;
	}
	cout<<-1;
	return 0;
}
