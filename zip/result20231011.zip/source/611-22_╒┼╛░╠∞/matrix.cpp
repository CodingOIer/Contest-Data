#include <bits/stdc++.h>
using namespace std;
int i,j,x,y,n,u[30005],q=1,w=0,a=1,b=1,val=1;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>i>>j;
	if(i==1)
	{
		cout<<j;
		return 0;
	}
	if(j==n)
	{
		cout<<n+i-1;
		return 0;
	}
	w=n-1;
	for(int i=1;i<=2*n;i++)
	{
		if(i==1)
		{
			u[i]=n-1;
		}
		else 
		{
			u[i]=n-i/2;
		}
	}
	while(1)
	{
		if(q%2==1)
		{
			if(q%4==1)
			{
				if(a==i&&b+u[q]>=j)
				{
					val+=j-b;
					b=j;
					break;		
				}
				b+=u[q];
				val+=u[q];
				q++;
				continue;
			}
			if(a==i&&b-u[q]<=j)
			{
				val+=b-j;
				b=j;
				break;		
			}
			b-=u[q];
			val+=u[q];
		}
		else if(q%2==0)
		{
			if(q%4==0)
			{
				if(b==j&&a-u[q]<=i)
				{
					val+=a-i;
					a=i;
					break;		
				}
				a-=u[q];
				val+=u[q];
				q++;
				continue;

			}
			if(b==j&&a+u[q]>=i)
			{
				val+=i-a;
				a=i;
				break;		
			}
			a+=u[q];
			val+=u[q];
		}
		q++;
	}
	cout<<val;
	return 0;
}
