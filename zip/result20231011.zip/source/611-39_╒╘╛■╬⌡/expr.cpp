#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll mod=10000;
ll a[100010],a_size=0,b,cnt;
string s;
bool f=0;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	for(ll i=0;i<=s.length();i++){
		if(s[i]>='0' && s[i]<='9')	b*=10,b=b+(s[i]-48)%mod;
		else if(f){
			a_size++;
			a[a_size]=-b;
			b=0;
			f=0;
		}
		else if(s[i]=='*')	a[a_size]=(a[a_size]*b)%mod,b=0;
		else{
			a_size++;
			a[a_size]=b%mod;
			b=0;
		}
		if(s[i]=='-')	f=1;
	}
	for(ll i=1;i<=a_size;i++){
		cnt+=a[i];
	}
	cout<<cnt;
	return 0;
}/*
1+1*3+4

8

1+1234567890*1

7891

1+1000000003*1

4

*/
