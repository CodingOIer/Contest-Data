#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e7+5,mod=1e9+7;
ll n,a,b,x,y,i=1,j=1,cnt=1;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>a>>b;
	x=n-1,y=x;
	while(1){
		if(a==i){
			cout<<cnt+abs(b-j);
//			cout<<i<<" "<<j;
			return 0;
		}
		j+=y,cnt+=y;
		if(b==j){
			cout<<cnt+abs(a-i);
//			cout<<i<<" "<<j<<" ";
			return 0;
		}
		i+=x,cnt+=x;
		if(a==i){
			cout<<cnt+(abs(b-j));
//			cout<<i<<" "<<j;
			return 0;
		}
		x--;
		j-=y,cnt+=y;
		if(b==j){
			cout<<cnt+(abs(a-i));
//			cout<<i<<" "<<j;
			return 0;
		}
		y--;
		i-=x,cnt+=x;
		if(a==i){
			cout<<cnt+(abs(b-j));
//			cout<<i<<" "<<j;
			return 0;
		}
		x--;
	}
	//����ϸ��д���ˣ��������ҵ����� 
	return 0;
}/*
4 2 3

14
*/
