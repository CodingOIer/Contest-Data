#include<bits/stdc++.h>
using namespace std;
long long n,m,k,ans,o,j;
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>k>>n>>m;
	for(o=1; o<=k; o++) {
		if(n>=o+1&&n<=k-o) {
			if(m>=o+1&&m<=k-o)
				j++;
			else
				break;
		} else
			break;
	}
	ans=k*k;
	k=k-j*2;
	ans=ans-k*k;
	n=n-j,m=m-j;
	if(n==1)
		cout<<ans+m;
	else if(m==k)
		cout<<ans+k+n-1;
	else if(n==k)
		cout<<ans+k+k-2+(k-m+1);
	else if(m==1)
		cout<<ans+k+k-1+k-1+(k-n);
	return 0;
}
