#include<bits/stdc++.h>
using namespace std;
long long jl,num,ans[10000000];
string n;
char last='+';
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>n;
	for(int i=0;i<=n.length();i++)
	{
		jl=jl%10000; 
		if(n[i]=='0')
			jl=jl*10+0; 
		else
		if(n[i]=='1')
			jl=jl*10+1; 
		else
		if(n[i]=='2')
			jl=jl*10+2; 
		else
		if(n[i]=='3')
			jl=jl*10+3; 
		else
		if(n[i]=='4')
			jl=jl*10+4; 
		else
		if(n[i]=='5')
			jl=jl*10+5; 
		else
		if(n[i]=='6')
			jl=jl*10+6; 
		else
		if(n[i]=='7')
			jl=jl*10+7; 
		else
		if(n[i]=='8')
			jl=jl*10+8; 
		else
		if(n[i]=='9')
			jl=jl*10+9; 
		else
		{
			if(last=='+')
			{
				num++;
				ans[num]=jl;
			}
			else
			if(last=='-')
			{
				num++;
				ans[num]=0-jl;
			}
			else
			if(last=='*')
				ans[num]=(ans[num]*jl)%10000;
			jl=0;
			if(n[i]=='+')
				last='+';
			else
			if(n[i]=='-')
				last='-';
			else
			if(n[i]=='*')
				last='*';
		}
	}
	jl=0;
	for(int i=1;i<=num;i++)
		jl=(jl+ans[i])%10000;	
	cout<<jl%10000;
	return 0;
} 
