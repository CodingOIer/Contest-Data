#include<bits/stdc++.h>
using namespace std;
/*long long n,m,t[1001][1001],ans=99999999;

int dfs(int x,int y,int f,int zhi)
{
	if(x==n&&y==n)	
	{	
		if(ans<zhi)	
			return ans;
		else
			return zhi;
	}
	if(t[x+1][y]==0&&f==0 || t[x][y+1]==0&&f==0) return 99999999;
	if(f==1)
	{
		if(t[x+1][y]!=0 && t[x][y]==t[x+1][y])	
			dfs(x+1,y,1,zhi);
		else
			dfs(x+1,y,1,zhi+1);
		
		if(t[x][y+1]!=0 && t[x][y]==t[x][y+1])	
			dfs(x,y+1,1,zhi);
		else
			dfs(x,y+1,1,zhi+1);
			
		if(t[x+1][y]==0&&f!=0 || t[x][y+1]==0&&f!=0)
		{
			dfs(x,y+1,0,zhi+2);
			dfs(x+1,y,0,zhi+2);
		}
	}
	else
	{
		if(t[x+1][y]!=0)	
			dfs(x+1,y,1,zhi);
		if(t[x][y+1]!=0)	
			dfs(x,y+1,1,zhi);
		if(t[x+1][y]==0&&t[x][y+1]==0)
			return 99999999;
	}	
}*/
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cout<<"-1";
	/*cin>>n>>m;
	
	int a,b,s;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b>>s;
		t[a][b]=s+1;//1/2(������ɫ) 
	}
	cout<<dfs(1,1,1,0);
	*/
	return 0;
}

