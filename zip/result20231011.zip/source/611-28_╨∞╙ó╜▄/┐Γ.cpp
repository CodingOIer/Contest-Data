#include<bits/stdc++.h>
using namespace std;
long long n,num[9]={0,1,10,100,1000,10000,100000,1000000,10000000};
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cout<<rand()%num[n];
		if(rand()%3==1)
			cout<<"+";
		else
		if(rand()%3==2)
			cout<<"*";
		else
			cout<<"-";
	} 
	cout<<rand();
	return 0;
} //-37937-569546384-20940
