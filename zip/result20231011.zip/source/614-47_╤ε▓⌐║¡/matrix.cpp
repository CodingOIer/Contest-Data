#include<bits/stdc++.h>
#define ll long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 2e6+5;
int n;
int x,y,cnt;
int qu[MAX],sum[MAX];
void where(int x,int y){
	int jqu = min(min(x,n-x+1),min(y,n-y+1));
	int stw = sum[jqu-1]+1,ban = qu[jqu]/4+1,add = 0;
	x -= jqu-1,y -= jqu-1;
	if(y == 1){
		if(x == 1) add = 0;
		else add = qu[jqu]-x+1;
	}
	else if(y == ban) add = ban+x-2;
	else{
		if(x == 1) add = y-1;
		else add = ban*3-2-y;
	}
	cout<<stw+add;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	for(int i = n-1; i>=1; i-=2)
		qu[++cnt] = i*4,sum[cnt] = sum[cnt-1]+qu[cnt];
	where(x,y);
	return 0;
} 
