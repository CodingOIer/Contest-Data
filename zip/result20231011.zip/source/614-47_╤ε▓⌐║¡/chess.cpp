#include<bits/stdc++.h>
#define ll long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e3+5;
int n,m,cs;
int a[MAX][MAX],bj[MAX][MAX],lg[MAX][MAX];
int yd[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
int dfs(int x,int y,int sum,int id){// id:Ϊ1ʱ����չ 
	if(x == m && y == m) return sum;
	if(bj[x][y]) return bj[x][y]+sum;
	int w = 1e9,add = 0;
	lg[x][y] = 1;
	for(int i = 0; i<4; i++){
		int newx = x+yd[i][0];
		int newy = y+yd[i][1];
		if(newx<1 || newy<1 || newx>m || newy>m || lg[newx][newy]) continue;
		if(a[newx][newy] == -1 && id){
			a[newx][newy] = a[x][y];
			w = min(w,dfs(newx,newy,sum+2,0));
			a[newx][newy] = -1;
		}
		if(a[newx][newy] != -1){
			if(a[newx][newy] != a[x][y])  w = min(w,dfs(newx,newy,sum+1,1));
			else w = min(w,dfs(newx,newy,sum,1));
		}
	}
	lg[x][y] = 0;
	if(w != 1e9)bj[x][y] = w-sum;
	return w;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	memset(a,-1,sizeof(a));
	for(int i = 1; i<=n; i++){
		int x,y,c;
		cin>>x>>y>>c;
		a[x][y] = c;
	}
	int ans = dfs(1,1,0,1);
	if(ans == 1e9) cout<<-1;
	else cout<<ans;
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

5 5
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0

*/
