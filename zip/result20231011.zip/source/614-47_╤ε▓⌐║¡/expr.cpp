#include<bits/stdc++.h>
#define int long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e5+5;
const int mod = 1e4;
char c;
int ans,a,b;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	while(1){
		c = getchar();
		if(c == '\n') break;
		cin>>b; b %= mod;
		if(c == '+') ans = (ans+a)%mod,a = b;
		if(c == '-') ans = (ans+a)%mod,a = -b;
		if(c == '*') a = (a*b)%mod;
	}
	cout<<(ans+a)%mod;
	return 0;
}

