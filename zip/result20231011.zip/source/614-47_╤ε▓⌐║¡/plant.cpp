#include<bits/stdc++.h>
#define ll long long
#define max(a,b) ((a)>(b)?a:b)
#define min(a,b) ((a)<(b)?a:b)
using namespace std;
const int MAX = 1e3+5;
int t,id;
int n,m,c,f;
int a[MAX][MAX];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id>>n>>m>>c>>f;
	for(int i = 1; i<=n; i++)
		for(int j = 1; j<=m; j++)
			cin>>a[i][j];
	cout<<"1 1";
	return 0;
}

