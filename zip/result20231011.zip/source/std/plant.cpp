#include <bits/stdc++.h>
using namespace std;
const int N=1005,mod=998244353;
long long vc,vf,c,f;
int n,m,id,T;
int s[N][N],shang,lc;
string str;
int main(){
	freopen ("plant.in" , "r" , stdin);
	freopen ("plant.out" , "w" , stdout);
	scanf("%d%d",&T,&id);
	while(T--){
		memset(s,0,sizeof(s));
			scanf("%d%d%d%d",&n,&m,&c,&f);
		for(int i=1;i<=n;i++){
		   cin>>str;str=' '+str;
		   for(int j=m-1;j>=1;j--)
			  if(str[j]=='1') s[i][j]=-1;
				else  if(str[j+1]=='0') s[i][j]=s[i][j+1]+1; 
		}
		for(int j=1;j<m;j++){
			shang=0;
			for(int i=1;i<=n;i++){
				if(s[i][j]==-1){shang=0;continue ;}
				vc=vc%mod+(1ll*s[i][j]*(shang%mod))%mod;
				shang+=max(0,s[i-1][j]);
			}
		}
		for(int j=1;j<m;j++){
			lc=shang=0;
			for(int i=1;i<=n;i++){
				if(s[i][j]==-1){lc=shang=0;continue ;}
				vf=(vf%mod+lc%mod)%mod;
				lc=lc%mod+(1ll*s[i][j]*(shang%mod))%mod;
				shang+=max(0,s[i-1][j]);
			}
		}
		cout<<(c*vc)%mod<<' '<<(f*vf)%mod<<'\n';
		vc=vf=0;
	}
	return 0;
}
