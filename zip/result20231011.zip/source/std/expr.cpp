#include <bits/stdc++.h>
using namespace std;
long long p , p1 , ans;
char ch;
stack <long long> sta;
int main () {

	freopen ("expr.in" , "r" , stdin);
	freopen ("expr.out" , "w" , stdout);
	cin >> p;
	sta . push(p);
	while (cin >> ch >> p) {
		p %= 10000;
		if (ch == '+') {
			      sta.push(p);
		}
		else if(ch=='-') {
			      sta.push(-p);	
		} else {
			long long tmp2 = sta . top();
			sta . pop();
			long long tmp = p * tmp2 % 10000;
			sta . push(tmp);
		}
	}
	while (sta . size()) {
		ans += sta . top();
		ans %= 10000;
		sta . pop();
	}
	cout << ans << endl;
	return 0;
}
