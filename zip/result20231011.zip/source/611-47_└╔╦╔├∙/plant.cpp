#include <bits/stdc++.h>
using namespace std;
int main () {
	ios :: sync_with_stdio (false);
	freopen ("plant.in" , "r" , stdin);
	freopen ("plant.out" , "w" , stdout);
	cout << "0" << endl;
	return 0;
}
