#include <bits/stdc++.h>
using namespace std;
int p , ans;
char f;
stack <int> sta;
int main () {
	ios :: sync_with_stdio (false);
	freopen ("expr.in" , "r" , stdin);
	freopen ("expr.out" , "w" , stdout);
	cin >> p;
	sta . push (p);
	while (cin >> f >> p) {
		p %= 10000;
		if (f == '*') {
			int tmp = sta . top ();
			sta . pop ();
			p = ( p * tmp )% 10000;
		}
		if (f == '-') sta . push (-p);
		else sta . push (p);
	}
	while (sta . size ()) {
		ans = ( ans + sta . top () ) % 10000;
		sta . pop ();
	}
	cout << ans << endl;
	return 0;
}
