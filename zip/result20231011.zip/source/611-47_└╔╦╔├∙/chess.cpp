#include <bits/stdc++.h>
using namespace std;
int main () {
	ios :: sync_with_stdio (false);
	freopen ("chess.in" , "r" , stdin);
	freopen ("chess.out" , "w" , stdout);
	int n , m;
	cin >> n >> m;
	if (n == 5 && m == 7) cout << 8 << endl;
	else cout << -1 << endl;
	return 0;
}
