#include <bits/stdc++.h>
using namespace std;
int n , i , j , a [110] [110];
int fx [5] = {0 , 0 , 1 , 0 , -1};
int fy [5] = {0 , 1 , 0 , -1 , 0};
bool yuejie (int a1 , int b) {
	if (a1 > n || b > n || a1 < 1 || b < 1 || a [a1] [b] != 0)
		return false;
	return true;
}
int main () {
	ios :: sync_with_stdio (false);
	freopen ("matrix.in" , "r" , stdin);
	freopen ("matrix.out" , "w" , stdout);
	cin >> n >> i >> j;
	int tcp = n * n , x = 1 , y = 1 , fw = 1;
	a [1] [1] = 1;
	for (int i = 2; i <= tcp; i ++) {
		int tx = x + fx [fw] , ty = y + fy [fw];
		while (!yuejie (tx , ty)) {
			fw ++;
			if (fw >= 5) fw = 1;
			tx = x + fx [fw] , ty = y + fy [fw];
		}
		if (fw >= 5) fw = 1;
		a [tx] [ty] = i;
		x = tx , y = ty;
	}
	cout << a [i] [j] << endl;
	return 0;
}
