#include <bits/stdc++.h>
using namespace std;
long long n,x,y,a[3000][3000],k=1,h=1,l1=1,p=1;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	long long h1=n,l=n;
	for(long long m=n;m>=1;m--){
		for(long long i=p;i<=m;i++){
			a[h][i]=k;
			k++;
		}h++;
		p++;
		for(long long j=p;j<=m;j++){
			a[j][l]=k;k++;
		}l--;
		m--;
		for(long long u=m;u>=p;u--){
			a[h1][u]=k;
			k++;
		}h1--;
		m++;
		for(long long b=m;b>=p;b--){
			a[b][l1]=k;
			k++;
		}l1++;
	} 
	cout<<a[x][y];
//	for(int i=1;i<=n;i++){
//		for(long long b=1;b<=n;b++){
//			cout<<a[i][b]<<" ";
//		}
//		cout<<endl;
//	}
	return 0;
}  
