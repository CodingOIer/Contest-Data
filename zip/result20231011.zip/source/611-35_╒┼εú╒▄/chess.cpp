#include<bits/stdc++.h>
using namespace std;
bool xdl=1;
long long n,poi,m,a,b,c,q[1005][1005],ans,anss=99999999; 
void dfs(long long x,long long y,long long z){
	if(x==n&&y==n){
		cout<<ans;
		return;
	}
	if(x>n||x<=0||y>n||y<=0){
		return;
	}
	else{
		if(q[x][y]==poi)z=z;
		if(q[x][y]!=poi&&q[x][y]!=0)z=z+1;
		if(q[x][y]!=poi&&q[x][y]==0){
			if(xdl!=0)z=z+2;
			if(xdl==0)cout<<"-1";
		}
		ans=min(z,anss);
		anss=z;
		dfs(x+1,y,ans);
		dfs(x-1,y,ans);
		dfs(x,y+1,ans);
		dfs(x,y-1,ans);
	}
	poi=q[x][y];
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(long long i=1;i<=m;i++){
		cin>>a>>b>>c;
		q[a][b]=c;
	}
//	dfs(1,1,0);
	cout<<"-1";
	return 0;
}  
