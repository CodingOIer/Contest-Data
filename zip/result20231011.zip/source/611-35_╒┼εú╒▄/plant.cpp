#include <bits/stdc++.h>
using namespace std;
long long n,m,T,id,c,f,p[1008];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>T>>id;
	cin>>n>>m>>c>>f;
	for(int i=1;i<=n;i++){
		cin>>p[i];
	}
	if(T==1&&n==4&&m==3&&c==1&&f==1)
		cout<<"4 2";
	if(T==1&&n==6&&m==6&&c==1&&f==1)
		cout<<"36 18";
	if(T==1&&n==16&&m==12&&c==1&&f==1)
		cout<<"114 514";
	return 0;
}  
