#include<bits/stdc++.h>
#pragma GCC optimize(2)
#define int long long
using namespace std;
inline int init_(){
	srand(time(0));
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	return 0;
}
const int maxn=1e6+10,mod=1e9+7,init=init_();
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-'; 
	do (n*=10)+=c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int ans;

signed main(){
	for(int i=1,num=0,cnt=1,x=0,c;c!='\n';++i) if((c=getchar())<'0'||c>'9') if(c=='*') (cnt*=num)%=10000,num=0;
	else (cnt*=num)%=10000,(ans+=(x?-cnt:cnt))%=10000,cnt=1,num=0,x=c=='-';
	else ((num*=10)+=c-'0')%=10000;
	write(ans);
	return 0;
}
