#include<bits/stdc++.h>
#pragma GCC optimize(2)
#define int long long
using namespace std;
inline int init_(){
	srand(time(0));
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	return 0;
}
const int maxn=1e6+10,mod=1e9+7,init=init_();
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-'; 
	do (n*=10)+=c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int n=read(),m=read(),a[maxn],far[maxn],t[10]={-1,1,-n,n};
map<int,int> edge[maxn];
int djskl(){
	priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> t;
	for(auto it:edge[1]) t.push({it.second,it.first});
	n*=n;
	for(int i=2;i<=n;++i) far[i]=INT_MAX;
	while(t.size()){
		auto now=t.top();t.pop();
		int u=now.second,tmp=now.first;
		if(tmp>far[u]||!far[u]) continue;
		far[u]=now.first;
		for(auto it:edge[u]) t.push({tmp+it.second,it.first});
	}
	if(far[n]==INT_MAX) return -1;
	return far[n];
}

signed main(){
	for(int i=1;i<=m;++i){
		int x=read(),y=read();
		a[(x-1)*n+y]=read()+1;
	}
	for(int i=1;i<=n*n;++i) if(i%n!=1&&i%n)
		if(a[i]) for(int j=0;j<4;++j) if(a[i+t[j]]&&i+t[j]>0&&i+t[j]<=n*n)
			edge[i][i+t[j]]=edge[i+t[j]][i]=(a[i+t[j]]!=a[i]);
			else;
		else for(int x=0;x<4;++x) for(int y=x+1;y<4;++y)
			if(a[i+t[x]]&&a[i+t[y]]&&i+t[x]>0&&i+t[x]<=n*n&&i+t[y]>0&&i+t[y]<=n*n)
				edge[i+t[x]][i+t[y]]=edge[i+t[y]][i+t[x]]=2+(a[i+t[x]]!=a[i+t[y]]);
	write(djskl());
	return 0;
}
