#include<bits/stdc++.h>
#pragma GCC optimize(2)
#define int long long
using namespace std;
inline int init_(){
	srand(time(0));
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	return 0;
}
const int maxn=1e6+10,mod=1e9+7,init=init_();
inline int read(){
	int n=0,x=0,c;
	while((c=getchar())<'0'||c>'9') x=c=='-'; 
	do (n*=10)+=c-'0';while((c=getchar())>='0'&&c<='9');
	return x?-n:n;
}
inline int write(int n){
	if(n<0) putchar('-'),n=-n;
	if(n>9) write(n/10);
	putchar('0'+n%10);
	return n;
}

int n=read(),a=read(),b=read(),k=min(min(a,b),min(n-a+1,n-b+1))-1,ans=2*(2*n-k*2)*k;

signed main(){
	n-=k*2,a-=k,b-=k;
	if(a==1) ans+=b;
	else{
		ans+=n;
		if(b==n) ans+=a-1;
		else{
			ans+=n-1;
			if(a==n) ans+=n-b;
			else ans+=n-1,ans+=n-a;
		}
	}
	write(ans);
	return 0;
}
