#include<bits/stdc++.h>
using namespace std;
int js(int n,int i,int j){
	if(i==1)
		return j;
	if(i==n)
		return 3*n-1-j;
	if(j==1)
		return 4*n-2-i;
	if(j==n)
		return n-1+i;
	return js(n-2,i-1,j-1)+4*n-4;
}
int main(){
	int n,i,j;
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d%d",&n,&i,&j);
	printf("%d",js(n,i,j));
	return 0;
}
