#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int ret=0,f=0; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=1; ch=getchar();}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,l,r;
	n=read(),l=read(),r=read();
	int xlu=1,ylu=1,xld=n,yld=1,xru=1,yru=n,xrd=n,yrd=n;
	int lu=1,ru=n,ld=3*n-2;
	while(1){
		if(l==xlu){
			cout<<lu+r-ylu;
			return 0;
		}
		if(l==xld){
			cout<<ld-r+yld;
			return 0;
		}
		if(r==ylu){
			cout<<ld-l+xld;
			return 0;
		}
		if(r==yru){
			cout<<ru+l-xru;
			return 0;
		}
		lu+=4*(yru-ylu);
		xlu++,ylu++,xld--,yld++,xru++,yru--,xrd--,yrd--;
		ru=lu+yru-ylu,ld=lu-1+3*(yru-ylu+1)-2;
	}
	return 0;
}

