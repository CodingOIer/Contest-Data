#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int ret=0,f=0; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=1; ch=getchar();}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
stack<long long>t;
bool jl[500001];
int number[500001];
int top=0;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	int len=s.size();
	long long num=0;
	bool f=0;
	for(int i=0;i<=len;i++){
		if(i==len){
			t.push(num);
			if(f==1){
				long long a=t.top();
				t.pop();
				long long b=t.top();
				t.pop();
				t.push((a*b)%10000);
			}
			f=0;
		}
		if(s[i]=='+'){
			t.push(num);
			num=0;
			if(f==1){
				long long a=t.top();
				t.pop();
				long long b=t.top();
				t.pop();
				t.push((a*b)%10000);
				f=0;
			}
			jl[top]=0,top++;
		}
		else if(s[i]=='-'){
			t.push(num);
			num=0;
			if(f==1){
				long long a=t.top();
				t.pop();
				long long b=t.top();
				t.pop();
				t.push((a*b)%10000);
				f=0;
			}
			jl[top]=1,top++;
		}
		else if(s[i]=='*'){
			t.push(num);
			num=0;
			if(f==1){
				long long a=t.top();
				t.pop();
				long long b=t.top();
				t.pop();
				t.push((a*b)%10000);
			}
			f=1;
		}
		else{
			num=(num*10+(s[i]-'0'))%10000;
		}
	} 
	for(int i=top;i>=0;i--){
		long long a=t.top();
		t.pop();
		number[i]=a;
	}
	for(int i=0;i<top;i++){
		long long a=number[i];
		long long b=number[i+1];
		if(jl[i]==0){
			number[i+1]=(a+b)%10000;
		}
		else{
			number[i+1]=a-b;
		}
	}
	cout<<number[top]%10000;
	return 0;
}

