#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
inline int read(){
	int ret=0,f=0; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=1; ch=getchar();}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}
struct kkk{
	int r[1001],d[1001];
}num[1001];
bool pl[1001][1001];
long long ansc,ansf;
int n,m,c,f;
void dfsc(int i,int x,int y){
	for(int k=x;k<=n;k++){
		if(pl[k][y]==1){
			return ;
		}
		ansc+=num[i].r[y]*num[k].r[y];
		ansc%=mod;
	}
}
void dfsf(int i,int x,int y){
	for(int k=x;k<=n;k++){
		if(pl[k][y]==1){
			return ;
		}
		ansf+=num[i].r[y]*num[k].r[y]*num[k].d[y];
		ansf%=mod;
	}
}
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	t=read(),id=read();
	while(t--){
		n=read(),m=read(),c=read(),f=read();
		ansc=0,ansf=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				char c;
				cin>>c;
				if(c-'0'==0){
					pl[i][j]=false;
				}
				else{
					pl[i][j]=true;
				}
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=m;j>=1;j--){
				if(pl[i][j]==0){
					num[i].r[j]=num[i].r[j+1]+1;
				}
				else{
					num[i].r[j]=0;
				}
			}
		}
		for(int i=1;i<=m;i++){
			for(int j=n;j>=1;j--){
				if(pl[j][i]==0){
					num[j].d[i]=num[j+1].d[i]+1;
				}
				else{
					num[j].d[i]=0;
				}
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				num[i].r[j]--;
				num[i].r[j]=max(0,num[i].r[j]);
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				num[i].d[j]--;
				num[i].d[j]=max(0,num[i].d[j]);
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(pl[i+1][j]==0){
					dfsc(i,i+2,j);
				}
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(pl[i+1][j]==0){
					dfsf(i,i+2,j);
				}
			}
		}
		cout<<c*ansc%mod<<" "<<f*ansf%mod<<endl;
	}
	return 0;
}

