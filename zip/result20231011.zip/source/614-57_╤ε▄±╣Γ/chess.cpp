#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int ret=0,f=0; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=1; ch=getchar();}
	while(isdigit(ch)) ret=(ret<<1)+(ret<<3)+(ch^48),ch=getchar();
	return f?-ret:ret;
}

int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int x,y,j;
		cin>>x>>y>>j;
	}
	cout<<-1;
	return 0;
}

