#include<bits/stdc++.h>
using namespace std;
int n,m;
int X[4]={0,1,0,-1};
int Y[4]={1,0,-1,0};
int col[105][105];
int vis[105][105];
int dfs(int x,int y,int k)
{
	if(x<1 || y<1 || x>n || y>n) return INT_MAX;
	if(k>=vis[x][y]) return INT_MAX;
	if(x==n && y==n) return k;
	vis[x][y]=k;
	int res=INT_MAX;
	for(int i=0;i<4;i++)
	{
		if(col[x+X[i]][y+Y[i]]==0)
		{
			col[x+X[i]][y+Y[i]]=col[x][y];
			res=min(res,dfs(x+X[i],y+Y[i],k+2));
			col[x+X[i]][y+Y[i]]=0;
		}
		else
		{
			if(col[x+X[i]][y+Y[i]]!=col[x][y])	res=min(res,dfs(x+X[i],y+Y[i],k+1));
			else res=min(res,dfs(x+X[i],y+Y[i],k));
		}
	}
	return res;
}
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		col[x][y]=z+1;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			vis[i][j]=INT_MAX;
	int ans=dfs(1,1,0);
	if(ans==INT_MAX) cout<<-1;
	else cout<<ans;
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

*/
