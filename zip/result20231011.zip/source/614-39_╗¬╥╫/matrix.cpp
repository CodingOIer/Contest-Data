#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,ans;
int x,y;
signed main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	for(int i=0;;i++)
	{
		if(i+1==x)
		{
			for(int j=i+1;j<=y;j++) ans++;
			cout<<ans;
			return 0;
		}
		if(i+1==y)
		{
			ans+=3*(n-i*2-1);
			for(int j=n-i;j>=x;j--) ans++;
			cout<<ans;
			return 0;
		}
		if(n-i==x)
		{
			ans+=2*(n-i*2-1);
			for(int j=n-i;j>=y;j--) ans++;
			cout<<ans;
			return 0;
		}
		if(n-i==y)
		{
			ans+=(n-i*2-1);
			for(int j=i+1;j<=x;j++) ans++;
			cout<<ans;
			return 0;
		}
		ans+=4*(n-i*2-1);
	}
	return 0;
}
