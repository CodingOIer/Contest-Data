#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int t,id;
int n,m,C,F,ansc,ansf;
int a[1005][1005];
bool b[1005][1005];
int c[1005][1005];
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--)
	{
		ansc=ansf=0;
		scanf("%d%d%d%d",&n,&m,&C,&F);
		for(int i=1;i<=n;i++)
		{
			string s;
			cin>>s;
			for(int j=0;j<m;j++)
				b[i][j+1]=bool(s[j]-'0');
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=m;j>=1;j--)
			{
				if(b[i][j]) a[i][j]=0;
				else a[i][j]=a[i][j+1]+1;
			}
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				if(!b[i][j]) a[i][j]--;
		for(int i=1;i<=m;i++)
		{
			int k=0,lst=0,cc=ansc;
			for(int j=1;j<=n;j++)
			{
				if(b[j][i]) k=0;
				else
				{
					ansc+=k*a[j][i];
					ansc%=mod;
					k+=lst;
					lst=a[j][i];
					k%=mod;
					c[j][i]=ansc-cc;
				}
			}
		}
		for(int i=1;i<=m;i++)
		{
			int k=0;
			for(int j=1;j<=n;j++)
			{
				if(b[j][i]) k=0;
				else
				{
					ansf+=k;
					k+=c[j][i];
				}
			}
		}
		cout<<(ansc*C)%mod<<' '<<(ansf*F)%mod<<'\n';
	}
	return 0;
}
