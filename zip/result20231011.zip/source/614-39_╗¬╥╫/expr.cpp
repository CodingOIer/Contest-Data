#include<bits/stdc++.h>
#define int long long
#define mod 10000
using namespace std;
int a,b,ans;
char c;
signed main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%d",&a);
	a%=mod;
	while(scanf("%c%d",&c,&b)==2)
	{
		b%=mod;
		if(c=='*') a*=b;
		else if(c=='-') ans+=a,a=-b;
		else ans+=a,a=b;
		a%=mod,ans%=mod;
	}
	cout<<(ans+a)%mod;
	return 0;
}
