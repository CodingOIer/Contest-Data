#include<bits/stdc++.h>
using namespace std;
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T,id,n,m;
	cin>>T>>id>>n>>m;
	if(n==4&&m==3) cout<<"4 2";
	if(n==6&&m==6) cout<<"36 18";
	if(n==16&&m==12) cout<<"114 514";
	else cout<<"Hello World!";
	return 0;
}
