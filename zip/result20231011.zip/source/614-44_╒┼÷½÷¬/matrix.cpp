#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	long long n,x=1,y=1,s=0,I,J,fx=0;
	cin>>n>>I>>J;
	if(I==1){
		cout<<J;
		return 0;
	}
	int top=n-1;
	for(int i=1;i<=2*n-1;i++){
		if(i>3&&i%2==0) top--;
		s+=top;
		if(fx==0) y+=top;
		if(fx==1) x+=top;
		if(fx==2) y-=top;
		if(fx==3) x-=top;
		if(x==I){
			cout<<s+abs(y-J)+1;
			return 0;
		}
		if(y==J){
			cout<<s+abs(x-I)+1;
			return 0;
		}
		fx=(fx+1)%4;
	}
	return 0;
}
