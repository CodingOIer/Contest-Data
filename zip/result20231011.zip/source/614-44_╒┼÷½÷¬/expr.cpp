#include<bits/stdc++.h>
using namespace std;
const int mod=10000;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	long long n,m,ans=0;
	char c;
	cin>>m;
	while(1){
		c=getchar();
		if(c=='\n') break;
		cin>>n;
		if(c=='*') m=(m*n)%mod;
		else{
			ans=(ans+m)%mod;
			if(c=='+')m=n;
			else m=-n;
		}
	}
	ans=(ans+m)%mod;
	if(ans<0) cout<<ans%(mod/10);
	else cout<<ans;
	return 0;
}
