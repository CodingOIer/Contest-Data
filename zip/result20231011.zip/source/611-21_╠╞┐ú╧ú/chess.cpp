#include<bits/stdc++.h>
using namespace std;
const int N=102,$=11451419;
int m,n,dp[N][N],s[N][N];
bool use[N][N];
int min_(int a,int b,int c,int d){
	return min(min(a,b),min(c,d));
}
signed main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	/*
	����ը�ˣ�++
	for(int i=0;i<=101;i++)
		for(int j=0;j<=101;j++)
			dp[i][j]=s[i][j]=$;
	dp[1][1]=0;
	cin>>m>>n;
	for(int i=0;i<n;i++){
		int x,y,k;
		cin>>x>>y>>k;
		s[x][y]=k;
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<=m;j++){
			if(i==1&&j==1) continue;
			int a=$,b=$,c=$,d=$;
			if(s[i][j]==$){
				if(!use[i-1][j]) a=dp[i-1][j]+1-(s[i-1][j]==s[i][j]);
				if(!use[i][j-1]) b=dp[i][j-1]+1-(s[i][j-1]==s[i][j]);
				dp[i][j]=min_(a,b,c,d)+1;
				use[i][j]=1;
			}
			else{
				a=dp[i-1][j]+1-(s[i-1][j]==s[i][j]||s[i-1][j-1]==s[i][j]);
				b=dp[i][j-1]+1-(s[i][j-1]==s[i][j]||s[i-1][j-1]==s[i][j]);
				dp[i][j]=min_(a,b,c,d);
			}
			cout<<dp[i][j]<<' ';
		}
		cout<<endl;
	}
	*/
	cout<<-1;
	return 0;
}
