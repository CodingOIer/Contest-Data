#include<bits/stdc++.h>
using namespace std;
const int mod=10000;
vector<string> a;
string s,str;
bool b;
int ans;
string STR(int x){
	return to_string(x);
}
int INT(string x){
	return atoi(x.c_str())%mod;
}
void check(){
	if(b){
		a.push_back(str);
		b=0;
		int num=INT(a[a.size()-1]);
		num=num*INT(a[a.size()-3])%mod;
		a.erase(a.end()-1);
		a.erase(a.end()-1);
		a.erase(a.end()-1);
		str=STR(num);
	}
}
signed main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int len=s.length();
	for(int i=0;i<len;i++){
		if(s[i]=='+'||s[i]=='-'){
			check();
			a.push_back(str);
			str="";
			if(s[i]=='-') a.push_back("-");
			if(s[i]=='+') a.push_back("+");
		}
		else if(s[i]=='*'){
			check();
			b=1;
			a.push_back(str);
			str="";
			a.push_back("*");
		}
		else str+=s[i];
	}
	check();
	a.push_back(str);
	ans=INT(a[0]);
	for(int i=2;i<a.size();i++){
		if(a[i]!="+"&&a[i]!="-"){
			if(a[i-1]=="+") ans=(ans+INT(a[i]))%mod;
			if(a[i-1]=="-") ans=(ans-INT(a[i]))%mod;
		}
	}
	cout<<ans%mod;
	return 0;
}
