#include<bits/stdc++.h>
using namespace std;
long long n,i,j,x=1,y,zt=1,sz,bs;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>i>>j;
	bs=n;
	while(1){
		if(x==i){
			cout<<sz+abs(j-y);
			return 0;
		}
		if(y==j){
			cout<<sz+abs(i-x);
			return 0;
		}
		if(zt==1) y+=bs,zt=2,sz+=bs;
		else if(zt==2) x=x+bs-1,zt=3,sz=sz+bs-1,bs--;
		else if(zt==3) y-=bs,zt=4,sz+=bs;
		else x=x-bs+1,zt=1,sz=sz+bs-1,bs--;
	}
	return 0;
}
