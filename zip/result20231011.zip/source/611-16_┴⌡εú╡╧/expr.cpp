#include<bits/stdc++.h>
using namespace std;
string s,s1[100010];
int cnt=1,ans;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	s1[1].push_back('+');
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]=='+'||s[i]=='-') cnt++;
		s1[cnt].push_back(s[i]);
	}
	for(int j=1;j<=cnt;j++){
		int sum=1,num=0;
		for(int i=1;i<s1[j].size();i++){
			if(s1[j][i]!='*') num=(num*10+s1[j][i]-'0')%10000;
			if(s1[j][i]=='*'||i==s1[j].size()-1){
				sum=sum*num%10000;
				num=0;
			}
		}
		if(s1[j][0]=='+') ans=(ans+sum)%10000;
		else ans=(ans-sum)%10000;
	}
	cout<<ans;
	return 0;
}
