#include<bits/stdc++.h>
using namespace std;
int m,n,a[110][110],bj[110][110],ans=2000000000;
int check(int x,int y,int x2,int y2){
	if(a[x][y]==a[x2][y2]&&a[x][y]!=-1) return 0;
	if(a[x][y]!=-1&&a[x2][y2]!=-1) return 1;
	return 2;
}
void dfs(int x,int y,int zt,int sum,int bj[110][110]){
	if(a[x][y]==-1) zt--;
	else zt=2;
	if(!zt||bj[x][y]!=-1&&sum>=bj[x][y]) return;
	bj[x][y]=sum;
	if(x==m&&y==m){
		ans=min(ans,sum);
		return;
	}
	if(x<m) dfs(x+1,y,zt,sum+check(x,y,x+1,y),bj);
	if(x>1) dfs(x-1,y,zt,sum+check(x,y,x-1,y),bj);
	if(y<m) dfs(x,y+1,zt,sum+check(x,y,x,y+1),bj);
	if(y>1) dfs(x,y-1,zt,sum+check(x,y,x,y-1),bj);
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d",&m,&n);
	memset(a,-1,sizeof(a));
	memset(bj,-1,sizeof(bj));
	for(int i=1;i<=n;i++){
		int x,y,c;
		scanf("%d%d%d",&x,&y,&c);
		a[x][y]=c;
	}
	dfs(1,1,2,0,bj);
	if(ans==2000000000) cout<<-1;
	else cout<<ans;
	return 0;
}
