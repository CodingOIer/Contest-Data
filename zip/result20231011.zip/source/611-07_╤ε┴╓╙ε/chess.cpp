#include<bits/stdc++.h>
using namespace std;
void in(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
}
int n,m,minn=10000000;
int a[105][105];
bool book[105][105];
int d[5][5]={{0,1},{0,-1},{1,0},{-1,0}};
void dfs(int x,int y,int sum,bool f){
	if(x==n&&y==n){
		if(sum<minn)minn=sum;
		return; 
	}
	if(sum>=minn)return;
	for(int i=0;i<=3;i++){
		int u=x+d[i][0],v=y+d[i][1];
		if(u<=0||u>n||v<=0||v>n||book[u][v]==1)continue;
		if(a[u][v]==-1){
			if(f==1)continue;
			a[u][v]=a[x][y];
			book[u][v]=1;
			//cout<<u<<" "<<v<<" b"<<endl;
			dfs(u,v,sum+2,1);
			book[u][v]=0;
			a[u][v]=-1;
		}else{
			book[u][v]=1;
			//cout<<u<<" "<<v<<" l"<<endl;
			dfs(u,v,sum+(a[x][y]!=a[u][v]),0);
			book[u][v]=0;
		}
		
	}
}
int main(){
	in();
	cin>>n>>m;
	memset(a,-1,sizeof(a));
	for(int i=1;i<=m;i++){
		int x,y;
		int c;
		cin>>x>>y>>c;
		a[x][y]=c;
	}
	book[1][1]=1;
	dfs(1,1,0,0);
	if(minn==10000000)cout<<-1<<endl;
	else cout<<minn<<endl;
}

