#include<bits/stdc++.h>
using namespace std;
void in(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
}
int n,x,y;
int i=1,j=1,f=0;
int u,d,l,r;
int ans=0;
int main(){
	in();
	cin>>n>>x>>y;
	u=1;
	d=n;
	l=1;
	r=n;
	ans++;
	while(i!=x&&j!=y){
		if(f==0)ans+=r-j,j=r,u++;
		if(f==1)ans+=d-i,i=d,r--;
		if(f==2)ans+=j-l,j=l,d--;
		if(f==3)ans+=i-u,i=u,l++;
		f=(f+1)%4;
		//cout<<f<<" "<<i<<" "<<j<<" "<<ans<<endl;
	}
	if(i==x)ans+=abs(j-y);
	if(j==y)ans+=abs(i-x);
	cout<<ans<<endl;
}
/*
1  2  3  4  5
16 17 18 19 6
15 24 25 20 7
14 23 22 21 8
13 12 11 10 9
*/

