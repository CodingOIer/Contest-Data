#include<bits/stdc++.h>
using namespace std;
void in(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
}
int f=0;
int sum;
int a[100006];

int cnt;
string str;
int main(){
	in();
	cin>>str;
	for(int i=0;i<str.size();i++){
		if('0'<=str[i]&&str[i]<='9')sum=(sum*10+str[i]-'0')%10000;
		else{
			if(f==1)a[cnt]=(a[cnt]*sum)%10000;
			else if(f==0)a[++cnt]=sum;
			else a[++cnt]=-sum;
			sum=0;
			if(str[i]=='*')f=1;
			else if(str[i]=='+')f=0; 
			else f=2;
		}
	}
	if(f==1)a[cnt]=(a[cnt]*sum)%10000;
	else if(f==0)a[++cnt]=sum;
	else a[++cnt]=-sum;
	int ans=0;
	for(int i=1;i<=cnt;i++)ans=(ans+a[i])%10000;
	cout<<ans;
} 
