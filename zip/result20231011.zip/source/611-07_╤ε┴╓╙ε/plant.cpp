#include<bits/stdc++.h>
using namespace std;
void in(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
}
const int mod=998244353;
int n,m,t,id;
bool a[1005][1005]={};
int r[1005][1005]={},d[1005][1005]={};
int main(){
	in();
	cin>>t>>id;
	while(t--){
		memset(r,0,sizeof(r));
		memset(d,0,sizeof(d));
		int n,m,c,f;
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++){
			string str;
			cin>>str;
			for(int j=0;j<m;j++)a[i][j+1]=str[j]-'0';
		}
		for(int i=1;i<=m;i++){
			for(int j=n;j>=1;j--){
				if(a[j][i]==0)d[j][i]=d[j+1][i]+1;
				else d[j][i]=0;
			} 
		}
		for(int i=1;i<=n;i++){
			for(int j=m;j>=1;j--){
				if(a[i][j]==0)r[i][j]=r[i][j+1]+1;
				else r[i][j]=0;
			} 
		}
		
		long long ansc=0,ansf=0;
		for(int j=1;j<m;j++){
			long long sum=r[1][j+1];
			for(int i=3;i<=n;i++){
				while(a[i][j]==1||a[i-1][j]==1){
					i++;
					sum=r[i-2][j+1];
				}
				ansc=(ansc+sum*r[i][j+1]%mod)%mod;
				//cout<<sum<<" ";
				ansf=(ansf+sum*r[i][j+1]%mod*d[i+1][j]%mod)%mod;
				sum=(sum+r[i-1][j+1])%mod;
				
				//cout<<ansc<<" ";
				
			}
			//cout<<endl;
		}
		cout<<(ansc*c)%mod<<" "<<(ansf*f)%mod<<endl;
		
	}
}

