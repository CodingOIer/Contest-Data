#include <iostream>
#define int long long
using namespace std;
constexpr int N = 1e3 + 5;
constexpr int mod = 998244353;
int T, id, n, m, c, f;
int a[N][N], nxt[N][N];
int line[N][N];
signed main() {
	freopen("plant.in", "r", stdin);
	freopen("plant.out", "w", stdout);
	scanf("%d%d", &T, &id);
	while (T--) {
		scanf("%d%d%d%d", &n, &m, &c, &f);
		char ch = getchar();
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m + 1; ++j) {
				ch = getchar();
				a[i][j] = ch - '0';
			}
//		for (int i = 1; i <= n; ++i)
//			for (int j = 1; j <= m; ++j) {
//				int k;
//				for (k = j; a[i][k] == 0 && k <= m; ++k)
//				nxt[i][j] = k - 1;
//				cout << i << ' ' << j << ' ' << nxt[i][j] << endl;
//			}
//		for (int i = 1; i <= n; ++i)
//			for (int j = 1; j <= m; ++j) {
//				int k;
//				for (k = i; a[k][j] == 0 && k <= n; ++k)
//				line[i][j] = k - 1;
//			}
		int vc = 0, vf = 0;
		if (c)
			for (int x1 = 1; x1 <= n; ++x1)
				for (int x2 = x1 + 2; x2 <= n; ++x2)
					for (int y0 = 1; y0 <= m; ++y0) {
//						if (nxt[x1][y0] <= y0 || nxt[x2][y0] <= y0)	continue;
//						vc += (nxt[x1][y0] - y0) * (nxt[x2][y0] - y0) % mod;
//						vc %= mod;
						if (a[x1][y0] || a[x2][y0])	continue;
						for (int y1 = y0 + 1; !a[x1][y1] && y1 <= m; ++y1)
							for (int y2 = y0 + 1; !a[x2][y2] && y2 <= m; ++y2)
								++vc;
					}
		if (f)
			for (int x1 = 1; x1 <= n; ++x1)
				for (int x2 = x1 + 2; x2 <= n; ++x2)
					for (int x3 = x2 + 1; x3 <= n; ++x3)
						for (int y0 = 1; y0 <= m; ++y0) {
//							if (nxt[x1][y0] <= y0 || nxt[x2][y0] <= y0)	continue;
//							vc += (nxt[x1][y0] - y0) * (nxt[x2][y0] - y0) % mod;
//							vc %= mod;
							if (a[x1][y0] || a[x2][y0])	continue;
							for (int y1 = y0 + 1; !a[x1][y1] && y1 <= m; ++y1)
								for (int y2 = y0 + 1; !a[x2][y2] && y2 <= m; ++y2)
									++vf;
						}
		printf("%d %d\n", vc * c % mod, vf * f % mod);
	}
	return 0;
}

