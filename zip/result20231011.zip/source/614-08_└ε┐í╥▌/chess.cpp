#include <bits/stdc++.h>
using namespace std;
constexpr int N = 1e2 + 5;
int ans, a[N][N];
int n, vis[N][N];
void dfs(int x, int y, int can, int sum) {
	if (x < 1 || y < 1 || x > n || y > n || vis[x][y])
		return;
	vis[x][y] = 1;
	if (x == n && y == n) {
		ans = min(ans, sum);
		return;
	}
	if (a[x][y + 1] == a[x][y])
		dfs(x, y + 1, 1, sum);
	else if (a[x][y + 1] > 0)
		dfs(x, y + 1, 1, sum + 1);
	else if (can) {
		a[x][y + 1] = a[x][y];
		dfs(x, y + 1, 0, sum + 2);
		a[x][y + 1] = 0;
	}
	if (a[x][y - 1] == a[x][y])
		dfs(x, y - 1, 1, sum);
	else if (a[x][y - 1] > 0)
		dfs(x, y - 1, 1, sum + 1);
	else if (can) {
		a[x][y - 1] = a[x][y];
		dfs(x, y - 1, 0, sum + 2);
		a[x][y - 1] = 0;
	}
	if (a[x + 1][y] == a[x][y])
		dfs(x + 1, y, 1, sum);
	else if (a[x + 1][y] > 0)
		dfs(x + 1, y, 1, sum + 1);
	else if (can) {
		a[x + 1][y] = a[x][y];
		dfs(x + 1, y, 0, sum + 2);
		a[x + 1][y] = 0;
	}
	if (a[x - 1][y] == a[x][y])
		dfs(x - 1, y, 1, sum);
	else if (a[x - 1][y] > 0)
		dfs(x - 1, y, 1, sum + 1);
	else if (can) {
		a[x - 1][y] = a[x][y];
		dfs(x - 1, y, 0, sum + 2);
		a[x - 1][y] = 0;
	}
	vis[x][y] = 0;
}
signed main() {
	freopen("chess.in", "r", stdin);
	freopen("chess.out", "w", stdout);
	int m;
	scanf("%d%d", &n, &m);
	while (m--) {
		int x, y, col;
		scanf("%d%d%d", &x, &y, &col);
		a[x][y] = col + 1;
	}
	ans = 1e9;
	dfs(1, 1, 1, 0);
	if (ans == 1e9)	ans = -1;
	printf("%d", ans);
	return 0;
}

