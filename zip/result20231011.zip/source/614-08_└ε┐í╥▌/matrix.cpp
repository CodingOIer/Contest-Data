#include <bits/stdc++.h>
using namespace std;
constexpr int L = 1e2 + 5;
int n, dex, cnt[L][L];
void pts(int x, int y, int dir) {
//	cout << x << ' ' << y << ' ' << dir << '\n';
	if (dir == 1) {
		if (cnt[x][y + 1])	return;
		int i;
		for (i = y + 1; i <= n && !cnt[x][i]; ++i)
			cnt[x][i] = ++dex;
		--i;
		pts(x, i, dir % 4 + 1);
	}
	if (dir == 2) {
		if (cnt[x + 1][y])	return;
		int i;
		for (i = x + 1; i <= n && !cnt[i][y]; ++i)
			cnt[i][y] = ++dex;
		--i;
		pts(i, y, dir % 4 + 1);
	}
	if (dir == 3) {
		if (cnt[x][y - 1])	return;
		int i;
		for (i = y - 1; i >= 1 && !cnt[x][i]; --i)
			cnt[x][i] = ++dex;
		++i;
		pts(x, i, dir % 4 + 1);
	}
	if (dir == 4) {
		if (cnt[x - 1][y])	return;
		int i;
		for (i = x - 1; i >= 1 && !cnt[i][y]; --i)
			cnt[i][y] = ++dex;
		++i;
		pts(i, y, dir % 4 + 1);
	}
}
int x, y;
signed main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d%d%d", &n, &x, &y);
	if (n <= 100) {
		cnt[1][1] = ++dex;
		pts(1, 1, 1);
//		for (int i = 1; i <= n; ++i) {
//			for (int j = 1; j <= n; ++j)
//				cout << cnt[i][j] << ' ';
//			cout << '\n';
//		}
		printf("%d", cnt[x][y]);
		return 0;
	}
	int ans = 0;
	if (n & 1) {
		if (x <= n / 2 + 1) {
			if (y >= x && y <= n - x + 1) {
				int now = 0;
				for (int i = 1; i < x; ++i)
					now += (n - 1 - (i - 1) * 2) * 4;
				ans = now + (y - x + 1);
			}
			else {
				if (y < x) {
					int now = 0;
					for (int i = 1; i < y; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (y - 1) * 2) * 3;
					ans = now + (x - y + 1);
				}
				if (y > n - x + 1) {
					int now = 0;
					for (int i = 1; i < n - y + 1; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (n - y) * 2);
					ans = now + x - (n - y);
				}
			}
		}
		else {
			if (y <= x && y >= n - x + 1) {
				int now = 0;
				for (int i = 1; i < n - x + 1; ++i)
					now += (n - 1 - (i - 1) * 2) * 4;
				now += (n - 1 - (n - x) * 2) * 3 + 1;
				ans = now - (y - (n - x) + 1);
			}
			else {
				if (y > x) {
					int now = 0;
					for (int i = 1; i < n - y + 1; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (n - y) * 2);
					ans = now + y - (n - x);
				}
				if (y < n - x + 1) {
					int now = 0;
					for (int i = 1; i < y; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (y - 1) * 2) * 3;
					ans = now + (y - (n - x) + 1);
				}
			}
		}
	}
	else {
		if (x <= n / 2) {
			if (y >= x && y <= n - x + 1) {
				int now = 0;
				for (int i = 1; i < x; ++i)
					now += (n - 1 - (i - 1) * 2) * 4;
				ans = now + (y - x + 1);
			}
			else {
				if (y < x) {
					int now = 0;
					for (int i = 1; i < y; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (y - 1) * 2) * 3;
					ans = now + (x - y + 1);
				}
				if (y > n - x + 1) {
					int now = 0;
					for (int i = 1; i < n - y + 1; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (n - y) * 2);
					ans = now + x - (n - y);
				}
			}
		}
		else {
			if (y <= x && y >= n - x + 1) {
				int now = 0;
				for (int i = 1; i < n - x + 1; ++i)
					now += (n - 1 - (i - 1) * 2) * 4;
				now += (n - 1 - (n - x) * 2) * 3 + 1;
				ans = now - (y - (n - x) + 1);
			}
			else {
				if (y > x) {
					int now = 0;
					for (int i = 1; i < n - y + 1; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (n - y) * 2);
					ans = now + y - (n - x);
				}
				if (y < n - x + 1) {
					int now = 0;
					for (int i = 1; i < y; ++i)
						now += (n - 1 - (i - 1) * 2) * 4;
					now += (n - 1 - (y - 1) * 2) * 3;
					ans = now + (y - (n - x) + 1);
				}
			}
		}
	}
	printf("%d", ans);
	return 0;
}

