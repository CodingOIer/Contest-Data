#include <bits/stdc++.h>
#define int long long
using namespace std;
constexpr int N = 1e6 + 5;
constexpr int mod = 10000;
constexpr int modx = 3e9;
string s;
int n, all, t, ans;
int cnt[N], vis[N];
signed main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	cin >> s;
	n = s.size();
	s = ' ' + s;
	for (int i = 1; i <= n; ++i) {
		if (s[i] >= '0' && s[i] <= '9')
			t = t * 10 + s[i] - '0';
		if (s[i] == '+') {
			vis[++all] = 1;
			cnt[all] = t;
			t = 0;
		}
		if (s[i] == '-') {
			vis[++all] = 2;
			cnt[all] = t;
			t = 0;
		}
		if (s[i] == '*') {
			vis[++all] = 3;
			cnt[all] = t;
			t = 0;
		}
		t %= mod;
	}
	if (all == 0) {
		printf("%lld", t % mod);
		return 0;
	}
//	cout << (0 != 2 && 0 != 3) << endl;
	for (int i = 1; i <= all; ++i) {
		if (i == 1 && vis[i] != 3)	ans += cnt[i];
		else {
			if (vis[i - 1] == 1 && vis[i] != 3)
				ans += cnt[i];
			if (vis[i - 1] == 2 && vis[i] != 3)
				ans -= cnt[i];
		}
		if (i == all && vis[i] == 1)
			ans += t;
		if (i == all && vis[i] == 2)
			ans -= t;
		ans = (ans + modx) % mod;
//		cout << vis[i - 1] << ' ' << ' ' << ans << '\n';
	}
	int fl = 0, f = 1;
	for (int i = 1; i <= all; ++i) {
		if (vis[i] == 3) {
			f *= cnt[i];
			if (vis[i - 1] == 2)	f *= -1;
			f = (f + modx) % mod;
//			cout << "1TH " << f << '\n';
			fl = 1;
		}
		if (vis[i] == 3 && i == all) {
			f *= t;
			f = (f + modx) % mod;
//			cout << "2TH " << f << '\n';
			fl = 1;
		}
		if (vis[i] != 3 && vis[i - 1] == 3) {
			f *= cnt[i];
			f = (f + modx) % mod;
//			cout << "3TH " << f << '\n';
			fl = 1;
		}
//		cout << "ALL " << fl << ' ' << f << '\n';
		if (vis[i] != 3 || i == all) {
			if (fl) {
				ans += f;
//				cout << "EX " << ans << '\n';
				ans = (ans + modx) % mod;
			}
			fl = 0;
			f = 1;
		}
	}
	printf("%lld", ans);
	return 0;
}

