#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;
const ll mod = 1e4 ;

ll solve ( string now )
{
	// cerr << now << endl ;
	ll len = now.size () - 1 ;
	if ( now.find ( '+' ) != string::npos )
	{
		ll place = now.find ( '+' ) ;
		// cerr << place << " " << now.substr ( 0 , place ) << '+' << now.substr ( place + 1 , len - place ) << endl ;
		return ( solve ( now.substr ( 0 , place ) ) + solve ( now.substr ( place + 1 , len - place ) ) ) % mod; 
	}
	if ( now.find ( '-' ) != string::npos )
	{
		ll place = now.find ( '-' ) ;
		// cerr << place << " " << now.substr ( 0 , place ) << '+' << now.substr ( place + 1 , len - place ) << endl ;
		return ( solve ( now.substr ( 0 , place ) ) - solve ( now.substr ( place + 1 , len - place ) ) ) % mod ; 
	}
	if ( now.find ( '*' ) != string::npos )
	{
		ll place = now.find ( '*' ) ;
		// cerr << now.substr ( 0 , place - 1 ) << '+' << now.substr ( place , len - place ) << endl ;
		return ( solve ( now.substr ( 0 , place ) ) * solve ( now.substr ( place + 1 , len - place ) ) ) % mod ; 
	}
	return stoll ( now ) ;
}

int main ()
{
	 freopen ( "expr.in" , "r" , stdin ) ;
	 freopen ( "expr.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	string s ;
	cin >> s ;
	cout << solve ( s ) % mod << endl ;
	return 0 ;
}


