#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

const ll inf = 1e18 ;

struct node
{
	ll x , y , need = 0 , last_color ;
	bool can_mofa = 1 ;
} ;

ll m , n , ans = inf ;

int mp [105] [105] ;

bool book [105] [105] ;

bool check ( ll x , ll y )
{
	if ( x < 1 || x > n || y < 1 || y > n )
	{
		return 0 ;
	}
	return 1 ;
}

void dfs ( node now )
{
	if ( now.need >= ans )
	{
		return ;
	}
	if ( now.x == now.y && now.x == n )
	{
		ans = min ( ans , now.need ) ;
		return ;
	}
	node nxt = now ;
	book [now.x] [now.y] = 1 ;
	for ( int i = 0 ; i < 2 ; i ++ )
	{
		for ( int j = 0 ; j < 2 ; j ++ )
		{
			if ( ! ( i ^ j ) )
			{
				continue ;
			}
			nxt = now ;
			if ( check ( now.x + i , now.y + j ) )
			{
				nxt.x += i , nxt.y += j ;
				if ( mp [nxt.x] [nxt.y] == 0 && now.can_mofa )
				{
					nxt.need += 4 ;
					nxt.last_color = mp [nxt.x] [nxt.y] ;
					nxt.can_mofa = 0 ;
					dfs ( nxt ) ;
				}
				if ( mp [nxt.x] [nxt.y] != nxt.last_color )
				{
					nxt.need += 2 ;
					nxt.last_color = mp [nxt.x] [nxt.y] ;
					dfs ( nxt ) ;
				}
			}
		}
	}
	book [now.x] [now.y] = 0 ;
	return ;
}

int main ()
{
	freopen ( "chess.in" , "r" , stdin ) ;
	freopen ( "chess.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> m >> n ;
	for ( int i = 0 ; i < n ; i ++ )
	{
		int x , y , k ;
		cin >> x >> y >> k ;
		if ( k == 0 )
		{
			mp [x] [y] = 1 ;
		}
		else
		{
			mp [x] [y] = 2 ;
		}
	}
	node first ;
	first.x = first.y = 1 ;
	first.last_color = mp [1] [1] ;
	dfs ( first ) ;
	if ( ans == inf )
	{
		cout << -1 << endl ;
		return 0 ;
	}
	cout << ans << endl ;
	return 0 ;
}


