#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

int main ()
{
	freopen ( "plant.in" , "r" , stdin ) ;
	freopen ( "plant.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cout << 0 << " " << 0 << endl ;
	return 0 ;
}


