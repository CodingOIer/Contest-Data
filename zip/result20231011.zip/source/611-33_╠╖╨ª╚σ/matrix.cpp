#include<bits/stdc++.h>

using namespace std ;

typedef long long ll ;

ll n , x , y ;
ll m [1005] [1005] ;

void init ()
{
	int num = 1 , i = 1 , j = 1 ;
	int turn = 0 ;
	while ( num != n * n + 1 )
	{
		switch ( turn )
		{
			case 0 :
			{
				if ( m [i] [j + 1] || j + 1 > n )
				{
					turn = ( ++ turn ) % 4 ;
				}
				break ;
			}
			case 1 :
			{
				if ( m [i + 1] [j] || i + 1 > n )
				{
					turn = ( ++ turn ) % 4 ;
				}
				break ;
			}
			case 2 :
			{
				if ( m [i] [j - 1] || j - 1 < 1 )
				{
					turn = ( ++ turn ) % 4 ;
				}
				break ;
			}
			case 3 :
			{
				if ( m [i - 1] [j] || i - 1 < 1 )
				{
					turn = ( ++ turn ) % 4 ;
				}
				break ;
			}
		}
		switch ( turn )
		{
			case 0 :
			{
				m [i] [j ++] = num ++ ;
				break ;
			}
			case 1 :
			{
				m [i ++] [j] = num ++ ;
				break ;
			}
			case 2 :
			{
				m [i] [j --] = num ++ ;
				break ;
			}
			case 3 :
			{
				m [i --] [j] = num ++ ;
				break ;
			}
		}
	}
}

int main ()
{
	 freopen ( "matrix.in" , "r" , stdin ) ;
	 freopen ( "matrix.out" , "w" , stdout ) ;
	ios::sync_with_stdio ( 0 ) ;
	cin.tie ( 0 ) ;
	cout.tie ( 0 ) ;
	cin >> n >> x >> y ;
	init () ;
	// for ( int i = 1 ; i <= n ; i ++ )
	// {
		// for ( int j = 1 ; j <= n ; j ++ )
		// {
			// cout << m [i] [j] << ' ' ;
		// }
		// cout << endl ;
	// }
	cout << m [x] [y] << endl ;
	return 0 ;
}


