#include<bits/stdc++.h>
using namespace std;
#define int long long
int fir,nex,s;
char num;
stack<int> a;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>fir;
	a.push(fir);
	while(cin>>num>>nex){
		if(num=='+'){
			int kkk=nex%10000;
			a.push(kkk);
			continue;
		}
		if(num=='-'){
			fir=a.top();
			a.pop();
			int kkk=(fir-nex)%10000;
			a.push(kkk);
			continue;
		}
		fir=a.top();
		a.pop();
		int kkk=(fir*nex)%10000;
		a.push(kkk);
	}
	while(a.size()){
		s+=a.top();
		s%=10000;
		a.pop();
	}
	cout<<s;
	return 0;
}

