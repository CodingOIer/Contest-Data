#include<bits/stdc++.h>
using namespace std;
//#define int long long
int n,xx,yy,s;
int line(int x,int y){
	int i=n,flag=0,tim=1;//0Ϊ���ң�1Ϊ���£�2Ϊ����3Ϊ����
	while(i){ 
		i=n-tim/2;
		if(x==xx&&y==yy) break;
		if(flag%4==0){
			if(y+i>yy&&x==xx) s+=(yy-y);
			else{
				s+=(i);
				y=n-tim/4;
			}
		}
		if(flag%4==1){
			if(x+i>xx&&y==yy) s+=(xx-x);
			else {
				s+=(i);
				x=n-tim/4;
			}
		}
		if(flag%4==2){
			if(y-i<yy&&xx==x) s+=(y-yy);
			else{
				s+=(i);
				y=1+tim/4;
			} 
		}
		if(flag%4==3){
			if(x-i<xx&&y==yy) s+=(x-xx);
			else{
				s+=(i);
				x=1+tim/4;
			} 
		}
		tim++;
		flag++;
	}
	return s;
}
signed main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>xx>>yy;
	if(xx==1){
		cout<<yy;
		return 0;
	}
	cout<<line(1,1);
	return 0;
}

