#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,c,f;
bool a[1005][1005];
signed main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>n>>m>>c>>f;
	for(int i=0;i<n;i++) for(int j=0;j<m;j++) cin>>a[i][j];
	cout<<0<<" "<<0;
	return 0;
}

