#include<bits/stdc++.h>
using namespace std;
int MAXN=1e9+7;
#define int long long
//������������DP��
int n,m,x,y,c,a[105][105],dp[105][105],flag;//,magic,not_same;
int mn(int aa,int bb,int cc,int dd,int ee) {
	return min(min(aa,bb),min(min(cc,dd),ee));
}
int check(int xx,int yy) {
	int MN=MAXN;
	if(a[xx][yy] == a[xx+1][yy] && a[xx][yy] > -1 && dp[xx+1][yy]!=MAXN) MN=min(MN, min(dp[xx][yy], dp[xx+1][yy]));//�����ɫ��ͬ���ͼ̳��ý�����ٵ�һ�� 
	else if(a[xx][yy] == a[xx-1][yy] && a[xx][yy] > -1 && dp[xx-1][yy]!=MAXN) MN=min(MN, min(dp[xx][yy], dp[xx-1][yy]));
	else if(a[xx][yy] == a[xx][yy+1] && a[xx][yy] > -1 && dp[xx][yy+1]!=MAXN) MN=min(MN, min(dp[xx][yy], dp[xx][yy+1]));
	else if(a[xx][yy] == a[xx][yy-1] && a[xx][yy] > -1 && dp[xx][yy-1]!=MAXN) MN=min(MN, min(dp[xx][yy], dp[xx][yy-1]));
	else return -1;
	return MN;
}
void printdp(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) cout<<dp[i][j]<<" ";
		cout<<endl;
	}
}
void printa(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) cout<<a[i][j]<<" ";
		cout<<endl;
	}
	cout<<endl;
}
signed main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(int i=0; i<=n+1; i++) for(int j=0; j<=n+1; j++) a[i][j]=-1;
	for(int i=0; i<=n+1; i++) for(int j=0; j<=n+1; j++) dp[i][j]=MAXN;
	for(int i=0; i<m; i++) {
		cin>>x>>y>>c;
		a[x][y]=c;
	}
	dp[1][1]=0;
	for(int i=1; i<=n; i++) {
		for(int j=2; j<=n; j++) {
		//	printdp();
		//	printa();
		//	cout<<endl;
			if(a[i][j]==-1){
				if(!flag){
					dp[i][j]=mn(dp[i][j],dp[i+1][j],dp[i-1][j],dp[i][j+1],dp[i][j-1])+2;
					flag=1;
				}
				continue;
			}//���ûɫ����ħ��
			int kkk=check(i,j);
			flag=0;
			if(kkk>-1){
				dp[i][j]=kkk;
				continue;
			}
			dp[i][j]=mn(dp[i][j],dp[i+1][j],dp[i-1][j],dp[i][j+1],dp[i][j-1])+1;
		}
	}
	if(dp[n][n]>=MAXN) cout<<-1;
	else cout<<dp[n][n]-1;
	return 0;
}

