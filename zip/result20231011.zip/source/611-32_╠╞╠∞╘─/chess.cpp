#include<bits/stdc++.h>
using namespace std;
int n,m,fl=0;
int a[105][105];
int dis[105][105];
int f[105][105];
int dx[10]={1,-1,0,0};
int dy[10]={0,0,1,-1};
void bfs()
{
	queue<int> qx;
	queue<int> qy;
	queue<int> qm;
	queue<int> qf;
	qx.push(1);
	qy.push(1);
	qm.push(0);
	qf.push(0);
	f[1][1]=0;
	while (!qx.empty())
	{
		int nowx=qx.front();
		int nowy=qy.front();
		int nowm=qm.front();
		int nowf=qf.front();
		qx.pop();
		qy.pop();
		qm.pop();
		qf.pop();
		if (nowx==n && nowy==n)
			fl=1;
		for (int i=0;i<4;i++)
		{
			int flag=0;
			int nx=nowx+dx[i];
			int ny=nowy+dy[i];
			int nm=nowm;
			int nf=nowf;
			if (nx>n || ny>n || nx<=0 || ny<=0)
				continue;
			if (a[nowx][nowy]==0 && a[nx][ny]==0)
				continue;
			if (a[nowx][nowy]!=0 && a[nx][ny]==0)
			{
				flag=1;
				nm+=2;
			}
			else if ((a[nowx][nowy]!=a[nx][ny] && nf==0) || (a[nx][ny]!=nf && nf!=0))
				nm++;
			if (f[nx][ny]<=nm)
				continue;
			if (flag==1)
				qf.push(a[nowx][nowy]);
			else
				qf.push(0);
			f[nx][ny]=nm;
			qx.push(nx);
			qy.push(ny);
			qm.push(nm);
			dis[nx][ny]=nm;
		}
	}
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++)
	{
		int x,y,c;
		cin>>x>>y>>c;
		a[x][y]=c+1;
	}
	for (int i=1;i<=100;i++)
		for (int j=1;j<=100;j++)
			f[i][j]=1e9;
	bfs();
	if (fl==0)
	{
		cout<<-1;
		return 0;
	}
	cout<<dis[n][n];
	return 0;
}