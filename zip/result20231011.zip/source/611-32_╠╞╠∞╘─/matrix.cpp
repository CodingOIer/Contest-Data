#include<bits/stdc++.h>
using namespace std;
long long n,a,b,x;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>a>>b;
	long long z;
	long long a1=a,b1=b;
	if (a>n/2+1)
		a=n-a+1;
	if (b>=a && b<=n-a+1)
		x=a;
	else if (b<a)
		x=b;
	else if (b>n-a+1)
		x=n-b+1;
	z=x;
	if (n%2==1)
		x=(n/2-x+2)*2-1;
	else
		x=(n/2-x+1)*2;
	long long y;
	y=n*n-x*x;
	long long c=1,ans=0;
	long long i=z,j=z;
	while (1)
	{
		ans++;
		if (i==a1 && j==b1)
			break;
		if (j==n-z+1 && c==1)
			c=2;
		if (i==n-z+1 && c==2)
			c=3;
		if (j==z && c==3)
			c=4;
		if (c==1)
			j++;
		if (c==2)
			i++;
		if (c==3)
			j--;
		if (c==4)
			i--;
	}
	cout<<ans+y;
	return 0;
}