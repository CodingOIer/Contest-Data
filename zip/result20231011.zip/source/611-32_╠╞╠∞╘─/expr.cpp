#include<bits/stdc++.h>
using namespace std;
string s;
long long t=0,mod=10000;
char st[1000005];
int sk[1000005];
char a[1000005];
int top=0,b=0;
int main()
{
	freopen("expr.in" ,"r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int l=s.length();
	for (int i=0;i<l;i++)
	{
		if (s[i]>='0' && s[i]<='9')
			a[++b]=s[i];
		else if (s[i]=='+')
		{
			a[++b]='.';
			if (st[top-1]=='*')
			{
				while (top)
				{
					a[++b]=st[top-1];
					top--;
				}
			}
			st[top++]='+';
		}
		else if (s[i]=='-')
		{
			a[++b]='.';
			if (st[top-1]=='*')
			{
				while (top)
				{
					a[++b]=st[top-1];
					top--;
				}
			}
			st[top++]='-';
		}
		else if (s[i]=='*')
		{
			a[++b]='.';
			st[top++]='*';
		}
	}
	a[++b]='.';
	while (top)
	{
		a[++b]=st[top-1];
		top--;
	}
	top=0;
	for (int i=1;i<=b;i++)
	{
		if (a[i]>='0' && a[i]<='9')
			t=t*10+a[i]-'0';
		else if (a[i]=='.')
		{
			t%=mod;
			sk[top++]=t;
			t=0;
		}
		else if (a[i]=='+')
		{
			int a=sk[top-1];
			int b=sk[top-2];
			top-=2;
			sk[top++]=(a+b)%mod;
		}
		else if (a[i]=='-')
		{
			int a=sk[top-1];
			int b=sk[top-2];
			top-=2;
			sk[top++]=(b-a)%mod;
		}
		else if (a[i]=='*')
		{
			int a=sk[top-1];
			int b=sk[top-2];
			top-=2;
			sk[top++]=(a*b)%mod;
		}
	}
	cout<<sk[0];
	return 0;
}