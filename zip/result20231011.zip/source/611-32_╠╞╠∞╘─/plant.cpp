#include<bits/stdc++.h>
using namespace std;
int n,m;
int t,id,c,f;
int a[1005][1005];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	if (id==0)
		cout<<4<<' '<<2;
	while (t--)
	{
		cin>>n>>m;
		for (int i=1;i<=n;i++)
			for (int j=1;j<=m;j++)
				cin>>a[i][j];
	}
	return 0;
}