#include<bits/stdc++.h>
#define endl "\n"
#define mem_min 128
#define mem_max 127
#define int long long
#define INT LONG_LONG
#define quick_io ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
using namespace std;
string s,s1,s2;
int a[100005],t,st[100005],top;
signed main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	quick_io;
	cin>>s;
	int n=s.size();
	for (int i=0;i<n;)
	{
		if (isdigit(s[i]))
		{
			t++;
			while (isdigit(s[i]))
			{
				a[t]=a[t]*10+(s[i]-'0');
				a[t]%=10000;
				i++;
			}
		}
		else 
		{
			s1+=s[i];
			i++;
		}
	}
	st[++top]=a[1];
	int k=0;
	for (int i=2,j=0;i<=t;i++,j++)
	{
		if (s1[j]=='+'||s1[j]=='-')
			st[++top]=a[i],s2[++k]=s1[j];
		else 
			st[top]=(st[top]*a[i])%10000;
	}
	for (int i=top-1;i>=1;i--)
	{
		if (s2[i]=='+')
			st[i]=(st[i]+st[i+1])%10000;
		else
			st[i]=(st[i]-st[i+1])%10000;
	}
	cout<<st[1];
	return 0;
}
