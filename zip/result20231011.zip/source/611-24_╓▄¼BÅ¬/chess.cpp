#include<bits/stdc++.h>
#define endl "\n"
#define mem_min 128
#define mem_max 127
#define int long long
#define INT LONG_LONG
#define quick_io ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
using namespace std;
int m,n,x,y,c,a[10005],ans=INT_MAX;
vector<int> edges[10005];
bool vis[10005];
inline void dfs(int x,bool v,int sum)
{
	if (x==m*m)
	{
		ans=min(ans,sum);
		return ;
	}
	for (auto i:edges[x])
		if (vis[i]==0)
		{
			vis[i]=1;
			if (!v&&a[i]==-1)
				a[i]=a[x],dfs(i,1,sum+2),a[i]=-1;
			else if (a[i]!=-1&&a[i]!=a[x])
				dfs(i,0,sum+1);
			else if (a[i]!=-1&&a[i]==a[x])
				dfs(i,0,sum);
			vis[i]=0;
		}
}
signed main()
{
	freopen("chees.in","r",stdin);
	freopen("chess.out","w",stdout);
	quick_io;
	cin>>m>>n;
	memset(a,255,sizeof(a));
	for (int i=1;i<=m*m;i++)
	{
		if (i-m>0)
			edges[i].push_back(i-m);
		if (i+m<=m*m)
			edges[i].push_back(i+m);
		if (i-1>0)
			edges[i].push_back(i-1);
		if (i+1<=m*m)
			edges[i].push_back(i+1);
	}
	for (int i=1;i<=n;i++)
	{
		cin>>x>>y>>c;
		a[(x-1)*m+y]=c;
	}
	dfs(1,0,0);
	if (ans==INT_MAX)
		cout<<-1;
	else 
		cout<<ans;
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

5 5
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0
*/
