#include<bits/stdc++.h>
#define endl "\n"
#define mem_min 128
#define mem_max 127
#define int long long
#define INT LONG_LONG
#define quick_io ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define lowbit(x) x&-x
const int P=998244353;
using namespace std;
int T,id,n,m,c,f,a[1005][1005],b[1005][6];
string s;
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	quick_io;
	cin>>T>>id;
	for (int k=1;k<=T;k++)
	{
		cin>>n>>m>>c>>f;
		if (id==1)
		{
			cout<<0<<' '<<0<<endl;
			continue;
		}
		int ansi=0,ansj=0;
		for (int i=1;i<=n;i++)
		{
			cin>>s;
			for (int j=0;j<m;j++)
			{
				a[i][j+1]=s[j]-'0';
			}
		}
		int ans=0;
		for (int x1=1;x1<n-1;x1++)
		{
			for (int x2=x1+2;x2<=n;x2++)
			{
				for (int y1=1;y1<m;y1++)
				{
					for (int y2=y1+1;y2<=m;y2++)
					{
						for (int y3=y1+1;y3<=m;y3++)
						{
							bool v=true;
							for (int k=y1;k<=y2;k++)
								if (a[x1][k])
								{
									v=false;
									break;
								}
							for (int k=y1;k<=y3;k++)
								if (a[x2][k])
								{
									v=false;
									break;
								}
							if (v)
							{
								for (int k=x1;k<=x2;k++)
								{
									if (a[k][y1])
									{
										v=false;
										break;
									}
								}
								if (v)
								{
									ans=ans%P+1;
								}
							}
						}
					}
				}
			}
		}
		cout<<(ans*c)%P<<' ';
		ans=0;
		for (int x1=1;x1<n-1;x1++)
		{
			for (int x2=x1+2;x2<n;x2++)
			{
				for (int x3=x2+1;x3<=n;x3++)
				{
					for (int y1=1;y1<m;y1++)
					{
						for (int y2=y1+1;y2<=m;y2++)
						{
							for (int y3=y1+1;y3<=m;y3++)
							{
								bool v=true;
								for (int k=y1;k<=y2;k++)
									if (a[x1][k])
									{
										v=false;
										break;
									}
								for (int k=y1;k<=y3;k++)
									if (a[x2][k])
									{
										v=false;
										break;
									}
								if (v)
								{
									for (int k=x1;k<=x3;k++)
									{
										if (a[k][y1])
										{
											v=false;
											break;
										}
									}
									if (v)
									{
										ans=ans%P+1;
									}
								}
							}
						}
					}
				}
			}
		}
		cout<<(ans*f)%P<<endl;
	}
	return 0;
}
/*1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

*/
