#include<bits/stdc++.h>
#define endl "\n"
#define mem_min 128
#define mem_max 127
#define int long long
#define INT LONG_LONG
#define lowbit(x) x&-x
using namespace std;
int n,x,y,a[30005],b[30005],fx;
signed main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	int i=1,j=0,ans=0;
	while (1)
	{
		if (i==x)
		{
			ans+=abs(j-y);
			break;
		}
		if (j==y)
		{
			ans+=abs(i-x);
			break;
		}
		if (fx==0||fx==2)
		{
			int t=j;
			if (fx==0)
				j+=(n-a[i]);
			else 
				j-=(n-a[i]);
			ans+=(n-a[i]);
			a[i]=n;
			if (j<t)
			{
				for (int i1=j;i1<=t;i1++)
					b[i1]=b[i1]==n?n:b[i1]+1; 
			}
			else 
			{
				for (int i1=t;i1<=j;i1++)
					b[i1]=b[i1]==n?n:b[i1]+1;
			}
		}
		else
		{
			int t=i;
			if (fx==1)
				i+=(n-b[j]);
			else 
				i-=(n-b[j]);
			ans+=(n-b[j]);
			b[j]=n;
			if (i<t)
			{
				for (int i1=i;i1<=t;i1++)
					a[i1]=a[i1]==n?n:a[i1]+1; 
			}
			else 
			{
				for (int i1=t;i1<=i;i1++)
					a[i1]=a[i1]==n?n:a[i1]+1;
			}
		}
		fx=(fx+1)%4;
	}
	cout<<ans;
	return 0;
}
