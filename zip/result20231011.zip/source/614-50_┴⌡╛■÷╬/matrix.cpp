#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
void pop(){return;}
int a[1010][1010],n,x,y;
void baoli()
{
	for(int i=1,j=0,vis=0,sum=1;sum<=n*n;sum++)
	{
	//	cout << i << " " << j << " " << vis << "\n";
		if(vis==0&&a[i][j+1]==0&&j!=n) a[i][++j]=sum;
		else if(vis==1&&a[i+1][j]==0&&i!=n) a[++i][j]=sum;
		else if(vis==2&&a[i][j-1]==0&&j!=1) a[i][--j]=sum;
		else if(vis==3&&a[i-1][j]==0&&i!=1) a[--i][j]=sum;
		else vis=(vis+1)%4,sum--;
	}
	cout << a[x][y];
}
void waijie()
{
	for(int i=1,j=1,vis=0,sum=1,up=0,down=n,left=0,right=n;;)
	{
		if(up==x&&right==y){
			cout << sum;
			break;
		}
		if(vis==0){sum+=right-left;up++;}
		if(vis==1){sum+=down-up;right--;}
		if(vis==2){sum+=right-left;down--;}
		if(vis==3){sum+=down-up;left++;}
		vis=(vis+1)%4;
	}
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin >> n >> x >> y;
	if(n<=1000) baoli();
	else waijie();
	return 0;
}
//4 2 3
/*
1  2  3  4
12 13 14 5
11 16 15 6
10 9  8  7

1 sum=4,up=1,down=4,left=0,right=4;
2 sum=7,up=1,down=4,left=0,right=3;
3 sum=10,up=1,down=3,left=0,right=3;
4 sum=12,up=1,down=3,left=1,right=3;
5 sum=14,up=2,down=3,left=1,right=3;
6 sum=15,up=2,down=3,left=1,right=2;
7 sum=16,up=2,down=2,left=1,right=2;




*/
