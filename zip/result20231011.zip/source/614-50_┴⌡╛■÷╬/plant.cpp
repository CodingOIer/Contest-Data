#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
void pop(){return;}
int t,id,n,m,c,f;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin >> t >> id;
	if(id==1) cout << "0 0";
	if(id==2) cout << "1 0";
	if(id==3) cout << "2 1";
	return 0;
}
