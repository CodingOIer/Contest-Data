#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
void pop(){return;}
int n,m,col[110][110],dp[110][110],vis[110][110],cis[110][110],minx=2e9,sum;
int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};
void dfs(int x,int y)
{
	if(sum>=minx) return;
	if(x==m&&y==m){
		minx=sum;
		return;
	}
	for(int i=0;i<4;i++)
	{
		int xx=x+dx[i];
		int yy=y+dy[i];
		if(xx>=1&&xx<=m&&yy>=1&&yy<=m&&!vis[xx][yy]){
			if(col[xx][yy]==0){
				if(cis[x][y]) continue;
				else{
					cis[xx][yy]=1;col[xx][yy]=col[x][y];
					sum+=2,vis[xx][yy]=1;
					dfs(xx,yy);
					sum-=2,vis[xx][yy]=0;
					cis[xx][yy]=0;col[xx][yy]=0;
				}
			}
			else{
				if(col[x][y]!=col[xx][yy]) sum++;
				vis[xx][yy]=1,dfs(xx,yy),vis[xx][yy]=0;
				if(col[x][y]!=col[xx][yy]) sum--;
			}
		}
	}
}
void d_p()
{
	for(int i=0;i<=m;i++)
		for(int j=0;j<=m;j++)
			dp[i][j]=2e9;
	dp[1][1]=0;
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(i==1&&j==1) j=2;
			if(col[i][j]==0){
				bool con1=(cis[i-1][j]||col[i-1][j]==0),con2=(cis[i][j-1]||col[i][j-1]);
				if(con1&&con2) continue;
				else if((dp[i-1][j]<=dp[i][j-1]&&!con1)||con2){
					col[i][j]=col[i-1][j];
					dp[i][j]=dp[i-1][j]+2;
				}
				else{
					col[i][j]=col[i][j-1];
					dp[i][j]=dp[i][j-1]+2;
				}
				cis[i][j]=1;
			}
			else dp[i][j]=min(dp[i-1][j]+(col[i][j]!=col[i-1][j]),dp[i][j-1]+(col[i][j]!=col[i][j-1]));
		}
	}
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin >> m >> n;
	for(int i=1;i<=n;i++)
	{
		int x,y,c;
		cin >> x >> y >> c;
		if(c==0) col[x][y]=1;
		else col[x][y]=2;
	}
	if(m>=10){
		dfs(1,1);
		if(minx==2e9) cout << -1;
		else cout << minx;
		return 0;
	}
	else{
		d_p();
		if(dp[m][m]>=2e9) cout << -1;
		else cout << dp[m][m];
		return 0;
	}
}
