#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
void pop(){return;}
const int mod=10000;
ll ans,sum,vis,cnt,a[100010],b[100010];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	for(char s;;)
	{
		s=getchar();
		if(s=='\n'){
			if(vis==0) a[++cnt]=sum;
			else a[++cnt]=(sum*vis)%mod;
			break;
		}
		if(s>='0'&&s<='9') sum=(sum*10+int(s-'0'))%mod;
		if(s=='*'){
			if(vis==0) vis=sum;
			else vis=(vis*sum)%mod;
			sum=0;
		}
		if(s=='+'||s=='-'){
			if(vis==0) a[++cnt]=sum;
			else a[++cnt]=(sum*vis)%mod;
			if(s=='+') b[cnt+1]=1;
			vis=0;sum=0;
		}
	}
	ans=a[1];
	for(int i=2;i<=cnt;i++)
	{
		if(b[i]==1) ans=(ans+a[i])%10000;
		else ans=(ans-a[i])%10000;
	}
	cout << ans;
	return 0;
}
