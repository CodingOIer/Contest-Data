#include<bits/stdc++.h>
using namespace std;
long long tt,dd,n,m,cc,ff;
char a[1145][1145];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&tt,&dd);
	scanf("%d%d%d%d",&n,&m,&cc,&ff);
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n+1;j++){
			scanf("%c",&a[i][j]);
		}
	}
	if(cc==0&&ff==0||m==2) {printf("%d %d",0,0);return 0;}
	
	return 0;
}
/*
1 0
4 3 1 1 
001
010
000
000
*/

