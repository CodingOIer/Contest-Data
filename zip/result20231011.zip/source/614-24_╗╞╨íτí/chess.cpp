#include<bits/stdc++.h>
using namespace std;
long long n,m,a[1145][1419],t=0,s=0;
int e,f,g;
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout); 
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){scanf("%d%d%d",&e,&f,&g);a[e][f]=g+1;}
	printf("%d",-1);
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
*/
