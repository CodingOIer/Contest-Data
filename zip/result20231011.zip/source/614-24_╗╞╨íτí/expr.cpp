#include<bits/stdc++.h>
using namespace std;
char qq=0,q=0,h;//q:ǰһ���������h:��һ������� 
long long s=0,small_s,t=1,n; 
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	while(t)
	{
		scanf("%d",&n);
		t=scanf("%c",&h)==1? 1:0;
		if(t) qq=q;
		if(q==0) small_s=n%10000;
		if(q=='+') {s=(s+small_s)%10000;small_s=n%10000;}
		if(q=='-') {s=small_s%10000;small_s=-n;}
		if(q=='*') small_s=(small_s*(n%10000))%10000;
		if(t==0) s=(s+small_s)%10000;
		q=h;
	}
	printf("%d",s);
	return 0;
}
//1+1*3-4
/*
n=1,h=-,q=0
small_s=1;

n=5,h=*,q=-
s=1 small_s=-5

n=8,h=+,q=*
small_s=-5*8=-40

n=99,h=??? q=+
s=1-40 small_s=99
 */
