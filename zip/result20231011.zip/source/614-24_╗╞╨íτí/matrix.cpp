#include<bits/stdc++.h>
using namespace std;
long long n,hang,lie,s=0,m,q;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d%d",&n,&hang,&lie);
	m=n,n=n*n;
	if(lie==hang&&hang==n/2+1||lie==n/2&&hang==n/2+1)
	{printf("%d",n*n);return 0;} 
	while(hang!=1&&hang!=n&&lie!=1&&lie!=n)
	{
		hang--,lie--;
		s+=4*m-4;
		m-=2;
		n=m*m;
	}
	if(hang==1) s+=lie;
	else
	{
		q=4*m-4;
		if(lie==1) s+=q-hang+2;
		if(lie==n) s+=n+1;
	}
	printf("%d",s);
	return 0;
}
/*
hang!=1!=n&&lie!=1!=n;
*/

