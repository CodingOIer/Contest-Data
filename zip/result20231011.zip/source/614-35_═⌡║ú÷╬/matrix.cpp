#include<bits/stdc++.h>
using namespace std;
long long a[101][101],cnt;
long long n,x,y;
void dfs(int r,int l,int f)
{
//	cout<<cnt<<endl;
	a[r][l]=++cnt;
	if(cnt==n*n) return;
	if(f==1)
	{
		if(a[r+1][l]==0) dfs(r+1,l,f);
		else f=2; 
	}
	if(f==2) 
	{
		if(a[r][l-1]==0) dfs(r,l-1,f);
		else f=3;
	}
	if(f==3) 
	{
		if(a[r-1][l]==0) dfs(r-1,l,f);
		else f=4;
	}
	if(f==4)
	{
		if(a[r][l+1]==0) dfs(r,l+1,f);
		else dfs(r+1,l,1);
	}
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	if(n<=100)
	{
		a[n+1][n]=-1;
		a[n][0]=-1;
		a[0][1]=-1;
		dfs(1,n,1);
		cout<<a[y][n-x+1];
		return 0;
	} 
	long long u=min(y-1,min(x-1,min(n-x,n-y)));
	cnt+=n*n-(n-u*2)*(n-u*2);
	if(x==u+1) cnt+=y-u;
	if(y==n-u && x!=u+1) cnt+=n-2*u-1,cnt+=x-u;
	if(x==n-u && y!=n-u && x!=u+1) cnt+=n-2*u-1,cnt+=n-u-y;
	if(y==u+1 && y!=n-u && x!=u+1 && x!=n-u) cnt+=n-2*u-1,cnt+=x-u;
	cout<<cnt; 
	return 0;
}

