#include<bits/stdc++.h>
using namespace std;
int a[1000001];
int b[1000001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	long long n=s.size(),ans=0,cnt=0;
	for(int i=0;i<n;i++)
	{
		if(s[i]=='+') a[++cnt]=ans%100000,ans=0,a[++cnt]=0,b[cnt]=1;
		if(s[i]=='*') a[++cnt]=ans%100000,ans=0,a[++cnt]=0,b[cnt]=2;
		if(s[i]=='-') a[++cnt]=ans%100000,ans=0,a[++cnt]=0,b[cnt]=3;
		if(s[i]!='*' && s[i]!='+' && s[i]!='-') ans=(ans*10+s[i]-'0')%100000;
	}
	a[++cnt]=ans;
	for(int i=1;i<=cnt;i++)
	{
		if(b[i]==2)
		{
			a[i+1]=(a[i+1]*a[i-1])%100000;
			a[i-1]=0;
		}
		if(b[i]==3)
		{
			a[i+1]=-a[i+1];
		}
	}
	ans=0;
	for(int i=1;i<=cnt;i++) 
	{
		ans=(ans+a[i])%100000;
	}
	if(ans>0) cout<<ans%10000;
	else cout<<-(-ans%10000); 
	return 0;
}

