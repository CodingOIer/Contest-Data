#include<bits/stdc++.h>
using namespace std;
int a[1001][1001],vis[1001][1001],ans=INT_MAX;
long long dp[1001][1001];
int n,m;
void dfs(int x,int y,int f,int sum)
{
	if(x>n || y>n || x<1 || y<1) return;
	vis[x][y]=1;	
	dp[x][y]=sum;
	if(x==n && y==n) {vis[x][y]=0;ans=min(ans,sum);return;}
	if(f==0)
	{
		int t;
		if(dp[x+1][y]>dp[x][y]&&vis[x+1][y]==0 && a[x+1][y]!=a[x][y]) t=a[x+1][y],a[x+1][y]=a[x][y],dfs(x+1,y,1,sum+2),a[x+1][y]=t;
		if(dp[x-1][y]>dp[x][y]&&vis[x-1][y]==0 && a[x-1][y]!=a[x][y]) t=a[x-1][y],a[x-1][y]=a[x][y],dfs(x-1,y,1,sum+2),a[x-1][y]=t;
		if(dp[x][y+1]>dp[x][y]&&vis[x][y+1]==0 && a[x][y+1]!=a[x][y]) t=a[x][y+1],a[x][y+1]=a[x][y],dfs(x,y+1,1,sum+2),a[x][y+1]=t;
		if(dp[x][y-1]>dp[x][y]&&vis[x][y-1]==0 && a[x][y-1]!=a[x][y]) t=a[x][y-1],a[x][y-1]=a[x][y],dfs(x,y-1,1,sum+2),a[x][y-1]=t;
	}
	if(dp[x+1][y]>dp[x][y]&&vis[x+1][y]==0 && a[x+1][y]==a[x][y]) dfs(x+1,y,0,sum);
	if(dp[x-1][y]>dp[x][y]&&vis[x-1][y]==0 && a[x-1][y]==a[x][y]) dfs(x-1,y,0,sum);
	if(dp[x][y+1]>dp[x][y]&&vis[x][y+1]==0 && a[x][y+1]==a[x][y]) dfs(x,y+1,0,sum);
	if(dp[x][y-1]>dp[x][y]&&vis[x][y-1]==0 && a[x][y-1]==a[x][y]) dfs(x,y-1,0,sum);
	if(dp[x+1][y]>dp[x][y]&&vis[x+1][y]==0 && a[x+1][y]!=a[x][y] && a[x+1][y]!=2) dfs(x+1,y,0,sum+1);
	if(dp[x-1][y]>dp[x][y]&&vis[x-1][y]==0 && a[x-1][y]!=a[x][y]&& a[x-1][y]!=2) dfs(x-1,y,0,sum+1);
	if(dp[x][y+1]>dp[x][y]&&vis[x][y+1]==0 && a[x][y+1]!=a[x][y]&& a[x][y+1]!=2) dfs(x,y+1,0,sum+1);
	if(dp[x][y-1]>dp[x][y]&&vis[x][y-1]==0 && a[x][y-1]!=a[x][y]&& a[x][y-1]!=2) dfs(x,y-1,0,sum+1);
	vis[x][y]=0;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)for(int j=1;j<=n;j++) a[i][j]=2,dp[i][j]=INT_MAX;
	for(int i=1;i<=m;i++)
	{
		int x,y,z;
		cin>>x>>y>>z;
		a[x][y]=z;	
	} 
	dfs(1,1,0,0);
	if(ans==INT_MAX) cout<<-1;
	else cout<<ans;
	return 0;
}

