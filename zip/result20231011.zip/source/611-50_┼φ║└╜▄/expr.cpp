#include <bits/stdc++.h>
using namespace std;
int num=1,i,first,m=10000,t;
long long ans;
char a[1000005],anum[100005],f[100005];
int ch(int n,int x)
{
	int s=1,nu=n;
	for(int j=x;;j++)
	{
		if(a[j]>='0' && a[j]<='9')
		{
			nu=(nu*10+a[j]-48)%m;
		}
		if(a[j]=='*')
		{
			s=s*nu%m;
			nu=0;
		}
		else if(a[j]=='+' || a[j]=='-' || a[j]==0)
		{
			i=j-1;
			return s*nu%m;
		}
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int nu;
	cin>>a+1;
	for(int i=1;;i++)
	{
		if(a[i]>='0' && a[i]<='9')
			t=t*10+a[i]-48;
		if(a[i]=='+' || a[i]=='-' || a[i]=='*')
			break;
		if(a[i]==0)
		{
			cout<<t;
			return 0;
		}
	}
	for(i=1;a[i]!=0;i++)
	{
		if(a[i]>='0' && a[i]<='9')
			nu=(nu*10+a[i]-48)%m;
		else if(first==0)
		{
			first=1;
			ans+=ch(0,1)%m;
		}
		if(a[i]=='+')
			ans+=ch(0,i+1)%m;
		if(a[i]=='-')
			ans-=ch(0,i+1)%m;
		if(a[i]=='*')
			ans+=ch(0,i+1)%m;
	}
	cout<<ans;
	return 0;
}
