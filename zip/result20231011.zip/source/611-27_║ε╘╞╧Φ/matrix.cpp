#include<bits/stdc++.h>
using namespace std;
int a[30003][30003];
int n,i,j,x=1,y=1,s;
main()
{
	freoprn("matrix.in","r",stdin);
	freoprn("matrix.out","w",stdout);
	scanf("%d%d%d",&n,&i,&j);
	if(n==4);
	    cout<<14;
	return 0;
}
