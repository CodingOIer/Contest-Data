#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int mx = 5505;
int q[mx][mx],dir = 0,n,tx,ty;
int d[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
inline int read()
{
	int ch = getchar(),res = 0,f = 0;
	while(!isdigit(ch)) f |= ch == '-',ch = getchar();
	while( isdigit(ch)) res = (res << 3) + (res << 1) + (ch ^ 48),ch = getchar();
	return f ? -res : res;
}
void dfs(int x,int y,int s)
{
	q[x][y] = s;
	if(x == tx && y == ty) return; 
	int nx = x + d[dir][0],ny = y + d[dir][1];
	while(q[nx][ny] != 0) dir = (dir + 1) % 4,nx = x + d[dir][0],ny = y + d[dir][1];
	dfs(nx,ny,s+1);
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	n = read(),tx = read(),ty = read();
	for(int i = 0;i <= n + 1; i++) q[0][i] = q[n + 1][i] = q[i][0] = q[i][n + 1] = 1e9;
	dfs(1,1,1);
	cout << q[tx][ty];
	return 0;
}  
