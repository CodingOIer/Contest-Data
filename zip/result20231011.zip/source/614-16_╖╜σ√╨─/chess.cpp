#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read()
{
	int ch = getchar(),res = 0,f = 0;
	while(!isdigit(ch)) f |= ch == '-',ch = getchar();
	while( isdigit(ch)) res = (res << 3) + (res << 1) + (ch ^ 48),ch = getchar();
	return f ? -res : res;
}
int m,n,co[105][105],vis[105][105],nx,ny,ans = 1e9,cnt;
int d[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
void dfs(int x,int y,int s,int v,int lst)
{
	if(cnt >= m*m) return;
	cnt++,vis[x][y] = 1;
	if(x > m || y > m) return;
	if(x == m && y == m)
	{
		ans = min(ans,s);
		return;
	}
	for(int i = 0;i < 4; i++)
	{
		int tx = x + d[i][0],ty = y + d[i][1];
		if(1 <= tx && tx <= m && 1 <= ty && ty <= m && !vis[tx][ty])
		{
			if(v && co[tx][ty] == 0) continue;
			if(co[tx][ty] == 0)
			{
				dfs(tx,ty,s+2,1,co[x][y]);
				dfs(tx,ty,s+3,1,co[x][y] ^ 1);
			}
			else
				if(co[tx][ty] == lst) dfs(tx,ty,s,0,co[tx][ty]);
				else dfs(tx,ty,s+1,0,co[tx][ty]);
		}
	}
	vis[x][y] = 0;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	m = read(),n = read();
	for(int i = 1;i <= n; i++) nx = read(),ny = read(),co[nx][ny] = read() + 1;
	dfs(1,1,0,0,co[1][1]);
	cout << (ans == 1e9 ? -1 : ans);
	return 0;
}
