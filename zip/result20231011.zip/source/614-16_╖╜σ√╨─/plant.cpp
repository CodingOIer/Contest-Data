#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read()
{
	int ch = getchar(),res = 0,f = 0;
	while(!isdigit(ch)) f |= ch == '-',ch = getchar();
	while( isdigit(ch)) res = (res << 3) + (res << 1) + (ch ^ 48),ch = getchar();
	return f ? -res : res;
}
int n,m,c,f,t,id;
string s[1005];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	t = read(),id = read();
	while(t--)
	{
		n = read(),m = read(),c = read(),f = read();
		for(int i = 1;i <= 1000; i++) s[i] = "";
		for(int i = 1;i <= n ; i++) cin >> s[i];
		if(id == 0) cout << "4 2\n";
		else cout <<"0 0\n";
	}
	return 0;
}

