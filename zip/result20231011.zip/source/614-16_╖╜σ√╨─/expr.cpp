#include<bits/stdc++.h>
using namespace std;
#define ll unsigned long long
string s;
ll res,sta[100005],now,ans;
int opt,len,cnt,ss;
ll change(int opt,ll ch,ll res)
{
	if(opt == 1) sta[cnt] = sta[cnt] * res;
	else if(opt == 2) sta[++cnt] = -res;
	else sta[++cnt] = res;
	if(now == '+') return 0;
	if(now == '*') return 1;
	return 2;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	getline(cin,s);
	len = s.length();
	for(int i = 0;i < len; i++)
	{
		now = s[i];
		if('0' <= now && now <= '9') res = (res << 3) + (res << 1) + (now ^ 48);
		else opt = change(opt,now,res),res = 0;
	}
	opt = change(opt,now,res);
	for(int i = 1;i <= cnt; i++) ans += sta[i];
	ss = ans % 10000;
	cout << ss;
	return 0;
}

