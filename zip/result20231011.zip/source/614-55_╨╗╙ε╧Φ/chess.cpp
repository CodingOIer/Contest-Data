//��������36���������뻹��6[���ߤ�΢Ц] 
#include <bits/stdc++.h>
using namespace std;
int n,m,x,y,c;
int C[105][105],ans[105][105];
void dfs(int i,int j,int f)
{
	int tmp=C[i][j];
	if(!C[i-1][j]&&f&&ans[i][j]+2<ans[i-1][j]) ans[i-1][j]=ans[i][j]+2,C[i-1][j]=C[i][j],dfs(i-1,j,0);
	if(!C[i+1][j]&&f&&ans[i][j]+2<ans[i+1][j]) ans[i+1][j]=ans[i][j]+2,C[i+1][j]=C[i][j],dfs(i+1,j,0);
	if(!C[i][j-1]&&f&&ans[i][j]+2<ans[i][j-1]) ans[i][j-1]=ans[i][j]+2,C[i][j-1]=C[i][j],dfs(i,j-1,0);
	if(!C[i][j+1]&&f&&ans[i][j]+2<ans[i][j+1]) ans[i][j+1]=ans[i][j]+2,C[i][j+1]=C[i][j],dfs(i,j+1,0);
	if(C[i-1][j]&&ans[i][j]+(C[i][j]!=C[i-1][j])<ans[i-1][j]) 
	{
		ans[i-1][j]=ans[i][j]+(C[i][j]!=C[i-1][j]);
		C[i][j]=f*C[i][j];
		dfs(i-1,j,1);
		C[i][j]=tmp;
	}
	if(C[i+1][j]&&ans[i][j]+(C[i][j]!=C[i+1][j])<ans[i+1][j]) 
	{
		ans[i+1][j]=ans[i][j]+(C[i][j]!=C[i+1][j]);
		C[i][j]=f*C[i][j];
		dfs(i+1,j,1);
		C[i][j]=tmp;
	}
	if(C[i][j-1]&&ans[i][j]+(C[i][j]!=C[i][j-1])<ans[i][j-1])
	{
		ans[i][j-1]=ans[i][j]+(C[i][j]!=C[i][j-1]);
		C[i][j]=f*C[i][j];
		dfs(i,j-1,1);
		C[i][j]=tmp;
	}
	if(C[i][j+1]&&ans[i][j]+(C[i][j]!=C[i][j+1])<ans[i][j+1]) 
	{
		ans[i][j+1]=ans[i][j]+(C[i][j]!=C[i][j+1]);
		C[i][j]=f*C[i][j];
		dfs(i,j+1,1);
		C[i][j]=tmp;
	}
	C[i][j]*=f;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
		cin>>x>>y>>c,C[x][y]=c+1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans[i][j]=INT_MAX;
	ans[1][1]=0;
	dfs(1,1,1);
	if(ans[n][n]==INT_MAX) cout<<-1;
	else cout<<ans[n][n];
	return 0;
}
