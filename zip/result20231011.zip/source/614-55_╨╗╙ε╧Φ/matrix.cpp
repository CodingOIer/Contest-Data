//36*2
#include <bits/stdc++.h>
using namespace std;
int n,x,y,l,r,id;
int X_=0,Y_=1;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>x>>y;
	l=1,r=n,id=1;
	while(l+1<=x&&l+1<=y&&r-1>=x&&r-1>=y)
	{
		id+=4*(r-l);
		l++;
		r--;
	}
	int X=l,Y=l;
	while(true)
	{
		if(X==x&&Y==y)
		{
			cout<<id;
			return 0;
		}
		id++;
		if(Y+Y_>r) X_=1,Y_=0;
		else if(X+X_>r) X_=0,Y_=-1;
		else if(Y+Y_<l) X_=-1,Y_=0;
		else if(X+X_<l) X_=0,Y_=1;
		X+=X_,Y+=Y_;
	}
	return 0;
}
