//����ĺ��뿴1�ֵ��⣡ 
#include <bits/stdc++.h>
using namespace std;
const int mod=998244353;
int t,tmp,n,m,c,f;
int a[1005][1005];
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>t>>tmp;
	while(t--)
	{
		cin>>n>>m>>c>>f;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				cin>>a[i][j];
		cout<<"0 0"<<endl;
	}
	return 0;
} 
