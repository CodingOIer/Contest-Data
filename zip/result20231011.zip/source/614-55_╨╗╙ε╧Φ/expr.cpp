//36*1
#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e4;
int l,last,ans,k[100005];
string s;
signed main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	l=s.length()+1;
	s=s+'+';
	for(int i=0;i<l;i++)
	{
		if(s[i]=='+')
		{
			for(int i=1;i<=k[0];i++)
				last*=k[i];
			ans=(ans+last)%mod;
			k[0]=0;
			last=0;
		}
		else if(s[i]=='*')
		{
			k[++k[0]]=last;
			last=0;
		}
		else last=(last*10+s[i]-'0')%mod;
	}
	cout<<ans;
	return 0;
}
