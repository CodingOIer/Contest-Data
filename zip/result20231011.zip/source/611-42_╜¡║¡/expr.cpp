#include<bits/stdc++.h>
using namespace std;
long long h,k,sum=0,l;
char f='s',u='s';
int a() {
	cin>>h;
	while(scanf("%c",&f) and f!='\n') {
		if(f=='*') {
			cin>>k;
			h*=k;
			h%10000;
		}
		if(f=='+') {
			cin>>k;
			cin>>f;
			if(f=='\n') {
				sum+=k;
				sum%10000;
				return h+sum;
			}
			cin>>l;
			if(f=='+') {
				sum+=k+l;
				sum%10000;
			}
			if(f=='-') {
				sum+=k-l;
				sum%10000;
			}
			if(f=='*') {
				sum+=k*l;
				sum%10000;
			}

		}
		if(f=='-') {
			cin>>k;
			cin>>f;
			if(f=='\n') {
				sum-=k;
				sum%10000;
				return h+sum;
			}
			cin>>l;
			if(f=='-') {
				sum-=k+l;
				sum%10000;
			}
			if(f=='+') {
				sum-=k-l;
				sum%10000;
			}
			if(f=='*') {
				sum-=k*l;
				sum%10000;
			}
		}
	}
	return h+sum;
}
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<a()%10000;
}

