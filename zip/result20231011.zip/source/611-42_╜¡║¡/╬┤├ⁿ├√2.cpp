#include<bits/stdc++.h>
using namespace std;
int n,i,j,q=1,d=1,shu=1;
long long a[101][101];
int main() {
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	cin>>n>>i>>j;
	for(int i=1; i<=n/2; i++) {
		q++;
		for(int y=d;; y++) {
			if(a[q][y]==0 and y<=n) {
				a[q][y]=shu;
				shu++;
				if(y<n)
					d++;
			} else {
				break;
			}
		}
		d+1;
		for(int y=q+1;; y++) {
			if(a[y][d]==0 and y<=n) {
				a[y][d]=shu;
				shu++;
				if(y<=n)
					q++;
			} else {
				break;
			}
		}
		q++;
	cout<<q<<" "<<d<<endl;
		for(int y=d;; y--) {
			if(a[q][y]==0 and y>=1) {
				a[q][y]=shu;
				shu++;
				if(y>=1)
					d--;

			} else break;
		}
		q--;
		cout<<q<<" "<<d<<endl;
		for(int y=q;; y--) {
			if(a[y][d]==0 and y>=1) {
				a[y][d]=shu;
				shu++;
				if(y-1>=0)
					q--;
			} else break;
		}
		d++;
	}
	for(int i=0; i<=10; i++) {
		for(int j=0; j<=10; j++) {
			printf("%d ",a[i][j]);
		}
		cout<<endl;
	}
	cout<<shu;
}

