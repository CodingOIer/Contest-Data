#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
char s;
ll ans,a,b;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%lld",&b);
	b%=10000;
	while(scanf("%c",&s)){
		if(s!='+' && s!='*' && s!='-') 
		{
			ans=(ans+b)%10000; 
			printf("%lld",ans);
			return 0;
		}
		scanf("%lld",&a);
		if(s=='*') b=(b*a)%10000;
		else if(s=='+') ans=(ans+b)%10000,b=a%10000;
		else if(s=='-') ans=(ans+b)%10000,b=(-a)%10000;
	}
	ans=(ans+b)%10000; 
	printf("%lld",ans);
	return 0;
} 
