#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
ll n,x,y,minn,sum=1,x_1=1,y_1=1;
char z='y';
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%lld%lld%lld",&n,&y,&x);
	minn=min(x-1,y-1); minn=min(minn,min(n-x,n-y));
	for(ll i=1;i<=minn;i++)
	{
		x--,y--;
		sum+=(n-1)*4;
		n-=2;
	}
	while(1)
	{
		if(x_1==x && y_1==y)
		{
			printf("%lld",sum);
			return 0; 
		}
		sum++;
		if(z=='y')
		{
			if(x_1==n) z='x',y_1++;
			else x_1++;
		}
		else if(z=='x')
		{
			if(y_1==n) z='z',x_1--;
			else y_1++;
		}
		else if(z=='z')
		{
			if(x_1==1) z='s',y_1--;
			else x_1--;
		}
		else if(z=='s')
		{
			if(y_1==1) z='y',x_1++;
			else y_1--;
		}
	}
	printf("%lld",sum);
	return 0;
}
/*
1  2  3  4  5
16 17 18 19 6
15 24 25 20 7
14 23 22 21 8
13 12 11 10 9
*/
