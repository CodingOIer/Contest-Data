#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
int t,id,n,m;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&id);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		if(n==4) cout<<"4 2"<<endl;
		else if(n==6) cout<<"36 18"<<endl;
		else if(n==16) cout<<"114 514"<<endl;
	}
	return 0;
}

