#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
ll n,m,dp[101][101][2];
void sum(int x,int y){
	dp[x][y][1]=INT_MAX-10;
	if(dp[x][y][0]==0)
	{
		if(dp[x-1][y][0]>0 && dp[x-1][y][1]<dp[x][y][1]+2) 
			dp[x][y][1]=dp[x-1][y][1]+2,dp[x][y][0]=-dp[x-1][y][0];
		if(dp[x][y-1][0]>0 && dp[x][y-1][1]<dp[x][y][1]+2) 
			dp[x][y][1]=dp[x][y-1][1]+2,dp[x][y][0]=-dp[x][y-1][0];
		if(dp[x][y-1][0]!=dp[x-1][y][0] && dp[x][y-1][0]>0 && dp[x-1][y][0]>0 && dp[x][y-1][1]==dp[x-1][y][1])
			dp[x][y][1]=dp[x][y-1][1]+2,dp[x][y][0]=-3;
	}
	else
	{
		if(abs(dp[x-1][y][0])!=dp[x][y][0] && dp[x-1][y][0]!=-3) 
			dp[x][y][1]=min(dp[x][y][1],dp[x-1][y][1]+1);
		else dp[x][y][1]=min(dp[x][y][1],dp[x-1][y][1]);
		if(abs(dp[x][y-1][0])!=dp[x][y][0] && dp[x][y-1][0]!=-3) 
			dp[x][y][1]=min(dp[x][y][1],dp[x][y-1][1]+1);
		else dp[x][y][1]=min(dp[x][y][1],dp[x][y-1][1]);
	}
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=m;i++)
	{
		ll x,y,z;
		scanf("%lld%lld%lld",&x,&y,&z);
		dp[x][y][0]=z+1;
	}
	for(int i=2;i<=n;i++)
	{
		for(int j=1;j<i;j++) sum(i,j);
		for(int j=1;j<i;j++)  sum(j,i);
		sum(i,i);
	}
	if(dp[n][n][1]==INT_MAX-10) printf("-1");
	else printf("%lld",dp[n][n][1]);
	return 0;
}
/*
5 17
1 1 1
1 2 1
1 3 1
1 4 1
1 5 1
2 5 1
3 5 1
3 4 1
3 3 1
3 2 1
3 1 1
4 1 1
5 1 1
5 2 1
5 3 1
5 4 1
5 5 1
*/
