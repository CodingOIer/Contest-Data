#include <bits/stdc++.h>
#define int long long
using namespace std;

const int mod = 1e10, ansmod = 1e4;
int sum, ans;
char ch;
stack <int> s;

signed main(){
	freopen ("expr.in", "r", stdin);
	freopen ("expr.out", "w", stdout);
	
	bool flag = false, flag1 = false; // flag�����˺ţ�flag1�������� 
	while (scanf ("%c", &ch) != EOF){
		if (isdigit(ch)){
			sum *= 10;
			sum += (ch - '0');
		} else {
			if (flag1) {
				s.push(-sum);
				flag1 = false;
			}
			else s.push(sum);
			
			if (flag) {
				int x = s.top(); s.pop();
				int y = s.top(); s.pop();
				
				s.push(x * y % mod);
				flag = false;
			} 	
			if (ch == '*') flag = true;
			else if (ch == '-') flag1 = true;
			sum = 0;
		}
	}
	if (sum != 0) {
		if (flag1) s.push(-sum);
		else s.push(sum);
	}
	
	while (!s.empty()) {
		int x = s.top(); s.pop();
		ans += x;
		ans = (ans + ansmod) % ansmod;
	}
	
	printf ("%d", (ans + ansmod) % ansmod);
	
	return 0;
} 
// 2147413647-114514=2147369133 
