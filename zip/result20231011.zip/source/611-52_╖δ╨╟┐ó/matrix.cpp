#include <bits/stdc++.h>
#define int long long 
using namespace std;

int n, x, y; 
int sum, num, t, ix, iy;
int flag;

signed main(){
	freopen ("matrix.in", "r", stdin);
	freopen ("matrix.out", "w", stdout);
	
	scanf ("%lld%lld%lld", &n, &x, &y);
	sum = n - 1;
	t = n;
	n *= n;
	ix = iy = num = 1;
	flag = 0;
	for (int i = 1; i <= n; ++i){
		if (sum == 0) {
			--num;
			sum = t;
			flag++;
		} 
		if (num == 0){
			--t;
			num = 2;
			sum = t;
		}
			
		if (ix == x && iy == y) {
			printf ("%lld", i);
			exit(0);
		}
		
		if (flag % 4 == 0) ++iy;
		else if (flag % 4 == 1) ++ix;
		else if (flag % 4 == 2) --iy;
		else --ix; 
		flag %= 4;
		
		--sum;
	}

	return 0;
}

