#include <bits/stdc++.h>
using namespace std;

const int N = 100 + 9, maxn = 0x3f3f3f3f; 
int m, n, ans = maxn;
int col[N][N];
bool vis[N][N];

int dx[4] = {1, 0, 0, -1};
int dy[4] = {0, -1, 1, 0};

void dfs(int x, int y, int sum, bool flag){
	if (x == m && y == m){
		ans = min(ans, sum);
		return ;
	}
	
	for (int i = 0; i < 4; ++i){
		int xx = x + dx[i], yy = y + dy[i]; 
		if (xx < 1 || xx > m || yy < 1 || yy > m || vis[xx][yy]) continue;
		
		// ��
		vis[x][y] = true;
		if (col[xx][yy] != -1){
			if (col[x][y] == col[xx][yy]) dfs(xx, yy, sum, 0);
			else dfs(xx, yy, sum + 1, 0);
		}
		
		// ����ɫ+��
		if (col[xx][yy] == -1 && flag == 0){
			col[xx][yy] = col[x][y];
			dfs(xx, yy, sum + 2, 1);
			col[xx][yy] = -1;
		}	
		vis[x][y] = false;
	}
}

int main(){
	freopen ("chess.in", "r", stdin);
	freopen ("chess.out", "w", stdout);
	
	memset (col, 255, sizeof col);
	memset (vis, false, sizeof vis);
	scanf ("%d%d", &m, &n);
	for (int i = 1; i <= n; ++i){
		int x, y, w;
		scanf ("%d%d%d", &x, &y, &w);
		col[x][y] = w;
	}
	
	dfs(1, 1, 0, 0);
	if (ans == maxn) printf ("-1");
	else printf ("%d", ans);
	
	return 0;
}
/*
#1:
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

#2:
5 5
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0
*/
