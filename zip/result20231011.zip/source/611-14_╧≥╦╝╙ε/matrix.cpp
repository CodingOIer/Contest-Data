#include<bits/stdc++.h>
using namespace std;
long long n,x,y,a,b,l,r,p=1,q=1;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	if(x==1){
		cout<<y;
		return 0;
	}
	p+=n-1;
	l=n%30000;
	for(int i=n-1,k=1;i>=1;i--,k++){
		if(k%2==1)q+=i;
		else q-=i;
		l+=i;
		if(p==y){
			if(q>x)l-=q-x;
			else l-=x-q;
			//cout<<"1 "<<q<<" "<<p<<endl;
			cout<<r*30000+l;
			return 0;
		}
		//cout<<q<<" "<<p<<" "<<l<<endl;
		if(k%2==0)p+=i;
		else p-=i;
		l+=i;
		if(l>=30000){
			l%=30000;
			r++;
		}
		if(q==x){
			if(p>y)l-=p-y;
			else l-=y-p;
			//cout<<"2 "<<q<<" "<<p<<endl;
			cout<<r*30000+l;
			return 0;
		}
		//cout<<q<<" "<<p<<" "<<l<<endl;
	}
	return 0;
}

