#include<bits/stdc++.h>
using namespace std;
int m,n,s,t,d;
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=n;i++)cin>>s>>t>>d;
	cout<<-1;
	return 0;
}

