#include<bits/stdc++.h>
using namespace std;
long long n,m=1,b,ans;
char a,c;
stack<long long>jia; 
stack<long long>jian;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>b;
	//b%=10000;
	jia.push(b);
	while(cin>>a>>b){
		//b%=10000;
		if(a=='+'){
			jia.push(b);
			c=a;
			m++;
		}
		else if(a=='-'){
			jian.push(b);
			c=a;
			n++; 
		}
		else{
			if(c=='+'){
				long long p=jia.top();
				jia.pop();
				p*=b;
				//p%=10000;
				jia.push(p);
			}
			else{
				long long p=jian.top();
				jian.pop();
				p*=b;
				//p%=10000;
				jian.push(p);
			}
		}
		//cout<<a<<" "<<b<<endl;
	}
	for(int i=1;i<=m;i++){
		long long p=jia.top();
		jia.pop();
		ans+=p;
		//cout<<p<<" ";
	}
	//cout<<endl;
	for(int i=1;i<=n;i++){
		long long p=jian.top();
		jian.pop();
		ans-=p;
		//cout<<p<<" ";
	}
	cout<<ans%10000;
	return 0;
} 

