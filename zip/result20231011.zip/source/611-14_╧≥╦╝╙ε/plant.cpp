#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],n,m,c,f,x,y,ans,id,t;
string z;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	for(int i=1;i<=t;i++){
		cin>>n>>m>>c>>f;
		for(int j=1;j<=n;j++){
			cin>>z;
			for(int k=0;k<z.size();k++){
				a[j][k+1]=z[k]-48;
			}
		}
		for(int j=1;j<=m-1;j++){//�ڼ��� 
			for(int k=1;k<=n-2;k++){//�ڼ��� 
				if(a[j][k]==0){
					for(int l=2;l<=n-1;l++){//�༸�� 
						int p=0;
						for(int o=1;o<=l;o++){//���� 
							if(a[k+o][j]!=0){
								p=1;
								break;
							}
						}
						if(p==1){
							continue;
						}
						x=0;
						y=0;
						for(int o=j+1;o<=m;o++){
							if(a[k][o]==1)break;
							x++;
						}
						for(int o=j+1;o<=m;o++){
							if(a[k+l][o]==1)break;
							y++;
						}
						ans+=x*y;
					}
				}
			}
		}
		cout<<ans*c%998244353<<" ";
		x=0;
		y=0;
		ans=0;
		for(int j=1;j<=m-1;j++){
			for(int k=1;k<=n-3;k++){
				if(a[j][k]==0){
					for(int l=3;l<=n-1;l++){
						int p=0;
						for(int o=1;o<=l;o++){
							if(a[k+o][j]!=0){
								p=1;
								break;
							}
						}
						if(p==1){
							continue;
						}
						x=0;
						y=0;
						for(int o=j+1;o<=m;o++){
							if(a[k][o]==1)break;
							x++;
						}
						for(int o=j+1;o<=m;o++){
							if(a[k+l-1][o]==1)break;
							y++;
						}
						ans+=x*y;
					}
				}
			}
		}
		cout<<ans*f%998244353<<endl;
		x=0;
		y=0;
		ans=0;
	}
	return 0;
}

