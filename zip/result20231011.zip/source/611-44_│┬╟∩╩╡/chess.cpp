#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
int a,b,c,ans;
int s[10005][10005];
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		scanf("%lld%lld%lld",&a,&b,&c);
		s[a][b]=c+1;
	}
	for(int i=1;;)
	{
		for(int j=1;;)
		{
			if(s[i+1][j]!=0&&s[i+1][j]==s[i][j])
			{
				i++;
				continue;
			}
			if(s[i+1][j]!=0&&s[i+1][j]!=s[i][j])
			{
				ans++;
				i++;
				continue;
			}
			if(s[i][j+1]!=0&&s[i][j+1]==s[i][j])
			{
				j++;
				continue;
			}
			if(s[i][j+1]!=0&&s[i][j+1]!=s[i][j])
			{
				ans++;
				j++;
				continue;
			}
			if(i==n&&j==n)
			{
				cout<<ans;
				return 0;
			}
			if(s[i+1][j]==0 && s[i][j+1]==0)
			{
				cout<<-1;
				return 0;
			}
		}
	}
	return 0;
}
