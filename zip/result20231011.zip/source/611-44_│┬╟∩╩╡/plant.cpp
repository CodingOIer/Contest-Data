#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,x,y;
int st,en,s=1,flag=1;
signed main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cout<<"114 514";
	return 0;
} /*
a[1][1]=1           st=1;an=4;
a[1][2]=2           
a[1][3]=3
a[1][4]=4
a[2][4]=5
a[3][4]=6
a[4][4]=7
a[4][3]=8
a[4][2]=9
a[4][1]=10          st=2;an=3;
a[3][1]=11
a[2][1]=12
a[2][2]=13
a[2][3]=14
a[3][3]=15
a[3][2]=16*/
