#include<bits/stdc++.h>
using namespace std;
#define int long long
char a[110000];
signed main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	
	cout<<0;
	return 0;
}
