#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,x,y;
int st,en,s=1,flag=1;
int a[10000][10000];
signed main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%lld%lld%lld",&n,&x,&y);
	st=1;en=n;
	while(flag)
	{
		for(int j=st;j<=en;j++)
		{
			a[st][j]=s;
			if(s==n*n)flag=0;
			s++;
		}
		for(int i=st+1;i<=en;i++)
		{
			a[i][en]=s;
			if(s==n*n)flag=0;
			s++;
		}
		for(int j=en-1;j>=st;j--)
		{
			a[en][j]=s;
			if(s==n*n)flag=0;
			s++;
		}
		for(int i=en-1;i>=st+1;i--)
		{
			a[i][st]=s;
			if(s==n*n)flag=0;
			s++;
		}
		st++;
		en--;
	}
	/*for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}*/
	cout<<a[x][y];
	return 0;
} /*
a[1][1]=1           st=1;an=4;
a[1][2]=2           
a[1][3]=3
a[1][4]=4
a[2][4]=5
a[3][4]=6
a[4][4]=7
a[4][3]=8
a[4][2]=9
a[4][1]=10          st=2;an=3;
a[3][1]=11
a[2][1]=12
a[2][2]=13
a[2][3]=14
a[3][3]=15
a[3][2]=16*/
