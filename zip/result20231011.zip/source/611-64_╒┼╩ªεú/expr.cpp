#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define isint(a) (a<='9'&&a>='0')
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	getline(cin,a);
	char updat='+';
	vector<int> s;
	int len=a.size();
	ll ans=0,j=0,mod=10000;
	for(int i=0;i<len;i++){
		if(isint(a[i])){
			j*=10;
			j+=a[i]-'0';
			j%=mod;
		}else{
			if(updat=='*'){
				s[s.size()-1]*=j;
				s[s.size()-1]%=mod;
			}else{
				if(updat=='-')j=-j;
				s.push_back(j);
			}
			j=0;
			updat=a[i];
		}
	}
	if(updat=='*'){
		s[s.size()-1]*=j;
		s[s.size()-1]%=mod;
	}else{
		if(updat=='-')j=-j;
		s.push_back(j);
	}
	for(auto e:s){
		ans+=e;
		ans%=mod;
	}
	cout<<ans;
} 
