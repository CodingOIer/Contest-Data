#include<bits/stdc++.h>
using namespace std;
#define ll long long
int toup(double s){
	double a=1-1E-5;
	s+=a;
	return (int)s; 
}
int i,j,n,x=1,y=1,len;
int mid;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);

	cin>>n>>i>>j;
	mid=toup(double(n)/2);
	if(i>mid){
		x=n-i+1;
	}else{
		x=i;
	}
	if(j>mid){
		y=n-j+1;
	}else{
		y=j;
	}
	len=min(x,y);
	int x2=len,y2=len;
	int wlen=n-2*(len-1);
	int ans=0;
	if(x==y&&x==mid&&n%2==1){
		cout<<n*n;
		return 0;
	}
	for(int i=0;i<len-1;i++){
		ans+=4*(n-2*i)-4;
	}
	//cout<<wlen<<endl;
	x2--;
	for(int i=1;i<=wlen;i++){//cout<<x2<<" "<<y2<<" "<<ans<<endl;
		if(x2== ::j&&y2== ::i){
			cout<<ans;
			return 0;
		}
		x2++;
		ans++;
	}
		for(int i=1;i<wlen;i++){//cout<<x2<<" "<<y2<<" "<<ans<<endl;
			
		if(x2== ::j&&y2== ::i){
			cout<<ans;
			return 0;
		}
		y2++;
		ans++;
	}
		for(int i=1;i<wlen;i++){//cout<<x2<<" "<<y2<<" "<<ans<<endl;
		if(x2== ::j&&y2== ::i){
			cout<<ans;
			return 0;
		}
		x2--;
		ans++;
	}
	for(int i=1;i<wlen;i++){//cout<<x2<<" "<<y2<<" "<<ans<<endl;
		if(x2== ::j&&y2== ::i){
			cout<<ans;
			return 0;
		}
		y2--;
		ans++;
	}
}

