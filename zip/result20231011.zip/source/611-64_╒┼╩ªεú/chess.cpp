#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main(){
	freopen("chess.out","w",stdout);
	cout<<-1; 
}

