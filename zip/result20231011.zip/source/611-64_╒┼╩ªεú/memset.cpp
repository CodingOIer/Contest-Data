#include<bits/stdc++.h>
using namespace std;
#define ll long long
int a[3];
int main(){
	memset(a,114514,sizeof(a));
	cout<<a[0];
}

