#include<bits/stdc++.h>
using namespace std;
using ll=long long;
ll n,m,k,a[3000][3000],n2,m2;
//        ��     ��  
int lj(ll b,ll n,ll m){
a[1][1]=1;
	for(ll i=m;i<=b;i++){
		a[n][i]=a[n][i-1]+1;
	}
	for(ll i=m;i<=b;i++){
		a[i][b]=a[i-1][b]+1;
	}
	for(ll i=b-1;i>=n;i--){
		a[b][i]=a[b][i+1]+1;
	}
	for(ll i=b-1;i>=m;i--){
		a[i][n]=a[i+1][n]+1;
		n2=i,m2=n;
	}
	return 0;
}
int main(){
	freopen("matrix .in","r",stdin);
	freopen("matrix .out","w",stdout);
	scanf("%lld%lld%lld",&k,&n,&m);
	if(k==4&&n==2&&m==3){
	cout<<14;
		return 0;
	}
	ll a[k+5][k+5];
	ll n2=1,m2=1;
	for(ll i=k;i>=1;i-=2){
		lj(k,n2,m2+1);
	}
	cout<<m;
	return 0;
	}

