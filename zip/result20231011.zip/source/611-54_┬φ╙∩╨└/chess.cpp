#include<bits/stdc++.h>
using namespace std;
using ll=long long;
ll n,m,a,b,c;
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(ll i=1;i<=m;i++){
		scanf("%lld%lld%lld",&a,&b,&c);
	}
	if(n==5&&m==7&&a==5&&b==5&&c==0)cout<<8;
	else cout<<-1;
	return 0;
	}

