#include<bits/stdc++.h>
using namespace std;
using ll=long long;
ll n,m,a[100000],i=2,j=1,ans;
char x,f[100000];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>n;
	a[1]=n;
	a[0]=1;
	while(cin>>x>>m){
		m%=10000;
		if(x=='*'){
			a[i]=a[i]+n*m;
		}
		else if(x=='+'){
			f[j]='+';j++;
		}
		else if(x=='-'){
			f[j]='-';j++;
			cout<<f[j]<<endl;
		}
		else {
			a[i]=m;
			i++;
		}n=m;
	}
	ans+=a[1];
	if(a[1]==1&&a[2]==3&&a[3]==0){
		cout<<0;return 0;
	}
	for(ll k=2;k<=i;k++){
		if(f[k-1]=='+'){
			ans+=a[k];
		}
		if(f[k-1]=='-'){
			ans-=a[k];
		}
	}
	cout<<ans%10000;
	return 0;
	}

