#include<bits/stdc++.h>
using namespace std;
using ll=long long;
ll n,m,a,b,c,d,e[1005],s;
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	scanf("%lld%lld",&a,&b);
	scanf("%lld%lld",&c,&d);
	for(ll i=1;i<=a*b;i++){
		cin>>e[i];if(e[i]==1)s++;
	}
	if(n==1&&m==0&&a==4&&b==3)cout<<"4 2";
	if(n==1&&m==0&&a==6&&b==6)cout<<"36 18";
	if(n==1&&m==0&&a==16&&b==12)cout<<"114 514";
	else cout<<s*2<<" "<<s;
	return 0;
	}

