#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
int n,x,y;
int q1,q2;
void dfs(int sum,int dqx,int dqy,int p,char fx){
	if(dqx==y && dqy==x){
		cout<<sum<<endl;
		return;
	}
	if((fx=='L' && p==q1) || (fx=='R' && p==q1) || (fx=='U' && p==q2) || (fx=='D' && p==q2)){
		if(fx=='R') fx='D',q2--;
		else if(fx=='L') fx='U',q2--;
		else if(fx=='U') fx='R',q1--;
		else if(fx=='D') fx='L',q1--;
		if(fx=='R') dqx++;
		else if(fx=='L') dqx--;
		else if(fx=='U') dqy--;
		else if(fx=='D') dqy++;
		dfs(sum+1,dqx,dqy,1,fx);
		return;
	}
	if(fx=='R') dqx++;
	else if(fx=='L') dqx--;
	else if(fx=='U') dqy--;
	else if(fx=='D') dqy++;
	dfs(sum+1,dqx,dqy,p+1,fx);
}
signed main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>n>>x>>y;
    q1=q2=n;
    dfs(1,1,1,1,'R');
    return 0;
}

