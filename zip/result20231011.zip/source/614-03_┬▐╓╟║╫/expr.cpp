#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e5+5,mod=1e4;
int top;
int a[maxn];
string s;
signed main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>s;
    int p=0;char k='@';
    for(int i=0;i<s.size();i++){
    	if(s[i]!='+' && s[i]!='*' && s[i]!='-') p=(p*10+s[i]-'0')%mod;
    	if(s[i]=='+'){
    		if(k=='*') a[top]=(a[top]*p)%mod;
    		else if(k=='+' || k=='@') a[++top]=p%mod;
    		else a[++top]=-(p%mod);
    		p=0,k=s[i];
		}
		if(s[i]=='-'){
			if(k=='*') a[top]=(a[top]*p)%mod;
			else if(k=='+' || k=='@') a[++top]=p%mod;
    		else a[++top]=-(p%mod);
    		p=0,k=s[i];
		}
		if(s[i]=='*'){
			if(k=='*') a[top]=(a[top]*p)%mod;
			else if(k=='+' || k=='@') a[++top]=p%mod;
    		else a[++top]=-(p%mod);
    		p=0,k=s[i];
		}
	}
	if(k=='@'){
		cout<<p<<endl;
		return 0;
	}
	if(k=='*') a[top]=(a[top]*p)%mod;
	else if(k=='+' || k=='@') a[++top]=p%mod;
    else a[++top]=-(p%mod);
	int ans=0;
	for(int i=1;i<=top;i++){
		ans+=a[i];
		ans%=mod;
	}
	cout<<ans<<endl;
    return 0;
}

