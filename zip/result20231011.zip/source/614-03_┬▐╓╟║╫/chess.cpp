#include<bits/stdc++.h>
#define int long long
#define double long double
#define INF INT_MAX
using namespace std;
const int maxn=1e2+5;
int m,n,ans=INF;
int a[maxn][maxn],flag[maxn][maxn];
int dp[maxn][maxn][10];
void dfs1(int x,int y,int sum,int p){
	cout<<x<<" "<<y<<" "<<sum<<" "<<p<<endl;
	if(x<1 || y<1 || x>m || y>m || flag[x][y]) return;
	flag[x][y]=1;
	if(x==m && y==m){
		ans=min(ans,sum);
		return;
	}
	if(a[x][y]==a[x+1][y] || p==1 && a[x+1][y]!=-1) dfs1(x+1,y,sum,0);
	else if(a[x+1][y]!=-1) dfs1(x+1,y,sum+1,0);
	else if(a[x+1][y]==-1 && p==0) dfs1(x+1,y,sum+2,1);
	else return;
	if(a[x][y]==a[x-1][y] || p==1 && a[x-1][y]!=-1) dfs1(x-1,y,sum,0);
	else if(a[x-1][y]!=-1) dfs1(x-1,y,sum+1,0);
	else if(a[x-1][y]==-1 && p==0) dfs1(x-1,y,sum+2,1);
	else return;
	if(a[x][y]==a[x][y+1] || p==1 && a[x][y+1]!=-1) dfs1(x,y+1,sum,0);
	else if(a[x][y+1]!=-1) dfs1(x,y+1,sum+1,0);
	else if(a[x][y+1]==-1 && p==0) dfs1(x,y+1,sum+2,1);
	else return;
	if(a[x][y]==a[x][y-1] || p==1 && a[x][y-1]!=-1) dfs1(x,y-1,sum,0);
	else if(a[x][y-1]!=-1) dfs1(x,y-1,sum+1,0);
	else if(a[x][y-1]==-1 && p==0) dfs1(x,y-1,sum+2,1);
	else return;
}
signed main() {
//	freopen("chess.in","r",stdin);
//	freopen("chess.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>m>>n;
    memset(a,-1,sizeof(a));
    for(int i=1;i<=n;i++){
    	int x,y,p;
    	cin>>x>>y>>p;
    	a[x][y]=p;
	}
    if(m<=14){
    	dfs1(1,1,0,0);
    	if(ans==INF) cout<<-1<<endl;
    	else cout<<ans<<endl;
	}
    return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
-------------------
5 5
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0
*/

