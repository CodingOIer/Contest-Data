#include<bits/stdc++.h>
#define mod 10000
using namespace std;
string a;
int p[100009];
int op[100009];
int cnt,ans;
int cnt1,flag;
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>a;
	int len = a.size();
	for(int i=0; i<len; i++) {
		if(a[i]>='0' && a[i]<='9') {
			if(a[i-1]>='0' && a[i-1]<='9') {
				p[cnt]=p[cnt]*10+(a[i]-'0');
				p[cnt]%=mod;
			} else {
				cnt++;
				p[cnt]=a[i]-'0';
			}
		}
		if(flag==1) {
			i++;
			for(;i<len && a[i]>='0' && a[i]<='9';i++)
				p[cnt]=p[cnt]*10+a[i]-'0';
			p[cnt-1]=p[cnt]*p[cnt-1];
			p[cnt-1]%=mod;
			p[cnt]=0;
			cnt--;
			flag = 0;
		}
		if(a[i]=='*') flag = 1;
		if(a[i]=='+' || a[i]=='-') {
			if(a[i]=='+')
				op[++cnt1]=1;
			else
				op[++cnt1]=2;
		}
	}
	ans=p[1];
	for(int i=1; i<=cnt1; i++) {
		/*cout<<ans<<" ";*/
		if(op[i]==1)
			ans+=p[i+1];
		else
			ans-=p[i+1];
		ans%=mod;
	}
	cout<<ans;
	return 0;
}
/*
	1+1*3-4
*/
