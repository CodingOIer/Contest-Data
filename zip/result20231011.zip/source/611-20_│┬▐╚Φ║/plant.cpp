#include<bits/stdc++.h>
using namespace std;
int n,m;
bool tk[1009][1009];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cout<<0<<" "<<0;
	return 0;
}

