#include<bits/stdc++.h>
#define inf 0X3f3f3f
using namespace std;
int m,n;
int ans;
int x,y,c;
int fx[10][10]= {{0,-1},{0,1},{-1,0},{1,0}};
int a[109][109];
int _map[109][109];
/* int jy[109][109];��Ҫ���仯���� ���������bag wuwu[����] */ 
int dfs(int x,int y,int ans1,int flag) {
	if(x>m || y>m || x<=0 || y<=0) return inf;
	if(x==m && y==m) return ans1;
	int sum=inf;
	for(int i=0; i<4; i++) {
		int xx=x+fx[i][0];
		int yy=y+fx[i][1];
		if(_map[xx][yy]!=1) {
			_map[x][y]=1;
			if(a[xx][yy]==0) {
				if(flag==0){
					a[xx][yy]=a[x][y];
					sum=min(sum,dfs(xx,yy,ans1+2,1));
					a[xx][yy]=0;
				}
			} else if(a[xx][yy]!=a[x][y]) {
				sum=min(sum,dfs(xx,yy,ans1+1,0));
			} else {
				sum=min(sum,dfs(xx,yy,ans1,0));
			}
			_map[x][y]=0;
		}
	}
	return 	sum;
}
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>m>>n;
	for(int i=1; i<=n; i++) {
		cin>>x>>y>>c;
		a[x][y]=c+1;
	}
	ans=dfs(1,1,0,0);
	if(ans == inf) cout<<-1;
	else cout<<ans;
	return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0

5 12
1 2 0
2 3 0
3 2 0
4 3 0
4 4 0
1 1 1
2 1 1
3 1 1
3 3 1
3 4 1
4 5 1
5 5 1
*/
