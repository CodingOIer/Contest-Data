#include<bits/stdc++.h>
using namespace std;
int n,i,j,i1,jj;
int add,cnt,fx;
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(0);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>i1>>jj;
	i=1;
	int nz=1,ny=n,nx=n,ns=2;
	while(1) {
		if(fx==0) {
			if(i1==i) {
				cout<<cnt+jj-j;
				return 0;
			}
			cnt+=ny-j;
			j=ny;
			ny--;
		} else if(fx==1) {
			if(jj==j) {
				cout<<cnt+i1-i;
				return 0;
			}
			cnt+=nx-i;
			i=nx;
			nx--;
		} else if(fx==2) {
			if(i1==i) {
				cout<<cnt+j-jj;
				return 0;
			}
			cnt+=j-nz;
			j=nz;
			nz++;
		} else {
			if(jj==j) {
				cout<<cnt+i-i1;
				return 0;
			}
			cnt+=i-ns;
			i=ns;
			ns++;
		}
		fx++;
		if(fx>3) fx=0;
	}
	return 0;
}
/*
��ˮ���� qwq
4 2 3

*/
