#include<bits/stdc++.h>
using namespace std;
const int mod = 10000;
int ans,ans1,ans2,ans3,o,l;
string s;
int an(int x)
{
	l = s.size();
	for(int i = x;i < s.size();i++)
	{
		if(s[i] == '+' || s[i] == '-')
		{
			l = i - 1;
			break;
		}
		ans = 0;
		while('0' <= s[i] && s[i] <= '9' && i < s.size())
		{
			ans = (ans * 10 + s[i] - '0') % mod;
			i++;
		}
		while(s[i] == '*')
		{
			i++;
			ans1 = 0;
			while('0' <= s[i] && s[i] <= '9' && i < s.size())
			{
				ans1 = (ans1 * 10 + s[i] - '0') % mod;
				i++;
			}
			ans = (ans1 * ans);
		}
		i--;
	}
	return ans;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin >> s;
	for(int i = 0;i < s.size();i++)
	{
		if(s[i] == '+')
		{
			if(!o) o = 1,ans3 = an(0) % mod;
			ans3 = (ans3 + an(i + 1)) % mod;
			i = l;
		}
		else if(s[i] == '-')
		{
			if(!o) o = 1,ans3 = an(0) % mod;
			ans3 = (ans3 - an(i + 1) + mod) % mod;
			i = l;
		}
	}
	if(!o) ans3 = an(0) % mod;
	printf("%d",ans3);
	return 0;
}

