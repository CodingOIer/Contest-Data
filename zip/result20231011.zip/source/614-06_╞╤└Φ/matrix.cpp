#include<bits/stdc++.h>
using namespace std;
int n,x,y,l,r;
long long ans,cnt;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d%d",&n,&x,&y); ans = n * n;
	l = n;
	while(l != 1)
	{
		if(x == 1 + r)
		{
			ans = cnt + (y - r);
			break;
		}
		else if(x == n - r)
		{
			ans = cnt + (n - r - y + l * 2 - 1);
			break;
		}
		else if(y == 1 + r)
		{
			ans = cnt + (n - r - x + l * 3 - 2);
			break;
		}
		else if(y == n - r)
		{
			ans = cnt + (l + x - (r + 1));
			break;
		}
		r++;
		cnt += l * 4 - 4;
		l -= 2;
	}
	printf("%lld",ans);
	return 0;
}
