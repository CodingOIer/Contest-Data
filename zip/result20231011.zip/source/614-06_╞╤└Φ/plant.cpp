#include<bits/stdc++.h>
using namespace std;
const int mod = 998244353;
int n,m,c,f,a[1010][1010],t,id;
long long aq[1010][1010],aq1[1010][1010],aq2[1010][1010],qc,qf;//aq2���漸��Ϊ1�ĸ��� 
char ss;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	scanf("%d%d",&t,&id);
	while(t--)
	{
		scanf("%d%d%d%d",&n,&m,&c,&f); qc = qf = 0;
		if(id == 1)
		{
			printf("%d %d\n",c,f);
			continue;
		}
		for(int i = 1;i <= n;i++)
			for(int j = 1;j <= m;j++)
				cin >> ss,a[i][j] = ss - '0',aq[i][j] = aq1[i][j] = aq2[i][j] = 0;
		for(int i = 1;i <= n;i++)
			for(int j = m;j >= 1;j--)
				if(!a[i][j]) aq[i][j] = aq[i][j + 1] + 1,aq1[i][j] = aq1[i - 1][j] + aq[i][j];
		for(int i = n;i >= 1;i--)
			for(int j = m;j >= 1;j--)
				if(!a[i][j]) aq2[i][j] = aq2[i + 1][j] + 1;
		if(!f)
		{
			for(int i = 1;i <= n - 2;i++)
				for(int j = 1;j <= m - 1;j++)
					if(a[i][j] == 0 && a[i + 1][j] == 0 && a[i + 2][j] == 0) qc = (qc + ((aq[i][j] - 1) * (aq1[i + aq2[i + 1][j]][j]  - aq2[i + 1][j] + 1- aq1[i + 1][j]) % mod)) % mod;
			printf("%lld 0\n",qc);
			continue;
		}
		if(n <= 1000 && m <= 1000)
		{
			for(int i = 1;i <= n - 2;i++)
				for(int j = 1;j <= m - 1;j++)
					for(int z = 0;z <= n - i;z++)
					{
						if(a[i + z][j]) break;
						if(z > 1)
						{
							qc = (qc + ((aq[i][j] - 1) * (aq[i + z][j] - 1) % mod)) % mod;
							if(i + z + 1 <= n && a[i + z][j] == 0) qf = (qf + (((aq[i][j] - 1) * (aq[i + z][j] - 1) % mod) * aq2[i + z + 1][j])) % mod;
						//	printf("%d %d %d %lld\n",i,j,z,aq2[i + z + 1][j]);
						}
					}
			printf("%lld %lld\n",qc,qf);
		}
	}
	return 0;
}
/*
1 0
4 3 1 1
001
010
000
000

1 0
5 2 1 1
00
00
00
00
00
*/


