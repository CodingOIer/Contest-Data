#include<bits/stdc++.h>
using namespace std;
int n,x,y,a[2010][2010],cnt,i,j,l,o;
int main()
{
	cin >> n >> x >> y;
	i = j = 1; l = 1;//1 �� 2 �� 3��  4�� 
	while(cnt < n * n)
	{
		a[i][j] = ++cnt;
		if(l == 1)
		{
			if(j < n - o) j++;
			else i++,l = 2;
		}
		else if(l == 2)
		{
			if(i < n - o) i++;
			else j--,l = 3;
		}
		else if(l == 3)
		{
			if(j > 1 + o) j--;
			else i--,l = 4;
		}
		else if(l == 4)
		{
			if(i > 2 + o) i--;
			else j++,l = 1,o++;
		}
	}
	/*
	for(int i = 1;i <= n;i++,cout<<endl)
		for(int j = 1;j <= n;j++,cout<<" ")
			cout << a[i][j]; 
	*/
	cout << a[x][y];
	return 0;
}


