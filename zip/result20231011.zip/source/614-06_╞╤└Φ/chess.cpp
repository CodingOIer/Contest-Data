#include<bits/stdc++.h>
using namespace std;
int n,m,a[310][310],f[310][310],v[310][310],x,y,z,l,r,b[10000010],c[10000010],zz[310][310];
int fx[8] = {-1,1,0,0};
int fy[8] = {0,0,-1,1};
int check(int xx,int yy)
{
	if(xx == yy) return 0;
	if(yy == 0) return 2;	
	else if(xx == 0) return 0;
	return 1;
}
void bf(int xx,int yy)
{
	int x2,y2;
	for(int z = 1;z <= 4;z++)
	{
		x2 = xx + fx[z],y2 = yy + fy[z];
		if(x2 > m || y2 > m || x2 < 1 || y2 < 1 ||
		a[x2][y2] == 0) continue;
		if(f[x2][y2] > f[xx][yy] + check(a[xx][yy],a[x2][y2]))
		{
			f[x2][y2] = f[xx][yy] + check(a[xx][yy],a[x2][y2]);
			if(!v[x2][y2]) v[x2][y2] = 1,b[++r] = x2,c[r] = y2;
		}
	}
}
void bfs()
{
	while(l <= r)
	{
		v[b[l]][c[l]] = 0;
		for(int z = 1;z <= 4;z++)
		{
			x = b[l] + fx[z],y = c[l] + fy[z];
			if(x > m || y > m || x < 1 || y < 1 ||
			(a[b[l]][c[l]] == 0 && a[b[l]][c[l]] == a[x][y])) continue;
			if(f[x][y] > f[b[l]][c[l]] + check(a[b[l]][c[l]],a[x][y]))
			{
				if(a[x][y] == 0)
				{
					f[x][y] = f[b[l]][c[l]] + check(a[b[l]][c[l]],a[x][y]);
				//	printf("%d %d\n",b[l],c[l]);
				//	cout<<check(a[b[l]][c[l]],a[x][y])<<" "<<a[b[l]][c[l]]<<" "<<a[x][y]<<endl;
					a[x][y] = a[b[l]][c[l]];
					bf(x,y);
					a[x][y] = 0;
					continue;
				}
				f[x][y] = f[b[l]][c[l]] + check(a[x][y],a[b[l]][c[l]]);
				if(!v[x][y]) v[x][y] = 1,b[++r] = x,c[r] = y;
			}
		}
		l++;
	}
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i = 1;i <= n;i++)
	{
		scanf("%d%d%d",&x,&y,&z); z++;
		a[x][y] = z;
	}
	for(int i = 1;i <= m;i++)
		for(int j = 1;j <= m;j++) f[i][j] = 1e9;
	f[1][1] = 0; v[1][1] = 1;
	l = r = 1; b[l] = 1,c[l] = 1;
	bfs();
	/*
	for(int i = 1;i <= m;i++,cout<<endl)
		for(int j = 1;j <= m;j++,cout<<" ")
		{
			if(f[i][j] == 1e9) f[i][j] = -1;
			cout << f[i][j]; 
		}
	*/
	if(f[m][m] == 1e9) f[m][m] = -1;
	printf("%d",f[m][m]);
	return 0;
}
/*
5 6
1 1 0
1 2 0
2 2 1
3 3 1
5 5 0
4 4 0
*/
