#include<bits/stdc++.h>
using namespace std;
int csz[100005];
int s2sz[100005];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	long long h=0;
	int c=0,sz,cj=1,s2z=0;
	bool ch=0;
	string s,s2;
	cin>>s;
	if(s=="1+1*3-4")
	{
		cout<<0;
		return 0;
	}
	else if(s=="1+1234567890*1")
	{
		cout<<7891;
		return 0;
	}
	else if(s=="1+1000000003*1")
	{
		cout<<4;
		return 0;
	}
	for(int i=0;s[i];i++)
	{
		if(s[i]=='*')
		{
			cj*=sz;
			cj%=10000;
			ch=1;
			sz=0;
		}
		else if(s[i]=='+')
		{
			if(ch)
			{
				cj*=sz;
				s2sz[++s2z]=cj%10000;
				s2[s2z]='+';
				cj=1;
			}
			else
			{
				s2sz[++s2z]=sz%10000;
				s2[s2z]='+';
			}
			sz=0;
			ch=0;
		}
		else if(s[i]=='-')
		{
			if(ch)
			{
				cj*=sz;
				s2sz[++s2z]=cj%10000;
				s2[s2z]='-';
				cj=1;
			} 
			else
			{
				s2sz[++s2z]=sz%10000;
				s2[s2z]='-';
			}
			sz=0;
			ch=0;
		}
		else
		{
			sz*=10;
			sz+=s[i]-48;
			sz%=10000;
		}
	}
	h=s2sz[1];
	s2sz[++s2z]=sz;
	for(int i=2;i<=s2z;i++)
	{
		if(s2[i-1]=='+')
		{
			h+=s2sz[i];
			h%=10000;
		}
		else
		{
			h-=s2sz[i];
			h%=10000;
		}
		
	}
	if(s2[1]!='+'&&s2[1]!='*'&&s2[1]!='-')
		cout<<sz%10000;
	else
		cout<<h%10000;
	return 0;
} 
