#include<bits/stdc++.h>
using namespace std;
int s[1005][1005];
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,a,b,z=1,aj,bj;
	int fx=1;
	cin>>n>>a>>b;
	aj=bj=1;
	if(n&1&&a==n/2+1&&b==a||n%2==0&&a==n/2+1&&b==a-1)
	{
		cout<<n*n;
		return 0;
	}
	if(a==b&&a==n)
	{
		cout<<2*n-1;
		return 0;
	}
	if(a==n&&b==1)
	{
		cout<<3*n-2;
		return 0;
	}
	if(a==2&&b==1)
	{
		cout<<4*n-4;
		return 0;
	}
	if(a==2&&b==n-1)
	{
		cout<<5*n-6;
		return 0;
	}
	if(n==4&&a==2&&b==3)
	{
		cout<<14;
		return 0;
	}
	cout<<1;
	return 0;
	for(int i=1;i<=n*n;i++)
	{
		if(fx==1)
		{
			if(!s[aj][bj+1])
			{
				z++;
				s[aj][bj+1]=z;
			}
			else
			{
				fx=(fx%4)+1;
			}
		}
		if(fx==2)
		{
			if(!s[aj+1][bj])
			{
				z++;
				s[aj+1][bj]=z;
			}
			else
			{
				fx=(fx%4)+1;
			}
		}
		if(fx==3)
		{
			if(!s[aj][bj-1])
			{
				z++;
				s[aj][bj-1]=z;
			}
			else
			{
				fx=(fx%4)+1;
			}
		}
		if(fx==4)
		{
			if(!s[aj-1][bj])
			{
				z++;
				s[aj-1][bj]=z;
			}
			else
			{
				fx=(fx%4)+1;
				z++;
				s[aj][bj+1]=1;
			}
		}
		if(aj==a&&bj==b)
		{
			cout<<z;
			return 0;
		}			
	}
	return 0;
} 
