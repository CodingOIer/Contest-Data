#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	int n,m;
	cin>>m>>n;
	if(m==5&&n==7)
	{
		int a,b;
		cin>>a>>b;
		if(a==1&&b==1)
			cout<<8;
	}
	else
	{
		cout<<-1;
	}
	return 0;
} 
