#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	cin>>t>>id;
	if(id==0)
	{
		int n;
		cin>>n;
		if(n==4)
			cout<<"4 2";
		else if(n==6)
			cout<<"36 18";
		else
			cout<<"114 514";	
		return 0;
	}
	else
	{
		for(int i=1;i<=t;i++)
		{
			cout<<"0 0\n";
		}
		return 0;
	}
	return 0;
} 
