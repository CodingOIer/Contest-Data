#include <bits/stdc++.h>
using namespace std;
#define int long long
stack<int>stk;
stack<int>cha;
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int x,y;
    char c;
    cin>>x;
    stk.push(x);
	char last='+';
    while(cin>>c>>y)
    {
    	
        if(c=='*')
        {	
            if(last=='-')
            {
                int p=cha.top();
                cha.pop();
                cha.push(p*y);
            }
            else
            {
                int p=stk.top();
                stk.pop();
                stk.push(p*y);
            }
		}
        if(c=='+')stk.push(y);
        if(c=='-')cha.push(y);
        last=c=='*'?last:c;
    }
    int ans=0;
    while(!stk.empty())
    {
        ans+=stk.top();
        stk.pop();
    }
    while(!cha.empty())
    {
        ans-=cha.top();
        cha.pop();
    }
    cout<<ans%10000;
    return 0;
}
