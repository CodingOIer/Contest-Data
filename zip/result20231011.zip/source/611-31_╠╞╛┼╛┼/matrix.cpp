#include <bits/stdc++.h>
using namespace std;
#define int long long
int mp[105][105];
int book[105][105];
int ansx,ansy;
int n;
int ans;
void dfs(int x,int y,int cnt,int f)
{
    if(x==ansx&&y==ansy||cnt==n*n+1)
    {
		ans=cnt;
		return;
	}
    if(f==0)
    {
        if(y+1<=n&&!book[x][y+1])
        {
			book[x][y]=1;
            mp[x][++y]=cnt; 
            dfs(x,y,cnt+1,0);
            return;
        }
        else
        {
			book[x][y]=1;
            mp[++x][y]=cnt;           
            dfs(x,y,cnt+1,1);
            return;
        }
    }
    else if(f==1)
    {
        if(x+1<=n&&!book[x+1][y])
        {
			book[x][y]=1;            
			mp[++x][y]=cnt;          
            dfs(x,y,cnt+1,1);
            return;
        }
        else
        {
        	book[x][y]=1;
            mp[x][--y]=cnt;            
            dfs(x,y,cnt+1,2);
            return;
        }
    }
    else if(f==2)
    {
        if(y-1>=1&&!book[x][y-1])
        {
        	book[x][y]=1;
            mp[x][--y]=cnt;            
            dfs(x,y,cnt+1,2);
            return;
        }
        else
        {
        	book[x][y]=1;
            mp[--x][y]=cnt;           
            dfs(x,y,cnt+1,3);
            return;
        }
    }
    else if(f==3)
    {
        if(x-1>=1&&!book[x-1][y])
        {
        	book[x][y]=1;
            mp[--x][y]=cnt;            
            dfs(x,y,cnt+1,3);
            return;
        }
        else
        {
        	book[x][y]=1;
            mp[x][++y]=cnt;           
            dfs(x,y,cnt+1,0);
            return;
        }
    }
	return; 
}
signed main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>ansx>>ansy;
    dfs(1,1,1,0);
    cout<<ans;
    return 0;
}
