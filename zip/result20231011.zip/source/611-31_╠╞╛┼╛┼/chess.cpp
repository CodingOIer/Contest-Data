#include <bits/stdc++.h>
using namespace std;
#define int long long
int color[105][105];
int f[105][105];
int n,m;
int ans=0x7f;
int _min(int x,int y)
{
	return x<y?x:y;
}
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	for(int i=1;i<=105;i++)for(int j=1;j<=105;j++)f[i][j]=0x7f;
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>m>>n;
    for(int i=1;i<=n;i++)
    {
        int x,y,c;
        cin>>x>>y>>c;
		color[x][y]=c+1;

    }

    f[1][1]=0;
    for(int i=1;i<=m;i++)
    {
    	for(int j=1;j<=m;j++)
    	{

    		if(color[i][j]==color[i-1][j]&&color[i-1][j])f[i][j]=_min(f[i][j],f[i-1][j]);
			if(color[i][j]==color[i][j-1]&&color[i][j-1])f[i][j]=_min(f[i][j],f[i][j-1]);
			if(!color[i-1][j])f[i][j]=_min(f[i][j],f[i-1][j]+2);
			if(!color[i][j-1])f[i][j]=_min(f[i][j],f[i][j-1]+2);
			if(color[i][j]!=color[i-1][j]&&color[i][j])f[i][j]=_min(f[i][j],f[i-1][j]+1); 
			if(color[i][j]!=color[i][j-1]&&color[i][j])f[i][j]=_min(f[i][j],f[i][j-1]+1);
		}

	}


	if(f[m][m]==0x7f)cout<<-1;
    else cout<<_min(f[m-1][m],f[m][m-1]);
    return 0;
}
/*
5 7
1 1 0
1 2 0
2 2 1
3 3 1
3 4 0
4 4 1
5 5 0
*/
