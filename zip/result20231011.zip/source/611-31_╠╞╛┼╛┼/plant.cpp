#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cout<<"0 0"��
	return 0; 
 } 
