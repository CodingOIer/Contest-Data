#include<bits/stdc++.h>
using namespace std;
int t;
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t;
	while(t--)cout<<"0 0"<<endl;
	return 0;
}
