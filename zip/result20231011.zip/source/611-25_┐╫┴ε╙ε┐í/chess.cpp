#include<bits/stdc++.h>
using namespace std;
int m,n,i,x[1001],y[1001],c[1001],o,s;
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	for(i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i]>>c[i];
		if(i==1)
		{
			o=c[i];
			continue;
		}
		if(x[i]-x[i-1]+y[i]-y[i-1]>2)
		{
			cout<<-1;
			return 0;
		}
		if(x[i]-x[i-1]+y[i]-y[i-1]==2)s+=2,o=c[i];
		if(o!=c[i])
		{
			o=c[i];
			s++;
		}
	}
	cout<<s;
	return 0;
}
