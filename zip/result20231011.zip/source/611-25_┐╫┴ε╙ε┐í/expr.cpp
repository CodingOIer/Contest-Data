#include<bits/stdc++.h>
using namespace std;
long long a,s,b,i,q[100001],l=1,r;
char c,t[100001];
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	q[1]=a;
	while(cin>>c>>b)
	{
		l++;
		q[l]=b;
		if(c=='*')
		{
			q[l-1]=(q[l-1]*q[l])%10000;
			l--;
		}
		else
		{
			r++;
			t[r]=c;
		}
	}
	for(i=1;i<=r;i++)
	{
		if(t[i]=='+')q[i+1]=(q[i+1]+q[i])%10000;
		else q[i+1]=(q[i]-q[i+1])%10000;
	}
	cout<<q[l]%10000;
	return 0;
}
