#include<bits/stdc++.h>
using namespace std;
int n,i,j,q,s,k;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>i>>j;
	for(q=1;q<=n/2;q++)
	{
		if(q==i)
		{
			cout<<k+j-q+1;
			return 0;
		}
		if((n-q+1)==i)
		{
			cout<<k+(n-2*q+1)*2+(n-q+1-j)+1;
			return 0;
		}
		if(q==j)
		{
			cout<<k+(n-2*q+1)*3+(n-q+1-i)+1;
			return 0;
		}
		if((n-q+1)==j)
		{
			cout<<k+(n-2*q+1)+(i-q)+1;
			return 0;
		}
		if(q!=1)k+=(n-2*q+1)*4;
		else k+=(n-1)*4;
	}
	cout<<n*n;
	return 0;
}
