#include<bits/stdc++.h>
using namespace std;
int n,a,b,x,y;
int ans;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>a>>b;
	x=1;
	while(1){
		for(int i=1;i<=n;i++){
			if(x==a&&y==b) break;
			y++;
			ans++;
		}
		for(int i=1;i<n;i++){
			if(x==a&&y==b) break;
			x++;
			ans++;
		}
		for(int i=1;i<n;i++){
			if(x==a&&y==b) break;
			y--;
			ans++;
		}
		for(int i=1;i<n-1;i++){
			if(x==a&&y==b) break;
			x--;
			ans++;
		}
		if(x==a&&y==b) break;
		n-=2;	
	}
	cout<<ans;
	return 0;
}
