#include<bits/stdc++.h>
using namespace std;
int m,n,ans=INT_MAX;
int v[105][105];
bool a[105][105];
void dfs(int x,int y,int vis,int sum){
	if(sum>=ans) return;
//	cout<<x<<" "<<y<<" "<<vis<<" "<<sum<<endl;
	if(x==m&&y==m){
		ans=sum;
		return;
	}
	a[x][y]=1;
	if(v[x][y]){
		if(v[x][y+1]&&!a[x][y+1]) dfs(x,y+1,v[x][y+1],sum+bool(vis!=v[x][y+1]));
		else if(!a[x][y+1]) dfs(x,y+1,1,sum+2+bool(1==v[x][y])),dfs(x,y+1,2,sum+2+bool(2==v[x][y]));
		if(v[x+1][y]&&!a[x+1][y]) dfs(x+1,y,v[x+1][y],sum+bool(vis!=v[x+1][y]));
		else if(!a[x+1][y]) dfs(x+1,y,1,sum+2+bool(1==v[x][y])),dfs(x+1,y,2,sum+2+bool(2==v[x][y]));
		if(v[x-1][y]&&!a[x-1][y]) dfs(x-1,y,v[x-1][y],sum+bool(vis!=v[x-1][y]));
		else if(!a[x-1][y]) dfs(x-1,y,1,sum+2+bool(1==v[x][y])),dfs(x-1,y,2,sum+2+bool(2==v[x][y]));
		if(v[x][y-1]&&!a[x][y-1]) dfs(x,y-1,v[x][y-1],sum+bool(vis!=v[x][y-1]));
		else if(!a[x][y-1]) dfs(x,y-1,1,sum+2+bool(1==v[x][y])),dfs(x,y-1,2,sum+2+bool(2==v[x][y]));
	}else{
		if(v[x][y+1]&&!a[x][y+1]) dfs(x,y+1,v[x][y+1],sum+bool(vis!=v[x][y+1]));
		if(v[x+1][y]&&!a[x+1][y]) dfs(x+1,y,v[x+1][y],sum+bool(vis!=v[x+1][y]));
		if(v[x-1][y]&&!a[x-1][y]) dfs(x-1,y,v[x-1][y],sum+bool(vis!=v[x-1][y]));
		if(v[x][y-1]&&!a[x][y-1]) dfs(x,y-1,v[x][y-1],sum+bool(vis!=v[x][y-1]));
	}
	a[x][y]=0;
//	cout<<endl;
	return;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=n;i++){
		int x,y,op;
		cin>>x>>y>>op;
		v[x][y]=op+1;
	}
	dfs(1,1,v[1][1],0);
	if(ans==INT_MAX) cout<<"-1";
	else cout<<ans;
	return 0;
}

