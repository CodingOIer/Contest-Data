#include<bits/stdc++.h>
using namespace std;
string s;
int ans;
bool f=1;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int len=s.length();
	for(int i=0;i<len;i++){
		int a=1;
		while(s[i]!='+'&&s[i]!='-'&&i<len){
			int b=0;
			while(s[i]>='0'&&s[i]<='9'&&i<len){
				b=b*10+(s[i]-'0');
				i++;
			}
			b%=10000;
			a*=b;
			a%=10000;
			if(s[i]=='*') i++;
		}
		if(f) ans+=a;
		else ans-=a;
		if(s[i]=='+') f=1;
		else f=0;
	}
	cout<<ans;
	return 0;
}

