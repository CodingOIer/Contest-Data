#include<bits/stdc++.h>
#define mod 998244353
using namespace std;
long long t,id;
long long v[1005][1005];
int main(){
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	cin>>t>>id;
	while(t--){
		long long n,m,a,b,c=0,f=0;
		cin>>n>>m>>a>>b;
		for(long long i=1;i<=n;i++){
			long long g=0;
			string s;
			cin>>s;
			for(long long j=m-1;j>=0;j--){
				if(s[j]=='0') g++;
				else g=0;
				v[i][j+1]=g;
			}
		}
		if(a){
			for(long long i=1;i<=m;i++){
				for(long long j=1;j<=n;j++){
					if(!v[j][i]) continue;
					for(long long o=j+1;o<=n;o++){
						if(!v[o][i]){
							j=o;
							break;	
						}
						if((v[o][i]-1)&&(v[j][i]-1)&&o-j>1){
							c+=(v[j][i]-1)*(v[o][i]-1);
							c%=mod;
						}
					}
				}
			}
		}
		if(b){
			for(long long i=1;i<=m;i++){
				for(long long j=1;j<=n;j++){
					if(!v[j][i]) continue;
					for(long long o=j+1;o<n;o++){
						if(!v[o][i]){
							j=o;
							break;	
						}
						if((v[o][i]-1)&&(v[j][i]-1)&&o-j>1){
							long long k=0;
							for(long long x=o+1;x<=n;x++){
								if(!v[x][i]) break;
								k++;
							}
							f+=(v[j][i]-1)*(v[o][i]-1)*k;
							f%=mod;
						}
					}
				}
			}
		}
		cout<<c<<" "<<f;
	}
	return 0;
}
