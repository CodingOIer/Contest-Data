#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int cnt[1005][1005];
int pre[1005][1005],por[1005][1005];//����ÿһ����ǰ׺��Ӷ� 
int main()
{
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int t,id;
	int n,m,ct,vt;
	scanf("%d%d",&t,&id);
	for(int l=1;l<=t;l++)
	{
		scanf("%d%d%d%d",&n,&m,&ct,&vt);
		char e;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				cin>>e,cnt[i][j]=e-'0';
		for(int i=n;i>=1;i--)
		{
			for(int j=m;j>=1;j--)
				if(cnt[i][j]==0)
					pre[i][j]=pre[i][j+1]+1,por[i][j]=por[i+1][j]+1;
		}
		if(ct==0)cout<<0<<" ";
		else{
			long long ans=0;
			for(int i=1;i<=n;i++)
				for(int j=1;i<=n;i++)
				{
					if(por[i][j]>1&&pre[i][j]>1&&cnt[i][j]==0)
					{
						long long as=0;
						for(int k=i+2;k<=i+por[i][j];k++)
							if(pre[k][j]>1)as=(as+pre[k][i]-1)%mod;
						as=as*(pre[i][j]-1);
						ans=(ans+as)%mod;
					}
				}
			cout<<ans<<" ";
		}
		if(vt==0)cout<<0;
		else{
			long long ans=0;
			for(int i=1;i<=n;i++)
				for(int j=1;i<=n;i++)
				{
					if(por[i][j]>1&&pre[i][j]>1&&cnt[i][j]==0)
					{
						long long as=0;
						for(int k=i+2;k<=i+por[i][j];k++)
							if(pre[k][j]>1&&por[k][j]>1)as=(as+pre[k][i]-1)%mod;
						as=as*(pre[i][j]-1);
						ans=(ans+as)%mod;
					}
				}
			cout<<ans<<" ";
		}
		memset(por,0,sizeof(por));
		memset(pre,0,sizeof(pre)); 
	}
	return 0;
 }  
