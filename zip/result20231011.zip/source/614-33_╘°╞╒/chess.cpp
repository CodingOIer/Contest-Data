#include<bits/stdc++.h>
using namespace std;
int f[1005][1005];
int dp[3][1005][1005];
const int _fine=100000007;
int mix(int w,int a,int b,int c,int d){
	return min(a,min(b,min(c,min(w,d))));
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		f[a][b]=c+1;
	}
	memset(dp,_fine,sizeof(dp));
	dp[f[1][1]][1][1]=0;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			if(f[i][j]==1)
				dp[1][i][j]=min(mix(dp[1][i][j],dp[1][i][j-1],dp[1][i][j+1],dp[1][i-1][j],dp[1][i+1][j]),mix(dp[2][i][j],dp[2][i][j-1],dp[2][i][j+1],dp[2][i-1][j],dp[2][i+1][j])+1);
			if(f[i][j]==2)
				dp[2][i][j]=min(mix(dp[1][i][j],dp[1][i][j-1],dp[1][i][j+1],dp[1][i-1][j],dp[1][i+1][j])+1,mix(dp[2][i][j],dp[2][i][j-1],dp[2][i][j+1],dp[2][i-1][j],dp[2][i+1][j]));
			if(f[i][j]==0)
			{
				dp[1][i][j]=mix(dp[1][i][j],f[i][j-1]==0?_fine:dp[1][i][j-1],f[i][j+1]==0?_fine:dp[1][i][j+1],f[i-1][j]==0?_fine:dp[1][i-1][j],f[i+1][j]==0?_fine:dp[1][i+1][j])+2;
				dp[2][i][j]=mix(dp[2][i][j],f[i][j-1]==0?_fine:dp[2][i][j-1],f[i][j+1]==0?_fine:dp[2][i][j+1],f[i-1][j]==0?_fine:dp[2][i-1][j],f[i+1][j]==0?_fine:dp[2][i+1][j])+2;
			}
		}
	if(_fine<=min(dp[1][n][n],dp[2][n][n]))cout<<-1;
	else cout<<min(dp[1][n][n],dp[2][n][n]);
	return 0;
 } 
