#include<bits/stdc++.h>
using namespace std;
long long w[100005];
const int mod=10000;
const long long modl=100000000000;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	int qac=0,cnt=1;
	int f=0;
	int n=s.size();
	for(int i=0;i<n;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			qac++;
			while(s[i]>='0'&&s[i]<='9')
			{
				w[qac]=w[qac]*10+s[i]-'0';
				i++;
			}
			if(cnt==-1)w[qac]=-w[qac];
			if(f==1)w[qac]=(w[qac-1]*w[qac])%modl,w[qac-1]=f=0;
		}
		if(s[i]=='*')
		{
			f=1;
			cnt=1;
		}
		if(s[i]=='-')
			cnt=-1;
		if(s[i]=='+')
			cnt=1;
	}
	long long ans=0;
	for(int i=1;i<=qac;i++)
		ans=(ans+w[i])%mod;
	cout<<ans%mod;
	return 0;
 } 
