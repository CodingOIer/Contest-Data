#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,x,y;
	scanf("%d%d%d",&n,&x,&y);
	int i=1,j=0,fon=1,fop=0;
	int nx=n,mx=n;
	int qac=n*n;
	int cnt=0;
	while(cnt<=qac)
	{
		if(i==x&&j==y)
		{
			cout<<cnt;
			return 0;
		}
		//cout<<"FON:"<<fon<<"FOP:"<<fop<<"\n";
		if(fop==0)
		{
			int r=0;
			while(r<mx&&cnt<=qac)
			{
				r++;cnt++;j+=fon;
				//cout<<"CNT:"<<cnt<<" "<<i<<" "<<j<<"\n";
				if(i==x&&j==y)
				{
					cout<<cnt;
					return 0;
				}
			}
			nx--;
			fop=fon;
			fon=0;
		}
		//cout<<"FON:"<<fon<<"FOP:"<<fop<<"\n";
		if(fon==0)
		{
			int r=0;
			while(r<nx&&cnt<=qac)
			{
				r++;cnt++;i+=fop;
				//cout<<"CNT:"<<cnt<<" "<<i<<" "<<j<<"\n";
				if(i==x&&j==y)
				{
					cout<<cnt;
					return 0;
				}
			}
			mx--;
			fon=-fop;
			fop=0;
		}
	}
	return 0;
 } 
