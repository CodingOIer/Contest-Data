#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(ll i=(a); i>=(b); --i)
#define tell(ans) out(ans),printf("\n");
#define say(ans) out(ans),printf(" ");
#define pb push_back
#define mid (l+r)>>1
//
//
//
using namespace std;
inline ll read() {
	ll f=0,t=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}
inline void out(ll x) {
	if(x<0) putchar('-');
	if(x>9) out(x/10);
	putchar('0'+x%10);
}
ll ans(ll x,ll y,ll l,ll r,ll op) {
	if(x==l) return op+(y-l+1);
	if(y==r) return op+(r-1)+(x-l+1);
	if(x==r) return op+(r-1)*2+(r-y+1);
	if(y==l) return op+(r-1)*3+(r-x+1);
	return ans(x,y,l+1,r-1,op+(r-1)*4);
}
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ll n=read(),x=read(),y=read();
	cout<<ans(x,y,1,n,0);
	return 0;
}

