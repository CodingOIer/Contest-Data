#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(ll i=(a); i>=(b); --i)
#define tell(ans) out(ans),printf("\n");
#define say(ans) out(ans),printf(" ");
#define pb push_back
#define mid (l+r)>>1
//
//
//
using namespace std;
inline ll read() {
	ll f=0,t=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}
inline void out(ll x) {
	if(x<0) putchar('-');
	if(x>9) out(x/10);
	putchar('0'+x%10);
}
ll mp[1005][1005];
ll f[1005][1005];
bool vis[1005][1005];
ll ans=1e9;
int n,m;
void dfs(int x,int y,int col,ll sum,bool magi) {
	if(x==n && y==n) {
		ans=min(ans,sum);
		return;
	}
	if(sum>=ans) return;
	if(y+1<=n && !vis[x][y+1])  {
		vis[x][y+1]=1;
		if(!magi || mp[x][y+1]!=-1) dfs(x,y+1,((mp[x][y+1]==-1)?col:mp[x][y+1]),sum+((mp[x][y+1]==col)?0:1)+((mp[x][y+1]==-1)?1:0),!magi);
		vis[x][y+1]=0;
	}
	if(x+1<=n && !vis[x+1][y])  {
		vis[x+1][y]=1;
		if(!magi || mp[x+1][y]!=-1) dfs(x+1,y,((mp[x+1][y]==-1)?col:mp[x+1][y]),sum+((mp[x+1][y]==col)?0:1)+((mp[x+1][y]==-1)?1:0),!magi);
		vis[x+1][y]=0;
	}
	if(y-1>=1 && !vis[x][y-1])  {
		vis[x][y-1]=1;
		if(!magi || mp[x][y-1]!=-1) dfs(x,y-1,((mp[x][y-1]==-1)?col:mp[x][y-1]),sum+((mp[x][y-1]==col)?0:1)+((mp[x][y-1]==-1)?1:0),!magi);
		vis[x][y-1]=0;
	}
	if(x-1>=1 && !vis[x-1][y])  {
		vis[x-1][y]=1;
		if(!magi || mp[x-1][y]!=-1) dfs(x-1,y,((mp[x-1][y]==-1)?col:mp[x-1][y]),sum+((mp[x-1][y]==col)?0:1)+((mp[x-1][y]==-1)?1:0),!magi);
		vis[x-1][y]=0;
	}
}
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read();
	FOR(i,1,n) FOR(j,1,n) mp[i][j]=-1;
	FOR(i,1,m) {
		int x=read(),y=read(),c=read();
		mp[x][y]=c;
	}
	dfs(1,1,mp[1][1],0,0);
	if(ans==1e9) cout<<-1;
	else cout<<ans;
	return 0;
}

