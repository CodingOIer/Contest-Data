#include<bits/stdc++.h>
#define ll long long
#define FOR(i,a,b) for(ll i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(ll i=(a); i>=(b); --i)
#define tell(ans) out(ans),printf("\n");
#define say(ans) out(ans),printf(" ");
#define pb push_back
#define mid (l+r)>>1
//
//
//
using namespace std;
inline ll read() {
	ll f=0,t=0;
	char c=getchar();
	while(!isdigit(c)) t|=(c=='-'),c=getchar();
	while(isdigit(c)) f=(f<<3)+(f<<1)+c-48,c=getchar();
	return t?-f:f;
}
inline void out(ll x) {
	if(x<0) putchar('-');
	if(x>9) out(x/10);
	putchar('0'+x%10);
}
char a[1005][1005];
int p[1005][1005];
int t[1005][1005];
const int mod=998244353;
int main() {
	freopen("plant.in","r",stdin);
	freopen("plant.out","w",stdout);
	int T=read(),id=read();
	while(T--) {
		ll n=read(),m=read(),c=read(),f=read();
		FOR(i,1,n) FOR(j,1,m) cin>>a[i][j];
		FOR(i,1,n) FOR(j,1,m) p[i][j]=0;
		FOR(i,1,n) {
			int s=m+1;
			ROF(j,m,1) {
				if(a[i][j]=='1') s=j;
				p[i][j]=s-j-1;
			}
		}
		FOR(i,1,m) {
			int s=n+1;
			ROF(j,n,1) {
				if(a[j][i]=='1') s=j;
				t[j][i]=s-j-1;
			}
		}
		__int128 ansc=0;
		FOR(i,1,m) {
			int op=1;
			__int128 k=0,have=0;
			FOR(j,1,n) {
				if(a[j][i]=='1')  op=j+1,have=0,k=0;
				if(j-op>=2) {
					have+=p[op+k][i];
					k++;
					ansc+=p[j][i]*have;
				}
			}
		}
		__int128 ansf=0;
		FOR(i,1,m) {
			int op=1;
			ll k=0,have=0;
			FOR(j,1,n) {
				if(a[j][i]=='1')  op=j+1,have=0,k=0;
				if(j-op>=2) {
					have+=p[op+k][i];
					k++;
					ansf+=p[j][i]*have*t[j][i];
				}
			}
		}
		out((ansc*c)%mod);
		cout<<" ";
		out((ansf*f)%mod);
		cout<<endl;
	}
	return 0;
}
/*
1 0
16 12 1 1
000000000001
011111111111
000000000011
011111111111
010011111111
010111100011
010011101111
011111100011
111111111111
000011111111
011111111111
000000111111
011111000111
011111011111
011111000111
011111011111

1 0
6 6 1 1
000010
011000
000110
010000
011000
000000
*/

