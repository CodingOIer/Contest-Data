#include<bits/stdc++.h>
using namespace std;
long long jz[320][312];
int n,h,l,hh=1,ll=0,fx=1;
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>h>>l;
	long long nf=n*n;
	for(int i=1; i<=nf; i++) {
		if(fx==1) {
			ll++;
			if(jz[hh][ll]>0||ll>n||hh>n) {
				fx++;
				ll--;
			} else {
				jz[hh][ll]=i;
			}
		}
		if(fx==2) {
			hh++;
			if(jz[hh][ll]>0||hh>n||ll>n) {
				fx++;
				hh--;
			} else {
				jz[hh][ll]=i;
			}
		}
		if(fx==3) {
			ll--;
			if(jz[hh][ll]>0||ll<=0) {
				fx++;
				ll++;
			} else {
				jz[hh][ll]=i;
			}
		}
		if(fx==4) {
			hh--;
			if(jz[hh][ll]>0||hh<=0) {
				fx=1;
				hh++;
				ll++;
				jz[hh][ll]=i;
			} else {
				jz[hh][ll]=i;
			}
		}
	}
	/*for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)cout<<jz[i][j]<<" ";
		cout<<endl;
	}*/
	cout<<jz[h][l];
	return 0;
}
//���� ���� ����~~
//happy happy happy~~ 
