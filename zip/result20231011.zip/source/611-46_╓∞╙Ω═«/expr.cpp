#include<bits/stdc++.h>
using namespace std;
long long a,aa,ans=0,sumans=0,jfjs=0,cfjs=0;
char b,bb;
long long sum[100005];
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	bb='+';
	aa=a;
	while(cin>>b) {
		if((b!='+'&&b!='*'&&b!='-')||b==' ') {
			break;
		}
		scanf("%lld",&a);
		if(b=='+'||b=='-') {
			if(bb!='*') {
				if(jfjs==0)
					ans++;
				if(bb=='+') {
					sum[ans]=(sum[ans]+aa)%10000;
				} else {
					sum[ans]=(sum[ans]-aa)%10000;
				}
			}
			jfjs++;
			cfjs=0;
		} else {
			jfjs=0;
			if(cfjs==0) {
				ans++;
				if(bb=='-') {
					sum[ans]=-1;
				} else {
					sum[ans]=1;
				}
				sum[ans]=(sum[ans]*aa*a)%10000;
			} else {
				sum[ans]=(sum[ans]*a)%10000;
			}
			cfjs++;
		}
		aa=a;
		bb=b;
	}
	if(bb=='+') {
		sum[ans]=(sum[ans]+a)%10000;
	}
	if(bb=='-') {
		sum[ans]=(sum[ans]-a)%10000;
	}
	for(int i=1; i<=ans; i++) {
		sumans=(sumans+sum[i])%10000;
	}
	cout<<sumans;
	return 0;
}
//ԭ�� ԭ�� ԭ��~~
//happy happy happy~~
//(but��Ȼ���˼��� ���ܻᱬ0)
