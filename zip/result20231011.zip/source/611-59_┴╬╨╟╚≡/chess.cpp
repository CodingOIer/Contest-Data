#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,a[1005][1005],color,x,y,f[4][2]={0,1,1,0,-1,0,0,-1},vis[1005][1005],jl,f1;
void dfs(int x,int y,int sum){
	if(x==n&&y==n){
		cout<<sum;
		return;
	}
	for(int i=0;i<4;i++){
		int xx=x+f[i][0],yy=y+f[i][1];
		if(xx>=1&&xx<=n&&yy>=1&&yy<=n&&!vis[xx][yy]&&a[xx][yy]){
			if(jl!=a[xx][yy]) sum++;
			jl=a[xx][yy],vis[xx][yy]=1;
			dfs(xx,yy,sum);
			vis[xx][yy]=0;
		}
		else{
			if(f1) a[xx][yy]=0,f1=0;
			a[xx][yy]=jl,sum+=2,f1=1,vis[xx][yy]=1;
			dfs(xx,yy,sum);
			vis[xx][yy]=0;
		}
	}
	cout<<-1;
}
int main(){
    freopen("chess.in","r",stdin);
    freopen("chess.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>x>>y>>color;
		a[x][y]=color+1;
	}
//	dfs(1,1,0);
	cout<<-1;
	return 0;
}
