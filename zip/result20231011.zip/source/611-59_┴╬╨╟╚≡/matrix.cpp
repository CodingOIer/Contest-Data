#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,x,y,cs=1,csz=1;
int main(){
    freopen("matrix.in","r",stdin);
    freopen("matrix.out","w",stdout);
	cin>>n>>x>>y;
	if(n==1){
		cout<<1;
		return 0;
	}
	if(n==2){
		if(x==1){
			if(y==1) cout<<1;
			else cout<<2;
		}
		else{
			if(y==1) cout<<4;
			else cout<<3;
		}
		return 0;
	}
	for(int i=1;i<=n/2;i++){
		csz=cs;
		if(x==i){
			for(int j=i;j<=i+n-1-(i-1)*2-1;j++,csz++){
				if(y==j){
					cout<<csz;
					return 0;
				}
			}
		}
		if(x==n-i+1){
			csz+=(n-1-(i-1)*2)*3-1;
			for(int j=i+1;j<=i+n-1-(i-1)*2;j++,csz--){
				if(y==j){
					cout<<csz;
					return 0;
				}
			}
		}
		csz=cs;
		if(y==i){
			csz+=(n-1-(i-1)*2)*4-1;
			for(int j=i+1;j<=i+n-1-(i-1)*2;j++,csz--){
				if(x==j){
					cout<<csz;
					return 0;
				}
			}
		}
		if(y==n-i+1){
			csz+=(n-1-(i-1)*2);
			for(int j=i;j<=i+n-1-(i-1)*2-1;j++,csz++){
				if(x==j){
					cout<<csz;
					return 0;
				}
			}
		}
		cs+=(n-1-(i-1)*2)*4;
	}
	cout<<n*n;
	return 0;
}
