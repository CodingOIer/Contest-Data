#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll g,f,cnt[100005],g1=1;
__int128 b[100005],sum;
string a;
int main(){
    freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
	cin>>a;
	ll len=a.size();
	for(int i=0;i<len;i++){
		if(a[i]>='0'&&a[i]<='9') g++;
		while(a[i]>='0'&&a[i]<='9') b[g]*=10,b[g]+=int(a[i]-48),i++;
		if(f) b[g-1]*=b[g],b[g]=0,g--,f=0;
		if(a[i]=='*') f=1;
		else if(a[i]=='+') cnt[g1]=0,g1++;
		else if(a[i]=='-') cnt[g1]=1,g1++;
	}
	sum=b[1];
	for(int i=2;i<=g;i++){
		if(!cnt[i-1]) sum+=b[i];
		else sum-=b[i];
	}
	sum%=10000;
	cout<<int(sum);
	return 0;
}
