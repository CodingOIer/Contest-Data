#include <bits/stdc++.h>

#define rep(i, a, b) for(int i = (a), i##end = (b); i <= i##end; i++)
#define _rep(i, a, b) for(int i = (a), i##end = (b); i >= i##end; i--)

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;

int read() {
	int x = 0, f = 1; char c = getchar();
	while (!isdigit(c)) {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	return x * f;
}

template <typename _Tp>
void print(_Tp x) {
	if (x < 0) x = (~x + 1), putchar('-');
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

const int MAXN = 1e3 + 5;
int n, m, a[MAXN];
int w[MAXN][MAXN];
vector <int> G[MAXN];

void dfs(int u, int fa, int val, int o) {
	if (!val) {
		w[u][u] = u;
		for (auto v : G[u]) {
			dfs(v, u, v, o);
		}
	}
	else {
		w[o][u] = val;
		for (auto v : G[u]) {
			if (v == fa) continue;
			dfs(v, u, val, o);
		}
	}
}

int main() {
	freopen("sunset.in", "r", stdin);
	freopen("sunset.out", "w", stdout);
	n = read(), m = read();
	for (int i = 2, v; i <= n; i++) {
		v = read();
		G[v].emplace_back(i);
		G[i].emplace_back(v);
	}
	rep (i, 1, n) a[i] = read();
	rep (i, 1, n) dfs(i, i, 0, i);
	for (int i = 1, x, l, r; i <= m; i++) {
		x = read(), l = read(), r = read();
		rep (i, l, r) x = w[x][a[i]];
		print(x), putchar(10);
	}
	return 0;
}
