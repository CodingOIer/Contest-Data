#include <bits/stdc++.h>

#define rep(i, a, b) for(int i = (a), i##end = (b); i <= i##end; i++)
#define _rep(i, a, b) for(int i = (a), i##end = (b); i >= i##end; i--)

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;

int read() {
	int x = 0, f = 1; char c = getchar();
	while (!isdigit(c)) {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c)) {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	return x * f;
}

template <typename _Tp>
void print(_Tp x) {
	if (x < 0) x = (~x + 1), putchar('-');
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}

int n, m;
int a[15][15];
string str;

int main() {
	freopen("mat.in", "r", stdin);
	freopen("mat.out", "w", stdout);
	cin >> n >> m;
	rep (i, 1, n) rep (j, 1, n) cin >> a[i][j];
	cin >> str;
	for (auto c : str) {
		if (c == 'R') {
			rep (i, 1, n) {
				int key = a[i][n];
				_rep (j, n, 2) a[i][j] = a[i][j - 1];
				a[i][1] = key;
			}
		}
		if (c == 'L') {
			rep (i, 1, n) {
				int key = a[i][1];
				rep (j, 1, n - 1) a[i][j] = a[i][j + 1];
				a[i][n] = key;
			}
		}
		if (c == 'D') {
			rep (i, 1, n) {
				int key = a[n][i];
				_rep (j, n, 2) a[j][i] = a[j - 1][i];
				a[1][i] = key;
			}
		}
		if (c == 'U') {
			rep (i, 1, n) {
				int key = a[1][i];
				rep (j, 1, n - 1) a[j][i] = a[j + 1][i];
				a[n][i] = key;
			}
		}
		if (c == 'I') {
			int s[15];
			rep (i, 1, n) {
				rep (j, 1, n) s[a[i][j]] = j;
				rep (j, 1, n) a[i][j] = s[j];
			}
		}
		if (c == 'C') {
			int s[15];
			rep (i, 1, n) {
				rep (j, 1, n) s[a[j][i]] = j;
				rep (j, 1, n) a[j][i] = s[j];
			}
		}
	}
	rep (i, 1, n) {
		rep (j, 1, n) cout << a[i][j] << " ";
		cout << "\n";
	}
	return 0;
}
