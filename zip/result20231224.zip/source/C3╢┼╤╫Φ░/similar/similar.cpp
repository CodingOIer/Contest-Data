#include<bits/stdc++.h>
namespace IO{
    char buff[1<<23],*p1=buff,*p2=buff;
    char getch(){
        return p1==p2&&(p2=((p1=buff)+fread(buff,1,1<<21,stdin)),p1==p2)?EOF:*p1++;
    }
    template<typename T>
    void read(T &x){
        char ch=getch();int fl=1;x=0;
        while(ch>'9'||ch<'0'){if(ch=='-')fl=-1;ch=getch();}
        while(ch<='9'&&ch>='0'){x=x*10+ch-48;ch=getch();}
        x*=fl;
    }
    template<typename T,typename ...Args>
    void read(T &x,Args& ...args){
        read(x);read(args...);
    }
    char obuf[1<<23],*p3=obuf;
    void putch(char ch){
        if(p3-obuf<(1<<21))*p3++=ch;
        else fwrite(obuf,p3-obuf,1,stdout),p3=obuf,*p3++=ch;
    }
    char ch[100];
    template<typename T>
    void write(T x){
        if(!x)return putch('0');
        if(x<0)putch('-'),x*=-1;
        int top=0;
        while(x)ch[++top]=x%10+48,x/=10;
        while(top)putch(ch[top]),top--;
    }
    template<typename T,typename ...Args>
    void write(T x,Args ...args){
        write(x);write(args...);
    }
    void flush(){fwrite(obuf,p3-obuf,1,stdout);}
}
using namespace IO;
using namespace std;
const int MAXN=1e5+5,d=998244353,mod=1e9+7,inf=1e5;
int a[MAXN],rt[MAXN],pw[MAXN];
struct node{
    int l,r,v,h;
}sum[MAXN*800];
int ksm(int x,int y) {
    int ans=1;
    while(y) {
        if(y&1) ans=(1ll*ans*x)%mod;
        x=(1ll*x*x)%mod;
        y>>=1;
    }
    return ans;
}
inline int add(int x,int y) {
    if(x+y>=mod) return x+y-mod;
    return x+y;
}
inline int inc(int x,int y) {
    if(x-y<0) return x-y+mod;
    return x-y;
}
#define mid ((l+r)>>1)
int cnt=0;
int build(int l,int r) {
	int x=++cnt;
	sum[x].v=0;
    sum[x].h=0;
	if(l<r) {
		sum[x].l=build(l,mid);
		sum[x].r=build(mid+1,r);
	}
	return x;
}
int update(int x,int l,int r,int k) {
	int t=++cnt;
	sum[t].l=sum[x].l;
	sum[t].r=sum[x].r;
	sum[t].v=sum[x].v+1;
    sum[t].h=add(sum[t].h,(sum[x].h+1ll*ksm(d,r-k)));
	if(l<r) {
		if(k<=mid) sum[t].l=update(sum[x].l,l,mid,k);
		else sum[t].r=update(sum[x].r,mid+1,r,k);
	}   
	return t;
}
pair<int,int> query(int u,int v,int l,int r,int k) {
    if(!(l^r)) return {k,k>0};
    int t=sum[sum[u].l].v-sum[sum[v].l].v;
    int w=inc(sum[sum[u].l].h,sum[sum[v].l].h);
    if(t>=k) return query(sum[u].l,sum[v].l,l,mid,k);
    else {
        pair<int,int> res=query(sum[u].r,sum[v].r,mid+1,r,k-t);
        return {add(res.first,1ll*w*pw[res.second]%mod),res.second+(mid-l+1)}; 
    }
}
pair<int,int> find(int u,int v,int l,int r,int k) {
    if(!(l^r)) return {k,k>0};
    int t=sum[sum[u].r].v-sum[sum[v].r].v;
    int w=inc(sum[sum[u].r].h,sum[sum[v].r].h);
    if(t>=k) return find(sum[u].r,sum[v].r,mid+1,r,k);
    else {
        pair<int,int> res=find(sum[u].l,sum[v].l,l,mid,k-t);
        return {add(w,1ll*res.first*pw[r-mid]%mod),res.second+(r-mid)}; 
    }
}
//二分rnk，使得其第一个rnk不同，接着，判断后面的是否是相同的
int find(int lx,int rx,int ly,int ry) {
    int l=1,r=rx-lx+1,len=rx-lx+1;
    while(l<=r) {
        pair<int,int> x=query(rt[rx],rt[lx-1],1,inf,mid);
        pair<int,int> y=query(rt[ry],rt[ly-1],1,inf,mid);
        if(x==y) l=mid+1;
        else r=mid-1;
    }
    pair<int,int> x=find(rt[rx],rt[lx-1],1,inf,len-l);
    pair<int,int> y=find(rt[ry],rt[ly-1],1,inf,len-l);
    if(x==y) return 1;
    return 0;
}
signed main() {
    freopen("similar.in","r",stdin);
    freopen("similar.out","w",stdout);
    int n,q;
    read(n,q);
    rt[0]=build(1,inf);
    for(int i=1;i<=n;i++) {
        read(a[i]);
        rt[i]=update(rt[i-1],1,inf,a[i]);
    }
    for(int i=0;i<=inf;i++) pw[i]=ksm(d,i);
    while(q--) {
        int lx,rx,ly,ry;
        read(lx,rx,ly,ry);
        if(find(lx,rx,ly,ry)) {
            putch('Y'),putch('E'),putch('S'),putch('\n');
        } else putch('N'),putch('O'),putch('\n');
    }
    flush();
    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}