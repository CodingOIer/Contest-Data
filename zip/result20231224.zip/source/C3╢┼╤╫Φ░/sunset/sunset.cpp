#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+5;
vector<int> e[MAXN];
int fa[MAXN],Q[MAXN],dfn[MAXN],siz[MAXN],cnt=0;
void dfs(int x) {
    dfn[x]=++cnt;
    siz[x]=1;
    for(auto i:e[x]) {
        if(i==fa[x]) continue;
        dfs(i);
        siz[x]+=siz[i];
    }
}
int solve(int x,int to) {
    for(auto i:e[x]) {
        if(i==fa[x]) continue;
        if(dfn[i]<=dfn[to] && dfn[to]<=dfn[i]+siz[i]-1) {
            return i;
        }
    }
    if(to==x) return x;
    return fa[x];
}
int main() {
    freopen("sunset.in","r",stdin);
    freopen("sunset.out","w",stdout);
    int n,q;
    scanf("%d %d",&n,&q);
    for(int i=2;i<=n;i++) {
        int x;
        scanf("%d",&x);
        fa[i]=x;
        e[x].push_back(i);
        e[i].push_back(x);
    }
    for(int i=1;i<=n;i++) scanf("%d",&Q[i]);
    dfs(1);
    while(q--) {
        int x,l,r;
        scanf("%d %d %d",&x,&l,&r);
        for(int i=l;i<=r;i++) x=solve(x,Q[i]);
        printf("%d\n",x);
    }
    return 0;
}