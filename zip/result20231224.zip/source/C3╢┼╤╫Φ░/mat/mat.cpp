#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],b[1005][1005];
int main() {
    freopen("mat.in","r",stdin);
    freopen("mat.out","w",stdout);
    int n,q;
    scanf("%d %d",&n,&q);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=n;j++) {
            scanf("%d",&a[i][j]);
        }
    }
    if(n<=10) { 
        string s;
        cin>>s;
        s=" "+s;
        for(int ljh=1;ljh<=q;ljh++) {
            if(s[ljh]=='L') {
                for(int i=1;i<=n;i++) {
                    int to=(i-1);
                    if(to==0) to=n;
                    for(int j=1;j<=n;j++) b[j][to]=a[j][i];
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        a[i][j]=b[i][j];
                    }
                }
            } else if(s[ljh]=='R') {
                for(int i=1;i<=n;i++) {
                    int to=(i+1);
                    if(to==n+1) to=1;
                    for(int j=1;j<=n;j++) b[j][to]=a[j][i];
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        a[i][j]=b[i][j];
                    }
                }
            } else if(s[ljh]=='U'){
                for(int i=1;i<=n;i++) {
                    int to=(i-1);
                    if(to==0) to=n;
                    for(int j=1;j<=n;j++) b[to][j]=a[i][j];
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        a[i][j]=b[i][j];
                    }
                }
            } else if(s[ljh]=='D'){
                for(int i=1;i<=n;i++) {
                    int to=(i+1);
                    if(to==n+1) to=1;
                    for(int j=1;j<=n;j++) b[to][j]=a[i][j];
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) { 
                        a[i][j]=b[i][j];
                    }
                }
            } else if(s[ljh]=='I') {
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        b[i][a[i][j]]=j;
                    }
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        a[i][j]=b[i][j];
                    }
                }
            } else {
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        b[a[j][i]][i]=j;
                    }
                }
                for(int i=1;i<=n;i++) {
                    for(int j=1;j<=n;j++) {
                        a[i][j]=b[i][j];
                    }
                }
            }
        }
        for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) {
                printf("%d ",a[i][j]);
            }
            printf("\n");
        }
    } else {
        int l=1,r=1;
        string s;
        cin>>s;
        s=" "+s;
        for(int k=1;k<=q;k++) {
            if(s[k]=='L') {
                l++;
                if(l==n+1) l=1;
            } else if(s[k]=='R') {
                l--;
                if(l==0) l=n;
            } else if(s[k]=='U') {
                r++;
                if(r==n+1) r=1; 
            } else {
                r--;
                if(r==0) r=n;
            }

        }
        for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) {
                int x=i+r-1,y=j+l-1;
                if(x>n) x-=n;
                if(y>n) y-=n;
                printf("%d ",a[x][y]);
            }
            printf("\n");
        }
    }

    return 0;
}
/*
6
1 3 6 2 5 4

1 4 2 6 5 3

6 3 1 5 4 2
*/