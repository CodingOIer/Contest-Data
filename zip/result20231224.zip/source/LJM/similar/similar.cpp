#include<bits/stdc++.h>
#define N 200006
#define base 998244353
#define int long long
using namespace std;
int n, Q, cnt;
int a[N], rt[N], h[N];
struct node{
    int ls, rs, v, Hash;
}t[N * 20];
void update(int lsto, int &o, int L, int R, int x) {
    o = ++cnt;
    t[o] = t[lsto];
    if(L == R) {
        t[o].v++;
        t[o].Hash++;
        return;
    }
    int mid = (L + R) / 2;
    if(x <= mid) update(t[lsto].ls, t[o].ls, L, mid, x);
    else update(t[lsto].rs, t[o].rs, mid + 1, R, x);
    t[o].v = t[t[o].ls].v + t[t[o].rs].v;
    t[o].Hash = t[t[o].ls].Hash * h[R - (mid + 1) + 1] + t[t[o].rs].Hash;
}
bool OutofRange(int L, int R, int l, int r) {
    return R < l || r < L;
}
int query(int lsto, int o, int l, int r, int L, int R) {
    //if(R < l || r < L) return 0;
    if(l <= L && R <= r) return t[o].Hash - t[lsto].Hash;
    int mid = (L + R) / 2;
    int L1 = L, R1 = mid, L2 = mid + 1, R2 = R;
    if(OutofRange(L1, R1, l, r) && OutofRange(L2, R2, l, r)) return 0;
    else if(OutofRange(L1, R1, l, r)) return query(t[lsto].rs, t[o].rs, l, r, mid + 1, R);
    else if(OutofRange(L2, R2, l, r)) return query(t[lsto].ls, t[o].ls, l, r, L, mid);
    else return query(t[lsto].ls, t[o].ls, l, r, L, mid) * h[R2 - L2 + 1] + query(t[lsto].rs, t[o].rs, l, r, mid + 1, R);
}
signed main() {
    freopen("similar.in", "r", stdin);
    freopen("similar.out", "w", stdout);
    h[0] = 1;
    for(int i = 1; i <= 100000; i++) h[i] = h[i - 1] * base;
    scanf("%lld %lld", &n, &Q);
    for(int i = 1; i <= n; i++) {
        scanf("%lld", &a[i]);
        update(rt[i - 1], rt[i], 1, 100000, a[i]);
    }
    //cout << query(rt[0], rt[6], 1, 4, 1, 100000) << endl;
    while(Q--) {
        int l1, r1, l2, r2;
        scanf("%lld %lld %lld %lld", &l1, &r1, &l2, &r2);
        int L = 1, R = 100000, mid, Get1 = 0, Get2; //Get1表示最后一个相同前缀哈希值的位置
        while(L <= R) {
            mid = (L + R) / 2;
            if(query(rt[l1 - 1], rt[r1], 1, mid, 1, 100000) == query(rt[l2 - 1], rt[r2], 1, mid, 1, 100000)) {
                Get1 = mid;
                L = mid + 1;
            }
            else R = mid - 1;
        }
        L = 1, R = 100000, Get2 = 100001; //Get2表示第一个相同后缀哈希值的位置
        while(L <= R) {
            mid = (L + R) / 2;
            if(query(rt[l1 - 1], rt[r1], mid, 100000, 1, 100000) == query(rt[l2 - 1], rt[r2], mid, 100000, 1, 100000)) {
                Get2 = mid;
                R = mid - 1;
            }
            else L = mid + 1;
        }
        if(Get1 == 100000) {
            printf("YES\n");
            continue;
        }
        Get1++; Get2--;
        if(Get2 - Get1 + 1 == 2) {
            printf("YES\n");
            continue;
        }
        Get1++, Get2--;
        if(query(rt[l1 - 1], rt[r1], Get1, Get2, 1, 100000) == 0) {
            printf("YES\n");
        } 
        else printf("NO\n");
        
    }
    return 0;
}
/*
6 3
1 3 4 2 3 4
1 3 4 6
1 2 5 6
3 5 2 4
*/