#include<bits/stdc++.h>
#define int long long
#define N 2010
using namespace std;
int n, Q;
int a[N][N], b[N][N];
char opt[100005];
signed main() {
    freopen("mat.in", "r", stdin);
    freopen("mat.out", "w", stdout);
    scanf("%lld %lld", &n, &Q);
    for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++) scanf("%lld", &a[i][j]);
    scanf("%s", opt + 1);
    if(n > 10) {
        int nowx = 1, nowy = 1;
        for(int i = 1; i <= Q; i++) {
            if(opt[i] == 'L') {
                nowy++;
                if(nowy == n + 1) nowy = 1;
            }
            else if(opt[i] == 'R') {
                nowy--;
                if(nowy == 0) nowy = n;
            }
            else if(opt[i] == 'U') {
                nowx++;
                if(nowx == n + 1) nowx = 1;
            }
            else {
                nowx--;
                if(nowx == 0) nowx = n;
            }
        }
        for(int i = 1; i <= 2 * n; i++) 
        for(int j = 1; j <= 2 * n; j++) {
            if(i <= n && j <= n) continue;
            if(i > n && j > n) a[i][j] = a[i - n][j - n];
            else if(i > n) a[i][j] = a[i - n][j];
            else a[i][j] = a[i][j - n];
        }
        for(int i = nowx; i <= nowx + n - 1; i++) {
            for(int j = nowy; j <= nowy + n - 1; j++) printf("%lld ", a[i][j]);
            printf("\n");
        }
        return 0;
    }
    for(int i = 1; i <= Q; i++) {
        for(int x = 1; x <= n; x++)
        for(int y = 1; y <= n; y++) b[x][y] = a[x][y];
        if(opt[i] == 'R') {
            for(int x = 1; x <= n; x++)
            for(int y = 1; y <= n; y++) a[x][y % n + 1] = b[x][y];
        }
        else if(opt[i] == 'L') {
            for(int x = 1; x <= n; x++)
            for(int y = 1; y <= n; y++) a[x][y] = b[x][y % n + 1];
        }
        else if(opt[i] == 'D') {
            for(int x = 1; x <= n; x++)
            for(int y = 1; y <= n; y++) a[x % n + 1][y] = b[x][y];
        }
        else if(opt[i] == 'U') {
            for(int x = 1; x <= n; x++)
            for(int y = 1; y <= n; y++) a[x][y] = b[x % n + 1][y];
        }
        else if(opt[i] == 'I') {
            for(int x = 1; x <= n; x++)
            for(int y = 1; y <= n; y++) a[x][b[x][y]] = y;
        }
        else {
            for(int y = 1; y <= n; y++)
            for(int x = 1; x <= n; x++) a[b[x][y]][y] = x;
        }
    }
    for(int x = 1; x <= n; x++) {
        for(int y = 1; y <= n; y++) printf("%lld ", a[x][y]);
        printf("\n");
    }
    
    return 0;
}