#include<bits/stdc++.h>
#define int long long
#define N 100005
using namespace std;
int n, Q;
vector<int>p[N];
int a[N], walk[1010][1010];
void dfs(int x, int fa, int P, int z) {
    walk[P][x] = z;
    for(auto y : p[x]) {
        if(y == fa) continue;
        dfs(y, x, P, z);
    }
}
signed main() {
    freopen("sunset.in", "r", stdin);
    freopen("sunset.out", "w", stdout);
    scanf("%lld %lld", &n, &Q);
    for(int i = 2, x; i <= n; i++) {
        scanf("%lld", &x);
        p[x].push_back(i);
        p[i].push_back(x);
    }
    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for(int i = 1; i <= n; i++) {
        for(auto x : p[i]) dfs(x, i, i, x);
        walk[i][i] = i;
    }
    
    while(Q--) {
        int x, l, r;
        scanf("%lld %lld %lld", &x, &l, &r);
        for(int i = l; i <= r; i++) x = walk[x][a[i]];
        printf("%lld\n", x);
    }
    
    return 0;
}