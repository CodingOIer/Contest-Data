#include<bits/stdc++.h>
#define N 100005
using namespace std;
int n,m;
int fa[N],a[N];
int tot,head[N],nxt[N],to[N];
int idx,dfn[N],siz[N];
void add(int u,int v){
	nxt[++tot]=head[u];
	to[tot]=v;
	head[u]=tot;
}
void dfs(int x){
	dfn[x]=++idx;
	siz[x]=1;
	for(int i=head[x];i;i=nxt[i]){
		dfs(to[i]);
		siz[x]+=siz[to[i]];
	}
}
int main(){
	freopen("sunset.in","r",stdin);
	freopen("sunset.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		add(fa[i],i);
	}
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	dfs(1);
	while(m--){
		int x,l,r;
		scanf("%d %d %d",&x,&l,&r);
		for(int i=l;i<=r;i++){
			if(x==a[i]) continue;
			bool z=0;
			for(int j=head[x];j;j=nxt[j]){
				if(dfn[a[i]]>=dfn[to[j]]&&dfn[a[i]]<=dfn[to[j]]+siz[to[j]]-1){
					x=to[j];
					z=1;
					break;
				}
			}
			if(!z) x=fa[x];
		}
		printf("%d\n",x);
	}
	return 0;
} 
