#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[1005][1005],b[1005][1005];
int p,q;
string s;
void f(){
	if(!p&&!q) return;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			b[(i+q)%n][(j+p)%n]=a[i][j];
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=b[i][j];
		}
	}
	p=q=0;
}
void w1(){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			b[i][a[i][j]-1]=j+1;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=b[i][j];
		}
	}
}
void w2(){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			b[a[i][j]-1][j]=i+1;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=b[i][j];
		}
	}
}
int main(){
	freopen("mat.in","r",stdin);
	freopen("mat.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	cin>>s;
	s=' '+s;
	for(int i=1;i<=m;i++){
		if(s[i]=='L') p=(p-1+n)%n;
		else if(s[i]=='R') p=(p+1)%n;
		else if(s[i]=='U') q=(q-1+n)%n;
		else if(s[i]=='D') q=(q+1)%n;
		else{
			f();
			if(s[i]=='I') w1();
			else w2();
		}
	}
	f();
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
} 
