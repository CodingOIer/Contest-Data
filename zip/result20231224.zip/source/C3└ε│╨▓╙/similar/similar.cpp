#include<bits/stdc++.h>
#define N 100005
#define ll unsigned long long
#define mid ((l+r)>>1)
using namespace std;
int n,q;
int a[N];
int h1[N],h2[N];
int mx,b[N];
int w[N][105];
int main(){
	freopen("similar.in","r",stdin);
	freopen("similar.out","w",stdout);
	scanf("%d %d",&n,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),mx=max(mx,a[i]);
	if(n<=1000&&q<=1000){
		while(q--){
			int l1,r1,l2,r2,z=0;
			scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
			for(int i=0;i<=r1-l1;i++){
				h1[i]=a[l1+i];
				h2[i]=a[l2+i];
			}
			sort(h1,h1+r1-l1+1);
			sort(h2,h2+r2-l2+1);
			for(int i=0;i<=r1-l1;i++){
				if(h1[i]!=h2[i]) z++;
				if(z>1) break;
			}
			if(z<=1) printf("YES\n");
			else printf("NO\n");
		}
		return 0;
	}
	if(mx<=100){
		for(int i=1;i<=n;i++) b[i]=a[i];
		sort(b+1,b+n+1);
		int len=unique(b+1,b+n+1)-b-1;
		for(int i=1;i<=n;i++){
			a[i]=lower_bound(b+1,b+len+1,a[i])-b;
			for(int j=1;j<=mx;j++) w[i][j]=w[i-1][j];
			w[i][a[i]]++;
		}
		while(q--){
			int l1,r1,l2,r2;
			int z=0;
			scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
			for(int i=1;i<=mx;i++){
				if(w[r1][i]-w[l1-1][i]==0&&w[r2][i]-w[l2-1][i]==0) continue;
				if((w[r1][i]-w[l1-1][i]==w[r2][i]-w[l2-1][i]&&z==1)||abs(w[r1][i]-w[l1-1][i]-(w[r2][i]-w[l2-1][i]))>1){
					z=-1;
					break;
				}
				if(abs(w[r1][i]-w[l1-1][i]-(w[r2][i]-w[l2-1][i]))==1){
					if(z==0) z=w[r1][i]-w[l1-1][i]-(w[r2][i]-w[l2-1][i]);
					else if(-z==w[r1][i]-w[l1-1][i]-(w[r2][i]-w[l2-1][i])) z=2;
					else{
						z=-1;
						break;
					}
				}
			}
			if(z==-1) printf("NO\n");
			else printf("YES\n");
		}
		return 0;
	}
	return 0;
}
