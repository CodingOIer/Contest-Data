#include <bits/stdc++.h>
#define fi first
#define se second
#define pb(x) push_back(x)
using namespace std;
typedef long long i64;
typedef pair<int, int> pii;
typedef double f32;
using namespace std;
const int N = 1e3+5, M = 1e5+5;
int n, m, A[N][N], B[N][N], u[3], v[3], w[3]; char o[M]; void fix(int &x) { x<n?0:x-=n; }
int main()
{
    freopen("mat.in", "r", stdin), freopen("mat.out", "w", stdout);
    scanf("%d%d", &n, &m), assert(n <= 1e3&&m <= 1e5);
    for(int i = 0; i < n; ++i) for(int j = 0; j < n; ++j) 
        scanf("%d", A[i]+j), assert(1 <= A[i][j]&&A[i][j] <= n), --A[i][j];
    for(int i = 0; i < n; ++i) 
    {
        static int vis[N];
        for(int j = 0; j < n; ++j) vis[j] = 0;
        for(int j = 0; j < n; ++j) assert(!vis[A[i][j]]), vis[A[i][j]] = 1;
        for(int j = 0; j < n; ++j) vis[j] = 0;
        for(int j = 0; j < n; ++j) assert(!vis[A[j][i]]), vis[A[j][i]] = 1;
    }
    scanf("%s", o); for(int i = 0; i < 3; ++i) u[i] = i, v[i] = 0;
    for(int i = 0; i < m; ++i)
        if(o[i] == 'R') fix(++v[1]);
        else if(o[i] == 'L') fix(v[1] += n-1);
        else if(o[i] == 'D')  fix(++v[0]);
        else if(o[i] == 'U') fix(v[0] += n-1);
        else if(o[i] == 'I') swap(v[1], v[2]), swap(u[1], u[2]);
        else swap(v[0], v[2]), swap(u[0], u[2]);
    for(int i = 0; i < n; ++i) for(int j = 0; j < n; ++j)
    {
        for(int k = 0; k < 3; ++k) fix(w[k] = (u[k] == 2?A[i][j]:u[k]?j:i)+v[k]);
        B[w[0]][w[1]] = w[2];
    }
    for(int i = 0; i < n; puts(""), ++i) for(int j = 0; j < n; ++j) printf("%d ", B[i][j]+1);
    return 0;
}