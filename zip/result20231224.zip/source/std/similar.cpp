#include <bits/stdc++.h>
#define ll long long
#define INF 1000000000
#define INF2 2000000000000000000
 
using namespace std;

const int N = 1e5 + 5;
const int LOGN = 30;
const int P = 1e5 + 7;
const int MOD1 = 1e9 + 7;
const int MOD2 = 1e9 + 21;

int A[N], root[N], L[N * LOGN], R[N * LOGN];
int pw1[N], pw2[N];
int tree1[N * LOGN], tree2[N * LOGN];
int id = 0;
int n, q;

inline void copyNode(const int &dest, const int &src) {
    tree1[dest] = tree1[src];
    tree2[dest] = tree2[src];
    L[dest] = L[src];
    R[dest] = R[src];
}

int power(int x, int y, int mod) {
    if(y == 0)
        return 1;
    int a = power(x, y/2, mod);
    a = (1LL * a * a)%mod;
    if(y%2)
        a = (1LL * a * x)%mod;
    return a;
}

int create(int start, int end) {
    int node = ++id;
    if(start == end)
        tree1[node] = tree2[node] = L[node] = R[node] = 0;
    else {
        int mid = (start + end)/2;
        L[node] = create(start, mid);
        R[node] = create(mid + 1, end);
        tree1[node] = tree2[node] = 0;
    }
    return node;
}

int update(int node, int start, int end, int idx, int val) {
    int newNode = ++id;
    copyNode(newNode, node);
    node = newNode;
    if(start == end) {
        tree1[node] += val;
        tree2[node] += val;
        return node;
    }
    int mid = (start + end)/2;
    if(start <= idx && idx <= mid)
        L[node] = update(L[node], start, mid, idx, val);
    else
        R[node] = update(R[node], mid + 1, end, idx, val);
    tree1[node] = (1LL * tree1[L[node]] + 1LL * pw1[mid - start + 1] * tree1[R[node]])%MOD1;
    tree2[node] = (1LL * tree2[L[node]] + 1LL * pw2[mid - start + 1] * tree2[R[node]])%MOD2;
    return node;
}

bool check(int node1L, int node1R, int node2L, int node2R) {
    if(node1L == 0)
        return true;
    int val1 = tree1[node1R] - tree1[node1L];
    if(val1 < 0)
        val1 += MOD1;
    int val2 = tree1[node2R] - tree1[node2L];
    if(val2 < 0)
        val2 += MOD1;
    int val3 = tree2[node1R] - tree2[node1L];
    if(val3 < 0)
        val3 += MOD2;
    int val4 = tree2[node2R] - tree2[node2L];
    if(val4 < 0)
        val4 += MOD2;
    return (val1 == val2 && val3 == val4);
}

int query2(int node1L, int node1R, int node2L, int node2R, const int &dir) {
    if(!L[node1L] && !R[node1L]) {
        int val1 = tree1[node1R] - tree1[node1L];
        if(val1 < 0)
            val1 += MOD1;

        int val2 = tree1[node2R] - tree1[node2L];
        if(val2 < 0)
            val2 += MOD1;
        return (val1 - val2);
    }
    bool lVal = check(L[node1L], L[node1R], L[node2L], L[node2R]);
    bool rVal = check(R[node1L], R[node1R], R[node2L], R[node2R]);
    if(!lVal && !rVal)
        return INF;
    if(!lVal && dir && (((tree1[R[node1R]] - tree1[R[node1L]] + MOD1)%MOD1) || ((tree2[R[node1R]] - tree2[R[node1L]] + MOD2)%MOD2)))
        return INF;
    if(!rVal && !dir && (((tree1[L[node1R]] - tree1[L[node1L]] + MOD1)%MOD1) || ((tree2[L[node1R]] - tree2[L[node1L]] + MOD2)%MOD2)))
        return INF;
    if(!lVal)
        return query2(L[node1L], L[node1R], L[node2L], L[node2R], dir);
    else if(!rVal)
        return query2(R[node1L], R[node1R], R[node2L], R[node2R], dir);
    return 0;
}

bool query(int node1L, int node1R, int node2L, int node2R, int start, int end) {
    bool lVal = check(L[node1L], L[node1R], L[node2L], L[node2R]);
    bool rVal = check(R[node1L], R[node1R], R[node2L], R[node2R]);
    int mid = (start + end)/2;
    if(!lVal && !rVal) {
        int a = query2(L[node1L], L[node1R], L[node2L], L[node2R], 1);
        int b = query2(R[node1L], R[node1R], R[node2L], R[node2R], 0);
        return (abs(a) == 1 && a + b == 0);
    }
    else if(!lVal) {
        return query(L[node1L], L[node1R], L[node2L], L[node2R], start, mid);
    }
    else if(!rVal) {
        return query(R[node1L], R[node1R], R[node2L], R[node2R], mid + 1, end);
    }
    return true;
}



int main() {
	freopen("similar.in","r",stdin);
	freopen("similar.out","w",stdout);
    cin.tie(0);
    int t;
    pw1[0] = pw2[0] = 1;
    for(int i = 1; i <= 100000; i++) {
        pw1[i] = (1LL * pw1[i - 1] * P)%MOD1;
        pw2[i] = (1LL * pw2[i - 1] * P)%MOD2;
    }
    cin >> n >> q;
    id = 0;
    for(int i = 1; i <= n; i++)
        cin >> A[i];
    root[0] = create(1, N);
    for(int i = 1; i <= n; i++)
        root[i] = update(root[i - 1], 1, N, A[i], 1);
    while(q--) {
        int l1, r1, l2, r2;
        cin >> l1 >> r1 >> l2 >> r2;
        if(query(root[l1 - 1], root[r1], root[l2 - 1], root[r2], 1, N))
            cout << "YES\n";
    	else cout << "NO\n";
    }
    return 0; 
}   
