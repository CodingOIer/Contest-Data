#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
int n, m, dep[N], son[N], h[N], pos[N], val[N << 1], ed[N], cnt[N], ev[N], f[N], df[N][2], tk, fa[N][18], nx[N], rp, tot, id[N];
vector<int> g[N];

void dfs(int u) {
	h[u] = 1, df[u][0] = ++tk;
	for (auto v : g[u]) {
		for (int i = 1; i < 18; i++)
			fa[v][i] = fa[fa[v][i - 1]][i - 1];
		dep[v] = dep[u] + 1, dfs(v), h[u] = max(h[u], h[v] + 1);
		if (h[v] > h[son[u]]) son[u] = v;
	}
	df[u][1] = tk;
}
int la(int x, int k) {
	if (!k) return x;
	int i = 31 - __builtin_clz(k);
	return val[pos[fa[x][i]] + k - (1 << i)];
}
int move(int u, int v) {
	if (u == v) return u;
	if (df[u][0] <= df[v][0] && df[v][0] <= df[u][1])
		return la(v, dep[v] - dep[u] - 1);
	return fa[u][0];
}
struct Q { int l, r, x; } q[N];
struct Z { int d, w, x; } s[N];
struct List {
	int h, t;
	List(int w = 0) { h = t = w; }
	void ins(List w) {
		if (!w.h) return;
		if (!h) return void(*this = w);
		nx[t] = w.h, t = w.t;
	}
} rs[N];
struct Ring {
	List *v;
	int sz, a, fa, tk;
	List &operator[](int x) { if ((x += a) >= sz) x -= sz; return v[x]; }
	List &back() { return (*this)[sz - 1]; }
	List sl() { if (++a == sz) a = 0; return mv(back()); }
	List sr() { if (--a < 0) a = sz - 1; return mv((*this)[0]); }
	static List mv(List &x) { List x0 = x; x = List(); return x0; }
} r[N];

int main() {
	freopen("sunset.in", "r", stdin);
	freopen("sunset.out", "w", stdout);

	scanf("%d%d", &n, &m);
	int B = max(1, (int)sqrt(2.0 * n));
	for (int i = 2; i <= n; i++) {
		scanf("%d", &fa[i][0]);
		g[fa[i][0]].emplace_back(i);
	}
	for (int i = 1; i <= n; i++) scanf("%d", &id[i]);
	for (int i = 1; i <= m; i++) scanf("%d%d%d", &q[i].x, &q[i].l, &q[i].r);
	dfs(1), tk = 0;
	for (int i = 1; i <= n; i++) {
		if (i != son[fa[i][0]]) {
			tk += h[i];
			int w = i, u = i;
			for (int j = 0; j < h[i]; j++, w = son[w]) {
				val[tk + j + 1] = u = fa[u][0];
				val[pos[w] = tk - j] = w;
			}
			tk += h[i];
		}
	}
	for (int L = 1, R = B; L <= n; L += B, R += B) {
		R = min(R, n);
		memset(ed, 0, sizeof(ed));
		memset(nx, 0, sizeof(nx));
		memset(cnt, 0, sizeof(int) * (B + 5));
		for (int i = L; i <= R; i++) ed[id[i]] = 2;
		for (int i = n; i >= 2; i--) {
			if (ed[i]) ed[fa[i][0]] = ed[fa[i][0]] ? 2 : 1;
		}
		rp = tot = 0, ed[0] = 2;
		for (int i = 1; i <= n; i++) {
			if (ed[i]) {
				if (ed[fa[i][0]] == 2) s[i] = Z{0, ++tot, 0};
				else s[i] = s[fa[i][0]], ++s[i].x;
				if (ed[i] == 2) {
					int a = s[i].w, sz = s[i].x + 1, w = i;
					r[a] = {rs + rp, sz, 0, 0, 0}, rp += sz;
					for (int j = 0; j < sz; j++, w = fa[w][0]) {
						r[a].v[sz - 1 - j] = List(w);
					}
					r[a].fa = s[w].w;
				}
			} else {
				s[i] = s[fa[i][0]], ++cnt[++s[i].d];
			}
		}
		for (int i = 1; i <= B; i++) cnt[i] += cnt[i - 1];
		for (int i = 1; i <= n; i++) {
			if (!ed[i] && s[i].d <= B) ev[cnt[s[i].d - 1]++] = i;
		}
		int ep = 0;
		for (int i = L; i <= R; i++) {
			for (int a = s[id[i]].w, b = 0; a; b = a, a = r[a].fa) {
				r[a].tk = i;
				auto tmp = r[a].sr();
				(b ? r[b][0] : r[a].back()).ins(tmp);
			}
			for (int j = 1; j <= tot; j++) {
				if (r[j].tk != i) r[r[j].fa].back().ins(r[j].sl());
			}
			while (ep < cnt[i - L]) {
				int w = ev[ep++];
				r[s[w].w][s[w].x].ins(List(w));
			}
		}
		for (int i = 1; i <= n; i++) {
			if (!ed[i]) {
				if (s[i].d > R - L + 1) f[i] = la(i, R - L + 1);
			} else {
				for (int a = r[s[i].w][s[i].x].h; a; a = nx[a]) f[a] = i;
			}
		}
		for (int i = 1; i <= m; i++) {
			int l = q[i].l, r = q[i].r, &x = q[i].x;
			if (l > R || r < L) continue;
			if (l <= L && R <= r) { x = f[x]; continue; }
			for (int j = max(L, l); j <= min(R, r); j++) x = move(x, id[j]);
		}
	}
	for (int i = 1; i <= m; i++) printf("%d\n", q[i].x);
	cerr << clock() << endl;
	return 0;
}