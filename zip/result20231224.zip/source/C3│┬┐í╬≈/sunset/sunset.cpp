#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,q,a[N];

int head[N],nxt[N<<1],to[N<<1],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=head[u],head[u]=tot;}

int dep[N],siz[N],son[N],top[N],fa[N],id[N],idx;

void dfs1(int u,int f){
	dep[u]=dep[f]+1;
	siz[u]=1,fa[u]=f;
	id[u]=++idx;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[son[u]]<siz[v]) son[u]=v;
	}
}
void dfs2(int u,int tp){
	top[u]=tp;
	if(!son[u]) return;
	dfs2(son[u],tp);
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==son[u]) continue;
		dfs2(v,v);
	}
}
int Lca(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}

signed main(){
	freopen("sunset.in","r",stdin);
	freopen("sunset.out","w",stdout);
	n=read(),q=read();
	for(int i=2;i<=n;i++){
		int f=read();
		add(f,i);
	}
	for(int i=1;i<=n;i++) a[i]=read();
	dfs1(1,1);
	dfs2(1,1);
	while(q--){
		int x=read(),l=read(),r=read();
		for(int i=l;i<=r;i++){
			int y=a[i];
			if(x==y) continue;
			if(Lca(x,y)!=x) x=fa[x];
			else{
				for(int j=head[x];j;j=nxt[j]){
					int v=to[j];
					if(id[y]>=id[v]&&id[y]<=id[v]+siz[v]-1){
						x=v;
						break;
					}
				}
			}
		}
		printf("%lld\n",x);
	}
	return 0;
}
