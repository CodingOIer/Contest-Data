#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1005;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}
int n,m,a[N][N],b[N][N];
string s;
signed main(){
	freopen("mat.in","r",stdin);
	freopen("mat.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			a[i][j]=read();
	cin>>s;
	if(n<=10){
		for(int i=0;i<m;i++){
			char opt=s[i];
			if(opt=='L'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[j][k]=a[j][k%n+1];
			}
			if(opt=='R'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[j][k%n+1]=a[j][k];			
			}		
			if(opt=='D'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[j%n+1][k]=a[j][k];			
			}
			if(opt=='U'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[j][k]=a[j%n+1][k];			
			}
			if(opt=='I'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[j][a[j][k]]=k;
			}
			if(opt=='C'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++)
						b[a[j][k]][k]=j;
			}
			for(int j=1;j<=n;j++)
				for(int k=1;k<=n;k++)
					a[j][k]=b[j][k];
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				printf("%lld ",a[i][j]);
			printf("\n");
		}		
	}
	else{
		int LR=0,UD=0;
		for(int i=0;i<m;i++){
			char opt=s[i];
			if(opt=='L') LR++;
			if(opt=='R') LR--;				
			if(opt=='D') UD--;		
			if(opt=='U') UD++;	
		}
		LR%=n;
		UD%=n;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				int x=(i+UD+n)%n==0?n:(i+UD+n)%n;
				int y=(j+LR+n)%n==0?n:(j+LR+n)%n;
				printf("%lld ",a[x][y]);
			}
			printf("\n");
		}
	}
	return 0;
}
