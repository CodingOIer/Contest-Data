#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5,V=105;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-48,ch=getchar();}
	return x*f;
}

int n,m,a[N],s1[N],s2[N];
bool ans[N];

int sum[N][V];
bool vis1[V],vis2[V];

signed main(){
	freopen("similar.in","r",stdin);
	freopen("similar.out","w",stdout);
	n=read(),m=read();
	
	for(int i=1;i<=n;i++) a[i]=read();
	
	if(n<=1000&&m<=1000){
		while(m--){
			int l1=read(),r1=read();
			int l2=read(),r2=read();
			int len=r1-l1+1;
			if(r1-l1!=r2-l2){
				puts("NO");
				continue;
			}
			for(int i=l1;i<=r1;i++) s1[i-l1+1]=a[i];
			for(int i=l2;i<=r2;i++) s2[i-l2+1]=a[i];
			sort(s1+1,s1+1+len);
			sort(s2+1,s2+1+len);
			int dif=0;
			for(int i=1;i<=len;i++)
				dif+=(s1[i]!=s2[i]);
			if(dif<=1) puts("YES");
			else puts("NO");
		}
	}
	else{
		for(int i=1;i<=n;i++){
			sum[i][a[i]]=1;
			for(int j=1;j<=100;j++)
				sum[i][j]+=sum[i-1][j];
		}
		while(m--){
			int l1=read(),r1=read();
			int l2=read(),r2=read();
			if(r1-l1!=r2-l2){
				puts("NO");
				continue;
			}
			int sm=0,x1=0,x2=0;
			for(int i=1;i<=100;i++) vis1[i]=vis2[i]=0;
			
			for(int i=1;i<=100;i++){
				int c=(sum[r1][i]-sum[l1-1][i])-(sum[r2][i]-sum[l2-1][i]);
				
				if((sum[r1][i]-sum[l1-1][i])) vis1[i]=1;
				if((sum[r2][i]-sum[l2-1][i])) vis2[i]=1;
				
				if(c>0) sm+=c;
				if(c==1) x1=i;
				if(c==-1) x2=i;
			}
			if(sm>1){
				puts("NO");
				continue;
			}
			if(!sm){
				puts("YES");
				continue;
			}
			
			
			
			int ls1=0,rs1=101;
			int ls2=0,rs2=101;
			
			for(int i=x1-1;i>=1;i--){
				if(vis1[i]){
					ls1=i;
					break;
				}
			}
			
			for(int i=x1+1;i<=100;i++){
				if(vis1[i]){
					rs1=i;
					break;
				}
			}

			for(int i=x2-1;i>=1;i--){
				if(vis2[i]){
					ls2=i;
					break;
				}
			}
			
			for(int i=x2+1;i<=100;i++){
				if(vis2[i]){
					rs2=i;
					break;
				}
			}
					
			if((ls1==ls2||ls1==x2||ls2==x1)&&(rs1==rs2||rs1==x2||rs2==x1)) puts("YES");
			else puts("NO");
		}
	}
	
	return 0;
}
