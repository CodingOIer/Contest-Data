#include <bits/stdc++.h>
using namespace std;

int n, m, f[21][100005], a[100005], x, l, r, d[100005];
vector<int> edges[100005];

void dfs(int i) {
	for (auto j : edges[i]) {
		d[j] = d[i] + 1;
		dfs(j);
	}
}

int lca(int x, int y) { // x �Ƿ�Ϊ y �����ȣ�����ǣ����� y ���� x ��һ��Ľڵ㣬���򷵻� -1
	if (d[x] >= d[y]) return -1;
	int stp = d[y] - d[x] - 1;
	for (int l = 0; stp; ++l, stp >>= 1) {
		if (stp & 1) {
			y = f[l][y];
		}
	}
	if (f[0][y] == x) return y;
	else return -1;
}

int main() {
	freopen("sunset.in", "r", stdin);
	freopen("sunset.out","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i = 2; i <= n; ++i) {
		scanf("%d", &f[0][i]);
		edges[f[0][i]].push_back(i);
	}
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
	for (int j = 1; j <= 20; ++j) {
		for (int i = 1; i <= n; ++i) {
			f[j][i] = f[j - 1][f[j - 1][i]];
		}
	}
	d[1] = 1;
	dfs(1);
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d%d", &x, &l, &r);
		for (int j = l; j <= r; ++j) {
			if (x != a[j]) {
				int tmp = lca(x, a[j]);
				if (tmp + 1) x = tmp;
				else x = f[0][x];
			}
		}
		printf("%d\n", x);
	}
	return 0;
}
/*
15pts

1
|
2
|
3
|
4
|
5

3 1 4 5 2

*/
