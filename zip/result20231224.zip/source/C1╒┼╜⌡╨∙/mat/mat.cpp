#include <bits/stdc++.h>
using namespace std;

int n, m, a[1001][1001], b[1001][1001];
char s[100061];
int tmp[1001];

void tmove(int x, int y) {
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
//			fprintf(stderr, "(%d %d) -> (%d %d)\n", i, j, ((i - x) % n + n) % n, ((j - y) % n + n) % n);
			b[((i - x) % n + n) % n][((j - y) % n + n) % n] = a[i][j];
		}
	}
	for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) 
		a[i][j] = b[i][j]; 
}

int main() {
	freopen("mat.in", "r", stdin);
	freopen("mat.out","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			scanf("%d", &a[i][j]);
			--a[i][j];
		}
	}
	scanf("%s", s + 1);
	int x = 0, y = 0;
	for (int i = 1; i <= m; ++i) {
		if (s[i] == 'L') ++y;
		else if (s[i] == 'R') --y;
		else if (s[i] == 'D') --x;
		else if (s[i] == 'U') ++x;
		else if (s[i] == 'I') {
			if (x || y) tmove(x, y);
			x = y = 0;
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < n; ++j) tmp[a[i][j]] = j;
				for (int j = 0; j < n; ++j) a[i][j] = tmp[j];
			}
		} else if (s[i] == 'C') {
			if (x || y) tmove(x, y);
			x = y = 0;
			for (int j = 0; j < n; ++j) {
				for (int i = 0; i < n; ++i) tmp[a[i][j]] = i;
				for (int i = 0; i < n; ++i) a[i][j] = tmp[i];
			}
		}
	}
	if (x || y) tmove(x, y);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) printf("%d%c", a[i][j] + 1, " \n"[j == n - 1]);
	}
	return 0;
}
/*
30pts
1/3 ����Ӧ���Ż����˶��� 
*/

