#include <bits/stdc++.h>
using namespace std;

int n, q, a[100001], sum[100001][101], lisan[100001], zy;
int tmpa[100001], tmpb[100001];
int cnta[100001], cntb[100001], tmp[100001];
unsigned short cntaa[100108], cntbb[100108];

inline void solve(int l1, int r1, int l2, int r2) {
	memset(cnta, 0, sizeof(cnta));
	memset(cntb, 0, sizeof(cntb));
	for (int i = l1; i <= r1; ++i) {
		++cnta[a[i]];
	}
	for (int i = l2; i <= r2; ++i) {
		++cntb[a[i]];
	}
}

void solve_faster(int l1, int r1, int l2, int r2) {
	memset(cntaa, 0, (zy + 5) << 1);
	memset(cntbb, 0, (zy + 5) << 1);
	for (int i = l1; i <= r1; ++i) ++cntaa[a[i]];
	for (int i = l2; i <= r2; ++i) ++cntbb[a[i]];
}

char buf[1 << 20];
int top = 0;

int main() {
	freopen("similar.in", "r", stdin);
	freopen("similar.out", "w", stdout);
	scanf("%d%d", &n, &q);
	bool a_ile100 = 1;
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &a[i]);
		a_ile100 &= (a[i] <= 100);
	}
	if (n <= 1000 && q <= 1000) {
		for (int i = 1; i <= q; ++i) {
			int l1, r1, l2, r2;
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			for (int i = l1, pos = 1; i <= r1; ++i, ++pos) tmpa[pos] = a[i];
			for (int i = l2, pos = 1; i <= r2; ++i, ++pos) tmpb[pos] = a[i];
			int len = r1 - l1 + 1;
			sort(tmpa + 1, tmpa + len + 1);
			sort(tmpb + 1, tmpb + len + 1);
			int cnt = 0;
			for (int i = 1; i <= len && cnt <= 1; ++i) cnt += (tmpa[i] != tmpb[i]);
			if (cnt <= 1) puts("YES");
			else puts("NO");
		}
	} else if (a_ile100) {
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j <= 100; ++j) {
				sum[i][j] = sum[i - 1][j];
				if (a[i] == j) sum[i][j]++;
			}
		}
		for (int i = 1; i <= q; ++i) {
			int l1, r1, l2, r2, zf = 0;
			bool flag = 0, ok = 1;
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			for (int j = 1; j <= 100; ++j) {
				int ac = sum[r1][j] - sum[l1 - 1][j];
				int bc = sum[r2][j] - sum[l2 - 1][j];
				if (ac == bc && ac == 0) continue;
				if (ac != bc) {
					if (flag) {
						ok = 0;
						break;
					}
					if (zf) {
						if (bc - zf != ac) {
							ok = 0;
							break;
						}
						zf = 0;
						flag = 1;
					} else {
						if (abs(ac - bc) == 1) {
							zf = ac - bc;
						} else {
							ok = 0;
							break;
						}
					}
				} else {
					if (zf) {
						ok = 0;
						break;
					}
				}
			}
			if (ok) puts("YES");
			else puts("NO");
		}
	} else {
		for (int i = 1; i <= n; ++i) lisan[i] = a[i];
		sort(lisan + 1, lisan + n + 1);
		int rnk = 0;
		for (int i = 1; i <= n; ++i) {
			if (lisan[i] != lisan[i - 1]) {
				tmp[lisan[i]] = ++rnk;
			}
		}
		zy = rnk;
		for (int i = 1; i <= n; ++i) a[i] = tmp[a[i]];
		for (int i = 1; i <= q; ++i) {
			int l1, r1, l2, r2, zf = 0, flag = 0, ok = 1;
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			solve_faster(l1, r1, l2, r2);			
			for (int j = 1; j <= zy; ++j) {
				int ac = cntaa[j];
				int bc = cntbb[j];
				if (ac == bc && ac == 0) continue;
				if (ac ^ bc) {
					if (flag) {
						ok = 0;
						break;
					}
					if (zf) {
						if (bc - zf != ac) {
							ok = 0;
							break;
						}
						zf = 0;
						flag = 1;
					} else {
						if (abs(ac - bc) == 1) {
							zf = ac - bc;
						} else {
							ok = 0;
							break;
						}
					}
				} else {
					if (zf) {
						ok = 0;
						break;
					}
				}
			}
			if (ok) puts("YES");
			else puts("NO");
		}
	}
	return 0;
}
/*
50pts
����ˮ�Ļ�Ӧ���ܶ��ü��� 
*/
