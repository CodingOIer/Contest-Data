#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1010;
string s;
int ops, n, m;
int a[Maxn][Maxn], b[Maxn][Maxn];
void solve1(){
    for(int Q = 1 ; Q <= m ; Q++){
        if(s[Q] == 'R'){
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    b[i][j % n + 1] = a[i][j];
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        if(s[Q] == 'L'){
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    b[i][j] = a[i][j % n + 1];
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        if(s[Q] == 'D'){
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    b[i % n + 1][j] = a[i][j];
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        if(s[Q] == 'U'){
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    b[i][j] = a[i % n + 1][j];
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        if(s[Q] == 'I'){
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    b[i][a[i][j]] = j;
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        if(s[Q] == 'C'){
            for(int j = 1 ; j <= n ; j++)
                for(int i = 1 ; i <= n ; i++)
                    b[a[i][j]][j] = i;
            for(int i = 1 ; i <= n ; i++)
                for(int j = 1 ; j <= n ; j++)
                    a[i][j] = b[i][j];
        }
        // for(int i = 1 ; i <= n ; i++){
        //     for(int j = 1 ; j <= n ; j++)
        //         cout << a[i][j] << " ";
        //     cout << '\n';
        // }
        // cout << '\n';
    }
}
int siz[5];
void solve2(){
    for(int i = 1 ; i <= m ; i++){
        if(s[i] == 'R') siz[1]++;
        if(s[i] == 'L') siz[2]++;
        if(s[i] == 'D') siz[3]++;
        if(s[i] == 'U') siz[4]++;
    }
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++){
            b[i][(j + siz[1] - 1) % n + 1] = a[i][j];
        }     
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            a[i][j] = b[i][j];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            b[i][j] = a[i][(j + siz[2] - 1) % n + 1];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            a[i][j] = b[i][j];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            b[(i + siz[3] - 1) % n + 1][j] = a[i][j];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            a[i][j] = b[i][j];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            b[i][j] = a[(i + siz[4] - 1) % n + 1][j];
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= n ; j++)
            a[i][j] = b[i][j];
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("mat.in", "r", stdin);
    freopen("mat.out", "w", stdout);
    cin >> n >> m;
    for(int i = 1 ; i <= n ; i++){
        for(int j = 1 ; j <= n ; j++){
            cin >> a[i][j];
        }
    }
    cin >> s;
    s = ' ' + s;
    for(int i = 1 ; i <= m ; i++){
        if(s[i] == 'I' || s[i] == 'C') ops = 1;
    }
    if(n <= 10){
        solve1();
        for(int i = 1 ; i <= n ; i++){
            for(int j = 1 ; j <= n ; j++)
                cout << a[i][j] << " ";
            cout << '\n';
        }
        cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
        return 0;
    }
    if(!ops){
        solve2();
        for(int i = 1 ; i <= n ; i++){
            for(int j = 1 ; j <= n ; j++)
                cout << a[i][j] << " ";
            cout << '\n';
        }
        cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    }
    return 0;
}
/*
3 5
1 2 3
2 3 1
3 1 2
CICIC
*/