#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 1010;
vector<int> Tree[Maxn];
struct node{
    int l, r;
}son[Maxn];
int a[Maxn], fa[Maxn];
int dep[Maxn], siz[Maxn], dfn[Maxn], tot;
int n, Q;
void dfs(int x, int fa){
    siz[x] = 1;
    dep[x] = dep[fa] + 1;
    dfn[x] = ++tot;
    son[x].l = tot;
    for(auto to : Tree[x]){
        if(to == fa) continue;
        dfs(to, x);
        siz[x] += siz[to];
    }
    son[x].r = tot;
}
signed main(){
    ios::sync_with_stdio(false);
    freopen("sunset.in", "r", stdin);
    freopen("sunset.out", "w", stdout);
    cin >> n >> Q;
    for(int i = 2 ; i <= n ; i++){
        int x;
        cin >> x;
        fa[i] = x;
        Tree[x].push_back(i);
        Tree[i].push_back(x);
    }
    for(int i = 1 ; i <= n ; i++) cin >> a[i];
    dfs(1, 0);
    // for(int i = 1 ; i <= n ; i++) cout << dep[i] << " ";
    // cout << '\n';
    while(Q--){
        int x, l, r;
        cin >> x >> l >> r;
        for(int i = l ; i <= r ; i++){
            int ops = 1;
            for(auto to : Tree[x]){
                if(to == fa[x]) continue;
                if(dfn[a[i]] >= son[to].l && dfn[a[i]] <= son[to].r)
                    x = to, ops = 0;
            }
            if(ops && a[i] != x) x = fa[x]; 
            // cout << x << " ";
        }
        cout << x << '\n';
    }
    cerr << clock() * 1.0 / CLOCKS_PER_SEC << "sec" << endl;
    return 0;
}