#include<bits/stdc++.h>
#define int long long
using namespace std;
const int Maxn = 100010;
int n, Q;
int a[Maxn], b[Maxn], c[Maxn];
signed main(){
    ios::sync_with_stdio(false);
    freopen("similar.in", "r", stdin);
    freopen("similar.out", "w", stdout);
    cin >> n >> Q;
    for(int i = 1 ; i <= n ; i++){
        cin >> a[i];
    }
    while(Q--){
        int l1, r1, l2, r2;
        int len1 = 0, len2 = 0;
        cin >> l1 >> r1 >> l2 >> r2;
        for(int i = l1 ; i <= r1 ; i++) b[++len1] = a[i];
        for(int i = l2 ; i <= r2 ; i++) c[++len2] = a[i];
        sort(b + 1, b + len1 + 1);
        sort(c + 1, c + len2 + 1);
        int op = 0;
        for(int i = 1 ; i <= len1 ; i++) if(b[i] != c[i]) op++;
        if(op <= 1) cout << "YES" << '\n';
        else cout << "NO" << '\n';
    }
    return 0;
}