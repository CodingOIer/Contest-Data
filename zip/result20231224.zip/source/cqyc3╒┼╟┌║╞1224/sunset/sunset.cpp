#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e3+7;
int n,Q,a[Maxn],nxt[Maxn][Maxn];
vector<int>e[Maxn];
bool vis[Maxn];

struct node{
	int u,c;
};
inline void BFS(int s){
	queue<node>q;
	memset(vis,0,sizeof vis);
	vis[s]=1;
	q.push((node){s,s});
	while(!q.empty()){
		node tp=q.front();
		q.pop();
		nxt[s][tp.u]=tp.c;
		for(auto i:e[tp.u]){
			if(!vis[i]){
				int c=tp.c==s?i:tp.c;
				q.push((node){i,c});
			}
			vis[i]=1;
		}
	}
}

int main(){
	freopen("sunset.in","r",stdin);
	freopen("sunset.out","w",stdout);
	scanf("%d%d",&n,&Q);
	for(int i=2;i<=n;i++){
		int u;
		scanf("%d",&u);
		e[u].emplace_back(i);
		e[i].emplace_back(u);
	}
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) BFS(i);
	while(Q--){
		int x,l,r;
		scanf("%d%d%d",&x,&l,&r);
		for(int i=l;i<=r;i++) x=nxt[x][a[i]];
		printf("%d\n",x);
	}
	return 0;
}

/*
5 5
1 2 3 2
4 3 1 5 2
4 1 4
3 1 3
1 1 4
3 1 2
2 4 5
*/

