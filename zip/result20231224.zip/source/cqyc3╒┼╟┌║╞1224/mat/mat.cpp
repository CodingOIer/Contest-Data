#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1010;
int n,m,a[Maxn][Maxn],b[Maxn][Maxn],R,U; 
string S;
inline void doit(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			a[i][j]=b[i][j];
}
inline int gt(int x){
	if(x<=0) return x+n;
	return x; 
}

int main(){
	freopen("mat.in","r",stdin);
	freopen("mat.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	cin>>S;
	if(n<=10){
		for(int i=0;i<m;i++){
			if(S[i]=='U'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[k][j]=a[k%n+1][j];
				doit();
			}
			if(S[i]=='L'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[j][k]=a[j][k%n+1];
				doit();
			}
			if(S[i]=='D'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[k][j]=a[gt(k%n-1)][j];
				doit();
			}
			if(S[i]=='R'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[j][k]=a[j][gt(k%n-1)];
				doit();
			}
			if(S[i]=='I'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[j][a[j][k]]=k;
				doit();
			}
			if(S[i]=='C'){
				for(int j=1;j<=n;j++)
					for(int k=1;k<=n;k++) b[a[k][j]][j]=k;
				doit();
			}
		}
		for(int i=1;i<=n;i++,puts(""))
			for(int j=1;j<=n;j++)
				printf("%d ",a[i][j]);
		return 0;
	}
	for(int i=0;i<m;i++){
		if(S[i]=='R') R++;
		if(S[i]=='L') R--;
		if(S[i]=='U') U++;
		if(S[i]=='D') U--;
	} 
	R%=n;U%=n;
	if(R>0){
		R=-R;
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++) b[j][k]=a[j][gt((k+R+1)%n-1)];
		doit();
	}
	else if(R<0){	
		R=-R;
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++) b[j][k]=a[j][(k+R-1)%n+1];
		doit();
	}
	if(U>0){
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++) b[k][j]=a[(k+U-1)%n+1][j];
		doit();
	}
	if(U<0){
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++) b[k][j]=a[gt((k+U+1)%n-1)][j];
		doit();
	}
	for(int i=1;i<=n;i++,puts(""))
		for(int j=1;j<=n;j++)
			printf("%d ",a[i][j]);
	
	return 0;
}
/*
3 3
1 2 3
2 3 1
3 1 2
DRR

3 1
1 2 3
2 3 1
3 1 2
I
*/


