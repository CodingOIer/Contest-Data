#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn=1e5+7;
int n,Q,a[Maxn],V,g1[Maxn],g2[Maxn],cnt1,cnt2; 



int main(){
	freopen("similar.in","r",stdin);
	freopen("similar.out","w",stdout);
	scanf("%d%d",&n,&Q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),V=max(V,a[i]);
	if(n<=1000){
		for(int t=1;t<=Q;t++){
			int l1,r1,l2,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			cnt1=cnt2=0;
			for(int i=l1;i<=r1;i++) g1[++cnt1]=a[i];
			for(int i=l2;i<=r2;i++) g2[++cnt2]=a[i];
			int res=0;
			sort(g1+1,g1+cnt1+1);sort(g2+1,g2+cnt2+1);
			for(int i=1;i<=cnt1;i++) if(g1[i]!=g2[i]) res++;
			if(res>1) printf("NO\n");
			else printf("YES\n"); 
		}
	}
	
	return 0;
}

/*
6 3
1 3 4 2 3 4
1 3 4 6
1 2 5 6
3 5 2 4
*/

