/*
 * @Author: zaa
 * @Date: 2023-12-24 09:42:35
 * @LastEditors: zaa
 * @LastEditTime: 2023-12-24 11:18:49
 * @FilePath: \code\c3ZYH(test12.24)\similar.cpp
 */
#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=5e5+5;
//char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return f?-x:x;
}
int n,Q;
int a[N];
int s1[N],s2[N];
struct XXX{
	int l,r,x;
};
XXX tree[N*4];
int rt[N*4];
int cnt;
void build(int &p,int l,int r){
	p=++cnt;
	if(l==r){
		tree[p].x=a[l];
		return;
	}
	int mid=(l+r)/2;
	build(tree[p].l,l,mid);
	build(tree[p].r,mid+1,r);
}
void update(int &p,int l,int r,int x,int k){
	tree[++cnt]=tree[p];
	p=cnt;
	if(l==r){
		tree[p].x++;
		return;
	}
	int mid=(l+r)/2;
	if(x<=mid) update(tree[p].l,l,mid,x,k);
	else update(tree[p].r,mid+1,r,x,k);
}
int query(int p,int l,int r,int x){
	if(l==r )return tree[p].x;
	int mid=(l+r)/2;
	if(x<=mid) return query(tree[p].l,l,mid,x);
	else return query(tree[p].r,mid+1,r,x);
}
int tong[100005][105];
int t1[105],t2[105];
signed main(){
	freopen("similar.in","r",stdin);
	freopen("similar.out","w",stdout);
	n=read(),Q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	if(n<=1000&&Q<=1000){
		while(Q--){
            int l=read(),r=read(),L=read(),R=read();
			for(int i=l;i<=r;i++) s1[i-l+1]=a[i];
			for(int i=L;i<=R;i++) s2[i-L+1]=a[i];
			sort(s1+1,s1+r-l+2);
			sort(s2+1,s2+r-l+2);
			int dif=0;
			for(int i=1;i<=r-l+1;i++){
				if(s1[i]!=s2[i]) dif++;
                if(dif>1) break;
			}
			if(dif<=1) puts("YES");
			else puts("NO");
		}
        return 0;
	}

	for(int i=1;i<=n;i++){
		for(int j=0;j<=100;j++) tong[i][j]=tong[i-1][j];
		tong[i][a[i]]++;
	}
    while(Q--){
        int l=read(),r=read(),L=read(),R=read();
		for(int i=0;i<=100;i++) t1[i]=tong[r][i];
		for(int i=0;i<=100;i++) t2[i]=tong[R][i];
		for(int i=0;i<=100;i++) t1[i]-=tong[l-1][i];
		for(int i=0;i<=100;i++) t2[i]-=tong[L-1][i];
		int dif=0;
		int wz=0,ws=0;
		for(int i=0;i<=100;i++){
			if(t1[i]==0&&t2[i]==0) continue;
			wz+=t1[i],ws+=t2[i];
			dif+=abs(wz-ws);
		}
		if(dif<=1){
			puts("YES");
		}
		else puts("NO");

    }
	return 0;
}