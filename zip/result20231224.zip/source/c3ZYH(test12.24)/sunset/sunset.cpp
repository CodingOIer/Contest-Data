/*
 * @Author: zaa
 * @Date: 2023-12-24 08:10:32
 * @LastEditors: zaa
 * @LastEditTime: 2023-12-24 11:34:01
 * @FilePath: \code\c3ZYH(test12.24)\sunset.cpp
 */
#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=5e5+5;
//char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return f?-x:x;
}
int n,m,ans;
int f[N];
int a[N];
int ch[1005][1005];
bool flag=0;
signed main(){
	freopen("sunset.in","r",stdin);
	freopen("sunset.out","w",stdout);
	n=read(),m=read();
	for(int i=2;i<=n;i++){
		f[i]=read();
		if(f[i]!=i-1) flag=1;
	}
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	// if(!flag){
	// 	for(int i=1;i<=n;i++){
			
	// 	}
	// 	return 0;
	// }
	for(int t=1;t<=n;t++){
		int p=a[t];
		while(p!=1){
			ch[f[p]][t]=p;
			// cout<<f[p]<<" ";
			p=f[p];
		}
		// cout<<endl;
		for(int i=1;i<=n;i++){
			if(ch[i][t]==0) ch[i][t]=f[i]; 
		}
		// for(int i=1;i<=n;i++){
			// cout<<ch[i][t];
		// }
		// cout<<endl;
		ch[a[t]][t]=a[t];
	}
	while(m--){
		int x=read(),l=read(),r=read();
		for(int i=l;i<=r;i++){
			x=ch[x][i];
		}
		printf("%lld\n",x);
	}
	return 0;
}
