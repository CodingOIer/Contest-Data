/*
 * @Author: zaa
 * @Date: 2023-12-24 09:00:57
 * @LastEditors: zaa
 * @LastEditTime: 2023-12-24 09:12:31
 * @FilePath: \code\c3ZYH(test12.24)\mat.cpp
 */
#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i,  b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=5e5+5;
//char buf[(1<<21)+5],*p1,*p2;
//#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
void chmx(int &x,int y){(x<y)&&(x=y);}
void chmn(int &x,int y){(x>y)&&(x=y);}
inline int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=(x<<3)+(x<<1)+(ch^48);ch=getchar();}
	return f?-x:x;
}
int n,m;
int a[1005][1005];
int b[1005][1005];
char s[100005];
signed main(){
	freopen("mat.in","r",stdin);
	freopen("mat.out","w",stdout);
	n=read(),m=read();
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
			a[i][j]=read();
		}
	}
	scanf("%s",s+1);
    bool bk=0;
    for(int i=1;i<=m;i++){
        if(s[i]=='I'||s[i]=='C'){
            bk=1;
            break;
        }
    }
    if(!bk){
        int H=0,W=0;
        for(int i=1;i<=m;i++){
            if(s[i]=='L') W--;
            if(s[i]=='R') W++;
            if(s[i]=='U') H--;
            if(s[i]=='D') H++;
        }
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                b[(i+H+n-1)%n+1][(j+W+n-1)%n+1]=a[i][j];
            }
        }
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                printf("%lld ",b[i][j]);
            }
            puts("");
        }
        return 0;
    }
	if(n<=1000){
		for(int i=1;i<=m;i++){
			if(s[i]=='L'){
                for(int j=1;j<=n;j++){
                    for(int t=1;t<=n;t++){
						b[j][t]=a[j][(t)%n+1];
					}
				}
			}
			if(s[i]=='R'){
                for(int j=1;j<=n;j++){
                    for(int t=1;t<=n;t++){
						b[j][(t)%n+1]=a[j][t];
					}
				}
                
			}
			if(s[i]=='U'){
                for(int t=1;t<=n;t++){
                    for(int j=1;j<=n;j++){
						b[j][t]=a[(j)%n+1][t];
					}
				}
			}
			if(s[i]=='D'){
                for(int t=1;t<=n;t++){
                    for(int j=1;j<=n;j++){
						b[(j)%n+1][t]=a[j][t];
					}
				}
			}
			if(s[i]=='I'){
                for(int j=1;j<=n;j++){
                    for(int t=1;t<=n;t++){
						b[j][a[j][t]]=t;
					}
				}
			}
			if(s[i]=='C'){
                for(int t=1;t<=n;t++){
                    for(int j=1;j<=n;j++){
						b[a[j][t]][t]=j;
					}
				}
			}
            for(int j=1;j<=n;j++)
                for(int t=1;t<=n;t++)
                    a[j][t]=b[j][t];
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				printf("%lld ",a[i][j]);
			}
			puts("");
		}
        return 0;
	}
	return 0;
}